from pathlib import Path
import os,subprocess,sys,tempfile,zipfile
from api_doubles import SOURCES

ROOT=Path(__file__).resolve().parent.parent
JAR=Path(sys.argv[1])
CACHE=Path(os.environ.get('HORDES_BUILD_CACHE',str(ROOT/'tools')))
def run(*args,**kwargs):subprocess.run([str(a) for a in args],check=True,**kwargs)
with tempfile.TemporaryDirectory(prefix='hordes-checks-') as folder:
 folder=Path(folder);stubs=folder/'stubs';classes=folder/'classes';runtime=folder/'runtime'
 for name,text in SOURCES.items():
  p=stubs/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 with zipfile.ZipFile(JAR) as z:
  assert z.testzip() is None
  for name in z.namelist():
   if name.startswith(('dev/zomboid/hordes/Chunk','dev/zomboid/hordes/Event','dev/zomboid/hordes/PopulationCommands','dev/zomboid/hordes/InvestigateNoiseGoal')) or name in ['dev/zomboid/hordes/HordeData.class','dev/zomboid/hordes/HordeData$Ticket.class','dev/zomboid/hordes/HordeConfig.class','dev/zomboid/hordes/HordeRules.class','dev/zomboid/hordes/HordeCommands.class']:
    p=runtime/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
 compiler=['java','-jar',CACHE/'ecj.jar','-21','-proc:none','-warn:none']
 gson=str(CACHE/'gson.jar')+':'+str(CACHE/'brigadier.jar')
 run(*compiler,'-cp',str(runtime)+':'+gson,'-d',classes,*sorted(stubs.rglob('*.java')),ROOT/'tests/PopulationChecks.java',ROOT/'tests/IntegrationChecks.java',ROOT/'tests/AttractionChecks.java',ROOT/'tests/CommandChecks.java')
 cp=str(classes)+':'+str(runtime)+':'+gson
 run('java','-Xverify:all','-cp',cp,'PopulationChecks',cwd=folder)
 run('java','-Xverify:all','-cp',cp,'IntegrationChecks',cwd=folder)
 run('java','-Xverify:all','-cp',cp,'AttractionChecks',cwd=folder)
 run('java','-Xverify:all','-cp',cp,'CommandChecks',cwd=folder)
 asmcp=':'.join(str(CACHE/n) for n in ['asm.jar','asm-tree.jar','asm-util.jar','asm-analysis.jar'])
 run(*compiler,'-cp',asmcp,'-d',classes,ROOT/'tests/BytecodeChecks.java')
 run('java','-cp',str(classes)+':'+asmcp,'BytecodeChecks',JAR)
