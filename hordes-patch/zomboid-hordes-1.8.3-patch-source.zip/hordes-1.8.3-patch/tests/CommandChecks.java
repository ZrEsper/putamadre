import dev.zomboid.hordes.*;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.*;
import net.minecraft.server.level.*;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import java.util.*;
public class CommandChecks {
 static int checks;
 static void check(boolean v,String m){checks++;if(!v)throw new AssertionError(m);}
 static final class Rolls extends Random {
  public int nextInt(int bound){return bound==16?8:0;}
 }
 static ServerPlayer player(ServerLevel l,double x){ServerPlayer p=new ServerPlayer();p.world=l;p.x=x;p.y=64;l.players.add(p);return p;}
 public static void main(String[] args)throws Exception {
  ServerLevel l=new ServerLevel();l.random=new Rolls();l.chunks.add("0,0");l.chunks.add("7,0");
  ServerPlayer a=player(l,0),b=player(l,112);CommandSourceStack source=new CommandSourceStack(a);
  CommandDispatcher<CommandSourceStack> dispatcher=new CommandDispatcher<>();
  // Run the actual patched original registration method and the real Mojang parser.
  HordeCommands.register(new RegisterCommandsEvent(dispatcher));
  for(String sub:new String[]{"poblar","horda","estado","dia","noche","ruido","helicoptero","parar","zombis","loot"})
   check(dispatcher.getRoot().getChild("zhorda").getChild(sub)!=null,"Existing/new subcommand registered: "+sub);
  check(dispatcher.execute("zhorda poblar",source)==2,"Force population covers both players");
  check(l.entities.size()==2 && ChunkPopulation.counts(l).size()==2,"At least one zombie per independent loaded chunk");
  check(l.chunkLoads==0,"Global command does not force terrain loading");
  dispatcher.execute("zhorda poblar",source);check(l.entities.size()==2,"Repeated command cannot accumulate duplicates");
  l.entities.get(0).alive=false;dispatcher.execute("zhorda poblar",source);
  check(l.entities.size()==3,"Explicit command refills before cooldown");
  dispatcher.execute("zhorda estado",source);check(source.messages.get(source.messages.size()-1).contains("1–5 zombis por chunk"),"Old status now reports correct per-chunk policy");
  dispatcher.execute("zhorda horda",source);dispatcher.execute("zhorda helicoptero",source);
  check(l.entities.size()==3,"Attraction commands do not enqueue giant waves");
  source.permission=0;boolean denied=false;
  try{dispatcher.execute("zhorda poblar",source);}catch(com.mojang.brigadier.exceptions.CommandSyntaxException e){denied=true;}
  check(denied,"Global force command requires operator permission");
  source.permission=2;a.creative=true;b.creative=true;
  int previous=l.entities.size();check(dispatcher.execute("zhorda poblar",source)==0 && l.entities.size()==previous,"No forced population without eligible players");
  a.creative=false;b.creative=false;l.entities.clear();
  CommandSourceStack console=new CommandSourceStack(l.getServer());
  check(dispatcher.execute("zhorda poblar",console)==2 && l.entities.size()==2,"Dedicated-server console supported");
  l.chunks.clear();for(int x=-4;x<=4;x++)for(int z=-4;z<=4;z++)l.chunks.add(x+","+z);
  b.creative=true;l.entities.clear();l.storage.values.clear();
  check(dispatcher.execute("zhorda poblar",source)==81,"Queue all loaded chunks around survival players");
  check(l.entities.size()<=16,"First command batch has safe spawn budget");
  for(int t=20;t<=600;t+=20) {l.time=t;ChunkPopulation.tick(new net.neoforged.neoforge.event.tick.ServerTickEvent.Post(l.getServer()));}
  check(ChunkPopulation.state(HordeData.get(l)).forced.isEmpty(),"Immediate queue completes without waiting 5–10 minutes");
  check(ChunkPopulation.counts(l).size()==81,"Every safe loaded chunk, including player's own chunk, gets minimum one");
  for(int n:ChunkPopulation.counts(l).values())check(n==1,"Queue respects per-chunk target and max");
  // Refilled chunk cooldown survives save/reload; old pair schedules cannot alias neighbor chunks.
  var data=HordeData.get(l);var restored=HordeData.load(data.save(new net.minecraft.nbt.CompoundTag(),null),null);
  check(ChunkPopulation.state(restored).next.equals(ChunkPopulation.state(data).next),"New per-chunk deadlines persist");
  var legacy=new net.minecraft.nbt.CompoundTag();legacy.putLongArray("chunkPopulationCooldowns",new long[]{0,0,9000});
  legacy.putLong("chunkPopulationPause",8000);
  restored=HordeData.load(legacy,null);
  check(ChunkPopulation.state(restored).next.isEmpty() && ChunkPopulation.state(restored).pausedUntil==8000,"Legacy migration preserves explicit pause and retires pair schedules");
  System.out.println("PASS: "+checks+" real Brigadier/production command, multiplayer refill and save migration checks");
 }
}
