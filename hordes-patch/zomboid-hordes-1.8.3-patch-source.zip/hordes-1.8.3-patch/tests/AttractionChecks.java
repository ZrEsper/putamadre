import dev.zomboid.hordes.*;
import net.minecraft.server.level.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Zombie;
import java.util.*;
public class AttractionChecks {
 static int checks;
 static void check(boolean v,String m){checks++;if(!v)throw new AssertionError(m);}
 static final class Rolls extends Random {
  double value;Rolls(double value){this.value=value;}
  public double nextDouble(){return value;}
  public int nextInt(int bound){return bound/2;}
 }
 static ServerLevel world() {
  ServerLevel l=new ServerLevel();ServerPlayer p=new ServerPlayer();p.world=l;p.x=0;p.y=64;p.z=0;l.players.add(p);return l;
 }
 static Zombie mob(ServerLevel l,int type,double x,double roll) {
  Zombie z=new Zombie();z.world=l;z.x=x;z.y=64;z.z=0;z.rng=new Rolls(roll);
  z.tags.putInt("zi_type",type);z.tags.putDouble("zi_hearing",1);l.entities.add(z);return z;
 }
 public static void main(String[] args) {
  check(EventRules.notice(0,20,96)<EventRules.notice(1,20,96) && EventRules.notice(1,20,96)<EventRules.notice(2,20,96),"Different attention probabilities");
  check(EventRules.notice(2,97,96)==0,"Events cannot be heard outside actual radius");
  check(EventRules.memory(0)<EventRules.memory(1) && EventRules.memory(1)<EventRules.memory(2),"Different memories");
  ServerLevel l=world();ServerPlayer p=l.players.get(0);
  Zombie dull=mob(l,0,30,.70),normal=mob(l,1,30,.70),smart=mob(l,2,30,.70);
  check(EventAttraction.alert(l,p,96,0,false)==2,"Some zombies ignore noise while others commit");
  check(!dull.tags.hasUUID("zha_source") && normal.tags.hasUUID("zha_source") && smart.tags.hasUUID("zha_source"),"No hive-mind reaction");
  check(normal.tags.getLong("zha_until")==1200 && smart.tags.getLong("zha_until")==1800,"Personality-specific memory stored");
  check(normal.target==null && smart.target==null,"Sound does not grant a through-wall attack target");
  Zombie deaf=mob(l,2,60,0);deaf.tags.putDouble("zi_hearing",.1);
  check(EventAttraction.alert(l,p,96,0,false)==2 && !deaf.tags.hasUUID("zha_source"),"Hearing impairment preserved");
  smart.tickCount=20;l.time=100;p.x=5;
  EventAttraction.tick(smart);
  check(net.minecraft.core.BlockPos.of(smart.tags.getLong("zh_pos")).getX()==5,"Audible event refreshes sound position");
  l.time=700;p.x=10;EventAttraction.tick(smart);
  check(net.minecraft.core.BlockPos.of(smart.tags.getLong("zh_pos")).getX()==5,"After sound stops only last known position remains");
  smart.sees=true;EventAttraction.tick(smart);check(smart.target==p,"Real sight permits pursuit");
  smart.sees=false;smart.target=null;smart.rng=new Rolls(.02);
  normal.rng=new Rolls(.02);normal.tickCount=20;l.time=760;
  EventAttraction.tick(normal);EventAttraction.tick(smart);
  check(!normal.tags.hasUUID("zha_source") && smart.tags.hasUUID("zha_source"),"Ordinary zombie loses interest while attentive zombie stays focused");
  l.time=1800;EventAttraction.tick(smart);
  check(!smart.tags.hasUUID("zha_source") && !smart.tags.contains("zh_until"),"Event memory expires");
  l=world();p=l.players.get(0);smart=mob(l,2,80,0);
  check(EventAttraction.alert(l,p,192,0,true)==1,"Helicopter attracts distant zombie");
  InvestigateNoiseGoal goal=new InvestigateNoiseGoal(smart);
  check(goal.canUse(),"Actual investigation goal activates");
  goal.start();check(smart.nav.calls==1 && Math.abs(smart.nav.x-64)<.01 && smart.nav.speed==1.05,"Real goal requests a bounded intermediate waypoint");
  check(smart.x==80,"Navigation never teleports zombie");
  goal.tick();check(smart.nav.calls==1,"Pathfinding throttled");
  l.time=20;goal.tick();check(smart.nav.calls==2,"Attentive zombie replans");
  smart.tags.putLong("zpush_until",100);check(!goal.canUse(),"V stun respected");
  smart.tags.remove("zpush_until");smart.tags.putLong("zc_stun",100);check(!goal.canUse(),"Existing melee stun respected");
  smart.tags.remove("zc_stun");smart.target=p;check(!goal.canUse(),"Investigation yields to real melee attack goal");
  smart.target=null;smart.x=.5;smart.z=.5;check(!goal.canUse(),"Investigation ends within 1.5 blocks");
  smart.x=80;smart.nav.canPath=false;l.time=40;goal.tick();
  check(smart.x==80,"Unreachable route is not bypassed");
  goal.stop();check(smart.nav.stops==1,"Goal releases navigation");
  p.creative=true;l.time=60;EventAttraction.tick(smart);
  check(!smart.tags.hasUUID("zha_source"),"Creative player stops event pursuit");
  l=world();p=l.players.get(0);smart=mob(l,2,60,0);EventAttraction.alert(l,p,96,0,false);
  smart.tickCount=20;p.world=new ServerLevel();l.time=20;EventAttraction.tick(smart);
  check(!smart.tags.hasUUID("zha_source"),"Cross-dimension player is not tracked");
  l=world();p=l.players.get(0);for(int i=0;i<400;i++)mob(l,2,30,0);
  check(EventAttraction.alert(l,p,192,0,true)==320,"Event processing remains bounded");
  System.out.println("PASS: "+checks+" actual attraction/goal personality, sight, distraction and path regression checks with API doubles");
 }
}
