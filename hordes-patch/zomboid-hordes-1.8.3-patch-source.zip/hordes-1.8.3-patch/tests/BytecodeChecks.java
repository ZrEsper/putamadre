import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import org.objectweb.asm.util.CheckClassAdapter;
import java.util.*;
import java.util.zip.*;

public final class BytecodeChecks implements Opcodes {
 static int checks,methods;static final String MOD="dev/zomboid/hordes/";
 static void check(boolean value,String text){checks++;if(!value)throw new AssertionError(text);}
 static ClassNode read(ZipFile z,String n)throws Exception{ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(MOD+n+".class"))).accept(c,0);return c;}
 static MethodNode method(ClassNode c,String n){return c.methods.stream().filter(m->m.name.equals(n)).findFirst().orElseThrow();}
 static boolean calls(MethodNode m,String name){for(AbstractInsnNode i:m.instructions)if(i instanceof MethodInsnNode v&&v.owner.equals(MOD+"ChunkPopulation")&&v.name.equals(name))return true;return false;}
 public static void main(String[] args)throws Exception {
  try(ZipFile z=new ZipFile(args[0])) {
   for(String n:List.of("HordeEvents","HordeData","HordeConfig","HordeCommands","ChunkPopulation","ChunkPopulationRules","ChunkPopulationRules$Pair","ChunkPopulationRules$State","ChunkReflection","PopulationCommands","EventRules","EventAttraction","InvestigateNoiseGoal","ZombieIndividual")) {
    ClassNode c=read(z,n);
    for(MethodNode method:c.methods)for(AbstractInsnNode i:method.instructions)if(i instanceof MethodInsnNode v)
     check(!v.desc.contains("Mob$Navigation") && !v.owner.contains("Mob$Navigation"),"No double-only navigation descriptor in production bytecode");
    c.accept(new CheckClassAdapter(new ClassWriter(0),false));
    for(MethodNode m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0){
     try{new Analyzer<>(new BasicVerifier()).analyze(c.name,m);methods++;}
     catch(AnalyzerException error){throw new AssertionError(c.name+"."+m.name+m.desc,error);}
    }
   }
   ClassNode events=read(z,"HordeEvents");
   for(String name:List.of("serverTick","spawnCheck","join","testHorde","stopHordes"))check(calls(method(events,name),switch(name){case "serverTick"->"tick";case "testHorde"->"test";case "stopHordes"->"pause";default->name;}),"Original event/command wired: "+name);
   long instructions=Arrays.stream(method(events,"startSmall").instructions.toArray()).filter(i->i.getOpcode()>=0).count();
   check(Arrays.stream(method(events,"startSmall").instructions.toArray()).anyMatch(i->i instanceof MethodInsnNode v&&v.owner.equals(MOD+"EventAttraction")&&v.name.equals("start")),"Noise/night triggers attract through personality-aware event hook");
   check(Arrays.stream(method(read(z,"HordeCommands"),"register").instructions.toArray()).anyMatch(i->i instanceof MethodInsnNode v&&v.owner.equals(MOD+"PopulationCommands")&&v.name.equals("register")),"New commands wired into original registered handler");
   check(Arrays.stream(method(read(z,"ZombieIndividual"),"tick").instructions.toArray()).anyMatch(i->i instanceof MethodInsnNode v&&v.owner.equals(MOD+"EventAttraction")&&v.name.equals("tick")),"Personality tracking connected to actual entity tick event");
   check(Arrays.stream(method(read(z,"InvestigateNoiseGoal"),"tick").instructions.toArray()).anyMatch(i->i instanceof MethodInsnNode v&&v.owner.equals(MOD+"EventAttraction")&&v.name.equals("investigate")),"Real investigation goal uses waypoint pathfinding");
   check(calls(method(read(z,"HordeData"),"save"),"write")&&calls(method(read(z,"HordeData"),"load"),"read"),"Persistent pair timers wired into actual SavedData");
   check(calls(method(read(z,"HordeConfig"),"load"),"configure"),"Config migration wired");
   check(read(z,"HordeConfig").fields.stream().anyMatch(f->f.name.equals("populationRadiusChunks")),"Radius config field declared");
   check(read(z,"HordeCommands").methods.stream().anyMatch(m->calls(m,"status")),"Admin status reports real density/cooldowns");
   MethodNode tick=method(events,"serverTick");check(Arrays.stream(tick.instructions.toArray()).noneMatch(i->i instanceof MethodInsnNode v&&v.name.equals("waves")),"Old wave processor is not called");
   check(events.visibleAnnotations!=null && events.visibleAnnotations.stream().anyMatch(a->a.desc.endsWith("EventBusSubscriber;")),"Event bus subscriber preserved");
   check(tick.visibleAnnotations!=null&&tick.visibleAnnotations.stream().anyMatch(a->a.desc.endsWith("SubscribeEvent;")),"Server tick handler remains registered");
   for(ZipEntry e:Collections.list(z.entries()))if(e.getName().startsWith(MOD+"mixin/")&&e.getName().endsWith(".class")){
    ClassNode c=new ClassNode();new ClassReader(z.getInputStream(e)).accept(c,ClassReader.SKIP_CODE);
    check(c.invisibleAnnotations!=null&&c.invisibleAnnotations.stream().anyMatch(a->a.desc.equals("Lorg/spongepowered/asm/mixin/Mixin;")),"CLASS-retained Mixin annotation preserved: "+c.name);
   }
  }
  System.out.println("PASS: "+methods+" methods analyzed; "+checks+" event/wave/save/config/mixin wiring checks");
 }
}
