package dev.zomboid.hordes;

import static dev.zomboid.hordes.ChunkReflection.*;
import java.lang.reflect.Proxy;
import java.util.function.Predicate;

/** Merge new operator subcommands into the existing zhorda tree. */
public final class PopulationCommands {
 public static void register(Object event) {
  Object root=stat("net.minecraft.commands.Commands","literal","zhorda");
  Predicate<Object> op=source->(Boolean)call(source,"hasPermission",2);
  call(root,"requires",op);
  Class<?> command=type("com.mojang.brigadier.Command");
  Object force=Proxy.newProxyInstance(command.getClassLoader(),new Class<?>[]{command},(proxy,method,args)->{
   if(method.getName().equals("run"))return ChunkPopulation.force(args[0]);
   if(method.getName().equals("toString"))return "Hordes immediate population command";
   if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);
   if(method.getName().equals("equals"))return proxy==args[0];
   throw new UnsupportedOperationException(method.getName());
  });
  Object child=stat("net.minecraft.commands.Commands","literal","poblar");
  call(child,"executes",force);call(root,"then",child);
  Object horde=Proxy.newProxyInstance(command.getClassLoader(),new Class<?>[]{command},(proxy,method,args)->{
   if(method.getName().equals("run")) {
    Object source=call(args[0],"getSource"),player=call(source,"getPlayerOrException");
    if(!ChunkPopulation.test(player,1))return 0;
    return 1;
   }
   if(method.getName().equals("toString"))return "Hordes attraction command";
   if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);
   if(method.getName().equals("equals"))return proxy==args[0];
   throw new UnsupportedOperationException(method.getName());
  });
  Object attract=stat("net.minecraft.commands.Commands","literal","horda");
  call(attract,"executes",horde);call(root,"then",attract);
  call(call(event,"getDispatcher"),"register",root);
 }
}
