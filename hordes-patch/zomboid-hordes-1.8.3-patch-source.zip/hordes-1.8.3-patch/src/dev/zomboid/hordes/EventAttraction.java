package dev.zomboid.hordes;

import static dev.zomboid.hordes.ChunkReflection.*;
import java.util.*;

/** Sound cues, individual distraction, real sight and bounded pathfinding. Never teleports. */
public final class EventAttraction {
 private static final String MOD="dev.zomboid.hordes.",MC="net.minecraft.";
 private static long time(Object level){return ((Number)call(level,"getGameTime")).longValue();}
 private static double random(Object mob){return number(call(call(mob,"getRandom"),"nextDouble"));}
 private static Object profile(Object mob){return stat(MOD+"ZombieIndividual","profile",mob);}
 private static long lng(Object tag,String key){return ((Number)call(tag,"getLong",key)).longValue();}
 private static int kind(Object tag){return integer(call(tag,"getInt","zi_type"));}
 private static double distance(Object a,Object b) {
  double dx=number(call(a,"getX"))-number(call(b,"getX"));
  double dy=number(call(a,"getY"))-number(call(b,"getY"));
  double dz=number(call(a,"getZ"))-number(call(b,"getZ"));
  return Math.sqrt(dx*dx+dy*dy+dz*dz);
 }
 private static boolean eligible(Object player) {
  return (Boolean)call(player,"isAlive") && !(Boolean)call(player,"isCreative") && !(Boolean)call(player,"isSpectator");
 }
 private static void hint(Object mob,Object tag,Object player,long now) {
  int spread=EventRules.spread(kind(tag));
  Object rng=call(mob,"getRandom");
  int dx=spread==0?0:integer(call(rng,"nextInt",spread*2+1))-spread;
  int dz=spread==0?0:integer(call(rng,"nextInt",spread*2+1))-spread;
  Object pos=call(call(player,"blockPosition"),"offset",dx,0,dz);
  call(tag,"putLong","zh_pos",call(pos,"asLong"));
  call(tag,"putLong","zh_until",lng(tag,"zha_until"));
  call(tag,"putUUID","zh_player",call(player,"getUUID"));
  call(tag,"putLong","zha_listen_next",now+EventRules.listenDelay(kind(tag)));
 }
 public static int alert(Object level,Object player,double radius,long now,boolean helicopter) {
  if(!eligible(player))return 0;
  List<Object> candidates=new ArrayList<>();
  for(Object mob:(Iterable<?>)call(level,"getAllEntities")) {
   if((Boolean)call(mob,"isAlive") && (Boolean)stat(MOD+"ZombieIndividual","supported",mob) && distance(mob,player)<=radius)candidates.add(mob);
  }
  candidates.sort(Comparator.comparingDouble(m->distance(m,player)));
  int heard=0;
  for(Object mob:candidates.subList(0,Math.min(320,candidates.size()))) {
   Object tag=profile(mob);int type=kind(tag);
   double effective=Math.min(radius,radius*number(call(tag,"getDouble","zi_hearing")));
   if(random(mob)>=EventRules.notice(type,distance(mob,player),effective))continue;
   call(tag,"putUUID","zha_source",call(player,"getUUID"));
   call(tag,"putLong","zha_until",now+EventRules.memory(type));
   call(tag,"putLong","zha_audible_until",now+(helicopter?1800L:600L));
   call(tag,"putDouble","zha_radius",radius);
   call(tag,"putLong","zha_distract_next",now+60L);
   call(tag,"putBoolean","zh_heli",helicopter);
   hint(mob,tag,player,now);heard++;
  }
  return heard;
 }
 /** Compatibility hook for noise/night horde triggers: attract existing mobs, not large waves. */
 public static boolean start(Object level,Object player,int kind,long now) {
  alert(level,player,kind==2?192.0:96.0,now,kind==2);return true;
 }
 private static void forget(Object tag) {
  boolean own=(Boolean)call(tag,"hasUUID","zh_player") && (Boolean)call(tag,"hasUUID","zha_source")
          && call(tag,"getUUID","zh_player").equals(call(tag,"getUUID","zha_source"));
  if(own)for(String key:List.of("zh_until","zh_pos","zh_player","zh_heli"))call(tag,"remove",key);
  for(String key:List.of("zha_until","zha_source","zha_audible_until","zha_radius","zha_listen_next","zha_distract_next"))call(tag,"remove",key);
 }
 public static void tick(Object mob) {
  if(!(Boolean)stat(MOD+"ZombieIndividual","supported",mob) || !(Boolean)call(mob,"isAlive"))return;
  Object level=call(mob,"level");if((Boolean)call(level,"isClientSide"))return;
  if(Math.floorMod(integer(get(mob,"tickCount"))+integer(call(mob,"getId")),20)!=0)return;
  Object tag=profile(mob);if(!(Boolean)call(tag,"hasUUID","zha_source"))return;
  long now=time(level);
  Object player=call(call(call(level,"getServer"),"getPlayerList"),"getPlayer",call(tag,"getUUID","zha_source"));
  if(lng(tag,"zha_until")<=now || player==null || !eligible(player) || call(player,"serverLevel")!=level) {forget(tag);return;}
  boolean sees=(Boolean)stat(MOD+"ZombieIndividual","sees",mob,player);
  if(sees) {
   // The original visual/retaliation rules must authorize any direct attack target.
   Object current=call(mob,"getTarget");
   if(current==null || current==player)call(mob,"setTarget",player);
  } else if(now>=lng(tag,"zha_distract_next")) {
   call(tag,"putLong","zha_distract_next",now+60L);
   if(random(mob)<EventRules.distraction(kind(tag))) {forget(tag);return;}
  }
  // Refresh only while the moving event is audible, never an omniscient GPS target.
  double radius=number(call(tag,"getDouble","zha_radius"));
  double effective=Math.min(radius,radius*number(call(tag,"getDouble","zi_hearing")));
  if(now<lng(tag,"zha_audible_until") && now>=lng(tag,"zha_listen_next") && distance(mob,player)<=effective)hint(mob,tag,player,now);
 }
 /** Intermediate waypoints prevent a distant noise position requiring one huge path. */
 public static void investigate(Object mob) {
  Object level=call(mob,"level"),tag=profile(mob);long now=time(level);
  if(call(mob,"getTarget")!=null || lng(tag,"zh_until")<=now || lng(tag,"zha_nav_next")>now)return;
  call(tag,"putLong","zha_nav_next",now+EventRules.pathDelay(kind(tag)));
  Object pos=stat(MC+"core.BlockPos","of",lng(tag,"zh_pos"));
  double x=number(call(mob,"getX")),y=number(call(mob,"getY")),z=number(call(mob,"getZ"));
  double tx=integer(call(pos,"getX"))+.5,tz=integer(call(pos,"getZ"))+.5;
  double dx=tx-x,dz=tz-z,distance=Math.sqrt(dx*dx+dz*dz);
  double wx=EventRules.waypoint(x,tx,distance),wz=EventRules.waypoint(z,tz,distance);
  double wy=distance>16?y:integer(call(pos,"getY"));
  // No teleport, forced chunk loading or artificial speed/stat boost.
  call(call(mob,"getNavigation"),"moveTo",wx,wy,wz,1.05);
 }
}
