package dev.zomboid.hordes;

import java.util.*;

public final class ChunkPopulationRules {
    public static final int MINIMUM=1, MAXIMUM=5, MIN_COOLDOWN=6000, MAX_COOLDOWN=12000;
    public record Pair(int x,int z) implements Comparable<Pair> {
        public static Pair of(int chunkX,int chunkZ) {return new Pair(chunkX,chunkZ);}
        public int compareTo(Pair other) {int result=Integer.compare(x,other.x);return result==0?Integer.compare(z,other.z):result;}
    }
    public static int chunk(double coordinate) {return (int)Math.floor(coordinate/16.0);}
    /** Exact percent weights: 1=70, 2=18, 3=8, 4=3, 5=1. */
    public static int target(int percent) {
        if(percent<0 || percent>=100)throw new IllegalArgumentException("Chance roll must be 0..99");
        if(percent<70)return 1;if(percent<88)return 2;
        if(percent<96)return 3;if(percent<99)return 4;return 5;
    }
    public static int missing(int live,int target) {
        return Math.max(0,Math.min(MAXIMUM,Math.max(MINIMUM,target))-Math.max(0,live));
    }
    public static long cooldown(long now,int random) {
        if(random<0 || random>MAX_COOLDOWN-MIN_COOLDOWN)throw new IllegalArgumentException("Cooldown roll out of range");
        return Math.addExact(now,MIN_COOLDOWN+random);
    }
    /** Cooldowns live in SavedData, shared by all players in the same dimension. */
    public static final class State {
        public final Map<Pair,Long> next=new TreeMap<>();
        public long pausedUntil;
        public final Map<Pair,Integer> forced=new TreeMap<>();
        public final Map<Pair,Integer> targets=new TreeMap<>();
        public final Map<Pair,Long> rolls=new TreeMap<>();
        public long[] plans() {
            long[] out=new long[targets.size()*4];int i=0;
            for(var e:targets.entrySet()) {out[i++]=e.getKey().x;out[i++]=e.getKey().z;out[i++]=e.getValue();out[i++]=rolls.getOrDefault(e.getKey(),0L);}
            return out;
        }
        public void plans(long[] values) {
            targets.clear();rolls.clear();
            for(int i=0;i+3<values.length;i+=4) {
                if(values[i]<Integer.MIN_VALUE || values[i]>Integer.MAX_VALUE || values[i+1]<Integer.MIN_VALUE || values[i+1]>Integer.MAX_VALUE || values[i+2]<MINIMUM || values[i+2]>MAXIMUM)continue;
                Pair p=Pair.of((int)values[i],(int)values[i+1]);
                targets.put(p,(int)values[i+2]);rolls.put(p,Math.max(0,values[i+3]));
            }
        }
        public boolean due(Pair pair,long now) {return now>=pausedUntil && now>=next.getOrDefault(pair,0L);}
        public long[] encode() {
            long[] out=new long[next.size()*3];int i=0;
            for(var e:next.entrySet()) {out[i++]=e.getKey().x;out[i++]=e.getKey().z;out[i++]=e.getValue();}
            return out;
        }
        public void decode(long[] values) {
            next.clear();
            for(int i=0;i+2<values.length;i+=3) {
                if(values[i]<Integer.MIN_VALUE || values[i]>Integer.MAX_VALUE || values[i+1]<Integer.MIN_VALUE || values[i+1]>Integer.MAX_VALUE)continue;
                Pair p=Pair.of((int)values[i],(int)values[i+1]);
                next.merge(p,Math.max(0,values[i+2]),Math::max);
            }
        }
    }
}
