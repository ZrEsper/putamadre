package dev.zomboid.hordes;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import java.util.EnumSet;
import static dev.zomboid.hordes.ChunkReflection.*;
public final class InvestigateNoiseGoal extends Goal {
 private final Mob zombie;
 public InvestigateNoiseGoal(Mob zombie){this.zombie=zombie;setFlags(EnumSet.of(Flag.MOVE));}
 public boolean canUse() {
  if(zombie.level().isClientSide() || zombie.getTarget()!=null)return false;
  Object tag=call(zombie,"getPersistentData");long now=((Number)call(zombie.level(),"getGameTime")).longValue();
  Object pos=stat("net.minecraft.core.BlockPos","of",call(tag,"getLong","zh_pos"));
  double dx=zombie.getX()-integer(call(pos,"getX"))-.5,dz=zombie.getZ()-integer(call(pos,"getZ"))-.5;
  double dy=zombie.getY()-integer(call(pos,"getY"));
  return ((Number)call(tag,"getLong","zc_stun")).longValue()<=now
      && ((Number)call(tag,"getLong","zpush_until")).longValue()<=now
      && ((Number)call(tag,"getLong","zh_until")).longValue()>now && dx*dx+dy*dy+dz*dz>2.25;
 }
 public boolean canContinueToUse(){return canUse();}
 public void start(){tick();}
 public void tick(){EventAttraction.investigate(zombie);}
 public void stop(){call(call(zombie,"getNavigation"),"stop");}
}
