package dev.zomboid.hordes;

/** Event-specific persistence; the original individual personality stays intact. */
public final class EventRules {
 public static double notice(int type,double distance,double radius) {
  if(radius<=0 || distance>radius)return 0;
  return (type==0?.65:type==1?.85:.98)*(1-.2*distance/radius);
 }
 public static int memory(int type){return type==0?600:type==1?1200:1800;}
 public static int spread(int type){return type==0?5:type==1?2:0;}
 public static double distraction(int type){return type==0?.12:type==1?.04:.006;}
 public static int listenDelay(int type){return type==0?100:type==1?60:20;}
 public static int pathDelay(int type){return type==0?60:type==1?40:20;}
 public static double waypoint(double from,double to,double distance) {
  return distance>16?from+(to-from)*16/distance:to;
 }
}
