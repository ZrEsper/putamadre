from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parent
TOOLS=ROOT/'tools'
EXPECTED={
 'ecj.jar':'01f5a92ac19bb2b3bf85e295a68f2c73c264369109158b566ce9b490af982948',
 'asm.jar':'8cadd43ac5eb6d09de05faecca38b917a040bb9139c7edeb4cc81c740b713281',
 'asm-tree.jar':'9929881f59eb6b840e86d54570c77b59ce721d104e6dfd7a40978991c2d3b41f',
 'asm-util.jar':'f885be71b5c90556f5f1ad1c4f9276b29b96057c497d46666fe4ddbec3cb43c6',
 'asm-analysis.jar':'85b29371884ba31bb76edf22323c2c24e172c3267a67152eba3d1ccc2e041ef2',
 'gson.jar':'4241c14a7727c34feea6507ec801318a3d4a90f070e4525681079fb94ee4c593',
 'brigadier.jar':'84e3904efb986f8a90733f932945cb82f7d120f985145b07149c959fc9813cc3',
}
def run(*args):subprocess.run([str(a) for a in args],check=True)
def main():
 if len(sys.argv)!=2:raise SystemExit('Usage: python3 -B build_183.py HORDES_1.8.2.jar')
 base=Path(sys.argv[1]).resolve()
 assert hashlib.sha256(base.read_bytes()).hexdigest()=='a6128c419a65154ea82ee11cdf3758ef35381048a3f71540d43fb65bb711bb42','Wrong base JAR'
 for n,h in EXPECTED.items():assert hashlib.sha256((TOOLS/n).read_bytes()).hexdigest()==h,n
 compiler=['java','-jar',TOOLS/'ecj.jar','-21','-proc:none','-warn:none']
 asmcp=':'.join(str(TOOLS/n) for n in ('asm.jar','asm-tree.jar'))
 with tempfile.TemporaryDirectory(prefix='hordes-183-') as folder:
  folder=Path(folder);stubs=folder/'stubs';classes=folder/'classes';toolclasses=folder/'tools'
  sys.path.insert(0,str(ROOT/'tests'));from api_doubles import SOURCES
  # Production compile uses only Mob/Goal signatures; packaged output excludes these doubles.
  names=['net/minecraft/world/entity/Entity.java','net/minecraft/world/entity/LivingEntity.java','net/minecraft/world/entity/Mob.java','net/minecraft/world/entity/SpawnGroupData.java','net/minecraft/world/entity/MobSpawnType.java','net/minecraft/world/entity/ai/goal/Goal.java','net/minecraft/world/level/Level.java','net/minecraft/world/level/ServerLevelAccessor.java','net/minecraft/nbt/CompoundTag.java','net/minecraft/nbt/Tag.java','net/minecraft/nbt/ListTag.java','net/minecraft/core/Vec3i.java','net/minecraft/core/BlockPos.java','net/minecraft/world/DifficultyInstance.java']
  # ServerLevelAccessor is not used at runtime by the compiled goal, but Mob's double needs the type.
  for n in names:
   p=stubs/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(SOURCES[n])
  p=stubs/'net/minecraft/server/level/ServerLevel.java';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('package net.minecraft.server.level; public class ServerLevel extends net.minecraft.world.level.Level {}')
  # LivingEntity's small double uses AABB/Vec3 inherited signatures.
  for n in ('net/minecraft/world/phys/AABB.java','net/minecraft/world/phys/Vec3.java'):
   p=stubs/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(SOURCES[n])
  run(*compiler,'-d',classes,*sorted(stubs.rglob('*.java')),*sorted((ROOT/'src').rglob('*.java')))
  run(*compiler,'-cp',asmcp,'-d',toolclasses,TOOLS/'PatchRuntime.java')
  run('java','-cp',str(toolclasses)+':'+asmcp,'PatchRuntime',base,classes)
  changes={p.relative_to(classes).as_posix():p.read_bytes() for p in (classes/'dev/zomboid/hordes').rglob('*.class')}
  with zipfile.ZipFile(base) as z:
   meta='META-INF/neoforge.mods.toml'
   text=z.read(meta).decode().replace('version="1.8.2"','version="1.8.3"').replace('Zomboid Hordes — Chance Population','Zomboid Hordes — Living Population')
   start=text.index('description=')
   # Replace only the mod description; all dependency declarations stay intact.
   prefix=text[:start];rest=text[start:]
   marker=chr(39)*3
   a=rest.index(marker);b=rest.index(marker,a+3)
   rest=rest[:a]+'"""At least one zombie per safe loaded chunk, with rare extras up to five and persistent 5–10 minute cooldowns. Operator global refill command and personality-aware helicopter/horde investigation."""'+rest[b+3:]
   changes[meta]=(prefix+rest).encode()
   added=set(changes)-set(z.namelist())
   assert added=={'dev/zomboid/hordes/'+n+'.class' for n in ('PopulationCommands','EventRules','EventAttraction')},added
   out=ROOT/'output/zomboid-hordes-1.8.3-neoforge-1.21.1-living-population.jar'
   out.parent.mkdir(exist_ok=True)
   with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as result:
    for e in z.infolist():result.writestr(e,changes.get(e.filename,z.read(e)))
    for n in sorted(added):
     e=zipfile.ZipInfo(n,(1980,1,1,0,0,0));e.compress_type=zipfile.ZIP_DEFLATED;result.writestr(e,changes[n])
  with zipfile.ZipFile(base) as original,zipfile.ZipFile(out) as result:
   assert result.testzip() is None
   assert len(result.namelist())==len(set(result.namelist()))
   assert set(result.namelist())==set(original.namelist())|added
   assert all(original.read(n)==result.read(n) for n in original.namelist() if n not in changes)
   assert all(not n.startswith(('net/','com/mojang/')) for n in result.namelist())
   print('PASS: only declared population/event/command/goal classes and metadata changed; unrelated code, assets and dependency requirements preserved',flush=True)
  run(sys.executable,'-B',ROOT/'tests/run.py',out)
 print('Output:',out)
 print('SHA256:',hashlib.sha256(out.read_bytes()).hexdigest())
 print('Full Minecraft modpack startup/integration is not verified by API doubles.')
if __name__=='__main__':main()
