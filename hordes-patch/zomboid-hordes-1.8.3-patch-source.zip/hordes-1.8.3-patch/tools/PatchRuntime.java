import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
public class PatchRuntime implements Opcodes {
 static final String MOD="dev/zomboid/hordes/";
 static byte[] patch(byte[] bytes,String name) {
  ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);int changed=0;
  for(MethodNode m:c.methods) {
   if(name.equals("HordeCommands") && m.name.equals("register")) {
    for(AbstractInsnNode i:m.instructions.toArray())if(i.getOpcode()==RETURN) {
     InsnList add=new InsnList();add.add(new VarInsnNode(ALOAD,0));
     add.add(new MethodInsnNode(INVOKESTATIC,MOD+"PopulationCommands","register","(Ljava/lang/Object;)V",false));
     m.instructions.insertBefore(i,add);changed++;
    }
   }
   if(name.equals("HordeEvents") && m.name.equals("startSmall")) {
    if(!m.desc.endsWith(";IIJ)Z"))throw new IllegalStateException("Unexpected horde signature "+m.desc);
    m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
    m.visibleLocalVariableAnnotations=null;m.invisibleLocalVariableAnnotations=null;
    m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new VarInsnNode(ALOAD,2));
    m.instructions.add(new VarInsnNode(ILOAD,3));m.instructions.add(new VarInsnNode(LLOAD,5));
    m.instructions.add(new MethodInsnNode(INVOKESTATIC,MOD+"EventAttraction","start","(Ljava/lang/Object;Ljava/lang/Object;IJ)Z",false));
    m.instructions.add(new InsnNode(IRETURN));m.maxLocals=7;changed++;
   }
   if(name.equals("ZombieIndividual") && m.name.equals("tick")) {
    MethodInsnNode entity=null;
    for(AbstractInsnNode i:m.instructions)if(i instanceof MethodInsnNode call && call.name.equals("getEntity")){entity=call;break;}
    if(entity==null)throw new IllegalStateException("Missing tick entity accessor");
    InsnList add=new InsnList();add.add(new VarInsnNode(ALOAD,0));
    add.add(new MethodInsnNode(entity.getOpcode(),entity.owner,entity.name,entity.desc,entity.itf));
    add.add(new MethodInsnNode(INVOKESTATIC,MOD+"EventAttraction","tick","(Ljava/lang/Object;)V",false));
    m.instructions.insert(add);changed++;
   }
  }
  if(changed!=1)throw new IllegalStateException("Expected exactly one hook in "+name+", got "+changed);
  ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(writer);return writer.toByteArray();
 }
 public static void main(String[] args)throws Exception {
  try(ZipFile z=new ZipFile(args[0])) {
   for(String name:List.of("HordeCommands","HordeEvents","ZombieIndividual")) {
    byte[] original=z.getInputStream(z.getEntry(MOD+name+".class")).readAllBytes();
    Path p=Path.of(args[1],MOD+name+".class");Files.createDirectories(p.getParent());Files.write(p,patch(original,name));
   }
  }
 }
}
