package dev.zomboid.hordes;

import java.lang.reflect.*;
import java.util.concurrent.ConcurrentHashMap;

/** Mojmap runtime bridge, for Minecraft/NeoForge APIs. */
public final class ChunkReflection {
    private static final ConcurrentHashMap<String, Method> METHODS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, Field> FIELDS = new ConcurrentHashMap<>();
    public static Class<?> type(String name) {
        try { return Class.forName(name); }
        catch (ClassNotFoundException e) { throw new IllegalStateException(name,e); }
    }
    private static Class<?> boxed(Class<?> c) {
        if (c==int.class) return Integer.class;
        if (c==double.class) return Double.class;
        if (c==float.class) return Float.class;
        if (c==boolean.class) return Boolean.class;
        if (c==long.class) return Long.class;
        return c;
    }
    private static boolean fits(Class<?>[] types,Object[] args) {
        if (types.length!=args.length) return false;
        for(int i=0;i<args.length;i++) if(args[i]==null ? types[i].isPrimitive() : !boxed(types[i]).isInstance(args[i])) return false;
        return true;
    }
    public static Object call(Object target,String name,Object...args) {
        Class<?> c=target instanceof Class<?> k?k:target.getClass();
        String key=c.getName()+"#"+name;
        for(Object a:args) key+=":"+(a==null?"null":a.getClass().getName());
        Method m=METHODS.get(key);
        if(m==null) {
            for(Class<?> k=c;k!=null && m==null;k=k.getSuperclass())
                for(Method candidate:k.getDeclaredMethods())
                    if(candidate.getName().equals(name) && fits(candidate.getParameterTypes(),args)) {m=candidate;break;}
            // Public methods inherited from interfaces.
            if(m==null) for(Method candidate:c.getMethods())
                if(candidate.getName().equals(name) && fits(candidate.getParameterTypes(),args)) {m=candidate;break;}
            if(m==null) throw new IllegalStateException("Missing method "+key);
            m.setAccessible(true); METHODS.put(key,m);
        }
        try {return m.invoke(target instanceof Class<?>?null:target,args);}
        catch(ReflectiveOperationException e) {throw new IllegalStateException(key,e);}
    }
    public static Object stat(String name,String method,Object...args) {return call(type(name),method,args);}
    public static Object get(Object target,String name) {
        Class<?> c=target instanceof Class<?> k?k:target.getClass();
        String key=c.getName()+"#"+name;
        Field f=FIELDS.get(key);
        if(f==null) {
            for(Class<?> k=c;k!=null;k=k.getSuperclass()) {
                try { f=k.getDeclaredField(name);break; } catch(NoSuchFieldException ignored) {}
            }
            if(f==null) throw new IllegalStateException("Missing field "+key);
            f.setAccessible(true); FIELDS.put(key,f);
        }
        try {return f.get(target instanceof Class<?>?null:target);}
        catch(IllegalAccessException e) {throw new IllegalStateException(key,e);}
    }
    public static Object create(String name,Object...args) {
        for(Constructor<?> c:type(name).getConstructors()) if(fits(c.getParameterTypes(),args)) {
            try {return c.newInstance(args);} catch(ReflectiveOperationException e) {throw new IllegalStateException(name,e);}
        }
        throw new IllegalStateException("Missing constructor "+name);
    }
    public static int integer(Object value) {return ((Number)value).intValue();}
    public static double number(Object value) {return ((Number)value).doubleValue();}
    public static Object constant(String c,String name) {return get(type(c),name);}
    public static void set(Object target,String name,Object value) {
        Class<?> c=target instanceof Class<?> k?k:target.getClass();
        for(Class<?> k=c;k!=null;k=k.getSuperclass()) {
            try {Field f=k.getDeclaredField(name);f.setAccessible(true);f.set(target instanceof Class<?>?null:target,value);return;}
            catch(NoSuchFieldException ignored) {}
            catch(IllegalAccessException e) {throw new IllegalStateException(name,e);}
        }
        throw new IllegalStateException("Missing field "+name);
    }
}
