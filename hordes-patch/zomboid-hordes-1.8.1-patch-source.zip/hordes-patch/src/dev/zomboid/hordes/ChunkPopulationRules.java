package dev.zomboid.hordes;

import java.util.*;

public final class ChunkPopulationRules {
    public static final int MINIMUM=2, MIN_COOLDOWN=6000, MAX_COOLDOWN=12000;
    public record Pair(int x,int z) implements Comparable<Pair> {
        public static Pair of(int chunkX,int chunkZ) {return new Pair(Math.floorDiv(chunkX,2)*2,chunkZ);}
        public int compareTo(Pair other) {int result=Integer.compare(x,other.x);return result==0?Integer.compare(z,other.z):result;}
    }
    public static int chunk(double coordinate) {return (int)Math.floor(coordinate/16.0);}
    public static int missing(int live) {return Math.max(0,MINIMUM-Math.max(0,live));}
    public static int[] assignments(int live,boolean first,boolean second) {
        int[] out=new int[2];
        if(missing(live)>0) out[first?0:1]++;
        if(missing(live)>1) out[second?0:1]++;
        return out;
    }
    public static long cooldown(long now,int random) {
        if(random<0 || random>MAX_COOLDOWN-MIN_COOLDOWN)throw new IllegalArgumentException("Cooldown roll out of range");
        return Math.addExact(now,MIN_COOLDOWN+random);
    }
    /** Cooldowns live in SavedData, shared by all players in the same dimension. */
    public static final class State {
        public final Map<Pair,Long> next=new TreeMap<>();
        public long pausedUntil;
        public boolean due(Pair pair,long now) {return now>=pausedUntil && now>=next.getOrDefault(pair,0L);}
        public long[] encode() {
            long[] out=new long[next.size()*3];int i=0;
            for(var e:next.entrySet()) {out[i++]=e.getKey().x;out[i++]=e.getKey().z;out[i++]=e.getValue();}
            return out;
        }
        public void decode(long[] values) {
            next.clear();
            for(int i=0;i+2<values.length;i+=3) {
                if(values[i]<Integer.MIN_VALUE || values[i]>Integer.MAX_VALUE || values[i+1]<Integer.MIN_VALUE || values[i+1]>Integer.MAX_VALUE)continue;
                Pair p=Pair.of((int)values[i],(int)values[i+1]);
                next.merge(p,Math.max(0,values[i+2]),Math::max);
            }
        }
    }
}
