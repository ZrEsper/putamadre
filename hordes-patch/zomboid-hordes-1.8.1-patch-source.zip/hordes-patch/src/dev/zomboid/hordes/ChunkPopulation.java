package dev.zomboid.hordes;

import static dev.zomboid.hordes.ChunkReflection.*;
import dev.zomboid.hordes.ChunkPopulationRules.Pair;
import dev.zomboid.hordes.ChunkPopulationRules.State;
import java.nio.file.*;
import java.util.*;
import java.util.function.Supplier;

/** Density replacement for automatic waves, keeping the original noise/AI integration. */
public final class ChunkPopulation {
    static final String MC="net.minecraft.", MOD="dev.zomboid.hordes.";
    private static final Map<Object,State> STATES=Collections.synchronizedMap(new WeakHashMap<>());
    public static State state(Object data) {return STATES.computeIfAbsent(data,k->new State());}
    private static Object events() {return type(MOD+"HordeEvents");}
    private static Object config() {return constant(MOD+"ZomboidHordes","CONFIG");}
    private static Object data(Object level) {return stat(MOD+"HordeData","get",level);}
    private static long time(Object level) {return ((Number)call(level,"getGameTime")).longValue();}
    private static boolean eligible(Object p) {return (Boolean)call(events(),"eligible",p);}
    private static boolean enabled(Object level) {
        return !"PEACEFUL".equals(String.valueOf(call(level,"getDifficulty"))) &&
                (Boolean)call(call(level,"getGameRules"),"getBoolean",constant(MC+"world.level.GameRules","RULE_DOMOBSPAWNING"));
    }
    private static boolean overworld(Object level) {
        return call(level,"dimension").equals(constant(MC+"world.level.Level","OVERWORLD"));
    }
    private static List<Object> players(Object level) {
        List<Object> out=new ArrayList<>();
        for(Object p:(List<?>)call(level,"players")) if(eligible(p))out.add(p);
        return out;
    }
    private static int roll(Object level,int bound) {return integer(call(get(level,"random"),"nextInt",bound));}
    private static boolean coin(Object level) {return (Boolean)call(get(level,"random"),"nextBoolean");}
    private static long next(Object level,long now) {return ChunkPopulationRules.cooldown(now,roll(level,6001));}
    private static void dirty(Object data) {call(data,"setDirty");}

    /** Additive config migration: keep unrelated balances and existing custom values. */
    public static void configure(Object cfg) {
        int radius=integer(get(cfg,"populationRadiusChunks"));
        if(radius<1 || radius>8) throw new IllegalArgumentException("populationRadiusChunks must be 1..8");
        if(integer(get(cfg,"balanceVersion"))<9) {
            set(cfg,"balanceVersion",9);
            Object gson=call(call(create("com.google.gson.GsonBuilder"),"setPrettyPrinting"),"create");
            try {Files.writeString(Path.of("config","zomboid-hordes.json"),(String)call(gson,"toJson",cfg));}
            catch(java.io.IOException e) {throw new IllegalStateException("Could not save chunk population config",e);}
        }
    }
    public static void write(Object data,Object tag) {
        State s=state(data);
        call(tag,"putLongArray","chunkPopulationCooldowns",s.encode());
        call(tag,"putLong","chunkPopulationPause",s.pausedUntil);
    }
    public static void read(Object data,Object tag) {
        State s=new State();s.decode((long[])call(tag,"getLongArray","chunkPopulationCooldowns"));
        s.pausedUntil=Math.max(0,((Number)call(tag,"getLong","chunkPopulationPause")).longValue());
        STATES.put(data,s);
    }

    public static void tick(Object event) {
        Object server=call(event,"getServer"),level=call(server,"overworld");
        long now=time(level);if(now%20!=0)return;
        // Keep exactly the original cache cleanup and the awareness integration.
        Map<?,?> noise=(Map<?,?>)get(events(),"noise");
        noise.keySet().removeIf(id->call(call(server,"getPlayerList"),"getPlayer",id)==null);
        Map<?,?> heard=(Map<?,?>)get(events(),"heard");
        heard.entrySet().removeIf(e->now>((Number)e.getValue()).longValue());
        List<Object> players=players(level);
        if(players.isEmpty() || !enabled(level))return;
        call(events(),"configureAwareness");
        Object data=data(level);
        List<?> tickets=(List<?>)get(data,"tickets");
        // Old-world wave tickets must never leak bursts into the new system.
        if(!tickets.isEmpty()) {tickets.clear();dirty(data);}
        helicopter(level,data,players,now);
        for(Object p:players) call(events(),"listen",level,data,p,now);
        populate(level,data,players,now);
    }

    private static boolean loaded(Object level,int x,int z) {
        return (Boolean)call(call(level,"getChunkSource"),"hasChunk",x,z);
    }
    public static Set<Pair> pairs(Object level,List<Object> players) {
        int radius=integer(get(config(),"populationRadiusChunks"));
        Set<Pair> out=new TreeSet<>();
        for(Object p:players) {
            int cx=ChunkPopulationRules.chunk(number(call(p,"getX"))),cz=ChunkPopulationRules.chunk(number(call(p,"getZ")));
            for(int x=cx-radius;x<=cx+radius;x++)for(int z=cz-radius;z<=cz+radius;z++) {
                Pair pair=Pair.of(x,z);
                if(loaded(level,pair.x(),z) && loaded(level,pair.x()+1,z))out.add(pair);
            }
        }
        return out;
    }
    public static Map<Pair,Integer> counts(Object level) {
        Map<Pair,Integer> counts=new HashMap<>();
        for(Object mob:(Iterable<?>)call(level,"getAllEntities")) {
            if(!(Boolean)call(mob,"isAlive") || !(Boolean)stat(MOD+"ZombieIndividual","supported",mob))continue;
            Pair pair=Pair.of(ChunkPopulationRules.chunk(number(call(mob,"getX"))),ChunkPopulationRules.chunk(number(call(mob,"getZ"))));
            counts.merge(pair,1,Integer::sum);
        }
        return counts;
    }
    /** Bounded initial filling; a full pair never receives extra zombies. */
    public static int populate(Object level,Object data,List<Object> players,long now) {
        State state=state(data);
        if(now<state.pausedUntil)return 0;
        Set<Pair> all=pairs(level,players);
        List<Pair> due=all.stream().filter(p->state.due(p,now)).toList();
        if(due.isEmpty())return 0;
        Map<Pair,Integer> counts=counts(level);
        int spawned=0;int[] attempts={256};
        for(Pair pair:due) {
            if(spawned>=16 || attempts[0]<=0)break;
            int missing=ChunkPopulationRules.missing(counts.getOrDefault(pair,0));
            int local=0;
            for(int i=0;i<missing && spawned<16 && attempts[0]>0;i++) {
                int first=coin(level)?pair.x():pair.x()+1;
                boolean success=spawnInChunk(level,players,first,pair.z(),attempts)
                        || spawnInChunk(level,players,first==pair.x()?pair.x()+1:pair.x(),pair.z(),attempts);
                if(success) {spawned++;local++;}
            }
            // Failed terrain searches can retry; any actual spawn starts the full cooldown.
            state.next.put(pair,missing==0 || local>0?next(level,now):now+200);
            dirty(data);
        }
        return spawned;
    }
    public static boolean spawnInChunk(Object level,List<Object> players,int chunkX,int chunkZ,int[] attempts) {
        if(!loaded(level,chunkX,chunkZ))return false;
        for(int i=0;i<24 && attempts[0]>0;i++) {
            attempts[0]--;
            int x=chunkX*16+roll(level,16),z=chunkZ*16+roll(level,16);
            Object base=create(MC+"core.BlockPos",x,0,z);
            Object pos=call(level,"getHeightmapPos",constant(MC+"world.level.levelgen.Heightmap$Types","MOTION_BLOCKING_NO_LEAVES"),base);
            if(!(Boolean)call(call(level,"getWorldBorder"),"isWithinBounds",pos))continue;
            double y=number(call(pos,"getY"));
            boolean near=false;
            for(Object p:players) {
                double dx=number(call(p,"getX"))-x-.5,dz=number(call(p,"getZ"))-z-.5;
                if(dx*dx+dz*dz<24*24) {near=true;break;}
            }
            if(near)continue;
            Object closest=players.stream().min(Comparator.comparingDouble(p->{double dx=number(call(p,"getX"))-x,dz=number(call(p,"getZ"))-z;return dx*dx+dz*dz;})).orElseThrow();
            if(Math.abs(number(call(closest,"getY"))-y)>28)continue;
            Object below=call(pos,"below");
            if(!(Boolean)call(call(level,"getBlockState",below),"isValidSpawn",level,below,constant(MC+"world.entity.EntityType","ZOMBIE")))continue;
            if(!(Boolean)call(call(level,"getFluidState",pos),"isEmpty") || !(Boolean)call(call(level,"getFluidState",call(pos,"above")),"isEmpty"))continue;
            Object chosen=call(events(),"pick",level,pos),zombie=call(chosen,"create",level);
            if(zombie==null || !type(MC+"world.entity.monster.Zombie").isInstance(zombie))continue;
            call(zombie,"moveTo",x+.5,y,z+.5,(float)number(call(get(level,"random"),"nextFloat"))*360.0f,0.0f);
            if(!(Boolean)call(level,"noCollision",zombie))continue;
            call(zombie,"finalizeSpawn",level,call(level,"getCurrentDifficultyAt",pos),constant(MC+"world.entity.MobSpawnType","EVENT"),null);
            call(zombie,"setCanPickUpLoot",false);
            call(zombie,"setPersistenceRequired");
            Object tags=call(zombie,"getPersistentData");call(tags,"putBoolean","zh_spawned",true);call(tags,"putBoolean","zh_population",true);
            stat(MOD+"ZombieIndividual","profile",zombie);
            boolean night=(Boolean)stat(MOD+"HordeRules","night",call(level,"getDayTime"));
            call(events(),"attributes",zombie,night);
            if((Boolean)call(level,"addFreshEntity",zombie))return true;
        }
        return false;
    }

    /** Helicopter sound/event survives, but attracts existing zombies instead of creating waves. */
    private static void helicopter(Object level,Object data,List<Object> players,long now) {
        long dayTime=((Number)call(level,"getDayTime")).longValue(),day=Math.floorDiv(dayTime,24000);
        if(day>((Number)get(data,"lastDay")).longValue()) {
            set(data,"lastDay",day);
            double chance=number(get(config(),"helicopterChance"));
            boolean event=number(call(get(level,"random"),"nextDouble"))<chance;
            long schedule=event?((Number)stat(MOD+"HordeRules","schedule",dayTime,roll(level,10001))).longValue():-1L;
            set(data,"helicopterAt",schedule);dirty(data);
        }
        long at=((Number)get(data,"helicopterAt")).longValue();
        if(at>=0 && dayTime>=at) {
            set(data,"helicopterAt",-1L);dirty(data);
            helicopterNow(level,players.get(roll(level,players.size())),now);
        }
    }
    private static void helicopterNow(Object level,Object player,long now) {
        call(events(),"announce",level,player,2);
        call(events(),"alert",level,call(player,"blockPosition"),player,192.0,now+1800,true);
    }
    public static void spawnCheck(Object event) {
        Object mob=call(event,"getEntity"),level=call(call(event,"getLevel"),"getLevel");
        if(!overworld(level) || !(Boolean)stat(MOD+"ZombieIndividual","supported",mob))return;
        String reason=String.valueOf(call(event,"getSpawnType"));
        if(reason.equals("NATURAL") || reason.equals("CHUNK_GENERATION"))
            call(event,"setResult",constant("net.neoforged.neoforge.event.entity.living.MobSpawnEvent$PositionCheck$Result","FAIL"));
    }
    public static void join(Object event) {
        Object level=call(event,"getLevel");
        if((Boolean)call(level,"isClientSide") || (Boolean)call(event,"loadedFromDisk") || !overworld(level))return;
        Object mob=call(event,"getEntity");
        if(!(Boolean)stat(MOD+"ZombieIndividual","supported",mob))return;
        Object tags=call(mob,"getPersistentData");
        if((Boolean)call(tags,"getBoolean","zh_spawned"))return;
        String reason=(String)call(tags,"getString","zh_spawn_reason");
        if(reason.equals("NATURAL") || reason.equals("CHUNK_GENERATION"))call(event,"setCanceled",true);
    }
    public static boolean test(Object player,int kind) {
        Object level=call(player,"serverLevel");
        if(!eligible(player) || !overworld(level) || !enabled(level))return false;
        Object data=data(level);long now=time(level);
        if(kind==2)helicopterNow(level,player,now);
        int spawned=populate(level,data,players(level),now);
        call(player,"sendSystemMessage",stat(MC+"network.chat.Component","literal","Población revisada: "+spawned+" zombis añadidos. Se respeta el mínimo de 2 por par y el cooldown de 5–10 minutos."));
        return true;
    }
    public static int pause(Object player) {
        Object level=call(player,"serverLevel"),data=data(level);State s=state(data);
        s.pausedUntil=next(level,time(level));dirty(data);
        return pairs(level,players(level)).size();
    }
    public static int status(Object context) {
        Object source=call(context,"getSource"),player=call(source,"getPlayerOrException"),level=call(player,"serverLevel");
        Object data=data(level);State s=state(data);long now=time(level);
        Set<Pair> all=pairs(level,players(level));Map<Pair,Integer> counts=counts(level);
        long deficient=all.stream().filter(p->ChunkPopulationRules.missing(counts.getOrDefault(p,0))>0).count();
        long earliest=all.stream().mapToLong(p->Math.max(s.pausedUntil,s.next.getOrDefault(p,0L))).min().orElse(now);
        String message="Población por chunks: mínimo 2 zombis por par; cooldown 5–10 min. Pares cargados activos: "+all.size()+"; bajo el mínimo: "+deficient+". Próxima revisión: "+Math.max(0,(earliest-now+19)/20)+" s. Helicóptero programado: "+(((Number)get(data,"helicopterAt")).longValue()>=0?"sí":"no")+".";
        Supplier<Object> text=()->stat(MC+"network.chat.Component","literal",message);
        call(source,"sendSuccess",text,false);return all.size();
    }
}
