import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

public final class PatchHordes implements Opcodes {
    static final String MOD="dev/zomboid/hordes/",HELPER=MOD+"ChunkPopulation";
    static int edits;
    static MethodNode method(ClassNode c,String name){return c.methods.stream().filter(m->m.name.equals(name)).findFirst().orElseThrow(()->new IllegalStateException("Missing "+c.name+"."+name));}
    static void clear(MethodNode m) {
        m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
        m.visibleLocalVariableAnnotations=null;m.invisibleLocalVariableAnnotations=null;edits++;
    }
    static InsnList hook(String name,String desc,int...slots) {
        InsnList code=new InsnList();for(int slot:slots)code.add(new VarInsnNode(ALOAD,slot));
        code.add(new MethodInsnNode(INVOKESTATIC,HELPER,name,desc,false));return code;
    }
    static void bridge(MethodNode m,String name,String desc,int ret,int...slots) {clear(m);m.instructions.add(hook(name,desc,slots));m.instructions.add(new InsnNode(ret));}
    static byte[] patch(byte[] data) {
        ClassNode c=new ClassNode();new ClassReader(data).accept(c,0);
        switch(c.name.substring(MOD.length())) {
            case "HordeEvents":
                bridge(method(c,"serverTick"),"tick","(Ljava/lang/Object;)V",RETURN,0);
                for(String n:List.of("spawnCheck","join")) {method(c,n).instructions.insert(hook(n,"(Ljava/lang/Object;)V",0));edits++;}
                MethodNode start=method(c,"startSmall");clear(start);start.instructions.add(new InsnNode(ICONST_0));start.instructions.add(new InsnNode(IRETURN));
                MethodNode test=method(c,"testHorde");clear(test);
                test.instructions.add(new VarInsnNode(ALOAD,0));test.instructions.add(new VarInsnNode(ILOAD,1));
                test.instructions.add(new MethodInsnNode(INVOKESTATIC,HELPER,"test","(Ljava/lang/Object;I)Z",false));test.instructions.add(new InsnNode(IRETURN));
                bridge(method(c,"stopHordes"),"pause","(Ljava/lang/Object;)I",IRETURN,0);
                for(AbstractInsnNode i:method(c,"announce").instructions.toArray())
                    if(i instanceof LdcInsnNode s && s.cst instanceof String text && text.contains("[Helicóptero]")) {
                        s.cst="§c[Helicóptero] Un helicóptero sobrevuela la zona. Su ruido atrae a los zombis ya presentes; no genera oleadas nuevas.";edits++;
                    }
                break;
            case "HordeData":
                MethodNode load=method(c,"load");
                for(AbstractInsnNode i:load.instructions.toArray())if(i.getOpcode()==ARETURN) {
                    InsnList h=new InsnList();h.add(new InsnNode(DUP));h.add(new VarInsnNode(ALOAD,0));
                    h.add(new MethodInsnNode(INVOKESTATIC,HELPER,"read","(Ljava/lang/Object;Ljava/lang/Object;)V",false));
                    load.instructions.insertBefore(i,h);edits++;
                }
                MethodNode save=method(c,"save");
                for(AbstractInsnNode i:save.instructions.toArray())if(i.getOpcode()==ARETURN) {save.instructions.insertBefore(i,hook("write","(Ljava/lang/Object;Ljava/lang/Object;)V",0,1));edits++;}
                break;
            case "HordeConfig":
                c.fields.add(new FieldNode(ACC_PUBLIC,"populationRadiusChunks","I",null,null));
                MethodNode ctor=method(c,"<init>");
                for(AbstractInsnNode i:ctor.instructions.toArray())if(i.getOpcode()==RETURN) {
                    InsnList h=new InsnList();h.add(new VarInsnNode(ALOAD,0));h.add(new InsnNode(ICONST_4));
                    h.add(new FieldInsnNode(PUTFIELD,c.name,"populationRadiusChunks","I"));ctor.instructions.insertBefore(i,h);edits++;
                }
                MethodNode config=method(c,"load");
                for(AbstractInsnNode i:config.instructions.toArray())if(i.getOpcode()==ARETURN) {
                    InsnList h=new InsnList();h.add(new InsnNode(DUP));h.add(new MethodInsnNode(INVOKESTATIC,HELPER,"configure","(Ljava/lang/Object;)V",false));
                    config.instructions.insertBefore(i,h);edits++;
                }break;
            case "HordeCommands":
                int status=0;
                for(MethodNode m:c.methods) {
                    boolean found=false;
                    for(AbstractInsnNode i:m.instructions.toArray()) {
                        if(m.desc.endsWith(")I") && i instanceof MethodInsnNode call && call.owner.equals(MOD+"HordeData") && call.name.equals("get"))found=true;
                        if(i instanceof LdcInsnNode l && l.cst instanceof String text && text.startsWith("Prueba iniciada."))
                            l.cst="Prueba de población ejecutada. /zhorda estado muestra densidad y cooldowns. No se cambia la hora ni se crean oleadas grandes.";
                        if(i instanceof InvokeDynamicInsnNode indy)for(int j=0;j<indy.bsmArgs.length;j++)
                            if(indy.bsmArgs[j] instanceof String text && text.startsWith("Se cancelaron "))
                                indy.bsmArgs[j]="Se pausó la reposición en el Overworld durante 5–10 minutos (\u0001 pares activos). Los zombis existentes siguen ahí.";
                    }
                    if(found) {bridge(m,"status","(Ljava/lang/Object;)I",IRETURN,0);status++;}
                }
                if(status!=1)throw new IllegalStateException("Expected one status command; got "+status);
                break;
            default:throw new IllegalArgumentException(c.name);
        }
        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);return w.toByteArray();
    }
    public static void main(String[] args)throws Exception {
        Set<String> targets=new HashSet<>(List.of("HordeEvents","HordeData","HordeConfig","HordeCommands"));
        try(ZipFile input=new ZipFile(args[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(args[2])))) {
            for(ZipEntry e:Collections.list(input.entries())) {
                byte[] data=input.getInputStream(e).readAllBytes();
                if(e.getName().startsWith(MOD) && e.getName().endsWith(".class")) {
                    String name=e.getName().substring(MOD.length(),e.getName().length()-6);
                    if(targets.remove(name))data=patch(data);
                }
                ZipEntry z=new ZipEntry(e.getName());z.setTime(0);out.putNextEntry(z);out.write(data);out.closeEntry();
            }
            if(!targets.isEmpty())throw new IllegalStateException("Missing classes: "+targets);
            try(var paths=Files.walk(Path.of(args[1]))) {
                for(Path path:paths.filter(p->p.toString().endsWith(".class")).sorted().toList()) {
                    ZipEntry z=new ZipEntry(Path.of(args[1]).relativize(path).toString());z.setTime(0);out.putNextEntry(z);out.write(Files.readAllBytes(path));out.closeEntry();
                }
            }
        }
        System.out.println("Patched "+edits+" population/config/save/command hooks.");
    }
}
