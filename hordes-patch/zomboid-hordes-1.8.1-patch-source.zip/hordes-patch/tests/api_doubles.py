# Signature-based Minecraft/NeoForge API doubles; never packaged in the mod.
SOURCES={'net/minecraft/nbt/Tag.java': 'package net.minecraft.nbt; public class Tag {}',
 'net/minecraft/network/chat/Component.java': 'package net.minecraft.network.chat;public record '
                                              'Component(String text) {public static Component '
                                              'literal(String text){return new Component(text);}}',
 'net/minecraft/resources/ResourceLocation.java': 'package net.minecraft.resources;public record '
                                                  'ResourceLocation(String ns,String path) {\n'
                                                  ' public static ResourceLocation '
                                                  'fromNamespaceAndPath(String ns,String path){return new '
                                                  'ResourceLocation(ns,path);}\n'
                                                  ' public String getNamespace(){return ns;} public String '
                                                  'getPath(){return path;} public String toString(){return '
                                                  'ns+":"+path;}}\n',
 'net/minecraft/world/entity/Entity.java': 'package net.minecraft.world.entity;\n'
                                           'import net.minecraft.world.phys.*;import '
                                           'net.minecraft.world.level.Level;\n'
                                           'public class Entity {\n'
                                           ' public double x,y,z;public boolean alive=true;public int '
                                           'tickCount;public Level world;public String '
                                           'type="minecraft:entity";\n'
                                           ' public double getX(){return x;}public double getY(){return '
                                           'y;}public double getZ(){return z;}\n'
                                           ' public boolean isAlive(){return alive;}public Level '
                                           'level(){return world;}\n'
                                           ' public Object getType(){return type;}public double '
                                           'distanceToSqr(Entity e){return '
                                           '(x-e.x)*(x-e.x)+(y-e.y)*(y-e.y)+(z-e.z)*(z-e.z);}\n'
                                           ' public AABB getBoundingBox(){return new '
                                           'AABB(x-.3,y,z-.3,x+.3,y+1.8,z+.3);}\n'
                                           '}',
 'net/minecraft/world/entity/LivingEntity.java': 'package net.minecraft.world.entity;public class '
                                                 'LivingEntity extends Entity {public float yBodyRot;public '
                                                 'double getEyeY(){return y+1.62;}}',
 'net/minecraft/world/entity/Mob.java': 'package net.minecraft.world.entity;\n'
                                        'public class Mob extends LivingEntity {public LivingEntity '
                                        'target;public Navigation nav=new Navigation();\n'
                                        ' public void setTarget(LivingEntity e){target=e;}public Navigation '
                                        'getNavigation(){return nav;}\n'
                                        ' public static class Navigation {public Entity destination;public '
                                        'boolean moveTo(Entity e,double speed){destination=e;return true;}}\n'
                                        '}',
 'net/minecraft/world/entity/monster/Zombie.java': 'package net.minecraft.world.entity.monster;public class '
                                                   'Zombie extends net.minecraft.world.entity.Mob {public '
                                                   'Zombie(){type="minecraft:zombie";}}',
 'net/minecraft/world/phys/AABB.java': 'package net.minecraft.world.phys;public class AABB {\n'
                                       ' public double minX,minY,minZ,maxX,maxY,maxZ;\n'
                                       ' public AABB(double x,double y,double z,double a,double b,double '
                                       'c){minX=x;minY=y;minZ=z;maxX=a;maxY=b;maxZ=c;}\n'
                                       ' public AABB inflate(double d){return new '
                                       'AABB(minX-d,minY-d,minZ-d,maxX+d,maxY+d,maxZ+d);}\n'
                                       '}',
 'net/minecraft/world/phys/Vec3.java': 'package net.minecraft.world.phys; public class Vec3 {public final '
                                       'double x,y,z;public Vec3(double x,double y,double '
                                       'z){this.x=x;this.y=y;this.z=z;}}'}
SOURCES.update({
'net/minecraft/core/Vec3i.java':'''package net.minecraft.core;public class Vec3i {
 protected int x,y,z;public Vec3i(int x,int y,int z){this.x=x;this.y=y;this.z=z;}
 public int getX(){return x;}public int getY(){return y;}public int getZ(){return z;}}
''',
'net/minecraft/core/BlockPos.java':'''package net.minecraft.core;public class BlockPos extends Vec3i {
 public BlockPos(int x,int y,int z){super(x,y,z);}public BlockPos below(){return new BlockPos(x,y-1,z);}public BlockPos above(){return new BlockPos(x,y+1,z);}
 public long asLong(){return ((long)x&0x3ffffff)<<38|((long)z&0x3ffffff)<<12|((long)y&0xfff);}
 public static BlockPos of(long v){return new BlockPos((int)(v>>38),(int)(v<<52>>52),(int)(v<<26>>38));}}
''',
'net/minecraft/core/HolderLookup.java':'''package net.minecraft.core;public class HolderLookup {public interface Provider {}}''',
'net/minecraft/nbt/CompoundTag.java':'''package net.minecraft.nbt;import java.util.*;
public class CompoundTag extends Tag {
 public final Map<String,Object> values=new HashMap<>();
 public Tag put(String k,Tag t){return (Tag)values.put(k,t);}public CompoundTag getCompound(String k){return values.get(k) instanceof CompoundTag t?t:new CompoundTag();}
 public boolean contains(String k){return values.containsKey(k);}public void remove(String k){values.remove(k);}
 public void putInt(String k,int v){values.put(k,v);}public int getInt(String k){return values.get(k) instanceof Number n?n.intValue():0;}
 public void putLong(String k,long v){values.put(k,v);}public long getLong(String k){return values.get(k) instanceof Number n?n.longValue():0;}
 public void putBoolean(String k,boolean v){values.put(k,v);}public boolean getBoolean(String k){return Boolean.TRUE.equals(values.get(k));}
 public void putString(String k,String v){values.put(k,v);}public String getString(String k){return values.get(k) instanceof String s?s:"";}
 public void putUUID(String k,UUID v){values.put(k,v);}public UUID getUUID(String k){return (UUID)values.get(k);}public boolean hasUUID(String k){return values.get(k) instanceof UUID;}
 public void putLongArray(String k,long[] v){values.put(k,v.clone());}public long[] getLongArray(String k){return values.get(k) instanceof long[] v?v.clone():new long[0];}
 public ListTag getList(String k,int type){return values.get(k) instanceof ListTag t?t:new ListTag();}
}''',
'net/minecraft/nbt/ListTag.java':'''package net.minecraft.nbt;import java.util.*;
public class ListTag extends Tag implements Iterable<Tag> {public List<Tag> values=new ArrayList<>();
 public boolean add(Tag t){return values.add(t);}public boolean add(Object t){return add((Tag)t);}
 public int size(){return values.size();}public CompoundTag getCompound(int i){return (CompoundTag)values.get(i);}public Iterator<Tag> iterator(){return values.iterator();}}
''',
'net/minecraft/world/entity/Entity.java':'''package net.minecraft.world.entity;
import net.minecraft.world.level.Level;import net.minecraft.core.BlockPos;import net.minecraft.nbt.CompoundTag;
public class Entity {public double x,y,z;public Level world;public boolean alive=true;public int tickCount;public CompoundTag tags=new CompoundTag();
 public double getX(){return x;}public double getY(){return y;}public double getZ(){return z;}
 public Level level(){return world;}public boolean isAlive(){return alive;}public CompoundTag getPersistentData(){return tags;}
 public BlockPos blockPosition(){return new BlockPos((int)Math.floor(x),(int)Math.floor(y),(int)Math.floor(z));}
}''',
'net/minecraft/world/entity/Mob.java':'''package net.minecraft.world.entity;
import net.minecraft.world.level.ServerLevelAccessor;import net.minecraft.world.DifficultyInstance;
public class Mob extends LivingEntity {public boolean persistent,loot=true,profiled,night,finalized;
 public void moveTo(double x,double y,double z,float yaw,float pitch){this.x=x;this.y=y;this.z=z;}
 public void setPersistenceRequired(){persistent=true;}public void setCanPickUpLoot(boolean v){loot=v;}
 public SpawnGroupData finalizeSpawn(ServerLevelAccessor l,DifficultyInstance d,MobSpawnType t,SpawnGroupData group){finalized=true;return group;}}
''',
'net/minecraft/world/entity/MobSpawnType.java':'''package net.minecraft.world.entity;public enum MobSpawnType {NATURAL,CHUNK_GENERATION,SPAWN_EGG,SPAWNER,COMMAND,EVENT,REINFORCEMENT}''',
'net/minecraft/world/entity/SpawnGroupData.java':'''package net.minecraft.world.entity;public interface SpawnGroupData {}''',
'net/minecraft/world/entity/EntityType.java':'''package net.minecraft.world.entity;
import net.minecraft.world.level.Level;import net.minecraft.world.entity.monster.Zombie;
public class EntityType<T extends Entity> {public static final EntityType<Zombie> ZOMBIE=new EntityType<>();
 public Entity create(Level l){Zombie z=new Zombie();z.world=l;return z;}}
''',
'net/minecraft/world/entity/monster/Zombie.java':'''package net.minecraft.world.entity.monster;public class Zombie extends net.minecraft.world.entity.Mob {}''',
'net/minecraft/world/entity/player/Player.java':'''package net.minecraft.world.entity.player;public class Player extends net.minecraft.world.entity.LivingEntity {}''',
'net/minecraft/server/level/ServerPlayer.java':'''package net.minecraft.server.level;
import java.util.*;import net.minecraft.network.chat.Component;
public class ServerPlayer extends net.minecraft.world.entity.player.Player {
 public boolean creative,spectator;public UUID uuid=UUID.randomUUID();public List<String> messages=new ArrayList<>();
 public boolean isCreative(){return creative;}public boolean isSpectator(){return spectator;}public UUID getUUID(){return uuid;}
 public ServerLevel serverLevel(){return (ServerLevel)world;}public void sendSystemMessage(Component c){messages.add(c.text());}}
''',
'net/minecraft/world/level/Level.java':'''package net.minecraft.world.level;public class Level {public static final Object OVERWORLD=new Object();public boolean isClientSide(){return false;}}''',
'net/minecraft/world/level/ServerLevelAccessor.java':'''package net.minecraft.world.level;import net.minecraft.server.level.ServerLevel;public interface ServerLevelAccessor {ServerLevel getLevel();}''',
'net/minecraft/world/Difficulty.java':'''package net.minecraft.world;public enum Difficulty {PEACEFUL,NORMAL}''',
'net/minecraft/world/DifficultyInstance.java':'''package net.minecraft.world;public class DifficultyInstance {}''',
'net/minecraft/world/level/GameRules.java':'''package net.minecraft.world.level;public class GameRules {public static final Object RULE_DOMOBSPAWNING=new Object();public boolean spawn=true;public boolean getBoolean(Object rule){return spawn;}}''',
'net/minecraft/world/level/levelgen/Heightmap.java':'''package net.minecraft.world.level.levelgen;public class Heightmap {public enum Types {MOTION_BLOCKING_NO_LEAVES}}''',
'net/minecraft/world/level/block/state/BlockState.java':'''package net.minecraft.world.level.block.state;
import net.minecraft.world.level.Level;import net.minecraft.core.BlockPos;import net.minecraft.world.entity.EntityType;
public class BlockState {public boolean valid;public BlockState(boolean v){valid=v;}public boolean isValidSpawn(Level l,BlockPos p,EntityType<?> t){return valid;}}''',
'net/minecraft/world/level/material/FluidState.java':'''package net.minecraft.world.level.material;public class FluidState {public boolean empty;public FluidState(boolean v){empty=v;}public boolean isEmpty(){return empty;}}''',
'net/minecraft/world/level/border/WorldBorder.java':'''package net.minecraft.world.level.border;import net.minecraft.core.BlockPos;
public class WorldBorder {public boolean valid=true;public boolean isWithinBounds(BlockPos p){return valid;}}''',
'net/minecraft/util/datafix/DataFixTypes.java':'''package net.minecraft.util.datafix;public class DataFixTypes {}''',
'net/minecraft/world/level/saveddata/SavedData.java':'''package net.minecraft.world.level.saveddata;
import java.util.function.*;import net.minecraft.nbt.CompoundTag;import net.minecraft.core.HolderLookup;import net.minecraft.util.datafix.DataFixTypes;
public abstract class SavedData {public int dirties;public void setDirty(){dirties++;}public abstract CompoundTag save(CompoundTag t,HolderLookup.Provider p);
 public static record Factory<T extends SavedData>(Supplier<T> constructor,BiFunction<CompoundTag,HolderLookup.Provider,T> loader,DataFixTypes type){}}
''',
'net/minecraft/world/level/storage/DimensionDataStorage.java':'''package net.minecraft.world.level.storage;
import java.util.*;import net.minecraft.world.level.saveddata.SavedData;
public class DimensionDataStorage {public Map<String,SavedData> values=new HashMap<>();public <T extends SavedData> T computeIfAbsent(SavedData.Factory<T> f,String id){return (T)values.computeIfAbsent(id,k->f.constructor().get());}}
''',
'net/minecraft/server/level/ServerLevel.java':'''package net.minecraft.server.level;
import java.util.*;import net.minecraft.world.level.*;import net.minecraft.world.entity.*;import net.minecraft.world.*;
import net.minecraft.world.level.levelgen.Heightmap;import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.border.WorldBorder;import net.minecraft.world.level.storage.DimensionDataStorage;
public class ServerLevel extends Level implements ServerLevelAccessor {
 public Random random=new Random(15);public long time,day=5000;public Object dimension=OVERWORLD;public Difficulty difficulty=Difficulty.NORMAL;
 public List<ServerPlayer> players=new ArrayList<>();public List<Entity> entities=new ArrayList<>();public Set<String> chunks=new HashSet<>();
 public boolean solid=true,dry=true,collisionFree=true,accept=true;public GameRules rules=new GameRules();public WorldBorder border=new WorldBorder();
 public int chunkLoads,added;public DimensionDataStorage storage=new DimensionDataStorage();
 public ServerLevel getLevel(){return this;}public Object dimension(){return dimension;}public long getGameTime(){return time;}public long getDayTime(){return day;}
 public List<ServerPlayer> players(){return players;}public Difficulty getDifficulty(){return difficulty;}public GameRules getGameRules(){return rules;}
 public Iterable<Entity> getAllEntities(){return entities;}public DimensionDataStorage getDataStorage(){return storage;}
 public ChunkSource getChunkSource(){return new ChunkSource(this);}public BlockPos getHeightmapPos(Heightmap.Types t,BlockPos p){
  if(!chunks.contains((p.getX()>>4)+","+(p.getZ()>>4)))chunkLoads++;return new BlockPos(p.getX(),64,p.getZ());}
 public BlockState getBlockState(BlockPos p){return new BlockState(solid);}public FluidState getFluidState(BlockPos p){return new FluidState(dry);}
 public WorldBorder getWorldBorder(){return border;}public boolean noCollision(Entity e){return collisionFree;}
 public DifficultyInstance getCurrentDifficultyAt(BlockPos p){return new DifficultyInstance();}
 public boolean addFreshEntity(Entity e){if(!accept)return false;entities.add(e);added++;return true;}
 public static class ChunkSource {public ServerLevel l;public ChunkSource(ServerLevel l){this.l=l;}public boolean hasChunk(int x,int z){return l.chunks.contains(x+","+z);}}
}''',
'net/minecraft/server/MinecraftServer.java':'''package net.minecraft.server;
import net.minecraft.server.level.*;import java.util.*;
public class MinecraftServer {public ServerLevel level;public MinecraftServer(ServerLevel l){level=l;}public ServerLevel overworld(){return level;}
 public PlayerList getPlayerList(){return new PlayerList(level);}public static class PlayerList {public ServerLevel level;public PlayerList(ServerLevel l){level=l;}public ServerPlayer getPlayer(UUID id){return level.players.stream().filter(p->p.uuid.equals(id)).findFirst().orElse(null);}}}
''',
'net/neoforged/neoforge/event/tick/ServerTickEvent.java':'''package net.neoforged.neoforge.event.tick;import net.minecraft.server.MinecraftServer;
public class ServerTickEvent {public record Post(MinecraftServer server) {public MinecraftServer getServer(){return server;}}}
''',
'net/neoforged/neoforge/event/entity/living/MobSpawnEvent.java':'''package net.neoforged.neoforge.event.entity.living;
import net.minecraft.world.entity.Mob;import net.minecraft.world.entity.MobSpawnType;import net.minecraft.world.level.ServerLevelAccessor;
public class MobSpawnEvent {public static class PositionCheck {
 public Mob mob;public ServerLevelAccessor level;public MobSpawnType reason;public Result result=Result.DEFAULT;
 public PositionCheck(Mob m,ServerLevelAccessor l,MobSpawnType r){mob=m;level=l;reason=r;}
 public Mob getEntity(){return mob;}public ServerLevelAccessor getLevel(){return level;}public MobSpawnType getSpawnType(){return reason;}public void setResult(Result r){result=r;}
 public enum Result {FAIL,DEFAULT}}}
''',
'net/neoforged/neoforge/event/entity/EntityJoinLevelEvent.java':'''package net.neoforged.neoforge.event.entity;
import net.minecraft.world.entity.Entity;import net.minecraft.world.level.Level;
public class EntityJoinLevelEvent {public Entity e;public Level level;public boolean disk,canceled;
 public EntityJoinLevelEvent(Entity e,Level l,boolean disk){this.e=e;level=l;this.disk=disk;}
 public Entity getEntity(){return e;}public Level getLevel(){return level;}public boolean loadedFromDisk(){return disk;}public void setCanceled(boolean v){canceled=v;}}
''',
'dev/zomboid/hordes/ZomboidHordes.java':'''package dev.zomboid.hordes;public class ZomboidHordes {public static HordeConfig CONFIG=new HordeConfig();}''',
'dev/zomboid/hordes/ZombieIndividual.java':'''package dev.zomboid.hordes;
import net.minecraft.world.entity.*;import net.minecraft.world.entity.monster.Zombie;
public class ZombieIndividual {public static boolean supported(Entity e){return e instanceof Zombie;}
 public static Object profile(Mob mob){mob.profiled=true;return mob.tags;}}
''',
'dev/zomboid/hordes/HordeEvents.java':'''package dev.zomboid.hordes;
import java.util.*;import net.minecraft.server.level.*;import net.minecraft.world.entity.*;import net.minecraft.world.entity.monster.Zombie;import net.minecraft.core.BlockPos;
public class HordeEvents {private static Map<UUID,Object> noise=new HashMap<>();private static Map<Object,Long> heard=new HashMap<>();
 public static int listens,announces,alerts;private static boolean eligible(ServerPlayer p){return p.alive&&!p.creative&&!p.spectator;}
 private static void configureAwareness(){}private static void listen(ServerLevel l,HordeData d,ServerPlayer p,long t){listens++;}
 private static EntityType<?> pick(ServerLevel l,BlockPos p){return EntityType.ZOMBIE;}
 private static void attributes(Zombie z,boolean night){z.night=night;}
 private static void announce(ServerLevel l,ServerPlayer p,int kind){announces++;}
 private static void alert(ServerLevel l,BlockPos b,ServerPlayer p,double r,long until,boolean heli){alerts++;}}
''',
'net/minecraft/commands/CommandSourceStack.java':'''package net.minecraft.commands;
import java.util.*;import java.util.function.Supplier;import net.minecraft.server.level.ServerPlayer;import net.minecraft.network.chat.Component;
public class CommandSourceStack {public ServerPlayer p;public List<String> messages=new ArrayList<>();public CommandSourceStack(ServerPlayer p){this.p=p;}
 public ServerPlayer getPlayerOrException(){return p;}public void sendSuccess(Supplier<Component> message,boolean broadcast){messages.add(message.get().text());}}
''',
'com/mojang/brigadier/context/CommandContext.java':'''package com.mojang.brigadier.context;public class CommandContext<T> {public T source;public CommandContext(T source){this.source=source;}public T getSource(){return source;}}'''
})
