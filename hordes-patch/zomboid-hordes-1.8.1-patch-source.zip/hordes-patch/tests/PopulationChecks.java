import dev.zomboid.hordes.ChunkPopulationRules;
import dev.zomboid.hordes.ChunkPopulationRules.*;
import java.util.*;

public final class PopulationChecks {
 static int assertions;
 static void check(boolean test,String text){assertions++;if(!test)throw new AssertionError(text);}
 public static void main(String[] args) {
  int singles=0,empty=0,doubles=0;
  for(boolean a:new boolean[]{false,true})for(boolean b:new boolean[]{false,true}) {
   int[] counts=ChunkPopulationRules.assignments(0,a,b);
   check(counts[0]+counts[1]==2,"Every empty pair receives two zombies");
   if(counts[0]==1)singles++;if(counts[0]==0)empty++;if(counts[0]==2)doubles++;
  }
  check(singles==2 && empty==1 && doubles==1,"Exactly one zombie per chunk has 50% probability");
  check(Arrays.stream(ChunkPopulationRules.assignments(1,true,false)).sum()==1,"Only replace the single deficit");
  for(int n=2;n<=1000;n++)check(Arrays.stream(ChunkPopulationRules.assignments(n,true,true)).sum()==0,"No population accumulation above minimum");
  for(int roll=0;roll<=6000;roll++) {
   long next=ChunkPopulationRules.cooldown(123456,roll);
   check(next>=129456 && next<=135456,"Cooldown inside exact 5–10 minute range");
  }
  check(ChunkPopulationRules.cooldown(100,0)==6100 && ChunkPopulationRules.cooldown(100,6000)==12100,"Inclusive cooldown endpoints");
  for(int x=-1000;x<=1000;x++) {
   Pair pair=Pair.of(x,8);
   check(pair.x()%2==0 && (x==pair.x() || x==pair.x()+1),"Negative chunk pairing is stable");
   check(pair.equals(Pair.of(pair.x()+1,8)),"Neighbors share one cooldown key");
  }
  check(ChunkPopulationRules.chunk(-.1)==-1 && ChunkPopulationRules.chunk(-16)==-1 && ChunkPopulationRules.chunk(-16.1)==-2,"World-to-chunk conversion uses floor");
  State s=new State();Pair p=Pair.of(-1,3);s.next.put(p,6000L);
  check(!s.due(p,5999) && s.due(p,6000),"Kills/reloads cannot bypass existing cooldown");
  s.pausedUntil=7000;check(!s.due(p,6000) && s.due(p,7000),"Admin pause applied to all pairs");
  State loaded=new State();loaded.decode(s.encode());check(loaded.next.equals(s.next),"Stable persistent cooldown roundtrip");
  loaded.decode(new long[]{-1,3,99,-2,3,100,Long.MAX_VALUE,1,200,0,0,-1,12});
  check(loaded.next.size()==2 && loaded.next.get(p)==100 && loaded.next.get(Pair.of(0,0))==0,"Malformed/duplicate saved keys normalized safely");
  System.out.println("PASS: "+assertions+" density/distribution/cooldown/persistence assertions");
 }
}
