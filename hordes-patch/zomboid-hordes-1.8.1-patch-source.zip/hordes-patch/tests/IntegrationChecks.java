import dev.zomboid.hordes.*;
import dev.zomboid.hordes.ChunkPopulationRules.*;
import net.minecraft.server.level.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.core.*;
import net.minecraft.nbt.*;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.event.entity.living.MobSpawnEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.minecraft.commands.CommandSourceStack;
import com.mojang.brigadier.context.CommandContext;
import java.util.*;
import java.nio.file.*;

/** Actual patch classes and patched HordeData/HordeConfig, with API doubles. */
public final class IntegrationChecks {
 static int checks;
 static void check(boolean v,String m){checks++;if(!v)throw new AssertionError(m);}
 static ServerPlayer player(ServerLevel level,double x,double z) {
  ServerPlayer p=new ServerPlayer();p.world=level;p.x=x;p.y=64;p.z=z;level.players.add(p);return p;
 }
 static ServerLevel world() {
  ServerLevel l=new ServerLevel();for(int x=-8;x<=8;x++)for(int z=-8;z<=8;z++)l.chunks.add(x+","+z);return l;
 }
 public static void main(String[] args)throws Exception {
  HordeConfig cfg=HordeConfig.load();
  check(cfg.balanceVersion==9 && cfg.populationRadiusChunks==4,"Real config load migrates fresh settings");
  check(Files.readString(Path.of("config/zomboid-hordes.json")).contains("populationRadiusChunks"),"New setting persisted with real Gson");
  Files.writeString(Path.of("config/zomboid-hordes.json"),"{\"balanceVersion\":8,\"daySpeed\":-0.12,\"populationRadiusChunks\":2}");
  cfg=HordeConfig.load();check(cfg.balanceVersion==9 && cfg.populationRadiusChunks==2 && cfg.daySpeed==-.12,"Existing unrelated settings preserved in migration");
  String saved=Files.readString(Path.of("config/zomboid-hordes.json"));HordeConfig.load();
  check(Files.readString(Path.of("config/zomboid-hordes.json")).equals(saved),"Config migration repeatable");
  cfg.populationRadiusChunks=0;boolean rejected=false;try{ChunkPopulation.configure(cfg);}catch(IllegalArgumentException expected){rejected=true;}
  check(rejected,"Invalid population radius rejected");
  cfg.populationRadiusChunks=1;cfg.helicopterChance=0;ZomboidHordes.CONFIG=cfg;
  ServerLevel level=world();ServerPlayer p=player(level,0,0);HordeData data=HordeData.get(level);
  Set<Pair> pairs=ChunkPopulation.pairs(level,new ArrayList<>(level.players));
  check(pairs.size()==6,"Fixed adjacent pairs around player");
  int initial=ChunkPopulation.populate(level,data,new ArrayList<>(level.players),0);
  check(initial==12 && level.entities.size()==12,"Initial fill creates exactly two per pair, not a horde");
  for(Pair pair:pairs)check(ChunkPopulation.counts(level).get(pair)==2,"Every valid pair reaches minimum");
  for(Entity e:level.entities) {
   Mob mob=(Mob)e;
   check(mob.persistent && !mob.loot && mob.finalized && mob.profiled,"Actual spawned entity initialized and retained");
   check(e.tags.getBoolean("zh_spawned") && e.tags.getBoolean("zh_population"),"Population tagging bypasses old daytime join cap");
   check(e.x*e.x+e.z*e.z>=576,"No spawn within 24 blocks of a player");
  }
  check(level.chunkLoads==0,"Only loaded chunks inspected; no generation or forced loading");
  ServerPlayer second=player(level,0,0);
  check(ChunkPopulation.pairs(level,new ArrayList<>(level.players)).size()==pairs.size(),"Overlapping players share pairs");
  check(ChunkPopulation.populate(level,data,new ArrayList<>(level.players),1)==0 && level.entities.size()==12,"No multiplayer duplicate population or immediate repeat");
  Zombie killed=(Zombie)level.entities.get(0);killed.alive=false;
  Pair pair=Pair.of(ChunkPopulationRules.chunk(killed.x),ChunkPopulationRules.chunk(killed.z));
  long next=ChunkPopulation.state(data).next.get(pair);
  check(next>=6000 && next<=12000,"Actual random cooldown is 5–10 minutes");
  level.time=next-1;
  check(ChunkPopulation.populate(level,data,new ArrayList<>(level.players),level.time)==0,"Killed zombie not replenished before cooldown");
  level.time=next;
  check(ChunkPopulation.populate(level,data,new ArrayList<>(level.players),level.time)==1,"Cooldown expiry replaces only the missing zombie");
  check(ChunkPopulation.counts(level).get(pair)==2,"Replenishment restores minimum without accumulation");
  CompoundTag savedData=data.save(new CompoundTag(),null);
  HordeData restored=HordeData.load(savedData,null);
  check(ChunkPopulation.state(restored).next.equals(ChunkPopulation.state(data).next),"Real patched SavedData roundtrip retains all cooldowns");
  check(ChunkPopulation.populate(level,restored,new ArrayList<>(level.players),level.time)==0,"Save/reload cannot bypass cooldown");
  HordeData legacy=HordeData.load(new CompoundTag(),null);check(ChunkPopulation.state(legacy).next.isEmpty(),"Old worlds migrate without invalid timers");

  level.time+=1;int added=level.added;MinecraftServer server=new MinecraftServer(level);ServerTickEvent.Post event=new ServerTickEvent.Post(server);
  ChunkPopulation.tick(event);check(level.added==added,"Server event runs only once per 20 ticks");
  level.time=20000;level.difficulty=Difficulty.PEACEFUL;ChunkPopulation.tick(event);
  check(level.added==added,"Peaceful disables replenishment");level.difficulty=Difficulty.NORMAL;
  level.rules.spawn=false;ChunkPopulation.tick(event);check(level.added==added,"doMobSpawning respected");level.rules.spawn=true;
  p.creative=true;second.spectator=true;ChunkPopulation.tick(event);check(level.added==added,"Creative and spectator do not activate spawn areas");
  p.creative=false;second.spectator=false;
  data.tickets.add(new HordeData.Ticket(p.uuid,new BlockPos(0,64,0),1,80,0));
  int listens=HordeEvents.listens;ChunkPopulation.tick(event);
  check(data.tickets.isEmpty() && HordeEvents.listens==listens+2,"Old wave tickets discarded; sound tracking still active");
  check(level.added==added,"A full population does not receive new zombies on timer");
  data.helicopterAt=level.day;int announces=HordeEvents.announces,alerts=HordeEvents.alerts;
  ChunkPopulation.tick(event);
  check(HordeEvents.announces==announces+1 && HordeEvents.alerts==alerts+1 && level.added==added,"Helicopter attracts existing zombies without creating waves");
  int paused=ChunkPopulation.pause(p);long until=ChunkPopulation.state(data).pausedUntil;
  check(paused==6 && until>=level.time+6000 && until<=level.time+12000,"Stop command pauses global refill for 5–10 minutes");
  restored=HordeData.load(data.save(new CompoundTag(),null),null);check(ChunkPopulation.state(restored).pausedUntil==until,"Pause persists across restart");
  CommandSourceStack source=new CommandSourceStack(p);ChunkPopulation.status(new CommandContext<>(source));
  check(source.messages.get(0).contains("mínimo 2") && source.messages.get(0).contains("5–10 min"),"Status command exposes the actual population policy");
  check(ChunkPopulation.test(p,3),"Legacy test command still works with new density policy");
  check(level.added==added,"Test command respects pause/cooldowns");

  Zombie natural=new Zombie();natural.world=level;
  MobSpawnEvent.PositionCheck spawn=new MobSpawnEvent.PositionCheck(natural,level,MobSpawnType.NATURAL);ChunkPopulation.spawnCheck(spawn);
  check(spawn.result==MobSpawnEvent.PositionCheck.Result.FAIL,"Vanilla natural spawn cannot bypass cooldown");
  for(MobSpawnType reason:new MobSpawnType[]{MobSpawnType.SPAWN_EGG,MobSpawnType.SPAWNER,MobSpawnType.COMMAND,MobSpawnType.EVENT}) {
   spawn=new MobSpawnEvent.PositionCheck(natural,level,reason);ChunkPopulation.spawnCheck(spawn);
   check(spawn.result==MobSpawnEvent.PositionCheck.Result.DEFAULT,"Explicit spawn source preserved: "+reason);
  }
  natural.tags.putString("zh_spawn_reason","NATURAL");EntityJoinLevelEvent join=new EntityJoinLevelEvent(natural,level,false);ChunkPopulation.join(join);
  check(join.canceled,"Natural join fallback blocked");
  join=new EntityJoinLevelEvent(natural,level,true);ChunkPopulation.join(join);check(!join.canceled,"Existing saved zombies never deleted");
  natural.tags.putBoolean("zh_spawned",true);join=new EntityJoinLevelEvent(natural,level,false);ChunkPopulation.join(join);
  check(!join.canceled,"Population-generated event zombie accepted");
  natural.tags.putBoolean("zh_spawned",false);level.dimension=new Object();spawn=new MobSpawnEvent.PositionCheck(natural,level,MobSpawnType.NATURAL);
  ChunkPopulation.spawnCheck(spawn);check(spawn.result==MobSpawnEvent.PositionCheck.Result.DEFAULT,"Other dimensions unchanged");level.dimension=net.minecraft.world.level.Level.OVERWORLD;

  ServerLevel bad=world();ServerPlayer bp=player(bad,0,0);HordeData bd=HordeData.get(bad);List<Object> players=new ArrayList<>(bad.players);
  bad.dry=false;check(ChunkPopulation.populate(bad,bd,players,0)==0,"No zombie spawned in water");
  bad.dry=true;bad.solid=false;check(!ChunkPopulation.spawnInChunk(bad,players,4,4,new int[]{24}),"Invalid floor rejected");
  bad.solid=true;bad.collisionFree=false;check(!ChunkPopulation.spawnInChunk(bad,players,4,4,new int[]{24}),"Solid collision rejected");
  bad.collisionFree=true;bad.border.valid=false;check(!ChunkPopulation.spawnInChunk(bad,players,4,4,new int[]{24}),"World border respected");
  bad.border.valid=true;bad.accept=false;check(!ChunkPopulation.spawnInChunk(bad,players,4,4,new int[]{24}),"Canceled entity insertion is not counted as a spawn");
  int[] budget={7};ChunkPopulation.spawnInChunk(bad,players,4,4,budget);check(budget[0]==0,"Failed terrain search obeys bounded attempt budget");
  bad.chunks.clear();check(ChunkPopulation.pairs(bad,players).isEmpty() && !ChunkPopulation.spawnInChunk(bad,players,4,4,new int[]{24}),"Unloaded chunks excluded");
  check(bad.chunkLoads==0,"Failed searches never force chunk loading");
  ServerLevel big=world();ZomboidHordes.CONFIG.populationRadiusChunks=4;player(big,0,0);
  int first=ChunkPopulation.populate(big,HordeData.get(big),new ArrayList<>(big.players),0);
  check(first<=16,"Initial terrain generation cannot create an unbounded spawn burst");
  for(int t=20;t<=200;t+=20)ChunkPopulation.populate(big,HordeData.get(big),new ArrayList<>(big.players),t);
  for(Pair key:ChunkPopulation.pairs(big,new ArrayList<>(big.players)))check(ChunkPopulation.counts(big).getOrDefault(key,0)==2,"Bounded filling eventually covers every valid active pair");
  System.out.println("PASS: "+checks+" actual helper/SavedData/config integration assertions (Minecraft API doubles)");
 }
}
