#!/usr/bin/env python3
"""Build and validate the chunk-population patch over the exact supplied JAR."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,zipfile

ROOT=Path(__file__).resolve().parent
BASE=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/attachments/a35cc6e7-3376-4547-b875-9120a9111014/zomboid-hordes-1.8.0-neoforge-1.21.1.jar')
CACHE=Path(os.environ.get('HORDES_BUILD_CACHE',str(ROOT/'tools')))
OUTPUT=ROOT/'output/zomboid-hordes-1.8.1-neoforge-1.21.1-chunk-population.jar'
BASE_HASH='e4a38448a57dca20a4ef87508b64770b53f3a8abe5013a1d1c567fc1c3c3dc7c'
HASHES={
 'ecj.jar':'01f5a92ac19bb2b3bf85e295a68f2c73c264369109158b566ce9b490af982948',
 'asm.jar':'8cadd43ac5eb6d09de05faecca38b917a040bb9139c7edeb4cc81c740b713281',
 'asm-tree.jar':'9929881f59eb6b840e86d54570c77b59ce721d104e6dfd7a40978991c2d3b41f',
 'asm-util.jar':'f885be71b5c90556f5f1ad1c4f9276b29b96057c497d46666fe4ddbec3cb43c6',
 'asm-analysis.jar':'85b29371884ba31bb76edf22323c2c24e172c3267a67152eba3d1ccc2e041ef2',
 'gson.jar':'4241c14a7727c34feea6507ec801318a3d4a90f070e4525681079fb94ee4c593',
}
def run(*args):subprocess.run([str(a) for a in args],check=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 if sha(BASE)!=BASE_HASH:raise RuntimeError('Unexpected input mod version; refusing to patch')
 for n,digest in HASHES.items():
  if sha(CACHE/n)!=digest:raise RuntimeError('Tool checksum mismatch: '+n)
 OUTPUT.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='hordes-chunks-') as temp:
  temp=Path(temp);classes=temp/'classes';tools=temp/'tools'
  compiler=['java','-jar',CACHE/'ecj.jar','-21','-proc:none','-warn:none']
  run(*compiler,'-d',classes,*sorted((ROOT/'src').rglob('*.java')))
  cp=str(CACHE/'asm.jar')+':'+str(CACHE/'asm-tree.jar')
  run(*compiler,'-cp',cp,'-d',tools,ROOT/'tools/PatchHordes.java')
  patched=temp/'patched.jar'
  run('java','-cp',str(tools)+':'+cp,'PatchHordes',BASE,classes,patched)
  with zipfile.ZipFile(patched) as original,zipfile.ZipFile(OUTPUT,'w',zipfile.ZIP_DEFLATED) as out:
   for name in original.namelist():
    data=original.read(name)
    if name=='META-INF/neoforge.mods.toml':
     text=data.decode().replace('version="1.8.0"','version="1.8.1"')
     text=text.replace('Zomboid Hordes — Helicopter, Noise and Nights','Zomboid Hordes — Chunk Population')
     text=text.replace('Daily 15% helicopter event, wave-based hordes, noise investigation and day/night zombie balance. Integrates the supplied SoundAttract, Weaker Day Zombie and Horde Hoard versions.',
        'At least two zombies per loaded two-chunk pair, with a shared 5–10 minute replenishment cooldown. Existing zombies count toward the minimum. Preserves noise investigation, zombie AI and helicopter attraction without spawning large waves.')
     data=text.encode()
    entry=zipfile.ZipInfo(name,(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;out.writestr(entry,data)
  with zipfile.ZipFile(BASE) as base,zipfile.ZipFile(OUTPUT) as out:
   assert out.testzip() is None
   changed={n for n in base.namelist() if base.read(n)!=out.read(n)}
   assert changed=={'dev/zomboid/hordes/'+n+'.class' for n in ['HordeEvents','HordeData','HordeConfig','HordeCommands']}|{'META-INF/neoforge.mods.toml'},changed
   added=set(out.namelist())-set(base.namelist())
   assert added=={'dev/zomboid/hordes/'+n+'.class' for n in ['ChunkPopulation','ChunkPopulationRules','ChunkPopulationRules$Pair','ChunkPopulationRules$State','ChunkReflection']},added
   assert set(base.namelist())<=set(out.namelist()) and len(out.namelist())==len(set(out.namelist()))
   print('PASS: only four existing classes and mod metadata changed; all original assets, mixins and unrelated code preserved')
  run(sys.executable,ROOT/'tests/run.py',OUTPUT)
 print('Output:',OUTPUT);print('SHA256:',sha(OUTPUT))
 print('Minecraft/NeoForge modpack startup not verified by these API-double checks.')
if __name__=='__main__':main()
