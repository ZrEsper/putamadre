data remove block ~ ~ ~ LootTable
data remove block ~ ~ ~ LootTableSeed
$loot insert ~ ~ ~ loot $(tabla)
scoreboard players add #generados ml_tmp 1
function mosslorn:loot/marcar_generado with storage mosslorn:runtime work
