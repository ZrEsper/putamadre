$data modify storage mosslorn:force entry set from storage mosslorn:registro cofres[$(i)]
execute store result score #fx ml_tmp run data get storage mosslorn:force entry.x
execute store result score #fz ml_tmp run data get storage mosslorn:force entry.z
execute if score #fx ml_tmp matches ..-1 run scoreboard players remove #fx ml_tmp 15
execute if score #fz ml_tmp matches ..-1 run scoreboard players remove #fz ml_tmp 15
scoreboard players operation #fx ml_tmp /= #16 ml_tmp
scoreboard players operation #fz ml_tmp /= #16 ml_tmp
execute store result storage mosslorn:force entry.cx int 1 run scoreboard players get #fx ml_tmp
execute store result storage mosslorn:force entry.cz int 1 run scoreboard players get #fz ml_tmp
function mosslorn:force/index_entry with storage mosslorn:force entry
