$execute unless data storage mosslorn:force chunks."$(dim)"."$(cx)_$(cz)"{done:0} run return 0
$execute in $(dim) positioned $(x) 0 $(z) unless loaded ~ ~ ~ run return 0
$data modify storage mosslorn:force queue set from storage mosslorn:force chunks."$(dim)"."$(cx)_$(cz)".entries
data modify storage mosslorn:force selected set from storage mosslorn:force candidate
