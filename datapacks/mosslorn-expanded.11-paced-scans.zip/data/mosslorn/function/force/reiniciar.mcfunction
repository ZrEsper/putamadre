scoreboard players set #fi ml_tmp 0
scoreboard players set #ftotal ml_tmp 0
execute store result score #ftotal ml_tmp run data get storage mosslorn:registro cofres
scoreboard players set #force_build ml_tmp 1
scoreboard players set #force_clock ml_tmp 0
scoreboard players set #force_reset ml_tmp 0
scoreboard players set #force_missing ml_tmp 0
scoreboard players set #force_done ml_tmp 0
scoreboard players set #force_chunks ml_tmp 3836
scoreboard players set #auto_scan ml_config 0
data modify storage mosslorn:runtime activo set value 0b
function mosslorn:loot/scan/cancelar
data modify storage mosslorn:force queue set value []
function mosslorn:force/catalogo
tellraw @s {"text":"Reinicio TOTAL solicitado: se vaciarán cofres y barriles y se restaurará su tabla. Preparando el índice; los chunks descargados se reiniciarán al acercarte. Usa /function mosslorn:force/estado para ver el progreso.","color":"yellow"}
execute if score #ftotal ml_tmp matches 0 run function mosslorn:force/listo
