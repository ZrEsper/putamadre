$execute unless data storage mosslorn:force chunks."$(dim)" run data modify storage mosslorn:force chunks."$(dim)" set value {}
$execute unless data storage mosslorn:force chunks."$(dim)"."$(cx)_$(cz)" run scoreboard players add #force_chunks ml_tmp 1
$execute unless data storage mosslorn:force chunks."$(dim)"."$(cx)_$(cz)" run data modify storage mosslorn:force chunks."$(dim)"."$(cx)_$(cz)" set value {entries:[],done:0}
$data remove storage mosslorn:force chunks."$(dim)"."$(cx)_$(cz)".entries[{x:$(x),y:$(y),z:$(z)}]
$data modify storage mosslorn:force chunks."$(dim)"."$(cx)_$(cz)".entries append from storage mosslorn:force entry
