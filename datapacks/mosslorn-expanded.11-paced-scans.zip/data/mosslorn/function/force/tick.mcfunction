execute unless data storage mosslorn:force chunks run return 0
scoreboard players add #force_clock ml_tmp 1
execute if score #force_build ml_tmp matches 1 run function mosslorn:force/index_batch
execute if score #force_build ml_tmp matches 1 if score #fi ml_tmp >= #ftotal ml_tmp run function mosslorn:force/listo
execute if score #force_build ml_tmp matches 1 if score #force_clock ml_tmp matches 100.. run tellraw @a [{"text":"Preparando reinicio: ","color":"yellow"},{"score":{"name":"#fi","objective":"ml_tmp"}},{"text":" / "},{"score":{"name":"#ftotal","objective":"ml_tmp"}}]
execute if score #force_clock ml_tmp matches 100.. run scoreboard players set #force_clock ml_tmp 0
execute if score #force_build ml_tmp matches 1 run return 0
execute if score #force_clock ml_tmp matches 20.. unless data storage mosslorn:force queue[0] as @a at @s run function mosslorn:force/cerca
execute if score #force_clock ml_tmp matches 20.. run scoreboard players set #force_clock ml_tmp 0
execute if score #force_reset_batch ml_config matches 1.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 2.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 3.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 4.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 5.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 6.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 7.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 8.. run function mosslorn:force/reset_step
