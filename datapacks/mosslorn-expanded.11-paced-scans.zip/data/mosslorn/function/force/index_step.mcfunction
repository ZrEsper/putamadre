execute if score #fi ml_tmp >= #ftotal ml_tmp run return 0
execute store result storage mosslorn:force pointer.i int 1 run scoreboard players get #fi ml_tmp
function mosslorn:force/index_read with storage mosslorn:force pointer
scoreboard players add #fi ml_tmp 1
