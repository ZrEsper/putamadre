$data modify storage mosslorn:force chunks."$(dim)"."$(cx)_$(cz)".done set value 1
scoreboard players add #force_done ml_tmp 1
