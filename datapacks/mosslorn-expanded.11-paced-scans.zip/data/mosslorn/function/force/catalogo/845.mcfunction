data modify storage mosslorn:force chunks."minecraft:overworld"."-28_-44" set value {"entries":[{"dim":"minecraft:overworld","x":-435,"y":66,"z":-692,"tabla":"mosslorn:chests/world_mix"}],"done":0}
