data modify storage mosslorn:force chunks."minecraft:overworld"."-17_80" set value {"entries":[{"dim":"minecraft:overworld","x":-262,"y":66,"z":1286,"tabla":"mosslorn:chests/world_mix"}],"done":0}
