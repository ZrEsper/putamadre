data modify storage mosslorn:force chunks."minecraft:overworld"."27_-36" set value {"entries":[{"dim":"minecraft:overworld","x":434,"y":66,"z":-569,"tabla":"mosslorn:chests/world_mix"}],"done":0}
