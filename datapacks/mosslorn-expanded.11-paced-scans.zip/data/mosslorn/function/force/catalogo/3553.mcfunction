data modify storage mosslorn:force chunks."minecraft:overworld"."30_4" set value {"entries":[{"dim":"minecraft:overworld","x":490,"y":66,"z":65,"tabla":"mosslorn:chests/world_mix"}],"done":0}
