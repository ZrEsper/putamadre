data modify storage mosslorn:force chunks."minecraft:overworld"."-6_52" set value {"entries":[{"dim":"minecraft:overworld","x":-93,"y":19,"z":839,"tabla":"mosslorn:chests/world_mix"}],"done":0}
