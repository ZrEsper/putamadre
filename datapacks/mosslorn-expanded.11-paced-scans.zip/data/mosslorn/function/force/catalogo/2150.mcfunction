data modify storage mosslorn:force chunks."minecraft:overworld"."-1_-21" set value {"entries":[{"dim":"minecraft:overworld","x":-4,"y":66,"z":-324,"tabla":"mosslorn:chests/world_mix"}],"done":0}
