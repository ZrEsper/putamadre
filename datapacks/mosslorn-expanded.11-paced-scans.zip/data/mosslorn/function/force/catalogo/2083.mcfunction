data modify storage mosslorn:force chunks."minecraft:overworld"."-3_-7" set value {"entries":[{"dim":"minecraft:overworld","x":-37,"y":66,"z":-111,"tabla":"mosslorn:chests/world_mix"}],"done":0}
