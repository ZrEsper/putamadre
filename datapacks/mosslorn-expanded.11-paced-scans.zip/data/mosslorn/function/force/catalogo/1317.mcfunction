data modify storage mosslorn:force chunks."minecraft:overworld"."-18_-1" set value {"entries":[{"dim":"minecraft:overworld","x":-288,"y":66,"z":-3,"tabla":"mosslorn:chests/crate_house"}],"done":0}
