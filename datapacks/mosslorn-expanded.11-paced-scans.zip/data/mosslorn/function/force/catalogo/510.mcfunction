data modify storage mosslorn:force chunks."minecraft:overworld"."-37_54" set value {"entries":[{"dim":"minecraft:overworld","x":-579,"y":66,"z":869,"tabla":"mosslorn:chests/world_mix"}],"done":0}
