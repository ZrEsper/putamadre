data modify storage mosslorn:force chunks."minecraft:overworld"."-25_25" set value {"entries":[{"dim":"minecraft:overworld","x":-399,"y":66,"z":406,"tabla":"mosslorn:chests/world_mix"}],"done":0}
