data modify storage mosslorn:force chunks."minecraft:overworld"."-14_22" set value {"entries":[{"dim":"minecraft:overworld","x":-211,"y":66,"z":364,"tabla":"mosslorn:chests/world_mix"}],"done":0}
