data modify storage mosslorn:force chunks."minecraft:overworld"."16_35" set value {"entries":[{"dim":"minecraft:overworld","x":267,"y":185,"z":563,"tabla":"mosslorn:chests/crate_kitchen"}],"done":0}
