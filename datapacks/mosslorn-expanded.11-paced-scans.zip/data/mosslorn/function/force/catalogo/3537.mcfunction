data modify storage mosslorn:force chunks."minecraft:overworld"."29_-6" set value {"entries":[{"dim":"minecraft:overworld","x":477,"y":66,"z":-92,"tabla":"mosslorn:chests/world_mix"}],"done":0}
