data modify storage mosslorn:force chunks."minecraft:overworld"."-10_41" set value {"entries":[{"dim":"minecraft:overworld","x":-155,"y":66,"z":657,"tabla":"mosslorn:chests/world_mix"}],"done":0}
