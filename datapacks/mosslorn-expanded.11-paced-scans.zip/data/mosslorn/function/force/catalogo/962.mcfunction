data modify storage mosslorn:force chunks."minecraft:overworld"."-26_-31" set value {"entries":[{"dim":"minecraft:overworld","x":-414,"y":66,"z":-496,"tabla":"mosslorn:chests/world_mix"}],"done":0}
