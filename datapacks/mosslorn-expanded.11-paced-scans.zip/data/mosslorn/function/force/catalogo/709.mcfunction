data modify storage mosslorn:force chunks."minecraft:overworld"."-32_-36" set value {"entries":[{"dim":"minecraft:overworld","x":-510,"y":60,"z":-573,"tabla":"mosslorn:chests/world_mix"}],"done":0}
