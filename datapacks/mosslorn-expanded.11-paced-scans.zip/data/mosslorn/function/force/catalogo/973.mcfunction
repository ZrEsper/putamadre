data modify storage mosslorn:force chunks."minecraft:overworld"."-26_-17" set value {"entries":[{"dim":"minecraft:overworld","x":-413,"y":66,"z":-258,"tabla":"mosslorn:chests/crate_car"}],"done":0}
