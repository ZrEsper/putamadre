data modify storage mosslorn:force chunks."minecraft:overworld"."24_40" set value {"entries":[{"dim":"minecraft:overworld","x":386,"y":66,"z":645,"tabla":"mosslorn:chests/world_mix"}],"done":0}
