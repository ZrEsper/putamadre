data modify storage mosslorn:force chunks."minecraft:overworld"."3_28" set value {"entries":[{"dim":"minecraft:overworld","x":63,"y":66,"z":455,"tabla":"mosslorn:chests/world_mix"}],"done":0}
