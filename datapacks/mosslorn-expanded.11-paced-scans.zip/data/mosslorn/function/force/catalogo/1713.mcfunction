data modify storage mosslorn:force chunks."minecraft:overworld"."-11_5" set value {"entries":[{"dim":"minecraft:overworld","x":-165,"y":66,"z":88,"tabla":"mosslorn:chests/world_mix"}],"done":0}
