data modify storage mosslorn:force chunks."minecraft:overworld"."12_77" set value {"entries":[{"dim":"minecraft:overworld","x":202,"y":10,"z":1235,"tabla":"mosslorn:chests/world_mix"}],"done":0}
