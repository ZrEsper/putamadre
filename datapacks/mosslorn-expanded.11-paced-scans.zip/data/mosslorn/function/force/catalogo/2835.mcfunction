data modify storage mosslorn:force chunks."minecraft:overworld"."12_53" set value {"entries":[{"dim":"minecraft:overworld","x":193,"y":66,"z":862,"tabla":"mosslorn:chests/world_mix"}],"done":0}
