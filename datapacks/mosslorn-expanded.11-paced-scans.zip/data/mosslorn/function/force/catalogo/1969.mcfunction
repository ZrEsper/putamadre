data modify storage mosslorn:force chunks."minecraft:overworld"."-6_54" set value {"entries":[{"dim":"minecraft:overworld","x":-85,"y":66,"z":871,"tabla":"mosslorn:chests/world_mix"}],"done":0}
