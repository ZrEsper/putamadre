data modify storage mosslorn:force chunks."minecraft:overworld"."-3_-3" set value {"entries":[{"dim":"minecraft:overworld","x":-39,"y":66,"z":-33,"tabla":"mosslorn:chests/crate_car"}],"done":0}
