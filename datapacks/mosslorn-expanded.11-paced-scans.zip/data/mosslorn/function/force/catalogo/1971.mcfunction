data modify storage mosslorn:force chunks."minecraft:overworld"."-6_79" set value {"entries":[{"dim":"minecraft:overworld","x":-90,"y":52,"z":1264,"tabla":"mosslorn:chests/world_mix"}],"done":0}
