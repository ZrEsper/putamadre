data modify storage mosslorn:force chunks."minecraft:overworld"."2_15" set value {"entries":[{"dim":"minecraft:overworld","x":34,"y":66,"z":254,"tabla":"mosslorn:chests/world_mix"}],"done":0}
