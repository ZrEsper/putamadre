data modify storage mosslorn:force chunks."minecraft:overworld"."8_-4" set value {"entries":[{"dim":"minecraft:overworld","x":139,"y":66,"z":-55,"tabla":"mosslorn:chests/world_mix"}],"done":0}
