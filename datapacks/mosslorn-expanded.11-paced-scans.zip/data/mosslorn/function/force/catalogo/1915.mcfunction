data modify storage mosslorn:force chunks."minecraft:overworld"."-7_75" set value {"entries":[{"dim":"minecraft:overworld","x":-99,"y":-14,"z":1210,"tabla":"mosslorn:chests/world_mix"}],"done":0}
