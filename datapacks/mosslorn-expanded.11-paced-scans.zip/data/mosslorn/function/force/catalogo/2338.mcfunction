data modify storage mosslorn:force chunks."minecraft:overworld"."2_11" set value {"entries":[{"dim":"minecraft:overworld","x":43,"y":-52,"z":191,"tabla":"mosslorn:chests/world_mix"}],"done":0}
