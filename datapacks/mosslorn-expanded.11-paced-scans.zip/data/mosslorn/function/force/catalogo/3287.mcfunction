data modify storage mosslorn:force chunks."minecraft:overworld"."22_-16" set value {"entries":[{"dim":"minecraft:overworld","x":353,"y":65,"z":-251,"tabla":"mosslorn:chests/world_mix"}],"done":0}
