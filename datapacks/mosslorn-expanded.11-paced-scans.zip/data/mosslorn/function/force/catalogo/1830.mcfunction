data modify storage mosslorn:force chunks."minecraft:overworld"."-8_-10" set value {"entries":[{"dim":"minecraft:overworld","x":-116,"y":66,"z":-157,"tabla":"mosslorn:chests/crate_car"}],"done":0}
