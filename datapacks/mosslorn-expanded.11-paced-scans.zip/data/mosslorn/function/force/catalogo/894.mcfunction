data modify storage mosslorn:force chunks."minecraft:overworld"."-28_40" set value {"entries":[{"dim":"minecraft:overworld","x":-433,"y":66,"z":655,"tabla":"mosslorn:chests/world_mix"}],"done":0}
