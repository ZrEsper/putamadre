data modify storage mosslorn:force chunks."minecraft:overworld"."-18_-15" set value {"entries":[{"dim":"minecraft:overworld","x":-276,"y":66,"z":-233,"tabla":"mosslorn:chests/crate_car"}],"done":0}
