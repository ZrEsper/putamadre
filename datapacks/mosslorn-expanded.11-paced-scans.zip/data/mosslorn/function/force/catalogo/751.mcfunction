data modify storage mosslorn:force chunks."minecraft:overworld"."-31_-34" set value {"entries":[{"dim":"minecraft:overworld","x":-488,"y":66,"z":-534,"tabla":"mosslorn:chests/world_mix"}],"done":0}
