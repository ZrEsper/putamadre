data modify storage mosslorn:force chunks."minecraft:overworld"."27_0" set value {"entries":[{"dim":"minecraft:overworld","x":433,"y":66,"z":8,"tabla":"mosslorn:chests/crate_car"}],"done":0}
