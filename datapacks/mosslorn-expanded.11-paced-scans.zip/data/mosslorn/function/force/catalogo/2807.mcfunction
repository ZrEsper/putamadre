data modify storage mosslorn:force chunks."minecraft:overworld"."12_-10" set value {"entries":[{"dim":"minecraft:overworld","x":192,"y":66,"z":-157,"tabla":"mosslorn:chests/crate_car"}],"done":0}
