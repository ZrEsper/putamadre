data modify storage mosslorn:force chunks."minecraft:overworld"."26_80" set value {"entries":[{"dim":"minecraft:overworld","x":416,"y":-28,"z":1281,"tabla":"mosslorn:chests/world_mix"}],"done":0}
