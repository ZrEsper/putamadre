data modify storage mosslorn:force chunks."minecraft:overworld"."13_24" set value {"entries":[{"dim":"minecraft:overworld","x":210,"y":66,"z":390,"tabla":"mosslorn:chests/world_mix"}],"done":0}
