data modify storage mosslorn:force chunks."minecraft:overworld"."19_-11" set value {"entries":[{"dim":"minecraft:overworld","x":319,"y":66,"z":-166,"tabla":"mosslorn:chests/world_mix"}],"done":0}
