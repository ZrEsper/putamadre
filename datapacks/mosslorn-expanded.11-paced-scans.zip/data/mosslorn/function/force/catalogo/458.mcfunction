data modify storage mosslorn:force chunks."minecraft:overworld"."-37_-25" set value {"entries":[{"dim":"minecraft:overworld","x":-580,"y":66,"z":-386,"tabla":"mosslorn:chests/world_mix"}],"done":0}
