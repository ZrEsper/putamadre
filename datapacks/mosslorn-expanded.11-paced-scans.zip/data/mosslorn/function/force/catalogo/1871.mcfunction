data modify storage mosslorn:force chunks."minecraft:overworld"."-7_-23" set value {"entries":[{"dim":"minecraft:overworld","x":-107,"y":66,"z":-368,"tabla":"mosslorn:chests/world_mix"}],"done":0}
