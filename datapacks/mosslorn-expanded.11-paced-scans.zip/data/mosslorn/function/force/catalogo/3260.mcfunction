data modify storage mosslorn:force chunks."minecraft:overworld"."21_-8" set value {"entries":[{"dim":"minecraft:overworld","x":344,"y":66,"z":-118,"tabla":"mosslorn:chests/world_mix"}],"done":0}
