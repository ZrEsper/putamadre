data modify storage mosslorn:force chunks."minecraft:overworld"."27_-3" set value {"entries":[{"dim":"minecraft:overworld","x":440,"y":66,"z":-34,"tabla":"mosslorn:chests/crate_car"}],"done":0}
