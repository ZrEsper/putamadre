data modify storage mosslorn:force chunks."minecraft:overworld"."-24_53" set value {"entries":[{"dim":"minecraft:overworld","x":-382,"y":66,"z":857,"tabla":"mosslorn:chests/world_mix"}],"done":0}
