data modify storage mosslorn:force chunks."minecraft:overworld"."-33_-45" set value {"entries":[{"dim":"minecraft:overworld","x":-523,"y":66,"z":-719,"tabla":"mosslorn:chests/world_mix"}],"done":0}
