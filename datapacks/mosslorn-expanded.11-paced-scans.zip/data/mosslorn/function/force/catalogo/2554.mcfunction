data modify storage mosslorn:force chunks."minecraft:overworld"."7_2" set value {"entries":[{"dim":"minecraft:overworld","x":123,"y":66,"z":39,"tabla":"mosslorn:chests/world_mix"}],"done":0}
