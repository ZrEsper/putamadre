data modify storage mosslorn:force chunks."minecraft:overworld"."35_8" set value {"entries":[{"dim":"minecraft:overworld","x":565,"y":79,"z":142,"tabla":"mosslorn:chests/crate_car"}],"done":0}
