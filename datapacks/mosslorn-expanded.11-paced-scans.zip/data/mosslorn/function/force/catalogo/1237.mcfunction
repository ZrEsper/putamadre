data modify storage mosslorn:force chunks."minecraft:overworld"."-20_-17" set value {"entries":[{"dim":"minecraft:overworld","x":-313,"y":66,"z":-261,"tabla":"mosslorn:chests/crate_car"}],"done":0}
