data modify storage mosslorn:force chunks."minecraft:overworld"."-3_41" set value {"entries":[{"dim":"minecraft:overworld","x":-40,"y":66,"z":660,"tabla":"mosslorn:chests/world_mix"}],"done":0}
