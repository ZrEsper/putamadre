data modify storage mosslorn:force chunks."minecraft:overworld"."-30_-41" set value {"entries":[{"dim":"minecraft:overworld","x":-470,"y":66,"z":-644,"tabla":"mosslorn:chests/world_mix"}],"done":0}
