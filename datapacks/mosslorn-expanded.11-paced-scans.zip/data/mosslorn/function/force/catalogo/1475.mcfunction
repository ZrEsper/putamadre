data modify storage mosslorn:force chunks."minecraft:overworld"."-15_-17" set value {"entries":[{"dim":"minecraft:overworld","x":-237,"y":66,"z":-261,"tabla":"mosslorn:chests/world_mix"}],"done":0}
