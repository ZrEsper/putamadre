data modify storage mosslorn:force chunks."minecraft:overworld"."8_-20" set value {"entries":[{"dim":"minecraft:overworld","x":129,"y":66,"z":-308,"tabla":"mosslorn:chests/crate_car"}],"done":0}
