data modify storage mosslorn:force chunks."minecraft:overworld"."-16_40" set value {"entries":[{"dim":"minecraft:overworld","x":-249,"y":66,"z":651,"tabla":"mosslorn:chests/world_mix"}],"done":0}
