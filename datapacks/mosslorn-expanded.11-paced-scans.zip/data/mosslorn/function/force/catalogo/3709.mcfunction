data modify storage mosslorn:force chunks."minecraft:overworld"."45_8" set value {"entries":[{"dim":"minecraft:overworld","x":725,"y":79,"z":142,"tabla":"mosslorn:chests/world_mix"}],"done":0}
