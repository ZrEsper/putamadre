data modify storage mosslorn:force chunks."minecraft:overworld"."57_-49" set value {"entries":[{"dim":"minecraft:overworld","x":912,"y":-44,"z":-774,"tabla":"mosslorn:chests/world_mix"}],"done":0}
