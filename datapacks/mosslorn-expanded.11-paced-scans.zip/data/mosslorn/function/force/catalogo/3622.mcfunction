data modify storage mosslorn:force chunks."minecraft:overworld"."35_92" set value {"entries":[{"dim":"minecraft:overworld","x":570,"y":-43,"z":1487,"tabla":"mosslorn:chests/world_mix"}],"done":0}
