data modify storage mosslorn:force chunks."minecraft:overworld"."-1_26" set value {"entries":[{"dim":"minecraft:overworld","x":-5,"y":66,"z":417,"tabla":"mosslorn:chests/world_mix"}],"done":0}
