data modify storage mosslorn:force chunks."minecraft:overworld"."-35_-40" set value {"entries":[{"dim":"minecraft:overworld","x":-553,"y":73,"z":-629,"tabla":"mosslorn:chests/world_mix"}],"done":0}
