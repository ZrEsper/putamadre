data modify storage mosslorn:force chunks."minecraft:overworld"."27_-28" set value {"entries":[{"dim":"minecraft:overworld","x":440,"y":66,"z":-438,"tabla":"mosslorn:chests/world_mix"}],"done":0}
