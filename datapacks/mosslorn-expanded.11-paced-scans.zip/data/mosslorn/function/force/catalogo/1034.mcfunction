data modify storage mosslorn:force chunks."minecraft:overworld"."-25_8" set value {"entries":[{"dim":"minecraft:overworld","x":-398,"y":73,"z":129,"tabla":"mosslorn:chests/crate_house"}],"done":0}
