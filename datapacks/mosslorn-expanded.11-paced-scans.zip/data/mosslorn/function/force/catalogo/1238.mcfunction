data modify storage mosslorn:force chunks."minecraft:overworld"."-20_-11" set value {"entries":[{"dim":"minecraft:overworld","x":-318,"y":66,"z":-162,"tabla":"mosslorn:chests/world_mix"}],"done":0}
