data modify storage mosslorn:force chunks."minecraft:overworld"."-15_-4" set value {"entries":[{"dim":"minecraft:overworld","x":-227,"y":66,"z":-55,"tabla":"mosslorn:chests/crate_car"}],"done":0}
