data modify storage mosslorn:force chunks."minecraft:overworld"."43_83" set value {"entries":[{"dim":"minecraft:overworld","x":703,"y":-7,"z":1331,"tabla":"mosslorn:chests/world_mix"}],"done":0}
