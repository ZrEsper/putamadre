data modify storage mosslorn:force chunks."minecraft:overworld"."-16_-29" set value {"entries":[{"dim":"minecraft:overworld","x":-244,"y":66,"z":-462,"tabla":"mosslorn:chests/world_mix"}],"done":0}
