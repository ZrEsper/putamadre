data modify storage mosslorn:force chunks."minecraft:overworld"."-30_-65" set value {"entries":[{"dim":"minecraft:overworld","x":-469,"y":-27,"z":-1034,"tabla":"mosslorn:chests/world_mix"}],"done":0}
