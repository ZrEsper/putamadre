data modify storage mosslorn:force chunks."minecraft:overworld"."-8_-60" set value {"entries":[{"dim":"minecraft:overworld","x":-125,"y":-54,"z":-950,"tabla":"mosslorn:chests/world_mix"}],"done":0}
