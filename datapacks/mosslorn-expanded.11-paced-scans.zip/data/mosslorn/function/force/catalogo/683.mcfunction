data modify storage mosslorn:force chunks."minecraft:overworld"."-33_9" set value {"entries":[{"dim":"minecraft:overworld","x":-526,"y":66,"z":148,"tabla":"mosslorn:chests/crate_car"}],"done":0}
