data modify storage mosslorn:force chunks."minecraft:overworld"."-17_54" set value {"entries":[{"dim":"minecraft:overworld","x":-271,"y":66,"z":866,"tabla":"mosslorn:chests/world_mix"}],"done":0}
