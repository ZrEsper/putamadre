data modify storage mosslorn:force chunks."minecraft:overworld"."15_9" set value {"entries":[{"dim":"minecraft:overworld","x":250,"y":66,"z":149,"tabla":"mosslorn:chests/crate_car"}],"done":0}
