data modify storage mosslorn:force chunks."minecraft:overworld"."-25_2" set value {"entries":[{"dim":"minecraft:overworld","x":-397,"y":66,"z":38,"tabla":"mosslorn:chests/crate_car"}],"done":0}
