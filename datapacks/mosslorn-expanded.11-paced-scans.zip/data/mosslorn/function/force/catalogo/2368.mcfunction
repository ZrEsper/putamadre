data modify storage mosslorn:force chunks."minecraft:overworld"."3_-35" set value {"entries":[{"dim":"minecraft:overworld","x":61,"y":67,"z":-554,"tabla":"mosslorn:chests/crate_fish"}],"done":0}
