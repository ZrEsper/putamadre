data modify storage mosslorn:force chunks."minecraft:overworld"."-9_8" set value {"entries":[{"dim":"minecraft:overworld","x":-139,"y":66,"z":142,"tabla":"mosslorn:chests/world_mix"}],"done":0}
