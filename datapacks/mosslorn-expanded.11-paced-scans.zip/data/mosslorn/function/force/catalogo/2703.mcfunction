data modify storage mosslorn:force chunks."minecraft:overworld"."10_-17" set value {"entries":[{"dim":"minecraft:overworld","x":169,"y":66,"z":-270,"tabla":"mosslorn:chests/world_mix"}],"done":0}
