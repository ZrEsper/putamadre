data modify storage mosslorn:force chunks."minecraft:overworld"."57_36" set value {"entries":[{"dim":"minecraft:overworld","x":927,"y":-12,"z":584,"tabla":"mosslorn:chests/world_mix"}],"done":0}
