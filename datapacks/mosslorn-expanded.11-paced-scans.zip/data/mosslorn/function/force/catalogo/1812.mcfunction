data modify storage mosslorn:force chunks."minecraft:overworld"."-8_-41" set value {"entries":[{"dim":"minecraft:overworld","x":-124,"y":112,"z":-642,"tabla":"mosslorn:chests/crate_fish"}],"done":0}
