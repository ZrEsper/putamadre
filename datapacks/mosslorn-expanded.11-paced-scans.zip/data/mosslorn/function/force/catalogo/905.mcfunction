data modify storage mosslorn:force chunks."minecraft:overworld"."-27_-33" set value {"entries":[{"dim":"minecraft:overworld","x":-429,"y":66,"z":-520,"tabla":"mosslorn:chests/world_mix"}],"done":0}
