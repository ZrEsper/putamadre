data modify storage mosslorn:force chunks."minecraft:overworld"."-10_27" set value {"entries":[{"dim":"minecraft:overworld","x":-153,"y":66,"z":432,"tabla":"mosslorn:chests/world_mix"}],"done":0}
