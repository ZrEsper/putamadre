data modify storage mosslorn:force chunks."minecraft:overworld"."14_-23" set value {"entries":[{"dim":"minecraft:overworld","x":229,"y":66,"z":-363,"tabla":"mosslorn:chests/world_mix"}],"done":0}
