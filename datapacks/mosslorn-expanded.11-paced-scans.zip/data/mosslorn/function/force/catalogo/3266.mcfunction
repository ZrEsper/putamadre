data modify storage mosslorn:force chunks."minecraft:overworld"."21_10" set value {"entries":[{"dim":"minecraft:overworld","x":351,"y":40,"z":161,"tabla":"mosslorn:chests/world_mix"}],"done":0}
