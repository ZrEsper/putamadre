data modify storage mosslorn:force chunks."minecraft:overworld"."-5_-23" set value {"entries":[{"dim":"minecraft:overworld","x":-72,"y":66,"z":-363,"tabla":"mosslorn:chests/crate_house"}],"done":0}
