data modify storage mosslorn:force chunks."minecraft:overworld"."39_-57" set value {"entries":[{"dim":"minecraft:overworld","x":637,"y":103,"z":-910,"tabla":"mosslorn:chests/world_mix"}],"done":0}
