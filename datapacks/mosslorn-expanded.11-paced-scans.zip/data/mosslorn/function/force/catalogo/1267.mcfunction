data modify storage mosslorn:force chunks."minecraft:overworld"."-20_54" set value {"entries":[{"dim":"minecraft:overworld","x":-308,"y":66,"z":866,"tabla":"mosslorn:chests/world_mix"}],"done":0}
