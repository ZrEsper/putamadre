data modify storage mosslorn:force chunks."minecraft:overworld"."21_-15" set value {"entries":[{"dim":"minecraft:overworld","x":345,"y":66,"z":-230,"tabla":"mosslorn:chests/crate_car"}],"done":0}
