data modify storage mosslorn:force chunks."minecraft:overworld"."20_72" set value {"entries":[{"dim":"minecraft:overworld","x":321,"y":-21,"z":1159,"tabla":"mosslorn:chests/world_mix"}],"done":0}
