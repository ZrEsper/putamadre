data modify storage mosslorn:force chunks."minecraft:overworld"."21_52" set value {"entries":[{"dim":"minecraft:overworld","x":340,"y":66,"z":832,"tabla":"mosslorn:chests/world_mix"}],"done":0}
