data modify storage mosslorn:force chunks."minecraft:overworld"."46_41" set value {"entries":[{"dim":"minecraft:overworld","x":736,"y":46,"z":658,"tabla":"mosslorn:chests/world_mix"}],"done":0}
