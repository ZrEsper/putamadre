data modify storage mosslorn:force chunks."minecraft:overworld"."57_50" set value {"entries":[{"dim":"minecraft:overworld","x":914,"y":-35,"z":800,"tabla":"mosslorn:chests/world_mix"}],"done":0}
