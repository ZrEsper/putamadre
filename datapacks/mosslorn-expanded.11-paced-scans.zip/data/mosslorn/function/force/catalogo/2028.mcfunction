data modify storage mosslorn:force chunks."minecraft:overworld"."-4_-24" set value {"entries":[{"dim":"minecraft:overworld","x":-54,"y":66,"z":-372,"tabla":"mosslorn:chests/crate_kitchen"}],"done":0}
