data modify storage mosslorn:force chunks."minecraft:overworld"."-1_15" set value {"entries":[{"dim":"minecraft:overworld","x":-12,"y":66,"z":253,"tabla":"mosslorn:chests/crate_car"}],"done":0}
