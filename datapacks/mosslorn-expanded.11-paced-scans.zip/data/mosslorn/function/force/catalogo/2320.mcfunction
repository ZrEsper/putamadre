data modify storage mosslorn:force chunks."minecraft:overworld"."2_-24" set value {"entries":[{"dim":"minecraft:overworld","x":47,"y":66,"z":-372,"tabla":"mosslorn:chests/crate_car"}],"done":0}
