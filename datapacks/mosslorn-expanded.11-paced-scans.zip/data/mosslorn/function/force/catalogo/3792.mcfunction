data modify storage mosslorn:force chunks."minecraft:overworld"."56_22" set value {"entries":[{"dim":"minecraft:overworld","x":908,"y":-1,"z":355,"tabla":"mosslorn:chests/world_mix"}],"done":0}
