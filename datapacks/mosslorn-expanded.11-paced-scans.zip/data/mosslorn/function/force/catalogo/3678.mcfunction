data modify storage mosslorn:force chunks."minecraft:overworld"."41_17" set value {"entries":[{"dim":"minecraft:overworld","x":670,"y":-33,"z":281,"tabla":"mosslorn:chests/world_mix"}],"done":0}
