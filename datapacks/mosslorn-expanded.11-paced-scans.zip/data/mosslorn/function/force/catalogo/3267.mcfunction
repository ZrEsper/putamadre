data modify storage mosslorn:force chunks."minecraft:overworld"."21_17" set value {"entries":[{"dim":"minecraft:overworld","x":341,"y":66,"z":280,"tabla":"mosslorn:chests/world_mix"}],"done":0}
