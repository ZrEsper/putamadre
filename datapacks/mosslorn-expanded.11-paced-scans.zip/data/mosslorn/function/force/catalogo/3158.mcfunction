data modify storage mosslorn:force chunks."minecraft:overworld"."18_48" set value {"entries":[{"dim":"minecraft:overworld","x":293,"y":66,"z":768,"tabla":"mosslorn:chests/world_mix"}],"done":0}
