data modify storage mosslorn:force chunks."minecraft:overworld"."-31_2" set value {"entries":[{"dim":"minecraft:overworld","x":-494,"y":66,"z":39,"tabla":"mosslorn:chests/world_mix"}],"done":0}
