data modify storage mosslorn:force chunks."minecraft:overworld"."18_9" set value {"entries":[{"dim":"minecraft:overworld","x":297,"y":66,"z":149,"tabla":"mosslorn:chests/world_mix"}],"done":0}
