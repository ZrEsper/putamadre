data modify storage mosslorn:force chunks."minecraft:overworld"."-30_76" set value {"entries":[{"dim":"minecraft:overworld","x":-480,"y":14,"z":1219,"tabla":"mosslorn:chests/world_mix"}],"done":0}
