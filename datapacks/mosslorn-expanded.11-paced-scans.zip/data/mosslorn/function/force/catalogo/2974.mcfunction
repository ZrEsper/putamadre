data modify storage mosslorn:force chunks."minecraft:overworld"."15_28" set value {"entries":[{"dim":"minecraft:overworld","x":240,"y":66,"z":454,"tabla":"mosslorn:chests/world_mix"}],"done":0}
