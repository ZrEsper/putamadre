data modify storage mosslorn:force chunks."minecraft:overworld"."11_21" set value {"entries":[{"dim":"minecraft:overworld","x":183,"y":66,"z":347,"tabla":"mosslorn:chests/world_mix"}],"done":0}
