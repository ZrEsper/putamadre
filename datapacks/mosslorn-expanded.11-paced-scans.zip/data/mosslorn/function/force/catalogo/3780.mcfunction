data modify storage mosslorn:force chunks."minecraft:overworld"."55_49" set value {"entries":[{"dim":"minecraft:overworld","x":894,"y":-35,"z":794,"tabla":"mosslorn:chests/world_mix"}],"done":0}
