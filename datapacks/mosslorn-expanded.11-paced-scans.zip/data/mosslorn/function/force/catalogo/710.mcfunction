data modify storage mosslorn:force chunks."minecraft:overworld"."-32_-35" set value {"entries":[{"dim":"minecraft:overworld","x":-511,"y":60,"z":-560,"tabla":"mosslorn:chests/world_mix"}],"done":0}
