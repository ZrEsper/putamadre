data modify storage mosslorn:force chunks."minecraft:overworld"."21_-62" set value {"entries":[{"dim":"minecraft:overworld","x":351,"y":35,"z":-985,"tabla":"mosslorn:chests/world_mix"}],"done":0}
