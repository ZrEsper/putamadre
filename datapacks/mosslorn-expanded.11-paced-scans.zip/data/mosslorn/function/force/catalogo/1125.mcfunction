data modify storage mosslorn:force chunks."minecraft:overworld"."-23_47" set value {"entries":[{"dim":"minecraft:overworld","x":-356,"y":66,"z":763,"tabla":"mosslorn:chests/world_mix"}],"done":0}
