data remove block ~ ~ ~ Items
data remove block ~ ~ ~ LootTableSeed
$data modify block ~ ~ ~ LootTable set value "$(tabla)"
scoreboard players add #force_reset ml_tmp 1
