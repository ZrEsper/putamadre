scoreboard players set #force_build ml_tmp 0
tellraw @a {"text":"Índice listo. Reiniciando contenedores cercanos; los demás quedan pendientes hasta visitar sus chunks. No abras contenedores durante el reinicio de su zona.","color":"green"}
