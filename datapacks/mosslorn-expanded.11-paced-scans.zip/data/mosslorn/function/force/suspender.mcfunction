$data modify storage mosslorn:force chunks."$(dim)"."$(cx)_$(cz)".entries set from storage mosslorn:force queue
data modify storage mosslorn:force queue set value []
