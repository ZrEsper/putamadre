execute if data block ~ ~ ~ LootTable run data modify storage mosslorn:force work.tabla set from block ~ ~ ~ LootTable
function mosslorn:force/aplicar with storage mosslorn:force work
