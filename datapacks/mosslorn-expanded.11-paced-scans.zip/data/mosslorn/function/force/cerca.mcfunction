execute store result score #base_x ml_tmp run data get entity @s Pos[0]
execute store result score #base_z ml_tmp run data get entity @s Pos[2]
execute if score #base_x ml_tmp matches ..-1 run scoreboard players remove #base_x ml_tmp 15
execute if score #base_z ml_tmp matches ..-1 run scoreboard players remove #base_z ml_tmp 15
scoreboard players operation #base_x ml_tmp /= #16 ml_tmp
scoreboard players operation #base_z ml_tmp /= #16 ml_tmp
data modify storage mosslorn:force candidate set value {dim:"minecraft:overworld"}
data modify storage mosslorn:force candidate.dim set from entity @s Dimension
execute unless data storage mosslorn:force queue[0] run function mosslorn:force/candidato_0
execute unless data storage mosslorn:force queue[0] run function mosslorn:force/candidato_1
execute unless data storage mosslorn:force queue[0] run function mosslorn:force/candidato_2
execute unless data storage mosslorn:force queue[0] run function mosslorn:force/candidato_3
execute unless data storage mosslorn:force queue[0] run function mosslorn:force/candidato_4
execute unless data storage mosslorn:force queue[0] run function mosslorn:force/candidato_5
execute unless data storage mosslorn:force queue[0] run function mosslorn:force/candidato_6
execute unless data storage mosslorn:force queue[0] run function mosslorn:force/candidato_7
execute unless data storage mosslorn:force queue[0] run function mosslorn:force/candidato_8
