execute unless data storage mosslorn:force queue[0] run return 0
data modify storage mosslorn:force work set from storage mosslorn:force queue[0]
function mosslorn:force/visitar with storage mosslorn:force work
