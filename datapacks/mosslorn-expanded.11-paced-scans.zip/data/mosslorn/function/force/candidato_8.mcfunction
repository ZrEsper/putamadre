scoreboard players operation #fx ml_tmp = #base_x ml_tmp
scoreboard players operation #fz ml_tmp = #base_z ml_tmp
scoreboard players add #fx ml_tmp 1
scoreboard players add #fz ml_tmp 1
execute store result storage mosslorn:force candidate.cx int 1 run scoreboard players get #fx ml_tmp
execute store result storage mosslorn:force candidate.cz int 1 run scoreboard players get #fz ml_tmp
scoreboard players operation #fx ml_tmp *= #16 ml_tmp
scoreboard players operation #fz ml_tmp *= #16 ml_tmp
execute store result storage mosslorn:force candidate.x int 1 run scoreboard players get #fx ml_tmp
execute store result storage mosslorn:force candidate.z int 1 run scoreboard players get #fz ml_tmp
function mosslorn:force/elegir with storage mosslorn:force candidate
