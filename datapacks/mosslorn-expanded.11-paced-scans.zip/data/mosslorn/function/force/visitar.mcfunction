$execute in $(dim) positioned $(x) $(y) $(z) unless loaded ~ ~ ~ run function mosslorn:force/suspender with storage mosslorn:force selected
$execute in $(dim) positioned $(x) $(y) $(z) unless loaded ~ ~ ~ run return 0
$execute in $(dim) positioned $(x) $(y) $(z) if block ~ ~ ~ #mosslorn:reset_containers run function mosslorn:force/preparar
$execute in $(dim) positioned $(x) $(y) $(z) unless block ~ ~ ~ #mosslorn:reset_containers run scoreboard players add #force_missing ml_tmp 1
data remove storage mosslorn:force queue[0]
execute unless data storage mosslorn:force queue[0] run function mosslorn:force/terminar_chunk with storage mosslorn:force selected
