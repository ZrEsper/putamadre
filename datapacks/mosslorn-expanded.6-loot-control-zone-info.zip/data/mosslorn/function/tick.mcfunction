scoreboard players add #reloj ml_tmp 1
scoreboard players add #auto_timer ml_tmp 1
execute if score #auto ml_config matches 1.. if score #auto_timer ml_tmp >= #auto ml_config run function mosslorn:loot/reiniciar
execute if score #reloj ml_tmp matches 10.. run function mosslorn:segundo
execute in minecraft:overworld as @e[type=minecraft:marker,tag=ml_scan_anchor,limit=1] at @s run function mosslorn:loot/scan/paso
execute in minecraft:the_nether as @e[type=minecraft:marker,tag=ml_scan_anchor,limit=1] at @s run function mosslorn:loot/scan/paso
execute in minecraft:the_end as @e[type=minecraft:marker,tag=ml_scan_anchor,limit=1] at @s run function mosslorn:loot/scan/paso
