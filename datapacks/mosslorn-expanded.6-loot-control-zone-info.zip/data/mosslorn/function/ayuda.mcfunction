tellraw @s {"text": "Mosslorn v6 — administración e información", "color": "gold"}
tellraw @s {"text": "/trigger moss_info — zona, bonus de loot, zombies presentes y reglas reales de los JAR de hordas", "color": "aqua"}
tellraw @s {"text": "/function mosslorn:loot/escanear — registra cofres sin abrir cerca (17×17×17)", "color": "yellow"}
tellraw @s {"text": "/function mosslorn:loot/registrar {x:0,y:64,z:0,tabla:\"mosslorn:chests/crate_house\"}", "color": "yellow"}
tellraw @s {"text": "/function mosslorn:loot/reiniciar — repone vacíos; respeta los ocupados", "color": "yellow"}
tellraw @s {"text": "/function mosslorn:loot/cantidad/escaso | normal | abundante", "color": "yellow"}
tellraw @s {"text": "/function mosslorn:loot/automatico {minutos:30} — 0 desactiva", "color": "yellow"}
tellraw @s {"text": "/function mosslorn:loot/estado — registros y avance", "color": "yellow"}
tellraw @s {"text":"/trigger moss_info set 2 — añade probabilidades de cada mutante","color":"aqua"}
