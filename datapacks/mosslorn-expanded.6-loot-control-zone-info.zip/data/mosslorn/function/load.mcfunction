scoreboard objectives add ml_config dummy
scoreboard objectives add ml_tmp dummy
scoreboard objectives add moss_info trigger
execute unless data storage mosslorn:registro cofres run data modify storage mosslorn:registro cofres set value []
execute unless score #cantidad ml_config matches 0..2 run scoreboard players set #cantidad ml_config 1
execute unless score #epoca ml_config matches 0.. run scoreboard players set #epoca ml_config 0
execute unless score #auto ml_config matches 0..1728000 run scoreboard players set #auto ml_config 0
scoreboard players set #reloj ml_tmp 0
scoreboard players set #scan ml_tmp 0
scoreboard players set #1200 ml_tmp 1200
scoreboard players set #16 ml_tmp 16
data modify storage mosslorn:runtime cola set value []
execute unless data storage mosslorn:runtime activo run data modify storage mosslorn:runtime activo set value 0b
tellraw @a {"text": "Mosslorn v6: /function mosslorn:ayuda | consulta pública: /trigger moss_info", "color": "green"}
function mosslorn:loot/scan/cancelar
