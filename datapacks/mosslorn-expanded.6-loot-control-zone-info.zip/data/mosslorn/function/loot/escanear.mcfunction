execute if score #scan ml_tmp matches 1 run tellraw @s {"text":"Ya hay un escaneo activo.","color":"red"}
execute unless score #scan ml_tmp matches 1 if dimension minecraft:overworld at @s run function mosslorn:loot/scan/iniciar
execute unless score #scan ml_tmp matches 1 if dimension minecraft:the_nether at @s run function mosslorn:loot/scan/iniciar
execute unless score #scan ml_tmp matches 1 if dimension minecraft:the_end at @s run function mosslorn:loot/scan/iniciar
execute unless dimension minecraft:overworld unless dimension minecraft:the_nether unless dimension minecraft:the_end run tellraw @s {"text":"El escaneo local admite Overworld, Nether y End. En esta dimensión usa el registro por coordenadas.","color":"red"}
