$data merge block ~ ~ ~ {LootTable:"$(tabla)"}
data remove block ~ ~ ~ LootTableSeed
scoreboard players add #repuestos ml_tmp 1
function mosslorn:loot/marcar with storage mosslorn:runtime work
