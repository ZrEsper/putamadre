scoreboard players set #scan ml_tmp 0
tellraw @a {"text": "Escaneo de cofres terminado. /function mosslorn:loot/estado", "color": "green"}
kill @s
