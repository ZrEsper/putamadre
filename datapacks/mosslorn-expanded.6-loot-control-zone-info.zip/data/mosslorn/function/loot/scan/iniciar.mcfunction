summon minecraft:marker ~ ~ ~ {Tags:["ml_scan_anchor"]}
scoreboard players set #scan ml_tmp 1
data modify storage mosslorn:runtime escaneo set value {fase:0,dim:"minecraft:overworld"}
data modify storage mosslorn:runtime escaneo.dim set from entity @s Dimension
tellraw @s {"text": "Escaneando 17×17×17 bloques alrededor de esta posición. Registra cofres sin abrir con tablas del pack.", "color": "green"}
