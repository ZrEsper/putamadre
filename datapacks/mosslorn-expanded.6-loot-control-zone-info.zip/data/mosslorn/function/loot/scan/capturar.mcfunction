data modify storage mosslorn:runtime entrada set value {dim:"minecraft:overworld",ultima:0}
data modify storage mosslorn:runtime entrada.dim set from storage mosslorn:runtime escaneo.dim
execute store result storage mosslorn:runtime entrada.x int 1 run data get block ~ ~ ~ x
execute store result storage mosslorn:runtime entrada.y int 1 run data get block ~ ~ ~ y
execute store result storage mosslorn:runtime entrada.z int 1 run data get block ~ ~ ~ z
data modify storage mosslorn:runtime entrada.tabla set from block ~ ~ ~ LootTable
function mosslorn:loot/guardar with storage mosslorn:runtime entrada
