$function mosslorn:loot/scan/batch_$(fase)
