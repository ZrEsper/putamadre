function mosslorn:loot/scan/ejecutar with storage mosslorn:runtime escaneo
execute store result score #fase ml_tmp run data get storage mosslorn:runtime escaneo.fase
scoreboard players add #fase ml_tmp 1
execute store result storage mosslorn:runtime escaneo.fase int 1 run scoreboard players get #fase ml_tmp
execute if score #fase ml_tmp matches 77.. run function mosslorn:loot/scan/terminar
