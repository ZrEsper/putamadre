#!/usr/bin/env python3
from pathlib import Path
import sys,hashlib,json,subprocess,zipfile,copy,shutil
r=Path(__file__).resolve().parent
bases=[Path(x).resolve() for x in sys.argv[1:]]
assert len(bases)==3,'Arguments: uploaded hordes.jar uploaded mutants.jar death-compat.4 remains.jar'
for p,digest in zip(bases,json.loads((r/'bases.sha256.json').read_text())):assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,'Different base: '+str(p)
for n,d in json.loads((r/'tools.sha256.json').read_text()).items():assert hashlib.sha256((r/'tools'/n).read_bytes()).hexdigest()==d,n
for d in ['classes','patch-tool','patched-horde','patched-remains','test-classes']:shutil.rmtree(r/d,ignore_errors=True);(r/d).mkdir()
def run(*a):subprocess.run(a,check=True,cwd=r)
ecj=['java','-jar',str(r/'tools/ecj.jar'),'-21','-nowarn'];asm=':'.join(str(r/'tools'/n) for n in ['asm.jar','asm-tree.jar','asm-analysis.jar','asm-util.jar'])
run(*ecj,'-d',str(r/'classes'),*[str(p) for p in (r/'src').rglob('*.java')])
run(*ecj,'-cp',asm,'-d',str(r/'patch-tool'),str(r/'Patch.java'))
for mode,base in [('horde',bases[0]),('remains',bases[2])]:run('java','-Xverify:all','-cp',str(r/'patch-tool')+':'+asm,'Patch',mode,str(base),str(r/('patched-'+mode)))
run(*ecj,'-cp',str(r/'classes'),'-d',str(r/'test-classes'),*[str(p) for p in (r/'tests').rglob('*.java')])
run('java','-Xverify:all','-cp',str(r/'test-classes')+':'+str(r/'classes'),'Checks')
# Distinct species loot; quantity and equipment value rise with combat strength.
profiles={
 'crawler':([('string',1,3),('flint',1,2),('bread',1,1)],('stone_axe',.08)),
 'blister_zombie':([('gunpowder',2,5),('iron_nugget',3,6),('cooked_porkchop',1,2)],('iron_helmet',.12)),
 'split_head_zombie':([('arrow',4,7),('leather',3,5),('bread',2,3)],('bow',.18)),
 'rotten_mutant':([('iron_ingot',4,7),('coal',5,8),('cooked_beef',3,5)],('iron_pickaxe',.25)),
 'spitter':([('slime_ball',6,10),('redstone',7,11),('cooked_chicken',5,7)],('golden_apple',.30)),
 'zombie_brute':([('iron_ingot',9,13),('gunpowder',10,15),('cooked_beef',7,10)],('diamond_axe',.18)),
 'mutant_brute':([('iron_ingot',14,20),('gunpowder',15,22),('cooked_beef',11,16)],('diamond_chestplate',.25))}
last_min=last_max=0
for id,(supplies,bonus) in profiles.items():
 low=sum(x[1] for x in supplies);high=sum(x[2] for x in supplies)
 assert low>last_min and high>last_max and 0<bonus[1]<1,id
 last_min,last_max=low,high
print('PASS seven distinct loot profiles, increasing supply ranges and bounded bonus chances')
def table(profile):
 supplies,bonus=profile;pools=[]
 for item,low,high in supplies:pools.append({'rolls':1,'entries':[{'type':'minecraft:item','name':'minecraft:'+item,'functions':[{'function':'minecraft:set_count','count':{'type':'minecraft:uniform','min':low,'max':high}}]}]})
 pools.append({'rolls':1,'conditions':[{'condition':'minecraft:killed_by_player'},{'condition':'minecraft:random_chance','chance':bonus[1]}],'entries':[{'type':'minecraft:item','name':'minecraft:'+bonus[0]}]})
 return {'type':'minecraft:entity','pools':pools}
names=['zomboid-hordes-1.8.3-neoforge-1.21.1-rare-mutants.1.jar','MutantsZombies-1.3.1-NeoForge-mc1.21-horde-loot.1.jar','zombie-remains-loot-1.6.2-neoforge-1.21.1-death-compat.4-mutant-loot.1.jar']
(r/'output').mkdir(exist_ok=True)
for index,base in enumerate(bases):
 additions={};removed=set()
 if index in (0,2):
  mode='horde' if index==0 else 'remains';package='rarehorde' if index==0 else 'rareloot'
  additions.update({p.relative_to(r/('patched-'+mode)).as_posix():p.read_bytes() for p in (r/('patched-'+mode)).rglob('*.class')})
  additions.update({p.relative_to(r/'classes').as_posix():p.read_bytes() for p in (r/'classes/dev/zomboid'/package).rglob('*.class')})
 if index==1:
  removed={'data/mutantszombies/neoforge/biome_modifier/'+id+'_biome_modifier.json' for id in profiles}
  additions.update({'data/mutantszombies/loot_table/entities/'+id+'.json':json.dumps(table(profile),indent=2).encode() for id,profile in profiles.items()})
 with zipfile.ZipFile(base) as z:
  assert removed<=set(z.namelist()),'Expected seven natural biome spawns'
  # Keep version strings unchanged: the installed ragdoll bridges require exact death-compat.4.
  additions['META-INF/rare-mutants-patch.json']=json.dumps({'revision':'rare-mutants.1','base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'role':['horde-population','mutant-loot-tables','corpse-loot-compat'][index]}).encode()
  changed=set(additions);out=r/'output'/names[index]
  with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
   for e in z.infolist():
    if e.filename not in removed:w.writestr(copy.copy(e),additions.pop(e.filename,z.read(e)))
   for n,b in sorted(additions.items()):w.writestr(n,b)
  with zipfile.ZipFile(out) as w:
   assert w.testzip() is None
   for n in z.namelist():
    if n not in changed|removed:assert z.read(n)==w.read(n),n
   assert not removed&set(w.namelist())
   assert not any(n.startswith('net/minecraft/') for n in w.namelist())
  print('PASS preserved untouched resources/classes:',out.name)
(r/'output/validation.json').write_text(json.dumps({'checks':'production runtime helper tests + ASM original/transformed methods + byte preservation','minecraft_runtime_tested':False,'files':{n:hashlib.sha256((r/'output'/n).read_bytes()).hexdigest() for n in names}},indent=2))
