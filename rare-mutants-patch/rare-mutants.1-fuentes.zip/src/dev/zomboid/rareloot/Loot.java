package dev.zomboid.rareloot;
import java.util.*;
/** Replace only the seven MutantsZombies' generic corpse bonus; their species tables supply the loot. */
public final class Loot {
 public static int tier(String id){return switch(id){case "mutantszombies:crawler"->0;case "mutantszombies:blister_zombie","mutantszombies:split_head_zombie"->1;case "mutantszombies:rotten_mutant"->2;case "mutantszombies:spitter","mutantszombies:zombie_brute"->3;case "mutantszombies:mutant_brute"->4;default->-1;};}
 public static String id(Object entity){return String.valueOf(R.call(R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE"),"getKey",R.call(entity,"getType")));}
 public static Object populate(Object receiver,String method,Object[] args,Object entity){int tier=tier(id(entity));if(tier<0)return R.call(receiver,method,args);R.set(args[0],"quality",tier);return null;}
 public static void extras(Object corpse,Object level,boolean bandit,boolean mutant,Object entity){if(tier(id(entity))>=0)return;R.call(R.type("dev.zomboid.remains.NpcCompatibility"),"extras",corpse,level,bandit,mutant,entity);}
}
