package dev.zomboid.rarehorde;
import java.util.*;
/** Only invoked by the existing population spawn path, never a second spawn loop. */
public final class Mutants {
 public static final String[] IDS={"crawler","blister_zombie","split_head_zombie","rotten_mutant","spitter","zombie_brute","mutant_brute"};
 public static final int[] WEIGHTS={18,25,23,18,10,5,1};
 public static boolean supported(String id){return id.startsWith("mutantszombies:")&&Arrays.asList(IDS).contains(id.substring(15));}
 public static String weighted(int roll){if(roll<0||roll>=100)throw new IllegalArgumentException("roll");for(int i=0;i<IDS.length;i++){roll-=WEIGHTS[i];if(roll<0)return IDS[i];}throw new AssertionError();}
 public static String id(Object entity){Object reg=R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE");return String.valueOf(R.call(reg,"getKey",R.call(entity,"getType")));}
 public static Object call(Object receiver,String method,Object[] args){
  if(method.equals("attributes")&&supported(id(args[0])))return null; // Native signature accepts Zombie, mutants are Monster.
  Object result=R.call(receiver,method,args);
  if(!method.equals("pick"))return result;
  Object level=args[0],pos=args[1],random=R.get(level,"random");
  if(((Number)R.call(random,"nextInt",500)).intValue()!=0)return result;
  int nearby=0;double x=R.coord(pos,"X"),z=R.coord(pos,"Z");
  for(Object entity:(Iterable<?>)R.call(level,"getAllEntities"))if(R.yes(R.call(entity,"isAlive"))&&supported(id(entity))&&Math.pow(R.coord(entity,"X")-x,2)+Math.pow(R.coord(entity,"Z")-z,2)<=128*128&&++nearby>=2)return result;
  String selected=weighted(((Number)R.call(random,"nextInt",100)).intValue());Object reg=R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE");Object key=R.call(R.type("net.minecraft.resources.ResourceLocation"),"parse","mutantszombies:"+selected);
  if(!R.yes(R.call(reg,"containsKey",key)))return result;return R.call(reg,"get",key);
 }
}
