import dev.zomboid.rarehorde.Mutants;import dev.zomboid.rareloot.Loot;import net.minecraft.core.registries.BuiltInRegistries;import net.minecraft.resources.ResourceLocation;import java.util.*;
public class Checks{
 static int checks;static void check(boolean b){checks++;if(!b)throw new AssertionError("check "+checks);}
 public static class Random{int rare,weighted;public int nextInt(int n){return n==500?rare:weighted;}}
 public static class Pos{public double getX(){return 0;}public double getZ(){return 0;}}
 public static class Entity extends Pos{String id;double x;boolean alive=true;Entity(String s,double x){id=s;this.x=x;}public Object getType(){return id;}public boolean isAlive(){return alive;}public double getX(){return x;}}
 public static class Level{public Random random=new Random();List<Entity> entities=new ArrayList<>();public Iterable<Entity> getAllEntities(){return entities;}}
 public static class Events{int attributes;Object original=new Object();public Object pick(Object l,Object p){return original;}public Object attributes(Object e,boolean n){attributes++;return null;}}
 public static class Corpse{public int quality=-1;}
 public static class NativeLoot{int count;public Object populateMutant(Object corpse,Object l){count++;return null;}}
 public static void main(String[] args){
  int[] counts=new int[7];for(int i=0;i<100;i++){String id=Mutants.weighted(i);counts[Arrays.asList(Mutants.IDS).indexOf(id)]++;}check(Arrays.equals(counts,Mutants.WEIGHTS));
  for(String id:Mutants.IDS)check(Mutants.supported("mutantszombies:"+id));check(!Mutants.supported("mutantszombies:spitter_projectile"));check(!Mutants.supported("other:crawler"));
  Events events=new Events();Level level=new Level();Pos pos=new Pos();Object[] pick={level,pos};for(String id:Mutants.IDS)BuiltInRegistries.ENTITY_TYPE.items.put(ResourceLocation.parse("mutantszombies:"+id),id);
  int rare=0;for(int i=0;i<500;i++){level.random.rare=i;Object result=Mutants.call(events,"pick",pick);if(result!=events.original)rare++;}check(rare==1);
  level.random.rare=0;level.random.weighted=99;check(Mutants.call(events,"pick",pick).equals("mutant_brute"));
  level.entities.add(new Entity("mutantszombies:crawler",20));check(Mutants.call(events,"pick",pick).equals("mutant_brute"));level.entities.add(new Entity("mutantszombies:spitter",30));check(Mutants.call(events,"pick",pick)==events.original);
  level.entities.get(1).x=129;check(Mutants.call(events,"pick",pick).equals("mutant_brute"));level.entities.get(1).x=30;level.entities.get(1).alive=false;check(Mutants.call(events,"pick",pick).equals("mutant_brute"));
  BuiltInRegistries.ENTITY_TYPE.items.clear();check(Mutants.call(events,"pick",pick)==events.original);
  Mutants.call(events,"attributes",new Object[]{new Entity("mutantszombies:mutant_brute",0),false});check(events.attributes==0);Mutants.call(events,"attributes",new Object[]{new Entity("minecraft:zombie",0),false});check(events.attributes==1);
  NativeLoot nativeLoot=new NativeLoot();Corpse corpse=new Corpse();for(String id:Mutants.IDS){Loot.populate(nativeLoot,"populateMutant",new Object[]{corpse,level},new Entity("mutantszombies:"+id,0));check(corpse.quality==Loot.tier("mutantszombies:"+id));Loot.extras(corpse,level,false,true,new Entity("mutantszombies:"+id,0));}check(nativeLoot.count==0);Loot.populate(nativeLoot,"populateMutant",new Object[]{corpse,level},new Entity("mutantmonsters:mutant_zombie",0));check(nativeLoot.count==1);
  System.out.println("PASS "+checks+" production runtime checks (API doubles; no Minecraft world)");
 }
}
