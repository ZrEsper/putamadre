from pathlib import Path
import json,zipfile,shutil,subprocess,re,copy,hashlib
r=Path(__file__).resolve().parent
for n,h in json.loads((r/'inputs.sha256.json').read_text()).items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
work=r/'build';shutil.rmtree(work,ignore_errors=True);work.mkdir()
for name in ['mutants','blues']:
 with zipfile.ZipFile(r/'bases'/f'{name}.zip') as z:
  assert all('..' not in Path(n).parts and not n.startswith('/') for n in z.namelist())
  z.extractall(work/name)
mut=work/'mutants';blue=work/'blues';cem=blue/'assets/minecraft/optifine/cem';mc=mut/'assets/mutantszombies/optifine/cem';mc.mkdir(parents=True)
def run(*a):subprocess.run(a,check=True)
def gore(base,art,out,strength=1):
 # Generated art is fitted to the original pixel grid. Keep original UV alpha exactly.
 from PIL import Image
 a=Image.open(base).convert('RGBA');w,h=a.size
 layer=work/'layer.png';mask=work/'masked.png'
 expr=f'(u.r>u.g*1.32&&u.r>u.b*1.25&&u.r>.15)?u.a*{strength}:((u.r>.65&&u.g>.57&&u.b>.4&&u.r>u.b*1.1&&u.g>u.b*1.05)?u.a*{strength}:0)'
 run('magick',str(art),'-filter','point','-resize',f'{w}x{h}!','-channel','A','-fx',expr,'+channel',str(layer))
 run('magick',str(layer),str(base),'-compose','DstIn','-composite',str(mask))
 raw=work/'raw.png'
 run('magick',str(base),str(mask),'-compose','Over','-composite',str(raw))
 run('magick',str(raw),str(base),'-compose','CopyOpacity','-composite','-strip',str(out))
 # Read-only validation: never package a changed UV silhouette or image dimensions.
 b=Image.open(out).convert('RGBA');assert a.size==b.size and a.getchannel('A').tobytes()==b.getchannel('A').tobytes(),out
 assert a.tobytes()!=b.tobytes(),out
native=['rottenmutant','mutantbrute','blisterzombie','spitter','crawler','splitheadzombie','zombiebrute']
for name in native:
 p=mut/'assets/mutantszombies/textures/entities'/f'{name}.png';gore(p,r/'art'/f'{name}.png',p)
# Process all adult/body atlases while preserving existing emissive masks and effect UVs.
for p in cem.glob('*.png'):
 if p.name.endswith('_e.png') or p.name=='pack.png':continue
 from PIL import Image
 if Image.open(p).size==(240,64):gore(p,r/'art/blues.png',p,.55)
def walk(node):
 yield node
 for child in node.get('submodels',[]):yield from walk(child)
 if 'submodel' in node:yield from walk(node['submodel'])
def enhance(d):
 # Health is normalized so mutant HP increases do not suppress Blue's damage effects.
 for top in d['models']:
  for node in walk(top):
   for anim in node.get('animations',[]):
    for key,value in list(anim.items()):
     if isinstance(value,(int,float)):anim[key]=str(value)
     if isinstance(value,str):anim[key]=re.sub(r'\bhealth\b','(health / max(1, max_health) * 20)',value)
    sides={'left':('zombie_new_arm_left_dismember',.42,117,14,-1),'right':('zombie_new_arm_right_dismember',.26,127,14,1),'head':('zombie_head_dismember',.10,137,20,1)}
    for side,(part,threshold,seed,fall,direction) in sides.items():
     key='var.dismember_'+side
     if key not in anim:continue
     # Place the timer before its consumers, retaining authored animation order.
     timer='var.gore_time_'+side;state=f'if(health < max_health * ({threshold} + random(id + {seed}) * .08), min({timer} + frame_time, 6), {timer})'
     rebuilt={}
     for k,v in anim.items():
      if k==key:rebuilt[timer]=state;v=f'min(2000, {timer} * 500)'
      elif k=='var.vanish_delay_'+side:v=f'{timer} * 20'
      elif k=='var.vanish_'+side:v=f'min(57.29578, max(0, {timer} - 3) * 38.19719)'
      rebuilt[k]=v
     anim.clear();anim.update(rebuilt)
   # Override existing authored part transforms rather than adding duplicate assignments.
   for anim in node.get('animations',[]):
    for side,(part,threshold,seed,fall,direction) in sides.items():
     timer='var.gore_time_'+side
     for suffix,expr in {'tx':f'{direction} * min(9, {timer} * 6)','ty':f'min({fall}, {timer} * {timer} * 48)','tz':f'min(7, {timer} * 4)','rz':f'{direction} * min(2.8, {timer} * 3)','sx':f'max(0, 1 - max(0, {timer} - 3) / 1.5)','sy':f'max(0, 1 - max(0, {timer} - 3) / 1.5)','sz':f'max(0, 1 - max(0, {timer} - 3) / 1.5)'}.items():
      k=part+'.'+suffix
      if k in anim:anim[k]=expr
 # Canonicalize original duplicate assignments: keep the authored last assignment.
 owners={}
 for top in d['models']:
  for node in walk(top):
   for anim in node.get('animations',[]):
    for k in list(anim):
     if k in owners:del owners[k][k]
     owners[k]=anim
 return d
# Authored Blue's models retain their gait/recoil/sway, with bounded falls and slower fade.
for p in cem.glob('*.jem'):
 d=enhance(json.loads(p.read_text()));p.write_text(json.dumps(d,separators=(',',':')))
new=[(31,2,'fresh'),(32,3,'bone'),(33,4,'bone'),(34,30,'fresh'),(35,27,'bone'),(36,28,'bone')]
for index,source,style in new:
 d=json.loads((cem/f'zombie{source}.jem').read_text());base=cem/d['texture'];texture=cem/f'zombie{index}.png';gore(base,r/'art'/('blues-bone.png' if style=='bone' else 'blues.png'),texture,.95)
 old_e=base.with_name(base.stem+'_e.png')
 if old_e.exists():shutil.copy2(old_e,cem/f'zombie{index}_e.png')
 d['texture']=texture.name;(cem/f'zombie{index}.jem').write_text(json.dumps(d,separators=(',',':')))
properties=(cem/'zombie.properties').read_text()
# Keep named/professional rules first; extend adult terrain and general adult pools only.
for rule in [14,15]:
 properties=re.sub(rf'(?m)^models\.{rule}=(.*)$',lambda m:m.group(0)+' 31 32 33 34 35 36',properties)
 properties=re.sub(rf'(?m)^weights\.{rule}=(.*)$',lambda m:m.group(0)+' 170 95 65 95 55 45',properties)
(cem/'zombie.properties').write_text(properties)
species={
 'crawler':('crawler_layer',28,1.0,{'head':'head','body':'torso','left_arm':'left_arm','right_arm':'right_arm','left_leg':'left_leg','right_leg':'right_leg'}),
 'blister_zombie':('blister_zombie_layer',2,1.25,{'head':'head','body':'torso','left_arm':'left_arm','right_arm':'right_arm','left_leg':'left_leg','right_leg':'right_leg'}),
 'rotten_mutant':('rotten_mutant_layer',3,1.4,{'head':'head','body':'torso','left_arm':'left_arm','right_arm':'right_arm','left_leg':'left_leg','right_leg':'right_leg'}),
 'zombie_brute':('zombie_brute_layer',4,1.4,{'head':'head','body':'torso','left_arm':'left_arm','right_arm':'right_arm','left_leg':'left_leg','right_leg':'right_leg'}),
 'mutant_brute':('mutant_brute',4,1.8,{'head':'head','body':'torso','left_arm':'left_arm','right_arm':'right_arm','left_leg':'left_leg','right_leg':'right_leg'}),
 'split_head_zombie':('split_head_zombie',27,1.3,{'head':'head1','body':'torso','left_leg':'leftleg','right_leg':'rightleg'}),
 'spitter':('spitter_layer',2,1.4,{'head':'head2','body':'torso','left_arm':'left_arm','right_arm':'right_arm','left_leg':'left_leg','right_leg':'right_leg'})}
for species_id,(layer,source,scale,parts) in species.items():
 for variant in range(1,4):
  d=json.loads((cem/f'zombie{source}.jem').read_text());tex=mc/f'{layer}-gore{variant}.png';gore(cem/d['texture'],r/'art'/('blues-bone.png' if variant>=2 else 'blues.png'),tex,.6 if variant==1 else .85 if variant==2 else 1)
  old_e=(cem/d['texture']).with_name(Path(d['texture']).stem+'_e.png')
  if old_e.exists():shutil.copy2(old_e,tex.with_name(tex.stem+'_e.png'))
  d['texture']=tex.name;d['models']=[m for m in d['models'] if m['part'] in parts]
  for m in d['models']:
   m['part']=parts[m['part']]
   if m['id']=='body':
    # Whole Blue's skeleton is carried by the native torso part.
    for node in walk(m):
     if node.get('id')=='zombie_all':node['scale']=scale
  extra=['head2'] if species_id=='split_head_zombie' else [f'head{i}' for i in range(3,9)] if species_id=='spitter' else []
  for head in extra:d['models'].append({'part':head,'id':'hidden_'+head,'animations':[{f'hidden_{head}.ty':'300'}]})
  filename=layer+('' if variant==1 else str(variant))+'.jem';(mc/filename).write_text(json.dumps(d,separators=(',',':')))
 (mc/f'{layer}.properties').write_text('models.1=1 2 3\nweights.1=55 30 15\n')
 # Exact native part map recorded for static audits against the provided MutantsZombies source.
 (mc/f'{layer}.mapping.json').write_text(json.dumps({'entity':species_id,'native_parts':list(parts.values())+extra,'source_blue':source,'scale':scale},indent=2))
# Validation catches missing textures, malformed animations, inaccessible variant indices and weights.
checks=0
for root in [blue,mut]:
 for p in root.rglob('*.jem'):
  d=json.loads(p.read_text());assert len(d.get('textureSize',[]))==2 and all(x>0 for x in d['textureSize']),p
  if d.get('texture'):assert (p.parent/d['texture']).exists(),p
  ids=set();assigned=set();variables=set()
  for top in d['models']:
   for node in walk(top):
    if 'id' in node:assert node['id'] not in ids,(p,node['id']);ids.add(node['id'])
    for anim in node.get('animations',[]):
     for k,v in anim.items():
      assert k not in assigned,(p,k);assigned.add(k)
      if k.startswith('var.'):variables.add(k)
      assert isinstance(v,str) and v.count('(')==v.count(')'),(p,k)
  for top in d['models']:
   for node in walk(top):
    for anim in node.get('animations',[]):
     for v in anim.values():
      for name in re.findall(r'var\.gore_time_\w+',v):assert name in assigned,(p,name)
  for k in assigned:
   if k.startswith('var.gore_time_'):checks+=1
  checks+=1
 for p in (root/'assets').rglob('*.properties'):
  text=p.read_text()
  for index,values in re.findall(r'(?m)^models\.(\d+)\s*=\s*([^\n]+)',text):
   variants=values.split();weight=re.search(rf'(?m)^weights\.{index}\s*=\s*([^\n]+)',text)
   if weight:assert len(variants)==len(weight.group(1).split()),p
   for v in variants:
    if v=='1':assert p.with_suffix('.jem').exists(),p
    else:assert (p.parent/(p.stem+v+'.jem')).exists(),(p,v)
   checks+=1
 meta=json.loads((root/'pack.mcmeta').read_text());meta['pack']['pack_format']=34;meta['pack']['description']=('MutantsZombies - Blue\'s EMF Gore + exposed bones' if root==mut else 'Blue\'s Better Zombies - PZ L4D2 Gore + exposed bones');(root/'pack.mcmeta').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
 (root/'GORE-LEEME.txt').write_text((r/'README.md').read_text())
(r/'output').mkdir(exist_ok=True)
for name,root in [('MutantsZombies-Blues-EMF-Gore.1.zip',mut),('Blues-Better-Zombies-PZ-L4D2-Gore.1.zip',blue)]:
 with zipfile.ZipFile(r/'output'/name,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(root))
# Mutant CEM variants cover exactly the constructor-accessed native root parts.
for species_id,(layer,source,scale,parts) in species.items():
 mapping=json.loads((mc/f'{layer}.mapping.json').read_text())
 for variant in range(1,4):
  d=json.loads((mc/(layer+('' if variant==1 else str(variant))+'.jem')).read_text())
  assert {m['part'] for m in d['models']}==set(mapping['native_parts']),(layer,variant)
  checks+=1
# Evaluate the authored detached-part transforms at key timestamps with a restricted AST.
import ast
semantic=0
for layer in [v[0] for v in species.values()]:
 d=json.loads((mc/f'{layer}.jem').read_text())
 for top in d['models']:
  for node in walk(top):
   for anim in node.get('animations',[]):
    for key,expr in anim.items():
     if 'dismember.' not in key or not key.endswith(('.ty','.sx','.sy','.sz')) or 'var.gore_time_' not in expr:continue
     for t in [0,.1,.5,1,3,4.5,6]:
      e=re.sub(r'var\.gore_time_\w+',str(t),expr);tree=ast.parse(e,mode='eval')
      assert all(isinstance(n,(ast.Expression,ast.Call,ast.Name,ast.Load,ast.Constant,ast.BinOp,ast.UnaryOp,ast.Add,ast.Sub,ast.Mult,ast.Div,ast.USub)) for n in ast.walk(tree))
      value=eval(compile(tree,'<animation-transform>','eval'),{'__builtins__':{},'min':min,'max':max})
      assert 0<=value<=(20 if key.endswith('.ty') else 1),(layer,key,t,value)
      if key.endswith(('.sx','.sy','.sz')):assert value==(1 if t<=3 else 0) if t in [0,1,3,4.5,6] else True
      semantic+=1
print('PASS static animation/resource checks:',checks,'bounded fall/fade values:',semantic)
(r/'output/validation.json').write_text(json.dumps({'static_checks':checks,'bounded_transform_values':semantic,'native_species':7,'native_emf_models':21,'new_blue_variants':6,'minecraft_visual_tested':False,'uv_alpha_preserved':True,'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'output').glob('*.zip')}},indent=2))
