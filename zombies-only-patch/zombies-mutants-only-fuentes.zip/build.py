from pathlib import Path
import sys,hashlib,json,subprocess,zipfile,shutil
r=Path(__file__).resolve().parent;h,th=map(lambda p:Path(p).resolve(),sys.argv[1:3])
for n,p in [('horde',h),('thehordes',th)]:assert hashlib.sha256(p.read_bytes()).hexdigest()==json.loads((r/'bases.sha256.json').read_text())[n]
for n,v in json.loads((r/'tools.sha256.json').read_text()).items():assert hashlib.sha256((r/'tools'/n).read_bytes()).hexdigest()==v
for d in ['classes','patch-tool','patched-h','patched-th','test-classes']:shutil.rmtree(r/d,ignore_errors=True);(r/d).mkdir()
def run(*a):subprocess.run(a,cwd=r,check=True)
ecj=['java','-jar',str(r/'tools/ecj.jar'),'-21','-nowarn'];asm=':'.join(str(r/'tools'/n) for n in ['asm.jar','asm-tree.jar','asm-analysis.jar','asm-util.jar'])
run(*ecj,'-d',str(r/'classes'),*[str(p) for p in (r/'src').rglob('*.java')])
run(*ecj,'-cp',asm,'-d',str(r/'patch-tool'),str(r/'FilterPatch.java'),str(r/'OtherPatch.java'))
run('java','-Xverify:all','-cp',str(r/'patch-tool')+':'+asm,'FilterPatch',str(h),str(r/'patched-h'),str(r/'test-classes'))
for kind,base,d in [('horde',h,'patched-h'),('thehordes',th,'patched-th')]:run('java','-Xverify:all','-cp',str(r/'patch-tool')+':'+asm,'OtherPatch',kind,str(base),str(r/d))
run(*ecj,'-cp',str(r/'classes')+':'+str(r/'test-classes'),'-d',str(r/'test-classes'),*[str(p) for p in (r/'tests').rglob('*.java')])
run('java','-Xverify:all','-cp',str(r/'test-classes')+':'+str(r/'classes'),'Checks')
(r/'output').mkdir(exist_ok=True);results={}
for kind,base,d,name in [('horde',h,'patched-h','zomboid-hordes-1.8.3-neoforge-1.21.1-zombies-mutants-only.2.jar'),('thehordes',th,'patched-th','The-Hordes-1.21.1-1.6.3f-zombies-mutants-only.1.jar')]:
 add={p.relative_to(r/d).as_posix():p.read_bytes() for p in (r/d).rglob('*.class')}
 if kind=='thehordes':add.update({p.relative_to(r/'classes').as_posix():p.read_bytes() for p in (r/'classes').rglob('*.class')})
 changed=set(add);out=r/'output'/name
 with zipfile.ZipFile(base) as z,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for e in z.infolist():w.writestr(e,add.pop(e.filename,z.read(e)))
  for n,b in add.items():w.writestr(n,b)
 with zipfile.ZipFile(base) as z,zipfile.ZipFile(out) as w:
  assert w.testzip() is None
  for n in z.namelist():
   if n not in changed:assert z.read(n)==w.read(n),n
  assert not any(n.startswith('net/minecraft/') or n=='SpawnPredicate.class' for n in w.namelist())
 results[name]={'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'changed_classes':sorted(changed)}
(r/'output/validation.json').write_text(json.dumps({'artifacts':results,'runtime_tested':False,'mutant_chance':.01},indent=2));print('PASS unrelated classes/resources preserved in both JARs')
