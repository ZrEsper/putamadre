package net.minecraft.resources;public record ResourceLocation(String value){public static ResourceLocation parse(String s){return new ResourceLocation(s);}public String toString(){return value;}}
