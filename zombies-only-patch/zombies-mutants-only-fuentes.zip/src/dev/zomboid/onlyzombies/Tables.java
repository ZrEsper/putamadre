package dev.zomboid.onlyzombies;
import java.util.*;
public final class Tables {
 static volatile List<Object> entries;
 public static final String[] IDS={"crawler","blister_zombie","split_head_zombie","rotten_mutant","spitter","zombie_brute","mutant_brute"};
 public static final int[] WEIGHTS={18,25,23,18,10,5,1};
 public static List<Object> entries(){
  if(entries!=null)return entries;
  synchronized(Tables.class){if(entries!=null)return entries;
   List<Object> result=new ArrayList<>();Object reg=R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE");
   Object zombie=R.call(reg,"get",R.call(R.type("net.minecraft.resources.ResourceLocation"),"parse","minecraft:zombie"));
   int missing=0;
   for(int i=0;i<IDS.length;i++){
    Object key=R.call(R.type("net.minecraft.resources.ResourceLocation"),"parse","mutantszombies:"+IDS[i]);
    if(!R.yes(R.call(reg,"containsKey",key))){missing+=WEIGHTS[i];continue;}
    result.add(entry(R.call(reg,"get",key),WEIGHTS[i]));
   }
   result.add(0,entry(zombie,9900+missing));entries=Collections.unmodifiableList(result);return entries;
  }
 }
 static Object entry(Object type,int weight){return R.make("net.smileycorp.hordes.hordeevent.HordeSpawnEntry",type,weight,0,0,0,0);}
}
