import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;import java.nio.file.*;import java.util.zip.*;
public class OtherPatch implements Opcodes{
 public static void main(String[] a)throws Exception{boolean th=a[0].equals("thehordes");String name=th?"net/smileycorp/hordes/hordeevent/HordeSpawnTable":"dev/zomboid/rarehorde/Mutants";ClassNode c=new ClassNode();try(ZipFile z=new ZipFile(a[1])){new ClassReader(z.getInputStream(z.getEntry(name+".class"))).accept(c,ClassReader.EXPAND_FRAMES);}int changes=0;
 for(MethodNode m:c.methods)for(AbstractInsnNode i:m.instructions.toArray()){
 if(th&&m.name.equals("getSpawnTable")&&i instanceof FieldInsnNode f&&f.getOpcode()==GETFIELD&&f.owner.equals(name)&&f.name.equals("spawns")){m.instructions.insertBefore(i,new InsnNode(POP));m.instructions.set(i,new MethodInsnNode(INVOKESTATIC,"dev/zomboid/onlyzombies/Tables","entries","()Ljava/util/List;",false));changes++;}
 if(!th&&m.name.equals("call")&&i instanceof IntInsnNode x&&x.operand==500){x.operand=100;changes++;}}
 if(changes!=1)throw new IllegalStateException("hook count "+changes);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] b=w.toByteArray();ClassNode check=new ClassNode();new ClassReader(b).accept(check,0);int n=0;for(MethodNode m:check.methods)if(m.instructions.size()>0){new Analyzer<>(new BasicVerifier()).analyze(check.name,m);n++;}Path p=Path.of(a[2],name+".class");Files.createDirectories(p.getParent());Files.write(p,b);System.out.println("PASS ASM "+n+" methods "+name);}
}
