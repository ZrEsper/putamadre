package dev.zomboid.installer;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.*;
import java.util.zip.*;

public final class PackFiles {
    public static Engine.Pack load(Path home, Consumer<String> log) throws IOException {
        Engine.Pack base=Engine.load(home.resolve("pack"));
        Path parts=home.resolve("componentes");
        List<Path> inputs=List.of();
        if(Files.isDirectory(parts)) try(Stream<Path> s=Files.list(parts)) {
            inputs=s.filter(p->Files.isDirectory(p) || p.toString().toLowerCase(Locale.ROOT).endsWith(".zip") || p.toString().toLowerCase(Locale.ROOT).endsWith(".jar")).sorted().toList();
        }
        if(inputs.isEmpty()) {
            if(base.files().isEmpty()) throw new IOException("Este paquete todavía no contiene los mods ni el mapa. Pide al creador el ZIP completo. No necesitas buscar archivos ni añadir nada tú.");
            return base;
        }
        Path imports=Files.createDirectories(home.resolve("imports"));
        Path pointer=imports.resolve("preparado.txt");
        // home is a content-addressed cache of datos.zip. Its creator inputs are immutable.
        // Reuse only a complete, hash-verified assembly to avoid copying huge maps each launch.
        if(Files.isRegularFile(pointer)) try {
            String name=Files.readString(pointer).trim();
            if(name.matches("lego-[a-fA-F0-9-]+")) {
                Engine.Pack prior=Engine.load(imports.resolve(name));
                boolean valid=!prior.files().isEmpty();
                for(Engine.Entry e:prior.files()) if(!Engine.sha(prior.root().resolve(Engine.safeName(e.path()))).equals(e.sha256())) { valid=false; break; }
                if(valid) { log.accept("Contenido preparado previamente: hashes correctos."); return prior; }
            }
        } catch(Exception e) { log.accept("Se vuelve a preparar el contenido: "+e.getMessage()); }
        Engine.Pack result=Lego.assemble(base,inputs,imports,log);
        Files.writeString(pointer,result.root().getFileName().toString());
        return result;
    }
    public static Path exportCurseForge(Engine.Pack pack,Path out) throws IOException {
        if(pack.files().isEmpty()) throw new IOException("El paquete está vacío.");
        Path tmp=Files.createTempFile(out.toAbsolutePath().getParent(),"curseforge-",".zip");
        try {
            try(ZipOutputStream zip=new ZipOutputStream(Files.newOutputStream(tmp))) {
                String manifest=Json.write(Map.of("minecraft",Map.of("version",pack.minecraft(),"modLoaders",List.of(Map.of("id","neoforge-"+pack.neoForge(),"primary",true))),
                    "manifestType","minecraftModpack","manifestVersion",1,"name","ZOMBIES POLDO","version","1.3.1","author","Poldo","files",List.of(),"overrides","overrides"));
                entry(zip,"manifest.json",manifest.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                for(Engine.Entry e:pack.files()) {
                    Path source=pack.root().resolve(Engine.safeName(e.path()));
                    if(!Engine.sha(source).equals(e.sha256())) throw new IOException("Archivo cambiado: "+e.path());
                    zip.putNextEntry(new ZipEntry("overrides/"+e.path())); Files.copy(source,zip); zip.closeEntry();
                }
                if(!pack.options().isEmpty()) entry(zip,"overrides/options.txt",pack.options().entrySet().stream().map(e->e.getKey()+":"+e.getValue()).collect(Collectors.joining("\n","","\n")).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
            // Never overwrite a player's existing export.
            Files.move(tmp,out);
            return out;
        } finally { Files.deleteIfExists(tmp); }
    }
    private static void entry(ZipOutputStream z,String name,byte[] data) throws IOException {
        z.putNextEntry(new ZipEntry(name)); z.write(data); z.closeEntry();
    }
    public static Path prepare(Path release,Path parts,Path out,Consumer<String> log) throws IOException {
        List<Path> inputs;
        try(Stream<Path> s=Files.list(parts)) { inputs=s.filter(p->Files.isDirectory(p)||p.toString().toLowerCase(Locale.ROOT).endsWith(".zip")||p.toString().toLowerCase(Locale.ROOT).endsWith(".jar")).sorted().toList(); }
        if(inputs.isEmpty()) throw new IOException("Pon primero los ZIP/JAR del modpack en Para-el-creador/componentes. Esta plantilla no incluye el modpack.");
        Path scratch=Files.createTempDirectory("poldo-validar-");
        Path payload=Files.createTempFile("poldo-datos-",".zip");
        Path outer=Files.createTempFile(out.getParent(),"poldo-distribucion-",".zip");
        try {
            // Validate all creator inputs before producing a player distribution.
            Engine.Pack assembled=Lego.assemble(null,inputs,scratch,log);
            log.accept("Contenido comprobado: "+assembled.files().size()+" archivos.");
            try(ZipOutputStream z=new ZipOutputStream(Files.newOutputStream(payload)); ZipFile old=new ZipFile(release.resolve("datos.zip").toFile())) {
                for(ZipEntry e:Collections.list(old.entries())) if(!e.isDirectory() && !e.getName().startsWith("componentes/")) {
                    z.putNextEntry(new ZipEntry(e.getName())); try(InputStream in=old.getInputStream(e)) { in.transferTo(z); } z.closeEntry();
                }
                for(Path p:inputs) {
                    if(Files.isSymbolicLink(p)) throw new IOException("No se permiten enlaces en componentes: "+p.getFileName());
                    if(Files.isDirectory(p)) try(Stream<Path> files=Files.walk(p)) {
                        for(Path f:files.filter(Files::isRegularFile).sorted().toList()) {
                            if(Files.isSymbolicLink(f)) throw new IOException("No se permiten enlaces en componentes.");
                            z.putNextEntry(new ZipEntry("componentes/"+p.getFileName()+"/"+p.relativize(f).toString().replace('\\','/'))); Files.copy(f,z); z.closeEntry();
                        }
                    } else { z.putNextEntry(new ZipEntry("componentes/"+p.getFileName())); Files.copy(p,z); z.closeEntry(); }
                }
            }
            try(ZipOutputStream z=new ZipOutputStream(Files.newOutputStream(outer))) {
                for(String name:List.of("Instalar.cmd","Ayuda.cmd","Abrir-Instalador.ps1","GUIA.html","LEEME.txt","motor.zip")) {
                    z.putNextEntry(new ZipEntry(name));
                    if(name.equals("LEEME.txt")) z.write(("ZOMBIES POLDO — INSTALAR Y JUGAR\n\n1. Clic derecho en este ZIP → Extraer todo.\n2. Abre Instalar.cmd en la carpeta extraída.\n3. Elige tu juego → Continuar → Instalar ahora.\n\nNo abras datos.zip: el instalador se encarga de todo lo de adentro.\n¿Primera vez con Minecraft? Pulsa ‘No tengo Minecraft preparado’.\nGuía fácil: GUIA.html. Si falla: Ayuda.cmd.\n").getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    else Files.copy(release.resolve(name),z);
                    z.closeEntry();
                }
                z.putNextEntry(new ZipEntry("datos.zip")); Files.copy(payload,z); z.closeEntry();
            }
            Files.move(outer,out);
            return out;
        } finally { Engine.removeTree(scratch); Files.deleteIfExists(payload); Files.deleteIfExists(outer); }
    }
}
