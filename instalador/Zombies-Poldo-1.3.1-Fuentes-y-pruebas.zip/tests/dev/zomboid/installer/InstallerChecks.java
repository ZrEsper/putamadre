package dev.zomboid.installer;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

public final class InstallerChecks {
    static int count;
    static void check(boolean b,String message) { if(!b) throw new AssertionError(message); count++; System.out.println("OK "+message); }
    static void fails(Throwing job,String label) throws Exception { try {job.run();}catch(IOException e){count++;System.out.println("OK "+label+" — "+e.getMessage());return;}throw new AssertionError(label); }
    interface Throwing {void run() throws Exception;}
    static void write(Path p,String s) throws IOException {Files.createDirectories(p.getParent());Files.writeString(p,s);}
    static void zip(Path p,Map<String,String> entries) throws IOException { Files.createDirectories(p.getParent()); try(ZipOutputStream z=new ZipOutputStream(Files.newOutputStream(p))) { for(var e:entries.entrySet()){z.putNextEntry(new ZipEntry(e.getKey()));z.write(e.getValue().getBytes(java.nio.charset.StandardCharsets.UTF_8));z.closeEntry();} } }
    static void instance(Path p,String neo) throws IOException {write(p.resolve("minecraftinstance.json"),"{\"minecraftVersion\":\"1.21.1\",\"baseModLoader\":{\"name\":\"neoforge-"+neo+"\"}}");}
    public static void main(String[] args) throws Exception {
        Path root=Files.createTempDirectory("poldo-tests-");
        try {
            Path user=root.resolve("Jugador con espacios"), roaming=root.resolve("Roaming"), local=root.resolve("Local");
            Path cf=user.resolve("curseforge/minecraft/Instances/ZOMBIES POLDO");instance(cf,"21.1.255");
            Path vanilla=roaming.resolve(".minecraft");Files.createDirectories(vanilla.resolve("versions"));
            Path custom=root.resolve("Juego personalizado");Files.createDirectories(custom.resolve("versions"));
            Properties props=new Properties();props.setProperty("minecraft.gamedir",custom.toString());
            Path prop=roaming.resolve(".tlauncher/tlauncher-2.0.properties");Files.createDirectories(prop.getParent());try(OutputStream o=Files.newOutputStream(prop)){props.store(o,"location only");}
            Path customCF=root.resolve("Otro disco/CurseForge");instance(customCF.resolve("Instances/Perfil personalizado"),"21.1.255");
            write(roaming.resolve("CurseForge/minecraft.settings"),Json.write(Map.of("minecraft",Map.of("moddingFolder",customCF.toString()))));
            Path profile=root.resolve("Perfil separado");Files.createDirectories(profile);
            write(vanilla.resolve("launcher_profiles.json"),Json.write(Map.of("profiles",Map.of("example",Map.of("name","Separado","gameDir",profile.toString())))));
            var targets=new LauncherDiscovery(user,roaming,local,s->{}).discover();
            check(targets.stream().anyMatch(t->t.path().equals(cf)),"CurseForge habitual");
            check(targets.stream().anyMatch(t->t.path().equals(custom)&&t.launcher().equals("TLauncher")),"TLauncher con carpeta personalizada y espacios");
            check(targets.stream().anyMatch(t->t.path().equals(customCF.resolve("Instances/Perfil personalizado"))),"CurseForge con ruta configurada");
            check(targets.stream().anyMatch(t->t.path().equals(profile)),"gameDir de perfil independiente");
            check(targets.stream().map(LauncherDiscovery.Target::path).distinct().count()==targets.size(),"Sin carpetas duplicadas");
            check(LauncherDiscovery.resolveManual(cf).equals(cf.toRealPath()),"Selección de perfil CurseForge");
            check(LauncherDiscovery.resolveManual(roaming).equals(vanilla.toRealPath()),"Normaliza carpeta padre de .minecraft");
            fails(()->LauncherDiscovery.resolveManual(root),"Bloquea selección de carpeta general");
            Path empty=root.resolve("empty");write(empty.resolve("pack/pack.json"),"{\"formatVersion\":1,\"name\":\"Poldo\",\"mode\":\"update\",\"minecraft\":\"1.21.1\",\"neoForge\":\"21.1.255\",\"files\":[]}");
            fails(()->PackFiles.load(empty,s->{}),"Plantilla vacía da ayuda concreta");
            Path home=root.resolve("payload");Files.createDirectories(home.resolve("pack"));Files.copy(empty.resolve("pack/pack.json"),home.resolve("pack/pack.json"));
            zip(home.resolve("componentes/Config.zip"),Map.of("config/poldo.cfg","new-config"));
            zip(home.resolve("componentes/Mapa.zip"),Map.of("Mi mapa/level.dat","world-fixture","Mi mapa/data/test.dat","world-data"));
            Path jar=home.resolve("componentes/demo.jar");zip(jar,Map.of("META-INF/neoforge.mods.toml","[[mods]]\nmodId=\"demo\"\nversion=\"1.0.0\"\n"));
            Engine.Pack pack=PackFiles.load(home,s->{});
            check(pack.files().stream().anyMatch(e->e.path().equals("config/poldo.cfg")),"Descomprime configuración automáticamente");
            check(pack.files().stream().anyMatch(e->e.path().equals("saves/Mi mapa/level.dat")),"Descomprime mapa dentro de saves");
            check(pack.files().stream().anyMatch(e->e.path().equals("mods/demo.jar")),"Coloca JAR en mods");
            check(PackFiles.load(home,s->{}).root().equals(pack.root()),"Reutiliza contenido verificado sin duplicar mapa");
            Path cfZip=root.resolve("CurseForge.zip");PackFiles.exportCurseForge(pack,cfZip);
            try(ZipFile z=new ZipFile(cfZip.toFile())) {
                var m=Json.object(Json.parse(new String(z.getInputStream(z.getEntry("manifest.json")).readAllBytes(),java.nio.charset.StandardCharsets.UTF_8)));
                check(m.get("manifestType").equals("minecraftModpack"),"Manifest de importación CurseForge");
                check(Json.object(m.get("minecraft")).get("version").equals("1.21.1"),"Versión Minecraft en perfil automático");
                check(Json.object(Json.list(Json.object(m.get("minecraft")).get("modLoaders")).get(0)).get("id").equals("neoforge-21.1.255"),"NeoForge en perfil automático");
                check(z.getEntry("overrides/saves/Mi mapa/level.dat")!=null&&z.getEntry("overrides/mods/demo.jar")!=null,"Perfil incluye mods y mapa");
            }
            fails(()->PackFiles.exportCurseForge(pack,cfZip),"Exportar no sobrescribe un ZIP existente");
            write(cf.resolve("config/poldo.cfg"),"old-config");
            Engine.Plan plan=Engine.review(pack,cf,List.of(),s->{});check(plan.allowed(),"Revisión válida permite instalar");
            Path backup=Engine.install(plan,true,s->{});
            check(Files.readString(cf.resolve("config/poldo.cfg")).equals("new-config"),"Instala contenido real");
            check(Files.readString(backup.resolve("config/poldo.cfg")).equals("old-config"),"Guarda respaldo original");
            check(Files.readString(cf.resolve("saves/Mi mapa/level.dat")).equals("world-fixture"),"Instala mapa real");
            Engine.Plan repeat=Engine.review(pack,cf,List.of(),s->{});check(repeat.allowed()&&repeat.copies().isEmpty(),"Reinstalación sin cambios no vuelve a copiar");
            Engine.restoreLatest(cf);check(Files.readString(cf.resolve("config/poldo.cfg")).equals("old-config"),"Restaura originales");
            check(!Files.exists(cf.resolve("saves/Mi mapa/level.dat")),"Restauración deshace archivos del mapa añadido");
            instance(cf,"21.1.254");check(!Engine.review(pack,cf,List.of(),s->{}).allowed(),"Versión NeoForge equivocada bloquea copia");instance(cf,"21.1.255");
            write(cf.resolve("saves/Mi mapa/level.dat"),"another-world");check(!Engine.review(pack,cf,List.of(),s->{}).allowed(),"Mundo existente distinto no se sobrescribe");
            Path bad=root.resolve("bad.zip");zip(bad,Map.of("../escape.txt","x"));
            fails(()->Lego.assemble(null,List.of(bad),root.resolve("bad-imports"),s->{}),"ZIP traversal rechazado");check(!Files.exists(root.resolve("escape.txt")),"ZIP no escapa a su carpeta");
            Path release=root.resolve("release");Files.createDirectories(release);
            zip(release.resolve("datos.zip"),Map.of("Zomboid-Installer.jar","jar-fixture","pack/pack.json","{}"));
            for(String n:List.of("Instalar.cmd","Ayuda.cmd","Abrir-Instalador.ps1","GUIA.html","LEEME.txt","motor.zip")) write(release.resolve(n),"fixture");
            Files.createDirectories(release.resolve("Para-el-creador/componentes"));
            fails(()->PackFiles.prepare(release,release.resolve("Para-el-creador/componentes"),root.resolve("empty-release.zip"),s->{}),"Creador no puede distribuir paquete vacío");
            Files.copy(home.resolve("componentes/Config.zip"),release.resolve("Para-el-creador/componentes/Config.zip"));
            Path dist=root.resolve("complete.zip");PackFiles.prepare(release,release.resolve("Para-el-creador/componentes"),dist,s->{});
            try(ZipFile z=new ZipFile(dist.toFile())) {
                check(z.size()==7,"Distribución del jugador tiene solo siete archivos");
                check(z.getEntry("datos.zip")!=null && z.stream().noneMatch(e->e.getName().startsWith("Para-el-creador/")),"Herramientas del creador fuera del ZIP del jugador");
                Path data=root.resolve("check-data.zip");Files.copy(z.getInputStream(z.getEntry("datos.zip")),data);
                try(ZipFile inside=new ZipFile(data.toFile())){check(inside.getEntry("componentes/Config.zip")!=null,"Componentes siguen comprimidos dentro de datos.zip");}
            }
            fails(()->PackFiles.prepare(release,release.resolve("Para-el-creador/componentes"),dist,s->{}),"Empaquetado no sobrescribe distribución anterior");
            System.out.println("PASSED "+count+" functional checks. Windows GUI/PowerShell execution not tested.");
        } finally {Engine.removeTree(root);}
    }
}
