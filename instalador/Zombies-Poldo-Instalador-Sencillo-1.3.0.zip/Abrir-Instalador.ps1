﻿param([switch]$Debug, [switch]$Prepare)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.IO.Compression.FileSystem
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$base = $PSScriptRoot
$cacheBase = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'ZombiesPoldo' } else { Join-Path ([IO.Path]::GetTempPath()) 'ZombiesPoldo' }
$logFolder = Join-Path $cacheBase 'logs'
$exitCode = 1
$stage = $null
$runtimeStage = $null
$runtimeArchive = $null
function Note([string]$text) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' | ' + $text
    Write-Host $text
    Add-Content -LiteralPath $script:bootLog -Value $line -Encoding UTF8
}
function Extract-Safe([string]$archive, [string]$destination) {
    $root = [IO.Path]::GetFullPath($destination).TrimEnd('\') + '\'
    $zip = [IO.Compression.ZipFile]::OpenRead($archive)
    try {
        if ($zip.Entries.Count -gt 250000) { throw 'El ZIP tiene demasiados archivos. Pide al creador que revise el paquete.' }
        $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        foreach ($entry in $zip.Entries) {
            $name = $entry.FullName.Replace('/', '\')
            if ($name.StartsWith('\') -or $name.Contains(':') -or ($name.Split('\') -contains '..')) { throw 'El paquete contiene una ruta no segura.' }
            $target = [IO.Path]::GetFullPath((Join-Path $destination $name))
            if (-not $target.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { throw 'Una ruta del paquete sale de su carpeta.' }
            if ($entry.Name -eq '') { [IO.Directory]::CreateDirectory($target) | Out-Null; continue }
            if (-not $seen.Add($target)) { throw 'Hay archivos duplicados en el paquete.' }
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $false)
        }
    } finally { $zip.Dispose() }
}
function Java-Version([string]$candidate) {
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $false }
    $p = $null
    try {
        $pi = [Diagnostics.ProcessStartInfo]::new()
        $pi.FileName = $candidate; $pi.Arguments = '-version'; $pi.UseShellExecute = $false; $pi.CreateNoWindow = $true
        $pi.RedirectStandardError = $true; $pi.RedirectStandardOutput = $true
        $p = [Diagnostics.Process]::new(); $p.StartInfo = $pi
        [void]$p.Start()
        if (-not $p.WaitForExit(5000)) { $p.Kill(); return $false }
        $info = $p.StandardError.ReadToEnd() + $p.StandardOutput.ReadToEnd()
        if ($p.ExitCode -eq 0 -and $info -match 'version\s+"(\d+)[.\-]') { return ([int]$Matches[1] -ge 21) }
        return $false
    } catch { return $false } finally { if ($p) { $p.Dispose() } }
}
try {
    New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
    $tag = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
    $script:bootLog = Join-Path $logFolder ('inicio-' + $tag + '.log')
    Note 'ZOMBIES POLDO 1.3.0 — Inicio'
    Note ('Windows: ' + [Environment]::OSVersion.VersionString)
    Note ('Paquete: ' + $base)
    $payload = Join-Path $base 'datos.zip'
    if (-not (Test-Path -LiteralPath $payload -PathType Leaf)) { throw 'Falta datos.zip. Extrae toda la carpeta del ZIP que recibiste y abre Instalar.cmd desde esa carpeta.' }
    $digest = (Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash.ToLowerInvariant()
    $appHome = Join-Path $cacheBase ('paquetes\' + $digest)
    $marker = Join-Path $appHome '.listo'
    if (-not (Test-Path -LiteralPath $marker) -or -not (Test-Path -LiteralPath (Join-Path $appHome 'Zomboid-Installer.jar'))) {
        Note 'Descomprimiendo el instalador. No cierres esta ventana.'
        $stage = Join-Path $cacheBase ('extraer-' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $stage | Out-Null
        Extract-Safe $payload $stage
        if (-not (Test-Path -LiteralPath (Join-Path $stage 'Zomboid-Installer.jar'))) { throw 'El paquete no contiene el instalador. Pide un ZIP nuevo al creador.' }
        if (-not (Test-Path -LiteralPath (Join-Path $stage 'pack\pack.json'))) { throw 'Falta la configuración del paquete. Pide un ZIP nuevo al creador.' }
        New-Item -ItemType Directory -Path (Split-Path -Parent $appHome) -Force | Out-Null
        if (Test-Path -LiteralPath $appHome) { throw 'La caché quedó incompleta. Abre Ayuda.cmd y usa la opción de reparar la caché.' }
        Set-Content -LiteralPath (Join-Path $stage '.listo') -Value $digest -Encoding ASCII
        Move-Item -LiteralPath $stage -Destination $appHome
        $stage = $null
    }
    Note ('Contenido preparado: ' + $digest)
    $candidates = [Collections.Generic.List[string]]::new()
    $fromPath = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($fromPath) { $candidates.Add($fromPath.Source) }
    if ($env:JAVA_HOME) { $candidates.Add((Join-Path $env:JAVA_HOME 'bin\java.exe')) }
    $roots = [Collections.Generic.List[string]]::new()
    $roots.Add((Join-Path $cacheBase 'java21'))
    foreach ($pair in @(@($env:ProgramFiles,'Eclipse Adoptium'), @($env:ProgramFiles,'Java'), @($env:ProgramFiles,'Microsoft'), @($env:USERPROFILE,'curseforge\minecraft\Install\runtime'), @($env:APPDATA,'.minecraft\runtime'), @($env:APPDATA,'.tlauncher\jvms'), @($env:USERPROFILE,'.tlauncher\jvms'))) {
        if ($pair[0]) { $roots.Add((Join-Path $pair[0] $pair[1])) }
    }
    foreach ($root in $roots) {
        if (Test-Path -LiteralPath $root -PathType Container) {
            Get-ChildItem -LiteralPath $root -Filter java.exe -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 100 | ForEach-Object { $candidates.Add($_.FullName) }
        }
    }
    $chosenJava = $null
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (Java-Version $candidate) { $chosenJava = $candidate; break }
    }
    if (-not $chosenJava) {
        $answer = [Windows.Forms.MessageBox]::Show('Falta un pequeño componente para abrir el instalador (Java 21). ¿Lo descargamos automáticamente desde Eclipse Adoptium? Necesitas Internet. Se guarda solo para este instalador y no pide administrador.', 'Preparar el instalador', 'YesNo', 'Question')
        if ($answer -ne [Windows.Forms.DialogResult]::Yes) { throw 'Descarga cancelada. Puedes instalar Java 21 desde adoptium.net o abrir Minecraft 1.21.1 una vez y volver a intentar.' }
        Note 'Descargando Java 21 oficial. Espera unos minutos…'
        $arch = if (($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64')) { 'aarch64' } else { 'x64' }
        if (-not [Environment]::Is64BitOperatingSystem) { throw 'Se necesita Windows de 64 bits para Minecraft 1.21.1.' }
        $api = 'https://api.adoptium.net/v3/assets/latest/21/hotspot?architecture=' + $arch + '&image_type=jre&os=windows&vendor=eclipse'
        $assets = Invoke-RestMethod -Uri $api -UseBasicParsing
        $pkg = @($assets)[0].binary.package
        $uri = [Uri]$pkg.link
        if ($uri.Scheme -ne 'https' -or $uri.Host -ne 'github.com' -or $uri.AbsolutePath -notlike '/adoptium/*' -or $pkg.checksum -notmatch '^[a-fA-F0-9]{64}$') { throw 'No se pudo verificar el origen de Java. Usa Java 21 desde adoptium.net.' }
        $runtimeArchive = Join-Path $cacheBase ('java-' + [guid]::NewGuid().ToString('N') + '.zip')
        Invoke-WebRequest -Uri $uri.AbsoluteUri -OutFile $runtimeArchive -UseBasicParsing
        if ((Get-FileHash -LiteralPath $runtimeArchive -Algorithm SHA256).Hash -ne $pkg.checksum) { throw 'La descarga de Java está incompleta o dañada. Vuelve a intentar; no se utilizará este archivo.' }
        Note 'Descarga de Java verificada con SHA-256.'
        $runtimeStage = Join-Path $cacheBase ('java-extraer-' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $runtimeStage | Out-Null
        Extract-Safe $runtimeArchive $runtimeStage
        $newJava = Get-ChildItem -LiteralPath $runtimeStage -Filter java.exe -Recurse -File | Select-Object -First 1
        if (-not $newJava -or -not (Java-Version $newJava.FullName)) { throw 'Java se descargó pero no pudo arrancar. Usa Ayuda.cmd.' }
        $javaHome = Join-Path $cacheBase ('java21\' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path (Split-Path -Parent $javaHome) -Force | Out-Null
        $relative = $newJava.FullName.Substring($runtimeStage.Length).TrimStart('\')
        Move-Item -LiteralPath $runtimeStage -Destination $javaHome; $runtimeStage = $null
        $chosenJava = Join-Path $javaHome $relative
    }
    Note ('Java: ' + $chosenJava)
    $env:POLDO_RELEASE_DIR = $base
    $jar = Join-Path $appHome 'Zomboid-Installer.jar'
    $outLog = Join-Path $logFolder ('java-' + $tag + '-salida.log')
    $errLog = Join-Path $logFolder ('java-' + $tag + '-error.log')
    $arguments = '-jar "' + $jar + '"'
    if ($Prepare) {
        $destination = Join-Path $base ('Zombies-Poldo-Completo-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.zip')
        $arguments += ' --prepare "' + $base + '" "' + $destination + '"'
    }
    $app = Start-Process -FilePath $chosenJava -ArgumentList $arguments -WorkingDirectory $appHome -RedirectStandardOutput $outLog -RedirectStandardError $errLog -WindowStyle Hidden -Wait -PassThru
    $exitCode = $app.ExitCode
    Note ('Finalizado. Código: ' + $exitCode)
    if ($exitCode -ne 0) {
        $hint = if ($Prepare -and (Test-Path $errLog)) { (Get-Content -LiteralPath $errLog -TotalCount 5) -join "`n" } else { 'Abre Ayuda.cmd para ver los registros.' }
        throw ('No se pudo completar la operación. ' + $hint)
    }
    if ($Prepare) { [Windows.Forms.MessageBox]::Show(('LISTO. Envía únicamente este ZIP a tus jugadores:' + "`n" + $destination),'Distribución preparada','OK','Information') | Out-Null }
} catch {
    $message = $_.Exception.Message
    if ($script:bootLog) { Note ('ERROR: ' + $message); Add-Content -LiteralPath $script:bootLog -Value $_.ScriptStackTrace -Encoding UTF8 }
    [Windows.Forms.MessageBox]::Show(($message + "`n`nDiagnóstico: " + $logFolder),'Vamos paso a paso','OK','Error') | Out-Null
    $exitCode = 1
} finally {
    foreach ($temporary in @($stage,$runtimeStage)) { if ($temporary -and (Test-Path -LiteralPath $temporary)) { Remove-Item -LiteralPath $temporary -Recurse -Force } }
    if ($runtimeArchive -and (Test-Path -LiteralPath $runtimeArchive)) { Remove-Item -LiteralPath $runtimeArchive -Force }
}
if ($Debug) { Write-Host ('Registros: ' + $logFolder); Read-Host 'Pulsa Enter para cerrar' | Out-Null }
exit $exitCode
