# Zombies Poldo 1.3.2 — instalador sencillo

Este proyecto añade una interfaz para jugadores al JAR suministrado. Conserva
Engine, Lego, Horror, Diagnostics, Json y App originales como backend y modo
avanzado; no reconstruye ni modifica sus clases. `original.jar` es el archivo
del ZIP adjunto, sin cambios. No contiene el modpack ni el mapa.

## Reconstruir y comprobar

Requisitos: Java 21 y Python 3. Ejecuta `python3 -B build.py` desde esta carpeta.
El script descarga ECJ 3.39.0 desde Maven Central con TLS y SHA-256 fijado,
compila las clases nuevas y ejecuta 34 pruebas funcionales con archivos de
prueba. Produce `dist/Zomboid-Installer.jar`. No necesita javac ni Gradle.

Las pruebas ejercitan detección de CurseForge y TLauncher con ubicaciones
personalizadas, ZIPs de configuración/mapa, instalación, respaldo,
restauración, conflictos de mundos y versiones, importación CurseForge,
rechazo de traversal y empaquetado comprimido sin sobrescribir archivos.
El manifiesto de CurseForge fue comprobado; no se ejecutó CurseForge.

Los scripts PowerShell pasaron análisis sintáctico con PowerShell 7.4.6,
y se ejecutó su detector de Java con rutas válidas e inexistentes en Linux.
No se ejecutó la interfaz ni el bootstrap en Windows. El endpoint de Adoptium
no pudo consultarse desde esta nube (HTTP 403); la descarga automática en
Windows requiere Internet y sigue verificando TLS y SHA-256.
No se inició Minecraft ni se probaron mods, partidas reales o autenticación.

## Distribución

`release-template/` contiene los scripts y la guía; `payload-template/` tiene
los recursos originales, configuración y componentes vacíos. Comprime el JAR
nuevo con audio/, pack/ y componentes/ en datos.zip. Colócalo junto a los
archivos de release-template/.

El creador añade sus ZIP/JAR a Para-el-creador/componentes y abre
Preparar-distribucion.cmd. Se valida el contenido y se crea un ZIP con seis
archivos para el jugador; componentes y recursos están dentro de datos.zip.
Los ZIP/JAR siguen comprimidos hasta que el instalador los necesita.
La validación del backend heredado limita cada ZIP entrante a 30.000 archivos
y 16 GiB extraídos. El empaquetado usa ZIP64; no elimina esos límites.

La caché se guarda en %LOCALAPPDATA%/ZombiesPoldo. La extracción inicial está
contenida en una carpeta temporal, rechaza rutas externas y duplicados; se
publica en la caché solo al completar. La carpeta tiene como nombre el SHA-256
de datos.zip. Ensamblajes completos se reutilizan tras comprobar sus hashes.
No se borra ni cambia el Java del usuario. Java nuevo se obtiene del API de
Adoptium y se limita a paquetes HTTPS de github.com/adoptium, con SHA-256.

La detección automática es acotada a ubicaciones habituales y ajustes
Minecraft de CurseForge, propiedades de TLauncher y gameDir de perfiles.
No recorre discos enteros ni lee tokens. Las variantes desconocidas conservan
selección manual; no se promete detectar cualquier instalación posible.
Varias carpetas requieren selección explícita. Elegir carpeta general falla.
No se modifican mundos distintos de mismo nombre. El backend guarda originales
y verifica cambios antes de instalar; puede restaurar el último respaldo.

El modo jugador no presenta herramientas del creador. Con `java -jar
Zomboid-Installer.jar --advanced` se conserva la interfaz original para casos
avanzados. `--preview HOME IMAGEN.png` genera una captura sin ventanas.
`--prepare CARPETA_RELEASE SALIDA.zip` empaqueta la distribución del creador.

Para alguien sin juego preparado se exporta un manifest Minecraft 1.21.1 /
NeoForge 21.1.255, con los archivos en overrides, para importar en CurseForge.
El usuario debe instalar CurseForge, importar ese ZIP e iniciar sesión en su
cuenta de Minecraft; no se crean credenciales ni se compra el juego.

Validar en Windows antes de distribución pública: sin Java, con Java 21,
ruta con espacios/acentos, perfil personalizado, múltiples perfiles,
paquete vacío/incompleto, falta de espacio, juego abierto, actualización de
una instancia de prueba, restauración y arranque real de cliente/modpack.

## Corrección 1.3.1: cualquier contenedor compatible

El bootstrap detecta el formato por firma binaria, sin exigir datos.zip.
Acepta carpeta datos o contenido raíz sin comprimir; ZIP, RAR, 7Z, TAR,
TAR.GZ, TAR.XZ y TAR.BZ2. Un ZIP llamado datos.izp o datos.rar sigue
tratándose como ZIP. Archivos cifrados/incompletos se detienen con diagnóstico.

Se incluye 7z.exe + 7z.dll oficiales de 7-Zip 25.01 (x64), sin modificar,
con License.txt, readme, historia y fuente pública. Se guardan en la caché
del instalador, se comprueban hashes y no se instalan en Windows.
Paquete original y fuente: https://github.com/ip7z/7zip/releases/tag/25.01
SHA-256 de 7z2501-x64.exe: 78afa2a1c773caf3cf7edf62f857d2a8a5da55fb0fff5da416074c0d28b2b55f

motor.zip incorpora la interfaz, configuración y extractor independientes
del archivo datos del usuario. Si datos contiene solo el modpack, el motor
lo integra en componentes/Contenido; si incluye el instalador completo o una
carpeta envolvente, se reconoce. No se renombra ni modifica el archivo fuente.
Archivos ZIP/JAR internos de componentes mantienen el tratamiento heredado;
los componentes del creador siguen siendo ZIP/JAR o carpetas estructuradas.

ArchiveChecks.ps1 añade 25 comprobaciones de detección por firma, ZIP con
extensiones incorrectas, carpeta normal, extracción real de 7Z, RAR5 y TAR.GZ,
rutas inseguras, archivo truncado y motor fallback. Se ejecutaron en Linux
con el mismo código PowerShell y la compilación Linux oficial de 7-Zip 25.01.
RAR de prueba: fixture test_read_format_rar5_stored.rar.uu de libarchive
(https://github.com/libarchive/libarchive). No se ejecutaron los binarios
Windows, WinRAR ni el bootstrap completo en Windows.

Para la carpeta existente del usuario, el ZIP de actualización lleva solo
scripts/guía/motor; no incluye datos.zip y no reemplaza su modpack grande.

## Corrección 1.3.2: preparar sin datos.zip

El modo creador selecciona únicamente motor.zip, sin explorar el archivo
RAR/ZIP del modpack. Carga la aplicación actual desde ese motor. PackFiles
usa motor.zip como semilla en lugar de exigir datos.zip; los componentes
se toman de Para-el-creador/componentes. Verifica los archivos auxiliares
antes de empezar. Se añadió la regresión con datos.zip eliminado: 35 checks
Java y 26 comprobaciones PowerShell/archivos pasan en Linux. La prueba de
selección confirma que el modo creador usa motor aunque haya otros archivos.

La consola del creador muestra cada segundo el tiempo y la última operación
del proceso. Java anuncia tres fases y avances en MiB para archivos grandes.
El ZIP exterior copia el ZIP interior con deflate nivel 0, sin recomprimir
gigabytes que ya están comprimidos. Se conserva el código de salida del
proceso y los archivos originales. Los binarios y bootstrap Windows siguen
pendientes de ejecución en Windows.
