param([string]$Source, [string]$SevenZip, [string]$RarFixture, [string]$Motor)
$ErrorActionPreference='Stop'
$t=$null; $errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($Source,[ref]$t,[ref]$errors)
if($errors.Count) { throw ($errors | Out-String) }
foreach($f in $ast.FindAll({param($a) $a -is [Management.Automation.Language.FunctionDefinitionAst]},$true)) { Invoke-Expression $f.Extent.Text }
function Note([string]$s) { Write-Host $s }
$script:count=0
function Check([bool]$ok,[string]$name) { if(-not $ok){throw $name};$script:count++;Write-Host ('OK '+$name) }
function Must-Fail([scriptblock]$job,[string]$name) { $failed=$false;try{& $job}catch{$failed=$true};Check $failed $name }
$work=Join-Path ([IO.Path]::GetTempPath()) ('poldo-archives-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
$script:base=$work
try {
    $data=Join-Path $work 'input';New-Item -ItemType Directory -Path (Join-Path $data 'config') -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $data 'config/poldo.txt') -Value 'real archive content'
    $zip=Join-Path $work 'datos.izp'
    [IO.Compression.ZipFile]::CreateFromDirectory($data,$zip)
    Check ((Get-ArchiveFormat $zip)-eq 'ZIP') 'ZIP detectado con extensión izp'
    $found=@(Find-Payload $work);Check ($found.Count-eq 1 -and $found[0].Path-eq $zip) 'Encuentra datos aunque no se llame datos.zip'
    $renamed=Join-Path $work 'datos.rar';Move-Item -LiteralPath $zip -Destination $renamed
    Check ((Get-ArchiveFormat $renamed)-eq 'ZIP') 'ZIP con extensión rar usa formato real'
    $extracted=Join-Path $work 'zip-output';New-Item -ItemType Directory -Path $extracted | Out-Null
    Extract-Payload $renamed 'ZIP' $extracted
    Check (Test-Path -LiteralPath (Join-Path $extracted 'config/poldo.txt')) 'ZIP se descomprime automáticamente'
    Remove-Item -LiteralPath $renamed
    $normal=Join-Path $work 'datos';New-Item -ItemType Directory -Path $normal | Out-Null
    Copy-Item -LiteralPath (Join-Path $data 'config') -Destination $normal -Recurse
    $found=@(Find-Payload $work);Check ($found[0].Format-eq 'DIRECTORY') 'Acepta carpeta datos sin comprimir'
    $copy=Join-Path $work 'normal-output';New-Item -ItemType Directory -Path $copy | Out-Null
    Extract-Payload $normal 'DIRECTORY' $copy
    Check (Test-Path -LiteralPath (Join-Path $copy 'config/poldo.txt')) 'Carpeta sin comprimir preparada automáticamente'
    Check (Test-Path -LiteralPath (Join-Path $normal 'config/poldo.txt')) 'No elimina contenido original'
    $junk=Join-Path $work 'junk.zip';Set-Content -LiteralPath $junk -Value 'not a zip'
    Check ((Get-ArchiveFormat $junk)-eq 'UNKNOWN') 'No confunde archivo dañado con ZIP'
    foreach($unsafePath in @('../escape','/absolute','C:\outside','folder\..\escape')) { Must-Fail {Assert-ArchiveName $unsafePath} ('Bloquea ruta '+$unsafePath) }
    # Override only tool discovery: exercise the shipped invocation/extraction code with
    # the official Linux 7-Zip 25.01 build on this Linux runner.
    function Find-ArchiveTool([string]$format) { return [pscustomobject]@{Path=$SevenZip;Type='7Z'} }
    $seven=Join-Path $work 'datos.7z'
    $r=Invoke-ArchiveTool $SevenZip @('a','-t7z',$seven,(Join-Path $data '*'))
    Check ($r.ExitCode-eq 0) 'Crea archivo 7Z de prueba real'
    Check ((Get-ArchiveFormat $seven)-eq '7Z') 'Detecta firma 7Z'
    $out7=Join-Path $work '7z-output';New-Item -ItemType Directory -Path $out7 | Out-Null
    Extract-Payload $seven '7Z' $out7
    Check (Test-Path -LiteralPath (Join-Path $out7 'config/poldo.txt')) '7Z se descomprime automáticamente'
    $rar=Join-Path $work 'rar-output';New-Item -ItemType Directory -Path $rar | Out-Null
    Check ((Get-ArchiveFormat $RarFixture)-eq 'RAR') 'Detecta RAR5 real'
    Extract-Payload $RarFixture 'RAR' $rar
    Check (@(Get-ChildItem -LiteralPath $rar -Recurse -File).Count-gt 0) 'RAR5 se descomprime con 7-Zip'
    $tar=Join-Path $work 'payload.tar';$gz=Join-Path $work 'payload.tar.gz'
    $r=Invoke-ArchiveTool $SevenZip @('a','-ttar',$tar,(Join-Path $data '*'));Check ($r.ExitCode-eq 0) 'Crea TAR real'
    $r=Invoke-ArchiveTool $SevenZip @('a','-tgzip',$gz,$tar);Check ($r.ExitCode-eq 0) 'Crea TAR.GZ real'
    Check ((Get-ArchiveFormat $gz)-eq 'GZIP') 'Detecta GZIP'
    $outTar=Join-Path $work 'gzip-output';New-Item -ItemType Directory -Path $outTar | Out-Null
    Extract-Payload $gz 'GZIP' $outTar
    Check (Test-Path -LiteralPath (Join-Path $outTar 'config/poldo.txt')) 'Extrae las dos capas TAR.GZ automáticamente'
    $truncated=Join-Path $work 'broken.7z';[IO.File]::WriteAllBytes($truncated,[IO.File]::ReadAllBytes($seven)[0..10])
    $brokenOut=Join-Path $work 'broken-output';New-Item -ItemType Directory -Path $brokenOut | Out-Null
    Must-Fail {Extract-Payload $truncated '7Z' $brokenOut} 'Archivo truncado detiene extracción'
    # A plain modpack need not contain the installer: supplied motor.zip fills the gap.
    Copy-Item -LiteralPath $Motor -Destination (Join-Path $work 'motor.zip')
    $startup=@(Get-StartupPayload $work -Creator)
    Check ($startup.Count-eq 1 -and $startup[0].Path-eq (Join-Path $work 'motor.zip')) 'Modo creador no elige RAR ni exige datos.zip'
    $stage=Join-Path $work 'fallback-stage';New-Item -ItemType Directory -Path $stage | Out-Null
    $ready=Resolve-InstallerContent $data $stage $work
    Check (Test-Path -LiteralPath (Join-Path $ready 'Zomboid-Installer.jar')) 'Motor incorporado para archivos de solo contenido'
    Check (Test-Path -LiteralPath (Join-Path $ready 'componentes/Contenido/config/poldo.txt')) 'Integra mods/config con motor sin alterar original'
    $nested=Join-Path $work 'nested';New-Item -ItemType Directory -Path (Join-Path $nested 'wrapper/pack') -Force | Out-Null
    Set-Content (Join-Path $nested 'wrapper/Zomboid-Installer.jar') 'fixture'
    Set-Content (Join-Path $nested 'wrapper/pack/pack.json') '{}'
    Check ((Resolve-InstallerContent $nested $stage $work)-eq (Join-Path $nested 'wrapper')) 'Acepta instalador dentro de una carpeta envolvente'
    Write-Host ('PASSED '+$script:count+' archive checks; Windows binaries not executed.')
} finally { Remove-Item -LiteralPath $work -Recurse -Force }
