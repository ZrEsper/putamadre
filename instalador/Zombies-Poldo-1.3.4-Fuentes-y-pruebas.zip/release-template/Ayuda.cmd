@echo off
cd /d "%~dp0"
set "poldoPrefs=%TEMP%\ZombiesPoldo\language.txt"
if defined LOCALAPPDATA set "poldoPrefs=%LOCALAPPDATA%\ZombiesPoldo\language.txt"
if not exist "%poldoPrefs%" goto spanish
findstr /x /c:"en" "%poldoPrefs%" >nul
if not errorlevel 1 goto english
findstr /x /c:"de" "%poldoPrefs%" >nul
if not errorlevel 1 goto german
:spanish
set "poldoGuide=GUIA.html"
set "poldoRepair=Cierra el instalador. Se limpiara solo su cache; mundos y respaldos se conservan."
set "poldoConfirm=Continuar? S/N: "
set "poldoKeys=SN"
echo ZOMBIES POLDO - AYUDA
echo 1. Abrir guia facil
echo 2. Abrir registros
echo 3. Abrir instalador con diagnostico
echo 4. Reparar cache del instalador
goto choose
:english
set "poldoGuide=GUIA-en.html"
set "poldoRepair=Close the installer. Only its cache will be cleared; worlds and backups are kept."
set "poldoConfirm=Continue? Y/N: "
set "poldoKeys=YN"
echo ZOMBIES POLDO - HELP
echo 1. Open easy guide
echo 2. Open logs
echo 3. Open installer with diagnostics
echo 4. Repair installer cache
goto choose
:german
set "poldoGuide=GUIA-de.html"
set "poldoRepair=Installer schliessen. Nur sein Cache wird geleert; Welten und Sicherungen bleiben erhalten."
set "poldoConfirm=Fortfahren? J/N: "
set "poldoKeys=JN"
echo ZOMBIES POLDO - HILFE
echo 1. Einfache Anleitung oeffnen
echo 2. Protokolle oeffnen
echo 3. Installer mit Diagnose oeffnen
echo 4. Installer-Cache reparieren
:choose
choice /c 1234 /n /m "1 / 2 / 3 / 4: "
if errorlevel 4 goto repair
if errorlevel 3 goto debug
if errorlevel 2 goto logs
start "" "%~dp0%poldoGuide%"
exit /b
:logs
if defined LOCALAPPDATA (explorer "%LOCALAPPDATA%\ZombiesPoldo") else (explorer "%TEMP%\ZombiesPoldo")
exit /b
:debug
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Abrir-Instalador.ps1" -Debug
exit /b
:repair
echo %poldoRepair%
choice /c %poldoKeys% /n /m "%poldoConfirm%"
if errorlevel 2 exit /b
powershell.exe -NoProfile -Command "$b = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'ZombiesPoldo' } else { Join-Path $env:TEMP 'ZombiesPoldo' }; foreach ($n in @('paquetes','extractor-7zip-25.01')) { $p = Join-Path $b $n; if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Recurse -Force } }"
pause
