@echo off
cd /d "%~dp0"
echo ZOMBIES POLDO - Cargando / Loading / Laden...
echo Español / English / Deutsch
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Abrir-Instalador.ps1"
if errorlevel 1 (
 echo Error / Fehler: Ayuda.cmd
 pause
)
