package dev.zomboid.installer;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Stream;

/** Bounded discovery: no drive scans, no credential reads, no silent target choice. */
public final class LauncherDiscovery {
    public record Target(Path path, String launcher, String name) {
        @Override public String toString() { return launcher + " · " + name + " — " + path; }
    }
    private final Path user, appData, localData;
    private final Consumer<String> log;
    private final Map<Path, Target> targets = new LinkedHashMap<>();
    public LauncherDiscovery(Path user, Path appData, Path localData, Consumer<String> log) {
        this.user=user; this.appData=appData; this.localData=localData; this.log=log;
    }
    public static LauncherDiscovery current(Consumer<String> log) {
        Path home=Path.of(System.getProperty("user.home"));
        return new LauncherDiscovery(home, env("APPDATA", home.resolve("AppData/Roaming")),
            env("LOCALAPPDATA", home.resolve("AppData/Local")), log);
    }
    private static Path env(String key, Path fallback) {
        String s=System.getenv(key); return s==null || s.isBlank() ? fallback : Path.of(s);
    }
    public List<Target> discover() {
        targets.clear();
        for(Path p: List.of(user.resolve("curseforge/minecraft"), user.resolve("Documents/CurseForge/Minecraft"),
            user.resolve("Documents/curseforge/minecraft"), appData.resolve("CurseForge/Minecraft"),
            localData.resolve("CurseForge/Minecraft"))) curseRoot(p);
        for(Path root: List.of(appData.resolve("CurseForge"), localData.resolve("CurseForge"),
            appData.resolve("Overwolf/Extensions/cchhcaiapeikjbdbpfplgmpobbcdkdaphclbmkbj"))) {
            if(!Files.isDirectory(root)) continue;
            try(Stream<Path> s=Files.walk(root,3)) {
                for(Path p:s.filter(Files::isRegularFile).filter(p-> {
                    String n=p.getFileName().toString().toLowerCase(Locale.ROOT);
                    return n.contains("minecraft") && (n.endsWith(".json") || n.endsWith(".settings"));
                }).limit(50).toList()) settings(p);
            } catch(IOException e) { log.accept("Detección CurseForge: " + e.getMessage()); }
        }
        for(Path p:List.of(user.resolve(".tlauncher/tlauncher-2.0.properties"),
            appData.resolve(".tlauncher/tlauncher-2.0.properties"), appData.resolve(".minecraft/tlauncher-2.0.properties"))) {
            if(!Files.isRegularFile(p)) continue;
            try(InputStream in=Files.newInputStream(p)) {
                Properties props=new Properties(); props.load(in);
                String dir=props.getProperty("minecraft.gamedir");
                if(dir!=null && !dir.isBlank()) add(normalizeConfigured(dir,p.getParent()), "TLauncher", "Minecraft");
            } catch(Exception e) { log.accept("No se pudo leer ubicación de TLauncher: " + e.getMessage()); }
        }
        for(Path p:List.of(appData.resolve(".minecraft"), user.resolve(".minecraft"))) {
            if(Files.isDirectory(p.resolve("versions")) || Files.isRegularFile(p.resolve("launcher_profiles.json"))) {
                add(p,"Minecraft / TLauncher","Carpeta principal");
                profileDirs(p.resolve("launcher_profiles.json"));
                profileDirs(p.resolve("TLauncherProfiles.json"));
            }
        }
        return targets.values().stream().sorted(Comparator.comparing((Target t)->!t.name().toLowerCase(Locale.ROOT).contains("poldo"))
            .thenComparing(Target::launcher).thenComparing(Target::name)).toList();
    }
    private void curseRoot(Path p) {
        Path instances=p.getFileName()!=null && p.getFileName().toString().equalsIgnoreCase("Instances") ? p : p.resolve("Instances");
        if(!Files.isDirectory(instances)) return;
        try(Stream<Path> s=Files.list(instances)) {
            for(Path child:s.filter(Files::isDirectory).limit(300).toList())
                if(Files.isRegularFile(child.resolve("minecraftinstance.json"))) add(child,"CurseForge", child.getFileName().toString());
        } catch(IOException e) { log.accept("No se pudieron listar perfiles: " + e.getMessage()); }
    }
    private void settings(Path p) {
        try {
            if(Files.size(p)>2_000_000) return;
            visitSettings(Json.parse(Files.readString(p)),p.getParent());
        } catch(Exception e) { log.accept("Ajustes de ubicación no legibles: " + p.getFileName()); }
    }
    private void visitSettings(Object node,Path base) {
        if(node instanceof Map<?,?> m) for(var e:m.entrySet()) {
            String k=String.valueOf(e.getKey()).toLowerCase(Locale.ROOT);
            if(e.getValue() instanceof String v && Set.of("moddingfolder","minecraftmoddingfolder","minecraftmoddingpath",
                "gameinstancespath","instancespath","installpath","minecraftpath","gamedirectory","gamedir").contains(k)) {
                try { curseRoot(normalizeConfigured(v,base)); } catch(RuntimeException ignored) { }
            } else if(e.getValue() instanceof Map<?,?> || e.getValue() instanceof List<?>) visitSettings(e.getValue(),base);
        } else if(node instanceof List<?> l) for(Object v:l) visitSettings(v,base);
    }
    private Path normalizeConfigured(String s,Path base) {
        s=s.replace("%USERPROFILE%",user.toString()).replace("%APPDATA%",appData.toString()).replace("%LOCALAPPDATA%",localData.toString());
        Path p=Path.of(s); return (p.isAbsolute()?p:base.resolve(p)).normalize();
    }
    private void profileDirs(Path file) {
        if(!Files.isRegularFile(file)) return;
        try {
            if(Files.size(file)>2_000_000) return;
            Map<String,Object> root=Json.object(Json.parse(Files.readString(file)));
            Object profiles=root.get("profiles");
            if(profiles instanceof Map<?,?> m) for(Object val:m.values()) if(val instanceof Map<?,?> v && v.get("gameDir") instanceof String dir)
                add(normalizeConfigured(dir,file.getParent()),"Minecraft / TLauncher",Objects.toString(v.get("name"),"Perfil separado"));
        } catch(Exception e) { log.accept("Perfiles de Minecraft no legibles; se conserva la selección manual."); }
    }
    private void add(Path p,String launcher,String name) {
        try {
            if(!Files.isDirectory(p)) return;
            Path real=p.toRealPath();
            targets.putIfAbsent(real,new Target(real,launcher,name));
            log.accept("Carpeta detectada: " + launcher + " | " + real);
        } catch(IOException e) { log.accept("Ubicación inaccesible: " + p); }
    }
    public static Path resolveManual(Path p) throws IOException {
        p=p.toAbsolutePath().normalize();
        if(!Files.isDirectory(p)) throw new IOException("Esa carpeta no existe. Usa ‘Elegir otra carpeta’.");
        if(Files.isDirectory(p.resolve(".minecraft"))) p=p.resolve(".minecraft");
        if(!Files.isRegularFile(p.resolve("minecraftinstance.json")) && !Files.isDirectory(p.resolve("versions"))
            && !Files.isRegularFile(p.resolve("launcher_profiles.json")) && !Files.isRegularFile(p.resolve("mmc-pack.json"))
            && !(p.getParent()!=null && Files.isRegularFile(p.getParent().resolve("mmc-pack.json"))))
            throw new IOException("Parece una carpeta general, no un perfil del juego. En CurseForge: perfil → ⋮ → Abrir carpeta. En TLauncher: pulsa el icono de carpeta y elige esa ubicación.");
        return p.toRealPath();
    }
}
