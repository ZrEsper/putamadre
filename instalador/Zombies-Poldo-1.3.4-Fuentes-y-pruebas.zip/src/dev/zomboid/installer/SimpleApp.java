package dev.zomboid.installer;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.List;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.*;

/** Beginner-facing shell; preserves the original transactional installation engine. */
public final class SimpleApp {
    private final Path home, release;
    private final Diagnostics diag;
    private final Horror.Audio audio=new Horror.Audio();
    private final JPanel panel;
    private final JComboBox<LauncherDiscovery.Target> targets=new JComboBox<>();
    private final JLabel status=new I18n.Label("Buscando tu juego…"), subtitle=new I18n.Label("No tienes que descomprimir los mods ni el mapa.");
    private final JTextArea details=new I18n.TextArea();
    private final JProgressBar progress=new JProgressBar();
    private final JButton scan=new I18n.Button("Buscar de nuevo"), browse=new I18n.Button("Elegir otra carpeta"), check=new I18n.Button("Continuar"), install=new I18n.Button("Instalar ahora"),
        fresh=new I18n.Button("No tengo Minecraft preparado"), cf=new I18n.Button("Preparar ZIP para CurseForge"), restore=new I18n.Button("Deshacer última instalación");
    private final JLabel title=new I18n.Label("PREPARA TU REFUGIO");
    private Engine.Pack pack;
    private Engine.Plan plan;
    private boolean busy, finished;
    private JFrame frame;

    public SimpleApp(Path home,Path release) throws IOException {
        this.home=home; this.release=release; this.diag=new Diagnostics(home);
        String local=System.getenv("LOCALAPPDATA");
        Path settings=Path.of(local==null?System.getProperty("java.io.tmpdir"):local,"ZombiesPoldo","language.txt");
        I18n.initialize(settings);
        this.panel=new Horror.Scene(new BorderLayout(24,24));
        panel.setBorder(new EmptyBorder(30,32,26,32));
        JPanel rail=column(); rail.setPreferredSize(new Dimension(220,400));
        rail.add(label("ZOMBIES",30,App.TEXT)); rail.add(label("POLDO",30,App.TEXT)); rail.add(Box.createVerticalStrut(12));
        rail.add(label("SEÑAL ENCONTRADA",11,App.RED)); rail.add(Box.createVerticalStrut(16));
        rail.add(label("Idioma / Language / Sprache",10,App.MUTED));
        JComboBox<String> languages=new JComboBox<>(new String[]{"Español","English","Deutsch"});
        languages.setSelectedIndex(I18n.language().equals("en")?1:I18n.language().equals("de")?2:0);
        languages.setBackground(App.CARD);languages.setForeground(App.TEXT);languages.setMaximumSize(new Dimension(220,34));
        languages.addActionListener(e->{I18n.setLanguage(new String[]{"es","en","de"}[languages.getSelectedIndex()],true);if(frame!=null)frame.setTitle(I18n.text("Zombies Poldo · Instalar y jugar"));panel.revalidate();panel.repaint();});
        rail.add(languages);rail.add(Box.createVerticalStrut(24));
        rail.add(label("01  Elige tu juego",15,App.TEXT)); rail.add(Box.createVerticalStrut(20));
        rail.add(label("02  Comprobamos",15,App.TEXT)); rail.add(Box.createVerticalStrut(20));
        rail.add(label("03  Instala y juega",15,App.TEXT)); rail.add(Box.createVerticalGlue());
        JButton guide=button("Guía fácil",false); guide.addActionListener(e->guide()); rail.add(guide); rail.add(Box.createVerticalStrut(10));
        JButton logs=button("Enviar diagnóstico",false); logs.addActionListener(e->support()); rail.add(logs); rail.add(Box.createVerticalStrut(10));
        JButton sound=button("Sonido",false); sound.addActionListener(e->{audio.toggle();}); rail.add(sound);
        panel.add(rail,BorderLayout.WEST);
        JPanel center=column(); title.setFont(App.font(29,true)); title.setForeground(App.TEXT); center.add(title);
        center.add(Box.createVerticalStrut(10)); subtitle.setForeground(App.MUTED); center.add(subtitle); center.add(Box.createVerticalStrut(24));
        center.add(label("¿DÓNDE VAS A JUGAR?",13,App.RED)); center.add(Box.createVerticalStrut(12));
        targets.setFont(App.font(13,false)); targets.setBackground(App.CARD); targets.setForeground(App.TEXT);
        targets.setMaximumSize(new Dimension(Integer.MAX_VALUE,44)); targets.setPreferredSize(new Dimension(620,44));
        targets.setRenderer(new DefaultListCellRenderer(){
            @Override public Component getListCellRendererComponent(JList<?> list,Object value,int index,boolean selected,boolean focus) {
                super.getListCellRendererComponent(list,value,index,selected,focus);
                if(value instanceof LauncherDiscovery.Target t) { setText(t.launcher()+" · "+t.name()); setToolTipText(t.path().toString()); }
                setBackground(selected?App.LINE:App.CARD); setForeground(App.TEXT); setBorder(new EmptyBorder(8,10,8,10)); return this;
            }
        });
        center.add(targets); center.add(Box.createVerticalStrut(10));
        center.add(App.row(style(scan,false),style(browse,false))); center.add(Box.createVerticalStrut(14));
        center.add(style(fresh,false)); center.add(Box.createVerticalStrut(6)); center.add(style(cf,false)); cf.setVisible(false);
        center.add(Box.createVerticalStrut(12));
        details.setEditable(false); details.setLineWrap(true); details.setWrapStyleWord(true); details.setFont(App.font(14,false));
        details.setBackground(App.CARD); details.setForeground(App.TEXT); details.setBorder(new EmptyBorder(14,14,14,14));
        details.setText("Elige el perfil que vas a usar. Si aparecen varios, no elegimos por ti.\n\nCierra Minecraft antes de instalar. Tus archivos originales se guardarán en un respaldo.");
        JScrollPane scroll=new JScrollPane(details); scroll.setBorder(new LineBorder(App.LINE)); scroll.setPreferredSize(new Dimension(620,190));
        center.add(Box.createVerticalStrut(12)); center.add(scroll); center.add(Box.createVerticalStrut(12));
        progress.setForeground(App.RED); progress.setBackground(App.LINE); progress.setMaximumSize(new Dimension(Integer.MAX_VALUE,8)); center.add(progress);
        center.add(Box.createVerticalStrut(10)); status.setForeground(App.MUTED); center.add(status); center.add(Box.createVerticalStrut(12));
        install.setVisible(false); restore.setVisible(false);
        center.add(App.row(style(check,true),style(install,true),style(restore,false))); panel.add(center,BorderLayout.CENTER);
        scan.addActionListener(e->discover()); browse.addActionListener(e->browse()); check.addActionListener(e->review()); install.addActionListener(e->install());
        targets.addActionListener(e->invalidate());
        fresh.addActionListener(e->{cf.setVisible(true); details.setText("RECOMENDADO: CURSEFORGE\n\n1. Instala CurseForge desde su web oficial (botón ‘Guía fácil’).\n2. Aquí pulsa ‘Preparar ZIP para CurseForge’.\n3. En CurseForge: Minecraft → Crear perfil → Importar. Elige ese ZIP.\n4. CurseForge descargará Minecraft 1.21.1 y NeoForge. Abre ZOMBIES POLDO y pulsa Jugar.\n\nPara jugar necesitarás tu cuenta de Minecraft Java.\n\n¿Usas TLauncher? La guía muestra cómo preparar la versión correcta y volver a este instalador.");});
        cf.addActionListener(e->exportCF()); restore.addActionListener(e->restore());
        for(JPanel p:List.of(rail,center)) for(Component child:p.getComponents()) if(child instanceof JComponent c) c.setAlignmentX(Component.LEFT_ALIGNMENT);
    }
    private static JPanel column() { JPanel p=new JPanel(); p.setOpaque(false); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS)); return p; }
    private static JLabel label(String s,int size,Color c) { JLabel l=new I18n.Label(s);l.setFont(App.font(size,true));l.setForeground(c);return l; }
    private static JButton style(JButton b,boolean main) { App.button(b,main); return b; }
    private static JButton button(String s,boolean main) { return style(new I18n.Button(s),main); }
    private void invalidate() { plan=null; install.setEnabled(false); install.setVisible(false); finished=false; check.setVisible(true); }
    private void discover() {
        run("Buscando carpetas de CurseForge y TLauncher…",()->LauncherDiscovery.current(diag::event).discover(),list->{
            targets.removeAllItems(); for(var t:list) targets.addItem(t);
            // Require an explicit choice whenever there is more than one candidate.
            targets.setSelectedIndex(list.size()==1?0:-1);
            status.setText(list.isEmpty()?"No encontramos un perfil. Puedes preparar uno con la guía.":list.size()+" carpeta(s) encontrada(s). Confirma cuál quieres usar.");
            if(list.size()>1) details.setText("Encontramos varios perfiles. Abre la lista y elige el que vas a usar.\n\nLa carpeta completa aparece al dejar el ratón sobre el perfil. No se instalará nada hasta que pulses ‘Instalar ahora’.");
        });
    }
    private void browse() {
        JFileChooser chooser=new JFileChooser(); chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); chooser.setDialogTitle(I18n.text("Elige la carpeta que abre tu launcher"));
        if(chooser.showOpenDialog(frame)!=JFileChooser.APPROVE_OPTION) return;
        try {
            Path p=LauncherDiscovery.resolveManual(chooser.getSelectedFile().toPath());
            var t=new LauncherDiscovery.Target(p,Files.isRegularFile(p.resolve("minecraftinstance.json"))?"CurseForge":"Minecraft / TLauncher",p.getFileName().toString());
            targets.addItem(t); targets.setSelectedItem(t); diag.event("Selección manual: "+p);
        } catch(Exception e) { error(e); }
    }
    private void review() {
        var t=(LauncherDiscovery.Target)targets.getSelectedItem();
        if(t==null) { error(new IOException("Elige tu juego en la lista. Si no aparece, pulsa ‘No tengo Minecraft preparado’ o ‘Elegir otra carpeta’.")); return; }
        invalidate();
        run("Descomprimiendo y comprobando el contenido…",()->{
            Path path=LauncherDiscovery.resolveManual(t.path());
            if(pack==null) pack=PackFiles.load(home,this::reportProgress);
            long required=pack.files().stream().mapToLong(Engine.Entry::size).sum();
            long available=Files.getFileStore(path).getUsableSpace(); diag.event("Espacio disponible: "+available+"; contenido: "+required);
            if(available<required*2+64*1024*1024) throw new IOException("No queda suficiente espacio. Libera espacio en el disco del juego y vuelve a intentar.");
            reportProgress("Preparación: comprobando versiones y destinos de los archivos…");
            return InstallWorkflow.review(pack,path,this::reportProgress);
        },p->{
            plan=p; diag.review(p);
            StringBuilder text=new StringBuilder("Carpeta: "+p.instance()+"\n\n");
            if(p.allowed()) text.append("TODO LISTO\nMods y mapa preparados automáticamente.\nSe guardarán los originales antes de cambiar archivos.\n\nPulsa ‘Instalar ahora’. Mantén Minecraft cerrado hasta que termine.\n");
            else text.append("FALTA UN PASO\n");
            for(var c:p.checks()) if(!c.good() || c.group().contains("Aviso")) text.append("\n").append(c.title()).append(": ").append(c.detail()).append("\n");
            if(!p.allowed() && p.checks().stream().anyMatch(c->!c.good() && (c.group().equals("Minecraft") || c.group().equals("NeoForge")))) {
                text.append("\nCurseForge: usa ‘No tengo Minecraft preparado’ para importar un perfil con las versiones correctas.\nTLauncher: abre la guía, prepara NeoForge 21.1.255 para Minecraft 1.21.1 y vuelve a buscar.\n");
            }
            details.setText(text.toString()); details.setCaretPosition(0); install.setVisible(plan!=null&&p.allowed()); install.setEnabled(plan!=null&&p.allowed());
            status.setText(plan!=null&&p.allowed()?"Comprobación terminada. Ya puedes instalar.":"Sigue la indicación de arriba. No se han cambiado archivos del juego.");
        });
    }
    private void install() {
        if(plan==null || !plan.allowed()) return;
        Engine.Plan selected=plan;
        run("Guardando respaldo e instalando…",()->InstallWorkflow.install(selected,this::reportProgress),backup->{
            finished=true; plan=null; title.setText("TU REFUGIO ESTÁ LISTO"); subtitle.setText("Instalación completada. Ya puedes abrir el juego.");
            details.setText("¡LISTO!\n\nCurseForge: abre el perfil que elegiste y pulsa Jugar.\nTLauncher: selecciona NeoForge 21.1.255 / Minecraft 1.21.1 y pulsa Entrar al juego.\n\nSi el pack incluye un mapa, lo encontrarás en Un jugador.\n\nRespaldo guardado en:\n"+backup+"\n\nSi el juego falla al arrancar, pulsa ‘Enviar diagnóstico’. Los logs no se envían solos.");
            progress.setValue(100); status.setText("Instalación completada con respaldo."); install.setVisible(false); check.setVisible(false); restore.setVisible(true);
        });
    }
    private void exportCF() {
        JFileChooser chooser=new JFileChooser(); chooser.setDialogTitle(I18n.text("Guardar el ZIP que importarás en CurseForge")); chooser.setSelectedFile(new File("ZOMBIES-POLDO-CurseForge.zip"));
        if(chooser.showSaveDialog(frame)!=JFileChooser.APPROVE_OPTION) return;
        Path out=chooser.getSelectedFile().toPath().toAbsolutePath();
        if(Files.exists(out)) { error(new IOException("Ese ZIP ya existe. Elige otro nombre para conservarlo.")); return; }
        run("Preparando tu perfil automático…",()->{ if(pack==null) pack=PackFiles.load(home,this::reportProgress); return PackFiles.exportCurseForge(pack,out); },p->{
            diag.event("Perfil CurseForge exportado: "+p); details.setText("ZIP PREPARADO\n\n1. Abre CurseForge y entra en Minecraft.\n2. Pulsa Crear perfil → Importar.\n3. Elige este archivo:\n"+p+"\n4. Espera la descarga y pulsa Jugar en ZOMBIES POLDO.\n\nEl ZIP incluye los mods y el mapa. CurseForge prepara Minecraft y NeoForge; no tienes que copiarlos a mano.");
            status.setText("ZIP listo para importar en CurseForge."); open(p.getParent());
        });
    }
    private void restore() {
        var t=(LauncherDiscovery.Target)targets.getSelectedItem(); if(t==null) return;
        if(JOptionPane.showConfirmDialog(frame,I18n.text("¿Deshacer la última instalación en esta carpeta?\n"+t.path()+"\nSe conservarán los archivos que hayas cambiado después."),I18n.text("Volver al respaldo"),JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION) return;
        run("Restaurando el respaldo…",()->{Engine.restoreLatest(t.path());return t.path();},p->{invalidate(); restore.setVisible(false); title.setText("RESPALDO RESTAURADO"); details.setText("Se restauraron los archivos originales. Puedes volver a comprobar el pack.");});
    }
    private <T> void run(String message,Callable<T> job,Consumer<T> done) {
        if(busy) return; busy=true; enable(false); progress.setIndeterminate(true); status.setText(message); diag.event(message);
        new SwingWorker<T,Void>() {
            @Override protected T doInBackground() throws Exception { return job.call(); }
            @Override protected void done() {
                busy=false; progress.setIndeterminate(false); enable(true);
                try { done.accept(get()); } catch(Exception e) { Throwable cause=e.getCause()!=null?e.getCause():e; error(cause); }
            }
        }.execute();
    }
    private void enable(boolean yes) { for(Component c:List.of(targets,scan,browse,check,install,fresh,cf,restore)) c.setEnabled(yes); if(yes) install.setEnabled(plan!=null&&plan.allowed()); }
    private void reportProgress(String message) {
        diag.event(message);
        SwingUtilities.invokeLater(()->{
            status.setText(message);
            status.setToolTipText(I18n.text(message));
            if(message.startsWith("Paso ")) title.setText(message.startsWith("Paso 1/")?"01 · PREPARANDO RESPALDO":message.startsWith("Paso 2/")?"02 · INSTALANDO ARCHIVOS":"03 · COMPROBANDO");
        });
    }
    private void error(Throwable e) {
        diag.error("Operación detenida",e); diag.event("El jugador puede reintentar tras corregir el problema.");
        details.setText("VAMOS PASO A PASO\n\n"+Objects.toString(e.getMessage(),e.toString())+"\n\nPulsa ‘Guía fácil’ para ver los pasos. Si necesitas ayuda, ‘Enviar diagnóstico’ prepara el informe.");
        details.setCaretPosition(0); status.setText("Operación detenida. Revisa la indicación de arriba.");
    }
    private void guide() { open(release.resolve(I18n.language().equals("es")?"GUIA.html":"GUIA-"+I18n.language()+".html")); }
    private void support() {
        try {
            Path out=diag.folder().resolve("LEEME-PARA-SOPORTE.txt");
            Files.writeString(out,I18n.text("ZOMBIES POLDO — AYUDA\n\nEnvía esta carpeta a quien te pasó el pack. No se envía nada automáticamente.\nLos registros incluyen rutas locales y pueden incluir tu nombre de usuario.\n\n"+diag.report()));
            var t=(LauncherDiscovery.Target)targets.getSelectedItem();
            if(t!=null && Files.isRegularFile(t.path().resolve("logs/latest.log"))) Files.copy(t.path().resolve("logs/latest.log"),diag.folder().resolve("minecraft-latest.log"),StandardCopyOption.REPLACE_EXISTING);
            open(diag.folder());
        } catch(Exception e) { error(e); }
    }
    private void open(Path p) { try { Desktop.getDesktop().open(p.toFile()); } catch(Exception e) { diag.error("Abrir archivo o carpeta",e); JOptionPane.showMessageDialog(frame,I18n.text("Abre esta ubicación:\n"+p)); } }
    public static void main(String[] args) throws Exception {
        Path home=Path.of(SimpleApp.class.getProtectionDomain().getCodeSource().getLocation().toURI()).toAbsolutePath().getParent();
        Path release=System.getenv("POLDO_RELEASE_DIR")==null?home:Path.of(System.getenv("POLDO_RELEASE_DIR"));
        if(args.length>0 && args[0].equals("--advanced")) { App.main(new String[0]); return; }
        if(args.length>0 && args[0].equals("--prepare")) {
            Path base=Path.of(args[1]).toAbsolutePath();
            System.out.println(PackFiles.prepare(base,base.resolve("Para-el-creador/componentes"),Path.of(args[2]).toAbsolutePath(),System.out::println)); return;
        }
        if(args.length>0 && args[0].equals("--preview")) {
            System.setProperty("java.awt.headless","true");
            SwingUtilities.invokeAndWait(()->{try {
                SimpleApp app=new SimpleApp(Path.of(args[1]),Path.of(args[1])); if(args.length>3)I18n.setLanguage(args[3],false); app.status.setText("Elige tu perfil. El instalador se encarga del contenido.");
                app.targets.addItem(new LauncherDiscovery.Target(Path.of("C:/Users/Jugador/curseforge/minecraft/Instances/ZOMBIES POLDO"),"CurseForge","ZOMBIES POLDO"));
                app.panel.setSize(1040,760); layout(app.panel); BufferedImage image=new BufferedImage(1040,760,BufferedImage.TYPE_INT_RGB);
                Graphics2D g=image.createGraphics();app.panel.paint(g);g.dispose();ImageIO.write(image,"png",Path.of(args[2]).toFile());
            }catch(Exception e){throw new RuntimeException(e);}}); return;
        }
        final Path appHome=home,appRelease=release;
        Thread.setDefaultUncaughtExceptionHandler((t,e)->{try { new Diagnostics(appHome).error("Error no controlado en "+t.getName(),e); }catch(IOException ignored){e.printStackTrace();}});
        SwingUtilities.invokeLater(()->{try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            SimpleApp app=new SimpleApp(appHome,appRelease); JFrame f=new JFrame(I18n.text("Zombies Poldo · Instalar y jugar")); app.frame=f;
            f.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE); f.addWindowListener(new WindowAdapter(){@Override public void windowClosing(WindowEvent e){if(app.busy){JOptionPane.showMessageDialog(f,I18n.text("Espera a que termine para cerrar."));return;} app.audio.close();f.dispose();}});
            f.setContentPane(app.panel); f.setMinimumSize(new Dimension(960,700)); f.setSize(1080,790); f.setLocationRelativeTo(null); f.setVisible(true); app.audio.start(appHome); app.discover();
        }catch(Exception e){e.printStackTrace();JOptionPane.showMessageDialog(null,I18n.text("No se pudo abrir. Usa Ayuda.cmd.\n"+e.getMessage()));System.exit(1);}});
    }
    private static void layout(Container c) { c.doLayout(); for(Component child:c.getComponents()) if(child instanceof Container nested) layout(nested); }
}
