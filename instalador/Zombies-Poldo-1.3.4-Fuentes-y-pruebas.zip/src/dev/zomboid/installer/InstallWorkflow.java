package dev.zomboid.installer;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Stream;

/** Global datapack routing, retaining the supplied engine's transactional backup. */
public final class InstallWorkflow {
    private static boolean paxiName(String name) { return name.toLowerCase(Locale.ROOT).matches("paxi(?:[-_].*)?\\.jar"); }
    public static boolean hasPaxi(Engine.Pack pack,Path instance) throws IOException {
        if(pack.files().stream().anyMatch(e->e.path().startsWith("mods/") && paxiName(Path.of(e.path()).getFileName().toString()))) return true;
        if(instance!=null && Files.isDirectory(instance.resolve("mods"))) try(Stream<Path> s=Files.list(instance.resolve("mods"))) {
            return s.anyMatch(p->Files.isRegularFile(p) && paxiName(p.getFileName().toString()));
        }
        return false;
    }
    public static String destination(String source,boolean paxi) throws IOException {
        source=Engine.safeName(source);
        return source.startsWith("datapacks/") && paxi ? "config/paxi/"+source : source;
    }
    public static Engine.Plan review(Engine.Pack pack,Path instance,Consumer<String> log) throws IOException {
        Engine.Plan original=Engine.review(pack,instance,List.of(),log);
        boolean paxi=hasPaxi(pack,instance);
        List<Engine.Check> checks=new ArrayList<>(original.checks().stream().filter(c->!(c.group().equals("datapacks") && c.detail().startsWith("Pendiente:")) && !(c.group().equals("Shaders") && c.good())).toList());
        Map<String,Engine.Copy> copies=new LinkedHashMap<>();
        for(Engine.Copy c:original.copies()) copies.put(c.relative(),c);
        Map<String,String> hashes=new HashMap<>();
        for(Engine.Entry e:pack.files()) if(!e.path().startsWith("datapacks/")) hashes.put(e.path(),e.sha256());
        for(Engine.Entry e:pack.files()) if(e.path().startsWith("datapacks/") || e.path().startsWith("shaderpacks/")) {
            String group=e.path().substring(0,e.path().indexOf('/'));
            String relative=destination(e.path(),paxi);
            String old=hashes.putIfAbsent(relative,e.sha256());
            if(old!=null && !old.equals(e.sha256())) { checks.add(new Engine.Check(group,relative,"Dos archivos distintos tienen el mismo destino; conserva una sola versión.",false)); continue; }
            Path source=pack.root().resolve(Engine.safeName(e.path()));
            if(!Files.isRegularFile(source) || !Engine.sha(source).equals(e.sha256())) { checks.add(new Engine.Check(group,e.path(),"Archivo ausente o dañado.",false));continue; }
            Path target=instance.resolve(relative);
            for(Path p=target;p!=null && p.startsWith(instance);p=p.getParent()) if(Files.isSymbolicLink(p)) throw new IOException("Enlace no permitido: "+p);
            boolean same=Files.isRegularFile(target) && Engine.sha(target).equals(e.sha256());
            if(!same) copies.putIfAbsent(relative,new Engine.Copy(source,relative,e.sha256()));
            checks.add(new Engine.Check(group,relative,same?"Correcto · ya instalado":(e.path().startsWith("shaderpacks/")?"Instalar en shaderpacks del perfil.":paxi?"Instalar para Paxi; no requiere seleccionar un mundo.":"Instalar en datapacks del perfil; no requiere seleccionar un mundo."),true));
            log.accept("Destino: "+e.path()+" → "+relative);
        }
        return new Engine.Plan(original.instance(),original.pack(),List.copyOf(checks),List.copyOf(copies.values()),original.obsolete(),original.fingerprint());
    }
    public static Path install(Engine.Plan plan,Consumer<String> log) throws IOException {
        log.accept("Paso 1/3: preparando archivos y respaldando los originales…");
        int[] current={0};
        Path backup=Engine.install(plan,true,message->{
            if(message.equals("Instalando options.txt")) log.accept("Paso 2/3: aplicando teclas y ajustes del pack…");
            else if(message.startsWith("Instalando ")) log.accept("Paso 2/3: archivo "+(++current[0])+" de "+plan.copies().size()+" · "+message.substring(11));
            else log.accept("Paso 1/3: "+message);
        });
        log.accept("Paso 3/3: comprobando los archivos instalados…");
        for(Engine.Copy copy:plan.copies()) if(!Engine.sha(plan.instance().resolve(Engine.safeName(copy.relative()))).equals(copy.sha()))
            throw new IOException("La comprobación final falló: "+copy.relative()+". Conserva el respaldo: "+backup);
        log.accept("Paso 3/3: comprobación terminada.");
        return backup;
    }
}
