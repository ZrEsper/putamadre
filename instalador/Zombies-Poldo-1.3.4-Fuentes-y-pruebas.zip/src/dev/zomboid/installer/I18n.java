package dev.zomboid.installer;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.lang.ref.WeakReference;
import javax.swing.*;

/** Spanish is the stable source language; paths and file names never change. */
public final class I18n {
    private static volatile String language="es";
    private static Path preference;
    private static final Map<String,Map<String,String>> catalogs=new HashMap<>();
    private static final List<WeakReference<Localized>> views=new ArrayList<>();
    interface Localized {void refresh();}
    static {
        for(String code:List.of("en","de")) try(InputStream in=I18n.class.getResourceAsStream("/lang/"+code+".json")) {
            if(in==null) throw new IOException("Missing language catalog: "+code);
            Map<String,String> map=new LinkedHashMap<>();
            Json.object(Json.parse(new String(in.readAllBytes(),StandardCharsets.UTF_8))).forEach((k,v)->map.put(k,String.valueOf(v)));
            catalogs.put(code,map);
        } catch(IOException e) {throw new ExceptionInInitializerError(e);}
    }
    public static void initialize(Path path) {
        preference=path; String code="es";
        try { if(Files.isRegularFile(path)) code=Files.readString(path).trim(); }catch(IOException ignored) { }
        setLanguage(code,false);
    }
    public static String language(){return language;}
    public static void setLanguage(String code,boolean save) {
        language=Set.of("es","en","de").contains(code)?code:"es";
        Locale locale=Locale.forLanguageTag(language);JComponent.setDefaultLocale(locale);Locale.setDefault(locale);
        if(save && preference!=null) try {
            Files.createDirectories(preference.getParent());
            Path tmp=Files.createTempFile(preference.getParent(),"poldo-language-",".tmp");
            try {Files.writeString(tmp,language);Files.move(tmp,preference,StandardCopyOption.REPLACE_EXISTING);}finally{Files.deleteIfExists(tmp);}
        }catch(IOException e){System.err.println("Language preference: "+e.getMessage());}
        synchronized(views) {views.removeIf(ref->ref.get()==null);for(var ref:views){Localized view=ref.get();if(view!=null)view.refresh();}}
    }
    public static String text(String source) {
        if(source==null || language.equals("es")) return source;
        Map<String,String> map=catalogs.get(language);
        if(map.containsKey(source)) return map.get(source);
        // Long phrases also occur in composed messages containing file paths.
        String result=Arrays.stream(source.split("\\n",-1)).map(line->map.getOrDefault(line,line)).collect(java.util.stream.Collectors.joining("\n"));
        if(source.startsWith("Paso 2/3: archivo ")) result=result.replace("archivo ",language.equals("de")?"Datei ":"file ").replace(" de ",language.equals("de")?" von ":" of ");
        for(String key:map.keySet().stream().filter(k->k.length()>=16 || k.endsWith(":" ) || k.startsWith("Paso ")).sorted(Comparator.comparingInt(String::length).reversed()).toList())
            result=result.replace(key,map.get(key));
        return result;
    }
    private static void track(Localized view){synchronized(views){views.add(new WeakReference<>(view));}}
    public static class Label extends JLabel implements Localized {
        private String source;
        public Label(){this("");} public Label(String text){super(text);track(this);}
        @Override public void setText(String text){source=text;super.setText(I18n.text(text));}
        @Override public void refresh(){super.setText(I18n.text(source));}
    }
    public static class Button extends JButton implements Localized {
        private String source;
        public Button(String text){super(text);track(this);}
        @Override public void setText(String text){source=text;super.setText(I18n.text(text));}
        @Override public void refresh(){super.setText(I18n.text(source));}
    }
    public static class TextArea extends JTextArea implements Localized {
        private String source;
        public TextArea(){super();track(this);}
        @Override public void setText(String text){source=text;super.setText(I18n.text(text));}
        @Override public void refresh(){super.setText(I18n.text(source));}
    }
}
