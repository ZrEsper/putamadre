@echo off
cd /d "%~dp0"
echo ZOMBIES POLDO - Preparando tu refugio...
echo No cierres esta ventana hasta que aparezca el instalador.
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Abrir-Instalador.ps1"
if errorlevel 1 (
 echo No se pudo completar. Abre Ayuda.cmd para ver los registros.
 pause
)
