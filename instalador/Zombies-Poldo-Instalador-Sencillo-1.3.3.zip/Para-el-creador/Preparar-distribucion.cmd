@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0..\Abrir-Instalador.ps1" -Prepare
if errorlevel 1 pause
