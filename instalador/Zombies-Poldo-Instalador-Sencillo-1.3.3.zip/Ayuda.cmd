@echo off
cd /d "%~dp0"
echo ZOMBIES POLDO - AYUDA
echo.
echo 1. Abrir guia facil
echo 2. Abrir registros de diagnostico
echo 3. Abrir instalador con consola de diagnostico
echo 4. Reparar cache del instalador (NO toca Minecraft ni mundos)
echo.
choice /c 1234 /n /m "Elige 1, 2, 3 o 4: "
if errorlevel 4 goto reparar
if errorlevel 3 goto debug
if errorlevel 2 goto logs
start "" "%~dp0GUIA.html"
exit /b
:logs
if defined LOCALAPPDATA (
 explorer "%LOCALAPPDATA%\ZombiesPoldo"
) else (
 explorer "%TEMP%\ZombiesPoldo"
)
exit /b
:debug
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Abrir-Instalador.ps1" -Debug
exit /b
:reparar
echo Cierra el instalador antes de continuar.
echo Solo se limpiara su cache. Los respaldos y mundos no se borran.
choice /c SN /n /m "Quieres continuar? S/N: "
if errorlevel 2 exit /b
powershell.exe -NoProfile -Command "$b = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'ZombiesPoldo' } else { Join-Path $env:TEMP 'ZombiesPoldo' }; foreach ($n in @('paquetes','extractor-7zip-25.01')) { $p = Join-Path $b $n; if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Recurse -Force } }; Write-Host 'Cache reparada. Abre Instalar.cmd otra vez.'"
pause
