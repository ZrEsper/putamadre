﻿param([switch]$Debug, [switch]$Prepare)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.IO.Compression.FileSystem
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$base = $PSScriptRoot
$cacheBase = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'ZombiesPoldo' } else { Join-Path ([IO.Path]::GetTempPath()) 'ZombiesPoldo' }
$logFolder = Join-Path $cacheBase 'logs'
$exitCode = 1
$stage = $null
$runtimeStage = $null
$runtimeArchive = $null
function Note([string]$text) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' | ' + $text
    Write-Host $text
    Add-Content -LiteralPath $script:bootLog -Value $line -Encoding UTF8
}
function Extract-Safe([string]$archive, [string]$destination) {
    $root = [IO.Path]::GetFullPath($destination).TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $zip = [IO.Compression.ZipFile]::OpenRead($archive)
    try {
        if ($zip.Entries.Count -gt 250000) { throw 'El ZIP tiene demasiados archivos. Pide al creador que revise el paquete.' }
        $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        foreach ($entry in $zip.Entries) {
            $name = $entry.FullName.Replace('\','/').Replace('/', [IO.Path]::DirectorySeparatorChar)
            Assert-ArchiveName $entry.FullName
            $target = [IO.Path]::GetFullPath((Join-Path $destination $name))
            if (-not $target.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { throw 'Una ruta del paquete sale de su carpeta.' }
            if ($entry.Name -eq '') { [IO.Directory]::CreateDirectory($target) | Out-Null; continue }
            if (-not $seen.Add($target)) { throw 'Hay archivos duplicados en el paquete.' }
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $false)
        }
    } finally { $zip.Dispose() }
}
function Get-ArchiveFormat([string]$path) {
    if (Test-Path -LiteralPath $path -PathType Container) { return 'DIRECTORY' }
    $stream = [IO.File]::OpenRead($path)
    try {
        $bytes = New-Object byte[] 512
        $count = $stream.Read($bytes, 0, $bytes.Length)
        $hex = ([BitConverter]::ToString($bytes,0,[Math]::Min($count,8))).Replace('-','')
        if ($hex -match '^504B(0304|0506|0708)') { return 'ZIP' }
        if ($hex -match '^526172211A07(00|0100)') { return 'RAR' }
        if ($hex -match '^377ABCAF271C') { return '7Z' }
        if ($hex -match '^1F8B') { return 'GZIP' }
        if ($hex -match '^425A68') { return 'BZIP2' }
        if ($hex -match '^FD377A585A00') { return 'XZ' }
        if ($count -ge 262 -and [Text.Encoding]::ASCII.GetString($bytes,257,5) -eq 'ustar') { return 'TAR' }
        return 'UNKNOWN'
    } finally { $stream.Dispose() }
}
function Find-Payload([string]$folder) {
    $files = @(Get-ChildItem -LiteralPath $folder -File | Where-Object {
        $_.Name -notmatch '^(motor|Zomboid-Installer)(\.|$)' -and
        ($_.Name -match '^datos($|[._-])' -or $_.Name -match '\.(zip|izp|rar|7z|tar|gz|tgz|bz2|xz)$')
    })
    $named = @($files | Where-Object { $_.Name -match '^datos($|[._-])' })
    if ($named.Count -gt 0) { $files = $named }
    $found = @()
    foreach ($file in $files) {
        $format = Get-ArchiveFormat $file.FullName
        Note ('Archivo encontrado: ' + $file.Name + ' | Formato real: ' + $format)
        if ($format -ne 'UNKNOWN') { $found += [pscustomobject]@{ Path=$file.FullName; Format=$format } }
    }
    if ($found.Count -gt 0) { return $found }
    foreach ($p in @((Join-Path $folder 'datos'), $folder)) {
        if (Test-Path -LiteralPath $p -PathType Container) {
            if ($p -ne $folder -or ((Test-Path -LiteralPath (Join-Path $p 'Zomboid-Installer.jar')) -and (Test-Path -LiteralPath (Join-Path $p 'pack/pack.json'))) -or (Test-Path -LiteralPath (Join-Path $p 'mods')) -or (Test-Path -LiteralPath (Join-Path $p 'config')) -or (Test-Path -LiteralPath (Join-Path $p 'saves'))) {
                return [pscustomobject]@{ Path=$p; Format='DIRECTORY' }
            }
        }
    }
    throw 'No encuentro el contenido. Pon el archivo datos (ZIP, RAR o 7Z) o la carpeta datos junto a Instalar.cmd. No cambies la extensión: se detecta el formato real.'
}
function Get-StartupPayload([string]$folder, [switch]$Creator) {
    if ($Creator) {
        $motor=Join-Path $folder 'motor.zip'
        if (-not (Test-Path -LiteralPath $motor)) { throw 'Falta motor.zip. Copia el motor de la actualización junto a Instalar.cmd.' }
        Note 'Modo creador: usando motor.zip. El contenido se toma de Para-el-creador/componentes.'
        return [pscustomobject]@{Path=$motor; Format='ZIP'}
    }
    return Find-Payload $folder
}
function Assert-ArchiveName([string]$name) {
    $normalized = $name.Replace('\','/').TrimEnd('/')
    if ([string]::IsNullOrWhiteSpace($normalized) -or $normalized.StartsWith('/') -or $normalized.Contains(':') -or ($normalized.Split('/') -contains '..')) {
        throw ('El paquete contiene una ruta no segura: ' + $name)
    }
}
function Invoke-ArchiveTool([string]$exe, [string[]]$items) {
    $quoted = @($items | ForEach-Object {
        if ($_.Contains('"')) { throw 'Una ruta contiene comillas no válidas.' }
        '"' + ($_ -replace '(\\+)$', '$1$1') + '"'
    }) -join ' '
    $pi = [Diagnostics.ProcessStartInfo]::new()
    $pi.FileName=$exe; $pi.Arguments=$quoted; $pi.UseShellExecute=$false; $pi.CreateNoWindow=$true
    $pi.RedirectStandardOutput=$true; $pi.RedirectStandardError=$true; $pi.RedirectStandardInput=$true
    $process = [Diagnostics.Process]::new(); $process.StartInfo=$pi
    try {
        [void]$process.Start()
        $process.StandardInput.Close()
        $stdout=$process.StandardOutput.ReadToEndAsync(); $stderr=$process.StandardError.ReadToEndAsync()
        $process.WaitForExit()
        $result = [pscustomobject]@{ ExitCode=$process.ExitCode; Output=$stdout.Result; Error=$stderr.Result }
        Note ('Extractor: ' + [IO.Path]::GetFileName($exe) + ' | Código: ' + $result.ExitCode)
        if ($result.Error) { Note $result.Error }
        return $result
    } finally { $process.Dispose() }
}
function Find-ArchiveTool([string]$format) {
    # The portable extractor travels with the installer; no system install or admin needed.
    $motor=Join-Path $script:base 'motor.zip'
    if (Test-Path -LiteralPath $motor) {
        $portable=Join-Path $script:cacheBase 'extractor-7zip-25.01'
        if (-not (Test-Path -LiteralPath (Join-Path $portable 'tools/7zip/7z.exe'))) {
            $temporary=Join-Path $script:cacheBase ('herramientas-' + [guid]::NewGuid().ToString('N'))
            New-Item -ItemType Directory -Path $temporary -Force | Out-Null
            try {
                Extract-Safe $motor $temporary
                if (-not (Test-Path -LiteralPath (Join-Path $temporary 'tools/7zip/7z.exe'))) { throw 'El motor no incluye el extractor. Descarga la actualización completa.' }
                Move-Item -LiteralPath $temporary -Destination $portable
            } finally { if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Recurse -Force } }
        }
        foreach ($item in @(@('7z.exe','4cd7d776c686427226a151789d2d61f0b2ed2c392148cc4e69c0238362fafecf'), @('7z.dll','5bd20fb38499d95c39594f41d4781b6181b3304b7f1f4d06b0182f514e7eaa74'))) {
            $tool=Join-Path $portable ('tools/7zip/' + $item[0])
            if (-not (Test-Path -LiteralPath $tool) -or (Get-FileHash -LiteralPath $tool -Algorithm SHA256).Hash -ne $item[1]) { throw 'El extractor está dañado. Usa Ayuda.cmd para reparar la caché y conserva tu archivo datos.' }
        }
        return [pscustomobject]@{ Path=(Join-Path $portable 'tools/7zip/7z.exe'); Type='7Z' }
    }

    foreach ($name in @('7z.exe','7zz.exe')) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if ($cmd) { return [pscustomobject]@{ Path=$cmd.Source; Type='7Z' } }
    }
    foreach ($parent in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ($parent) {
            $p=Join-Path $parent '7-Zip/7z.exe'
            if (Test-Path -LiteralPath $p) { return [pscustomobject]@{ Path=$p; Type='7Z' } }
        }
    }
    if ($format -eq 'RAR') {
        $cmd=Get-Command UnRAR.exe -ErrorAction SilentlyContinue
        if ($cmd) { return [pscustomobject]@{ Path=$cmd.Source; Type='RAR' } }
        foreach ($parent in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
            if ($parent) {
                $p=Join-Path $parent 'WinRAR/UnRAR.exe'
                if (Test-Path -LiteralPath $p) { return [pscustomobject]@{ Path=$p; Type='RAR' } }
            }
        }
    }
    $tar=Get-Command tar.exe -ErrorAction SilentlyContinue
    if ($tar) { return [pscustomobject]@{ Path=$tar.Source; Type='TAR' } }
    throw ('Encontré un archivo ' + $format + ', pero falta un extractor compatible. Instala 7-Zip desde https://www.7-zip.org/ y vuelve a abrir Instalar.cmd. No renombres el archivo a .zip.')
}
function Extract-Payload([string]$archive, [string]$format, [string]$destination, [int]$depth=0) {
    if ($depth -gt 4) { throw 'Hay demasiadas capas comprimidas. Pide un paquete más sencillo al creador.' }
    if ($format -eq 'ZIP') { Extract-Safe $archive $destination; return }
    if ($format -eq 'DIRECTORY') {
        $items=@(Get-ChildItem -LiteralPath $archive -Force)
        if ($archive -eq $script:base) { $items=@($items | Where-Object { $_.Name -in @('Zomboid-Installer.jar','audio','pack','componentes','mods','config','resourcepacks','shaderpacks','datapacks','saves') }) }
        foreach ($item in $items) {
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'El contenido contiene un enlace. Usa una carpeta normal.' }
            Copy-Item -LiteralPath $item.FullName -Destination $destination -Recurse
        }
        return
    }
    $tool=Find-ArchiveTool $format
    Note ('Descomprimiendo ' + $format + ' con ' + $tool.Path + '. Puede tardar varios minutos.')
    if ($tool.Type -eq '7Z') { $listing=Invoke-ArchiveTool $tool.Path @('l','-slt','-ba','-sccUTF-8','--',$archive) }
    elseif ($tool.Type -eq 'RAR') { $listing=Invoke-ArchiveTool $tool.Path @('lb','-p-',$archive) }
    else { $listing=Invoke-ArchiveTool $tool.Path @('-tf',$archive) }
    if ($listing.ExitCode -ne 0) { throw ('No se pudo leer el archivo ' + $format + '. Puede estar incompleto, tener contraseña o no ser compatible con el extractor. Instala 7-Zip desde https://www.7-zip.org/ y vuelve a intentar. Detalle: ' + $listing.Error) }
    $paths=@()
    foreach ($line in ($listing.Output -split '\r?\n')) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        if ($tool.Type -eq '7Z') {
            if ($line -match '^(Symbolic Link|Hard Link) = .+') { throw 'No se permiten enlaces dentro del paquete.' }
            if ($line -match '^Path = (.+)$') { $paths += $Matches[1] }
        } else { $paths += $line }
    }
    if ($paths.Count -eq 0 -or $paths.Count -gt 250000) { throw 'El archivo está vacío o tiene demasiadas entradas.' }
    foreach ($name in $paths) { Assert-ArchiveName $name }
    if ($tool.Type -eq '7Z') { $result=Invoke-ArchiveTool $tool.Path @('x','-y','-aos','-p-','-sccUTF-8',('-o' + $destination),'--',$archive) }
    elseif ($tool.Type -eq 'RAR') { $result=Invoke-ArchiveTool $tool.Path @('x','-o-','-p-','-y',$archive,($destination + [IO.Path]::DirectorySeparatorChar)) }
    else { $result=Invoke-ArchiveTool $tool.Path @('-xf',$archive,'-C',$destination) }
    if ($result.ExitCode -ne 0) { throw ('La extracción no terminó. No se usará el contenido incompleto. Código: ' + $result.ExitCode + '. Abre Ayuda.cmd para ver los registros.') }
    # TAR.GZ / TAR.XZ / TAR.BZ2 are two layers; unpack the inner TAR automatically.
    $children=@(Get-ChildItem -LiteralPath $destination -Force)
    if ($children.Count -eq 1 -and -not $children[0].PSIsContainer -and (Get-ArchiveFormat $children[0].FullName) -eq 'TAR') {
        $innerArchive=$children[0].FullName
        $inner=Join-Path $destination ('capa-' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $inner | Out-Null
        Extract-Payload $innerArchive 'TAR' $inner ($depth + 1)
        Remove-Item -LiteralPath $innerArchive
        foreach ($item in (Get-ChildItem -LiteralPath $inner -Force)) { Move-Item -LiteralPath $item.FullName -Destination $destination }
        Remove-Item -LiteralPath $inner
    }
    $links=@(Get-ChildItem -LiteralPath $destination -Recurse -Force | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })
    if ($links.Count -gt 0) { throw 'El archivo contiene enlaces. Pide una copia sin enlaces al creador.' }
}
function Resolve-InstallerContent([string]$raw, [string]$stage, [string]$release) {
    $candidates=@(Get-ChildItem -LiteralPath $raw -Filter Zomboid-Installer.jar -Recurse -File | Where-Object { Test-Path -LiteralPath (Join-Path $_.DirectoryName 'pack/pack.json') })
    if ($candidates.Count -eq 1) {
        $motor=Join-Path $release 'motor.zip'
        if (Test-Path -LiteralPath $motor) {
            $current=Join-Path $stage 'motor-actual'
            New-Item -ItemType Directory -Path $current -Force | Out-Null
            Extract-Safe $motor $current
            Copy-Item -LiteralPath (Join-Path $current 'Zomboid-Installer.jar') -Destination $candidates[0].FullName -Force
            Note 'Motor actualizado desde motor.zip; el archivo original se conserva.'
        }
        return $candidates[0].DirectoryName
    }
    if ($candidates.Count -gt 1) { throw 'El paquete contiene varios instaladores. Pide al creador una distribución única.' }
    $engine=Join-Path $release 'motor.zip'
    if (-not (Test-Path -LiteralPath $engine)) { throw 'El contenido no incluye el motor del instalador. Copia motor.zip de la actualización junto a Instalar.cmd. Conserva tu archivo datos.' }
    $ready=Join-Path $stage 'listo'; New-Item -ItemType Directory -Path $ready | Out-Null
    Extract-Safe $engine $ready
    $components=Join-Path $ready 'componentes/Contenido'; New-Item -ItemType Directory -Path $components -Force | Out-Null
    foreach ($item in (Get-ChildItem -LiteralPath $raw -Force)) { Copy-Item -LiteralPath $item.FullName -Destination $components -Recurse }
    return $ready
}

function Java-Version([string]$candidate) {
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $false }
    $p = $null
    try {
        $pi = [Diagnostics.ProcessStartInfo]::new()
        $pi.FileName = $candidate; $pi.Arguments = '-version'; $pi.UseShellExecute = $false; $pi.CreateNoWindow = $true
        $pi.RedirectStandardError = $true; $pi.RedirectStandardOutput = $true
        $p = [Diagnostics.Process]::new(); $p.StartInfo = $pi
        [void]$p.Start()
        if (-not $p.WaitForExit(5000)) { $p.Kill(); return $false }
        $info = $p.StandardError.ReadToEnd() + $p.StandardOutput.ReadToEnd()
        if ($p.ExitCode -eq 0 -and $info -match 'version\s+"(\d+)[.\-]') { return ([int]$Matches[1] -ge 21) }
        return $false
    } catch { return $false } finally { if ($p) { $p.Dispose() } }
}
try {
    New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
    $tag = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
    $script:bootLog = Join-Path $logFolder ('inicio-' + $tag + '.log')
    Note 'ZOMBIES POLDO 1.3.3 — Inicio'
    Note ('Windows: ' + [Environment]::OSVersion.VersionString)
    Note ('Paquete: ' + $base)
    $found = @(Get-StartupPayload $base -Creator:$Prepare)
    if ($found.Count -gt 1) {
        $picker = New-Object Windows.Forms.OpenFileDialog
        $picker.InitialDirectory = $base
        $picker.Title = 'Encontré varios archivos. Elige el contenido que quieres instalar'
        $picker.Filter = 'Todos los archivos|*.*'
        if ($picker.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { throw 'Selección cancelada. Tus archivos se conservan.' }
        $payload = $picker.FileName; $format = Get-ArchiveFormat $payload
        if ($format -eq 'UNKNOWN') { throw 'Ese formato no está reconocido. Elige el ZIP, RAR o 7Z que contiene el pack.' }
    } else { $payload = $found[0].Path; $format = $found[0].Format }
    Note ('Contenido seleccionado: ' + $payload + ' | ' + $format)
    if ($format -eq 'DIRECTORY') {
        $digest = [guid]::NewGuid().ToString('N')
    } else { $digest = (Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash.ToLowerInvariant() }
    # Separate this bootstrap version from old/incomplete caches.
    $appHome = Join-Path $cacheBase ('paquetes\1.3.3-' + $digest)
    $marker = Join-Path $appHome '.listo'
    if (-not (Test-Path -LiteralPath $marker) -or -not (Test-Path -LiteralPath (Join-Path $appHome 'Zomboid-Installer.jar'))) {
        Note 'Descomprimiendo el instalador. No cierres esta ventana.'
        $stage = Join-Path $cacheBase ('extraer-' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $stage | Out-Null
        $raw = Join-Path $stage 'contenido'
        New-Item -ItemType Directory -Path $raw | Out-Null
        Extract-Payload $payload $format $raw
        $contentHome = Resolve-InstallerContent $raw $stage $base
        if (-not (Test-Path -LiteralPath (Join-Path $contentHome 'Zomboid-Installer.jar'))) { throw 'El paquete no contiene el instalador. Pide un ZIP nuevo al creador.' }
        if (-not (Test-Path -LiteralPath (Join-Path $contentHome 'pack/pack.json'))) { throw 'Falta la configuración del paquete. Pide un ZIP nuevo al creador.' }
        New-Item -ItemType Directory -Path (Split-Path -Parent $appHome) -Force | Out-Null
        if (Test-Path -LiteralPath $appHome) { throw 'La caché quedó incompleta. Abre Ayuda.cmd y usa la opción de reparar la caché.' }
        Set-Content -LiteralPath (Join-Path $contentHome '.listo') -Value $digest -Encoding ASCII
        Move-Item -LiteralPath $contentHome -Destination $appHome
        Remove-Item -LiteralPath $stage -Recurse -Force
        $stage = $null
    }
    Note ('Contenido preparado: ' + $digest)
    $candidates = [Collections.Generic.List[string]]::new()
    $fromPath = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($fromPath) { $candidates.Add($fromPath.Source) }
    if ($env:JAVA_HOME) { $candidates.Add((Join-Path $env:JAVA_HOME 'bin\java.exe')) }
    $roots = [Collections.Generic.List[string]]::new()
    $roots.Add((Join-Path $cacheBase 'java21'))
    foreach ($pair in @(@($env:ProgramFiles,'Eclipse Adoptium'), @($env:ProgramFiles,'Java'), @($env:ProgramFiles,'Microsoft'), @($env:USERPROFILE,'curseforge\minecraft\Install\runtime'), @($env:APPDATA,'.minecraft\runtime'), @($env:APPDATA,'.tlauncher\jvms'), @($env:USERPROFILE,'.tlauncher\jvms'))) {
        if ($pair[0]) { $roots.Add((Join-Path $pair[0] $pair[1])) }
    }
    foreach ($root in $roots) {
        if (Test-Path -LiteralPath $root -PathType Container) {
            Get-ChildItem -LiteralPath $root -Filter java.exe -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 100 | ForEach-Object { $candidates.Add($_.FullName) }
        }
    }
    $chosenJava = $null
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (Java-Version $candidate) { $chosenJava = $candidate; break }
    }
    if (-not $chosenJava) {
        $answer = [Windows.Forms.MessageBox]::Show('Falta un pequeño componente para abrir el instalador (Java 21). ¿Lo descargamos automáticamente desde Eclipse Adoptium? Necesitas Internet. Se guarda solo para este instalador y no pide administrador.', 'Preparar el instalador', 'YesNo', 'Question')
        if ($answer -ne [Windows.Forms.DialogResult]::Yes) { throw 'Descarga cancelada. Puedes instalar Java 21 desde adoptium.net o abrir Minecraft 1.21.1 una vez y volver a intentar.' }
        Note 'Descargando Java 21 oficial. Espera unos minutos…'
        $arch = if (($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64')) { 'aarch64' } else { 'x64' }
        if (-not [Environment]::Is64BitOperatingSystem) { throw 'Se necesita Windows de 64 bits para Minecraft 1.21.1.' }
        $api = 'https://api.adoptium.net/v3/assets/latest/21/hotspot?architecture=' + $arch + '&image_type=jre&os=windows&vendor=eclipse'
        $assets = Invoke-RestMethod -Uri $api -UseBasicParsing
        $pkg = @($assets)[0].binary.package
        $uri = [Uri]$pkg.link
        if ($uri.Scheme -ne 'https' -or $uri.Host -ne 'github.com' -or $uri.AbsolutePath -notlike '/adoptium/*' -or $pkg.checksum -notmatch '^[a-fA-F0-9]{64}$') { throw 'No se pudo verificar el origen de Java. Usa Java 21 desde adoptium.net.' }
        $runtimeArchive = Join-Path $cacheBase ('java-' + [guid]::NewGuid().ToString('N') + '.zip')
        Invoke-WebRequest -Uri $uri.AbsoluteUri -OutFile $runtimeArchive -UseBasicParsing
        if ((Get-FileHash -LiteralPath $runtimeArchive -Algorithm SHA256).Hash -ne $pkg.checksum) { throw 'La descarga de Java está incompleta o dañada. Vuelve a intentar; no se utilizará este archivo.' }
        Note 'Descarga de Java verificada con SHA-256.'
        $runtimeStage = Join-Path $cacheBase ('java-extraer-' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $runtimeStage | Out-Null
        Extract-Safe $runtimeArchive $runtimeStage
        $newJava = Get-ChildItem -LiteralPath $runtimeStage -Filter java.exe -Recurse -File | Select-Object -First 1
        if (-not $newJava -or -not (Java-Version $newJava.FullName)) { throw 'Java se descargó pero no pudo arrancar. Usa Ayuda.cmd.' }
        $javaHome = Join-Path $cacheBase ('java21\' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path (Split-Path -Parent $javaHome) -Force | Out-Null
        $relative = $newJava.FullName.Substring($runtimeStage.Length).TrimStart('\')
        Move-Item -LiteralPath $runtimeStage -Destination $javaHome; $runtimeStage = $null
        $chosenJava = Join-Path $javaHome $relative
    }
    Note ('Java: ' + $chosenJava)
    $env:POLDO_RELEASE_DIR = $base
    $jar = Join-Path $appHome 'Zomboid-Installer.jar'
    $outLog = Join-Path $logFolder ('java-' + $tag + '-salida.log')
    $errLog = Join-Path $logFolder ('java-' + $tag + '-error.log')
    $arguments = '-jar "' + $jar + '"'
    if ($Prepare) {
        $destination = Join-Path $base ('Zombies-Poldo-Completo-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.zip')
        $arguments += ' --prepare "' + $base + '" "' + $destination + '"'
    }
    $app = Start-Process -FilePath $chosenJava -ArgumentList $arguments -WorkingDirectory $appHome -RedirectStandardOutput $outLog -RedirectStandardError $errLog -WindowStyle Hidden -PassThru
    $processHandle=$app.Handle
    if ($Prepare) {
        $started=Get-Date
        while (-not $app.HasExited) {
            $line=if (Test-Path -LiteralPath $outLog) { Get-Content -LiteralPath $outLog -Tail 1 -ErrorAction SilentlyContinue } else { 'Preparando...' }
            $elapsed=[int]((Get-Date)-$started).TotalSeconds
            Write-Host ('['+$elapsed+' s] '+$line)
            Start-Sleep -Seconds 1
            $app.Refresh()
        }
    }
    $app.WaitForExit()
    $exitCode = $app.ExitCode
    Note ('Finalizado. Código: ' + $exitCode)
    if ($exitCode -ne 0) {
        $hint = if ($Prepare -and (Test-Path $errLog)) { (Get-Content -LiteralPath $errLog -TotalCount 5) -join "`n" } else { 'Abre Ayuda.cmd para ver los registros.' }
        throw ('No se pudo completar la operación. ' + $hint)
    }
    if ($Prepare) { [Windows.Forms.MessageBox]::Show(('LISTO. Envía únicamente este ZIP a tus jugadores:' + "`n" + $destination),'Distribución preparada','OK','Information') | Out-Null }
} catch {
    $message = $_.Exception.Message
    if ($script:bootLog) { Note ('ERROR: ' + $message); Add-Content -LiteralPath $script:bootLog -Value $_.ScriptStackTrace -Encoding UTF8 }
    [Windows.Forms.MessageBox]::Show(($message + "`n`nDiagnóstico: " + $logFolder),'Vamos paso a paso','OK','Error') | Out-Null
    $exitCode = 1
} finally {
    foreach ($temporary in @($stage,$runtimeStage)) { if ($temporary -and (Test-Path -LiteralPath $temporary)) { Remove-Item -LiteralPath $temporary -Recurse -Force } }
    if ($runtimeArchive -and (Test-Path -LiteralPath $runtimeArchive)) { Remove-Item -LiteralPath $runtimeArchive -Force }
}
if ($Debug) { Write-Host ('Registros: ' + $logFolder); Read-Host 'Pulsa Enter para cerrar' | Out-Null }
exit $exitCode
