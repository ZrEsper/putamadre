"""Build the beginner installer without changing the supplied backend classes."""
from pathlib import Path
import hashlib, shutil, subprocess, urllib.request, zipfile
root=Path(__file__).resolve().parent
build=root/'build'; build.mkdir(exist_ok=True)
ecj=build/'ecj.jar'
digest='01f5a92ac19bb2b3bf85e295a68f2c73c264369109158b566ce9b490af982948'
if not ecj.exists() or hashlib.sha256(ecj.read_bytes()).hexdigest()!=digest:
    data=urllib.request.urlopen('https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.39.0/ecj-3.39.0.jar',timeout=60).read()
    if hashlib.sha256(data).hexdigest()!=digest: raise RuntimeError('ECJ checksum mismatch')
    ecj.write_bytes(data)
classes=build/'classes'
if classes.exists(): shutil.rmtree(classes)
classes.mkdir()
original=root/'original.jar'
sources=sorted((root/'src').rglob('*.java'))+sorted((root/'tests').rglob('*.java'))
subprocess.run(['java','-jar',str(ecj),'-21','-proc:none','-warn:none','-encoding','UTF-8','-cp',str(original),'-d',str(classes),*map(str,sources)],check=True)
import os
subprocess.run(['java','-Xverify:all','-cp',str(classes)+os.pathsep+str(original),'dev.zomboid.installer.InstallerChecks'],check=True)
dist=root/'dist';dist.mkdir(exist_ok=True)
jar=dist/'Zomboid-Installer.jar'
with zipfile.ZipFile(original) as old,zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
    for e in old.infolist():
        if e.filename=='META-INF/MANIFEST.MF': z.writestr(e,'Manifest-Version: 1.0\r\nMain-Class: dev.zomboid.installer.SimpleApp\r\n\r\n')
        else: z.writestr(e,old.read(e))
    for p in classes.rglob('*.class'):
        if not p.name.startswith('InstallerChecks'): z.write(p,p.relative_to(classes).as_posix())
print('Built:',jar)
