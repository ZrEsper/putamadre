package dev.zomboid.remains;
import java.util.*;
/** Weighted vanilla crafting ingredients, alongside the original quality minerals. */
public final class CraftingMaterials {
 public static String[] pool(String[] original,int quality){int q=Math.max(0,Math.min(4,quality));List<String> items=new ArrayList<>();if(original!=null)Collections.addAll(items,original);add(items,"gunpowder",12);add(items,"iron_ingot",10);add(items,"copper_ingot",6);add(items,"glass",6);add(items,"redstone",4);add(items,"quartz",3);add(items,"gold_ingot",2+q);add(items,"amethyst_shard",2);add(items,"blaze_rod",q>=3?2:1);return items.toArray(String[]::new);}
 private static void add(List<String> items,String id,int weight){for(int i=0;i<weight;i++)items.add("minecraft:"+id);}
}
