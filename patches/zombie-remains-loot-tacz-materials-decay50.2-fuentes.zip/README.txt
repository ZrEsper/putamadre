ACTUALIZACION 2 · MATERIALES + RESTOS 50/50
Reemplaza el JAR Zombie Remains Loot original, no instalar dos versiones. Instalar en cliente y servidor.

Cuando el cadaver pasa a la fase final (por descomposicion o al completar los cortes de extraccion), una tirada de servidor da 50% restos esqueleticos y50% desaparicion. Los que ya son esqueletos no vuelven a tirar. En desaparicion se elimina el bloque sin soltar el contenido al suelo y se vacia su inventario. El registro se retira en el siguiente ciclo normal de limpieza, evitando modificar el mapa durante su iteracion. Si falla la retirada del bloque no se vacia el inventario ni se marca como retirado. Se conservan los tiempos configurados y los restos ya existentes.

Prueba del metodo parcheado con API simulada: 50000 casos,25021restos y24979desapariciones; sin rerolls, y fallo de eliminacion conserva inventario. Verificacion de bytecode, CRC y dos clases originales modificadas (QualityRules y ZombieRemainsLoot). No se ha iniciado Minecraft.

Zombie Remains Loot 1.6.1 · npc-compat · TaCZ crafting materials patch1

Reemplazar el JAR anterior de Zombie Remains Loot por este, cliente y servidor; no instalar ambos. Integration y otros mods siguen igual.

El grupo de minerales existente incluye ahora materiales ponderados: polvora12, hierro10, cobre6, vidrio6, redstone4, cuarzo3, oro2+calidad, amatista2, blaze1 (calidad comun/poco comun/rara) o2 (epica/legendaria). Los minerales originales siguen en la tabla. Se conserva el numero de tiradas y cantidades originales por calidad: normalmente2-5 materiales en la tirada principal, uno en calidad maxima; algunas rutas ya realizan tiradas adicionales. Las varas de blaze son aproximadamente2% por tirada de materiales en calidad0-2 y3.7% en calidad3-4. No son porcentajes por zombie completo.

Son materias primas vanilla para recetas instaladas de armas, municion, miras y accesorios. No se modifican recetas ni se garantizan recetas particulares de packs de armas personalizados. No se entregan accesorios terminados. Se aplica a nueva generacion de loot; no rellena inventarios de cadaveres que ya tienen botin generado.

Parche de QualityRules.minerals, añade una clase helper sin dependencias Minecraft. Se conserva NPC compatibility y el resto de generacion/equipamiento/decadencia/sonidos/configuracion. No cambia calidad de los cuerpos, probabilidad de epicos o drops militares de Integration.

Validacion: prueba con la clase QualityRules real del JAR parcheado para los cinco niveles, ingredientes, peso de blaze y clamp; verificacion de bytecode de34clases/256metodos, CRC y retencion exacta de otros archivos. No ejecutado en Minecraft.

Fuentes: Java21. Compilar src/ y PatchMaterials con exports JDK asm y asm.tree; argumentos: originalJar,outputJar,helperClass. MaterialsTest usa el JAR parcheado en classpath.
