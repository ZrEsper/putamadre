package dev.zomboid.remains;
public class SkeletonRemains {public static final net.neoforged.neoforge.registries.DeferredHolder BONES=new net.neoforged.neoforge.registries.DeferredHolder();}