package dev.zomboid.remains;
public class LootSettings {public int skinningCuts=3;}