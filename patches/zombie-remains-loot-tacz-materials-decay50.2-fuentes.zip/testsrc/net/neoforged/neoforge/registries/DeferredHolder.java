package net.neoforged.neoforge.registries;
public class DeferredHolder {public Object get(){return new net.minecraft.world.level.block.Block();}}