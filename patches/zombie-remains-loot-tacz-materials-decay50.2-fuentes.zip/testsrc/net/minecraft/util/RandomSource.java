package net.minecraft.util;
public interface RandomSource {boolean nextBoolean();}