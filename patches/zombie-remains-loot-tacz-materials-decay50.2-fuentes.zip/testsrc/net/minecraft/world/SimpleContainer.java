package net.minecraft.world;
public class SimpleContainer {public boolean cleared;public void clearContent(){cleared=true;}}