package dev.zomboid.hordes;
import java.util.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Zombie;
public final class HordePerformance {
 private record PathStamp(UUID target,double x,double y,double z,long time){}
 private static final Map<Mob,PathStamp> PATHS=new WeakHashMap<>();
 public static int perceptionPeriod(Object entity){
  if(!(entity instanceof Zombie z))return 4;
  LivingEntity target=z.getTarget();
  if(target==null||!target.isAlive()||target.isRemoved()||target.level()!=z.level())return 16;
  return z.distanceToSqr(target)<=24*24?4:8;
 }
 public static void chase(Mob mob,LivingEntity target){
  if(target==null||!target.isAlive()||target.isRemoved()||target.level()!=mob.level()){PATHS.remove(mob);mob.getNavigation().stop();return;}
  long now=mob.level().getGameTime();PathStamp old=PATHS.get(mob);
  if(old!=null&&Objects.equals(old.target(),target.getUUID())&&now>=old.time()){
   long elapsed=now-old.time();double dx=target.getX()-old.x(),dy=target.getY()-old.y(),dz=target.getZ()-old.z();
   if(elapsed<8||elapsed<20&&dx*dx+dy*dy+dz*dz<4&&!mob.getNavigation().isDone())return;
  }
  PATHS.put(mob,new PathStamp(target.getUUID(),target.getX(),target.getY(),target.getZ(),now));
  mob.getNavigation().moveTo(target,1.15);
 }
}
