package dev.zomboid.hordes.mixin;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.invoke.arg.Args;import dev.zomboid.hordes.LootCapacity;import net.minecraft.util.RandomSource;import java.util.List;
@Mixin(targets="net.minecraft.world.level.storage.loot.LootTable")
public abstract class LootCapacityMixin{
 @ModifyArgs(method="fill",at=@At(value="INVOKE",target="Lnet/minecraft/world/level/storage/loot/LootTable;shuffleAndSplitItems(Ljava/util/List;ILnet/minecraft/util/RandomSource;)V"),require=0)
 private void zomboid$fitEmptySlots(Args args){List<?> items=args.get(0);int slots=args.get(1);RandomSource random=args.get(2);args.set(0,LootCapacity.fit(items,slots,random));}
}
