scoreboard players set #scan_budget ml_config 512
tellraw @s {"text":"Escaneo: 512 posiciones por tick.","color":"green"}
