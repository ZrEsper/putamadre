scoreboard players set #scan_budget ml_config 64
tellraw @s {"text":"Escaneo: 64 posiciones por tick.","color":"green"}
