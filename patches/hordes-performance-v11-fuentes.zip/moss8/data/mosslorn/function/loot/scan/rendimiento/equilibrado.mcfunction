scoreboard players set #scan_budget ml_config 128
tellraw @s {"text":"Escaneo: 128 posiciones por tick.","color":"green"}
