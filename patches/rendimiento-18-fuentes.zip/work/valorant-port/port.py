import zipfile,json,re,subprocess,hashlib,tomllib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'dist';OUT.mkdir(exist_ok=True)
PACKS=[('valorantpack','Valorant Gunpack','0.1.4','attachments/76d119ba-30ca-4d6b-a198-563090990cee/Valorant_gunpack_v0.1.4_beta3_fix1.zip','','valorant_neoforge_1211','port.valorant.PackMod'),('wtyj','Valorant Knife Pack','0.1.0','attachments/b59256dc-915e-413b-a852-0908615c26a5/Valorant Knife Pack-0.1.0.jar','','valorant_knife_neoforge_1211','port.wtyj.PackMod'),('guccivuitton','Gucci & Vuitton Attachments','0.2.2','attachments/c33996e2-842d-433b-8ee0-1611f70531cc/guccivuitton-1.20.1-0.2.2.jar','assets/guccivuitton/custom/gucci_vuitton_attachment/','gucci_vuitton_attachment_neoforge_1211','me.xjqsh.gucci.AttachmentMod')]
def parse(b):
 s=b.decode('utf-8-sig');o=[];i=0;quoted=False;escaped=False
 while i<len(s):
  c=s[i]
  if quoted:
   o.append(c)
   if escaped:escaped=False
   elif c=='\\':escaped=True
   elif c=='"':quoted=False
   i+=1;continue
  if c=='"':quoted=True;o.append(c);i+=1;continue
  if s[i:i+2]=='//':
   j=s.find('\n',i);i=len(s) if j<0 else j;continue
  if s[i:i+2]=='/*':
   j=s.find('*/',i+2)
   if j<0:raise ValueError('unclosed comment')
   i=j+2;continue
  o.append(c);i+=1
 return json.loads(''.join(o))
def enc(obj):return (json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode()
SINGLES={'nether_stars':'nether_star','obsidian':'obsidian','gunpowder':'gunpowder','rods/blaze':'blaze_rod'}
def walk(x):
 if isinstance(x,list):return [walk(y) for y in x]
 if not isinstance(x,dict):return x
 if x.get('type') in ('forge:partial_nbt','forge:nbt'):
  return {'type':'tacz:nbt','items':[x['item']] if 'item' in x else x['items'],'nbt':json.dumps(x['nbt'],separators=(',',':'),ensure_ascii=False) if isinstance(x['nbt'],dict) else x['nbt'],'partial':x['type']=='forge:partial_nbt'}
 y={k:walk(v) for k,v in x.items()}
 if str(y.get('tag','')).startswith('forge:'):
  t=y['tag'][6:]
  if t in SINGLES:y.pop('tag');y['item']='minecraft:'+SINGLES[t]
  else:y['tag']='c:'+({'glass':'glass_blocks'}.get(t,t))
 return y
def stack(x):
 y=dict(x);y['id']=y.pop('item',y.get('id'));y.setdefault('count',1)
 if 'nbt' in y:
  n=y.pop('nbt')
  if not isinstance(n,dict):raise ValueError('unexpected string stack NBT')
  y.setdefault('components',{})['minecraft:custom_data']=n
 return y
stub=ROOT/'stubs/net/neoforged/fml/common/Mod.java';stub.parent.mkdir(parents=True,exist_ok=True);stub.write_text('package net.neoforged.fml.common; import java.lang.annotation.*; @Retention(RetentionPolicy.RUNTIME) @Target(ElementType.TYPE) public @interface Mod { String value(); }')
report=[];metadata=[]
for mid,title,ver,path,oldprefix,dirname,fqn in PACKS:
 z=zipfile.ZipFile(path);assert z.testzip() is None
 contents={};outside={};changed=[];removed=[];unchanged=0
 for name in z.namelist():
  if name.endswith('/') or name.endswith('.class') or name.startswith('META-INF/'):continue
  if oldprefix:
   if not name.startswith(oldprefix):outside[name]=z.read(name);continue
   name2=name[len(oldprefix):]
  else:name2=name
  b=z.read(name);newname=re.sub(r'^(data/[^/]+)/recipes/',r'\1/recipe/',name2)
  if newname.endswith('.json'):
   obj=parse(b);newobj=obj
   if '/data/blocks/' in newname:
    def icons(v):
     if isinstance(v,list):return [icons(i) for i in v]
     if isinstance(v,dict):return {k:(stack(a) if k=='icon' and isinstance(a,dict) and 'item' in a else icons(a)) for k,a in v.items()}
     return v
    newobj=icons(obj)
   if '/recipe/' in newname:
    if obj.get('type')=='minecraft:crafting_shaped' or obj.get('type')=='crafting_shaped':
     if not obj.get('result') or not obj.get('pattern'):removed.append(name2);continue
    newobj=walk(obj)
    result=newobj.get('result')
    if isinstance(result,dict):
     if result.get('type')=='custom' and isinstance(result.get('item'),dict):result['item']=stack(result['item'])
     elif newobj.get('type','').startswith(('minecraft:','crafting_')) and 'item' in result:newobj['result']=stack(result)
   if mid=='wtyj':
    def attrs(v):
     if isinstance(v,list):return [attrs(i) for i in v]
     if isinstance(v,dict):return {('minecraft:'+k.removeprefix('minecraft:') if k.startswith(('generic.','minecraft:generic.')) else k):attrs(a) for k,a in v.items()}
     return v
    newobj=attrs(newobj)
   if newname=='assets/crystals/display/attachments/crystal_mag_display.json':
    newobj=dict(newobj);newobj.pop('model',None);newobj.pop('texture',None)
   if newname in ('assets/gucci_attachments/display/attachments/muzzle_191em_display.json','assets/gucci_attachments/display/attachments/muzzle_mk47_display.json'):
    removed.append(name2);continue
   if newname=='data/tacz/recipe_filters/default.json':
    newobj['whitelist']=['^.*$'];newobj['blacklist']=list(dict.fromkeys(['tacz:test']+newobj.get('blacklist',[])))
   try:json.loads(b.decode('utf-8-sig'));strict=True
   except ValueError:strict=False
   if newobj!=obj or not strict:b=enc(newobj)
  if newname=='pack.mcmeta':continue
  if newname!=name2 or b!=z.read(name):changed.append(name2)
  else:unchanged+=1
  assert newname not in contents;contents[newname]=b
 mcmeta=enc({'pack':{'description':title+' — NeoForge 1.21.1','pack_format':34,'supported_formats':{'min_inclusive':34,'max_inclusive':48}}})
 contents['pack.mcmeta']=mcmeta
 prefix=f'assets/{mid}/custom/{dirname}/'
 pkg,cls=fqn.rsplit('.',1);src=ROOT/'src'/Path(*fqn.split('.')).with_suffix('.java');src.parent.mkdir(parents=True,exist_ok=True)
 src.write_text(f'package {pkg};\n@net.neoforged.fml.common.Mod("{mid}")\npublic final class {cls} {{\n public static final String MOD_ID="{mid}";\n public static final String DEFAULT_PACK_NAME="{dirname}";\n public {cls}() {{ com.tacz.guns.api.resource.ResourceManager.registerExportResource({cls}.class, "/{prefix[:-1]}"); }}\n}}\n')
 classes=ROOT/'classes'/mid;classes.mkdir(parents=True,exist_ok=True)
 subprocess.run(['java','com.sun.tools.javac.Main','-source','21','-target','21','-classpath','work/tacz-accuracy/tacz-neoforge-1.21.1-1.1.8-hotfix-r7-third-person-pz.7.jar','-d',str(classes),str(stub),str(src)],check=True)
 toml=f'modLoader="javafml"\nloaderVersion="[4,)"\nlicense="'+('CC BY-NC-ND 4.0' if mid=='valorantpack' else 'All Rights Reserved')+f'"\n[[mods]]\nmodId="{mid}"\nversion="{ver}-neoforge1211"\ndisplayName="{title}"\nauthors="'+({'valorantpack':'幻梦星璇','wtyj':'WhiteFood & LesRaisins / LesRaisins Studio','guccivuitton':'xjqsh / Koei'}[mid])+'"\ndescription="Adaptacion de compatibilidad para Minecraft 1.21.1 y NeoForge. Autores y recursos originales conservados."\n'
 deps=[('neoforge','[21.1,)'),('minecraft','[1.21.1,1.21.2)'),('tacz','[1.1.8,)')]+([('lrtactical','[0.4.3,)')] if mid=='wtyj' else [])
 for dep,rng in deps:toml+=f'\n[[dependencies.{mid}]]\nmodId="{dep}"\ntype="required"\nversionRange="{rng}"\nordering="'+('AFTER' if dep in ('tacz','lrtactical') else 'NONE')+'"\nside="BOTH"\n'
 tomllib.loads(toml)
 filename={'valorantpack':'valorant-gunpack','wtyj':'valorant-knife-pack','guccivuitton':'guccivuitton'}[mid]+f'-{ver}-neoforge-1.21.1.jar';dest=OUT/filename
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as w:
  w.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\n\n');w.writestr('META-INF/neoforge.mods.toml',toml);w.writestr('pack.mcmeta',mcmeta)
  w.writestr(fqn.replace('.','/')+'.class',(classes/Path(*fqn.split('.')).with_suffix('.class')).read_bytes())
  for n,b in contents.items():w.writestr(prefix+n,b)
  for n,b in outside.items():
   if n!='pack.mcmeta':w.writestr(n,b)
 with zipfile.ZipFile(dest) as w:
  assert w.testzip() is None
  for n in w.namelist():
   if n.endswith(('.json','.mcmeta')):json.loads(w.read(n))
  assert len([n for n in w.namelist() if n.endswith('.class')])==1
  assert not any('/recipes/' in n for n in w.namelist())
 index={kind:len([n for n in contents if f'/index/{kind}/' in n and n.endswith('.json')]) for kind in ('guns','melee','attachments')}
 print(filename,index,'changed',len(changed),'removed',removed,'preserved',unchanged)
 report.append({'file':filename,'indices':index,'changed':changed,'removed':removed,'preserved_files':unchanged,'source_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()})
 b=dest.read_bytes();metadata.append({'path':'mods/'+filename,'local':str(dest),'size':len(b),'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
(OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
(OUT/'upload.json').write_text(json.dumps(metadata))
