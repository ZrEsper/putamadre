package org.spongepowered.asm.mixin.injection;import java.lang.annotation.*;@Retention(RetentionPolicy.RUNTIME) public @interface Constant{double doubleValue() default 0;}
