from pathlib import Path
import zipfile,json,subprocess
r=Path('work/perf19');flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
baseI=Path('work/sleep18/zomboid-integration-1.7.5-neoforge-1.21.1-virtual-hearing-sleep.jar');baseH=Path('work/noise17/zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.17-distant-hearing.jar')
with zipfile.ZipFile(baseH) as z:(r/'EventAttraction.class').write_bytes(z.read('dev/zomboid/hordes/EventAttraction.class'))
subprocess.run(['java',*flags,'-cp',str(r/'tools'),'PatchPaths',str(r/'EventAttraction.class'),str(r/'EventAttraction-patched.class')],check=True)
for base,out,prefix,oldver,newver in [(baseI,r/'zomboid-integration-1.7.6-neoforge-1.21.1-async-archive-item-merge.jar','dev/zomboid/integration/','1.7.5','1.7.6'),(baseH,r/'zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.18-path-budget.jar','dev/zomboid/hordes/','1.8.3','1.8.3')]:
 with zipfile.ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()}
 folder=r/'classes'/prefix
 for p in folder.rglob('*.class'):data[prefix+p.relative_to(folder).as_posix()]=p.read_bytes()
 if 'integration' in prefix:
  data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(('version="'+oldver+'"').encode(),('version="'+newver+'"').encode())
  obj=json.loads(data['zomboid_integration.mixins.json']);obj['mixins'].append('ItemMergeMixin');data['zomboid_integration.mixins.json']=json.dumps(obj,indent=2).encode()
 else:data['dev/zomboid/hordes/EventAttraction.class']=(r/'EventAttraction-patched.class').read_bytes()
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in data.items():z.writestr(n,b)
 with zipfile.ZipFile(out) as z:assert z.testzip() is None
 subprocess.run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/tools','Verify',str(out)],check=True)
 print(out,out.stat().st_size)
