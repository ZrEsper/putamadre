import java.nio.file.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public final class PatchPaths {
 public static void main(String[] args)throws Exception{
  ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(c,0);int count=0;
  for(MethodNode m:c.methods)if(m.name.equals("investigate")&&m.desc.equals("(Ljava/lang/Object;)V")){
   // Redirect only the final navigation moveTo call. All earlier reflection calls remain native.
   MethodInsnNode last=null;for(AbstractInsnNode i:m.instructions)if(i instanceof MethodInsnNode call&&call.owner.equals("dev/zomboid/hordes/ChunkReflection")&&call.name.equals("call"))last=call;
   if(last==null)throw new IllegalStateException("No moveTo call");
   m.instructions.insertBefore(last,new VarInsnNode(Opcodes.ALOAD,0));last.owner="dev/zomboid/hordes/PathThrottle";last.desc="(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;";count++;
  }
  if(count!=1)throw new IllegalStateException("Expected one investigation hook");ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.write(Path.of(args[1]),w.toByteArray());
 }
}
