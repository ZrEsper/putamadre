import java.nio.file.*;import dev.zomboid.integration.*;import net.minecraft.world.level.Level;import net.minecraft.world.entity.monster.Zombie;import net.minecraft.world.entity.player.Player;import net.neoforged.neoforge.event.tick.*;import net.neoforged.neoforge.event.entity.*;import net.neoforged.neoforge.event.server.*;
public class MarkFailureTest{
 static void ticks(Level l,int n)throws Exception{for(int i=0;i<n;i++){l.time++;ZombieSleep.tick(new LevelTickEvent.Post(l));ZombieSleep.clock(new ServerTickEvent.Post());Thread.sleep(2);}}
 public static void main(String[] args)throws Exception{
  Level l=new Level();l.server=new net.minecraft.server.MinecraftServer();l.server.root=Files.createTempDirectory("marker-failure");Player p=new Player();p.world=l;l.players.add(p);Zombie z=new Zombie();z.world=l;z.x=200;l.addFreshEntity(z);ticks(l,100);if(!z.removed)throw new AssertionError("not saved");
  ArchiveFiles.failActive=true;p.x=200;ticks(l,100);Zombie awake=(Zombie)l.getEntity(z.uuid);if(awake==null||ZombieSleep.frozen(awake))throw new AssertionError("IO failure lost/froze native entity");awake.removal="KILLED";l.entities.remove(z.uuid);EntityLeaveLevelEvent event=new EntityLeaveLevelEvent();event.entity=awake;ZombieSleep.leave(event);ticks(l,30);ZombieSleep.stop(new ServerStoppedEvent());
  try(var files=Files.walk(l.server.root)){if(files.anyMatch(file->file.getFileName().toString().endsWith(".nbt")))throw new AssertionError("dead zombie backup remained");}
  System.out.println("Marker failure regression passed: failed rename keeps live entity, pauses archive, and death removes the retained snapshot.");
 }
}
