package dev.zomboid.integration;
import java.nio.file.*;import java.nio.channels.FileChannel;import java.io.*;
public final class ArchiveFiles {
 public static boolean failActive;private ArchiveFiles(){}
 private static void worker(){if(!Thread.currentThread().getName().equals("Zomboid-Zombie-Archive"))throw new AssertionError("Archive IO on "+Thread.currentThread().getName());}
 public static void move(Path from,Path to)throws IOException {worker();if(failActive&&to.getFileName().toString().startsWith("A_"))throw new IOException("simulated marker failure");Files.move(from,to,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
 public static void write(Path target,Object tag)throws Exception {
  worker();Files.createDirectories(target.getParent());Path temp=target.resolveSibling(target.getFileName()+".tmp");
  try{NativeAccess.call(Class.forName("net.minecraft.nbt.NbtIo"),"writeCompressed",tag,temp);try(FileChannel channel=FileChannel.open(temp,StandardOpenOption.WRITE)){channel.force(true);}move(temp,target);}
  finally{Files.deleteIfExists(temp);}
 }
 public static Object read(Path file)throws Exception {worker();
  Object unlimited=NativeAccess.call(Class.forName("net.minecraft.nbt.NbtAccounter"),"unlimitedHeap");return NativeAccess.call(Class.forName("net.minecraft.nbt.NbtIo"),"readCompressed",file,unlimited);
 }
}
