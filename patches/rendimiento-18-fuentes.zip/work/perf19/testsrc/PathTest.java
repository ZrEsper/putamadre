import dev.zomboid.hordes.PathThrottle;
public class PathTest {
 public static class World{public long now;public long getGameTime(){return now;}}
 public static class Mob{public final World world;Mob(World w){world=w;}public World level(){return world;}}
 public static class Nav{public int paths;public boolean done,works=true;public boolean isDone(){return done;}public boolean moveTo(double x,double y,double z,double speed){paths++;return works;}}
 static int checks;static void check(boolean test){checks++;if(!test)throw new AssertionError(checks);}
 static void go(Nav n,Mob m,double x){PathThrottle.call(n,"moveTo",new Object[]{x,70d,0d,1.05d},m);}
 public static void main(String[]args){
  World w=new World();Mob m=new Mob(w);Nav n=new Nav();
  go(n,m,16);for(int i=0;i<79;i++){w.now=i;go(n,m,16);}check(n.paths==1);
  w.now=80;go(n,m,16);check(n.paths==2);w.now=81;go(n,m,24);check(n.paths==3);
  w.now=82;n.done=true;go(n,m,24);check(n.paths==4);
  World many=new World();int total=0;Nav[] batch=new Nav[256];Mob mm=new Mob(many);
  for(int i=0;i<256;i++){batch[i]=new Nav();go(batch[i],mm,16);total+=batch[i].paths;}check(total==4);
  for(int tick=1;tick<80;tick++){many.now=tick;for(Nav v:batch)go(v,mm,16);}
  for(Nav v:batch)check(v.paths==1);
  World fail=new World();Mob fm=new Mob(fail);Nav bad=new Nav();bad.works=false;go(bad,fm,16);for(int i=1;i<30;i++){fail.now=i;go(bad,fm,16);}check(bad.paths==1);fail.now=30;go(bad,fm,16);check(bad.paths==2);
  System.out.println("Path throttle tests passed: "+checks+" checks; 256 simultaneous requests spread at four/tick; valid paths reused and failed paths retry.");
 }
}
