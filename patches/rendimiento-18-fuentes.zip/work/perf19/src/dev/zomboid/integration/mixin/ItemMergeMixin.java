package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(targets="net.minecraft.world.entity.item.ItemEntity",remap=false)
public abstract class ItemMergeMixin {
 @ModifyConstant(method="mergeWithNeighbours()V",constant=@Constant(doubleValue=.5),require=0,remap=false)
 private double zi$mergeRadius(double radius){return 1.5;}
}
