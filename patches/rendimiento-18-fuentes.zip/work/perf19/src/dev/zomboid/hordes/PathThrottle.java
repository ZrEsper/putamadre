package dev.zomboid.hordes;
import java.util.*;
/** Only used for noise investigation, never the native combat navigation. */
public final class PathThrottle {
 private static final WeakHashMap<Object,State> PATHS=new WeakHashMap<>();
 private static final WeakHashMap<Object,Budget> WORLDS=new WeakHashMap<>();
 private static final class State {double x,y,z;long next;boolean success;}
 private static final class Budget {long tick=Long.MIN_VALUE;int spent;}
 public static Object call(Object nav,String method,Object[] args,Object mob){
  if(!method.equals("moveTo")||args.length!=4)return ChunkReflection.call(nav,method,args);
  Object level=ChunkReflection.call(mob,"level");long now=((Number)ChunkReflection.call(level,"getGameTime")).longValue();
  double x=((Number)args[0]).doubleValue(),y=((Number)args[1]).doubleValue(),z=((Number)args[2]).doubleValue();
  State last=PATHS.get(nav);
  if(last!=null){double dx=x-last.x,dy=y-last.y,dz=z-last.z;boolean same=dx*dx+dy*dy+dz*dz<16;
   if(same&&now<last.next){if(!last.success||!Boolean.TRUE.equals(ChunkReflection.call(nav,"isDone")))return last.success;}
  }
  Budget budget=WORLDS.computeIfAbsent(level,k->new Budget());if(budget.tick!=now){budget.tick=now;budget.spent=0;}
  if(budget.spent>=4)return last!=null&&last.success;
  budget.spent++;
  Object result=ChunkReflection.call(nav,method,args);
  State state=last==null?new State():last;state.x=x;state.y=y;state.z=z;state.success=Boolean.TRUE.equals(result);state.next=now+(state.success?80:30);PATHS.put(nav,state);return result;
 }
}
