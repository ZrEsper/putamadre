from pathlib import Path
import zipfile,json,re
root=Path('work/perf19');base='work/clothing-fixes/mosslorn-expanded.10-rendimiento-registro.zip';out=root/'mosslorn-expanded.11-paced-scans.zip'
with zipfile.ZipFile(base) as z:data={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
pre='data/mosslorn/function/'
tick=data[pre+'tick.mcfunction'].decode().replace('matches 10.. run function mosslorn:segundo','matches 20.. run function mosslorn:segundo')
lines=[]
for line in tick.splitlines():
 if 'as @e[type=minecraft:marker,tag=ml_scan_anchor,limit=1]' in line:line='execute if score #scan ml_tmp matches 1 if score #scan_slice ml_tmp matches 0 '+line[len('execute '):]
 lines.append(line)
lines.insert(1,'scoreboard players operation #scan_slice ml_tmp = #scan_clock ml_tmp')
lines.insert(2,'scoreboard players operation #scan_slice ml_tmp %= #scan_every ml_config')
data[pre+'tick.mcfunction']=('\n'.join(lines)+'\n').encode()
load=data[pre+'load.mcfunction'].decode().replace('Mosslorn v10:','Mosslorn v11:')
load+='\nexecute unless score #scan_every ml_config matches 1..10 run scoreboard players set #scan_every ml_config 2\nexecute unless score #perf11 ml_config matches 1 if score #scan_budget ml_config matches 128 run scoreboard players set #scan_budget ml_config 64\nscoreboard players set #perf11 ml_config 1\n'
data[pre+'load.mcfunction']=load.encode()
force=data[pre+'force/tick.mcfunction'].decode().splitlines();batch=[l for l in force if 'run function mosslorn:force/index_step' in l];rest=[l for l in force if l not in batch]
rest.insert(2,'execute if score #force_build ml_tmp matches 1 run function mosslorn:force/index_batch')
rest=[l.replace('matches 10..','matches 20..') for l in rest]
data[pre+'force/tick.mcfunction']=('\n'.join(rest)+'\n').encode();data[pre+'force/index_batch.mcfunction']=('\n'.join(batch)+'\n').encode()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in data.items():z.writestr(n,b)
assert len(batch)==64
for n,b in data.items():
 if n.endswith('.mcfunction'):
  # Static function targets must still exist. Macros preserve the original substitution rules.
  for fn in re.findall(r'\bfunction (mosslorn:[a-z0-9_/-]+)',b.decode()):assert pre+fn.split(':',1)[1]+'.mcfunction' in data,(n,fn)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print('Datapack validated:',out,'64 index branches only during rebuild; idle scan selectors removed; loot tables unchanged')
