import zipfile,json,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
native={}
for jar,prefix in [('work/tacz-accuracy/tacz-neoforge-1.21.1-1.1.8-hotfix-r7-third-person-pz.7.jar','assets/tacz/custom/tacz_default_gun/'),('attachments/32ff66ce-7b0b-4568-a265-c581abdc94ef/LesRaisins-Tactical-Equipements-1.21.1-0.4.3-zomboid-jsononly-safe.jar','')]:
 z=zipfile.ZipFile(jar)
 for n in z.namelist():
  if prefix and n.startswith(prefix):native[n[len(prefix):]]=z.read(n)
  elif not prefix and n.startswith(('assets/','data/')):native[n]=z.read(n)
issues=[];refs=0;recipes=0
for jar in root.glob('dist/*.jar'):
 z=zipfile.ZipFile(jar);files=dict(native)
 for n in z.namelist():
  if '/custom/' in n:
   parts=n.split('/custom/',1)[1].split('/',1)
   if len(parts)==2:files[parts[1]]=z.read(n)
 for n,b in list(files.items()):
  if not n.endswith('.json') or '/display/' not in n or not n.startswith('assets/'):continue
  try:o=json.loads(b)
  except ValueError:continue
  for key,folder,suffix in [('model','geo_models','.json'),('animation','animations','.animation.json'),('state_machine','scripts','.lua'),('texture','textures','.png'),('slot','textures','.png'),('slot_texture','textures','.png')]:
   v=o.get(key)
   if isinstance(v,str) and ':' in v:
    ns,p=v.split(':',1);target=f'assets/{ns}/{folder}/{p}{suffix}';refs+=1
    if target not in files:issues.append((jar.name,n,key,target))
 for n in z.namelist():
  if '/recipe/' not in n or not n.endswith('.json'):continue
  o=json.loads(z.read(n));recipes+=1;s=json.dumps(o)
  assert 'forge:' not in s and '"partial_nbt"' not in s
  if o.get('result',{}).get('type')=='custom':
   st=o['result']['item'];assert 'id' in st and 'item' not in st and 'nbt' not in st
  if o.get('type')=='minecraft:crafting_shaped':assert o['result'].get('id') and o.get('pattern')
 subprocess.run(['java','--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/tools','Verify',str(jar)],check=True)
print('Reference checks:',refs,'Recipes:',recipes,'Missing:',len(issues))
for i in issues:print(i)
(root/'dist/reference-report.json').write_text(json.dumps({'checks':refs,'recipes':recipes,'missing':issues},indent=2))
