package me.xjqsh.gucci;
@net.neoforged.fml.common.Mod("guccivuitton")
public final class AttachmentMod {
 public static final String MOD_ID="guccivuitton";
 public static final String DEFAULT_PACK_NAME="gucci_vuitton_attachment_neoforge_1211";
 public AttachmentMod() { com.tacz.guns.api.resource.ResourceManager.registerExportResource(AttachmentMod.class, "/assets/guccivuitton/custom/gucci_vuitton_attachment_neoforge_1211"); }
}
