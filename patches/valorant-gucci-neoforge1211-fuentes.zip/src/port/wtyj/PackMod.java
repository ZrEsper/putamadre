package port.wtyj;
@net.neoforged.fml.common.Mod("wtyj")
public final class PackMod {
 public static final String MOD_ID="wtyj";
 public static final String DEFAULT_PACK_NAME="valorant_knife_neoforge_1211";
 public PackMod() { com.tacz.guns.api.resource.ResourceManager.registerExportResource(PackMod.class, "/assets/wtyj/custom/valorant_knife_neoforge_1211"); }
}
