package port.valorant;
@net.neoforged.fml.common.Mod("valorantpack")
public final class PackMod {
 public static final String MOD_ID="valorantpack";
 public static final String DEFAULT_PACK_NAME="valorant_neoforge_1211";
 public PackMod() { com.tacz.guns.api.resource.ResourceManager.registerExportResource(PackMod.class, "/assets/valorantpack/custom/valorant_neoforge_1211"); }
}
