Zomboid Integration 1.2.0 — linterna y atención médica

INSTALACION
Reemplazar cualquier versión anterior de Zomboid Integration por 1.5.0 en mods de cliente y servidor, sin duplicados. Conservar Flashlight 5.1 corregido + TCTCore, First Aid ZOMBOID 3.4.9 global-health-revival, SurvivorCreator v24 y Quietly v10. No requiere sustituir esos tres JARs.

MEDICINA
Clic derecho en un jugador cercano abre la elección Revisarme / Revisar a [jugador]. Revisarme se habilita si hay lesiones. Se examina durante 30 ticks (1.5 segundos a 20 TPS), con barra; luego se muestran ocho zonas y su estado real del servidor: salud, cortes, disparos, balas alojadas, mordeduras, sangrado, vendaje limpio/sucio, infección, fracturas e inmovilización.
Elegir zona y Vendar / Férula / Extraer bala / Curar. Los materiales se buscan en el inventario del médico y se consumen o desgastan al completar la aplicación. No consume si se interrumpe por distancia, movimiento, daño o pérdida del material. Alcance máximo 3 bloques con visión directa. Esc/cerrar cancela.
Las férulas ya no se aplican automáticamente a la primera pierna: clic derecho con una férula abre el menú propio. Elegir la pierna fracturada y Férula; aplicación base 3 segundos, ajustada por el nivel de First Aid. La fractura queda inmovilizada y conserva la recuperación original de 2400 ticks (2 minutos a 20 TPS), mostrando lo que falta. No se aplica una férula a una zona sana.
La recompensa de First Aid la recibe quien trata, a través de la integración existente de First Aid con SurvivorCreator (3 XP por aplicación válida; las reglas originales omiten creativo/espectador). Examinar no da XP.
Las tijeras extraen una bala por aplicación; los objetos de curación normales mantienen sus curadores originales y su recuperación progresiva.
No permite dos tratamientos de este menú a la vez sobre el mismo paciente. Los tratamientos nativos activos también se comprueban antes de aplicar.

LINTERNAS
Conserva X, tecla configurable, luz desde inventario y luz en objetos tirados, con estado persistido por la variante encendida/apagada del objeto. El clic derecho no cambia el estado. Las reglas normales de desaparición de objetos tirados se mantienen.

VALIDACION
22 pruebas de distancia, interrupción y valores de paquete; 10 pruebas con el código real de heridas de First Aid; 20 pruebas de linterna/colocación segura conservadas. Bytecode y ZIP verificados. No se realizó una prueba dentro de Minecraft ni una sesión LAN real; esas pruebas siguen pendientes.

TECLAS 1.2
Al iniciar, si TCTCore comparte exactamente la tecla con Mostrar heridas o Rendirse de First Aid, mueve solamente TCTCore a F8, o a otra tecla de función libre si F8 está ocupada. Guarda el cambio en options.txt mediante Options.save. No cambia el menú médico, rendirse ni una asignación de TCTCore sin conflicto. Conserva todas las funciones anteriores. Los JAR enviados tienen H como predeterminada tanto en TCTCore como en Mostrar heridas, y G para Rendirse. Las teclas reales de options.txt pueden diferir.
Desatasco con disparo pendiente: los complementos enviados no contienen el motor de TaCZ; falta el JAR principal exacto para implementar ese cambio.
8 pruebas adicionales de selección de teclas. Falta prueba de arranque y controles dentro de Minecraft.

LOOT 1.3
Con Quietly v10, requiere 3 bloques o menos del centro del contenedor o posición del cadáver, también en contenedores ya registrados y al reabrir tras la búsqueda. Comprueba distancia en servidor al interactuar, iniciar, durante la búsqueda y antes de abrir. Muestra aviso de cercanía. Conserva la interrupción por movimiento del mod original. No altera contenido previamente generado.
Reduce 80% las probabilidades acumuladas de épico y legendario al elegir la calidad de una nueva búsqueda. Con scavenging 10 y suerte 0, épico o superior pasa de 9.8% a 1.96%; legendario pasa de 1.56% a 0.312%. Mantiene la influencia de habilidad y suerte; las tiradas degradadas quedan en las calidades inferiores. No modifica el loot base independiente de Zombie Remains ni su compatibilidad con NPC.
15 comprobaciones adicionales, incluyendo 900000 tiradas comparadas con Rules del Quietly enviado y distancia/reflexión usando su clase R real. No probado dentro de Minecraft/LAN.

HUD HOMEOSTATIC 1.4
Corrección opcional de cliente para Homeostatic 2.12.0.0. Conserva la fila original de gotas, sus valores, efectos y configuración. Antes de dibujar, vacía el lote gráfico previo, guarda el color/transparencia y el estado de mezcla, establece color blanco opaco y mezcla estándar; al terminar vacía las gotas pendientes y restaura color y mezcla anteriores. Así otro HUD no puede volver transparentes o tintadas las gotas por estado heredado. No añade hidratación ni modifica consumo o envía paquetes adicionales. First Aid ya usa los mismos datos reales de Homeostatic.
24 comprobaciones del aislamiento gráfico con simulación de lotes, varias transparencias y mezcla activada/desactivada. Compilación y bytecode verificados. La causa concreta reportada requiere confirmar esta corrección dentro de Minecraft, donde no se realizó una prueba.

MELEE Y LENGUA 1.5
Conservar los tres JAR enviados: melee 2.3.1 range-plus-one-ezweight-v11, mutants-l4d2-addon 1.3.0 y MutantsZombies 1.3.1. Reemplazar exclusivamente la integración anterior por esta en cliente y servidor.
La lengua se corta con una sola interacción válida sobre su segmento (o el personaje atrapado, como permitía el addon original). El ataque melee al infectado que mantiene una lengua activa libera al atrapado y permite que el daño del ataque continúe. Conserva las verificaciones originales de jugador válido, servidor, dimensión, visión y distancia máxima de 6 bloques; la interacción melee normal sigue pasando por sus controles propios de alcance. La liberación usa Tethers.release original, que elimina los segmentos y sus hitboxes. El cooldown de las habilidades no cambia: 200 ticks, 10 segundos a 20 TPS.
El renderByItem de NativeBatRenderer vuelve a dibujar el modelo original completo mediante ItemRenderer.renderStatic con el contexto, luz y overlay correctos, en vez de delegarlo a BEWLR, que no dibuja armas ordinarias. Usa el guard original para evitar que se seleccione nuevamente el proxy y lo libera incluso ante excepción. En primera persona aísla color/transparencia y mezcla, vaciando lotes BufferSource antes y después del render, para que estados de otros dibujos no vuelvan invisible el arma. Conserva animaciones, alcance y reglas de stamina.
10 comprobaciones de validación de lengua con Combat.valid real del addon, 5 de delegación del modelo con renderizador simulado y 24 de estado gráfico melee simulado. No equivalen a un lanzamiento de Minecraft ni a pruebas de shaders/LAN; sigue pendiente comprobar visualmente el resultado.
