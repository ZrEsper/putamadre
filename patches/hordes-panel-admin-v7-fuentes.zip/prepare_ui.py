from pathlib import Path
import shutil
p=Path('work/tuning7/stubs')
def write(n,s):f=p/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
def add(n,s):f=p/n;t=f.read_text();i=t.rfind('}');f.write_text(t[:i]+s+t[i:])
for root in ['com/google/gson','net/minecraft/network/codec','net/minecraft/network/protocol/common/custom','net/neoforged/neoforge/network']:
 src=Path('work/survivor16/stubs')/root
 if src.exists():shutil.copytree(src,p/root,dirs_exist_ok=True)
for f in ['net/minecraft/network/RegistryFriendlyByteBuf.java','net/minecraft/client/gui/Font.java','net/minecraft/util/FormattedCharSequence.java','net/minecraft/network/chat/FormattedText.java']:
 src=Path('work/survivor16/stubs')/f
 if src.exists():write(f,src.read_text())
add('com/google/gson/JsonObject.java','public JsonObject getAsJsonObject(String k){return null;}public java.util.Set<java.util.Map.Entry<String,JsonElement>> entrySet(){return null;}')
write('net/minecraft/network/codec/StreamMemberEncoder.java','package net.minecraft.network.codec;public interface StreamMemberEncoder<B,V>{void encode(B b,V v);}')
write('net/minecraft/network/codec/StreamDecoder.java','package net.minecraft.network.codec;public interface StreamDecoder<B,V>{V decode(B b);}')
add('net/minecraft/network/codec/StreamCodec.java','public static <B,V> StreamCodec<B,V> of(StreamMemberEncoder<B,V> e,StreamDecoder<B,V> d){return null;}')
add('net/minecraft/network/RegistryFriendlyByteBuf.java','public net.minecraft.network.FriendlyByteBuf writeUtf(String s,int max){return null;}public String readUtf(int max){return "";}')
write('net/minecraft/network/FriendlyByteBuf.java','package net.minecraft.network;public class FriendlyByteBuf {}')
write('net/minecraft/commands/CommandSourceStack.java','package net.minecraft.commands;public class CommandSourceStack {public boolean hasPermission(int level){return true;}}')
add('net/minecraft/server/level/ServerPlayer.java','public net.minecraft.commands.CommandSourceStack createCommandSourceStack(){return null;}public net.minecraft.server.MinecraftServer getServer(){return null;}public void sendSystemMessage(net.minecraft.network.chat.Component c){}')
write('net/minecraft/client/gui/screens/Screen.java','''package net.minecraft.client.gui.screens;public class Screen {protected net.minecraft.client.gui.Font font;protected net.minecraft.network.chat.Component title;public int width,height;public Screen(net.minecraft.network.chat.Component t){title=t;}protected void init(){}protected <T extends net.minecraft.client.gui.components.events.GuiEventListener & net.minecraft.client.gui.components.Renderable & net.minecraft.client.gui.narration.NarratableEntry> T addRenderableWidget(T t){return t;}public void onClose(){}public void render(net.minecraft.client.gui.GuiGraphics g,int x,int y,float d){}public boolean isPauseScreen(){return false;}}''')
for n in ['components/events/GuiEventListener','components/Renderable','narration/NarratableEntry']:
 pkg=n.rsplit('/',1)[0].replace('/','.');name=n.rsplit('/',1)[1];write('net/minecraft/client/gui/'+n+'.java','package net.minecraft.client.gui.'+pkg+';public interface '+name+' {}')
write('net/minecraft/client/gui/components/AbstractWidget.java','package net.minecraft.client.gui.components;public class AbstractWidget implements events.GuiEventListener,Renderable,net.minecraft.client.gui.narration.NarratableEntry {public boolean active=true;public void setTooltip(Tooltip t){}public void setMessage(net.minecraft.network.chat.Component c){}}'.replace('implements events.','implements net.minecraft.client.gui.components.events.').replace(',Renderable',',net.minecraft.client.gui.components.Renderable'))
write('net/minecraft/client/gui/components/Tooltip.java','package net.minecraft.client.gui.components;public class Tooltip {public static Tooltip create(net.minecraft.network.chat.Component c){return null;}}')
write('net/minecraft/client/gui/components/Button.java','package net.minecraft.client.gui.components;public class Button extends AbstractWidget {public interface OnPress{void onPress(Button b);}public static class Builder{public Builder bounds(int x,int y,int w,int h){return this;}public Button build(){return new Button();}}public static Builder builder(net.minecraft.network.chat.Component c,OnPress p){return new Builder();}}')
write('net/minecraft/client/gui/components/EditBox.java','package net.minecraft.client.gui.components;public class EditBox extends AbstractWidget {public EditBox(net.minecraft.client.gui.Font f,int x,int y,int w,int h,net.minecraft.network.chat.Component c){}public void setValue(String s){}public String getValue(){return "";}public void setMaxLength(int n){}}')
write('net/minecraft/client/Minecraft.java','package net.minecraft.client;public class Minecraft {public static Minecraft getInstance(){return null;}public void setScreen(net.minecraft.client.gui.screens.Screen s){}}')
# keep already-correct GuiGraphics fill; add text methods
write('net/minecraft/client/gui/GuiGraphics.java','package net.minecraft.client.gui;public class GuiGraphics{public void fill(int x,int y,int x2,int y2,int c){}public int drawString(Font f,String s,int x,int y,int c,boolean shadow){return 0;}public int drawString(Font f,net.minecraft.util.FormattedCharSequence s,int x,int y,int c,boolean shadow){return 0;}}')
write('net/minecraft/network/chat/Component.java','package net.minecraft.network.chat;public interface Component extends FormattedText {public static MutableComponent literal(String s){return null;}public String getString();}')
write('net/minecraft/network/chat/MutableComponent.java','package net.minecraft.network.chat;public class MutableComponent implements Component{public String getString(){return "";}}')
# Network registration runs on the mod bus only.
f=p/'net/neoforged/fml/common/EventBusSubscriber.java';t=f.read_text();i=t.rfind('}');f.write_text(t[:i]+'public enum Bus{GAME,MOD}Bus bus() default Bus.GAME;'+t[i:])
Path('work/tuning7/compile.args').write_text('-cp work/siege6/zomboid-hordes-1.8.3-neoforge-1.21.1-reactive-noise-siege.6.jar\n-d work/tuning7/classes\n'+'\n'.join(str(f) for base in ['work/tuning7/stubs','work/tuning7/src','work/tuning7/bridge'] for f in Path(base).rglob('*.java')))
