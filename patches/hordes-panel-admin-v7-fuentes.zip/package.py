from pathlib import Path
import zipfile
r=Path('work/tuning7')
for base,out,prefix in [('base.jar','zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.7.jar','dev/zomboid/hordes/'),('the-base.jar','The-Hordes-1.21.1-1.6.3f-zombies-mutants-admin.2.jar','dev/zomboid/onlyzombies/')]:
 with zipfile.ZipFile(r/base) as z:data={n:z.read(n) for n in z.namelist()}
 for p in (r/'classes'/prefix).rglob('*.class'):data[prefix+str(p.relative_to(r/'classes'/prefix))]=p.read_bytes()
 with zipfile.ZipFile(r/out,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in data.items():z.writestr(n,b)
 with zipfile.ZipFile(r/out) as z:assert z.testzip() is None
 print(out,(r/out).stat().st_size)
