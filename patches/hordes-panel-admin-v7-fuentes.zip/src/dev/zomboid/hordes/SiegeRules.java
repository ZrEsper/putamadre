package dev.zomboid.hordes;
public final class SiegeRules {
 public static boolean selected(double roll,double chance){return roll>=0 && roll<Math.max(0,Math.min(.01,chance));}
 public static double vision(double roll){return 12+44*roll;}
 public static int memory(double roll){return 160+(int)(540*roll);}
 public static double aggression(double roll){return .25+.75*roll;}
 public static int breakTicks(float hardness){return Math.max(12,Math.min(160,(int)(hardness*24)+12));}
 public static boolean breakable(float hardness,boolean blockEntity,boolean liquid){return hardness>=0 && hardness<=30 && !blockEntity && !liquid;}
}
