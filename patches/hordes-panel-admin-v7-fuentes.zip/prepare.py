from pathlib import Path
p=Path('work/tuning7/stubs')
def write(n,s):f=p/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
def add(n,s):f=p/n;t=f.read_text();i=t.rfind('}');f.write_text(t[:i]+s+t[i:])
write('net/minecraft/server/MinecraftServer.java','package net.minecraft.server;public class MinecraftServer {}')
for n in ['ServerStartedEvent','ServerStoppedEvent']:
 write('net/neoforged/neoforge/event/server/'+n+'.java','package net.neoforged.neoforge.event.server;public class '+n+' {public net.minecraft.server.MinecraftServer getServer(){return null;}}')
add('net/minecraft/world/entity/EntityType.java','public String getDescriptionId(){return "";}') if (p/'net/minecraft/world/entity/EntityType.java').exists() else write('net/minecraft/world/entity/EntityType.java','package net.minecraft.world.entity;public class EntityType<T> {public String getDescriptionId(){return "";}}')
write('net/minecraft/world/entity/ai/attributes/AttributeModifier.java','package net.minecraft.world.entity.ai.attributes;public record AttributeModifier(net.minecraft.resources.ResourceLocation id,double amount,Operation operation){public enum Operation{ADD_VALUE,ADD_MULTIPLIED_BASE,ADD_MULTIPLIED_TOTAL}}')
add('net/minecraft/world/entity/ai/attributes/AttributeInstance.java','public AttributeModifier getModifier(net.minecraft.resources.ResourceLocation id){return null;}public void removeModifier(net.minecraft.resources.ResourceLocation id){}public void addTransientModifier(AttributeModifier m){}')
# compile against the actual existing reflection helper and original addon API.
Path('work/tuning7/compile.args').write_text('-cp work/siege6/zomboid-hordes-1.8.3-neoforge-1.21.1-reactive-noise-siege.6.jar\n-d work/tuning7/classes\n'+'\n'.join(str(f) for base in ['work/tuning7/stubs','work/tuning7/src','work/tuning7/bridge'] for f in Path(base).rglob('*.java')))
