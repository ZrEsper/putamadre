from pathlib import Path
import zipfile,json,random,io
from PIL import Image
r=Path('work/tuning10');random.seed(410)
with zipfile.ZipFile(r/'base.jar') as z:data={n:z.read(n) for n in z.namelist()}
for p in (r/'classes/dev/zomboid/hordes').rglob('*.class'):data['dev/zomboid/hordes/'+str(p.relative_to(r/'classes/dev/zomboid/hordes'))]=p.read_bytes()
def put(path,obj):data['assets/zomboid_hordes/'+path]=json.dumps(obj,ensure_ascii=False,indent=2).encode()
put('blockstates/rotten_flesh_block.json',{'variants':{'':{'model':'zomboid_hordes:block/rotten_flesh_block'}}})
put('models/block/rotten_flesh_block.json',{'parent':'minecraft:block/cube_all','textures':{'all':'zomboid_hordes:block/rotten_flesh'}})
for name,parent in [('rotten_flesh_stairs','stairs'),('rotten_flesh_stairs_inner','inner_stairs'),('rotten_flesh_stairs_outer','outer_stairs')]:put('models/block/'+name+'.json',{'parent':'minecraft:block/'+parent,'textures':{k:'zomboid_hordes:block/rotten_flesh' for k in ('bottom','top','side')}})
variants={}
for face,angle in [('east',0),('south',90),('west',180),('north',270)]:
 for half in ['bottom','top']:
  for shape in ['straight','inner_left','inner_right','outer_left','outer_right']:
   suffix='' if shape=='straight' else '_'+shape.split('_')[0];y=angle
   if shape!='straight':y+=(270 if half=='bottom' and shape.endswith('left') else 90 if half=='top' and shape.endswith('right') else 0)
   model={'model':'zomboid_hordes:block/rotten_flesh_stairs'+suffix}
   if half=='top':model['x']=180
   if y%360:model['y']=y%360
   if half=='top' or y%360:model['uvlock']=True
   variants[f'facing={face},half={half},shape={shape}']=model
put('blockstates/rotten_flesh_stairs.json',{'variants':variants})
im=Image.new('RGB',(16,16));px=im.load()
for y in range(16):
 for x in range(16):
  base=random.choice([(90,42,28),(112,54,35),(132,68,41),(76,61,30),(82,76,36)]);noise=random.randint(-9,9);px[x,y]=tuple(max(0,c+noise) for c in base)
for x,y in [(3,3),(4,3),(5,4),(11,10),(12,10),(12,11),(6,13)]:px[x,y]=(159,85,49)
b=io.BytesIO();im.save(b,format='PNG');data['assets/zomboid_hordes/textures/block/rotten_flesh.png']=b.getvalue()
for lang,label in [('es_es','Carne podrida'),('en_us','Rotten flesh')]:
 path='assets/zomboid_hordes/lang/'+lang+'.json';d=json.loads(data.get(path,b'{}'));d.update({'block.zomboid_hordes.rotten_flesh_block':label,'block.zomboid_hordes.rotten_flesh_stairs':('Escaleras de carne podrida' if lang=='es_es' else 'Rotten flesh stairs')});data[path]=json.dumps(d,ensure_ascii=False,indent=2).encode()
out=r/'zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.10-rotten-build.jar'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in data.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(out,out.stat().st_size)
