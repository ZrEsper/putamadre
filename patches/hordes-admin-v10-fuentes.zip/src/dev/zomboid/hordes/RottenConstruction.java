package dev.zomboid.hordes;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.*;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.*;
public final class RottenConstruction {
 public static final int LIFETIME=2400;
 private static final DeferredRegister<Block> BLOCKS=DeferredRegister.create(Registries.BLOCK,"zomboid_hordes");
 public static final DeferredHolder<Block,Flesh> FLESH=BLOCKS.register("rotten_flesh_block",()->new Flesh(properties()));
 public static final DeferredHolder<Block,FleshStairs> STAIRS=BLOCKS.register("rotten_flesh_stairs",()->new FleshStairs(properties()));
 public static void register(IEventBus bus){BLOCKS.register(bus);}
 private static BlockBehaviour.Properties properties(){return BlockBehaviour.Properties.of().strength(.6f).sound(SoundType.SLIME_BLOCK).noLootTable();}
 private static void schedule(Level level,BlockPos pos,Block block,BlockState old){if(!level.isClientSide&&!old.is(block))level.scheduleTick(pos,block,LIFETIME);}
 private static void decay(ServerLevel level,BlockPos pos,Block block){if(level.getBlockState(pos).is(block))level.removeBlock(pos,false);}
 public static class Flesh extends Block {
  public static final MapCodec<Flesh> CODEC=simpleCodec(Flesh::new);
  public Flesh(BlockBehaviour.Properties p){super(p);}
  @Override protected MapCodec<? extends Block> codec(){return CODEC;}
  @Override public void onPlace(BlockState state,Level level,BlockPos pos,BlockState old,boolean moving){super.onPlace(state,level,pos,old,moving);schedule(level,pos,this,old);}
  @Override public void tick(BlockState state,ServerLevel level,BlockPos pos,RandomSource random){decay(level,pos,this);}
 }
 public static class FleshStairs extends StairBlock {
  public static final MapCodec<FleshStairs> CODEC=simpleCodec(FleshStairs::new);
  public FleshStairs(BlockBehaviour.Properties p){super(FLESH.get().defaultBlockState(),p);}
  @Override protected MapCodec<? extends StairBlock> codec(){return CODEC;}
  @Override public void onPlace(BlockState state,Level level,BlockPos pos,BlockState old,boolean moving){super.onPlace(state,level,pos,old,moving);schedule(level,pos,this,old);}
  @Override public void tick(BlockState state,ServerLevel level,BlockPos pos,RandomSource random){decay(level,pos,this);}
 }
}
