package net.minecraft.world.level.block;public class SoundType{public static final SoundType SLIME_BLOCK=new SoundType();}
