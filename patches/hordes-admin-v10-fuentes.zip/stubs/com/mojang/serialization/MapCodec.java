package com.mojang.serialization;public class MapCodec<T>{}
