package dev.zomboid.integration.loot;
public final class LootRules {
 public static int rarity(double roll,double luck,int skill){int lev=Math.max(0,Math.min(10,skill));double effective=Math.max(-2,Math.min(8,luck))+lev*.75;double bonus=Math.max(-.03,Math.min(.12,effective*.012));return dev.zomboid.integration.BalancePolicy.quality(roll,false,bonus+lev*.018);}
 public static boolean near(double d){return Double.isFinite(d)&&d>=0&&d<=9;}
}
