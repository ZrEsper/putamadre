package dev.zomboid.integration;
public final class ClothingRules {
 public static int kind(double roll,double civilian,double military){military=BalancePolicy.get("zombis_militares",military*100)/100;return !Double.isFinite(roll)||roll<0||roll>=1?0:roll<military?2:roll<Math.min(1,military+civilian)?1:0;}
 public static int quality(int kind,double roll){return Math.max(kind==2?2:kind==1?1:0,BalancePolicy.quality(roll,false));}
}
