package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Pseudo @Mixin(targets="dev.zomboid.scavenging.Rules",remap=false)
public abstract class RarityNamesMixin {
 @Inject(method="name(I)Ljava/lang/String;",at=@At("HEAD"),cancellable=true,remap=false)
 private static void balance$name(int quality,CallbackInfoReturnable<String> ci){if(quality==5)ci.setReturnValue("Mítico");}
}
