package dev.zomboid.remains;
import java.util.*;import java.util.concurrent.ThreadLocalRandom;
public final class GunLootExtras {
 public static void apply(Object stack,Object profile,int requested){try{if(Boolean.TRUE.equals(MilitaryDrops.call(stack,"isEmpty")))return;Object gun=MilitaryDrops.call(stack,"getItem");if(!Class.forName("com.tacz.guns.api.item.IGun").isInstance(gun))return;var random=ThreadLocalRandom.current();
  // Only freshly-created loot guns enter this method: player guns and inherited NPC gear are untouched.
  if(random.nextDouble()*100<BalancePolicy.get("accesorios_armas",35)){
   Object server=MilitaryDrops.call(Class.forName("net.neoforged.neoforge.server.ServerLifecycleHooks"),"getCurrentServer");if(server!=null){Object provider=MilitaryDrops.call(server,"registryAccess");List<Map.Entry<?,?>> pool=new ArrayList<>();for(Object e:(Set<?>)MilitaryDrops.call(Class.forName("com.tacz.guns.api.TimelessAPI"),"getAllCommonAttachmentIndex"))pool.add((Map.Entry<?,?>)e);Collections.shuffle(pool,random);Set<Object> filled=new HashSet<>();int wanted=1+random.nextInt(3);
    for(var entry:pool){Object attachment=MilitaryDrops.stack("tacz:attachment",1);if(Boolean.TRUE.equals(MilitaryDrops.call(attachment,"isEmpty")))break;Object item=MilitaryDrops.call(attachment,"getItem");MilitaryDrops.call(item,"setAttachmentId",attachment,entry.getKey());Object type=MilitaryDrops.call(item,"getType",attachment);if(filled.contains(type))continue;Object current=MilitaryDrops.call(gun,"getAttachmentId",stack,type),builtin=MilitaryDrops.call(gun,"getBuiltInAttachmentId",stack,type);if(!Boolean.TRUE.equals(MilitaryDrops.call(Class.forName("com.tacz.guns.api.DefaultAssets"),"isEmptyAttachmentId",current))||!Boolean.TRUE.equals(MilitaryDrops.call(Class.forName("com.tacz.guns.api.DefaultAssets"),"isEmptyAttachmentId",builtin)))continue;
     if(!Boolean.TRUE.equals(MilitaryDrops.call(gun,"allowAttachment",stack,attachment)))continue;MilitaryDrops.call(gun,"installAttachment",provider,stack,attachment);Object installed=MilitaryDrops.call(gun,"getAttachmentId",stack,type);if(Objects.equals(installed,entry.getKey())){filled.add(type);if(filled.size()>=wanted)break;}
    }
   }
  }
  int capacity=Math.max(0,((Number)MilitaryDrops.call(profile,"capacity")).intValue());int count=random.nextDouble()*100<BalancePolicy.get("armas_cargadas",45)&&capacity>0?1+random.nextInt(Math.max(1,(int)Math.ceil(capacity*.75))):0;MilitaryDrops.call(Class.forName("dev.zomboid.remains.GunAccess"),"load",stack,Math.min(capacity,count));
 }catch(Exception|LinkageError e){System.err.println("[Zombie Remains] Loot attachment/ammo setup failed; native gun retained: "+e);}}
}
