package dev.zomboid.hordes;
import java.lang.reflect.*;
public final class BalancePolicy {
 public static double get(String key,double fallback){try{Object v=Class.forName("dev.zomboid.hordes.WorldTuning").getMethod("get",String.class).invoke(null,key);return v instanceof Number n&&Double.isFinite(n.doubleValue())?Math.max(0,Math.min(100,n.doubleValue())):fallback;}catch(ReflectiveOperationException|LinkageError e){return fallback;}}
 public static int quality(double roll,boolean mutant){return quality(roll,mutant,0);}
 public static int quality(double roll,boolean mutant,double bonus){if(!Double.isFinite(roll)||roll<0||roll>=1)return 0;double epic=get("epicos",4),legend=get("legendarios",1),myth=get("miticos",.2),sum=epic+legend+myth,scale=sum>100?100/sum:1;epic*=scale;legend*=scale;myth*=scale;double p=roll*100;if(p<myth)return 5;if(p<myth+legend)return 4;if(p<myth+legend+epic)return 3;double residual=100-(myth+legend+epic);double lower=residual<=0?1:(p-myth-legend-epic)/residual;return lower<(mutant?.22:.14)+bonus?2:lower<(mutant?.60:.40)+bonus?1:0;}
 public static int clamped(int q){return Math.max(0,Math.min(5,q));}
 public static String name(int q){return new String[]{"común","poco común","raro","épico","legendario","mítico"}[clamped(q)];}
 public static double gunChance(int q){return new double[]{.12,.25,.45,.7,1,1}[clamped(q)];}
 public static int ammoMin(int q){return new int[]{15,24,36,48,64,96}[clamped(q)];}
 public static int ammoMax(int q){return new int[]{32,48,64,96,128,160}[clamped(q)];}
}
