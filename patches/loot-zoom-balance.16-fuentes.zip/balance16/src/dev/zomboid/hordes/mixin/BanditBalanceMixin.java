package dev.zomboid.hordes.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;
@Pseudo @Mixin(targets="mod.cdv.tnpc.tactical.BanditBrain",remap=false)
public abstract class BanditBalanceMixin {
 @Inject(method="levelTick(Ljava/lang/Object;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private static void balance$disabled(Object event,org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci){if(dev.zomboid.hordes.BalancePolicy.get("bandidos",50)<=0)ci.cancel();}
 @Redirect(method="levelTick(Ljava/lang/Object;)V",at=@At(value="INVOKE",target="Lmod/cdv/tnpc/tactical/BanditBrain;call(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"),remap=false)
 private static Object balance$spawn(Object receiver,String name,Object[] args)throws Exception{
  if(name.equals("addFreshEntity")&&args.length==1){var b=Class.forName("mod.cdv.tnpc.tactical.CalmBrain").getDeclaredMethod("bandit",Object.class);b.setAccessible(true);if(Boolean.TRUE.equals(b.invoke(null,args[0]))&&Math.random()*100>=dev.zomboid.hordes.BalancePolicy.get("bandidos",50))return false;}
  var method=Class.forName("mod.cdv.tnpc.tactical.BanditBrain").getDeclaredMethod("call",Object.class,String.class,Object[].class);method.setAccessible(true);try{return method.invoke(null,receiver,name,args);}catch(java.lang.reflect.InvocationTargetException e){if(e.getCause() instanceof Exception x)throw x;throw e;}
 }
}
