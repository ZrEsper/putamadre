package dev.zomboid.hordes.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;
@Pseudo @Mixin(targets="mod.cdv.tnpc.tactical.SurvivalGear",remap=false)
public abstract class MilitaryBanditBalanceMixin {
 @Redirect(method="outfit(Ljava/lang/Object;Ljava/util/Random;)V",at=@At(value="INVOKE",target="Ljava/util/Random;nextDouble()D",ordinal=0),remap=false)
 private static double balance$military(java.util.Random random,Object npc,java.util.Random outfitRandom){double roll=random.nextDouble();try{var method=Class.forName("mod.cdv.tnpc.tactical.CalmBrain").getDeclaredMethod("bandit",Object.class);method.setAccessible(true);if(!Boolean.TRUE.equals(method.invoke(null,npc)))return roll;}catch(ReflectiveOperationException e){return roll;}return roll*100<dev.zomboid.hordes.BalancePolicy.get("bandidos_militares",5)?0:1;}
}
