package dev.zomboid.hordes.client;
public final class ScrollSpeed {
 private long last;private int streak;private double direction;
 public double step(String key,double delta,long now){if(!Double.isFinite(delta)||delta==0)return 0;double sign=Math.signum(delta);if(now-last<90_000_000L&&now>=last&&sign==direction)streak=Math.min(8,streak+1);else streak=0;last=now;direction=sign;double base=key.equals("asediadores")?.01:key.equals("miticos")||key.equals("zombis_militares")||key.equals("vision_nocturna")?.1:key.equals("frecuencia")||key.equals("densidad")?.1:1;double boost=streak>=5?20:streak>=2?5:1;return sign*base*boost*Math.min(5,Math.max(1,Math.abs(delta)));}
}
