from pathlib import Path
import zipfile,subprocess,json,hashlib
r=Path('work/balance16');subprocess.run(['java','com.sun.tools.javac.Main','@'+str(r/'compile.args')],check=True)
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
subprocess.run(['java','com.sun.tools.javac.Main',*flags,'-d',str(r/'tools'),str(r/'PatchBalance.java')],check=True)
base='attachments/3f458d4d-45a0-4b40-bdc7-fde1ce36e9df/zombie-remains-loot-1.6.1-neoforge-1.21.1-tacz-materials-decay50.2.jar'
subprocess.run(['java',*flags,'-cp',str(r/'tools'),'PatchBalance',base,str(r/'remains-patched.jar')],check=True)
sets=[('attachments/4e71fbbe-5543-4a04-90fa-22cc4a42721b/zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.15-direct-noise-spawn-filter.jar','zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.16-loot-balance.jar','dev/zomboid/hordes/', 'zomboid_hordes.mixins.json',['BanditBalanceMixin','MilitaryBanditBalanceMixin']),('work/flashlight-fix2/zomboid-integration-1.7.3-neoforge-1.21.1-map-grass-protection.jar','zomboid-integration-1.7.4-neoforge-1.21.1-military-loot-controls.jar','dev/zomboid/integration/','zomboid_integration.mixins.json',['RarityNamesMixin']),(str(r/'remains-patched.jar'),'zombie-remains-loot-1.6.1-neoforge-1.21.1-military-nvg-mythic.3.jar','dev/zomboid/remains/',None,[])]
artifacts=[]
for base,out,prefix,mixin,add in sets:
 with zipfile.ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()}
 for p in (r/'classes'/prefix).rglob('*.class'):data[prefix+str(p.relative_to(r/'classes'/prefix))]=p.read_bytes()
 if mixin:
  j=json.loads(data[mixin]);j['mixins']+=add;data[mixin]=json.dumps(j,indent=2).encode()
 if prefix.endswith('integration/'):data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'version="1.7.3"',b'version="1.7.4"')
 with zipfile.ZipFile(r/out,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in data.items():z.writestr(n,b)
 with zipfile.ZipFile(r/out) as z:assert z.testzip() is None;assert not any(n.startswith(('net/minecraft/','net/neoforged/','org/spongepowered/')) for n in z.namelist())
 subprocess.run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/tools','Verify',str(r/out)],check=True)
 b=(r/out).read_bytes();artifacts.append({'path':str(r/out),'remote':'mods/'+out,'size':len(b),'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
(r/'artifacts.json').write_text(json.dumps(artifacts));print(json.dumps(artifacts,indent=2))
