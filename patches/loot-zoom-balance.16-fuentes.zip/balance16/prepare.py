from pathlib import Path
import shutil
r=Path('work/balance16'); src=r/'src'
p=src/'dev/zomboid/hordes/WorldTuning.java';t=p.read_text()
extra={'bandidos':50,'zombis_militares':1,'bandidos_militares':5,'epicos':4,'legendarios':1,'miticos':.2,'vision_nocturna':2,'ropa_militar':8}
import re
for name in ['DEFAULT','MIN','MAX']:
 pat=r'private static final Map<String,Double> '+name+r'=Map.of\((.*?)\);'
 match=re.search(pat,t); pairs=re.findall(r'"([^"]+)",([^,]+)',match[1]);pairs += [(k,str(v if name=='DEFAULT' else 0 if name=='MIN' else 100)+'d') for k,v in extra.items()]
 value='private static final Map<String,Double> '+name+'=Map.ofEntries('+','.join('Map.entry("'+k+'",'+v+')' for k,v in pairs)+');'
 t=t[:match.start()]+value+t[match.end():]
p.write_text(t)
p=src/'dev/zomboid/hordes/AdminNetwork.java';t=p.read_text().replace('admin_view7','admin_view16').replace('admin_apply7','admin_apply16').replace('registrar("7")','registrar("16")');p.write_text(t)
# Same probability logic in separate namespaces: absence of Hordes retains moderate defaults.
policy='''import java.lang.reflect.*;
public final class BalancePolicy {
 public static double get(String key,double fallback){try{Object v=Class.forName("dev.zomboid.hordes.WorldTuning").getMethod("get",String.class).invoke(null,key);return v instanceof Number n&&Double.isFinite(n.doubleValue())?Math.max(0,Math.min(100,n.doubleValue())):fallback;}catch(ReflectiveOperationException|LinkageError e){return fallback;}}
 public static int quality(double roll,boolean mutant){return quality(roll,mutant,0);}
 public static int quality(double roll,boolean mutant,double bonus){if(!Double.isFinite(roll)||roll<0||roll>=1)return 0;double epic=get("epicos",4),legend=get("legendarios",1),myth=get("miticos",.2),sum=epic+legend+myth,scale=sum>100?100/sum:1;epic*=scale;legend*=scale;myth*=scale;double p=roll*100;if(p<myth)return 5;if(p<myth+legend)return 4;if(p<myth+legend+epic)return 3;double residual=100-(myth+legend+epic);double lower=residual<=0?1:(p-myth-legend-epic)/residual;return lower<(mutant?.22:.14)+bonus?2:lower<(mutant?.60:.40)+bonus?1:0;}
 public static int clamped(int q){return Math.max(0,Math.min(5,q));}
 public static String name(int q){return new String[]{"común","poco común","raro","épico","legendario","mítico"}[clamped(q)];}
 public static double gunChance(int q){return new double[]{.12,.25,.45,.7,1,1}[clamped(q)];}
 public static int ammoMin(int q){return new int[]{15,24,36,48,64,96}[clamped(q)];}
 public static int ammoMax(int q){return new int[]{32,48,64,96,128,160}[clamped(q)];}
}
'''
for pkg in ['dev.zomboid.hordes','dev.zomboid.integration','dev.zomboid.remains']:
 p=src/Path(pkg.replace('.','/'))/'BalancePolicy.java';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('package '+pkg+';\n'+policy)
p=src/'dev/zomboid/integration/ClothingRules.java';p.write_text('''package dev.zomboid.integration;
public final class ClothingRules {
 public static int kind(double roll,double civilian,double military){military=BalancePolicy.get("zombis_militares",military*100)/100;return !Double.isFinite(roll)||roll<0||roll>=1?0:roll<military?2:roll<Math.min(1,military+civilian)?1:0;}
 public static int quality(int kind,double roll){return Math.max(kind==2?2:kind==1?1:0,BalancePolicy.quality(roll,false));}
}
''')
p=src/'dev/zomboid/integration/loot/LootRules.java';p.write_text('''package dev.zomboid.integration.loot;
public final class LootRules {
 public static int rarity(double roll,double luck,int skill){int lev=Math.max(0,Math.min(10,skill));double effective=Math.max(-2,Math.min(8,luck))+lev*.75;double bonus=Math.max(-.03,Math.min(.12,effective*.012));return dev.zomboid.integration.BalancePolicy.quality(roll,false,bonus+lev*.018);}
 public static boolean near(double d){return Double.isFinite(d)&&d>=0&&d<=9;}
}
''')
shutil.copytree('work/tuning7/stubs',r/'stubs',dirs_exist_ok=True)
p=r/'stubs/net/minecraft/client/gui/screens/Screen.java';t=p.read_text().replace('public void onClose(){}','public void onClose(){}protected void rebuildWidgets(){init();}public boolean mouseScrolled(double x,double y,double hx,double vy){return false;}');p.write_text(t)
p=r/'stubs/org/spongepowered/asm/mixin/injection/At.java';t=p.read_text().replace('String target() default "";','String target() default "";int ordinal() default -1;');p.write_text(t)
p=r/'stubs/org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable.java';t=p.read_text().replace('public double getReturnValueD()','public T getReturnValue(){return null;}public boolean getReturnValueZ(){return false;}public double getReturnValueD()');p.write_text(t)
