import dev.tactical.tacz.ScopeZoom;
public class TestZoom {
 static int checks;static void check(boolean b){checks++;if(!b)throw new AssertionError();}
 public static void main(String[] args){for(double zoom:new double[]{1,2,4,8,12,16}){check(ScopeZoom.wheel(zoom,1)>=zoom);check(ScopeZoom.wheel(zoom,-1)<=zoom);check(ScopeZoom.wheel(zoom,1000)<=16);check(ScopeZoom.wheel(zoom,-1000)>=1);if(zoom>1&&zoom<16)check(Math.abs(ScopeZoom.wheel(ScopeZoom.wheel(zoom,1),-1)-zoom)<1e-8);}check(ScopeZoom.wheel(4,Double.NaN)==4);check(ScopeZoom.adjusted(4,1)==4);check(ScopeZoom.adjusted(4,100)==16);check(ScopeZoom.adjusted(4,.01)==1);System.out.println("PASS "+checks+" zoom checks: direction, bounds, inverse wheel and native zoom unchanged at factor 1");}
}
