from pathlib import Path
import subprocess,zipfile,json,hashlib
r=Path('work/scope121');subprocess.run(['java','com.sun.tools.javac.Main','@'+str(r/'compile.args')],check=True)
base='attachments/bdebabb5-e4f1-4e13-ac5d-4dc7ed7f729e/tacz-tactical-1.2.0-neoforge-1.21.1-authoritative-hitscan.jar'
with zipfile.ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()}
for p in (r/'classes/dev/tactical/tacz').rglob('*.class'):data['dev/tactical/tacz/'+str(p.relative_to(r/'classes/dev/tactical/tacz'))]=p.read_bytes()
j=json.loads(data['tacz_tactical.mixins.json']);j['client']+=['ScopeIndexZoomMixin','ScopeSensitivityMixin'];data['tacz_tactical.mixins.json']=json.dumps(j,indent=2).encode();data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'version="1.2.0"',b'version="1.2.1"')
out=r/'tacz-tactical-1.2.1-neoforge-1.21.1-scope-wheel-sensitivity.jar'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in data.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED']
subprocess.run(['java',*flags,'-cp','work/tools','Verify',str(out)],check=True)
b=out.read_bytes();a={'path':str(out),'remote':'mods/'+out.name,'size':len(b),'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()};(r/'artifacts.json').write_text(json.dumps([a]));print(json.dumps(a))
