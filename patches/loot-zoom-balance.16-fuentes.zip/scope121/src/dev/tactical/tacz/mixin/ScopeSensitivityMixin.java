package dev.tactical.tacz.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(targets="com.tacz.guns.util.math.MathUtil",remap=false)
public abstract class ScopeSensitivityMixin {
 @Inject(method="zoomSensitivityRatio(DDD)D",at=@At("HEAD"),cancellable=true,remap=false)
 private static void scope$sensitivity(double scopedFov,double baseFov,double coefficient,CallbackInfoReturnable<Double> ci){ci.setReturnValue(1d);}
}
