package dev.tactical.tacz.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(targets="com.tacz.guns.client.resource.index.ClientAttachmentIndex",remap=false)
public abstract class ScopeIndexZoomMixin {
 @Inject(method="getZoom()[F",at=@At("RETURN"),cancellable=true,remap=false)
 private void scope$zoom(CallbackInfoReturnable<float[]> ci){ci.setReturnValue(dev.tactical.tacz.ScopeZoom.scale(this,ci.getReturnValue()));}
}
