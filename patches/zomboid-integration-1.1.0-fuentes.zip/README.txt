Zomboid Integration 1.1.0 — linterna y atención médica

INSTALACION
Reemplazar Zomboid Integration 1.0.0 por 1.1.0 en mods de cliente y servidor, sin duplicados. Conservar Flashlight 5.1 corregido + TCTCore, First Aid ZOMBOID 3.4.9 global-health-revival, SurvivorCreator v24 y Quietly v10. No requiere sustituir esos tres JARs.

MEDICINA
Clic derecho en un jugador cercano abre la elección Revisarme / Revisar a [jugador]. Revisarme se habilita si hay lesiones. Se examina durante 30 ticks (1.5 segundos a 20 TPS), con barra; luego se muestran ocho zonas y su estado real del servidor: salud, cortes, disparos, balas alojadas, mordeduras, sangrado, vendaje limpio/sucio, infección, fracturas e inmovilización.
Elegir zona y Vendar / Férula / Extraer bala / Curar. Los materiales se buscan en el inventario del médico y se consumen o desgastan al completar la aplicación. No consume si se interrumpe por distancia, movimiento, daño o pérdida del material. Alcance máximo 3 bloques con visión directa. Esc/cerrar cancela.
Las férulas ya no se aplican automáticamente a la primera pierna: clic derecho con una férula abre el menú propio. Elegir la pierna fracturada y Férula; aplicación base 3 segundos, ajustada por el nivel de First Aid. La fractura queda inmovilizada y conserva la recuperación original de 2400 ticks (2 minutos a 20 TPS), mostrando lo que falta. No se aplica una férula a una zona sana.
La recompensa de First Aid la recibe quien trata, a través de la integración existente de First Aid con SurvivorCreator (3 XP por aplicación válida; las reglas originales omiten creativo/espectador). Examinar no da XP.
Las tijeras extraen una bala por aplicación; los objetos de curación normales mantienen sus curadores originales y su recuperación progresiva.
No permite dos tratamientos de este menú a la vez sobre el mismo paciente. Los tratamientos nativos activos también se comprueban antes de aplicar.

LINTERNAS
Conserva X, tecla configurable, luz desde inventario y luz en objetos tirados, con estado persistido por la variante encendida/apagada del objeto. El clic derecho no cambia el estado. Las reglas normales de desaparición de objetos tirados se mantienen.

VALIDACION
22 pruebas de distancia, interrupción y valores de paquete; 10 pruebas con el código real de heridas de First Aid; 20 pruebas de linterna/colocación segura conservadas. Bytecode y ZIP verificados. No se realizó una prueba dentro de Minecraft ni una sesión LAN real; esas pruebas siguen pendientes.
