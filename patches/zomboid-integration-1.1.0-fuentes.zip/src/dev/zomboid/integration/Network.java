package dev.zomboid.integration;
import net.minecraft.resources.ResourceLocation;import net.minecraft.network.RegistryFriendlyByteBuf;import net.minecraft.network.codec.StreamCodec;import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
public final class Network {
 public record Toggle() implements CustomPacketPayload{public static final Toggle INSTANCE=new Toggle();public static final Type<Toggle> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("zomboid_integration","toggle_lamp"));public static final StreamCodec<RegistryFriendlyByteBuf,Toggle> CODEC=StreamCodec.unit(INSTANCE);public Type<Toggle> type(){return TYPE;}}
 @net.neoforged.fml.common.EventBusSubscriber(modid="zomboid_integration",bus=net.neoforged.fml.common.EventBusSubscriber.Bus.MOD)
 public static final class Registration{
 @net.neoforged.bus.api.SubscribeEvent public static void register(net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent e){e.registrar("1").playToServer(Toggle.TYPE,Toggle.CODEC,(packet,context)->context.enqueueWork(()->{if(context.player() instanceof net.minecraft.server.level.ServerPlayer p)Lamps.toggle(p);}));}
 }
}
