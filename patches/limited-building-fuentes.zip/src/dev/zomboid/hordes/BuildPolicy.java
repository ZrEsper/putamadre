package dev.zomboid.hordes;
public final class BuildPolicy {
 public static boolean elevated(double rise,double horizontal){return Double.isFinite(rise)&&Double.isFinite(horizontal)&&rise>=2.5&&rise<=16&&horizontal>=0&&horizontal<=12;}
 public static boolean allowed(double rise,double horizontal,long blocked,int built,int budget){return elevated(rise,horizontal)&&blocked>=40&&built<Math.min(24,budget);}
}
