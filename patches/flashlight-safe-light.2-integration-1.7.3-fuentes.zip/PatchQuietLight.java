import java.nio.file.*;import java.util.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public class PatchQuietLight implements Opcodes {
 static int writes,neighbors,analog;
 static byte[] patch(String path,byte[] bytes){ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);
 for(MethodNode m:c.methods){
 if(path.equals("net/flashlight/block/FlashlightLightBlock.class")&&m.name.equals("hasAnalogOutputSignal")){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new InsnNode(ICONST_0));m.instructions.add(new InsnNode(IRETURN));analog++;}
 for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof MethodInsnNode call){
 if(call.name.equals("setBlock")&&call.desc.equals("(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z")){InsnList quiet=new InsnList();quiet.add(new InsnNode(POP));quiet.add(new IntInsnNode(BIPUSH,18));m.instructions.insertBefore(n,quiet);writes++;}
 if(call.name.equals("updateNeighbourForOutputSignal")&&path.equals("net/flashlight/block/FlashlightLightBlock.class")){InsnList discard=new InsnList();discard.add(new InsnNode(POP));discard.add(new InsnNode(POP));discard.add(new InsnNode(POP));m.instructions.insertBefore(n,discard);m.instructions.remove(n);neighbors++;}
 }}ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);return w.toByteArray();}
 public static void main(String[] a)throws Exception {boolean integration=a[2].equals("integration");Set<String> changed=integration?Set.of("dev/zomboid/integration/Lamps.class"):Set.of("net/flashlight/procedures/SafeLight.class","net/flashlight/procedures/EndLightProcedure.class","net/flashlight/block/FlashlightLightBlock.class");
 try(ZipFile z=new ZipFile(a[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(a[1])))){var entries=z.entries();while(entries.hasMoreElements()){ZipEntry e=entries.nextElement();byte[] b=z.getInputStream(e).readAllBytes();if(changed.contains(e.getName()))b=patch(e.getName(),b);if(integration&&e.getName().equals("META-INF/neoforge.mods.toml"))b=new String(b,java.nio.charset.StandardCharsets.UTF_8).replace("1.7.1","1.7.2").getBytes(java.nio.charset.StandardCharsets.UTF_8);out.putNextEntry(new ZipEntry(e.getName()));out.write(b);out.closeEntry();}}
 if(writes!=(integration?1:4)||neighbors!=(integration?0:1)||analog!=(integration?0:1))throw new IllegalStateException("Unexpected patch counts");System.out.println("Quiet light writes="+writes+", removed neighbor notifications="+neighbors+", disabled analog signal="+analog);
 }
}
