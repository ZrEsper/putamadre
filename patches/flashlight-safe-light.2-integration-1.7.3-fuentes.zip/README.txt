Flashlight safe-light.2 + Zomboid Integration 1.7.3

Reemplazar Flashlight safe-light.1 y Zomboid Integration anterior por los dos nuevos JAR, tanto en cliente como en servidor. No conservar copias duplicadas.

Causa: proteger el bloque objetivo no basta. Las luces temporales antes usaban setBlock(...,3); sus actualizaciones vecinas y de forma hacian que plantas decorativas invalidas del mapa comprobaran su soporte y se rompieran.

Parche: colocacion y desaparicion usan flags 18 (UPDATE_CLIENTS | UPDATE_KNOWN_SHAPE): se sincroniza y recalcula luz sin notificaciones vecinas ni actualizaciones de forma. La limpieza del bloque de luz deja de notificar comparadores/vecinos. Su falsa salida analogica queda desactivada. Tambien se cambia la colocacion de luz en Lamps de Integration. Se conserva la proteccion para no reemplazar plantas, agua o paredes y la posicion junto a paredes. Integration conserva las funciones de 1.7.1, incluida ropa y loot militar.

Alcance: evita estas actualizaciones generadas por la linterna. Ademas, Integration 1.7.3 protege hierba corta, hierba alta, helechos pequenos/grandes y arbustos secos frente a soporte invalido, independientemente de la linterna. Las mitades superiores mantienen la validacion vanilla para no quedar separadas de su mitad inferior. Flores, cultivos y otros bloques no cambian. Los golpes directos o destruccion explicita de otro mod siguen pudiendo retirarlas. No recrea hierba previamente rota.

Validacion: 20 pruebas simuladas de seis caras de pared, posiciones sin impacto, no reemplazo de plantas/agua/piedra y conservacion de hierba vecina ante colocacion. Verificacion de bytecode de ambos JAR y comprobacion CRC. 9 pruebas simuladas adicionales de proteccion de plantas, exclusiones y mitades superiores. No ejecutado en Minecraft; falta probarlo en el mapa.

Fuentes: PatchQuietLight.java aplica el parche ASM a los JAR Flashlight safe-light.1 y Integration 1.7.1; argumento tercero flashlight o integration. Java21, JDK internal ASM exports para asm y asm.tree. testsrc contiene API mocks solo para pruebas, nunca incluir en los mods. Lamps.java es la fuente actualizada de la integracion.

Para reproducir Integration 1.7.3: aplicar PatchQuietLight sobre 1.7.1 como paso intermedio 1.7.2; compilar src/ con classpath de desarrollo Minecraft/NeoForge/Mixin y NativeAccess de Integration; ejecutar PackageGrass.py con el intermedio, directorio compilado y JAR final. No incluir stubs.
