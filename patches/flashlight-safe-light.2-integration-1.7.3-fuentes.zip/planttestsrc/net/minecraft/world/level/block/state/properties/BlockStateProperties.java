package net.minecraft.world.level.block.state.properties;public class BlockStateProperties {public static final Object DOUBLE_BLOCK_HALF=new Object();}
