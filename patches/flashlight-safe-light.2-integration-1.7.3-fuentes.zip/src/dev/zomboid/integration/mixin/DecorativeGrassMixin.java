package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;import net.minecraft.world.level.block.state.BlockState;import net.minecraft.world.level.LevelReader;import net.minecraft.core.BlockPos;import dev.zomboid.integration.DecorativePlants;
@Mixin(targets="net.minecraft.world.level.block.BushBlock")
public abstract class DecorativeGrassMixin {
 @Inject(method="canSurvive(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelReader;Lnet/minecraft/core/BlockPos;)Z",at=@At("HEAD"),cancellable=true)
 private void zi$keepGrass(BlockState state,LevelReader level,BlockPos pos,CallbackInfoReturnable<Boolean> ci){if(DecorativePlants.keep(state))ci.setReturnValue(true);}
}
