package dev.zomboid.integration;
import java.util.*;
/** Preserve the map's decorative vanilla grasses without touching flowers/crops. */
public final class DecorativePlants {
 private static final Set<Object> GRASSES=Collections.newSetFromMap(new IdentityHashMap<>());
 private static final Object HALF;
 static {try{Class<?> blocks=Class.forName("net.minecraft.world.level.block.Blocks");for(String name:List.of("SHORT_GRASS","TALL_GRASS","FERN","LARGE_FERN","DEAD_BUSH"))GRASSES.add(blocks.getField(name).get(null));HALF=Class.forName("net.minecraft.world.level.block.state.properties.BlockStateProperties").getField("DOUBLE_BLOCK_HALF").get(null);}catch(ReflectiveOperationException e){throw new ExceptionInInitializerError(e);}}
 public static boolean keep(Object state){try{if(!GRASSES.contains(NativeAccess.call(state,"getBlock")))return false;if(Boolean.TRUE.equals(NativeAccess.call(state,"hasProperty",HALF)))return NativeAccess.call(state,"getValue",HALF).toString().equalsIgnoreCase("lower");return true;}catch(ReflectiveOperationException e){throw new IllegalStateException("Decorative grass support",e);}}
}
