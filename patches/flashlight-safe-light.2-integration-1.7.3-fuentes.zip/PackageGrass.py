from pathlib import Path
import zipfile,json,sys
# Usage: python PackageGrass.py patched-integration1.7.2.jar compiled-helper-dir output1.7.3.jar
with zipfile.ZipFile(sys.argv[1]) as z,zipfile.ZipFile(sys.argv[3],'w',zipfile.ZIP_DEFLATED) as o:
 for entry in z.infolist():
  data=z.read(entry)
  if entry.filename=='META-INF/neoforge.mods.toml':data=data.replace(b'1.7.2',b'1.7.3')
  if entry.filename=='zomboid_integration.mixins.json':
   config=json.loads(data);config['mixins']+=['DecorativeGrassMixin','DecorativeTallGrassMixin'];data=json.dumps(config,indent=2).encode()
  o.writestr(entry,data)
 root=Path(sys.argv[2])
 for p in (root/'dev').rglob('*.class'):o.write(p,p.relative_to(root).as_posix())
