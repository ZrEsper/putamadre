package dev.zomboid.integration;
import net.flashlight.init.FlashlightModItems;
import net.flashlight.init.FlashlightModBlocks;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.network.chat.Component;
import java.util.HashSet;
@net.neoforged.fml.common.EventBusSubscriber(modid="zomboid_integration")
public final class Lamps {
 public static boolean isLamp(ItemStack s){return !s.isEmpty()&&(s.getItem()==FlashlightModItems.FLASHLIGHT.get()||s.getItem()==FlashlightModItems.FLASHLIGHT_OFF.get());}
 public static boolean lit(ItemStack s){return !s.isEmpty()&&s.getItem()==FlashlightModItems.FLASHLIGHT.get();}
 public static ItemStack swapped(ItemStack s){ItemStack replacement=new ItemStack(lit(s)?FlashlightModItems.FLASHLIGHT_OFF.get():FlashlightModItems.FLASHLIGHT.get(),s.getCount());replacement.applyComponents(s.getComponentsPatch());return replacement;}
 public static int selected(Player p){
  int main=p.getInventory().selected;
  if(isLamp(p.getInventory().getItem(main)))return main;
  if(isLamp(p.getOffhandItem()))return 40;
  for(int i=0;i<36;i++)if(isLamp(p.getInventory().getItem(i)))return i;
  return -1;
 }
 public static void toggle(ServerPlayer p){
  if(!p.isAlive()||p.isSpectator())return;
  long now=p.level().getGameTime();var data=p.getPersistentData();
  if(data.contains("zi_last_toggle")&&now-data.getLong("zi_last_toggle")<4)return;
  data.putLong("zi_last_toggle",now);
  int slot=selected(p);if(slot<0){p.displayClientMessage(Component.translatable("zomboid_integration.no_lamp"),true);return;}
  ItemStack old=p.getInventory().getItem(slot);
  // Keep the original player's battery gate when turning the flashlight on.
  if(!lit(old)&&p.getData(net.flashlight.network.FlashlightModVariables.PLAYER_VARIABLES).BatteryFlashlight<0){p.displayClientMessage(Component.translatable("zomboid_integration.empty_battery"),true);return;}
  ItemStack replacement=swapped(old);p.getInventory().setItem(slot,replacement);p.getInventory().setChanged();p.containerMenu.broadcastChanges();
  p.displayClientMessage(Component.translatable(lit(replacement)?"zomboid_integration.on":"zomboid_integration.off"),true);
  p.playSound(lit(replacement)?net.flashlight.init.FlashlightModSounds.FLASHLIGHT_CLICKING_ON.get():net.flashlight.init.FlashlightModSounds.FLASHLIGHT_CLICKING_OFF.get(),.5f,1);
 }
 @net.neoforged.bus.api.SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.EntityTickEvent.Post e){
  Entity entity=e.getEntity();if(entity.level().isClientSide||entity.isRemoved()||entity.tickCount%2!=0)return;
  if(entity instanceof Player p){if(!p.isAlive()||p.isSpectator())return;boolean on=false;for(int i=0;i<p.getInventory().getContainerSize();i++)if(lit(p.getInventory().getItem(i))){on=true;break;}if(on)beam(p,p.getEyePosition(1),p.getViewVector(1),25);}
  else if(entity instanceof ItemEntity item&&lit(item.getItem())){
   Vec3 start=item.position().add(0,.2,0);var d=item.getPersistentData();Vec3 dir=d.contains("zi_dx")?new Vec3(d.getDouble("zi_dx"),d.getDouble("zi_dy"),d.getDouble("zi_dz")):new Vec3(0,0,1);
   beam(item,start,dir,25);
  }
 }
 @net.neoforged.bus.api.SubscribeEvent public static void tossed(net.neoforged.neoforge.event.entity.item.ItemTossEvent e){
  ItemEntity item=e.getEntity();if(item.level().isClientSide||!isLamp(item.getItem()))return;
  Vec3 v=e.getPlayer().getViewVector(1);var d=item.getPersistentData();d.putDouble("zi_dx",v.x);d.putDouble("zi_dy",v.y);d.putDouble("zi_dz",v.z);
 }
 private static void beam(Entity owner,Vec3 start,Vec3 dir,int range){
  Level level=owner.level();HashSet<BlockPos> placed=new HashSet<>();
  // Two local samples keep a dropped lamp visible even beside grass or a wall.
  add(level,BlockPos.containing(start.x,start.y,start.z),placed);
  add(level,BlockPos.containing(start.x,start.y+1,start.z),placed);
  BlockHitResult hit=level.clip(new ClipContext(start,start.add(dir.scale(range)),ClipContext.Block.OUTLINE,ClipContext.Fluid.NONE,owner));
  double end=hit.getType()==HitResult.Type.MISS?range:Math.sqrt(start.distanceToSqr(hit.getLocation()));
  for(double distance=1;distance<end;distance+=2){Vec3 v=start.add(dir.scale(distance));add(level,BlockPos.containing(v.x,v.y,v.z),placed);}
  if(hit.getType()!=HitResult.Type.MISS)add(level,hit.getBlockPos().relative(hit.getDirection()),placed);
 }
 private static void add(Level l,BlockPos p,HashSet<BlockPos> placed){
  if(!placed.add(p)||!l.hasChunkAt(p))return;BlockState old=l.getBlockState(p);var light=FlashlightModBlocks.FLASHLIGHT_LIGHT.get();
  if(!old.isAir()&&!old.is(light))return;
  if(old.isAir()&&!l.setBlock(p,light.defaultBlockState(),3))return;
  var block=l.getBlockEntity(p);if(block!=null)block.getPersistentData().putDouble("Delay",5);
 }
}
