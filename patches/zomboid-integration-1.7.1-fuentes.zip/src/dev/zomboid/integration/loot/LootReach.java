package dev.zomboid.integration.loot;
import dev.zomboid.scavenging.R;
public final class LootReach {
 public static Object target(Object event,boolean entity){return entity?R.call(R.type("dev.zomboid.scavenging.Search"),"entityTarget",R.call(event,"getTarget")):R.call(R.type("dev.zomboid.scavenging.Search"),"target",R.call(event,"getLevel"),R.call(event,"getPos"));}
 public static boolean near(Object player,Object target){if(target==null)return true;Object entity=R.get(target,"entity"), pos=R.get(target,"pos");Object distance=entity!=null?R.call(player,"distanceToSqr",entity):R.call(player,"distanceToSqr",R.coord(pos,"X")+.5,R.coord(pos,"Y")+.5,R.coord(pos,"Z")+.5);return distance instanceof Number n&&LootRules.near(n.doubleValue());}
 public static boolean job(Object job){return near(R.get(job,"player"),R.get(job,"target"));}
 public static void message(Object player){Object text=R.call(R.type("net.minecraft.network.chat.Component"),"literal","Acércate para abrir el contenedor o cadáver (máximo 3 bloques).");R.call(player,"displayClientMessage",text,true);}
 public static boolean event(Object event,boolean entity){Object player=R.call(event,"getEntity"),level=R.call(player,"level");if(R.yes(R.call(level,"isClientSide")))return false;Object target=target(event,entity);if(target!=null&&!near(player,target)){R.call(event,"setCanceled",true);message(player);return true;}return false;}
}
