package dev.zomboid.integration.loot;
/** Recognize actual storage inheritance without loading an optional mod on absent installations. */
public final class StorageTypes {
 private StorageTypes() {}
 public static boolean supported(Object value){
  if(value==null)return false;
  for(Class<?> type=value.getClass();type!=null;type=type.getSuperclass())
   if(type.getName().equals("net.p3pp3rf1y.sophisticatedstorage.block.StorageBlockEntity"))return true;
  return false;
 }
}
