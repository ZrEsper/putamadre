package dev.zomboid.integration.loot;
public final class LootRules {
 public static int rarity(double roll,double luck,int skill){int lev=Math.max(0,Math.min(10,skill));double effective=Math.max(-2,Math.min(8,luck))+lev*.75;double bonus=Math.max(-.03,Math.min(.12,effective*.012));if(roll<(.002+bonus*.04+lev*.001)*.2)return 4;if(roll<(.02+bonus*.2+lev*.006)*.2)return 3;if(roll<.1+bonus*.55+lev*.018)return 2;if(roll<.3+bonus+lev*.03)return 1;return 0;}
 public static boolean near(double distanceSquared){return Double.isFinite(distanceSquared)&&distanceSquared>=0&&distanceSquared<=9;}
}
