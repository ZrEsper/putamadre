package dev.zomboid.integration;
import java.nio.file.*;import java.io.*;import java.util.*;import java.lang.reflect.*;
import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.SubscribeEvent;
@EventBusSubscriber(modid="zomboid_integration")
public final class ChunkArea {
 private static final Map<Object,Policy> POLICIES=new IdentityHashMap<>();
 private static final Map<net.minecraft.world.level.Level,Policy> LEVEL_POLICIES=new IdentityHashMap<>();
 private static final class Policy{Path file;int view=12,simulation=3,desiredView,desiredSimulation;boolean enabled=true,virtualize=true,internal;long modified=Long.MIN_VALUE;int ticks;}
 private static Object invoke(Object target,String method,Object...args)throws ReflectiveOperationException{
  for(Method m:target.getClass().getMethods())if(m.getName().equals(method)&&m.getParameterCount()==args.length)return m.invoke(target,args);
  throw new NoSuchMethodException(method);
 }
 public static boolean virtualization(net.minecraft.world.level.Level level){
  Policy cached=LEVEL_POLICIES.get(level);if(cached!=null)return cached.virtualize;
  try{Object server=NativeAccess.call(level,"getServer"),list=NativeAccess.call(server,"getPlayerList");Policy policy=POLICIES.get(list);if(policy!=null){LEVEL_POLICIES.put(level,policy);return policy.virtualize;}}catch(ReflectiveOperationException ignored){}
  return true;
 }
 @SubscribeEvent public static void start(net.neoforged.neoforge.event.server.ServerStartedEvent event){
  try{
   Object server=event.getServer(),list=invoke(server,"getPlayerList");Policy policy=new Policy();
   Class<?> resource=Class.forName("net.minecraft.world.level.storage.LevelResource");Object root=resource.getField("ROOT").get(null);
   Path world=(Path)invoke(server,"getWorldPath",root);policy.file=world.resolve("serverconfig/zomboid-integration-chunk-area.properties");
   policy.desiredView=((Number)invoke(list,"getViewDistance")).intValue();policy.desiredSimulation=((Number)invoke(list,"getSimulationDistance")).intValue();
   load(policy);POLICIES.put(list,policy);apply(list,policy);
  }catch(ReflectiveOperationException|IOException|RuntimeException failure){System.err.println("[Zomboid Integration] Chunk area was not enabled: "+failure);}
 }
 private static void load(Policy p)throws IOException{
  Properties props=new Properties();
  if(Files.exists(p.file)){try(InputStream in=Files.newInputStream(p.file)){props.load(in);}}
  else{props.setProperty("enabled","true");props.setProperty("view-radius","12");props.setProperty("simulation-radius","3");Files.createDirectories(p.file.getParent());try(OutputStream out=Files.newOutputStream(p.file)){props.store(out,"Per-world native chunk loading cap. Radius 3 is approximately 7x7 chunks. Forced chunks are not removed. Changes reload within 10 seconds.");}}
  if(!props.containsKey("zombie-virtualization")){props.setProperty("zombie-virtualization","true");if(props.getProperty("view-radius","3").equals("3"))props.setProperty("view-radius","12");try(OutputStream out=Files.newOutputStream(p.file)){props.store(out,"Landscape radius 12; simulation radius 3; zombies sleep separately.");}}
  boolean enabled=Boolean.parseBoolean(props.getProperty("enabled","true"));int view=Integer.parseInt(props.getProperty("view-radius","12")),sim=Integer.parseInt(props.getProperty("simulation-radius","3"));
  if(view<2||view>32||sim<2||sim>32)throw new IllegalArgumentException("Chunk radii must be 2..32");
  p.enabled=enabled;p.virtualize=Boolean.parseBoolean(props.getProperty("zombie-virtualization","true"));p.view=view;p.simulation=Math.min(sim,view);p.modified=Files.getLastModifiedTime(p.file).toMillis();
 }
 private static void apply(Object list,Policy p)throws ReflectiveOperationException{
  p.internal=true;
  try{invoke(list,"setViewDistance",p.enabled?Math.min(p.desiredView,p.view):p.desiredView);invoke(list,"setSimulationDistance",p.enabled?Math.min(p.desiredSimulation,p.simulation):p.desiredSimulation);}
  finally{p.internal=false;}
  System.out.println("[Zomboid Integration] Native chunk area: enabled="+p.enabled+", view-radius="+p.view+", simulation-radius="+p.simulation+". Distant chunks save/unload normally; forced chunks remain.");
 }
 /** Called before native setters; suppress redundant integrated-server requests instead of resending chunks every tick. */
 public static boolean intercept(Object list,int requested,boolean simulation){
  Policy p=POLICIES.get(list);if(p==null||p.internal)return false;
  if(simulation)p.desiredSimulation=requested;else p.desiredView=requested;
  if(!p.enabled)return false;int capped=Math.min(requested,simulation?p.simulation:p.view);if(capped==requested)return false;
  try{int current=((Number)invoke(list,simulation?"getSimulationDistance":"getViewDistance")).intValue();
   if(current!=capped){p.internal=true;try{invoke(list,simulation?"setSimulationDistance":"setViewDistance",capped);}finally{p.internal=false;}}
   return true;
  }catch(ReflectiveOperationException|RuntimeException failure){System.err.println("[Zomboid Integration] Native chunk cap fallback: "+failure);p.enabled=false;return false;}
 }
 @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.ServerTickEvent.Post event){
  for(var entry:POLICIES.entrySet()){Policy p=entry.getValue();if(++p.ticks%200!=0)continue;
   try{if(Files.getLastModifiedTime(p.file).toMillis()!=p.modified){load(p);apply(entry.getKey(),p);}}
   catch(IOException|ReflectiveOperationException|RuntimeException failure){System.err.println("[Zomboid Integration] Could not reload chunk area settings: "+failure);}
  }
 }
 @SubscribeEvent public static void stop(net.neoforged.neoforge.event.server.ServerStoppedEvent event){POLICIES.clear();LEVEL_POLICIES.clear();}
}
