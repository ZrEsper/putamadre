package dev.zomboid.integration.combat;
import java.lang.ref.WeakReference;import java.lang.reflect.Field;
import net.minecraft.world.entity.Entity;import net.minecraft.world.entity.player.Player;
public final class TongueRules {
 private static final ClassValue<Field> VICTIM=new ClassValue<>(){protected Field computeValue(Class<?> c){try{Field f=c.getDeclaredField("victim");f.setAccessible(true);return f;}catch(ReflectiveOperationException e){throw new IllegalStateException("Unsupported tongue link",e);}}};
 public static Object victim(Object link){try{return ((WeakReference<?>)VICTIM.get(link.getClass()).get(link)).get();}catch(IllegalAccessException e){throw new IllegalStateException(e);}}
 public static boolean allowed(Player player,Entity target){return !player.level().isClientSide&&player.level()==target.level()&&dev.zomboid.mutants.Combat.valid(player)&&player.distanceToSqr(target)<=36&&player.hasLineOfSight(target);}
}
