package dev.zomboid.integration;
import java.util.*;import java.nio.file.*;import java.io.*;import java.lang.reflect.*;
import net.minecraft.world.entity.Entity;import net.minecraft.world.entity.Mob;import net.minecraft.world.item.Item;import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.SubscribeEvent;import net.neoforged.bus.api.EventPriority;
@EventBusSubscriber(modid="zomboid_integration")
public final class ZombieClothing {
 private static final String MARK="zi_zombie_clothing_v1";
 private static Object registry;private static Class<?> armor;private static List<Object> slots;
 private static final Map<String,Map<Object,List<Item>>> CIVIL=new LinkedHashMap<>(),MILITARY=new LinkedHashMap<>();
 private static final Map<Path,double[]> SETTINGS=new HashMap<>();private static boolean changing;
 private static final String[] CIVIL_PREFIX={"courier","official","researcher","diplomatic","survivor","wanderer","tropic","hacker","blue_coat"};
 private static final String[] MILITARY_PREFIX={"ratnik","beta7","soviet","nato","insurgency","ru","sso","fsb","iz","killa","tagilla"};
 private ZombieClothing(){}
 private static void cache()throws ReflectiveOperationException{
  if(registry!=null)return;registry=Class.forName("net.minecraft.core.registries.BuiltInRegistries").getField("ITEM").get(null);armor=Class.forName("net.minecraft.world.item.ArmorItem");slots=new ArrayList<>();
  Class<?> slot=Class.forName("net.minecraft.world.entity.EquipmentSlot");for(String name:new String[]{"HEAD","CHEST","LEGS","FEET"})slots.add(slot.getField(name).get(null));
  for(Object value:(Iterable<?>)registry){if(!armor.isInstance(value))continue;String id=String.valueOf(NativeAccess.call(registry,"getKey",value));String[] split=id.split(":",2);if(split.length!=2)continue;
   Map<String,Map<Object,List<Item>>> pool=split[0].equals("selfexpression")?CIVIL:split[0].equals("fracturepoint")?MILITARY:null;if(pool==null)continue;
   String group=null;for(String prefix:pool==CIVIL?CIVIL_PREFIX:MILITARY_PREFIX)if(split[1].startsWith(prefix+"_")||split[1].startsWith(prefix)){group=prefix;break;}if(group==null)continue;
   if(pool==MILITARY&&(split[1].contains("backpack")||split[1].contains("shoulderpads")||split[1].contains("uniform")))continue;
   Object equipment;try{equipment=NativeAccess.call(value,"getEquipmentSlot");}catch(NoSuchMethodException absent){equipment=NativeAccess.call(NativeAccess.call(value,"getType"),"getSlot");}
   if(!slots.contains(equipment))continue;pool.computeIfAbsent(group,k->new LinkedHashMap<>()).computeIfAbsent(equipment,k->new ArrayList<>()).add((Item)value);
  }
 }
 public static String id(ItemStack stack)throws ReflectiveOperationException{cache();return String.valueOf(NativeAccess.call(registry,"getKey",stack.getItem()));}
 public static ItemStack stack(String id,int count)throws ReflectiveOperationException{
  cache();Object resource=net.minecraft.resources.ResourceLocation.parse(id);Item item=(Item)NativeAccess.call(registry,"get",resource);ItemStack stack=new ItemStack(item,count);if(id(stack).equals("minecraft:air"))return ItemStack.EMPTY;return stack;
 }
 public static boolean vanillaArmor(ItemStack stack)throws ReflectiveOperationException{return !stack.isEmpty()&&id(stack).startsWith("minecraft:")&&(armor.isInstance(stack.getItem())||id(stack).equals("minecraft:elytra"));}
 public static boolean disallow(Object slot,ItemStack stack){if(stack.isEmpty())return false;try{cache();return slots.contains(slot)&&vanillaArmor(stack);}catch(ReflectiveOperationException error){return false;}}
 public static int worn(Entity entity)throws ReflectiveOperationException{
  cache();int kind=0;for(Object slot:slots){ItemStack stack=(ItemStack)NativeAccess.call(entity,"getItemBySlot",slot);if(stack.isEmpty())continue;String name=id(stack);if(name.startsWith("fracturepoint:")&&armor.isInstance(stack.getItem()))return 2;if(name.startsWith("selfexpression:")&&armor.isInstance(stack.getItem()))kind=1;}return kind;
 }
 private static double[] settings(Entity entity)throws Exception{
  Object server=NativeAccess.call(entity.level(),"getServer");Class<?> resource=Class.forName("net.minecraft.world.level.storage.LevelResource");Path root=(Path)NativeAccess.call(server,"getWorldPath",resource.getField("ROOT").get(null));Path path=root.resolve("serverconfig/zomboid-zombie-clothing.properties");double[] known=SETTINGS.get(path);if(known!=null)return known;
  Properties p=new Properties();if(Files.exists(path)){try(InputStream in=Files.newInputStream(path)){p.load(in);}}else{p.setProperty("civilian-chance","0.06");p.setProperty("military-chance","0.003");Files.createDirectories(path.getParent());try(OutputStream out=Files.newOutputStream(path)){p.store(out,"Civilian Self Expression / rare military Fracture Point. Restart world after editing. Probabilities add, not multiply.");}}
  double civil=Double.parseDouble(p.getProperty("civilian-chance","0.06")),mil=Double.parseDouble(p.getProperty("military-chance","0.003"));if(!Double.isFinite(civil)||!Double.isFinite(mil)||civil<0||mil<0||civil+mil>1)throw new IllegalArgumentException("Invalid zombie clothing chances");double[] result={civil,mil};SETTINGS.put(path,result);return result;
 }
 private static double random(Entity e)throws ReflectiveOperationException{return ((Number)NativeAccess.call(NativeAccess.call(e,"getRandom"),"nextDouble")).doubleValue();}
 private static int pick(Entity e,int size)throws ReflectiveOperationException{return ((Number)NativeAccess.call(NativeAccess.call(e,"getRandom"),"nextInt",size)).intValue();}
 private static void clean(Entity e)throws ReflectiveOperationException{cache();for(Object slot:slots){ItemStack current=(ItemStack)NativeAccess.call(e,"getItemBySlot",slot);if(vanillaArmor(current))NativeAccess.call(e,"setItemSlot",slot,ItemStack.EMPTY);}}
 private static boolean dress(Entity e,int kind)throws ReflectiveOperationException{
  var pool=kind==2?MILITARY:CIVIL;if(pool.isEmpty())return false;List<Map<Object,List<Item>>> outfits=new ArrayList<>(pool.values()).stream().filter(m->m.containsKey(slots.get(1))).toList();if(outfits.isEmpty())return false;var outfit=outfits.get(pick(e,outfits.size()));boolean equipped=false;
  for(int i=0;i<slots.size();i++){Object slot=slots.get(i);List<Item> items=outfit.get(slot);if(items==null||items.isEmpty())continue;
   if(i!=1&&random(e)>(kind==2?.8:i==0?.4:.65))continue;
   NativeAccess.call(e,"setItemSlot",slot,new ItemStack(items.get(pick(e,items.size())),1));NativeAccess.call(e,"setDropChance",slot,kind==2?1f:.4f);equipped=true;
  }
  return equipped;
 }
 @SubscribeEvent(priority=EventPriority.LOWEST) public static void join(net.neoforged.neoforge.event.entity.EntityJoinLevelEvent event){
  Entity e=event.getEntity();if(e.level().isClientSide||!ZombieSleep.zombie(e))return;
  try{clean(e);var tag=e.getPersistentData();if(tag.getBoolean(MARK))return;int existing=worn(e);double[] probability=settings(e);int kind=existing>0?existing:ClothingRules.kind(random(e),probability[0],probability[1]);if(existing==0&&kind>0&&!dress(e,kind))kind=0;
   if(kind==2)MilitaryLoot.arm((Mob)e);tag.putBoolean(MARK,true);tag.putInt("zi_zombie_clothing_kind",kind);
  }catch(Exception|LinkageError error){System.err.println("[Zomboid Integration] Zombie clothing setup failed: "+error);}
 }
 @SubscribeEvent public static void equipment(net.neoforged.neoforge.event.entity.living.LivingEquipmentChangeEvent event){
  Entity e=event.getEntity();if(changing||e.level().isClientSide||!ZombieSleep.zombie(e))return;
  changing=true;try{clean(e);}catch(ReflectiveOperationException error){System.err.println("[Zomboid Integration] Vanilla zombie armor removal failed: "+error);}finally{changing=false;}
 }
 @SubscribeEvent(priority=EventPriority.LOWEST) public static void death(net.neoforged.neoforge.event.entity.living.LivingDeathEvent event){Entity e=event.getEntity();if(e.level().isClientSide||!ZombieSleep.zombie(e))return;try{e.getPersistentData().putInt("zi_zombie_worn_at_death",worn(e));}catch(ReflectiveOperationException error){System.err.println("[Zomboid Integration] Zombie clothing death snapshot failed: "+error);}}
 @SubscribeEvent public static void stop(net.neoforged.neoforge.event.server.ServerStoppedEvent event){SETTINGS.clear();registry=null;slots=null;CIVIL.clear();MILITARY.clear();}
}
