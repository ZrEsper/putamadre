package dev.zomboid.integration;
import java.lang.reflect.Field;
/** Use the existing TAN enableThirst switch when Homeostatic owns hydration. */
public final class TanHydration {
 private static boolean resolved,present,failed,logged;
 private static Field config,enabled;
 private TanHydration(){}
 public static boolean useHomeostatic(){
  if(!resolved){resolved=true;try{Class.forName("homeostatic.common.attachments.WaterData",false,TanHydration.class.getClassLoader());present=true;}catch(ClassNotFoundException|LinkageError absent){present=false;}}
  return present;
 }
 public static void disableDuplicate(){
  if(!useHomeostatic()||failed)return;
  try{
   if(config==null){config=Class.forName("toughasnails.init.ModConfig").getField("thirst");enabled=Class.forName("toughasnails.config.ThirstConfig").getField("enableThirst");}
   Object instance=config.get(null);if(instance==null)return;
   enabled.setBoolean(instance,false);
   if(!logged){logged=true;System.out.println("[Zomboid Integration] Homeostatic controls hydration; duplicate Tough As Nails thirst disabled.");}
  }catch(ReflectiveOperationException|RuntimeException|LinkageError failure){failed=true;System.err.println("[Zomboid Integration] Could not disable duplicate TAN thirst: "+failure);}
 }
}
