package dev.zomboid.integration.client;
import java.util.Set;
public final class KeyRules {public static boolean collides(int core,int health,int giveUp){return core>=0&&(core==health||core==giveUp);}public static int free(Set<Integer> used){for(int code:new int[]{297,298,299,296,300,295,301,294,293,292,291,290})if(!used.contains(code))return code;return -1;}}
