package dev.zomboid.integration.client;
public final class PressEdge {
 private boolean down;
 public boolean tick(boolean physical,boolean queued,boolean allowed){if(!allowed){down=physical;return false;}boolean now=physical||queued;boolean fire=now&&!down;down=now;return fire;}
}
