package dev.zomboid.integration.client;
import java.lang.reflect.Method;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
/** The exact attachment accessor used by First Aid, sampled anew for each HUD frame. */
public final class WaterDrops {
 private static Method data,level,force,position,globe,offsetX,offsetY,x,y;
 private static boolean initialized,disabled;
 private static final ResourceLocation ICONS=ResourceLocation.fromNamespaceAndPath("homeostatic","textures/gui/icons.png");
 private WaterDrops(){}
 public static boolean render(GuiGraphics graphics,Minecraft mc,int width,int height){
  if(disabled||mc.player==null)return false;
  try{
   if(!initialized){
    data=Class.forName("homeostatic.common.attachments.WaterData").getMethod("getData",Player.class);
    level=Class.forName("homeostatic.network.Water").getMethod("getWaterLevel");
    Class<?> config=Class.forName("homeostatic.config.ConfigHandler$Client");
    force=config.getMethod("forceWaterBarPosition");position=config.getMethod("waterBarPosition");globe=config.getMethod("globePosition");
    offsetX=config.getMethod("waterBarOffsetX");offsetY=config.getMethod("waterBarOffsetY");
    Class<?> alignment=Class.forName("homeostatic.util.Alignment"),type=Class.forName("homeostatic.util.Alignment$AlignmentType");
    x=alignment.getMethod("getX",type,int.class,int.class,int.class);y=alignment.getMethod("getY",type,int.class,int.class);
    initialized=true;
   }
   Object attachment=data.invoke(null,mc.player);
   if(attachment instanceof java.util.Optional<?> optional)attachment=optional.orElse(null);
   if(attachment==null)return false;
   int water=Math.clamp(((Number)level.invoke(attachment)).intValue(),0,20);
   int right=width/2+91,top=height;
   if(Boolean.TRUE.equals(force.invoke(null))){right=((Number)x.invoke(null,globe.invoke(null),width,9,offsetX.invoke(null))).intValue();top=((Number)y.invoke(null,position.invoke(null),height,offsetY.invoke(null))).intValue();}
   draw(graphics,right,top,water);
   return true;
  }catch(ReflectiveOperationException|LinkageError|RuntimeException failure){disabled=true;System.err.println("[Zomboid Integration] Water HUD fallback: "+failure);return false;}
 }
 public static void draw(GuiGraphics graphics,int right,int top,int water){
  water=Math.clamp(water,0,20);
  for(int slot=0;slot<10;slot++){
   int left=right-slot*8-9,units=Math.clamp(water-slot*2,0,2);
   graphics.blit(ICONS,left,top,36,0,9,9);
   if(units>0)graphics.blit(ICONS,left,top,units==2?0:9,0,9,9);
  }
 }
}
