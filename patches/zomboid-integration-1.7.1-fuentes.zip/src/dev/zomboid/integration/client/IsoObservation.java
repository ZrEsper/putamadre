package dev.zomboid.integration.client;
import java.lang.reflect.*;import dev.zomboid.integration.*;import net.minecraft.client.Minecraft;
import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.SubscribeEvent;import net.neoforged.api.distmarker.Dist;
@EventBusSubscriber(modid="zomboid_integration",value=Dist.CLIENT)
public final class IsoObservation {
 private static Class<?> mod;private static Field enabled,zoom;private static boolean absent;private static boolean previewActive;private static int observedX,observedZ;private static float baseline;private static boolean wasEnabled;private static int ticks;
 private static boolean resolve(){if(absent)return false;if(mod!=null)return true;try{mod=Class.forName("com.cleannrooster.dungeons_iso.mod.Mod");enabled=mod.getField("enabled");zoom=mod.getField("zoom");return true;}catch(ReflectiveOperationException|LinkageError e){absent=true;return false;}}
 public static boolean visible(net.minecraft.world.entity.Entity entity){
  Minecraft mc=Minecraft.getInstance();if(mc.player==null)return false;
  int x=Math.floorDiv((int)Math.floor(entity.getX()),16),z=Math.floorDiv((int)Math.floor(entity.getZ()),16);
  int px=Math.floorDiv((int)Math.floor(mc.player.getX()),16),pz=Math.floorDiv((int)Math.floor(mc.player.getZ()),16);
  return Math.abs(x-px)<=3&&Math.abs(z-pz)<=3||previewActive&&Math.abs(x-observedX)<=2&&Math.abs(z-observedZ)<=2;
 }
 @SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event){
  Minecraft mc=Minecraft.getInstance();if(mc.player==null||mc.screen!=null||!resolve()){previewActive=false;wasEnabled=false;return;}if(++ticks%10!=0)return;
  try{
   boolean iso=enabled.getBoolean(null);float current=zoom.getFloat(null);if(!wasEnabled&&iso)baseline=current;wasEnabled=iso;boolean active=iso&&current<baseline-.15f;
   var point=mc.player.position();Object hit=mod.getField("mouseTarget").get(null);if(hit==null)hit=mod.getField("crosshairTarget").get(null);
   if(hit!=null){Object pos=NativeAccess.call(hit,"getLocation");if(pos instanceof net.minecraft.world.phys.Vec3 v)point=v;}
   previewActive=active;observedX=Math.floorDiv((int)Math.floor(point.x),16);observedZ=Math.floorDiv((int)Math.floor(point.z),16);net.neoforged.neoforge.network.PacketDistributor.sendToServer(new HordeView.View(active,point.x,point.z));
  }catch(ReflectiveOperationException|LinkageError|RuntimeException ignored){}
 }
}
