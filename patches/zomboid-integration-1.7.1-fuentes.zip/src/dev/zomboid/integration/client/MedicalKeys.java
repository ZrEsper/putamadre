package dev.zomboid.integration.client;
import net.minecraft.client.*;import com.mojang.blaze3d.platform.InputConstants;
@net.neoforged.fml.common.EventBusSubscriber(modid="zomboid_integration",value=net.neoforged.api.distmarker.Dist.CLIENT)
public final class MedicalKeys {
 private static boolean checked;
 @net.neoforged.bus.api.SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post e){Minecraft mc=Minecraft.getInstance();if(checked||mc.options==null)return;checked=true;
  try{KeyMapping core=(KeyMapping)Class.forName("net.thetct.tctcore.init.TctcoreModKeyMappings").getField("TC_TCORE_KEY").get(null);KeyMapping health=(KeyMapping)Class.forName("ichttt.mods.firstaid.client.ClientHooks").getField("SHOW_WOUNDS").get(null);KeyMapping giveUp=(KeyMapping)Class.forName("ichttt.mods.firstaid.client.ClientHooks").getField("GIVE_UP").get(null);
   if(!(core.getKey().equals(health.getKey())||core.getKey().equals(giveUp.getKey()))||core.getKey().getType()!=InputConstants.Type.KEYSYM)return;
   java.util.Set<Integer> taken=new java.util.HashSet<>();for(KeyMapping key:mc.options.keyMappings)if(key!=core&&key.getKey().getType()==InputConstants.Type.KEYSYM)taken.add(key.getKey().getValue());
   int code=KeyRules.free(taken);if(code<0){System.err.println("[Zomboid Integration] No free function key for TCTCore. Change its key in Controls.");return;}
   core.setKey(InputConstants.Type.KEYSYM.getOrCreate(code));KeyMapping.resetMapping();mc.options.save();System.out.println("[Zomboid Integration] TCTCore key moved to "+core.getTranslatedKeyMessage().getString()+" to avoid the medical menu / give-up key.");
  }catch(ClassNotFoundException missing){/* TCTCore is optional for this migration. */}catch(ReflectiveOperationException ex){System.err.println("[Zomboid Integration] Cannot resolve medical key conflict: "+ex);}
 }
}
