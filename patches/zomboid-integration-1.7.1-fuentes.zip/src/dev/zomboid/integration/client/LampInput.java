package dev.zomboid.integration.client;
import net.minecraft.client.*;import com.mojang.blaze3d.platform.InputConstants;import org.lwjgl.glfw.GLFW;
public final class LampInput {
 public static boolean physical(Minecraft mc,KeyMapping mapping){var key=mapping.getKey();int code=key.getValue();if(code<0)return false;long window=mc.getWindow().getWindow();if(key.getType()==InputConstants.Type.KEYSYM)return GLFW.glfwGetKey(window,code)==1;if(key.getType()==InputConstants.Type.MOUSE)return GLFW.glfwGetMouseButton(window,code)==1;return mapping.isDown();}
 public static boolean focused(Minecraft mc){return GLFW.glfwGetWindowAttrib(mc.getWindow().getWindow(),131073)==1;}
}
