package dev.zomboid.integration.client;
import net.minecraft.client.Minecraft;import java.nio.file.*;import java.io.File;
@net.neoforged.fml.common.EventBusSubscriber(modid="zomboid_integration",value=net.neoforged.api.distmarker.Dist.CLIENT)
public final class InitialGuiScale {
 private static boolean checked;
 @net.neoforged.bus.api.SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post e){if(checked)return;Minecraft mc=Minecraft.getInstance();if(mc.options==null)return;try{if(mc.getClass().getMethod("getOverlay").invoke(mc)!=null)return;Path marker=((File)mc.getClass().getField("gameDirectory").get(mc)).toPath().resolve("config/zomboid-integration/gui-scale-initialized");if(Files.exists(marker)){checked=true;return;}Object option=mc.options.getClass().getMethod("guiScale").invoke(mc.options);option.getClass().getMethod("set",Object.class).invoke(option,3);mc.options.save();mc.getClass().getMethod("resizeDisplay").invoke(mc);Files.createDirectories(marker.getParent());Files.writeString(marker,"Initial GUI scale set to 3; later choices are preserved.\n",StandardOpenOption.CREATE_NEW);checked=true;}catch(Exception error){checked=true;System.err.println("[Zomboid Integration] Cannot initialize GUI scale: "+error);}}
}
