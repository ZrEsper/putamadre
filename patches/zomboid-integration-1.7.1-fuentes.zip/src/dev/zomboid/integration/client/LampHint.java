package dev.zomboid.integration.client;
import dev.zomboid.integration.Lamps;
import net.minecraft.client.Minecraft;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
@EventBusSubscriber(modid="zomboid_integration",value=Dist.CLIENT)
public final class LampHint {
 @SubscribeEvent public static void render(net.neoforged.neoforge.client.event.RenderGuiEvent.Post event){
  Minecraft mc=Minecraft.getInstance();
  if(mc.player==null||mc.screen!=null||mc.options.hideGui)return;
  if(!Lamps.isLamp(mc.player.getMainHandItem())&&!Lamps.isLamp(mc.player.getOffhandItem()))return;
  var graphics=event.getGuiGraphics();
  String text="Pulsa "+Keys.LAMP.getTranslatedKeyMessage().getString()+" para encender / apagar la linterna";
  int textWidth=mc.font.width(text);
  float scale=Math.min(1.5f,(graphics.guiWidth()-16f)/Math.max(1,textWidth+12));
  var pose=graphics.pose();pose.pushPose();
  try{
   pose.translate(graphics.guiWidth()/2.0,Math.max(8,graphics.guiHeight()-85),0);
   pose.scale(scale,scale,1);
   graphics.fill(-textWidth/2-6,-4,textWidth/2+6,13,0xA0000000);
   graphics.drawString(mc.font,text,-textWidth/2,0,0xFFF3D477,true);
  }finally{pose.popPose();}
 }
}
