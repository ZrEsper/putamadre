package dev.zomboid.integration.client;
import com.google.gson.*;import dev.zomboid.integration.care.CareNetwork;import net.minecraft.client.*;import net.minecraft.client.gui.*;import net.minecraft.client.gui.components.Button;import net.minecraft.client.gui.screens.Screen;import net.minecraft.network.chat.Component;import net.neoforged.neoforge.network.PacketDistributor;
public final class CareScreen extends Screen {
 private JsonObject data;private int selected=0;private Button[] actions;private int top,left,panel;
 private CareScreen(JsonObject j){super(Component.literal("Chequeo médico"));data=j;}
 public static void receive(String text){JsonObject j=JsonParser.parseString(text).getAsJsonObject();Minecraft mc=Minecraft.getInstance();if(j.get("stage").getAsString().equals("closed")){if(mc.screen instanceof CareScreen)mc.setScreen(null);if(mc.player!=null)mc.player.displayClientMessage(Component.literal(j.get("message").getAsString()),true);return;}if(mc.screen instanceof CareScreen s){String previous=s.data.get("stage").getAsString();s.data=j;if(!previous.equals(j.get("stage").getAsString()))s.rebuild();else s.update();}else mc.setScreen(new CareScreen(j));}
 private void send(int kind,int mode){PacketDistributor.sendToServer(new CareNetwork.Action(kind,selected,mode));}
 private void rebuild(){clearWidgets();init();}
 protected void init(){actions=null;panel=Math.min(570,width-20);left=(width-panel)/2;top=Math.max(8,(height-270)/2);String stage=data.get("stage").getAsString();
  if(stage.equals("offer")){Button self=addRenderableWidget(Button.builder(Component.literal("Revisarme y curarme"),b->send(2,0)).bounds(width/2-110,height/2-10,220,20).build());self.active=data.get("self").getAsBoolean();addRenderableWidget(Button.builder(Component.literal("Revisar a "+data.get("other").getAsString()),b->send(1,0)).bounds(width/2-110,height/2+15,220,20).build());}
  else if(data.has("rows")){JsonArray rows=data.getAsJsonArray("rows");for(int i=0;i<rows.size();i++){final int idx=i;addRenderableWidget(Button.builder(Component.literal(rows.get(i).getAsJsonObject().get("name").getAsString()),b->{selected=idx;}).bounds(left+5,top+30+i*20,135,18).build());}
   String[] labels={"Vendar","Férula","Extraer bala","Curar"};actions=new Button[4];for(int i=0;i<4;i++){final int mode=i+1;actions[i]=addRenderableWidget(Button.builder(Component.literal(labels[i]),b->send(3,mode)).bounds(left+i*(panel/4),top+210,panel/4-4,20).build());}update();}
  addRenderableWidget(Button.builder(Component.literal("Cancelar / cerrar"),b->onClose()).bounds(width/2-75,Math.min(height-24,top+244),150,20).build());
 }
 private void update(){if(actions!=null)for(Button b:actions)b.active=data.get("stage").getAsString().equals("examined");}
 public void render(GuiGraphics g,int x,int y,float partial){g.fill(0,0,width,height,0x99101412);super.render(g,x,y,partial);g.drawString(font,"Chequeo médico"+(data.get("patient").getAsString().isEmpty()?"":" · "+data.get("patient").getAsString()),left,top,0xffd8e6d3,false);
  if(data.has("rows")){JsonArray rows=data.getAsJsonArray("rows");for(int i=0;i<rows.size();i++){JsonObject row=rows.get(i).getAsJsonObject();g.drawString(font,(selected==i?"▶ ":"")+row.get("hp").getAsString(),left+148,top+34+i*20,selected==i?0xff8cde83:0xffc9cfc5,false);}if(selected>=rows.size())selected=0;String detail=rows.get(selected).getAsJsonObject().get("details").getAsString();int yy=top+32;for(var line:font.split(Component.literal(detail),Math.max(80,panel-255))){g.drawString(font,line,left+255,yy,0xffc9cfc5,false);yy+=12;if(yy>top+185)break;}}
  String message=data.get("message").getAsString();int yy=data.get("stage").getAsString().equals("offer")?height/2-45:!data.has("rows")?height/2-18:top+190;for(var line:font.split(Component.literal(message),panel)){g.drawString(font,line,left,yy,0xff97ca8d,false);yy+=11;if(yy>top+208)break;}
  if(data.get("stage").getAsString().equals("work")){int w=Math.min(280,panel),bx=(width-w)/2,by=data.has("rows")?top+234:height/2;g.fill(bx,by,bx+w,by+6,0xff364038);g.fill(bx,by,bx+w*data.get("progress").getAsInt()/100,by+6,0xff86cb76);}
 }
 public void onClose(){send(0,0);Minecraft.getInstance().setScreen(null);}
 public boolean isPauseScreen(){return false;}
}
