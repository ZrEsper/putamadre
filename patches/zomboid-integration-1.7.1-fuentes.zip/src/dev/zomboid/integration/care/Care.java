package dev.zomboid.integration.care;
import java.util.*;import net.minecraft.server.level.ServerPlayer;import net.minecraft.world.entity.player.Player;import net.minecraft.world.item.*;import net.minecraft.world.phys.Vec3;import net.minecraft.network.chat.Component;import net.minecraft.world.InteractionResult;import com.google.gson.*;
@net.neoforged.fml.common.EventBusSubscriber(modid="zomboid_integration")
public final class Care {
 private static final Map<UUID,Session> SESSIONS=new HashMap<>();
 static final class Session{ServerPlayer actor,candidate,patient;long touched;int elapsed,total,mode,part,slot;ItemStack stack;Vec3 origin,patientOrigin;String stage="offer",message="Elige a quién revisar.";Session(ServerPlayer a,ServerPlayer b){actor=a;candidate=b;touched=a.level().getGameTime();}}
 public static boolean near(ServerPlayer a,ServerPlayer b){return a!=null&&b!=null&&a.isAlive()&&b.isAlive()&&!a.isSpectator()&&!b.isSpectator()&&!a.isRemoved()&&!b.isRemoved()&&a.level()==b.level()&&CareRules.reachable(true,true,a==b||a.hasLineOfSight(b),a.distanceToSqr(b));}
 private static void offer(ServerPlayer a,ServerPlayer b){if(!near(a,b)||!Medical.conscious(a))return;Session old=SESSIONS.get(a.getUUID());if(old!=null&&old.stage.equals("work"))return;if(old!=null&&a.level().getGameTime()-old.touched<4)return;Session s=new Session(a,b);SESSIONS.put(a.getUUID(),s);view(s);}
 @net.neoforged.bus.api.SubscribeEvent public static void interact(net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.EntityInteract e){if(e.getTarget() instanceof Player){e.setCanceled(true);e.setCancellationResult(InteractionResult.SUCCESS);if(e.getEntity() instanceof ServerPlayer a&&e.getTarget() instanceof ServerPlayer b)offer(a,b);}}
 @net.neoforged.bus.api.SubscribeEvent public static void specific(net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.EntityInteractSpecific e){if(e.getTarget() instanceof Player){e.setCanceled(true);e.setCancellationResult(InteractionResult.SUCCESS);if(e.getEntity() instanceof ServerPlayer a&&e.getTarget() instanceof ServerPlayer b)offer(a,b);}}
 public static void self(ServerPlayer p){offer(p,p);}
 public static void action(ServerPlayer actor,CareNetwork.Action a){Session s=SESSIONS.get(actor.getUUID());if(s==null)return;s.touched=actor.level().getGameTime();if(a.kind()==0){SESSIONS.remove(actor.getUUID());return;}if(s.stage.equals("work"))return;
  if(a.kind()==1||a.kind()==2){ServerPlayer patient=a.kind()==2?actor:s.candidate;if(!near(actor,patient)||(patient==actor&&!Medical.injured(actor))){s.message="No tienes lesiones que tratar o el jugador está demasiado lejos.";view(s);return;}s.patient=patient;s.mode=0;s.total=30;start(s);return;}
  if(a.kind()!=3||!s.stage.equals("examined")||!near(actor,s.patient)||!Medical.conscious(actor)||!CareRules.validPart(a.part(),Medical.PARTS.length)||a.mode()<1||a.mode()>4)return;
  if(!Medical.needed(s.patient,a.part(),a.mode())){s.message="Ese tratamiento no corresponde a la zona o ya está en curso.";view(s);return;}
  for(Session other:SESSIONS.values())if(other!=s&&other.stage.equals("work")&&other.mode!=0&&other.patient==s.patient){s.message="Otra persona ya está tratando a este jugador.";view(s);return;}
  int slot=-1;for(int i=0;i<actor.getInventory().getContainerSize();i++)if(Medical.item(actor.getInventory().getItem(i),a.mode())){slot=i;break;}
  if(slot<0){s.message=switch(a.mode()){case 1->"Necesitas una venda o tela en tu inventario.";case 2->"Necesitas una férula en tu inventario.";case 3->"Necesitas unas tijeras para extraer la bala.";default->"Necesitas un objeto de curación de First Aid.";};view(s);return;}
  s.part=a.part();s.mode=a.mode();s.slot=slot;s.stack=actor.getInventory().getItem(slot);s.total=Medical.duration(actor,s.stack,s.mode);start(s);
 }
 private static void start(Session s){s.elapsed=0;s.origin=s.actor.position();s.patientOrigin=s.patient.position();s.stage="work";s.message=s.mode==0?"Chequeando lesiones…":label(s.mode)+" · "+Medical.name(s.part);view(s);}
 static String label(int mode){return switch(mode){case 1->"Aplicando vendaje";case 2->"Aplicando férula";case 3->"Extrayendo bala";default->"Aplicando tratamiento";};}
 @net.neoforged.bus.api.SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.EntityTickEvent.Post e){if(!(e.getEntity() instanceof ServerPlayer actor))return;Session s=SESSIONS.get(actor.getUUID());if(s==null)return;
  if(actor.level().getGameTime()-s.touched>1200||!near(actor,s.patient!=null?s.patient:s.candidate)){close(s,"Chequeo cancelado: debes permanecer cerca del jugador.");return;}
  if(s.stage.equals("work")){
   boolean invalid=CareRules.interrupted(Medical.conscious(actor),actor.hurtTime>0||s.patient.hurtTime>0,actor.position().distanceToSqr(s.origin),s.patient.position().distanceToSqr(s.patientOrigin));
   if(s.mode!=0)invalid|=actor.getInventory().getItem(s.slot)!=s.stack||s.stack.isEmpty()||!Medical.needed(s.patient,s.part,s.mode);
   if(invalid){s.stage=s.mode==0?"offer":"examined";s.message="Interrumpido: quédate quieto, cerca y sin recibir golpes. No se consumió material.";s.mode=0;view(s);return;}
   s.elapsed++;if(s.elapsed>=s.total){if(s.mode==0){s.stage="examined";s.message="Chequeo terminado. Selecciona una zona y un tratamiento.";}else{try{boolean ok=Medical.complete(actor,s.patient,s.part,s.mode,s.stack);s.message=ok?(s.mode==2?"Férula aplicada: fractura inmovilizada; la recuperación tarda 2 minutos.":"Tratamiento aplicado."):"La lesión cambió; no se consumió material.";}catch(ReflectiveOperationException ex){s.message="No se pudo aplicar el tratamiento.";System.err.println("[Zomboid Integration] Medical treatment: "+ex);}s.stage="examined";}s.mode=0;view(s);return;}
  }
  if(actor.tickCount%5==0&&!s.stage.equals("offer"))view(s);
 }
 @net.neoforged.bus.api.SubscribeEvent public static void logout(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent e){SESSIONS.remove(e.getEntity().getUUID());}
 private static void close(Session s,String message){SESSIONS.remove(s.actor.getUUID());JsonObject j=new JsonObject();j.addProperty("stage","closed");j.addProperty("message",message);CareNetwork.send(s.actor,j.toString());}
 private static void view(Session s){JsonObject j=new JsonObject();j.addProperty("stage",s.stage);j.addProperty("message",s.message);j.addProperty("other",s.candidate.getName().getString());j.addProperty("self",Medical.injured(s.actor));j.addProperty("patient",s.patient==null?"":s.patient.getName().getString());j.addProperty("progress",s.total==0?0:Math.min(100,s.elapsed*100/s.total));j.addProperty("total",s.total);if(s.patient!=null&&!(s.stage.equals("work")&&s.mode==0))j.add("rows",Medical.rows(s.patient));CareNetwork.send(s.actor,j.toString());}
}
