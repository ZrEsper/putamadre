package dev.zomboid.integration.care;
import ichttt.mods.firstaid.compat.lrtactical.TreatmentV33;
import net.minecraft.world.entity.player.Player;import net.minecraft.server.level.ServerPlayer;import net.minecraft.world.item.*;import net.minecraft.core.Holder;import net.minecraft.world.effect.*;import com.google.gson.*;
public final class Medical {
 private static final String ROOT="ichttt.mods.firstaid.";
 public static final Enum<?>[] PARTS=(Enum<?>[])TreatmentV33.type(ROOT+"api.enums.EnumPlayerPart").getEnumConstants();
 public static final ThreadLocal<Player> CREDIT=new ThreadLocal<>();
 public static Object call(Object o,String n,Object... args){return TreatmentV33.call(o,n,args);}
 public static Object stat(String c,String m,Object... args){return TreatmentV33.stat(ROOT+c,m,args);}
 public static Object get(Object o,String n){return TreatmentV33.get(o,n);}
 public static boolean yes(Object v){return Boolean.TRUE.equals(v);}
 public static int num(Object v){return v instanceof Number n?n.intValue():0;}
 public static Object model(Player p){return stat("common.util.CommonUtils","getDamageModel",p);}
 public static Object part(Object m,int i){return call(m,"getFromEnum",PARTS[i]);}
 public static Object state(Object m){return stat("survival.ClinicalData","state",m);}
 public static Object wound(Object m,int i){return ((Object[])get(state(m),"wounds"))[i];}
 public static boolean broken(Player p,boolean left){return yes(stat("fracture.Fractures","isBroken",p,left));}
 public static boolean splinted(Player p,boolean left){return yes(stat("fracture.Fractures","isSplinted",p,left));}
 public static boolean leg(int i){return PARTS[i].name().equals("LEFT_LEG")||PARTS[i].name().equals("RIGHT_LEG");}
 public static boolean left(int i){return PARTS[i].name().startsWith("LEFT");}
 public static String name(int i){return switch(PARTS[i].name()){case "HEAD"->"Cabeza";case "BODY"->"Torso";case "LEFT_ARM"->"Brazo izquierdo";case "RIGHT_ARM"->"Brazo derecho";case "LEFT_LEG"->"Pierna izquierda";case "RIGHT_LEG"->"Pierna derecha";case "LEFT_FOOT"->"Pie izquierdo";default->"Pie derecho";};}
 public static boolean injured(Player p){Object m=model(p);if(m==null)return false;for(int i=0;i<PARTS.length;i++){Object q=part(m,i),w=wound(m,i);if(num(get(q,"currentHealth"))<num(call(q,"getMaxHealth"))||yes(call(w,"active"))||yes(get(w,"infected"))||yes(stat("fracture.Bleeding","isBleeding",p,PARTS[i])))return true;}return broken(p,true)||broken(p,false)||splinted(p,true)||splinted(p,false);}
 public static boolean conscious(Player p){Object m=model(p);return m!=null&&num(call(m,"getUnconsciousTicks"))==0;}
 public static JsonArray rows(Player p){Object m=model(p);JsonArray rows=new JsonArray();for(int i=0;i<PARTS.length;i++){Object q=part(m,i),w=wound(m,i);JsonObject r=new JsonObject();r.addProperty("index",i);r.addProperty("name",name(i));r.addProperty("hp",String.valueOf(get(q,"currentHealth"))+" / "+call(q,"getMaxHealth"));StringBuilder t=new StringBuilder();if(yes(get(w,"gunshot")))t.append("Disparo; ");if(yes(get(w,"cut")))t.append("Corte; ");if(yes(get(w,"bitten")))t.append("Mordedura; ");if(num(get(w,"bullets"))>0)t.append("Balas alojadas: ").append(num(get(w,"bullets"))).append("; ");if(yes(get(w,"bandaged")))t.append("Vendaje ").append(yes(get(w,"dirty"))?"sucio":"aplicado").append("; ");if(yes(get(w,"infected")))t.append("Infección; ");if(yes(stat("fracture.Bleeding","isBleeding",p,PARTS[i])))t.append("Sangrado; ");if(leg(i)){if(broken(p,left(i)))t.append("Fractura sin inmovilizar; ");if(splinted(p,left(i)))t.append("Férula aplicada · recuperación: ").append(num(stat("fracture.Fractures","splintTicksLeft",p,left(i)))/20).append(" s; ");}if(get(q,"activeHealer")!=null)t.append("Curación en curso; ");if(t.length()==0)t.append("Sin lesiones activas");r.addProperty("details",t.toString());rows.add(r);}return rows;}
 public static boolean item(ItemStack s,int mode){if(s.isEmpty())return false;return switch(mode){case 1->yes(stat("survival.ClinicalHooks","dressing",s));case 2->TreatmentV33.type(ROOT+"fracture.SplintItem").isInstance(s.getItem());case 3->yes(stat("survival.ClinicalHooks","extraction",s));case 4->TreatmentV33.type(ROOT+"api.healing.ItemHealing").isInstance(s.getItem());default->false;};}
 public static boolean needed(Player p,int i,int mode){Object m=model(p),w=wound(m,i),q=part(m,i);if(num(get(state(m),"dressingPart"))>=0||num(get(state(m),"extractionPart"))>=0||get(q,"activeHealer")!=null)return false;return switch(mode){case 1->yes(call(w,"canBandage"))||yes(get(w,"dirty"))||yes(get(w,"infected"))||yes(stat("fracture.Bleeding","isBleeding",p,PARTS[i]));case 2->leg(i)&&broken(p,left(i));case 3->num(get(w,"bullets"))>0;case 4->!yes(call(w,"blocksHealing"))&&!yes(stat("common.util.CommonUtils","isPartVisuallyFull",q));default->false;};}
 public static int duration(Player healer,ItemStack stack,int mode){int base=switch(mode){case 1->66;case 2->60;case 3->80;default->Math.max(1,num(call(stack.getItem(),"getApplyTime",stack)));};return Math.max(20,num(stat("survival.MedicalSkills","duration",base,num(stat("survival.MedicalSkills","level",healer)))));}
 @SuppressWarnings({"rawtypes","unchecked"})
 public static boolean complete(ServerPlayer actor,ServerPlayer patient,int i,int mode,ItemStack stack)throws ReflectiveOperationException{
  if(!needed(patient,i,mode)||!item(stack,mode))return false;Object m=model(patient),w=wound(m,i),q=part(m,i);boolean nativeCredit=false;
  if(mode==1){call(w,"bandage");CREDIT.set(actor);try{TreatmentV33.applied(m,patient,i,stack);}finally{CREDIT.remove();}stat("fracture.Bleeding","stop",patient,PARTS[i],true);nativeCredit=true;}
  else if(mode==2){String side=left(i)?"LEFT":"RIGHT";Class<?> cls=TreatmentV33.type(ROOT+"fracture.FractureMod");Holder fracture=(Holder)cls.getField("FRACTURE_"+side).get(null),splint=(Holder)cls.getField("SPLINT_"+side).get(null);patient.removeEffect(fracture);patient.addEffect(new MobEffectInstance(splint,2400,0,false,false,true));stat("fracture.Fractures","updateSlow",patient);}
  else if(mode==3){TreatmentV33.set(w,"bullets",num(get(w,"bullets"))-1);}
  else{Object healer=call(stack.getItem(),"createNewHealer",stack.copyWithCount(1));if(healer==null)return false;Object ctx=null;for(var c:TreatmentV33.type(ROOT+"api.healing.PartHealingContext").getConstructors())if(c.getParameterCount()==6){ctx=c.newInstance(actor,actor.level(),stack.copyWithCount(1),m,q,healer);break;}if(ctx==null)return false;TreatmentV33.set(q,"activeHealer",healer);call(stack.getItem(),"onTreatmentStarted",ctx);nativeCredit=true;}
  if(!actor.isCreative()){if(stack.isDamageableItem()){int next=stack.getDamageValue()+1;if(next>=stack.getMaxDamage())stack.shrink(1);else stack.setDamageValue(next);}else stack.shrink(1);}actor.getInventory().setChanged();actor.containerMenu.broadcastChanges();if(!nativeCredit)stat("survival.MedicalSkills","reward",actor);call(m,"scheduleResync");stat("common.util.CommonUtils","syncDamageModel",patient);return true;
 }
}
