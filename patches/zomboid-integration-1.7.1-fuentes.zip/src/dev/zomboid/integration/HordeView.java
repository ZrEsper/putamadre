package dev.zomboid.integration;
import net.minecraft.resources.ResourceLocation;import net.minecraft.network.RegistryFriendlyByteBuf;import net.minecraft.network.codec.StreamCodec;import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
public final class HordeView {
 public record View(boolean active,double x,double z) implements CustomPacketPayload {
  public static final Type<View> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("zomboid_integration","horde_view"));
  public Type<View> type(){return TYPE;}
  public static final StreamCodec<RegistryFriendlyByteBuf,View> CODEC=StreamCodec.of((b,v)->b.writeUtf(v.active+","+v.x+","+v.z,128),b->decode(b.readUtf(128)));
  private static View decode(String text){String[] parts=text.split(",",-1);if(parts.length!=3)throw new IllegalArgumentException("Invalid view");return new View(Boolean.parseBoolean(parts[0]),Double.parseDouble(parts[1]),Double.parseDouble(parts[2]));}

 }
 @net.neoforged.fml.common.EventBusSubscriber(modid="zomboid_integration",bus=net.neoforged.fml.common.EventBusSubscriber.Bus.MOD)
 public static final class Registration {
  @net.neoforged.bus.api.SubscribeEvent public static void register(net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent e){e.registrar("2").playToServer(View.TYPE,View.CODEC,(v,context)->context.enqueueWork(()->{if(context.player() instanceof net.minecraft.server.level.ServerPlayer p)ZombieSleep.observe(p,v.active,v.x,v.z);}));}
 }
}
