package dev.zomboid.integration;
@net.neoforged.fml.common.Mod("zomboid_integration")
public final class Integration {public Integration(){}}
