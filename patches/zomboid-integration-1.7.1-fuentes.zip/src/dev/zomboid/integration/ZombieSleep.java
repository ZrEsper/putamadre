package dev.zomboid.integration;
import java.nio.file.*;import java.util.*;import java.util.concurrent.*;import java.io.*;
import net.minecraft.world.entity.Entity;import net.minecraft.world.entity.Mob;import net.minecraft.world.entity.player.Player;import net.minecraft.world.level.Level;
import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.SubscribeEvent;
@EventBusSubscriber(modid="zomboid_integration")
public final class ZombieSleep {
 private record Window(Level level,int x,int z,long expires){}
 private static final Map<UUID,Window> VIEWS=new HashMap<>();
 private static final Map<Level,Store> STORES=new IdentityHashMap<>();
 private static final ClassValue<Boolean> TYPES=new ClassValue<>(){protected Boolean computeValue(Class<?> type){for(Class<?> c=type;c!=null;c=c.getSuperclass())if(c.getName().equals("net.minecraft.world.entity.monster.Zombie")||c.getName().startsWith("net.mcreator.mutantszombies.entity."))return true;return type.getName().toLowerCase(Locale.ROOT).contains("mutantszombies")&&Mob.class.isAssignableFrom(type);}};
 private static ExecutorService worker;
 private static long clock;private static UUID writingRemoval,restoring;private static int totalPending;
 private static final class Entry{UUID uuid;int x,z;boolean asleep;Path path;long retryAt;Entry(UUID id,int x,int z,boolean asleep,Path path){this.uuid=id;this.x=x;this.z=z;this.asleep=asleep;this.path=path;}}
 private record Pending(UUID uuid,Entity entity,Entry entry,Future<?> future,double x,double y,double z,float health){}
 private static final class Store{Path dir;Map<UUID,Entry> entries=new HashMap<>();Map<UUID,Pending> pending=new HashMap<>();Iterator<Entity> scan;Iterator<Entry> wake;int ticks;boolean failed;}
 public static boolean zombie(Entity e){return e instanceof Mob&&TYPES.get(e.getClass());}
 private static int chunk(double v){return Math.floorDiv((int)Math.floor(v),16);}
 private static boolean playersNear(Level level,int x,int z,int radius){try{for(Object value:(Iterable<?>)NativeAccess.call(level,"players")){Player p=(Player)value;if(!p.isSpectator()&&Math.abs(chunk(p.getX())-x)<=radius&&Math.abs(chunk(p.getZ())-z)<=radius)return true;}}catch(ReflectiveOperationException error){return true;}return false;}
 private static boolean preview(Level level,int x,int z){for(Window w:VIEWS.values())if(w.level==level&&w.expires>=clock&&Math.abs(w.x-x)<=2&&Math.abs(w.z-z)<=2)return true;return false;}
 private static boolean wanted(Level level,Entry e){return !ChunkArea.virtualization(level)||playersNear(level,e.x,e.z,3)||preview(level,e.x,e.z);}
 public static void observe(Player p,boolean active,double x,double z){
  if(!active){VIEWS.remove(p.getUUID());return;}
  if(!Double.isFinite(x)||!Double.isFinite(z)||p.isSpectator()||!p.isAlive())return;
  if(Math.abs(x-p.getX())>96||Math.abs(z-p.getZ())>96)return;
  Window previous=VIEWS.get(p.getUUID());if(previous!=null&&previous.expires-clock>35)return;
  VIEWS.put(p.getUUID(),new Window(p.level(),chunk(x),chunk(z),clock+40));
 }
 /** Distant previews are real visible entities but their AI, attacks and movement do not tick. */
 public static boolean frozen(Entity e){Store s=STORES.get(e.level());return ChunkArea.virtualization(e.level())&&(s==null||!s.failed)&&e.isAlive()&&!e.isRemoved()&&zombie(e)&&!playersNear(e.level(),chunk(e.getX()),chunk(e.getZ()),3);}
 private static Store store(Level level){
  Store known=STORES.get(level);if(known!=null)return known;Store s=new Store();STORES.put(level,s);
  try{
   Object server=NativeAccess.call(level,"getServer");Class<?> resource=Class.forName("net.minecraft.world.level.storage.LevelResource");Path root=(Path)NativeAccess.call(server,"getWorldPath",resource.getField("ROOT").get(null));
   Object dimension=NativeAccess.call(NativeAccess.call(level,"dimension"),"location");String name=Base64.getUrlEncoder().withoutPadding().encodeToString(dimension.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
   s.dir=root.resolve("data/zomboid-zombie-sleep/"+name);Files.createDirectories(s.dir);
   try(var files=Files.list(s.dir)){for(Path p:files.filter(f->f.getFileName().toString().endsWith(".nbt")).toList()){
    String[] pieces=p.getFileName().toString().replace(".nbt","").split("_",4);if(pieces.length!=4)continue;
    try{Entry e=new Entry(UUID.fromString(pieces[3]),Integer.parseInt(pieces[1]),Integer.parseInt(pieces[2]),pieces[0].equals("S"),p);Entry old=s.entries.get(e.uuid);if(old==null||e.asleep)s.entries.put(e.uuid,e);}catch(IllegalArgumentException ignored){}
   }}
   if(worker==null)worker=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"Zomboid-Zombie-Archive");t.setDaemon(true);return t;});
  }catch(Exception|LinkageError error){s.failed=true;System.err.println("[Zomboid Integration] Zombie archive unavailable; entities retained: "+error);}
  return s;
 }
 private static Path path(Store s,Entry e,boolean asleep){return s.dir.resolve((asleep?"S":"A")+"_"+e.x+"_"+e.z+"_"+e.uuid+".nbt");}
 private static void active(Store s,Entry e)throws IOException{if(e.asleep){Path next=path(s,e,false);ArchiveFiles.move(e.path,next);e.path=next;e.asleep=false;}}
 private static void forget(Store s,UUID uuid){Entry e=s.entries.remove(uuid);if(e!=null)try{Files.deleteIfExists(e.path);}catch(IOException error){s.entries.put(uuid,e);s.failed=true;System.err.println("[Zomboid Integration] Archive cleanup failed; pausing virtualization: "+error);}}
 @SubscribeEvent public static void join(net.neoforged.neoforge.event.entity.EntityJoinLevelEvent event){
  Entity e=event.getEntity();Level level=event.getLevel();if(level.isClientSide||!zombie(e)||e.getUUID().equals(restoring))return;
  Store s=store(level);Entry archived=s.entries.get(e.getUUID());if(s.failed)return;
  if(archived==null){
   if(ChunkArea.virtualization(level)&&!playersNear(level,chunk(e.getX()),chunk(e.getZ()),3))try{
    if(Boolean.FALSE.equals(NativeAccess.call(event,"loadedFromDisk"))){int sleeping=0;for(Entry entry:s.entries.values())if(entry.asleep&&entry.x==chunk(e.getX())&&entry.z==chunk(e.getZ()))sleeping++;if(sleeping>=24)event.setCanceled(true);}
   }catch(ReflectiveOperationException ignored){}
   return;
  }
  if(!archived.asleep)return;
  // Joining from disk can precede FULL chunk status. Defer all restoration to the bounded level tick.
  event.setCanceled(true);
 }
 @SubscribeEvent public static void leave(net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent event){
  Entity e=event.getEntity();if(e.level().isClientSide||!zombie(e)||e.getUUID().equals(writingRemoval))return;
  Store s=STORES.get(e.level());if(s==null)return;
  try{Object reason=NativeAccess.call(e,"getRemovalReason");String name=String.valueOf(reason);if(name.equals("KILLED")||name.equals("DISCARDED"))forget(s,e.getUUID());}catch(ReflectiveOperationException ignored){}
 }
 @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.LevelTickEvent.Post event){
  Level level=event.getLevel();if(level.isClientSide)return;Store s=store(level);if(s.failed&&s.dir==null)return;if(++s.ticks<100)return;
  try{
   for(Iterator<Pending> it=s.pending.values().iterator();it.hasNext();){Pending p=it.next();if(!p.future.isDone())continue;it.remove();totalPending--;
    try{p.future.get();Entity e=p.entity;
     if(!ChunkArea.virtualization(level)||e.isRemoved()||!e.isAlive()||playersNear(level,chunk(e.getX()),chunk(e.getZ()),4)||preview(level,p.entry.x,p.entry.z)||e.getX()!=p.x||e.getY()!=p.y||e.getZ()!=p.z||((net.minecraft.world.entity.LivingEntity)e).getHealth()!=p.health){Files.deleteIfExists(p.entry.path);continue;}
     Entry old=s.entries.put(p.uuid,p.entry);if(old!=null&&!old.path.equals(p.entry.path))Files.deleteIfExists(old.path);
     writingRemoval=p.uuid;try{e.discard();}finally{writingRemoval=null;}
    }catch(Exception error){s.failed=true;System.err.println("[Zomboid Integration] Zombie kept after archive write failure; new archiving disabled: "+error);}
   }
   if(s.scan==null||!s.scan.hasNext()){s.scan=((Iterable<Entity>)NativeAccess.call(level,"getAllEntities")).iterator();}
   int scanned=0,queued=0;
   while(!s.failed&&ChunkArea.virtualization(level)&&s.scan.hasNext()&&scanned++<128&&queued<2&&totalPending<8){Entity e=s.scan.next();if(!zombie(e)||e.isRemoved()||!e.isAlive()||s.pending.containsKey(e.getUUID()))continue;
    int x=chunk(e.getX()),z=chunk(e.getZ());if(playersNear(level,x,z,4)||preview(level,x,z))continue;
    if(Boolean.TRUE.equals(NativeAccess.call(e,"isPassenger"))||Boolean.TRUE.equals(NativeAccess.call(e,"isVehicle"))||Boolean.TRUE.equals(NativeAccess.call(e,"hasCustomName")))continue;
    Object raw=Class.forName("net.minecraft.nbt.CompoundTag").getConstructor().newInstance();if(!Boolean.TRUE.equals(NativeAccess.call(e,"save",raw)))continue;Object tag=NativeAccess.call(raw,"copy");
    Entry entry=new Entry(e.getUUID(),x,z,true,null);entry.path=path(s,entry,true);
    Future<?> future=worker.submit(()->{try{ArchiveFiles.write(entry.path,tag);}catch(Exception error){throw new CompletionException(error);}});
    s.pending.put(e.getUUID(),new Pending(e.getUUID(),e,entry,future,e.getX(),e.getY(),e.getZ(),((net.minecraft.world.entity.LivingEntity)e).getHealth()));totalPending++;queued++;
   }
   if(s.wake==null||!s.wake.hasNext())s.wake=new ArrayList<>(s.entries.values()).iterator();int checked=0,woken=0;
   while(s.wake.hasNext()&&checked++<128&&woken<4){Entry entry=s.wake.next();if(s.entries.get(entry.uuid)!=entry||!entry.asleep||entry.retryAt>clock||!wanted(level,entry))continue;
    if(!Boolean.TRUE.equals(NativeAccess.call(level,"hasChunk",entry.x,entry.z)))continue;
    if(NativeAccess.call(level,"getEntity",entry.uuid)!=null)continue;
    boolean near=playersNear(level,entry.x,entry.z,3);if(!near&&ChunkArea.virtualization(level)){int shown=0;for(Entry other:s.entries.values())if(!other.asleep&&NativeAccess.call(level,"getEntity",other.uuid)!=null&&!playersNear(level,other.x,other.z,3)&&preview(level,other.x,other.z))shown++;if(shown>=64)continue;}
    try{Object tag=ArchiveFiles.read(entry.path);Entity e=(Entity)NativeAccess.call(Class.forName("net.minecraft.world.entity.EntityType"),"loadEntityRecursive",tag,level,java.util.function.Function.<Entity>identity());
     if(e==null||!zombie(e)||!e.getUUID().equals(entry.uuid)){entry.retryAt=clock+200;System.err.println("[Zomboid Integration] Missing entity type; archive retained: "+entry.uuid);continue;}
     restoring=entry.uuid;boolean added;try{added=Boolean.TRUE.equals(NativeAccess.call(level,"addFreshEntity",e));}finally{restoring=null;}
     if(added){active(s,entry);woken++;}
    }catch(Exception error){entry.retryAt=clock+200;System.err.println("[Zomboid Integration] Zombie archive retained after wake failure: "+error);}
   }
  }catch(Exception|LinkageError error){s.scan=null;System.err.println("[Zomboid Integration] Zombie sleep cycle paused: "+error);}
 }
 @SubscribeEvent public static void clock(net.neoforged.neoforge.event.tick.ServerTickEvent.Post event){clock++;VIEWS.values().removeIf(v->v.expires<clock);}
 @SubscribeEvent public static void stop(net.neoforged.neoforge.event.server.ServerStoppedEvent event){
  if(worker!=null){worker.shutdown();try{worker.awaitTermination(30,TimeUnit.SECONDS);}catch(InterruptedException interrupted){Thread.currentThread().interrupt();}worker=null;}
  for(Store s:STORES.values())for(Pending pending:s.pending.values())if(pending.future.isDone())try{Files.deleteIfExists(pending.entry.path);}catch(IOException ignored){}
  STORES.clear();VIEWS.clear();totalPending=0;clock=0;
 }
}
