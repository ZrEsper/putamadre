package dev.zomboid.integration;
import java.util.*;import java.lang.reflect.*;import net.minecraft.world.entity.Mob;import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.SubscribeEvent;import net.neoforged.bus.api.EventPriority;
@EventBusSubscriber(modid="zomboid_integration")
public final class MilitaryLoot {
 private record Context(Mob mob,Integer kind){}
 private static final ThreadLocal<Deque<Context>> CONTEXT=ThreadLocal.withInitial(ArrayDeque::new);
 private static Context current(){return CONTEXT.get().peek();}
 private MilitaryLoot(){}
 private static Object slot(String name)throws ReflectiveOperationException{return Class.forName("net.minecraft.world.entity.EquipmentSlot").getField(name).get(null);}
 public static void begin(net.neoforged.neoforge.event.entity.living.LivingDropsEvent event){
  Mob mob=null;Integer kind=null;
  if(ZombieSleep.zombie(event.getEntity()))try{mob=(Mob)event.getEntity();kind=mob.getPersistentData().contains("zi_zombie_worn_at_death")?mob.getPersistentData().getInt("zi_zombie_worn_at_death"):ZombieClothing.worn(mob);}catch(ReflectiveOperationException error){System.err.println("[Zomboid Integration] Clothing loot context failed: "+error);}
  CONTEXT.get().push(new Context(mob,kind));
 }
 public static void end(){Deque<Context> stack=CONTEXT.get();if(!stack.isEmpty())stack.pop();if(stack.isEmpty())CONTEXT.remove();}
 public static Integer quality(double roll,boolean mutant){Context context=current();Integer kind=context==null?null:context.kind;if(kind==null||mutant&&kind!=2)return null;return ClothingRules.quality(kind,roll);}
 private static ItemStack gun(Mob mob)throws ReflectiveOperationException{
  try{Class<?> access=Class.forName("dev.zomboid.remains.GunAccess");Object rng=NativeAccess.call(mob,"getRandom"),profile=NativeAccess.call(access,"choose",2,rng);if(profile==null)profile=NativeAccess.call(access,"choose",0,rng);if(profile!=null){int capacity=((Number)NativeAccess.call(profile,"capacity")).intValue();ItemStack gun=(ItemStack)NativeAccess.call(access,"create",profile,Math.min(24,capacity));if(!gun.isEmpty()){mark(gun);return gun;}}}catch(ReflectiveOperationException|RuntimeException|LinkageError failure){System.err.println("[Zomboid Integration] Military firearm unavailable; using melee fallback: "+failure);}
  return ZombieClothing.stack("minecraft:iron_sword",1);
 }
 private static void mark(ItemStack stack)throws ReflectiveOperationException{
  Class<?> loot=Class.forName("dev.zomboid.remains.WeaponLoot");Method mark=loot.getDeclaredMethod("mark",ItemStack.class);mark.setAccessible(true);mark.invoke(null,stack);NativeAccess.call(loot,"decorate",stack);
 }
 public static void arm(Mob mob)throws ReflectiveOperationException{
  Object hand=slot("MAINHAND");ItemStack held=(ItemStack)NativeAccess.call(mob,"getItemBySlot",hand);if(held.isEmpty())NativeAccess.call(mob,"setItemSlot",hand,gun(mob));NativeAccess.call(mob,"setDropChance",hand,1f);
 }
 private static Object field(Object target,String name)throws ReflectiveOperationException{for(Class<?> c=target.getClass();c!=null;c=c.getSuperclass())try{Field f=c.getDeclaredField(name);f.setAccessible(true);return f.get(target);}catch(NoSuchFieldException ignored){}throw new NoSuchFieldException(name);}
 private static void setQuality(Object target,int value)throws ReflectiveOperationException{Field f=target.getClass().getDeclaredField("quality");f.setAccessible(true);f.setInt(target,Math.max(f.getInt(target),value));}
 private static int importance(ItemStack stack)throws ReflectiveOperationException{if(stack.isEmpty())return -1;String id=ZombieClothing.id(stack);if(id.equals("minecraft:rotten_flesh")||id.equals("minecraft:bone"))return 0;if(id.startsWith("tacz:")&&!id.endsWith(":ammo"))return 100;if(id.equals("tacz:ammo"))return 80;if(id.startsWith("fracturepoint:")||id.startsWith("firstaid:"))return 70;if(id.startsWith("selfexpression:"))return 30;return 10;}
 private static void insert(Object inventory,ItemStack stack)throws ReflectiveOperationException{
  if(stack.isEmpty())return;ItemStack remaining=(ItemStack)NativeAccess.call(inventory,"addItem",stack.copyWithCount(stack.getCount()));if(remaining.isEmpty())return;
  int size=((Number)NativeAccess.call(inventory,"getContainerSize")).intValue();int best=-1,score=Integer.MAX_VALUE;
  for(int i=0;i<size;i++){int importance=importance((ItemStack)NativeAccess.call(inventory,"getItem",i));if(importance<score){score=importance;best=i;}}
  if(best<0)throw new IllegalStateException("Corpse has no inventory slots");NativeAccess.call(inventory,"setItem",best,remaining);
 }
 private static List<ItemStack> supplies(Mob mob,ItemStack weapon)throws ReflectiveOperationException{
  List<ItemStack> result=new ArrayList<>();if(!weapon.isEmpty())result.add(weapon);
  try{Object profile=NativeAccess.call(Class.forName("dev.zomboid.remains.GunAccess"),"describe",weapon);if(profile!=null){ItemStack ammo=(ItemStack)NativeAccess.call(Class.forName("dev.zomboid.remains.WeaponLoot"),"ammo",NativeAccess.call(profile,"ammo"),48);if(!ammo.isEmpty())result.add(ammo);}}catch(ReflectiveOperationException|LinkageError ignored){}
  ItemStack medical=ZombieClothing.stack("firstaid:bandage",3);if(medical.isEmpty())medical=ZombieClothing.stack("firstaid:plaster",3);if(!medical.isEmpty())result.add(medical);result.add(ZombieClothing.stack("minecraft:cooked_beef",3));return result;
 }
 public static void corpse(Object corpse,Object level,boolean bandit,boolean mutant,Object entity){
  if(bandit||!(entity instanceof Mob mob)||!ZombieSleep.zombie(mob))return;
  try{Object inventory=field(corpse,"inventory");int slots=((Number)NativeAccess.call(inventory,"getContainerSize")).intValue();for(int i=0;i<slots;i++)if(ZombieClothing.vanillaArmor((ItemStack)NativeAccess.call(inventory,"getItem",i)))NativeAccess.call(inventory,"setItem",i,ItemStack.EMPTY);}catch(ReflectiveOperationException error){System.err.println("[Zomboid Integration] Corpse vanilla armor cleanup failed: "+error);}
  Context context=current();if(context==null||context.mob!=mob||!Objects.equals(context.kind,2)||mob.getPersistentData().getBoolean("zi_military_loot_delivered"))return;
  try{
   Object inventory=field(corpse,"inventory");setQuality(corpse,2);ItemStack guaranteed=ItemStack.EMPTY;int size=((Number)NativeAccess.call(inventory,"getContainerSize")).intValue();
   for(int i=0;i<size;i++){ItemStack current=(ItemStack)NativeAccess.call(inventory,"getItem",i);if(!current.isEmpty()&&NativeAccess.call(Class.forName("dev.zomboid.remains.GunAccess"),"describe",current)!=null){mark(current);guaranteed=current;break;}}
   boolean alreadyGun=!guaranteed.isEmpty();if(!alreadyGun)guaranteed=gun(mob);
   List<ItemStack> extras=supplies(mob,guaranteed);for(int i=alreadyGun?1:0;i<extras.size();i++)insert(inventory,extras.get(i));NativeAccess.call(inventory,"setChanged");mob.getPersistentData().putBoolean("zi_military_loot_delivered",true);
  }catch(Exception|LinkageError error){System.err.println("[Zomboid Integration] Military corpse guarantee failed; drops fallback will retain loot: "+error);}
 }
 @SubscribeEvent(priority=EventPriority.LOWEST,receiveCanceled=true) public static void fallback(net.neoforged.neoforge.event.entity.living.LivingDropsEvent event){
  if(event.getEntity().level().isClientSide||!ZombieSleep.zombie(event.getEntity()))return;Mob mob=(Mob)event.getEntity();
  if(mob.getPersistentData().getBoolean("zi_military_loot_delivered")||mob.getPersistentData().getInt("zi_zombie_worn_at_death")!=2)return;
  try{for(ItemStack stack:supplies(mob,gun(mob)))if(!stack.isEmpty()){
   var item=new net.minecraft.world.entity.item.ItemEntity(mob.level(),mob.getX(),mob.getY()+.1,mob.getZ(),stack);
   if(Boolean.TRUE.equals(NativeAccess.call(event,"isCanceled")))NativeAccess.call(mob.level(),"addFreshEntity",item);else event.getDrops().add(item);
  }mob.getPersistentData().putBoolean("zi_military_loot_delivered",true);}catch(Exception|LinkageError error){System.err.println("[Zomboid Integration] Military drops fallback failed: "+error);}
 }
}
