package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;import dev.zomboid.integration.care.Medical;
@Mixin(targets="ichttt.mods.firstaid.survival.MedicalSkills",remap=false)
public abstract class CareCreditMixin {
 @Inject(method="applied(Ljava/lang/Object;Ljava/lang/Object;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private static void care$credit(Object model,Object patient,CallbackInfo ci){var actor=Medical.CREDIT.get();if(actor!=null){ci.cancel();Medical.stat("survival.MedicalSkills","reward",actor);}}
}
