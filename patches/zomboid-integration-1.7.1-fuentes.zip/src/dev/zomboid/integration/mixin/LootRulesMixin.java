package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Pseudo @Mixin(targets="dev.zomboid.scavenging.Rules",remap=false)
public abstract class LootRulesMixin {
 @Inject(method="rarity(DDI)I",at=@At("HEAD"),cancellable=true,remap=false)
 private static void loot$rarity(double roll,double luck,int skill,CallbackInfoReturnable<Integer> ci){ci.setReturnValue(dev.zomboid.integration.loot.LootRules.rarity(roll,luck,skill));}
}
