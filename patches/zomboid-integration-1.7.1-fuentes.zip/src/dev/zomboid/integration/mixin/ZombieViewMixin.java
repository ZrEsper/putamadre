package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.world.entity.Entity;import net.minecraft.client.renderer.culling.Frustum;
@Mixin(targets="net.minecraft.client.renderer.entity.EntityRenderDispatcher",remap=false)
public abstract class ZombieViewMixin {
 @Inject(method="shouldRender(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/culling/Frustum;DDD)Z",at=@At("HEAD"),cancellable=true,remap=false)
 private void integration$observed(Entity entity,Frustum frustum,double x,double y,double z,CallbackInfoReturnable<Boolean> ci){if(dev.zomboid.integration.ZombieSleep.zombie(entity)&&!dev.zomboid.integration.client.IsoObservation.visible(entity))ci.setReturnValue(false);}
}
