package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Pseudo @Mixin(targets="dev.zomboid.remains.ZombieRemainsLoot",remap=false)
public abstract class ClothingLootContextMixin {
 @Inject(method="death(Lnet/neoforged/neoforge/event/entity/living/LivingDropsEvent;)V",at=@At("HEAD"),remap=false)
 private static void integration$begin(net.neoforged.neoforge.event.entity.living.LivingDropsEvent e,CallbackInfo ci){dev.zomboid.integration.MilitaryLoot.begin(e);}
 @Inject(method="death(Lnet/neoforged/neoforge/event/entity/living/LivingDropsEvent;)V",at=@At("RETURN"),remap=false)
 private static void integration$end(net.neoforged.neoforge.event.entity.living.LivingDropsEvent e,CallbackInfo ci){dev.zomboid.integration.MilitaryLoot.end();}
}
