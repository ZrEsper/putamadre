package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(targets={"net.flashlight.procedures.FlashlightEvenementAuClicDroitDansLairProcedure","net.flashlight.procedures.FlashlightOFFEvenementAuClicDroitDansLairProcedure"},remap=false)
public abstract class ToggleMixin {
 @Inject(method="execute(Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;Lnet/minecraft/world/item/ItemStack;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private static void integration$noRightClick(net.minecraft.world.level.LevelAccessor world,double x,double y,double z,net.minecraft.world.entity.Entity entity,net.minecraft.world.item.ItemStack stack,CallbackInfo ci){ci.cancel();}
}
