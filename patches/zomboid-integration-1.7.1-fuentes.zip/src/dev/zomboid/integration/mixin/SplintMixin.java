package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets="ichttt.mods.firstaid.fracture.SplintItem",remap=false)
public abstract class SplintMixin {
 @Inject(method="use(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder;",at=@At("HEAD"),cancellable=true,remap=false)
 private void care$select(net.minecraft.world.level.Level level,net.minecraft.world.entity.player.Player player,net.minecraft.world.InteractionHand hand,CallbackInfoReturnable<net.minecraft.world.InteractionResultHolder<net.minecraft.world.item.ItemStack>> ci){if(player instanceof net.minecraft.server.level.ServerPlayer server)dev.zomboid.integration.care.Care.self(server);ci.setReturnValue(net.minecraft.world.InteractionResultHolder.consume(player.getItemInHand(hand)));}
}
