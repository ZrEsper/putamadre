package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Pseudo @Mixin(targets="dev.zomboid.remains.MutantRules",remap=false)
public abstract class MilitaryMutantQualityMixin {
 @Inject(method="quality(D)I",at=@At("RETURN"),cancellable=true,remap=false)
 private static void integration$quality(double roll,CallbackInfoReturnable<Integer> ci){Integer quality=dev.zomboid.integration.MilitaryLoot.quality(roll,true);if(quality!=null)ci.setReturnValue(Math.max(ci.getReturnValueI(),quality));}
}
