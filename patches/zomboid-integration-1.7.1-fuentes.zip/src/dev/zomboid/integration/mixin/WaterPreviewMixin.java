package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.gui.GuiGraphics;import net.minecraft.client.Minecraft;import net.minecraft.core.BlockPos;
@Pseudo @Mixin(targets="homeostatic.overlay.HydrationOverlay",remap=false)
public abstract class WaterPreviewMixin {
 @Inject(method="render(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/Minecraft;Lnet/minecraft/core/BlockPos;II)V",at=@At("HEAD"),cancellable=true,remap=false)
 private void integration$actualOnly(GuiGraphics g,Minecraft mc,BlockPos p,int width,int height,CallbackInfo ci){ci.cancel();}
}
