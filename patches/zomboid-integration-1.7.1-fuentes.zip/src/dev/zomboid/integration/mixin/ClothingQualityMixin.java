package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Pseudo @Mixin(targets="dev.zomboid.remains.QualityRules",remap=false)
public abstract class ClothingQualityMixin {
 @Inject(method="roll(DZ)I",at=@At("HEAD"),cancellable=true,remap=false)
 private static void integration$quality(double roll,boolean bandit,CallbackInfoReturnable<Integer> ci){Integer quality=dev.zomboid.integration.MilitaryLoot.quality(roll,false);if(quality!=null)ci.setReturnValue(quality);}
}
