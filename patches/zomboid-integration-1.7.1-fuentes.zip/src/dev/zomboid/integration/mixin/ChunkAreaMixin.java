package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(targets="net.minecraft.server.players.PlayerList",remap=false)
public abstract class ChunkAreaMixin {
 @Inject(method="setViewDistance(I)V",at=@At("HEAD"),cancellable=true,remap=false)
 private void integration$view(int distance,CallbackInfo ci){if(dev.zomboid.integration.ChunkArea.intercept(this,distance,false))ci.cancel();}
 @Inject(method="setSimulationDistance(I)V",at=@At("HEAD"),cancellable=true,remap=false)
 private void integration$simulation(int distance,CallbackInfo ci){if(dev.zomboid.integration.ChunkArea.intercept(this,distance,true))ci.cancel();}
}
