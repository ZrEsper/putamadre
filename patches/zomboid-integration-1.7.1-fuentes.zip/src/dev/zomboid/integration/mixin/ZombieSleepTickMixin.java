package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;import net.minecraft.world.entity.Entity;
@Mixin(targets="net.minecraft.server.level.ServerLevel",remap=false)
public abstract class ZombieSleepTickMixin {
 @Inject(method="tickNonPassenger(Lnet/minecraft/world/entity/Entity;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private void integration$distant(Entity e,CallbackInfo ci){if(dev.zomboid.integration.ZombieSleep.frozen(e)){e.setDeltaMovement(0,0,0);ci.cancel();}}
}
