package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Pseudo @Mixin(targets="toughasnails.thirst.ThirstOverlayRenderer",remap=false)
public abstract class TanHudMixin {
 @Inject(method="onBeginRenderAir(Lglitchcore/event/client/RenderGuiEvent$Pre;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private static void integration$onlyHomeostatic(CallbackInfo ci){if(dev.zomboid.integration.TanHydration.useHomeostatic()){dev.zomboid.integration.TanHydration.disableDuplicate();ci.cancel();}}
}
