package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.Mixin;import org.spongepowered.asm.mixin.injection.*;import net.minecraft.world.entity.LivingEntity;import net.minecraft.world.item.ItemStack;import dev.zomboid.integration.Lamps;
@Mixin(targets="net.flashlight.procedures.LightEventProcedure",remap=false)
public abstract class HeldLightMixin {
 @Redirect(method="execute(Lnet/neoforged/bus/api/Event;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/entity/Entity;)Z",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/LivingEntity;getMainHandItem()Lnet/minecraft/world/item/ItemStack;"),remap=false)
 private static ItemStack integration$main(LivingEntity e){ItemStack s=e.getMainHandItem();return e instanceof net.minecraft.world.entity.player.Player&&Lamps.isLamp(s)?ItemStack.EMPTY:s;}
 @Redirect(method="execute(Lnet/neoforged/bus/api/Event;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/entity/Entity;)Z",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/LivingEntity;getOffhandItem()Lnet/minecraft/world/item/ItemStack;"),remap=false)
 private static ItemStack integration$off(LivingEntity e){ItemStack s=e.getOffhandItem();return e instanceof net.minecraft.world.entity.player.Player&&Lamps.isLamp(s)?ItemStack.EMPTY:s;}
}
