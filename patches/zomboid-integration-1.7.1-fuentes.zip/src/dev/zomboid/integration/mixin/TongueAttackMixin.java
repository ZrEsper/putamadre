package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;import net.minecraft.world.entity.Mob;
@Pseudo @Mixin(targets="dev.zomboid.mutants.Events",remap=false)
public abstract class TongueAttackMixin {
 @Inject(method="attackTongue(Lnet/neoforged/neoforge/event/entity/player/AttackEntityEvent;)V",at=@At("HEAD"),remap=false)
 private static void integration$source(AttackEntityEvent event,CallbackInfo ci){if(event.getTarget() instanceof Mob source&&dev.zomboid.mutants.Tethers.active(source)&&dev.zomboid.integration.combat.TongueRules.allowed(event.getEntity(),source)){dev.zomboid.mutants.AbilitySounds.cut(source);dev.zomboid.mutants.Tethers.release(source.getUUID());}}
}
