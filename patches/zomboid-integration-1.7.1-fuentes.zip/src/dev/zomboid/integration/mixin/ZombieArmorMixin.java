package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.world.entity.Entity;import net.minecraft.world.entity.EquipmentSlot;import net.minecraft.world.item.ItemStack;
@Mixin(targets="net.minecraft.world.entity.Mob",remap=false)
public abstract class ZombieArmorMixin {
 @Inject(method="setItemSlot(Lnet/minecraft/world/entity/EquipmentSlot;Lnet/minecraft/world/item/ItemStack;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private void integration$clothing(EquipmentSlot slot,ItemStack stack,CallbackInfo ci){if(dev.zomboid.integration.ZombieSleep.zombie((Entity)(Object)this)&&dev.zomboid.integration.ZombieClothing.disallow(slot,stack))ci.cancel();}
}
