package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.world.entity.player.Player;
@Pseudo @Mixin(targets="toughasnails.thirst.ThirstHandler",remap=false)
public abstract class TanThirstMixin {
 @Inject(method="onPlayerTick(Lnet/minecraft/world/entity/player/Player;)V",at=@At("HEAD"),remap=false)
 private static void integration$singleHydration(Player player,CallbackInfo ci){dev.zomboid.integration.TanHydration.disableDuplicate();}
}
