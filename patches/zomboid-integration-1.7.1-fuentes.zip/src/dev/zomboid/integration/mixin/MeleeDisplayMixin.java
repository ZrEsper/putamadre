package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.world.item.*;import com.mojang.blaze3d.vertex.PoseStack;import net.minecraft.client.renderer.MultiBufferSource;import net.minecraft.client.Minecraft;
@Pseudo @Mixin(targets="dev.zomboidmelee.client.NativeBatRenderer",remap=false)
public abstract class MeleeDisplayMixin {
 @Inject(method="renderByItem(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II)V",at=@At("HEAD"),cancellable=true,remap=false)
 private void integration$original(ItemStack stack,ItemDisplayContext context,PoseStack pose,MultiBufferSource buffers,int light,int overlay,CallbackInfo ci){dev.zomboidmelee.client.BridgeExtensions.beginOriginal();try{Minecraft mc=Minecraft.getInstance();mc.getItemRenderer().renderStatic(stack,context,light,overlay,pose,buffers,mc.level,0);}finally{dev.zomboidmelee.client.BridgeExtensions.endOriginal();}ci.cancel();}
}
