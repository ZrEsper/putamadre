package dev.zomboid.integration.mixin;
import java.util.*;import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
import net.minecraft.world.entity.Entity;import net.minecraft.world.entity.player.Player;import dev.zomboid.integration.combat.TongueRules;
@Pseudo @Mixin(targets="dev.zomboid.mutants.Tethers",remap=false)
public abstract class TongueMixin {
 @Shadow @Final private static Map<UUID,?> LINKS;
 @Shadow @Final private static Map<UUID,UUID> HANDLES;
 @Shadow public static void release(UUID id){throw new AssertionError();}
 @Inject(method="cut(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/Entity;)Z",at=@At("HEAD"),cancellable=true,remap=false)
 private static void integration$cut(Player player,Entity segment,CallbackInfoReturnable<Boolean> ci){UUID id=HANDLES.get(segment.getUUID());if(id==null)for(var e:LINKS.entrySet())if(TongueRules.victim(e.getValue())==segment){id=e.getKey();break;}if(id==null)return;if(!TongueRules.allowed(player,segment)){ci.setReturnValue(false);return;}dev.zomboid.mutants.AbilitySounds.cut(segment);release(id);ci.setReturnValue(true);}
}
