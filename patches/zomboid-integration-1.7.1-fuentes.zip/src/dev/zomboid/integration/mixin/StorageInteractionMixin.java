package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Pseudo @Mixin(targets="cn.kafei.interact.Interaction",remap=false)
public abstract class StorageInteractionMixin {
 @Inject(method="supported(Ljava/lang/Object;)Z",at=@At("RETURN"),cancellable=true,remap=false)
 private static void integration$storage(Object target,CallbackInfoReturnable<Boolean> result){
  if( dev.zomboid.integration.loot.StorageTypes.supported(target)) result.setReturnValue(true);
 }
}
