package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Pseudo @Mixin(targets="dev.zomboid.remains.NpcCompatibility",remap=false)
public abstract class MilitaryCorpseMixin {
 @Inject(method="extras(Ljava/lang/Object;Ljava/lang/Object;ZZLjava/lang/Object;)V",at=@At("RETURN"),remap=false)
 private static void integration$military(Object corpse,Object level,boolean bandit,boolean mutant,Object entity,CallbackInfo ci){dev.zomboid.integration.MilitaryLoot.corpse(corpse,level,bandit,mutant,entity);}
}
