package dev.zomboid.integration;
public final class ClothingRules {
 private ClothingRules(){}
 public static int kind(double roll,double civilian,double military){if(!Double.isFinite(roll)||roll<0||roll>=1)return 0;return roll<military?2:roll<military+civilian?1:0;}
 public static int quality(int kind,double roll){return kind==2?(roll<.25?3:2):kind==1?(roll<.1?2:1):0;}
}
