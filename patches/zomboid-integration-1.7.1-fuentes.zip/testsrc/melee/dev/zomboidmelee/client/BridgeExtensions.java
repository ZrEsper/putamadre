package dev.zomboidmelee.client;public class BridgeExtensions {public static int depth;public static void beginOriginal(){depth++;}public static void endOriginal(){depth--;}}
