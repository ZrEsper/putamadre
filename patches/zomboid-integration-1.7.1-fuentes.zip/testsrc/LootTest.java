import dev.zomboid.integration.loot.*;
public class LootTest {
 static class Target {Object entity,pos;Target(Object e,Object p){entity=e;pos=p;}}
 static class Pos {public int getX(){return 0;}public int getY(){return 0;}public int getZ(){return 0;}}
 static class Actor {double distance;Actor(double d){distance=d;}public double distanceToSqr(Object e){return distance;}public double distanceToSqr(double x,double y,double z){if(x!=.5||y!=.5||z!=.5)throw new AssertionError("center");return distance;}}
 static class Job {Object player,target;Job(Object p,Object t){player=p;target=t;}}
 public static void main(String[] args){int checks=0;for(int skill:new int[]{0,5,10})for(double luck:new double[]{-2,0,8}){int oldHigh=0,newHigh=0,oldLegend=0,newLegend=0;for(int i=0;i<100000;i++){double r=(i+.5)/100000;int old=dev.zomboid.scavenging.Rules.rarity(r,luck,skill),n=LootRules.rarity(r,luck,skill);if(old>=3)oldHigh++;if(n>=3)newHigh++;if(old==4)oldLegend++;if(n==4)newLegend++;if(n>old)throw new AssertionError("upgraded");}if(Math.abs(newHigh-oldHigh*.2)>1||Math.abs(newLegend-oldLegend*.2)>1)throw new AssertionError("rate");checks++;}
 for(Object target:new Object[]{new Target(new Object(),null),new Target(null,new Pos())}){if(!LootReach.job(new Job(new Actor(9),target)))throw new AssertionError("boundary");if(LootReach.job(new Job(new Actor(9.001),target)))throw new AssertionError("remote");if(LootReach.job(new Job(new Actor(Double.NaN),target)))throw new AssertionError("nan");checks+=3;}System.out.println(checks+" checks passed; 900000 rolls compared with actual Quietly Rules");}
}
