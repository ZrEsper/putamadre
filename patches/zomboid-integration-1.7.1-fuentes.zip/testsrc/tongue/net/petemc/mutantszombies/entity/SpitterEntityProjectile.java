package net.petemc.mutantszombies.entity;public class SpitterEntityProjectile extends net.minecraft.world.entity.Entity {}
