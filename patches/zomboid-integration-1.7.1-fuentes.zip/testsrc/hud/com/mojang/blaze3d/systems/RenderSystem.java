package com.mojang.blaze3d.systems;
public class RenderSystem {
 public static float[] color={1,1,1,1};public static boolean blend;public static int[] factors={1,0,1,0};
 public static float[] getShaderColor(){return color;}
 public static void setShaderColor(float r,float g,float b,float a){color=new float[]{r,g,b,a};}
 public static void enableBlend(){blend=true;}public static void disableBlend(){blend=false;}
 public static void defaultBlendFunc(){factors=new int[]{770,771,1,0};}
 public static void blendFuncSeparate(int a,int b,int c,int d){factors=new int[]{a,b,c,d};}
}
