package org.lwjgl.opengl;
import com.mojang.blaze3d.systems.RenderSystem;
public class GL11 {public static boolean glIsEnabled(int cap){return RenderSystem.blend;}public static int glGetInteger(int cap){return RenderSystem.factors[switch(cap){case 32969->0;case 32968->1;case 32971->2;case 32970->3;default->throw new AssertionError(cap);}];}}
