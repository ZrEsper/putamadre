package dev.zomboid.scavenging;
/** Compile-only signatures; the real classes are supplied by Quietly. */
public final class Search {public static final class Target {}public static final class Job {}}
