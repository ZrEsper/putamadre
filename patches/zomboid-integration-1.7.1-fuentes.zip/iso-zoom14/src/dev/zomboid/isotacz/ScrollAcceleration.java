package dev.zomboid.isotacz;
/** Smooth isolated steps, accelerated rapid wheel bursts, reset when reversing. */
public final class ScrollAcceleration {
 private static long last;private static int direction;private static double momentum;
 private ScrollAcceleration(){}
 public static double adjust(double delta){
  try{
   Class<?> mod=Class.forName("com.cleannrooster.dungeons_iso.mod.Mod");
   Object holder=Class.forName("com.cleannrooster.dungeons_iso.config.Config").getField("GSON").get(null);
   Object config=holder.getClass().getMethod("instance").invoke(holder);
   if(!mod.getField("enabled").getBoolean(null)||!config.getClass().getField("scrollWheelZoom").getBoolean(config)){last=0;direction=0;momentum=0;return delta;}
   return sample(delta,System.nanoTime());
  }catch(ReflectiveOperationException|LinkageError error){return delta;}
 }
 public static double sample(double delta,long now){
  if(!Double.isFinite(delta)||delta==0)return 0;
  int sign=delta>0?1:-1;long gap=now-last;
  if(sign!=direction||gap<0||gap>220_000_000L)momentum=0;
  else momentum=Math.min(3,momentum+Math.min(1,Math.abs(delta))*(1-gap/220_000_000.0));
  direction=sign;last=now;
  return Math.copySign(Math.min(10,Math.abs(delta)*(1+momentum)),delta);
 }
}
