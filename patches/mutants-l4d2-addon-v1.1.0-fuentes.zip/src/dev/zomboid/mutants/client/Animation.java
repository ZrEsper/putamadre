package dev.zomboid.mutants.client;
import dev.zomboid.mutants.*;import net.minecraft.world.entity.Entity;import net.minecraft.client.model.geom.ModelPart;
@net.neoforged.fml.common.EventBusSubscriber(modid=MutantAddon.ID,value=net.neoforged.api.distmarker.Dist.CLIENT)
public final class Animation {
 public static Signals.Pose signal(Entity entity){return Signals.get(entity.getUUID());}
 public static void tank(Entity e,float age,ModelPart head,ModelPart torso,ModelPart right,ModelPart left){var s=signal(e);if(s==null)return;float p=Rules.progress(e.level().getGameTime(),s.start(),s.duration());switch(s.phase()){
 case Rules.WINDUP->{torso.xRot=.2f;right.xRot=-.4f;left.xRot=-.4f;}
 case Rules.CHARGE->{torso.xRot=.55f;head.xRot=.25f;right.xRot=-1;left.xRot=-1;}
 case Rules.STUN->{torso.xRot=.7f;head.xRot=.55f;right.xRot=.35f;left.xRot=.35f;}
 case Rules.THROW->{torso.xRot=-.15f*p;right.xRot=-2.6f*Math.min(1,p*1.7f);left.xRot=right.xRot;}
 case Rules.RECOVER->{right.xRot=-2.6f*(1-p);left.xRot=right.xRot;torso.xRot=.3f*(1-p);}
 }}
 public static void brute(Entity e,ModelPart torso,ModelPart right,ModelPart left){var s=signal(e);if(s!=null&&s.phase()==Rules.SMASH){float p=Rules.progress(e.level().getGameTime(),s.start(),s.duration());right.xRot=-.5f-2*p;left.xRot=right.xRot;torso.xRot=-.1f*p;}}
 public static void witch(Entity e,float age,ModelPart head1,ModelPart head2,ModelPart torso,ModelPart left,ModelPart right){var s=signal(e);boolean furious=s!=null&&s.phase()==Rules.FURY;if(furious){torso.xRot=.28f;head1.xRot-=.2f;head2.xRot-=.2f;left.xRot*=1.25f;right.xRot*=1.25f;}else{float breath=(float)Math.sin(age*.09)*.035f;torso.xRot=.7f+breath;torso.y+=6;head1.y+=6;head2.y+=6;head1.xRot=.8f+breath;head2.xRot=.85f+breath;left.xRot=-1.45f;right.xRot=-1.45f;left.y+=3;right.y+=3;left.z+=2;right.z+=2;}}
 @net.neoforged.bus.api.SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event){if(net.minecraft.client.Minecraft.getInstance().level==null)Signals.clear();}
}
