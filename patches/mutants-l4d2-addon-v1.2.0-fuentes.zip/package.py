from pathlib import Path
import zipfile,json,io,hashlib
from PIL import Image,ImageDraw
root=Path('work/mutants');out=Path('work/mutants-l4d2-addon-1.2.0-neoforge-1.21.1.jar')
files={}
for p in (root/'classes').rglob('*.class'):
 n=str(p.relative_to(root/'classes'));assert n.startswith('dev/zomboid/mutants/');files[n]=p.read_bytes()
files['META-INF/neoforge.mods.toml']=b'''modLoader="javafml"
loaderVersion="[4,)"
license="All Rights Reserved"
[[mods]]
modId="mutants_l4d2"
version="1.2.0"
displayName="Mutants: Bilis y ataques especiales"
authors="Mecanicas personalizadas"
description="""Bilis, Witch, tanque, golpe al suelo, toxinas, acido y salto Hunter para Mutants and Zombies 1.3.1."""
[[dependencies.mutants_l4d2]]
modId="neoforge"
type="required"
versionRange="[21.1,)"
ordering="NONE"
side="BOTH"
[[dependencies.mutants_l4d2]]
modId="minecraft"
type="required"
versionRange="[1.21.1,1.21.2)"
ordering="NONE"
side="BOTH"
[[dependencies.mutants_l4d2]]
modId="mutantszombies"
type="required"
versionRange="[1.3.1-NeoForge-mc1.21]"
ordering="AFTER"
side="BOTH"
[[mixins]]
config="mutants_l4d2.mixins.json"
'''
files['mutants_l4d2.mixins.json']=json.dumps({'required':True,'minVersion':'0.8','package':'dev.zomboid.mutants.mixin','compatibilityLevel':'JAVA_21','mixins':['MobGoals','WitchSounds','TankTerrain','BanditNPC','BanditEmergency'],'client':['TankModel','WitchModel','SmashModel','SpitterModel','CrawlerModel','BlisterModel','RottenModel'],'injectors':{'defaultRequire':1}},indent=2).encode()
for lang in ['es_es','es_mx','en_us']:
 text='Bilis' if lang.startswith('es') else 'Bile';files[f'assets/mutants_l4d2/lang/{lang}.json']=json.dumps({'effect.mutants_l4d2.bilis':text},ensure_ascii=False,indent=2).encode()
im=Image.new('RGBA',(18,18));d=ImageDraw.Draw(im);d.polygon([(8,1),(3,8),(2,11),(3,15),(6,17),(11,17),(14,14),(14,10)],fill=(62,83,24,255));d.polygon([(8,3),(4,9),(4,13),(6,15),(10,15),(12,13),(12,10)],fill=(151,175,41,255));d.line([(7,6),(5,10),(5,12)],fill=(212,225,107,255),width=2);d.ellipse((14,2,17,5),fill=(144,169,38,255));d.rectangle((0,3,2,5),fill=(107,137,31,255));bio=io.BytesIO();im.save(bio,format='PNG');files['assets/mutants_l4d2/textures/mob_effect/bilis.png']=bio.getvalue()
files['pack.mcmeta']=json.dumps({'pack':{'pack_format':34,'description':'Mutants L4D2: Bilis y ataques especiales'}}).encode()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in files.items():z.writestr(n,b)
b=out.read_bytes();print(out,len(b));print('SHA256',hashlib.sha256(b).hexdigest());print('Git blob',hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
