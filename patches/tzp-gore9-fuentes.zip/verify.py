import json,zipfile,re,math,itertools
pack=zipfile.ZipFile('work/tzp-gore8/TZP_1.20.1_2.7.zip');native={'zg_loss','zg_wounds','zg_burn','zg_exit','zg_broken','zg_ballistic','zg_blunt','zg_cut'};conditions=projections=0
for mob in ['zombie','husk','drowned','drowned_outer']:
 o=json.loads(pack.read('assets/minecraft/optifine/cem/'+mob+'.jem'));a=o['models'][0]['animations'];assert a[0]['var.zg_rear']=='zg_exit';assert a[0]['varb.zg_crawl']=='var.zgl4>0&&var.zgl5>0'
 for g in a:
  for v in g.values():
   if isinstance(v,str):assert set(re.findall(r'(?<![\w.])zg_[a-zA-Z_]+',v))<=native
 for flags in range(256):
  assert (bool((flags>>4)&1) and bool((flags>>5)&1))==((flags&48)==48);conditions+=1
 p=next(g for g in a if 'root.rx' in g);assert p['root.rx']=='0';assert 'limb_swing' in p['left_arm.rx'] and 'limb_speed' in p['right_arm.rx']
 # Evaluate the actual new expressions against a standard humanoid envelope.
 boxes={'head':(-4.25,-8.25,-4.25,8.5,8.5,8.5),'body':(-4.05,-.05,-2.05,8.1,12.1,4.1),'left_arm':(-1.05,-2.05,-2.05,4.1,12.1,4.1),'right_arm':(-3.05,-2.05,-2.05,4.1,12.1,4.1)}
 for frame in range(64):
  for speed in [0,.1,1]:
   env={'limb_swing':frame*.2,'limb_speed':speed,'head_pitch':math.sin(frame)*90,'head_yaw':math.cos(frame)*180,'varb.zg_crawl':True,'var.zgl2':0,'var.zgl3':0,'var.zgl4':1,'var.zgl5':1,'var.zgb0':0,'var.zgb1':0}
   for part in ['root','head','headwear','body','left_arm','right_arm','left_leg','right_leg']:
    for axis in ['rx','ry','rz','tx','ty','tz']:env[part+'.'+axis]=0
   fns={'choose':lambda c,x,y:x if c else y,'sin':math.sin,'torad':math.radians,'clamp':lambda v,l,h:max(l,min(h,v)),'pi':math.pi}
   for k,v in p.items():
    s=v.replace('if(','choose(').replace('&&',' and ').replace('||',' or ')
    s=re.sub(r'\b(?:varb|var|root|head|headwear|body|left_arm|right_arm|left_leg|right_leg)\.[A-Za-z_0-9]+\b',lambda m:'env['+repr(m[0])+']',s)
    env[k]=eval(s,{'__builtins__':{},**fns,**env,'env':env})
   for part,box in boxes.items():
    ax,ay,az=(env[part+'.'+v] for v in ['rx','ry','rz']);px,py,pz=(env[part+'.'+v] for v in ['tx','ty','tz']);x0,y0,z0,dx,dy,dz=box
    for x,y,z in itertools.product((x0,x0+dx),(y0,y0+dy),(z0,z0+dz)):
     y,z=y*math.cos(ax)-z*math.sin(ax),y*math.sin(ax)+z*math.cos(ax)
     x,z=x*math.cos(ay)+z*math.sin(ay),-x*math.sin(ay)+z*math.cos(ay)
     x,y=x*math.cos(az)-y*math.sin(az),x*math.sin(az)+y*math.cos(az)
     wx=-(x+px)/16;wy=1.501-(y+py)/16;wz=(z+pz)/16
     assert math.hypot(wx,wz)<=.9 and -.01<=wy<=.82,(mob,part,frame,speed,wx,wy,wz)
     projections+=1
print('PASS',conditions,'leg states; native Gore variables mapped;',projections,'adult humanoid corner projections fit 1.8x0.82 box, including outer head skin.')
print('This is a mathematical/static fixture, not an executed EMF render.')
