from pathlib import Path
import zipfile,json,copy
r=Path('work/tzp-gore8');source=Path('attachments/331ba1f3-66b5-4904-b32f-0ef9058a5e21/TZP-1.21.1-Gore.8-local-blended-surfaces (1).zip');out=r/'TZP_1.20.1_2.7.zip';changed=[]
# Use articulation of actual limbs rather than rotating the empty attached helper root.
# Normal Fresh Animations and all lesion geometry remain untouched.
phase='limb_swing*.7';amplitude='clamp(limb_speed*3,0,1)'
pose={
 'root.rx':'0','root.ry':'0','root.rz':'0','root.tx':'0','root.ty':'0','root.tz':'0',
 'head.rx':'if(varb.zg_crawl,clamp(torad(head_pitch),-.2,.2),head.rx)',
 'head.ry':'if(varb.zg_crawl,clamp(torad(head_yaw),-pi/3,pi/3),head.ry)',
 'head.rz':'if(varb.zg_crawl,0,head.rz)',
 'head.tx':'if(varb.zg_crawl,0,head.tx)',
 'head.ty':f'if(varb.zg_crawl,21+sin({phase}*2)*.1*{amplitude},head.ty)',
 'head.tz':'if(varb.zg_crawl,-2,head.tz)',
 'body.rx':'if(varb.zg_crawl,pi/2,body.rx)','body.ry':'if(varb.zg_crawl,0,body.ry)',
 'body.rz':f'if(varb.zg_crawl,sin({phase})*.025*{amplitude},body.rz)',
 'body.tx':'if(varb.zg_crawl,0,body.tx)','body.ty':'if(varb.zg_crawl,head.ty,body.ty)','body.tz':'if(varb.zg_crawl,0,body.tz)',
 'headwear.rx':'head.rx','headwear.ry':'head.ry','headwear.rz':'head.rz',
 'headwear.tx':'if(varb.zg_crawl,head.tx,headwear.tx)','headwear.ty':'if(varb.zg_crawl,head.ty,headwear.ty)','headwear.tz':'if(varb.zg_crawl,head.tz,headwear.tz)',
 'left_arm.rx':f'if(var.zgl2>0||var.zgb0>0,if(varb.zg_crawl,-pi/2+.15,.15),if(varb.zg_crawl,-pi/2+sin({phase})*.2*{amplitude},left_arm.rx))',
 'right_arm.rx':f'if(var.zgl3>0||var.zgb1>0,if(varb.zg_crawl,-pi/2+.15,.15),if(varb.zg_crawl,-pi/2-sin({phase})*.2*{amplitude},right_arm.rx))',
 'left_arm.ry':'if(varb.zg_crawl,0,left_arm.ry)','right_arm.ry':'if(varb.zg_crawl,0,right_arm.ry)',
 'left_arm.rz':'if(varb.zg_crawl,.08,left_arm.rz)','right_arm.rz':'if(varb.zg_crawl,-.08,right_arm.rz)',
 'left_arm.tx':'if(varb.zg_crawl,5,left_arm.tx)','right_arm.tx':'if(varb.zg_crawl,-5,right_arm.tx)',
 'left_arm.ty':'if(varb.zg_crawl,19.7,left_arm.ty)','right_arm.ty':'if(varb.zg_crawl,19.7,right_arm.ty)',
 'left_arm.tz':'if(varb.zg_crawl,-1,left_arm.tz)','right_arm.tz':'if(varb.zg_crawl,-1,right_arm.tz)',
 'left_leg.visible':'var.zgl4==0','right_leg.visible':'var.zgl5==0',
 # Restore original rotations already computed by the preceding animation groups.
 # Lost legs are hidden, so no artificial dangling-leg swing is necessary.
}
with zipfile.ZipFile(source) as base,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 assert base.testzip() is None
 for n in base.namelist():
  b=base.read(n)
  if n.endswith(('/zombie.jem','/husk.jem','/drowned.jem','/drowned_outer.jem')):
   o=json.loads(b);before=copy.deepcopy(o);roots=[m for m in o['models'] if m.get('id')=='root'];assert len(roots)==1;anim=roots[0]['animations'];assert 'varb.zg_crawl' in anim[0];anim[0]['var.zg_rear']='zg_exit';anim[0]['varb.zg_crawl']='var.zgl4>0&&var.zgl5>0'
   indexes=[i for i,a in enumerate(anim) if 'root.rx' in a];assert len(indexes)==1;anim[indexes[0]]=dict(pose)
   # Every original model/box/surface and every normal Fresh animation group is preserved.
   for old,new in zip(before['models'],o['models']):
    assert {k:v for k,v in old.items() if k!='animations'}=={k:v for k,v in new.items() if k!='animations'}
   for i,a in enumerate(before['models'][0]['animations']):
    if i not in [0,indexes[0]]:assert a==anim[i]
   b=(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode();changed.append(n)
  elif n=='pack.mcmeta':
   o=json.loads(b);o['pack']['description']='TZP Gore 9: Gore.8 surfaces + synchronized crawling / Gore 1.0.7';b=(json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode();changed.append(n)
  z.writestr(n,b)
with zipfile.ZipFile(source) as base,zipfile.ZipFile(out) as z:
 assert z.testzip() is None;assert set(z.namelist())==set(base.namelist())
 for n in base.namelist():
  if n not in changed:assert base.read(n)==z.read(n)
  if n.endswith(('.jem','.jpm','.mcmeta')) or n in changed:json.loads(z.read(n))
print('Complete pack',out.stat().st_size,'bytes; changed:',changed,'other',4056-len(changed),'entries byte-identical')
(r/'changed.json').write_text(json.dumps(changed,indent=2))
