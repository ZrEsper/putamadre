Zomboid Integration 1.0.0 — primera etapa: linterna
Minecraft 1.21.1 / NeoForge 21.1.190 o posterior.

INSTALACION
Añadir el JAR de integración a mods en cliente y servidor. Conservar Flashlight 5.1 corregido safe-light.1 y TCTCore. Este mod es aparte: no sustituye Flashlight ni Zomboid Hordes.

USO
X enciende/apaga una linterna. Se puede cambiar en Controles > Zomboid Integration.
Prioridad: mano principal, mano secundaria, primera linterna del inventario normal.
Al equiparla aparece una indicación breve con la tecla configurada.
El clic derecho ya no cambia el estado de la linterna.
Las linternas encendidas iluminan desde el inventario. Al tirarlas iluminan desde el suelo; el haz conserva la dirección de la mirada al tirarlas. Apagadas no iluminan. El objeto conserva su estado y sus componentes al alternar, tirarlo y recogerlo.
No se alteran las reglas normales de desaparición o destrucción de objetos tirados.
Se conserva la comprobación de batería original del jugador para permitir encender; no introduce otro sistema de batería.
Las luces se colocan solo en aire o se refrescan si son bloques de luz del propio mod; no cargan chunks. Se aprovecha la eliminación temporal de Flashlight para retirar la luz cuando deja de haber una fuente.

VERIFICACION
20 comprobaciones funcionales con API simulada: estado, metadatos, selección y colocación segura.
Validación de bytecode, JSON, dependencias, integridad ZIP y huella del archivo publicado.
No se ejecutó Minecraft ni una prueba LAN real. Comprobar encendido desde inventario, lanzamiento/recogida, paredes y vegetación tras instalar.
Esta versión implementa únicamente la primera etapa de linterna acordada.
