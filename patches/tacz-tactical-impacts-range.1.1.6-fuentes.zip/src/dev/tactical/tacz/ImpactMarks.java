package dev.tactical.tacz;
import java.util.*;
/** Bounded session-local storage: unloads and particle optimizers do not erase the record. */
public final class ImpactMarks {
 static final int LIMIT=2048;static Object world;static boolean replay;static int ticks;
 record Key(long x,long y,long z,String face){}
 static final class Mark {Object particle,level,face,pos;double x,y,z;String ammo,gun,display;Object originalState;}
 static final Map<Key,Mark> marks=new LinkedHashMap<>();
 public static void remember(Object particle,Object level,double x,double y,double z,Object face,Object pos,String ammo,String gun,String display){try{
  if(replay)return;if(world!=level){marks.clear();world=level;}Mark m=new Mark();m.particle=particle;m.level=level;m.x=x;m.y=y;m.z=z;m.face=face;m.pos=pos;m.ammo=ammo;m.gun=gun;m.display=display;
  m.originalState=Reflect.call(level,"getBlockState",pos);configure(particle);Key key=new Key(Double.doubleToLongBits(x),Double.doubleToLongBits(y),Double.doubleToLongBits(z),String.valueOf(face));Mark previous=marks.put(key,m);if(previous!=null)Reflect.call(previous.particle,"remove");while(marks.size()>LIMIT){var it=marks.values().iterator();Reflect.call(it.next().particle,"remove");it.remove();}
 }catch(Exception e){Reflect.warn("persistent impact capture",e);}}
 static void configure(Object p)throws Exception{ShotAlignment.set(p,"lifetime",Integer.MAX_VALUE);ShotAlignment.set(p,"alpha",1F);ShotAlignment.set(p,"quadSize",.08F);}
 public static void keepUnloaded(Object p,Object callback){if(unloaded(p))try{Reflect.call(callback,"setReturnValue",false);}catch(Exception e){Reflect.warn("impact chunk guard",e);}}
 public static void translate(Object stack,double x,double y,double z){try{Reflect.call(stack,"translate",x,0D,z);}catch(Exception e){Reflect.warn("world tracer pose",e);}}
 public static boolean unloaded(Object particle){try{return !Boolean.TRUE.equals(Reflect.call(Reflect.field(particle,"level"),"hasChunkAt",Reflect.field(particle,"pos")));}catch(Exception e){return false;}}
 public static float size(Object p){try{Object mc=Reflect.call(Reflect.type("net.minecraft.client.Minecraft"),"getInstance"),camera=Reflect.call(Reflect.field(mc,"gameRenderer"),"getMainCamera"),v=Reflect.call(camera,"getPosition");double dx=ShotAlignment.f(p,"x")-ShotAlignment.f(v,"x"),dy=ShotAlignment.f(p,"y")-ShotAlignment.f(v,"y"),dz=ShotAlignment.f(p,"z")-ShotAlignment.f(v,"z");return (float)Math.max(.08,Math.min(.4,Math.sqrt(dx*dx+dy*dy+dz*dz)*.002));}catch(Exception e){return .08F;}}
 public static void tick(){try{Object mc=Reflect.call(Reflect.type("net.minecraft.client.Minecraft"),"getInstance"),level=Reflect.field(mc,"level");if(level==null||level!=world){marks.clear();world=level;return;}if(++ticks%20!=0)return;Object player=Reflect.field(mc,"player");if(player==null)return;double px=ShotAlignment.n(Reflect.call(player,"getX")),py=ShotAlignment.n(Reflect.call(player,"getEyeY")),pz=ShotAlignment.n(Reflect.call(player,"getZ"));int restored=0;
  for(var it=marks.values().iterator();it.hasNext();){Mark m=it.next();if(!Boolean.TRUE.equals(Reflect.call(level,"hasChunkAt",m.pos)))continue;Object state=Reflect.call(level,"getBlockState",m.pos);if(!Objects.equals(state,m.originalState)){Reflect.call(m.particle,"remove");it.remove();continue;}
   if(Boolean.TRUE.equals(Reflect.call(m.particle,"isAlive")))continue;double d=(m.x-px)*(m.x-px)+(m.y-py)*(m.y-py)+(m.z-pz)*(m.z-pz);if(d>256D*256||restored>=64)continue;
   replay=true;try{m.particle=ShotAlignment.construct("com.tacz.guns.client.particle.BulletHoleParticle",level,m.x,m.y,m.z,m.face,m.pos,m.ammo,m.gun,m.display);configure(m.particle);Reflect.call(Reflect.field(mc,"particleEngine"),"add",m.particle);restored++;}finally{replay=false;}
  }
 }catch(Exception e){replay=false;Reflect.warn("persistent impact restore",e);}}
 public static Object tracking(Object builder,int old){try{return Reflect.call(builder,"clientTrackingRange",32);}catch(Exception e){Reflect.warn("bullet tracking range",e);return builder;}}
 public static int send(Object level,Object option,double x,double y,double z,int count,double dx,double dy,double dz,double speed){
  try{if(option.getClass().getName().equals("com.tacz.guns.particles.BulletHoleOption")){int delivered=0;for(Object p:(Iterable<?>)Reflect.call(level,"players")){double a=ShotAlignment.n(Reflect.call(p,"getX"))-x,b=ShotAlignment.n(Reflect.call(p,"getEyeY"))-y,c=ShotAlignment.n(Reflect.call(p,"getZ"))-z;if(a*a+b*b+c*c>256D*256)continue;if(Boolean.TRUE.equals(Reflect.call(level,"sendParticles",p,option,true,x,y,z,count,dx,dy,dz,speed)))delivered++;}return delivered;}}
  catch(Exception e){Reflect.warn("long-range impact notification",e);}try{return ((Number)Reflect.call(level,"sendParticles",option,x,y,z,count,dx,dy,dz,speed)).intValue();}catch(Exception e){Reflect.warn("native impact notification",e);return 0;}
 }
}
