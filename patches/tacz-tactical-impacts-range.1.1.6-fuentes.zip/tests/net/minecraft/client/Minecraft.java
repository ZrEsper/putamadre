package net.minecraft.client;import java.util.*;import net.minecraft.world.phys.*;import net.minecraft.world.level.*;
public class Minecraft {
 static final Minecraft INSTANCE=new Minecraft();public static Minecraft getInstance(){return INSTANCE;}
 public net.minecraft.world.entity.player.Player player=new net.minecraft.world.entity.player.Player();public Renderer gameRenderer=new Renderer();public Level level=new Level();public Engine particleEngine=new Engine();public boolean sameThread=true;public Runnable queued;public final List<String> order=new ArrayList<>();public final Connection connection=new Connection();
 public boolean isSameThread(){return sameThread;}public void execute(Runnable r){queued=r;}public Connection getConnection(){return connection;}
 public class Connection {public net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot last;public void send(Object packet){last=(net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot)packet;order.add("rotation");}}
 public static class Engine {public int added;public void add(Object p){added++;}}
 public static class Renderer {public Camera getMainCamera(){return new Camera();}}
 public static class Camera {public Vec3 getPosition(){return new Vec3(3,2,0);}public Vec3 getLookVector(){return new Vec3(0,0,1);}}
 public static class Hit {public Vec3 getLocation(){return new Vec3(3,2,24);}}
 public static class Level {public int clips;public boolean loaded=true;public Object state="stone";public boolean hasChunkAt(Object p){return loaded;}public Object getBlockState(Object p){return state;}public Hit clip(ClipContext c){clips++;return new Hit();}public java.util.List<Object> getEntities(net.minecraft.world.entity.Entity e,AABB box,java.util.function.Predicate<Object> p){return List.of();}}
}
