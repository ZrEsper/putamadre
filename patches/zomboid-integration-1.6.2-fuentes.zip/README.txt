Zomboid Integration 1.2.0 — linterna y atención médica

INSTALACION
Reemplazar cualquier versión anterior de Zomboid Integration por 1.6.2 en mods de cliente y servidor, sin duplicados. Conservar Flashlight 5.1 corregido + TCTCore, First Aid ZOMBOID 3.4.9 global-health-revival, SurvivorCreator v24 y Quietly v10. No requiere sustituir esos tres JARs.

MEDICINA
Clic derecho en un jugador cercano abre la elección Revisarme / Revisar a [jugador]. Revisarme se habilita si hay lesiones. Se examina durante 30 ticks (1.5 segundos a 20 TPS), con barra; luego se muestran ocho zonas y su estado real del servidor: salud, cortes, disparos, balas alojadas, mordeduras, sangrado, vendaje limpio/sucio, infección, fracturas e inmovilización.
Elegir zona y Vendar / Férula / Extraer bala / Curar. Los materiales se buscan en el inventario del médico y se consumen o desgastan al completar la aplicación. No consume si se interrumpe por distancia, movimiento, daño o pérdida del material. Alcance máximo 3 bloques con visión directa. Esc/cerrar cancela.
Las férulas ya no se aplican automáticamente a la primera pierna: clic derecho con una férula abre el menú propio. Elegir la pierna fracturada y Férula; aplicación base 3 segundos, ajustada por el nivel de First Aid. La fractura queda inmovilizada y conserva la recuperación original de 2400 ticks (2 minutos a 20 TPS), mostrando lo que falta. No se aplica una férula a una zona sana.
La recompensa de First Aid la recibe quien trata, a través de la integración existente de First Aid con SurvivorCreator (3 XP por aplicación válida; las reglas originales omiten creativo/espectador). Examinar no da XP.
Las tijeras extraen una bala por aplicación; los objetos de curación normales mantienen sus curadores originales y su recuperación progresiva.
No permite dos tratamientos de este menú a la vez sobre el mismo paciente. Los tratamientos nativos activos también se comprueban antes de aplicar.

LINTERNAS
Conserva X, tecla configurable, luz desde inventario y luz en objetos tirados, con estado persistido por la variante encendida/apagada del objeto. El clic derecho no cambia el estado. Las reglas normales de desaparición de objetos tirados se mantienen.

VALIDACION
22 pruebas de distancia, interrupción y valores de paquete; 10 pruebas con el código real de heridas de First Aid; 20 pruebas de linterna/colocación segura conservadas. Bytecode y ZIP verificados. No se realizó una prueba dentro de Minecraft ni una sesión LAN real; esas pruebas siguen pendientes.

TECLAS 1.2
Al iniciar, si TCTCore comparte exactamente la tecla con Mostrar heridas o Rendirse de First Aid, mueve solamente TCTCore a F8, o a otra tecla de función libre si F8 está ocupada. Guarda el cambio en options.txt mediante Options.save. No cambia el menú médico, rendirse ni una asignación de TCTCore sin conflicto. Conserva todas las funciones anteriores. Los JAR enviados tienen H como predeterminada tanto en TCTCore como en Mostrar heridas, y G para Rendirse. Las teclas reales de options.txt pueden diferir.
Desatasco con disparo pendiente: los complementos enviados no contienen el motor de TaCZ; falta el JAR principal exacto para implementar ese cambio.
8 pruebas adicionales de selección de teclas. Falta prueba de arranque y controles dentro de Minecraft.

LOOT 1.3
Con Quietly v10, requiere 3 bloques o menos del centro del contenedor o posición del cadáver, también en contenedores ya registrados y al reabrir tras la búsqueda. Comprueba distancia en servidor al interactuar, iniciar, durante la búsqueda y antes de abrir. Muestra aviso de cercanía. Conserva la interrupción por movimiento del mod original. No altera contenido previamente generado.
Reduce 80% las probabilidades acumuladas de épico y legendario al elegir la calidad de una nueva búsqueda. Con scavenging 10 y suerte 0, épico o superior pasa de 9.8% a 1.96%; legendario pasa de 1.56% a 0.312%. Mantiene la influencia de habilidad y suerte; las tiradas degradadas quedan en las calidades inferiores. No modifica el loot base independiente de Zombie Remains ni su compatibilidad con NPC.
15 comprobaciones adicionales, incluyendo 900000 tiradas comparadas con Rules del Quietly enviado y distancia/reflexión usando su clase R real. No probado dentro de Minecraft/LAN.

HUD HOMEOSTATIC 1.4
Corrección opcional de cliente para Homeostatic 2.12.0.0. Conserva la fila original de gotas, sus valores, efectos y configuración. Antes de dibujar, vacía el lote gráfico previo, guarda el color/transparencia y el estado de mezcla, establece color blanco opaco y mezcla estándar; al terminar vacía las gotas pendientes y restaura color y mezcla anteriores. Así otro HUD no puede volver transparentes o tintadas las gotas por estado heredado. No añade hidratación ni modifica consumo o envía paquetes adicionales. First Aid ya usa los mismos datos reales de Homeostatic.
24 comprobaciones del aislamiento gráfico con simulación de lotes, varias transparencias y mezcla activada/desactivada. Compilación y bytecode verificados. La causa concreta reportada requiere confirmar esta corrección dentro de Minecraft, donde no se realizó una prueba.

MELEE Y LENGUA 1.5
Conservar los tres JAR enviados: melee 2.3.1 range-plus-one-ezweight-v11, mutants-l4d2-addon 1.3.0 y MutantsZombies 1.3.1. Reemplazar exclusivamente la integración anterior por esta en cliente y servidor.
La lengua se corta con una sola interacción válida sobre su segmento (o el personaje atrapado, como permitía el addon original). El ataque melee al infectado que mantiene una lengua activa libera al atrapado y permite que el daño del ataque continúe. Conserva las verificaciones originales de jugador válido, servidor, dimensión, visión y distancia máxima de 6 bloques; la interacción melee normal sigue pasando por sus controles propios de alcance. La liberación usa Tethers.release original, que elimina los segmentos y sus hitboxes. El cooldown de las habilidades no cambia: 200 ticks, 10 segundos a 20 TPS.
El renderByItem de NativeBatRenderer vuelve a dibujar el modelo original completo mediante ItemRenderer.renderStatic con el contexto, luz y overlay correctos, en vez de delegarlo a BEWLR, que no dibuja armas ordinarias. Usa el guard original para evitar que se seleccione nuevamente el proxy y lo libera incluso ante excepción. En primera persona aísla color/transparencia y mezcla, vaciando lotes BufferSource antes y después del render, para que estados de otros dibujos no vuelvan invisible el arma. Conserva animaciones, alcance y reglas de stamina.
10 comprobaciones de validación de lengua con Combat.valid real del addon, 5 de delegación del modelo con renderizador simulado y 24 de estado gráfico melee simulado. No equivalen a un lanzamiento de Minecraft ni a pruebas de shaders/LAN; sigue pendiente comprobar visualmente el resultado.

PAQUETES AUTOMATICOS 1.6
Función de cliente: poner los siete ZIP originales en la carpeta resourcepacks de la instancia, conservando sus nombres. No se incluyen, instalan ni descargan los recursos dentro del JAR. Reemplazar Integration 1.5 por 1.6. La integración conserva las funciones anteriores.
Reconoce los nombres enviados, nombres sin extensión para carpetas y sufijos de copia como (1). Selecciona una sola copia de cada paquete. Orden de menor a mayor prioridad: Zomboid_Poldos, TZP_1.20.1_2.7, FreshAnimations_v1.10.4, FA+All_Extensions-v1.8.1, MutantsZombies-Rotten-Gore-v8-emf-fix, MandalasGUI+Dakmode_1.21.8_v3.1, zomboid-ambience. Conserva los otros paquetes ya seleccionados, dejando estos encima. Minecraft conserva sus restricciones para paquetes obligatorios.
Al iniciar y salir de la selección de paquetes verifica disponibilidad y activa estos packs. Cada 10 segundos de ticks de cliente verifica cambios de nombre, tamaño y fecha de los ZIP; si hay cambios reescanea el repositorio y recarga los recursos. Revisa selección cada 2 segundos de ticks para reactivar los que se desmarquen. Espera a que se cierre el overlay de carga, no altera la selección mientras su pantalla está abierta y evita recargas repetidas sin cambios. Guarda options.txt mediante Options.updateResourcePacks. Ante error de API o recarga detiene reintentos esa sesión y lo informa en el log.
Usa la confirmación de incompatibilidad persistida por Options para paquetes seleccionados de formatos antiguos. Esto no convierte ni garantiza todos los recursos de otras versiones: TZP declara 1.20.1 y Mandalas 1.21.8 en su nombre. EMF/ETF u otros requisitos originales siguen siendo necesarios.
zomboid-ambience no pudo inspeccionarse por superar 32 MiB, pero su nombre se incluye en la activación cuando Minecraft lo detecte.
12 pruebas de planificación y 7 de ciclo de activación con cliente simulado: activación/guardado, estabilidad, reactivación, descubrimiento y refresco de contenido. Bytecode y ZIP verificados. No probado dentro de Minecraft.

CORRECCION DEL CRASH 1.6.1
El crash-2026-10-11_14.07.45-server.txt identifica InvalidInjectionException en LootReachMixin. Los parámetros Object usados para Search.Target y Search.Job no fueron aceptados por Mixin: la anotación Coerce se había compilado con retención RUNTIME en vez de CLASS. Se eliminaron esas conversiones y se usan los descriptores exactos de los tipos originales en start, open e inReach.
Las clases api-stubs/Search se usan solo al compilar las firmas de tipos internos de Quietly y están excluidas del JAR: Quietly sigue proporcionando sus clases reales. El test CheckLootDescriptors compara los cinco handlers del parche con el JAR Quietly del usuario y comprueba tipos, callback y static; rechaza la integración 1.6.0 y acepta esta versión. Preserva toda la integración 1.6.0, incluidos paquetes automáticos.
También pasaron nuevamente las pruebas de loot, selección de paquetes y ciclo de activación simulado. No se realizó un arranque real de Minecraft.

ORDEN Y TECLA 1.6.2
Reemplazar Integration 1.6.1 por esta en cliente y servidor sin duplicados. Conserva corrección de descriptores de Quietly y todas las funciones previas.
Orden visible de arriba hacia abajo de los paquetes administrados: 1 TZP, 2 zomboid-ambience, 3 Zomboid_Poldos, 4 MutantsZombies Rotten Gore. Los otros paquetes administrados van debajo (FA Extensions encima de Fresh Animations); el orden interno del repositorio de Minecraft es el inverso del visible. Esta instrucción reemplaza el orden documentado para 1.6.
La linterna detecta directamente la tecla configurada mediante GLFW, además de consumir la cola de KeyMapping; su valor predeterminado sigue siendo X y respeta reasignaciones a otras teclas o ratón. No depende de que otra asignación deje KeyMapping activada. Usa un detector de pulsación para enviar un solo paquete por presión: mantenerla, la repetición del teclado y cerrar un menú con la tecla pulsada no provocan alternancias repetidas. Solo funciona dentro del juego, sin pantalla abierta y con la ventana enfocada. Mantiene la selección desde inventario, estado encendido/apagado, límites del servidor y batería originales.
44 aserciones del detector, 13 de selección y orden visible, 7 de activación de paquetes simulada y comprobación exacta de los cinco descriptores del parche de loot. Compilación y bytecode verificados. No probado dentro de Minecraft; la causa exacta de que X no llegue no puede confirmarse sin probar en la instancia del usuario.
