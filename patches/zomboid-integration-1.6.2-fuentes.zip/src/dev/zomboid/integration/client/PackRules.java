package dev.zomboid.integration.client;
import java.util.*;
public final class PackRules {
 private static final String[] PREFIX={"freshanimations_v1.10.4","fa+all_extensions-v1.8.1","mandalasgui+dakmode_1.21.8_v3.1","mutantszombies-rotten-gore-v8-emf-fix","zomboid_poldos","zomboid-ambience","tzp_1.20.1_2.7"};
 public static int rank(String id){String s=id.toLowerCase(Locale.ROOT);if(!s.startsWith("file/"))return -1;s=s.substring(5).replaceFirst(" \\([0-9]+\\)(?=\\.zip$)","");if(s.endsWith(".zip"))s=s.substring(0,s.length()-4);for(int i=0;i<PREFIX.length;i++)if(s.equals(PREFIX[i]))return i;return -1;}
 public static List<String> plan(Collection<String> available,Collection<String> selected){Set<String> present=new HashSet<>(available);List<String> result=new ArrayList<>();for(String id:selected)if(present.contains(id)&&rank(id)<0&&!result.contains(id))result.add(id);for(int rank=0;rank<PREFIX.length;rank++){final int r=rank;available.stream().filter(id->rank(id)==r).sorted(Comparator.comparing((String id)->id.matches(".* \\([0-9]+\\)\\.zip$")).thenComparing(id->id)).findFirst().ifPresent(result::add);}return result;}
}
