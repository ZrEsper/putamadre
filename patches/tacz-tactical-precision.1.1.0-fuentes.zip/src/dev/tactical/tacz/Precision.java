package dev.tactical.tacz;
import java.util.*;import com.tacz.guns.entity.EntityKineticBullet;import net.minecraft.world.entity.Entity;import org.joml.Vector2d;
/** Final launch policy; weapon damage, velocity, camera recoil and special NPC accuracy remain native. */
public final class Precision {
 static final Map<Object,State> shooters=new WeakHashMap<>();static final Map<Object,Plan> plans=new WeakHashMap<>();
 static final class State {Object gun,level,holder;long last=-10000,moving=-10000;int burst;float previous;}
 record Plan(float spread,boolean pellets){}
 public static float cone(int shot,boolean aiming,boolean crouch,boolean moving,boolean grounded,float nativeSpread){
  if(!Float.isFinite(nativeSpread)||nativeSpread<0)nativeSpread=0;
  float bloom=shot<=1?0:shot==2?.045F:shot==3?.12F:Math.min(2.4F,.12F+(shot-3)*.18F);
  if(!grounded)return Math.max(nativeSpread,5F+bloom);
  if(moving)return Math.max(nativeSpread,2F+bloom);
  if(aiming)return crouch?bloom*.6F:shot==1?0F:.025F+bloom;
  return Math.max(nativeSpread,crouch?1.5F:2.5F)+bloom;
 }
 public static float next(State state,Object gun,Object level,Object holder,long tick,boolean aim,boolean crouch,boolean moving,boolean grounded,float original,int pellet){
  if(pellet>0&&state.gun==gun&&state.holder==holder&&state.level==level&&state.last==tick)return state.previous;
  if(state.gun!=gun||state.level!=level||state.holder!=holder||tick<state.last||tick-state.last>=9){state.burst=0;state.moving=tick-3;}
  if(moving||!grounded)state.moving=tick;
  state.burst=Math.min(32,state.burst+1);state.gun=gun;state.level=level;state.holder=holder;state.last=tick;
  state.previous=cone(state.burst,aim,crouch,moving||tick-state.moving<3,grounded,original);return state.previous;
 }
 public static void prepare(Object holder,Object gun,Object shooter,Object bullet,int pellet,float original){
  try{if(!Reflect.type("net.minecraft.world.entity.player.Player").isInstance(shooter))return;Object level=Reflect.call(shooter,"level");long tick=((Number)Reflect.call(level,"getGameTime")).longValue();Object velocity;try{velocity=Reflect.call(Reflect.type("com.tacz.guns.util.HitboxHelper"),"getPlayerVelocity",shooter);}catch(Exception absent){velocity=Reflect.call(shooter,"getDeltaMovement");}
   double x=((Number)Reflect.field(velocity,"x")).doubleValue(),z=((Number)Reflect.field(velocity,"z")).doubleValue();boolean moving=x*x+z*z>.0004||Boolean.TRUE.equals(Reflect.call(shooter,"isSprinting"));boolean crouch=Boolean.TRUE.equals(Reflect.call(shooter,"isCrouching"));boolean ground=Boolean.TRUE.equals(Reflect.call(shooter,"onGround"));float aim=((Number)Reflect.field(holder,"aimingProgress")).floatValue();
   Object gunIndex=Reflect.call(Reflect.type("com.tacz.guns.api.TimelessAPI"),"getCommonGunIndex",Reflect.call(bullet,"getGunId"));Object index=((Optional<?>)gunIndex).orElse(null);if(index==null)return;boolean pellets=false;if(index!=null){Object data=Reflect.call(index,"getBulletData");pellets=((Number)Reflect.call(data,"getBulletAmount")).intValue()>1;}
   State state=shooters.computeIfAbsent(shooter,k->new State());float spread=next(state,gun,level,holder,tick,aim>=.95F,crouch,moving,ground,original,pellet);plans.put(bullet,new Plan(spread,pellets));
  }catch(Exception e){Reflect.warn("final player precision",e);}
 }
 public static void launch(EntityKineticBullet bullet,Entity shooter,float pitch,float yaw,float roll,float speed,float original){Plan p=plans.remove(bullet);bullet.shootFromRotation(shooter,pitch,yaw,roll,speed,p==null||p.pellets()?original:p.spread());}
 public static Vector2d vector(Vector2d original,float degrees,Random rng){if(degrees<=0)return new Vector2d(0,0);double length=Math.hypot(original.x,original.y),radius=Math.tan(Math.toRadians(degrees))*8;double angle=length>1e-12?Math.atan2(original.y,original.x):rng.nextDouble()*Math.PI*2;double magnitude=radius*Math.sqrt(rng.nextDouble());return new Vector2d(Math.cos(angle)*magnitude,Math.sin(angle)*magnitude);}
 public static void launchVector(EntityKineticBullet bullet,Entity shooter,float pitch,float yaw,float roll,float speed,Vector2d original){Plan p=plans.remove(bullet);Vector2d adjusted=original;if(p!=null&&!p.pellets())adjusted=vector(original,p.spread(),new Random());bullet.shootFromRotation(shooter,pitch,yaw,roll,speed,adjusted);}
 public static float volume(float original,Object sound){String id=String.valueOf(sound).toLowerCase(Locale.ROOT);boolean shot=(id.contains("shoot")||id.contains("gunshot")||id.contains("silence")||id.contains("suppres")||id.contains("gun_fire")||id.contains("/fire")||id.contains("_fire"))&&!id.contains("dry")&&!id.contains("reload");return shot&&Float.isFinite(original)?Math.max(0,original)*1.5F:original;}
}
