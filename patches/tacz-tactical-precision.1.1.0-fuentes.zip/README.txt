TaCZ Tactical 1.1.0 — Precisión al agacharse y ráfagas

Reemplaza tacz-tactical-1.0.0-neoforge-1.21.1.jar por este JAR en cliente y servidor. Conserva tacz-neoforge-1.21.1-1.1.8-hotfix-r7-third-person-pz.7.jar, TaCZ Addon y GunDB. La modificación se aplica al complemento Tactical; no necesita reemplazar el TaCZ principal de 57 MB y conserva sus animaciones. No pongas dos versiones de Tactical en mods.

Se corrige la dispersión al lanzar realmente el proyectil, tanto en la ruta normal como en la controlada por scripts de TaCZ. Después de terminar de apuntar, estando quieto en el suelo, el primer disparo tiene dispersión cero. Agachado, el segundo y tercero tienen conos muy cerrados (aproximadamente 0.027 y 0.072 grados); desde el cuarto se abre gradualmente. De pie, la ráfaga se abre más. Caminar/correr y estar en el aire penalizan la precisión. Al dejar de disparar durante nueve ticks (450 ms a 20 TPS), la precisión se recupera.

Se cuenta cada disparo, no cada perdigón. Las escopetas conservan su cono de perdigones. Los NPC conservan su precisión original y los ajustes de otros mods. Se mantiene el retroceso de cámara, velocidad, caída gravitatoria, daño, munición, atascos y recargas originales. Por tanto, a larga distancia todavía debes compensar la caída de la bala y el retroceso visual de la mira.

El volumen de los sonidos de disparo, incluidos los silenciados, aumenta un 50 %. No se amplifican las recargas ni los clics de disparo en seco. Se comprobó que los 138 identificadores de disparo y silenciador incluidos en tu TaCZ corresponden al filtro. Packs externos que usen nombres de sonido distintos pueden necesitar ampliar el filtro.

Si instalas también Hordes 14 y Zombie Awareness reactive-hearing.2, los disparos atraerán a zombies a mayor distancia, con casi todos buenos oyentes y origen impreciso para disparos silenciados. El nuevo módulo de ruido consulta la bandera real del silenciador en la caché de accesorios de TaCZ.

Verificación: 20 025 comprobaciones simuladas de precisión, ráfagas, recuperación, vectores finales, escopetas, NPC y audio. Se utilizó el auxiliar de reflexión real del Tactical enviado. Se verificaron 16 contratos de los nuevos Mixins contra el bytecode de tu TaCZ exacto, CRC del JAR y tipos de bytecode. No se ejecutó Minecraft ni se verificó la aplicación de Mixins dentro del juego.

Recompilar: Java 21, python3 build.py RUTA_AL_TACTICAL_ORIGINAL.jar. Los stubs son exclusivos de compilación/pruebas y no se incluyen en el mod. MixinContracts.java permite comparar las nuevas inyecciones contra el TaCZ principal.
