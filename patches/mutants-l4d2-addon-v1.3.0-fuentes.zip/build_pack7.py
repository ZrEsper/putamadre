from pathlib import Path
import zipfile,json,hashlib
source=Path('work/MutantsZombies-Rotten-Gore-v6.zip');out=Path('work/MutantsZombies-Rotten-Gore-v7.zip')
count=0
with zipfile.ZipFile(source) as zin,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for info in zin.infolist():
  if info.is_dir() or info.filename=='LEEME.txt':continue
  data=zin.read(info)
  if info.filename.endswith('.jem'):
   d=json.loads(data)
   for model in d['models']:
    for a in model.get('animations',[]):
     for key,factor in [('var.wind',1.6),('var.thrust',1.8)]:
      if key in a:a[key]='('+a[key]+') * '+str(factor)
     if 'var.run' in a:a['var.run']=a['var.run'].replace('frame_time * 4','frame_time * 8')
   data=json.dumps(d,ensure_ascii=False,indent=2).encode();count+=1
  if info.filename=='pack.mcmeta':
   d=json.loads(data);d['pack']['description']='MutantsZombies Rotten Gore v7 — caminata, carrera y ataques explosivos';data=json.dumps(d,ensure_ascii=False,indent=2).encode()
  z.writestr(info.filename,data)
 z.writestr('LEEME.txt','Rotten Gore v7. Reemplaza v5/v6 y ponlo por encima de otros packs de mutantes. Conserva sus texturas, geometría, variantes, ojos emisivos y gore. Caminata contenida, transición a carrera más rápida y ataques con preparación y golpe brusco. Se aumentan exclusivamente las variables de ataque, conservando la reducción de convulsiones en reposo de v6. Requiere EMF/ETF como v5 y modelos de mods activados. F3+T para recargar. Compatible con el complemento 1.3.0; EMF puede reemplazar parte de las poses nativas, por lo que se necesita comprobar en partida las habilidades con este pack. No probado dentro de Minecraft.')
print('Updated',count,'models;',out.stat().st_size,'bytes');print(hashlib.sha256(out.read_bytes()).hexdigest())
