import zipfile,json,re,ast,math
from collections import defaultdict
original='attachments/bd684d1b-dd8a-4001-9518-52e98443cd9b/MutantsZombies-Rotten-Gore-v5.zip'
pack='work/MutantsZombies-Rotten-Gore-v7.zip'
functions={'sin':math.sin,'cos':math.cos,'pow':pow,'min':min,'max':max,'abs':abs,'torad':math.radians,'clamp':lambda x,a,b:max(a,min(b,x)),'choose':lambda test,a,b:a if test else b,'random':lambda seed:(math.sin(seed*12.9898+78.233)*43758.5453)%1}
allowed=(ast.Expression,ast.BinOp,ast.UnaryOp,ast.BoolOp,ast.Compare,ast.Call,ast.Name,ast.Load,ast.Constant,ast.Add,ast.Sub,ast.Mult,ast.Div,ast.Pow,ast.Mod,ast.USub,ast.UAdd,ast.Not,ast.And,ast.Or,ast.Lt,ast.LtE,ast.Gt,ast.GtE,ast.Eq,ast.NotEq)
checks=0
with zipfile.ZipFile(original) as old,zipfile.ZipFile(pack) as new:
 assert new.testzip() is None
 for name in new.namelist():
  if name.endswith(('.png','.properties')):assert new.read(name)==old.read(name),name;checks+=1
  if not name.endswith('.jem'):continue
  before=json.loads(old.read(name));after=json.loads(new.read(name));assert {k:v for k,v in before.items() if k!='models'}=={k:v for k,v in after.items() if k!='models'}
  for bm,am in zip(before['models'],after['models']):
   assert {k:v for k,v in bm.items() if k!='animations'}=={k:v for k,v in am.items() if k!='animations'}
   for anim in am.get('animations',[]):
    programs=[]
    for key,value in anim.items():
     expr=re.sub(r'\bif\(', 'choose(',value).replace('&&',' and ').replace('||',' or ')
     expr=re.sub(r'\b([A-Za-z_]\w*\.\w+)\b',lambda m:'read('+repr(m.group(1))+')',expr)
     tree=ast.parse(expr,mode='eval')
     for node in ast.walk(tree):
      assert isinstance(node,allowed),(name,key,type(node).__name__)
      if isinstance(node,ast.Call):assert isinstance(node.func,ast.Name) and node.func.id in set(functions)|{'read'}
     programs.append((key,compile(tree,'<cem>','eval')))
    for hp,speed,hurt,dead in [(1,0,False,False),(1,.9,False,False),(.4,.7,True,False),(.05,.4,True,False),(0,0,False,True)]:
     state=defaultdict(float)
     for frame in range(120):
      scope=dict(functions,read=lambda key:state[key],age=frame,frame_time=1/60,limb_speed=speed,limb_swing=frame*.2,id=42,health=hp*100,max_health=100,is_alive=not dead,is_hurt=hurt,death_time=min(frame,20) if dead else 0,head_yaw=.3,head_pitch=.1,swing_progress=(frame%20)/20)
      for key,program in programs:
       value=eval(program,{'__builtins__':{}},scope);assert isinstance(value,(int,float)) and math.isfinite(value) and abs(value)<10000,(name,key,frame,value);state[key]=value;checks+=1
 print('Pack expression / preservation checks passed:',checks)
