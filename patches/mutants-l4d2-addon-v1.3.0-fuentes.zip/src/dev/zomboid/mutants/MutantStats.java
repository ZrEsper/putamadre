package dev.zomboid.mutants;
import net.minecraft.world.entity.*;import net.minecraft.world.entity.ai.attributes.Attributes;import net.petemc.mutantszombies.entity.*;
public final class MutantStats {
 public static void apply(Mob m){var tag=m.getPersistentData();if(m instanceof MutantBruteEntity||m instanceof ZombieBruteEntity||m instanceof RottenMutantEntity){if(!tag.getBoolean("l4d_speed_13")){var a=m.getAttribute(Attributes.MOVEMENT_SPEED);if(a!=null){a.setBaseValue(a.getBaseValue()*1.25);tag.putBoolean("l4d_speed_13",true);}}}
  if(m instanceof SplitHeadZombieEntity&&!tag.getBoolean("l4d_health_13")){var a=m.getAttribute(Attributes.MAX_HEALTH);if(a!=null){float old=m.getMaxHealth(),fraction=old>0?m.getHealth()/old:1;a.setBaseValue(Math.max(96,a.getBaseValue()*2));m.setHealth(m.getMaxHealth()*fraction);tag.putBoolean("l4d_health_13",true);}}
 }
}
