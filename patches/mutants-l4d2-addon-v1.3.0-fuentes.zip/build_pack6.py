from pathlib import Path
import zipfile,json,hashlib
source=Path('attachments/bd684d1b-dd8a-4001-9518-52e98443cd9b/MutantsZombies-Rotten-Gore-v5.zip')
out=Path('work/MutantsZombies-Rotten-Gore-v6.zip')
counts=0
with zipfile.ZipFile(source) as zin,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for info in zin.infolist():
  if info.is_dir() or info.filename.startswith('src/') or info.filename=='LEEME.txt':continue
  data=zin.read(info)
  if info.filename.endswith('.jem'):
   d=json.loads(data)
   for model in d['models']:
    for a in model.get('animations',[]):
     for key,factor in {'var.fit':.18,'var.hsnap':.22,'var.twitch':.3,'var.twitch2':.25,'var.shud':.4,'var.stumble':.2,'var.surge':.45,'var.wind':.65,'var.thrust':.65,'var.cock':.35}.items():
      if key in a:a[key]='('+a[key]+') * '+str(factor)
     for key in ['var.bob','var.sway']:
      if key in a:a[key]='('+a[key]+') * 0.6'
   data=json.dumps(d,ensure_ascii=False,indent=2).encode();counts+=1
  if info.filename=='pack.mcmeta':
   d=json.loads(data);d['pack']['description']='MutantsZombies Rotten Gore v6 — movimiento de infectado contenido';data=json.dumps(d,ensure_ascii=False,indent=2).encode()
  z.writestr(info.filename,data)
 z.writestr('LEEME.txt','Rotten Gore v6. Reemplaza el pack v5 y colócalo por encima de otros packs de mutantes. Mantiene las mismas texturas, variantes, ojos emisivos, heridas y desmembramiento. Reduce cabezazos, convulsiones, balanceo, tropiezos y extensión exagerada al atacar para un movimiento más pesado y contenido. Requiere EMF/ETF como v5, modelos de mods activados. Recarga con F3+T. El complemento 1.2.0 aporta la IA y poses nativas; EMF puede reemplazar parte de las poses nativas con las animaciones de este pack. No se ha probado dentro de Minecraft.')
print('Pack actualizado:',counts,'modelos;',out.stat().st_size,'bytes')
print('SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
