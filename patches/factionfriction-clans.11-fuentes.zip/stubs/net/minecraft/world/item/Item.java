package net.minecraft.world.item;
public class Item implements net.minecraft.world.level.ItemLike {}