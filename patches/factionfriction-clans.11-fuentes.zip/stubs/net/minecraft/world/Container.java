package net.minecraft.world;
public interface Container {boolean stillValid(net.minecraft.world.entity.player.Player p);}