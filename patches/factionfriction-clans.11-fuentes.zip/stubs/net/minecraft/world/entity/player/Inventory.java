package net.minecraft.world.entity.player;
public class Inventory {public final Player player=null;}