package net.minecraft.world.inventory;
public class MenuType<T> {public static final MenuType<ChestMenu> GENERIC_9x6=new MenuType<>();}