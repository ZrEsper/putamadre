package net.minecraft.core;
public class NonNullList<E> extends java.util.ArrayList<E> {}