package net.minecraft.core.component;
public class DataComponents {public static final DataComponentType<net.minecraft.network.chat.Component> CUSTOM_NAME=new DataComponentType<>();}