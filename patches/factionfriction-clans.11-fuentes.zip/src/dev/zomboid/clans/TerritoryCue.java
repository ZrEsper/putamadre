package dev.zomboid.clans;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
/** Direct sound holder is serialized by the vanilla sound packet. No extra custom networking. */
public final class TerritoryCue {
 private static final SoundEvent ENTER=SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("factionfriction","territory_enter"));
 public static void enter(ServerPlayer player, boolean factionChanged) {
  if(factionChanged) player.playNotifySound(ENTER,SoundSource.AMBIENT,0.8F,1.0F);
 }
}
