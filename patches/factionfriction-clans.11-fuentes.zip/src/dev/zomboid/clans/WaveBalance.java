package dev.zomboid.clans;
import java.util.*;
public final class WaveBalance {
 public static int count(int rarity){return new int[]{12,20,48,60,80}[Math.max(0,Math.min(4,rarity))];}
 public static int special(int rarity){return new int[]{0,3,3,5,6}[Math.max(0,Math.min(4,rarity))];}
 public static void tripleDelta(Map<String,Integer> bank,Map<String,Integer> before){for(var e:new ArrayList<>(bank.entrySet())){long old=Math.max(0,before.getOrDefault(e.getKey(),0)),delta=(long)e.getValue()-old;if(delta>0)bank.put(e.getKey(),(int)Math.min(Integer.MAX_VALUE,old+delta*3));}}
 private static void add(Map<String,Integer> bank,String key,int amount){bank.put(key,(int)Math.min(Integer.MAX_VALUE,(long)Math.max(0,bank.getOrDefault(key,0))+amount));}
 public static void supplies(Map<String,Integer> bank,int rarity,boolean medical){int n=Math.max(0,Math.min(4,rarity))+1;String[] ids={"gunpowder","iron_ingot","copper_ingot","gold_ingot","redstone","glass","quartz","amethyst_shard","cooked_beef"};int[] base={24,16,8,4,8,8,4,2,8};for(int i=0;i<ids.length;i++)add(bank,"minecraft:"+ids[i],base[i]*n*3);if(rarity>=2)add(bank,"minecraft:blaze_rod",3*(rarity-1));if(medical){add(bank,"firstaid:bandage",18*n);add(bank,"firstaid:plaster",18*n);add(bank,"firstaid:splint",6*n);}}
 public static void complete(Object actor,Object manager,Pve.Wave wave,boolean success){if(!success||Pve.waves.get(wave.clan)!=wave){Pve.legacyEnd(actor,manager,wave,success);return;}Object faction=Clans.faction(manager,wave.clan);if(faction==null){Pve.legacyEnd(actor,manager,wave,success);return;}ClanState.Profile p=Clans.state(manager).profile(wave.clan);Map<String,Integer> before=new HashMap<>(p.rewards);int wins=p.pveWins;Pve.legacyEnd(actor,manager,wave,success);if(p.pveWins<=wins)return;tripleDelta(p.rewards,before);supplies(p.rewards,wave.rarity,Rewards.installed("firstaid"));Clans.dirty(manager);}
}
