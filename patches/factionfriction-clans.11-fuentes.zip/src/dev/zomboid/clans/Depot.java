package dev.zomboid.clans;
import java.util.*;import net.minecraft.server.level.ServerPlayer;import net.minecraft.world.*;import net.minecraft.world.entity.player.*;import net.minecraft.world.inventory.*;import net.minecraft.world.item.*;import net.minecraft.core.component.DataComponents;import net.minecraft.network.chat.Component;
public final class Depot {
 static final Map<ClanState.Profile,UUID> leases=new WeakHashMap<>();
 static boolean allowed(Object manager,Object faction,Player player){Object current=Clans.mine(manager,player);return current!=null&&Objects.equals(Clans.fid(current),Clans.fid(faction))&&Clans.authority(faction,player);}
 public static void open(Object actor,Object manager,Object faction){if(!(actor instanceof ServerPlayer player)||!player.isAlive()||player.isSpectator()||!allowed(manager,faction,player))return;ClanState.Profile profile=Clans.state(manager).profile(Clans.fid(faction));UUID owner=leases.get(profile);if(owner!=null&&!owner.equals(player.getUUID())){Clans.say(player,"Otro compañero está utilizando el depósito. Espera a que lo cierre.");return;}player.closeContainer();Box box=new Box(profile,manager,faction,player);leases.put(profile,player.getUUID());try{if(player.openMenu(new SimpleMenuProvider((id,inventory,p)->new Menu(id,inventory,box),Component.literal("Depósito del clan"))).isEmpty())box.release();}catch(RuntimeException failure){box.release();throw failure;}}
 static final class Box extends SimpleContainer {
  final ClanState.Profile profile;final Object manager,faction;final ServerPlayer owner;final String[] keys=new String[45];final int[] last=new int[45];boolean loading,closed;int page;
  Box(ClanState.Profile p,Object manager,Object faction,ServerPlayer owner){super(54);this.profile=p;this.manager=manager;this.faction=faction;this.owner=owner;page(0);}
  public boolean stillValid(Player player){return !closed&&Objects.equals(leases.get(profile),player.getUUID())&&allowed(manager,faction,player);}
  public void setChanged(){super.setChanged();if(keys!=null&&!loading&&!closed)reconcile();}
  void reconcile(){for(int i=0;i<45;i++){if(keys[i]==null)continue;int count=getItem(i).getCount();int taken=Math.max(0,last[i]-count);if(taken>0){int left=Math.max(0,profile.rewards.getOrDefault(keys[i],0)-taken);if(left==0)profile.rewards.remove(keys[i]);else profile.rewards.put(keys[i],left);Clans.dirty(manager);}last[i]=count;}}
  int pages(){return Math.max(1,(profile.rewards.size()+44)/45);}
  void page(int requested){reconcile();page=Math.max(0,Math.min(pages()-1,requested));List<String> sorted=profile.rewards.entrySet().stream().filter(e->e.getValue()>0).map(Map.Entry::getKey).sorted().toList();Arrays.fill(keys,null);for(int i=0;i<45;i++)if(page*45+i<sorted.size())keys[i]=sorted.get(page*45+i);refill();}
  ItemStack named(Item item,String name){ItemStack s=new ItemStack(item,1);s.set(DataComponents.CUSTOM_NAME,Component.literal(name));return s;}
  void refill(){loading=true;try{for(int i=0;i<45;i++){ItemStack s=ItemStack.EMPTY;if(keys[i]!=null){int total=profile.rewards.getOrDefault(keys[i],0);if(total>0){Object sample=Rewards.stack(keys[i],1);if(sample instanceof ItemStack stack&&!stack.isEmpty())s=(ItemStack)Rewards.stack(keys[i],Math.min(total,Math.min(64,stack.getMaxStackSize())));}}setItem(i,s);last[i]=s.getCount();}for(int i=45;i<54;i++)setItem(i,ItemStack.EMPTY);setItem(45,named(Items.ARROW,"Página anterior"));setItem(49,named(Items.PAPER,"Página "+(page+1)+"/"+pages()+" · clic o Shift para retirar"));setItem(53,named(Items.ARROW,"Página siguiente"));}finally{loading=false;}}
  void release(){if(closed)return;reconcile();closed=true;leases.remove(profile,owner.getUUID());Clans.dirty(manager);Clans.snapshot(owner,manager);}
 }
 static final class TakeSlot extends Slot {final boolean material;TakeSlot(Container c,int i,int x,int y){super(c,i,x,y);material=i<45;}public boolean mayPlace(ItemStack stack){return false;}public boolean mayPickup(Player player){return material&&container.stillValid(player);}}
 static final class Menu extends ChestMenu {final Box box;Menu(int id,Inventory inventory,Box box){super(MenuType.GENERIC_9x6,id,inventory,box,6);this.box=box;for(int i=0;i<54;i++){TakeSlot slot=new TakeSlot(box,i,8+(i%9)*18,18+(i/9)*18);slot.index=i;slots.set(i,slot);}}
  public void broadcastChanges(){if(!box.closed){box.reconcile();box.refill();}super.broadcastChanges();}
  public ItemStack quickMoveStack(Player player,int index){if(index<0||index>=45||!stillValid(player))return ItemStack.EMPTY;return super.quickMoveStack(player,index);}
  public void clicked(int slot,int button,ClickType type,Player player){if(!stillValid(player))return;if(slot>=45&&slot<54){if(slot==45)box.page(box.page-1);if(slot==53)box.page(box.page+1);broadcastFullState();return;}super.clicked(slot,button,type,player);}
  public boolean stillValid(Player player){return box.stillValid(player);}
  public void removed(Player player){super.removed(player);box.release();}
 }
}
