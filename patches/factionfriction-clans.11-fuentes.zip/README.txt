Faction Friction — Clans 11

Reemplaza Clans 10 por este JAR tanto en servidor como en clientes. Conserva las demás dependencias y configuraciones.

Las recompensas de objetos de cada oleada completada se multiplican por tres. Las reservas ya acumuladas y la experiencia conservan sus cantidades. Se agregan pólvora, hierro, cobre, oro, redstone, cristal, cuarzo, amatista, comida y varas de blaze desde dificultad Difícil. Con First Aid instalado se añaden vendas, yesos y férulas.

Por fase: Fácil 12 normales/0 especiales; Normal 17/3; Difícil 45/3; Extrema 55/5; Pesadilla 74/6. Se conserva el calendario de aparición original.

En la pestaña de depósito, «Abrir depósito como cofre (jefatura)» abre un cofre de seis filas. Retira objetos con clic o Shift, en cantidades parciales. La fila inferior cambia de página. Las pilas de reservas grandes se reponen en la vista al retirar objetos. El depósito es de retirada; no acepta depósitos manuales. Se conserva el permiso de jefatura y se admite un usuario por depósito simultáneamente para evitar duplicaciones.

Un sonido original y breve avisa al entrar en tierras de otra facción o regresar desde territorio libre. No se repite al cruzar chunks de la misma facción ni al cambiar de parcela. Se envía solo al jugador que entra y usa el volumen Ambiente. El sonido se incluye dentro del JAR; todos los clientes necesitan esta actualización.

Verificación: 43 comprobaciones simuladas de recompensas, reservas, páginas y sonido, comprobación de CRC y análisis de tipos del bytecode. No probado dentro de Minecraft; los SDK simulados son exclusivos de compilación/pruebas y no se incluyen en el JAR.
