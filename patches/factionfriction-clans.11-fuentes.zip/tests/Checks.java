package dev.zomboid.clans;
import java.util.*;import net.minecraft.server.level.ServerPlayer;import net.minecraft.world.item.ItemStack;
public class Checks {
 static int checks;static void check(boolean v){checks++;if(!v)throw new AssertionError("Check "+checks);}
 public static void main(String[] a){
 int[] counts={12,20,48,60,80},specials={0,3,3,5,6};for(int q=0;q<5;q++){check(WaveBalance.count(q)==counts[q]);check(WaveBalance.special(q)==specials[q]);var b=new HashMap<String,Integer>();WaveBalance.supplies(b,q,true);check(b.get("minecraft:gunpowder")==72*(q+1));check(b.get("firstaid:bandage")==18*(q+1));}
 var b=new HashMap<String,Integer>();b.put("old",107);b.put("new",9);WaveBalance.tripleDelta(b,Map.of("old",100));check(b.get("old")==121);check(b.get("new")==27);
 var id=UUID.randomUUID();var p=Clans.state(id).profile(id);p.rewards.put("minecraft:iron_ingot",100);Pve.Wave w=new Pve.Wave();w.clan=id;w.rarity=2;Pve.waves.put(id,w);WaveBalance.complete(null,id,w,true);check(p.rewards.get("minecraft:iron_ingot")==265);var before=new HashMap<>(p.rewards);WaveBalance.complete(null,id,w,true);check(p.rewards.equals(before));Pve.waves.put(id,w);WaveBalance.complete(null,id,w,false);check(p.rewards.equals(before));
 p.rewards.clear();p.rewards.put("minecraft:iron_ingot",150);var player=new ServerPlayer();Depot.leases.put(p,player.getUUID());var box=new Depot.Box(p,id,id,player);check(p.rewards.get("minecraft:iron_ingot")==150);check(box.getItem(0).getCount()==64);box.setItem(0,new ItemStack(null,32));check(p.rewards.get("minecraft:iron_ingot")==118);box.refill();check(box.getItem(0).getCount()==64);box.reconcile();check(p.rewards.get("minecraft:iron_ingot")==118);check(box.stillValid(player));check(!box.stillValid(new ServerPlayer()));check(!new Depot.TakeSlot(box,0,0,0).mayPlace(ItemStack.EMPTY));check(!new Depot.TakeSlot(box,45,0,0).mayPickup(player));box.release();check(p.rewards.get("minecraft:iron_ingot")==118);check(!Depot.leases.containsKey(p));
 p.rewards.clear();for(int i=0;i<100;i++)p.rewards.put("item:"+i,10);var paged=new Depot.Box(p,id,id,player);check(paged.pages()==3);paged.page(999);check(paged.page==2);paged.page(-1);check(paged.page==0);check(p.rewards.size()==100);
 TerritoryCue.enter(player,false);check(player.cueCount==0);TerritoryCue.enter(player,true);check(player.cueCount==1);TerritoryCue.enter(player,false);check(player.cueCount==1);
 System.out.println("Passed "+checks+" simulated ledger, reward, paging and sound checks");
 }
}