import java.nio.file.*;import java.util.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public class PatchSurvival {
 static final String BR="dev/zomboid/survival/PreservationBridge";
 static InsnList call(String name,String desc,int...loads){InsnList l=new InsnList();for(int i=0;i<loads.length;i+=2)l.add(new VarInsnNode(loads[i],loads[i+1]));l.add(new MethodInsnNode(Opcodes.INVOKESTATIC,BR,name,desc,false));return l;}
 static void body(MethodNode m,InsnList instructions,int ret){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(instructions);m.instructions.add(new InsnNode(ret));}
 static MethodNode clone(MethodNode m,String name){MethodNode c=new MethodNode(m.access,name,m.desc,m.signature,m.exceptions.toArray(String[]::new));m.accept(c);c.name=name;return c;}
 static void gate(MethodNode m,InsnList prefix,int ret){LabelNode normal=new LabelNode();m.instructions.insert(prefix);InsnList tail=new InsnList();tail.add(new JumpInsnNode(Opcodes.IFEQ,normal));tail.add(new InsnNode(ret));tail.add(normal);tail.add(new FrameNode(Opcodes.F_SAME,0,null,0,null));m.instructions.insert(prefix.getLast(),tail);}
 static byte[] patch(String path,byte[] b){ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);List<MethodNode> extra=new ArrayList<>();
 for(MethodNode m:c.methods){
  if(path.equals("dev/zomboid/survival/FoodClock.class")){
   if(Set.of("update","inventory","frozen","cold","remaining","inherit").contains(m.name))extra.add(clone(m,"legacy"+Character.toUpperCase(m.name.charAt(0))+m.name.substring(1)));
   switch(m.name){
    case "update"->body(m,call("update",m.desc,Opcodes.ALOAD,0,Opcodes.LLOAD,1,Opcodes.ILOAD,3,Opcodes.ILOAD,4),Opcodes.ARETURN);
    case "inventory"->body(m,call("inventory","(Ljava/lang/Object;JIZ)V",Opcodes.ALOAD,0,Opcodes.LLOAD,1,Opcodes.ILOAD,3,Opcodes.ILOAD,4),Opcodes.RETURN);
    case "frozen","cold","perishable"->body(m,call(m.name,m.desc,Opcodes.ALOAD,0),Opcodes.IRETURN);
    case "remaining"->body(m,call(m.name,m.desc,Opcodes.ALOAD,0),Opcodes.DRETURN);
    case "inherit"->body(m,call(m.name,m.desc,Opcodes.ALOAD,0,Opcodes.ALOAD,1,Opcodes.LLOAD,2),Opcodes.RETURN);
   }
  }
  if(path.equals("dev/zomboid/survival/FoodStacking.class")&&m.name.equals("mergeable"))body(m,call("merge",m.desc,Opcodes.ALOAD,0,Opcodes.ALOAD,1),Opcodes.IRETURN);
  if(path.equals("dev/zomboid/survival/Client.class")&&m.name.equals("tooltip")){
   InsnList prefix=new InsnList();prefix.add(new VarInsnNode(Opcodes.ALOAD,0));prefix.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,"net/neoforged/neoforge/event/entity/player/ItemTooltipEvent","getItemStack","()Lnet/minecraft/world/item/ItemStack;",false));prefix.add(new MethodInsnNode(Opcodes.INVOKESTATIC,BR,"food","(Lnet/minecraft/world/item/ItemStack;)Z",false));LabelNode normal=new LabelNode();prefix.add(new JumpInsnNode(Opcodes.IFEQ,normal));prefix.add(new InsnNode(Opcodes.RETURN));prefix.add(normal);prefix.add(new FrameNode(Opcodes.F_SAME,0,null,0,null));m.instructions.insert(prefix);
  }
  if((path.equals("dev/zomboid/survival/mixin/FurnaceMixin.class")||path.equals("dev/zomboid/survival/mixin/StoveMixin.class"))&&m.name.equals("thaw")){
   m.instructions.insert(call("enter","(Ljava/lang/Object;Ljava/lang/Object;)V",Opcodes.ALOAD,0,Opcodes.ALOAD,3));
   for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==Opcodes.RETURN)m.instructions.insertBefore(n,new MethodInsnNode(Opcodes.INVOKESTATIC,BR,"exit","()V",false));
  }
  if(path.equals("com/fyxe/fffoodspoilageandpreservation/util/SpoilageHelper.class")){
   if(m.name.equals("identifyOpenContainer"))for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==Opcodes.ARETURN){InsnList l=new InsnList();l.add(new VarInsnNode(Opcodes.ALOAD,0));l.add(new MethodInsnNode(Opcodes.INVOKESTATIC,BR,"open","(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",false));l.add(new TypeInsnNode(Opcodes.CHECKCAST,"com/fyxe/fffoodspoilageandpreservation/util/SpoilageHelper$OpenContainer"));m.instructions.insertBefore(n,l);}
   if(m.name.equals("resolveContainerAmbientMultiplier")){
    InsnList l=call("ambient","(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Double;",Opcodes.ALOAD,0,Opcodes.ALOAD,1);LabelNode normal=new LabelNode();l.add(new InsnNode(Opcodes.DUP));l.add(new JumpInsnNode(Opcodes.IFNULL,normal));l.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,"java/lang/Double","doubleValue","()D",false));l.add(new InsnNode(Opcodes.DRETURN));l.add(normal);l.add(new FrameNode(Opcodes.F_SAME1,0,null,1,new Object[]{"java/lang/Double"}));l.add(new InsnNode(Opcodes.POP));m.instructions.insert(l);
   }
   if(m.name.equals("tickTemperatureContainer")){
    InsnList l=call("containerTemperature","(Lnet/minecraft/world/item/ItemStack;Ljava/lang/Object;Ljava/lang/Object;)Z",Opcodes.ALOAD,0,Opcodes.ALOAD,1,Opcodes.ALOAD,2);LabelNode normal=new LabelNode();l.add(new JumpInsnNode(Opcodes.IFEQ,normal));l.add(new InsnNode(Opcodes.RETURN));l.add(normal);l.add(new FrameNode(Opcodes.F_SAME,0,null,0,null));m.instructions.insert(l);
   }
  }
  if(path.equals("com/fyxe/fffoodspoilageandpreservation/compat/ColdSweatCompat.class")&&m.name.equals("identifyThermalDevice")){
   InsnList l=call("device","(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",Opcodes.ALOAD,0,Opcodes.ALOAD,1);LabelNode normal=new LabelNode();l.add(new InsnNode(Opcodes.DUP));l.add(new JumpInsnNode(Opcodes.IFNULL,normal));l.add(new TypeInsnNode(Opcodes.CHECKCAST,"com/fyxe/fffoodspoilageandpreservation/compat/ColdSweatCompat$ThermalDevice"));l.add(new InsnNode(Opcodes.ARETURN));l.add(normal);l.add(new FrameNode(Opcodes.F_SAME1,0,null,1,new Object[]{"java/lang/Object"}));l.add(new InsnNode(Opcodes.POP));m.instructions.insert(l);
  }
 }
 c.methods.addAll(extra);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);return w.toByteArray();
 }
 public static void main(String[]args)throws Exception{
  Set<String> patched=Set.of("dev/zomboid/survival/FoodClock.class","dev/zomboid/survival/FoodStacking.class","dev/zomboid/survival/Client.class","dev/zomboid/survival/mixin/FurnaceMixin.class","dev/zomboid/survival/mixin/StoveMixin.class","com/fyxe/fffoodspoilageandpreservation/util/SpoilageHelper.class","com/fyxe/fffoodspoilageandpreservation/compat/ColdSweatCompat.class");
  Map<String,byte[]> entries=new LinkedHashMap<>();for(int i=0;i<2;i++)try(ZipFile z=new ZipFile(args[i])){var all=z.entries();while(all.hasMoreElements()){ZipEntry e=all.nextElement();if(e.isDirectory()||e.getName().equals("META-INF/neoforge.mods.toml")||e.getName().equals("META-INF/MANIFEST.MF"))continue;byte[] bytes=z.getInputStream(e).readAllBytes();if(patched.contains(e.getName()))bytes=patch(e.getName(),bytes);if(entries.putIfAbsent(e.getName(),bytes)!=null)throw new IllegalStateException("Duplicate resource "+e.getName());}}
  Path helper=Path.of(args[2]);try(var files=Files.walk(helper)){for(Path p:files.filter(f->f.toString().endsWith(".class")).toList())entries.put(helper.relativize(p).toString().replace('\\','/'),Files.readAllBytes(p));}
  entries.put("META-INF/neoforge.mods.toml",Files.readAllBytes(Path.of(args[3])));entries.put("zomboid_survival.mixins.json",Files.readAllBytes(Path.of(args[4])));entries.put("MERGED-PRESERVATION-NOTES.txt",Files.readAllBytes(Path.of(args[5])));
  entries.put("META-INF/MANIFEST.MF","Manifest-Version: 1.0\r\nFMLModType: MOD\r\nImplementation-Version: 1.1.0\r\n\r\n".getBytes(java.nio.charset.StandardCharsets.UTF_8));
  try(ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(args[6])))){for(var e:entries.entrySet()){out.putNextEntry(new ZipEntry(e.getKey()));out.write(e.getValue());out.closeEntry();}}
  System.out.println("Merged all classes/resources, retained FF namespace/registries and bundled FFUtilities; patched "+patched.size()+" bridge classes");
 }
}
