package dev.zomboid.survival;
import java.util.*;import java.lang.reflect.*;import net.minecraft.world.item.ItemStack;
/** FF is the single food engine; ZS retains its own non-food drink temperature clock. */
public final class PreservationBridge {
 private record Context(Object level,Object container){}
 private static final ThreadLocal<Deque<Context>> CONTEXT=ThreadLocal.withInitial(ArrayDeque::new);
 private static final Class<?> FF=type("com.fyxe.fffoodspoilageandpreservation.util.SpoilageHelper"),CLOCK=type("dev.zomboid.survival.FoodClock"),CONFIG=type("com.fyxe.fffoodspoilageandpreservation.config.ServerConfig");
 private static Class<?> type(String name){try{return Class.forName(name);}catch(ClassNotFoundException e){throw new IllegalStateException(name,e);}}
 private static Object call(Object object,String name,Object...args){try{return PreservationReflect.call(object,name,args);}catch(ReflectiveOperationException e){throw new IllegalStateException(name,e);}}
 private static Object staticField(Class<?> type,String name){try{return type.getField(name).get(null);}catch(ReflectiveOperationException e){throw new IllegalStateException(name,e);}}
 private static Object componentKey(){return ((java.util.function.Supplier<?>)staticField(type("com.fyxe.fffoodspoilageandpreservation.data.ModDataComponents"),"SPOILAGE")).get();}
 private static Object component(ItemStack stack){return call(stack,"get",componentKey());}
 private static void component(ItemStack stack,Object value){call(stack,"set",componentKey(),value);}
 private static long time(Object level){return ((Number)call(level,"getGameTime")).longValue();}
 private static double number(Object value){return ((Number)value).doubleValue();}
 private static int integer(Object value){return ((Number)value).intValue();}
 public static boolean food(ItemStack stack){return Boolean.TRUE.equals(call(FF,"isFood",stack));}
 public static boolean perishable(ItemStack stack){return Boolean.TRUE.equals(call(FF,"canSpoil",stack));}
 public static void enter(Object level,Object container){CONTEXT.get().push(new Context(level,container));}
 public static void exit(){Deque<Context> contexts=CONTEXT.get();if(!contexts.isEmpty())contexts.pop();if(contexts.isEmpty())CONTEXT.remove();}
 private static Object world(Object container){try{return PreservationReflect.call(container,"getLevel");}catch(ReflectiveOperationException absent){Context context=CONTEXT.get().peek();return context==null?null:context.level;}}
 private static Object position(Object container){try{return PreservationReflect.call(container,"getBlockPos");}catch(ReflectiveOperationException absent){return null;}}
 private static Object machine(Object level,Object position){if(level==null||position==null)return null;Object loaded=call(level,"hasChunkAt",position);if(!Boolean.TRUE.equals(loaded))return null;Object entity=call(level,"getBlockEntity",position);return entity!=null&&entity.getClass().getName().equals("dev.zomboid.survival.MachineEntity")?entity:null;}
 private static int cooling(Object machine){if(machine==null||!Boolean.TRUE.equals(call(machine,"zsPowered"))||Boolean.TRUE.equals(call(machine,"generator"))||Boolean.TRUE.equals(call(machine,"oven")))return 1;return Boolean.TRUE.equals(call(machine,"freezer"))?20:15;}
 private static boolean hot(Object machine){return machine!=null&&Boolean.TRUE.equals(call(machine,"zsPowered"))&&Boolean.TRUE.equals(call(machine,"oven"));}
 private static double cfg(String name,double fallback){try{return number(call(staticField(CONFIG,name),"get"));}catch(RuntimeException absent){return fallback;}}
 private static boolean server(Object level){if(level==null)return false;try{return !level.getClass().getField("isClientSide").getBoolean(level);}catch(ReflectiveOperationException e){return false;}}
 private static void removeLegacy(ItemStack stack){
  Object key=staticField(type("net.minecraft.core.component.DataComponents"),"CUSTOM_DATA");Object data=call(stack,"get",key);if(data==null)return;Object root=call(data,"copyTag");if(!Boolean.TRUE.equals(call(root,"contains","zomboid_food")))return;call(root,"remove","zomboid_food");
  if(Boolean.TRUE.equals(call(root,"isEmpty")))call(stack,"remove",key);else call(stack,"set",key,call(type("net.minecraft.world.item.component.CustomData"),"of",root));
 }
 public static void migrate(ItemStack stack,long now){
  if(!food(stack))return;Object legacy=call(CLOCK,"data",stack);boolean old=Boolean.TRUE.equals(call(legacy,"contains","left"));Object base=component(stack);if(base==null)base=call(FF,"ensureComponent",stack,now);
  if(base!=null&&old){
   double left=number(call(legacy,"getDouble","left"));long last=((Number)call(legacy,"getLong","last")).longValue();int rate=Math.max(1,integer(call(legacy,"getInt","rate")));boolean frozen=Boolean.TRUE.equals(call(legacy,"getBoolean","frozen"));
   if(Boolean.TRUE.equals(call(legacy,"contains","last"))&&!frozen)left-=Math.max(0,now-last)/(double)rate;double age=Math.clamp(1-left/30000.0,0,1);
   int count=integer(call(FF,"stageCount"));long total=0;for(int i=0;i<count-1;i++)total+=Math.max(1,((Number)call(FF,"stageDuration",i)).longValue());long elapsed=Math.min(total,(long)(total*age));int stage=0;
   while(stage<count-1){long duration=Math.max(1,((Number)call(FF,"stageDuration",stage)).longValue());if(elapsed<duration)break;elapsed-=duration;stage++;}
   int existing=integer(call(base,"stage"));long progress=((Number)call(base,"progressTicks")).longValue();if(stage>existing||stage==existing&&elapsed>progress)base=call(base,"withProgress",stage,elapsed,now);
   if(frozen)base=call(base,"withModifier",net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("fffoodspoilageandpreservation","frozen"));component(stack,base);
  }
  removeLegacy(stack);
 }
 public static ItemStack update(ItemStack stack,long now,int rate,boolean heated){
  if(!food(stack))return (ItemStack)call(CLOCK,"legacyUpdate",stack,now,rate,heated);
  migrate(stack,now);Context context=CONTEXT.get().peek();if(context==null||!server(context.level))return stack;
  double ambient=rate>1?1:number(call(FF,"getBiomeTemperature",context.level,position(context.container)));
  if(rate<=1)ambient=number(call(FF,"ambientRateMultiplier",context.level,ambient));
  call(FF,"advance",stack,context.level,1.0/Math.max(1,rate),ambient);thermal(stack,context.level,rate,heated,position(context.container));
  Object c=component(stack);if(c!=null&&Boolean.TRUE.equals(call(FF,"isFullySpoiled",c))){Object replacement=convert(stack,context.level);if(replacement instanceof ItemStack out&&!out.isEmpty())return out;}return stack;
 }
 private static Object convert(ItemStack stack,Object level){try{Method m=type("com.fyxe.fffoodspoilageandpreservation.event.SpoilageEvents").getDeclaredMethod("convertIfNotCancelled",ItemStack.class,type("net.minecraft.world.level.Level"));m.setAccessible(true);return m.invoke(null,stack,level);}catch(ReflectiveOperationException e){throw new IllegalStateException("FoodSpoiledEvent conversion",e);}}
 public static void inventory(Object container,long now,int rate,boolean heated){
  Object level=world(container);boolean bound=level!=null;if(bound)enter(level,container);
  try{int size=integer(call(container,"getContainerSize"));for(int i=0;i<size;i++){ItemStack s=(ItemStack)call(container,"getItem",i);if(food(s))migrate(s,now);}call(CLOCK,"legacyInventory",container,now,rate,heated);}finally{if(bound)exit();}
 }
 public static boolean frozen(ItemStack stack){if(!food(stack))return Boolean.TRUE.equals(call(CLOCK,"legacyFrozen",stack));Object c=component(stack);return c==null?Boolean.TRUE.equals(call(CLOCK,"legacyFrozen",stack)):Boolean.TRUE.equals(call(c,"hasModifier",net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("fffoodspoilageandpreservation","frozen")));}
 public static boolean cold(ItemStack stack){if(!food(stack))return Boolean.TRUE.equals(call(CLOCK,"legacyCold",stack));Object c=component(stack);return frozen(stack)||c!=null&&number(call(c,"storageRate"))>=0&&number(call(c,"storageRate"))<1;}
 public static double remaining(ItemStack stack){if(!food(stack))return number(call(CLOCK,"legacyRemaining",stack));Object c=component(stack);if(c==null)return number(call(CLOCK,"legacyRemaining",stack));int count=integer(call(FF,"stageCount")),stage=integer(call(c,"stage"));long total=0,used=((Number)call(c,"progressTicks")).longValue();for(int i=0;i<count-1;i++){long duration=Math.max(1,((Number)call(FF,"stageDuration",i)).longValue());total+=duration;if(i<stage)used+=duration;}return 30000*Math.clamp(1-used/(double)Math.max(1,total),0,1);}
 public static void inherit(ItemStack output,ItemStack input,long now){if(!food(output)){call(CLOCK,"legacyInherit",output,input,now);return;}migrate(input,now);migrate(output,now);Object a=component(output),b=component(input);if(b==null)return;Object result=a==null?b:call(type("com.fyxe.fffoodspoilageandpreservation.data.SpoilageComponent"),"worst",a,b);component(output,call(result,"withLastGameTime",now));}
 public static boolean merge(ItemStack a,ItemStack b){return Boolean.TRUE.equals(call(type("com.fyxe.fffoodspoilageandpreservation.util.SpoilageStacking"),"canMerge",a,b));}
 private static void thermal(ItemStack stack,Object level,int rate,boolean heated,Object position){
  double freeze=cfg("FREEZE_THRESHOLD",0),thaw=cfg("THAW_THRESHOLD",.5),temperature=heated?thaw+1:rate>=20?freeze-1:rate>=15?(freeze+thaw)/2:number(call(FF,"getBiomeTemperature",level,position));
  call(FF,"tickTemperature",stack,level,temperature,false,rate>=20,heated,(long)cfg("ICEBOX_FREEZE_DURATION_TICKS",2400),(long)cfg("BOILER_THAW_DURATION_TICKS",400));
 }
 public static boolean containerTemperature(ItemStack stack,Object level,Object pos){Object machine=machine(level,pos);if(machine==null)return false;migrate(stack,time(level));thermal(stack,level,cooling(machine),hot(machine),pos);return true;}
 public static Object device(Object level,Object pos){Object machine=machine(level,pos);if(machine==null)return null;String name=cooling(machine)>=20?"ICEBOX_ACTIVE":hot(machine)?"BOILER_ACTIVE":null;return name==null?null:staticField(type("com.fyxe.fffoodspoilageandpreservation.compat.ColdSweatCompat$ThermalDevice"),name);}
 public static Double ambient(Object level,Object pos){Object machine=machine(level,pos);return machine!=null&&(cooling(machine)>1||hot(machine))?1.0:null;}
 public static Object open(Object original,Object player){if(original==null)return null;Object level=call(player,"level"),pos=call(original,"pos"),machine=machine(level,pos);if(machine==null)return original;try{return original.getClass().getConstructor(double.class,type("net.minecraft.core.BlockPos"),String.class).newInstance(1.0/cooling(machine),pos,String.valueOf(call(machine,"id")));}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}}
}
