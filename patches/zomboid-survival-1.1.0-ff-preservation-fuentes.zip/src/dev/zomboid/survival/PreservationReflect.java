package dev.zomboid.survival;
import java.lang.reflect.*;
public final class PreservationReflect {
 private PreservationReflect(){}
 private record Key(Class<?> type,String name,java.util.List<Class<?>> arguments){}
 private static final java.util.concurrent.ConcurrentMap<Key,Method> METHODS=new java.util.concurrent.ConcurrentHashMap<>();
 public static Object call(Object target,String name,Object...args)throws ReflectiveOperationException{
  Class<?> type=target instanceof Class<?> c?c:target.getClass();
  java.util.List<Class<?>> arguments=new java.util.ArrayList<>(args.length);for(Object arg:args)arguments.add(arg==null?Object.class:arg.getClass());Key key=new Key(type,name,arguments);Method cached=METHODS.get(key);if(cached!=null)return cached.invoke(target instanceof Class<?>?null:target,args);
  for(Method m:type.getMethods())if(m.getName().equals(name)&&m.getParameterCount()==args.length){
   Class<?>[] params=m.getParameterTypes();boolean match=true;
   for(int i=0;i<args.length;i++){Class<?> p=params[i];if(p==int.class)p=Integer.class;else if(p==boolean.class)p=Boolean.class;else if(p==long.class)p=Long.class;else if(p==float.class)p=Float.class;else if(p==double.class)p=Double.class;
    if(args[i]!=null&&!p.isInstance(args[i])){match=false;break;}}
   if(match){METHODS.putIfAbsent(key,m);return m.invoke(target instanceof Class<?>?null:target,args);}
  }
  throw new NoSuchMethodException(type.getName()+"."+name);
 }
}
