Zomboid Survival 1.1.0 — conservación FF integrada

INSTALACION
Retirar Zomboid Survival 1.0.4 y el JAR externo FFFoodSpoilageAndPreservation 0.13.0. Instalar solo este nuevo Zomboid Survival en cliente y servidor. Conservar Doomsday Decoration, First Aid, Homeostatic y Farmer's Delight. FFUtilities 0.2.17 sigue incluida como dependencia Jar-in-Jar. No duplicar los dos mods originales con este JAR.

TODAS LAS FUNCIONES FF
Se incluyen todas las clases y recursos originales FF: cinco fases de comida, modifiers cured/candied/brined/smoked/frozen, recetas, efectos, cambios de nutricion/saturacion, tooltip/highlights, apilado, eventos API, compatibilidad con AppleSkin/Tough As Nails/Cold Sweat/EMI/FFNutrition y configuraciones. Solo siete clases originales se conectan al puente. FF permanece como segundo mod ID dentro del mismo archivo, para mantener componentes y recetas de mundos existentes; no necesita su JAR separado. Autoria FF: FyxeINC. Se conservan los archivos de licencia y metadata de la biblioteca.

UN SOLO RELOJ
Los alimentos usan FF para caducar. El viejo reloj de alimentos de Survival no avanza en paralelo. Los datos zomboid_food se migran a fase/progreso FF segun la fraccion de vida restante, conservando el estado peor entre FF y Legacy, los modificadores FF y otros CUSTOM_DATA ajenos. No vuelve fresca comida vieja ni borra nombres, componentes o datos de otros mods. Bebidas sin componente FOOD conservan el sistema de temperatura y descongelacion original Survival.

FRIO Y COCINA
Los frigorificos Survival con energia usan 1/15 de tasa de almacenamiento. Los congeladores con energia usan 1/20 y el modificador Frozen FF al completar su temporizador. Apagados vuelven a tasa normal; el motor FF conserva la tasa anterior para liquidar el tiempo transcurrido. Horno y fogones mantienen descongelacion antes de cocinar, usando temperatura/tiempos FF para alimentos. Las congelaciones y descongelaciones alimentarias siguen los ajustes FF ICEBOX_FREEZE_DURATION_TICKS / BOILER_THAW_DURATION_TICKS. El agua conserva tiempos propios originales. A las maquinas Survival se les reconoce como dispositivos termicos, sin requerir instalar Cold Sweat. No fuerza chunks descargados.

SIN DUPLICADOS
Los cuatro mixins de apilado antiguos Survival se desactivan porque FF cubre inventarios, menus, entidades, hoppers, bundles y item handlers. Los tooltips antiguos de caducidad de alimentos se omiten, dejando los de FF. Se conserva el tooltip de bebidas, maquinas y combustible. El evento API FoodSpoiledEvent sigue pudiendo cancelar la conversion en maquinas. Agua, generadores, interfaces, energia, curacion y resto del codigo Survival original se conservan.

VALIDACION
Compilacion de puente con stubs, revision de metadata y Jar-in-Jar, bytecode y pruebas simuladas. No se ha iniciado Minecraft para validar mixins/registro/recetas. Probar primero en copia del mundo.
