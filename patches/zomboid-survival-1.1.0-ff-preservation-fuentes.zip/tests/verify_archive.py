from pathlib import Path
import zipfile,json,tomllib,hashlib
base=Path('work/survival-ff')
originals=[Path('/workspace/attachments/3c6ae573-a615-4f02-8734-00702877b267/zomboid-survival-1.21.1-1.0.4-water-varieties.jar'),Path('/workspace/attachments/69e2d9e4-d690-43b4-a9ab-08a9b439e38e/fffoodspoilageandpreservation-0.13.0+1.21.1-neoforge.jar')]
changed={'META-INF/MANIFEST.MF','META-INF/neoforge.mods.toml','zomboid_survival.mixins.json','dev/zomboid/survival/FoodClock.class','dev/zomboid/survival/FoodStacking.class','dev/zomboid/survival/Client.class','dev/zomboid/survival/mixin/FurnaceMixin.class','dev/zomboid/survival/mixin/StoveMixin.class','com/fyxe/fffoodspoilageandpreservation/util/SpoilageHelper.class','com/fyxe/fffoodspoilageandpreservation/compat/ColdSweatCompat.class'}
with zipfile.ZipFile(base/'zomboid-survival-1.21.1-1.1.0-ff-preservation-integrated.jar') as z:
 assert z.testzip() is None
 checked=0
 for source in originals:
  with zipfile.ZipFile(source) as old:
   for entry in old.infolist():
    if entry.is_dir():continue
    assert entry.filename in z.namelist(),entry.filename
    if entry.filename not in changed:
     assert old.read(entry)==z.read(entry.filename),entry.filename
     checked+=1
 meta=tomllib.loads(z.read('META-INF/neoforge.mods.toml').decode())
 assert {m['modId'] for m in meta['mods']}=={'zomboid_survival','fffoodspoilageandpreservation'}
 for mixin in meta['mixins']:
  config=json.loads(z.read(mixin['config']))
  for name in config.get('mixins',[])+config.get('client',[])+config.get('server',[]):
   assert (config['package']+'.'+name).replace('.','/')+'.class' in z.namelist()
 jarjar=json.loads(z.read('META-INF/jarjar/metadata.json'))
 for dependency in jarjar['jars']:
  import io
  with zipfile.ZipFile(io.BytesIO(z.read(dependency['path']))) as library:
   assert library.testzip() is None
 assert not any(n.startswith('net/minecraft/') for n in z.namelist()),'SDK stubs leaked'
 print(f'PASS archive CRC, {checked} unchanged original entries, mixin classes, two mod IDs, bundled FFUtilities, no SDK stubs')
