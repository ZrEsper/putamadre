package net.minecraft.client.renderer;public class RenderType {public static final RenderType LINES=new RenderType();public static RenderType lines(){return LINES;}}
