package dev.tactical.tacz;
import java.util.function.Supplier;import net.minecraft.resources.ResourceLocation;import net.minecraft.network.RegistryFriendlyByteBuf;import net.minecraft.network.codec.StreamCodec;import net.minecraft.network.protocol.common.custom.CustomPacketPayload;import net.minecraft.server.level.ServerPlayer;import net.neoforged.neoforge.network.PacketDistributor;
public final class FireNetwork {
 public record Fire(long timestamp,float charge,float pitch,float yaw) implements CustomPacketPayload {
  public static final Type<Fire> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("tacz_tactical","aim_fire"));
  public static final StreamCodec<RegistryFriendlyByteBuf,Fire> CODEC=StreamCodec.of((b,v)->b.writeUtf(v.timestamp+","+v.charge+","+v.pitch+","+v.yaw,128),b->decode(b.readUtf(128)));public Type<Fire> type(){return TYPE;}
 }
 public record Trace(double x,double y,double z,double ex,double ey,double ez,boolean hit) implements CustomPacketPayload {
  public static final Type<Trace> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("tacz_tactical","shot_trace"));
  public static final StreamCodec<RegistryFriendlyByteBuf,Trace> CODEC=StreamCodec.of((b,v)->b.writeUtf(v.x+","+v.y+","+v.z+","+v.ex+","+v.ey+","+v.ez+","+v.hit,256),b->trace(b.readUtf(256)));public Type<Trace> type(){return TYPE;}
 }
 public static boolean valid(Fire p){return p.timestamp>=0&&Float.isFinite(p.charge)&&p.charge>=0&&p.charge<=1&&Float.isFinite(p.pitch)&&Math.abs(p.pitch)<=90&&Float.isFinite(p.yaw)&&Math.abs(p.yaw)<=1000000;}
 static Fire decode(String text){String[] s=text.split(",",-1);if(s.length!=4)throw new IllegalArgumentException("aim/fire fields");Fire p=new Fire(Long.parseLong(s[0]),Float.parseFloat(s[1]),Float.parseFloat(s[2]),Float.parseFloat(s[3]));if(!valid(p))throw new IllegalArgumentException("invalid aim/fire");return p;}
 static Trace trace(String text){String[] s=text.split(",",-1);if(s.length!=7)throw new IllegalArgumentException("trace fields");double[] p=new double[6];for(int i=0;i<6;i++){p[i]=Double.parseDouble(s[i]);if(!Double.isFinite(p[i])||Math.abs(p[i])>32000000)throw new IllegalArgumentException("trace bounds");}if(Math.hypot(Math.hypot(p[3]-p[0],p[4]-p[1]),p[5]-p[2])>513)throw new IllegalArgumentException("trace length");if(!s[6].equals("true")&&!s[6].equals("false"))throw new IllegalArgumentException("trace hit flag");return new Trace(p[0],p[1],p[2],p[3],p[4],p[5],Boolean.parseBoolean(s[6]));}
 static int reports;
 public static void fire(Object player,Fire p){if(!(player instanceof ServerPlayer)||!valid(p))return;try{Object operator=Reflect.call(Reflect.type("com.tacz.guns.api.entity.IGunOperator"),"fromLivingEntity",player);Supplier<Float> pitch=()->p.pitch,yaw=()->p.yaw;Object result=Reflect.call(operator,"shoot",pitch,yaw,p.timestamp,p.charge);if(reports++<32)System.out.println("[TacZ Ray] v1.2.0 yaw="+p.yaw+" pitch="+p.pitch+" nativeResult="+result);}catch(Exception e){Reflect.warn("authoritative fire handler",e);}}
 public static void broadcast(Object level,Trace trace){try{for(Object p:(Iterable<?>)Reflect.call(level,"players")){double x=ShotAlignment.n(Reflect.call(p,"getX"))-trace.x,y=ShotAlignment.n(Reflect.call(p,"getEyeY"))-trace.y,z=ShotAlignment.n(Reflect.call(p,"getZ"))-trace.z;if(x*x+y*y+z*z<=256D*256&&p instanceof ServerPlayer sp)PacketDistributor.sendToPlayer(sp,trace);}}catch(Exception e){Reflect.warn("authoritative trace delivery",e);}}
 @net.neoforged.fml.common.EventBusSubscriber(modid="tacz_tactical",bus=net.neoforged.fml.common.EventBusSubscriber.Bus.MOD)
 public static class Registration {
  @net.neoforged.bus.api.SubscribeEvent public static void register(net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent e){var r=e.registrar("1.2.0");r.playToServer(Fire.TYPE,Fire.CODEC,(p,c)->c.enqueueWork(()->fire(c.player(),p)));r.playToClient(Trace.TYPE,Trace.CODEC,(p,c)->c.enqueueWork(()->{try{Reflect.call(Reflect.type("dev.tactical.tacz.ShotTrails"),"add",p);}catch(Exception ex){Reflect.warn("shot trace receive",ex);}}));}
 }
}
