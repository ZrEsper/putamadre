@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Aplicar-TZP.ps1"
if errorlevel 1 echo ERROR: No se completo el parche. El respaldo se conserva.
pause
