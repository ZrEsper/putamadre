from pathlib import Path
import zipfile,json,re,hashlib
r=Path('work/tzp-fix');source=zipfile.ZipFile('attachments/fafe8dae-c558-4fd2-b687-fb036e76ba87/TZP_1.20.1_2.7.zip');fresh=zipfile.ZipFile('attachments/7bb48366-d169-4df3-9672-a95356603b42/FreshAnimations_v1.10.4.zip')
prefix='assets/minecraft/optifine/cem/';copied={}
def add(name):
 if name in copied:return
 data=fresh.read(name);copied[name]=data
 obj=json.loads(data)
 def visit(x):
  if isinstance(x,list):
   for v in x:visit(v)
  elif isinstance(x,dict):
   for k,v in x.items():
    if k=='model' and isinstance(v,str):
     target=prefix+v if '/' not in v else str(Path(name).parent/v)
     add(target)
    else:visit(v)
 visit(obj)
for mob in ['zombie','husk','drowned','drowned_outer']:
 name=prefix+mob+'.jem'
 if name in fresh.namelist():add(name)
removed=[n for n in source.namelist() if n.startswith(prefix)]
dest=r/'TZP_1.20.1_2.7-connected-zombies-fix.1.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in source.namelist():
  if n.endswith('/') or n.startswith(prefix):continue
  b=source.read(n)
  if n=='pack.mcmeta':b=(json.dumps({'pack':{'pack_format':34,'description':'TZP textures + original Fresh Animations zombie models — connected bodies for 1.21.1'}},ensure_ascii=False,indent=2)+'\n').encode()
  z.writestr(n,b)
 for n,b in copied.items():z.writestr(n,b)
 z.writestr('ZOMBIES-LEEME.txt','Texturas TZP de Tissou conservadas. Modelos y animaciones originales Fresh Animations 1.10.4 de FreshLX, suministrados por el usuario. Se reemplazan los modelos personalizados de heridas visuales por cuerpos completos. Las amputaciones y quemaduras visuales personalizadas ya no se representan en este pack; el mod conserva sus efectos de juego. Reemplaza el ZIP TZP anterior en resourcepacks. No dejes ambas versiones activas. Comprobado como archivo; apariencia final pendiente de probar en Minecraft con EMF.\n')
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 kept=0
 for n in source.namelist():
  if n.endswith('/') or n.startswith(prefix) or n=='pack.mcmeta':continue
  assert z.read(n)==source.read(n);kept+=1
 for n,b in copied.items():assert z.read(n)==fresh.read(n)
 print('Pack:',dest,'preserved files:',kept,'original Fresh model files:',len(copied),'removed custom CEM:',len(removed),'size:',dest.stat().st_size)
(r/'pack-validation.json').write_text(json.dumps({'preserved_files':kept,'copied_fresh_files':list(copied),'removed_custom_cem':removed,'runtime_tested':False},indent=2))
