$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$base = $PSScriptRoot
$dirs = @($base, (Split-Path $base -Parent))
$choices = @()
foreach ($dir in $dirs) {
    $choices += @(Get-ChildItem -LiteralPath $dir -Filter 'TZP_1.20.1_2.7*.zip' -File -ErrorAction SilentlyContinue)
}
$choices = @($choices | Sort-Object FullName -Unique)
if ($choices.Count -eq 1) { $target = $choices[0].FullName }
elseif ($choices.Count -gt 1) {
    for ($i=0; $i -lt $choices.Count; $i++) { Write-Host "$($i+1): $($choices[$i].FullName)" }
    $choice = Read-Host 'Numero del ZIP TZP que esta activo'
    $index = 0
    if (-not [int]::TryParse($choice,[ref]$index) -or $index -lt 1 -or $index -gt $choices.Count) { throw 'Seleccion invalida' }
    $target = $choices[$index-1].FullName
} else { $target = (Read-Host 'Ruta completa del ZIP TZP en resourcepacks').Trim('"') }
if (-not (Test-Path -LiteralPath $target -PathType Leaf) -or [IO.Path]::GetExtension($target) -ne '.zip') { throw 'No se encontro el ZIP' }
Write-Host 'Minecraft debe estar cerrado. Se conservara una copia del ZIP original.'
$backupDir = Join-Path (Split-Path $target -Parent) 'TZP-respaldo'
[IO.Directory]::CreateDirectory($backupDir) | Out-Null
$backup = Join-Path $backupDir (([IO.Path]::GetFileName($target)) + '.' + (Get-Date -Format 'yyyyMMdd-HHmmssfff') + '.bak')
[IO.File]::Copy($target,$backup,$false)
$temp = $target + '.connected-' + [guid]::NewGuid().ToString('N') + '.tmp'
[IO.File]::Copy($target,$temp,$false)
$prefix = 'assets/minecraft/optifine/cem/'
$archive = $null
try {
    $archive = [IO.Compression.ZipFile]::Open($temp,[IO.Compression.ZipArchiveMode]::Update)
    foreach ($entry in @($archive.Entries)) {
        if ($entry.FullName.StartsWith($prefix,[StringComparison]::Ordinal) -or $entry.FullName -eq 'pack.mcmeta') { $entry.Delete() }
    }
    $payload = Join-Path $base 'payload'
    foreach ($file in Get-ChildItem -LiteralPath $payload -Recurse -File) {
        $name = $file.FullName.Substring($payload.Length+1).Replace('\','/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
    $archive.Dispose(); $archive = $null
    $verify = [IO.Compression.ZipFile]::OpenRead($temp)
    try {
        foreach ($required in @('zombie.jem','husk.jem','drowned.jem','drowned_outer.jem','zombie_animations.jpm','husk_animations.jpm','drowned_animations.jpm')) {
            if ($null -eq $verify.GetEntry($prefix+$required)) { throw "Falta $required" }
        }
    } finally { $verify.Dispose() }
    [IO.File]::Replace($temp,$target,$null)
    Write-Host "TZP corregido: $target" -ForegroundColor Green
    Write-Host "Respaldo: $backup"
    Write-Host 'Se conserva el nombre y el orden del pack. Inicia Minecraft.'
} finally {
    if ($null -ne $archive) { $archive.Dispose() }
    if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
}
