package com.cleannrooster.dungeons_iso.api.cullers.room;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;import net.minecraft.core.BlockPos;
public final class ClearSight {
 public static boolean walkable(Object block,int y,int floor){for(Class<?> c=block.getClass();c!=null;c=c.getSuperclass()){String name=c.getName();if(name.equals("net.minecraft.world.level.block.LadderBlock"))return true;if((y<=floor+2&&name.equals("net.minecraft.world.level.block.StairBlock"))||(y<=floor+1&&name.equals("net.minecraft.world.level.block.SlabBlock")))return true;}return false;}
 public static SightlineMask cast(SightlineScanner scanner,ChunkView view,double cx,double cy,double cz,double tx,double ty,double tz,int floor){
  LongOpenHashSet hidden=new LongOpenHashSet();
  ClearVolume.visit(cx,cy,cz,tx,ty,tz,Math.max(floor,view.getBottomY()),view.getTopY(),(x,y,z)->{scanner.tickBudget();var state=view.getBlockState(x,y,z);if(state!=null&&!state.isAir()&&!walkable(state.getBlock(),y,floor))hidden.add(BlockPos.asLong(x,y,z));});
  scanner.lastResult="clear player and surroundings: "+hidden.size()+" blocks";scanner.lastShapesFound=hidden.size();scanner.lastShapesCulled=hidden.size();scanner.lastShapesIncomplete=0;scanner.castCount++;
  return new SightlineMask(hidden,SightlineScanner.buildSections(hidden),SightlineScanner.contentHash(hidden),1,false,hidden.size(),hidden.size(),0);
 }
}
