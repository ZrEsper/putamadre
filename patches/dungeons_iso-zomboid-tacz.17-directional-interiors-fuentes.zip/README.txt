Dungeons ISO Zomboid TaCZ 17 · Interior y despeje direccional

Reemplazar v16 (o v15/v14), solo una version instalada en cliente.

Corrige recorte excesivo: solo se ocultan los obstaculos del lado de la camara respecto al jugador, dentro del corredor que conecta la camara real al personaje. Las estructuras que quedan por delante, al otro lado del jugador respecto a la camara, permanecen visibles. La direccion se obtiene de la camara, no de la orientacion de la cabeza ni del arma.

Se conserva el suelo por debajo de los pies, los escalones hasta dos bloques sobre ese nivel, las losas hasta un bloque y las escaleras de mano. Las losas elevadas de techos siguen siendo elegibles para el despeje. Hojas, enredaderas y muros del lado de la camara pueden ocultarse; cofres/modelos con renderer especial siguen el mismo filtro. Los bloques solo se ocultan; mantienen colision, inventarios e interacciones.

Se desactiva el viejo recorte por habitaciones: podia ocultar suelos o estructuras completas delante del jugador. TerrainCulling usa exclusivamente la mascara direccional; RoomScanner no publica recortes ni solicita trabajos. Se conserva trabajador asincrono, captura de chunks cargados, cancelacion de calculos obsoletos, presupuesto y reconstruccion incremental de secciones para el corredor. No fuerza chunks. Se conserva zoom rapido y TaCZ. La anotacion Mixin permanece correctamente en RuntimeInvisibleAnnotations, como en v16.

Validacion: 382701 comprobaciones simuladas de cobertura, cuatro orientaciones, estructuras de delante conservadas y superficies de paso; verificacion de anotacion Mixin/Inject, bytecode y CRC. No se ha ejecutado Minecraft ni comprobado visualmente este mapa.

Fuentes: PatchClear aplica ASM al JAR14 original; entradas original14, salida17, directorio helper classes. src contiene ClearSight/ClearVolume; stubs solo permiten compilar sin SDK real y NUNCA deben incluirse en el mod. testsrc contiene pruebas simuladas. Requiere Java21 y exports java.base/jdk.internal.org.objectweb.asm y .tree. Para desarrollo contra SDK real, aplicar antes los accesos publicos a SightlineScanner.tickBudget/buildSections/contentHash. El empaquetador incluye exclusivamente las tres clases helper y el mixin generado, nunca mocks.
