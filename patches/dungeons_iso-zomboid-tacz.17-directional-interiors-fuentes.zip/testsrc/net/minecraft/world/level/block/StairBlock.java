package net.minecraft.world.level.block;public class StairBlock extends Block {}
