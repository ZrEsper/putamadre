package net.minecraft.world.level.block;public class LadderBlock extends Block {}
