package net.minecraft.world.level.block;public class SlabBlock extends Block {}
