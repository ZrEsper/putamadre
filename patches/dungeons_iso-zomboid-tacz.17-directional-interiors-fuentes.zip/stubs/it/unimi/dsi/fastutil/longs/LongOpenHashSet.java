package it.unimi.dsi.fastutil.longs;public class LongOpenHashSet {public boolean add(long x){return true;}public int size(){return 0;}}
