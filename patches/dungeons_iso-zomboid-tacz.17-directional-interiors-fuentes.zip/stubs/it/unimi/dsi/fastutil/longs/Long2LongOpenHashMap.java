package it.unimi.dsi.fastutil.longs;public class Long2LongOpenHashMap {}
