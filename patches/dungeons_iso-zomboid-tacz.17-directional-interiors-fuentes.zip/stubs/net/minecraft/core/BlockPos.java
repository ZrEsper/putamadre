package net.minecraft.core;public class BlockPos {public static long asLong(int x,int y,int z){return ((long)x&0x3ffffff)<<38|((long)z&0x3ffffff)<<12|y&0xfff;}}
