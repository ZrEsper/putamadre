package ichttt.mods.firstaid.survival;
public final class HeadImpact {
 public static void record(Object model,Object player,Object source,Object before){
  if(model==null||before==null||player==null||source==null)return;
  Object level=WetReflection.call(player,"level");if(Boolean.TRUE.equals(WetReflection.call(level,"isClientSide"))||Boolean.TRUE.equals(WetReflection.call(player,"isCreative"))||Boolean.TRUE.equals(WetReflection.call(player,"isSpectator")))return;
  String id=String.valueOf(WetReflection.call(source,"getMsgId"));
  Object attacker=WetReflection.call(source,"getEntity"),direct=WetReflection.call(source,"getDirectEntity");
  if(attacker==null&&direct==null&&!id.equals("fall")&&!id.equals("flyIntoWall")&&!id.contains("explosion")&&!id.equals("fallingBlock")&&!id.equals("anvil"))return;
  Object head=WetReflection.constant("ichttt.mods.firstaid.api.enums.EnumPlayerPart","HEAD");
  Object oldPart=WetReflection.call(before,"getFromEnum",head),part=WetReflection.call(model,"getFromEnum",head);
  double loss=WetReflection.number(WetReflection.get(oldPart,"currentHealth"))-WetReflection.number(WetReflection.get(part,"currentHealth"));
  double threshold=Math.max(2,WetReflection.number(WetReflection.call(part,"getMaxHealth"))*.25);if(!Double.isFinite(loss)||loss<threshold)return;
  Object data=WetReflection.call(player,"getPersistentData");long now=((Number)WetReflection.call(level,"getGameTime")).longValue();
  if(Boolean.TRUE.equals(WetReflection.call(data,"contains","firstaid_head_impact"))&&now-((Number)WetReflection.call(data,"getLong","firstaid_head_impact")).longValue()<20)return;
  WetReflection.call(data,"putLong","firstaid_head_impact",now);
  int ticks=(int)Math.max(80,Math.min(120,loss*20));effect(player,"CONFUSION",ticks);effect(player,"MOVEMENT_SLOWDOWN",30);
 }
 private static void effect(Object player,String name,int duration){Object holder=WetReflection.constant("net.minecraft.world.effect.MobEffects",name);Object instance=WetReflection.create("net.minecraft.world.effect.MobEffectInstance",holder,duration,0,false,false,true);WetReflection.call(player,"addEffect",instance);}
}
