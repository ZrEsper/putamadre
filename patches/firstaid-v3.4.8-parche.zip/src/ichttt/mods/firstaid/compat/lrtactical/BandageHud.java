package ichttt.mods.firstaid.compat.lrtactical;
import ichttt.mods.firstaid.survival.ClinicalState.Wound;
public final class BandageHud {
 private static int shade(Wound w,int row,int height){if(row==0||row==height-1)return w.dirty?0xff71614a:0xffa7a89e;if(row%3==2)return w.dirty?0xff928064:0xffc7c8bd;return w.dirty?0xffb6a080:0xfff3f1df;}
 public static void hud(Object g,int x,int y,int s,Wound w,boolean bleed,int index){
  if(w.bandaged){int width=index<2?16:8;int height=index<2?8:6;int left=x-width/2,top=y-height/2;
   for(int r=0;r<height;r++){TreatmentV33.fill(g,left,top+r,left+width,top+r+1,shade(w,r,height));TreatmentV33.fill(g,left,top+r,left+1,top+r+1,w.dirty?0xff6b5940:0xff95978c);TreatmentV33.fill(g,left+width-1,top+r,left+width,top+r+1,w.dirty?0xff6b5940:0xff95978c);}
  }TreatmentV33.marker(g,x,y,s,w,bleed);
 }
 public static void menu(Object g,int x,int y,int s,Wound w,boolean bleed,int[][] polygon,double scale,double ox,double oy){
  if(w.bandaged&&Double.isFinite(scale)&&scale>0){double cy=(y-oy)/scale;int top=(int)Math.floor(y-4*scale),bottom=(int)Math.ceil(y+4*scale);int h=Math.max(1,bottom-top);
   for(int py=top;py<bottom;py++){double sy=(py+.5-oy)/scale;double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;
    for(int i=0;i<polygon.length;i++){int[] a=polygon[i],b=polygon[(i+1)%polygon.length];if((a[1]<=sy&&b[1]>sy)||(b[1]<=sy&&a[1]>sy)){double ix=a[0]+(sy-a[1])*(b[0]-a[0])/(double)(b[1]-a[1]);min=Math.min(min,ix);max=Math.max(max,ix);}}
    if(min<max){int left=(int)Math.floor(ox+min*scale),right=(int)Math.ceil(ox+max*scale);int row=(int)((py-top)/scale);TreatmentV33.fill(g,left,py,right,py+1,shade(w,row,Math.max(1,(int)Math.ceil(h/scale))));int edge=Math.max(1,(int)Math.round(scale));TreatmentV33.fill(g,left,py,Math.min(right,left+edge),py+1,w.dirty?0xff71614a:0xffa7a89e);TreatmentV33.fill(g,Math.max(left,right-edge),py,right,py+1,w.dirty?0xff71614a:0xffa7a89e);}
   }
  }TreatmentV33.marker(g,x,y,s,w,bleed);
 }
}
