package ichttt.mods.firstaid.api.enums;public enum EnumPlayerPart {HEAD}
