package net.minecraft.world.effect;public class MobEffects {public static final Object CONFUSION=new Object(),MOVEMENT_SLOWDOWN=new Object();}
