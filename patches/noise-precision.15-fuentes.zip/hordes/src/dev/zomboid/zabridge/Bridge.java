package dev.zomboid.zabridge;
import java.lang.reflect.*;
/** Optional perception bridge: resolve entry points once, not on every sound or mob tick. */
public final class Bridge {
 static Class<?> helper;static boolean missing,warned;static Method controlled,sound,block,levelEvent;
 static synchronized Class<?> helper(){if(missing)return null;if(helper!=null)return helper;try{Class<?> type=Class.forName("dev.zomboid.reactive.Reactive");controlled=type.getMethod("controlled",Object.class);sound=type.getMethod("sound",Object.class,Object.class,double.class,double.class,double.class,float.class);block=type.getMethod("block",Object.class,Object.class,Object.class);levelEvent=type.getMethod("levelEvent",int.class,Object.class,double.class,double.class,double.class);helper=type;return helper;}catch(ClassNotFoundException e){missing=true;return null;}catch(ReflectiveOperationException e){missing=true;error(e);return null;}}
 static void error(Exception e){if(!warned){warned=true;System.err.println("[Zombie Awareness] Perception bridge unavailable: "+e);}}
 public static boolean controlled(Object mob){if(helper()==null)return false;try{return Boolean.TRUE.equals(controlled.invoke(null,mob));}catch(ReflectiveOperationException e){error(e);return false;}}
 public static void sound(Object event,Object level,double x,double y,double z,float volume){if(helper()==null)return;try{sound.invoke(null,event,level,x,y,z,volume);}catch(ReflectiveOperationException e){error(e);}}
 public static void block(Object player,Object level,Object position){if(helper()==null)return;try{block.invoke(null,player,level,position);}catch(ReflectiveOperationException e){error(e);}}
 public static void levelEvent(int id,Object level,double x,double y,double z){if(helper()==null)return;try{levelEvent.invoke(null,id,level,x,y,z);}catch(ReflectiveOperationException e){error(e);}}
}
