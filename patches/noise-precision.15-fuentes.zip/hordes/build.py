"""Rebuild from the two uploaded JARs, Java 21. Test SDK classes are never packaged."""
import pathlib, subprocess, zipfile, sys
root=pathlib.Path(__file__).resolve().parent
hordes,awareness=map(pathlib.Path,sys.argv[1:3])
classes=root/'classes';tools=root/'tools';classes.mkdir(exist_ok=True);tools.mkdir(exist_ok=True)
exports=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
subprocess.run(['java','com.sun.tools.javac.Main','-d',str(classes),*[str(f) for d in ['src','stubs'] for f in (root/d).rglob('*.java')]],check=True)
subprocess.run(['java','com.sun.tools.javac.Main',*exports,'-d',str(tools),str(root/'PatchNoise.java')],check=True)
out=root/'zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.15-direct-noise-spawn-filter.jar'
subprocess.run(['java',*exports,'-cp',str(tools),'PatchNoise',str(hordes),str(out),str(classes)],check=True)
with zipfile.ZipFile(awareness) as original,zipfile.ZipFile(root/'zombieawareness-neoforge-1.21.0-1.13.2-reactive-hearing.2.jar','w',zipfile.ZIP_DEFLATED) as result:
 for entry in original.infolist():
  result.writestr(entry,(classes/'dev/zomboid/zabridge/Bridge.class').read_bytes() if entry.filename=='dev/zomboid/zabridge/Bridge.class' else original.read(entry))
