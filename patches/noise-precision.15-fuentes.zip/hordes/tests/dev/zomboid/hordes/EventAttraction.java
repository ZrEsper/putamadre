package dev.zomboid.hordes;public class EventAttraction {public static int investigations;public static void investigate(Object m){investigations++;}}
