package dev.zomboid.hordes;public class InvestigateNoiseGoal {public InvestigateNoiseGoal(net.minecraft.world.entity.Mob m){}}
