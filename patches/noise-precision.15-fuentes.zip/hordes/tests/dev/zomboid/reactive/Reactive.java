package dev.zomboid.reactive;import net.minecraft.world.entity.Mob;import net.minecraft.core.BlockPos;public class Reactive {
 public static int sounds,blocks,events,emits;public static double lastEmit;
 public static void emit(Object level,double x,double y,double z,double r){emits++;lastEmit=r;}public static boolean controlled(Object o){return o instanceof Mob;}
 public static boolean hear(Object o,Object pos,Object source,double radius,long until,boolean heli){Mob m=(Mob)o;BlockPos p=(BlockPos)pos;double hearing=(double)m.tag.values.getOrDefault("zi_hearing",1.4);double dist=Math.sqrt(Math.pow(m.x-p.x(),2)+Math.pow(m.y-p.y(),2)+Math.pow(m.z-p.z(),2));if(dist>NoisePolicy.hearingRange(radius,hearing,false))return false;m.heard++;m.shooter=source;m.origin=p;m.tag.putLong("zh_pos",p.asLong());m.tag.putLong("zh_until",until);return true;}
 public static void sound(Object event,Object level,double x,double y,double z,float volume){sounds++;}public static void block(Object p,Object l,Object b){blocks++;}public static void levelEvent(int e,Object l,double x,double y,double z){events++;}
}
