package dev.tactical.tacz;public class Settings{public static float SOUND=2,SILENCED=1.25F;}
