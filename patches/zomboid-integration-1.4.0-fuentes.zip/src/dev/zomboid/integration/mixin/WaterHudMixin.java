package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.mojang.blaze3d.systems.RenderSystem;import net.minecraft.client.gui.GuiGraphics;import net.minecraft.client.Minecraft;import net.minecraft.core.BlockPos;
@Pseudo @Mixin(targets="homeostatic.overlay.WaterHud",remap=false)
public abstract class WaterHudMixin {
 @Unique private float[] integration$color;
 @Unique private boolean integration$blend;
 @Unique private int[] integration$blendFactors;
 @Inject(method="render(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/Minecraft;Lnet/minecraft/core/BlockPos;II)V",at=@At("HEAD"),remap=false)
 private void integration$begin(GuiGraphics graphics,Minecraft mc,BlockPos pos,int width,int height,CallbackInfo ci){graphics.flush();integration$color=RenderSystem.getShaderColor().clone();integration$blend=org.lwjgl.opengl.GL11.glIsEnabled(3042);integration$blendFactors=new int[]{org.lwjgl.opengl.GL11.glGetInteger(32969),org.lwjgl.opengl.GL11.glGetInteger(32968),org.lwjgl.opengl.GL11.glGetInteger(32971),org.lwjgl.opengl.GL11.glGetInteger(32970)};RenderSystem.setShaderColor(1,1,1,1);RenderSystem.defaultBlendFunc();RenderSystem.enableBlend();}
 @Inject(method="render(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/Minecraft;Lnet/minecraft/core/BlockPos;II)V",at=@At("RETURN"),remap=false)
 private void integration$end(GuiGraphics graphics,Minecraft mc,BlockPos pos,int width,int height,CallbackInfo ci){graphics.flush();float[] color=integration$color;if(color!=null)RenderSystem.setShaderColor(color[0],color[1],color[2],color[3]);int[] blend=integration$blendFactors;if(blend!=null)RenderSystem.blendFuncSeparate(blend[0],blend[1],blend[2],blend[3]);if(!integration$blend)RenderSystem.disableBlend();integration$color=null;}
}
