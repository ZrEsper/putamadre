package dev.zomboid.integration.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;import dev.zomboid.integration.loot.LootReach;
@Pseudo @Mixin(targets="dev.zomboid.scavenging.Search",remap=false)
public abstract class LootReachMixin {
 @Inject(method="event(Ljava/lang/Object;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private static void loot$block(Object event,CallbackInfo ci){if(LootReach.event(event,false))ci.cancel();}
 @Inject(method="entityEvent(Ljava/lang/Object;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private static void loot$entity(Object event,CallbackInfo ci){if(LootReach.event(event,true))ci.cancel();}
 @Inject(method="start(Ljava/lang/Object;Ldev/zomboid/scavenging/Search$Target;Ljava/lang/Object;)V",at=@At("HEAD"),cancellable=true,remap=false)
 private static void loot$start(Object player,@Coerce Object target,Object hand,CallbackInfo ci){if(!LootReach.near(player,target)){LootReach.message(player);ci.cancel();}}
 @Inject(method="open(Ldev/zomboid/scavenging/Search$Job;)Z",at=@At("HEAD"),cancellable=true,remap=false)
 private static void loot$open(@Coerce Object job,CallbackInfoReturnable<Boolean> ci){if(!LootReach.job(job)){LootReach.message(dev.zomboid.scavenging.R.get(job,"player"));ci.setReturnValue(false);}}
 @Inject(method="inReach(Ldev/zomboid/scavenging/Search$Job;)Z",at=@At("HEAD"),cancellable=true,remap=false)
 private static void loot$reach(@Coerce Object job,CallbackInfoReturnable<Boolean> ci){ci.setReturnValue(LootReach.job(job));}
}
