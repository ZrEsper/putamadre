package dev.zomboid.integration;
import java.util.*;
/** Lightweight far travel: coordinates and hearing only, no entity or chunk references. */
public final class VirtualTravel {
 public record Echo(double x,double y,double z,double radius,boolean quiet,long expires){}
 public static final class Route {
  public double x,z,y,targetX,targetZ;public long until,last;
  public Route(double x,double z,double y,double tx,double tz,long until,long last){this.x=x;this.z=z;this.y=y;targetX=tx;targetZ=tz;this.until=until;this.last=last;}
  public String encode(){return x+","+z+","+y+","+targetX+","+targetZ+","+until+","+last;}
  public static Route decode(String raw){String[] a=raw.split(",",-1);if(a.length!=7)throw new IllegalArgumentException("route");double[] p=new double[5];for(int i=0;i<5;i++){p[i]=Double.parseDouble(a[i]);if(!Double.isFinite(p[i])||Math.abs(p[i])>32_000_000)throw new IllegalArgumentException("coordinate");}return new Route(p[0],p[1],p[2],p[3],p[4],Long.parseLong(a[5]),Long.parseLong(a[6]));}
 }
 public static double hearing(UUID id){int h=Math.floorMod(id.hashCode(),10000);return h<500?.35+h/500d*.25:h>=9500?2+(h-9500)/500d*.6:1.1+(h-500)/9000d*.45;}
 public static double range(Echo e,UUID id){return Math.min(e.quiet()?96:1024,e.radius()*hearing(id));}
 public static boolean hears(Echo e,UUID id,double x,double z,long now){return (!e.quiet()||Math.floorMod(id.hashCode(),100)<35)&&e.expires()>now&&Double.isFinite(e.radius())&&e.radius()>0&&Math.hypot(x-e.x(),z-e.z())<=range(e,id);}
 public static Route hear(Echo echo,UUID id,double x,double z,long now){double tx=echo.x(),tz=echo.z();if(echo.quiet()){Random r=new Random(id.getMostSignificantBits()^id.getLeastSignificantBits()^(now/40));double angle=r.nextDouble()*Math.PI*2,distance=8+r.nextDouble()*12;tx+=Math.cos(angle)*distance;tz+=Math.sin(angle)*distance;}return new Route(x,z,echo.y(),tx,tz,now+12000,now);}
 public static boolean advance(Route r,long now){long dt=now-r.last;r.last=now;if(dt<=0||now>r.until)return false;double distance=Math.hypot(r.targetX-r.x,r.targetZ-r.z);if(distance<.1)return false;double step=Math.min(distance,Math.min(20,dt)/20d*2.3);r.x+=(r.targetX-r.x)/distance*step;r.z+=(r.targetZ-r.z)/distance*step;return true;}
 public static int chunk(double coordinate){return Math.floorDiv((int)Math.floor(coordinate),16);}
}
