from pathlib import Path
p=Path('work/sleep18/src/dev/zomboid/integration/ZombieSleep.java');t=p.read_text()
t=t.replace('int ticks;boolean failed;}','int ticks;boolean failed;final Map<UUID,VirtualTravel.Route> routes=new HashMap<>();final ArrayDeque<VirtualTravel.Echo> echoes=new ArrayDeque<>();Iterator<Entry> ears;long virtualTick,lastSaved;boolean dirty;Future<?> routeWrite;}')
t=t.replace('private static boolean wanted(Level level,Entry e){return !ChunkArea.virtualization(level)||playersNear(level,e.x,e.z,3)||preview(level,e.x,e.z);}','''private static boolean wanted(Level level,Entry e){Store s=STORES.get(level);VirtualTravel.Route route=s==null?null:s.routes.get(e.uuid);if(route!=null)return !ChunkArea.virtualization(level)||playersNear(level,chunk(route.x),chunk(route.z),3);return !ChunkArea.virtualization(level)||playersNear(level,e.x,e.z,3)||preview(level,e.x,e.z);}''')
t=t.replace('if(worker==null)worker=', 'loadRoutes(s);\n   if(worker==null)worker=')
t=t.replace('Entry e=s.entries.remove(uuid);','s.routes.remove(uuid);s.dirty=true;Entry e=s.entries.remove(uuid);')
t=t.replace('if(++s.ticks<100)return;','if(++s.ticks<20)return;')
t=t.replace('Entry old=s.entries.put(p.uuid,p.entry);','s.routes.remove(p.uuid);s.dirty=true;Entry old=s.entries.put(p.uuid,p.entry);')
t=t.replace('s.scan=((Iterable<Entity>)NativeAccess.call(level,"getAllEntities")).iterator();','ArrayList<Entity> snapshot=new ArrayList<>();for(Entity entity:(Iterable<Entity>)NativeAccess.call(level,"getAllEntities"))snapshot.add(entity);s.scan=snapshot.iterator();')
t=t.replace('if(s.wake==null||!s.wake.hasNext())','virtualTick(level,s);\n   if(s.wake==null||!s.wake.hasNext())')
# Routes use destination chunk; original chunk must not be requested or required.
t=t.replace('if(!Boolean.TRUE.equals(NativeAccess.call(level,"hasChunk",entry.x,entry.z)))continue;','VirtualTravel.Route route=s.routes.get(entry.uuid);int wakeX=route==null?entry.x:chunk(route.x),wakeZ=route==null?entry.z:chunk(route.z);if(!Boolean.TRUE.equals(NativeAccess.call(level,"hasChunk",wakeX,wakeZ)))continue;')
t=t.replace('boolean near=playersNear(level,entry.x,entry.z,3);','boolean near=playersNear(level,wakeX,wakeZ,3);')
t=t.replace('if(e==null||!zombie(e)||!e.getUUID().equals(entry.uuid))','if(e==null||!zombie(e)||!e.getUUID().equals(entry.uuid))')
t=t.replace('restoring=entry.uuid;boolean added;', '''if(route!=null){if(!relocate(level,e,route)){entry.retryAt=clock+40;continue;}Object entityTag=e.getPersistentData();NativeAccess.call(entityTag,"putDouble","zh_x",route.targetX);NativeAccess.call(entityTag,"putDouble","zh_y",route.y);NativeAccess.call(entityTag,"putDouble","zh_z",route.targetZ);NativeAccess.call(entityTag,"putLong","zh_until",gameTime(level)+600);NativeAccess.call(entityTag,"putBoolean","zh_heli",false);}
     restoring=entry.uuid;boolean added;''')
t=t.replace('if(added){active(s,entry);woken++;}','if(added){active(s,entry);s.routes.remove(entry.uuid);s.dirty=true;woken++;}')
t=t.replace('if(worker!=null){worker.shutdown();','for(Store s:STORES.values())if(!s.failed&&s.dir!=null)saveRoutes(s,true);\n  if(worker!=null){worker.shutdown();')
insert='''
 private static long gameTime(Level level)throws ReflectiveOperationException{return ((Number)NativeAccess.call(level,"getGameTime")).longValue();}
 /** Called once per admitted gun-noise pulse; stores only compact coordinates. */
 public static void noise(Object raw,double x,double y,double z,double radius,boolean quiet){
  if(!(raw instanceof Level level)||level.isClientSide||!Double.isFinite(x)||!Double.isFinite(y)||!Double.isFinite(z)||!Double.isFinite(radius)||radius<=0)return;
  Store s=store(level);if(s.failed||!ChunkArea.virtualization(level))return;try{long now=gameTime(level);s.echoes.addLast(new VirtualTravel.Echo(x,y,z,Math.min(1024,radius),quiet,now+600));while(s.echoes.size()>16)s.echoes.removeFirst();}catch(ReflectiveOperationException error){System.err.println("[Zomboid Integration] Virtual noise ignored: "+error);}
 }
 private static void loadRoutes(Store s)throws IOException{Path file=s.dir.resolve("virtual-routes.properties");if(!Files.exists(file))return;Properties p=new Properties();try(InputStream in=Files.newInputStream(file)){p.load(in);}for(String key:p.stringPropertyNames())try{UUID id=UUID.fromString(key);if(s.entries.containsKey(id))s.routes.put(id,VirtualTravel.Route.decode(p.getProperty(key)));}catch(IllegalArgumentException error){System.err.println("[Zomboid Integration] Invalid virtual route ignored: "+key);}}
 private static void saveRoutes(Store s,boolean force){if(worker==null||!s.dirty||(!force&&s.routeWrite!=null&&!s.routeWrite.isDone()))return;Properties p=new Properties();s.routes.forEach((id,route)->p.setProperty(id.toString(),route.encode()));Path file=s.dir.resolve("virtual-routes.properties");s.routeWrite=worker.submit(()->{try{Path tmp=file.resolveSibling("virtual-routes.properties.tmp");try(OutputStream out=Files.newOutputStream(tmp)){p.store(out,"Virtual far-zombie travel: no active entity or chunk loading");}ArchiveFiles.move(tmp,file);}catch(IOException e){throw new CompletionException(e);}});s.dirty=false;}
 private static void virtualTick(Level level,Store s)throws ReflectiveOperationException{
  long now=gameTime(level);if(now-s.virtualTick<20)return;s.virtualTick=now;s.echoes.removeIf(e->e.expires()<=now);
  if(s.ears==null||!s.ears.hasNext())s.ears=new ArrayList<>(s.entries.values()).iterator();int count=0;
  while(s.ears.hasNext()&&count++<256){Entry entry=s.ears.next();if(!entry.asleep||s.entries.get(entry.uuid)!=entry)continue;VirtualTravel.Route route=s.routes.get(entry.uuid);double x=route==null?entry.x*16d+8:route.x,z=route==null?entry.z*16d+8:route.z;
   if(playersNear(level,chunk(x),chunk(z),3))continue;
   for(Iterator<VirtualTravel.Echo> noises=s.echoes.descendingIterator();noises.hasNext();){VirtualTravel.Echo echo=noises.next();if(VirtualTravel.hears(echo,entry.uuid,x,z,now)){if(route==null||route.targetX!=echo.x()||route.targetZ!=echo.z()){route=VirtualTravel.hear(echo,entry.uuid,x,z,now);s.routes.put(entry.uuid,route);s.dirty=true;}else route.until=Math.max(route.until,now+12000);break;}}
  }
  // At most 4096 compact coordinate records; far populations never instantiate Mob/AI.
  count=0;for(var pair:s.routes.entrySet()){if(count++>=4096)break;Entry entry=s.entries.get(pair.getKey());if(entry!=null&&entry.asleep&&!playersNear(level,chunk(pair.getValue().x),chunk(pair.getValue().z),3)&&VirtualTravel.advance(pair.getValue(),now))s.dirty=true;}
  if(s.routeWrite!=null&&s.routeWrite.isDone())try{s.routeWrite.get();s.routeWrite=null;}catch(Exception error){s.routeWrite=null;s.dirty=true;System.err.println("[Zomboid Integration] Virtual routes save will retry: "+error);}
  if(now-s.lastSaved>=200){s.lastSaved=now;saveRoutes(s,false);}
 }
 /** Choose only loaded, nearby, collision-free positions. Never place a mob inside a wall. */
 private static boolean relocate(Level level,Entity entity,VirtualTravel.Route r)throws ReflectiveOperationException{
  int x=(int)Math.floor(r.x),z=(int)Math.floor(r.z),base=(int)Math.floor(r.y);int min=((Number)NativeAccess.call(level,"getMinBuildHeight")).intValue(),max=((Number)NativeAccess.call(level,"getMaxBuildHeight")).intValue();
  for(int distance=0;distance<=12;distance++)for(int sign:new int[]{-1,1}){int y=base+distance*sign;if(y<=min||y+2>=max)continue;Object pos=NativeAccess.call(Class.forName("net.minecraft.core.BlockPos"),"containing",(double)x,(double)y,(double)z);if(!Boolean.TRUE.equals(NativeAccess.call(level,"hasChunkAt",pos)))return false;
   Object below=NativeAccess.call(level,"getBlockState",NativeAccess.call(pos,"below"));if(Boolean.TRUE.equals(NativeAccess.call(below,"isAir")))continue;Object top=NativeAccess.call(pos,"above");if(!Boolean.TRUE.equals(NativeAccess.call(NativeAccess.call(level,"getBlockState",pos),"isAir"))||!Boolean.TRUE.equals(NativeAccess.call(NativeAccess.call(level,"getBlockState",top),"isAir")))continue;
   NativeAccess.call(entity,"setPos",x+.5,(double)y,z+.5);Object box=NativeAccess.call(entity,"getBoundingBox");if(Boolean.TRUE.equals(NativeAccess.call(level,"noCollision",entity,box)))return true;
  }return false;
 }
'''
t=t.replace(' @SubscribeEvent public static void stop(',insert+'\n @SubscribeEvent public static void stop(')
p.write_text(t)
