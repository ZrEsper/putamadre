from pathlib import Path
import subprocess,zipfile,json,hashlib
r=Path('work/sleep18');out=[]
subprocess.run(['java','com.sun.tools.javac.Main','-cp','work/balance16/classes:work/balance16/zomboid-integration-1.7.4-neoforge-1.21.1-military-loot-controls.jar','-d',str(r/'classes'),'work/integration16/stubs/net/neoforged/neoforge/event/entity/EntityLeaveLevelEvent.java','work/integration16/stubs/net/neoforged/neoforge/event/tick/ServerTickEvent.java',*[str(f) for f in (r/'src').rglob('*.java')]],check=True)
subprocess.run(['java','com.sun.tools.javac.Main','-cp','work/balance16/zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.16-loot-balance.jar','-d','work/noise17/classes',*[str(f) for f in Path('work/noise17/src').rglob('*.java')]],check=True)
sets=[('work/balance16/zomboid-integration-1.7.4-neoforge-1.21.1-military-loot-controls.jar',r/'zomboid-integration-1.7.5-neoforge-1.21.1-virtual-hearing-sleep.jar',r/'classes/dev/zomboid/integration','dev/zomboid/integration/'),('work/balance16/zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.16-loot-balance.jar',Path('work/noise17/zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.17-distant-hearing.jar'),Path('work/noise17/classes/dev/zomboid/reactive'),'dev/zomboid/reactive/'),('work/scope121/tacz-tactical-1.2.1-neoforge-1.21.1-scope-wheel-sensitivity.jar',Path('work/sniper122/tacz-tactical-1.2.2-neoforge-1.21.1-sniper-damage.jar'),Path('work/sniper122/classes/dev/tactical/tacz'),'dev/tactical/tacz/')]
for base,target,folder,prefix in sets:
 with zipfile.ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()}
 for p in folder.rglob('*.class'):data[prefix+str(p.relative_to(folder))]=p.read_bytes()
 if 'integration' in prefix:data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'version="1.7.4"',b'version="1.7.5"')
 if 'tactical' in prefix:
  j=json.loads(data['tacz_tactical.mixins.json']);j['mixins'].append('SniperDamageMixin');data['tacz_tactical.mixins.json']=json.dumps(j,indent=2).encode();data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'version="1.2.1"',b'version="1.2.2"')
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in data.items():z.writestr(n,b)
 with zipfile.ZipFile(target) as z:assert z.testzip() is None
 flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED']
 subprocess.run(['java',*flags,'-cp','work/tools','Verify',str(target)],check=True)
 b=target.read_bytes();out.append({'path':str(target),'remote':'mods/'+target.name,'size':len(b),'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
(r/'artifacts.json').write_text(json.dumps(out));print(json.dumps(out))
