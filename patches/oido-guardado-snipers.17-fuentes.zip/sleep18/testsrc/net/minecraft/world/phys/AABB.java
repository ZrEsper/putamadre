package net.minecraft.world.phys;public class AABB{public AABB(double x,double y,double z,double x2,double y2,double z2){}}
