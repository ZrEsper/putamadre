package dev.tactical.tacz.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(targets="com.tacz.guns.entity.EntityKineticBullet",remap=false)
public abstract class SniperDamageMixin {
 @Inject(method="getDamage(Lnet/minecraft/world/phys/Vec3;)F",at=@At("RETURN"),cancellable=true,remap=false)
 private void sniper$damage(net.minecraft.world.phys.Vec3 position,CallbackInfoReturnable<Float> ci){ci.setReturnValue(dev.tactical.tacz.SniperDamage.damage(this,ci.getReturnValue()));}
}
