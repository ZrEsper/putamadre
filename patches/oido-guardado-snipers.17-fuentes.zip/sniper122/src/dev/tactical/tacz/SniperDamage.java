package dev.tactical.tacz;
import java.util.*;
public final class SniperDamage {
 public static boolean sniper(String type){return type!=null&&type.toLowerCase(Locale.ROOT).contains("sniper");}
 public static float damage(Object bullet,float nativeDamage){if(!Float.isFinite(nativeDamage)||nativeDamage<=0)return nativeDamage;try{Object id=Reflect.call(bullet,"getGunId");Optional<?> index=(Optional<?>)Reflect.call(Reflect.type("com.tacz.guns.api.TimelessAPI"),"getCommonGunIndex",id);if(index.isPresent()&&sniper(String.valueOf(Reflect.call(index.get(),"getType"))))return nativeDamage*1.5f;}catch(Exception e){Reflect.warn("sniper damage",e);}return nativeDamage;}
}
