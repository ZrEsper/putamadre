package com.tacz.guns.api;
public class TimelessAPI{public record Index(String getType){}public static java.util.Optional<Index> getCommonGunIndex(String id){return id.equals("missing")?java.util.Optional.empty():java.util.Optional.of(new Index(id));}}
