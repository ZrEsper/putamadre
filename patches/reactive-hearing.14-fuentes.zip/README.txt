Zomboid Hordes 14 + Zombie Awareness reactive hearing 2

Instalación: reemplaza los dos JAR enviados por estos dos, tanto en clientes como en servidor. No mantengas copias de sus versiones antiguas en mods. Conserva Sound Attract 6.3.8d y las demás dependencias actuales. No añade una nueva dependencia de TaCZ. Conserva el panel administrativo, las reglas de construcción limitada y el resto del comportamiento original.

Audición: aproximadamente el 95 % tendrá audición mejorada (factor 1.25–1.55); el 5 % restante oye peor (0.35–0.60). La asignación es estable por UUID. También se aplica a zombies ya existentes al actualizar su perfil; no cambia sus velocidades, ropa o tipo de agresividad.

Disparos normales: radio base de 192–360 bloques, ajustado por el perfil del ruido. Disparos silenciosos: 48–108 bloques. La detección personal depende de la audición, con un máximo de 360 bloques. El aviso no marca automáticamente al tirador como enemigo: necesitan verlo para perseguirlo como objetivo. Un zombie que ya te ve puede atacarte aunque lleves silenciador.

Los tiros silenciados producen destinos de investigación diferentes por zombie, aproximadamente a 8–20 bloques del origen. No se guarda una identidad del tirador en este aviso. Se consulta la bandera real del silenciador mediante IGunOperator y la caché SilenceModifier de tu TaCZ 1.1.8-hotfix-r7. Si esa información no está disponible, se usa el perfil de ruido ya proporcionado por Sound Attract/TaCZ y el umbral de compatibilidad anterior de 64, además de nombres que indiquen silence/suppressed. El aumento adicional del 50 % en radio de reacción se incorpora una sola vez; el volumen audible se aumenta mediante Tactical 1.1.0.

Otros ruidos: se aumenta la sensibilidad de pasos normales y correr, golpes, puertas, cofres y explosiones. Agacharse sigue siendo más silencioso. Se conserva el filtro que impide que música, lluvia y sonidos ambientales de los propios zombies causen una cadena de alertas.

Coste: señales repetidas de la misma zona se agrupan durante 12 ticks (0.6 s a 20 TPS), con hasta 320 reacciones por búsqueda y rotación para atender a los restantes en las siguientes señales. Las ráfagas no crean una búsqueda por bala. Solo se consultan entidades y chunks ya cargados; no se despiertan zombies archivados por otros mods ni se cargan regiones lejanas. El aumento del radio y de zombies que responden sí puede aumentar la actividad de IA.

Zombie Awareness conserva su percepción integrada y ahora resuelve una sola vez los métodos del puente compartido, reduciendo reflexión repetida y mensajes de error continuos.

Verificación: 40 033 comprobaciones simuladas, usando el auxiliar de reflexión real y las reglas originales parcheadas. Incluye porcentaje de oyentes, migración estable, rangos, ruido silencioso, destinos imprecisos, duplicados, rotación de 700 entidades, ausencia de identidad del tirador y puente de ZA. CRC de ambos archivos y verificación de tipos de bytecode. No se ejecutó Minecraft.

Fuentes: build.py requiere Java 21 y los dos JAR de entrada. Los stubs son exclusivos para compilar; no se empaquetan en los mods.
