package dev.tactical.tacz;public class Settings{public static float SOUND=2,SILENCED=1.25F,FLASH_SCALE=0;public static long FLASH_MS=0;}
