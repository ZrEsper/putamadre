package com.tacz.guns.particles;public class BulletHoleOption{}
