package net.minecraft.network.protocol.game;public class ServerboundMovePlayerPacket {public record Rot(float yaw,float pitch,boolean grounded){}}
