package net.minecraft.world.phys;public class AABB {public AABB(double a,double b,double c,double d,double e,double f){}public AABB inflate(double n){return this;}}
