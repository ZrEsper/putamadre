package net.minecraft.world.entity;public class Entity {public double x,y,z;public double getX(){return x;}public double getZ(){return z;}public double getEyeY(){return y+1.62;}}
