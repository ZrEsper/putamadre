"""Usage: python3 build.py ORIGINAL_TACTICAL_JAR. Java 21 required."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
classes=root/'classes';tools=root/'tools';classes.mkdir(exist_ok=True);tools.mkdir(exist_ok=True)
exports=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
subprocess.run(['java','com.sun.tools.javac.Main','-d',str(classes),*[str(f) for d in ['src','stubs'] for f in (root/d).rglob('*.java')]],check=True)
subprocess.run(['java','com.sun.tools.javac.Main',*exports,'-d',str(tools),str(root/'AddPrecision.java')],check=True)
subprocess.run(['java',*exports,'-cp',str(tools),'AddPrecision',sys.argv[1],str(root/'tacz-tactical-1.1.7-neoforge-1.21.1-camera-ray-thin-tracers.jar'),str(classes)],check=True)
