package net.minecraft.world.level; public class Level {public void broadcastEntityEvent(net.minecraft.world.entity.Entity entity,byte event){}}
