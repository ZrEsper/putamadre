package net.minecraft.world.entity; public class Entity {public net.minecraft.world.level.Level level(){return null;}}
