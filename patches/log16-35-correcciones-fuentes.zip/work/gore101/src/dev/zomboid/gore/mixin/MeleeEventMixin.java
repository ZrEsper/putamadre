package dev.zomboid.gore.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(targets="net.minecraft.world.entity.LivingEntity",remap=false)
public abstract class MeleeEventMixin {
 @Inject(method="handleEntityEvent(B)V",at=@At("HEAD"),cancellable=true,remap=false)
 private void zg$meleeEvent(byte event,CallbackInfo ci){if(dev.zomboid.gore.MeleeReaction.event(this,event))ci.cancel();}
}
