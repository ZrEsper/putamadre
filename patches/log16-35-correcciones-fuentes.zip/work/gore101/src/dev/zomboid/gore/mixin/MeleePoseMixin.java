package dev.zomboid.gore.mixin;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(targets="net.minecraft.client.model.HumanoidModel",remap=false)
public abstract class MeleePoseMixin {
 @Inject(method="setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V",at=@At("HEAD"),remap=false)
 private void zg$reset(LivingEntity entity,float limbSwing,float limbSwingAmount,float age,float yaw,float pitch,CallbackInfo ci){dev.zomboid.gore.MeleeReaction.reset(this);}
 @Inject(method="setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V",at=@At("TAIL"),remap=false)
 private void zg$react(LivingEntity entity,float limbSwing,float limbSwingAmount,float age,float yaw,float pitch,CallbackInfo ci){dev.zomboid.gore.MeleeReaction.pose(this,entity,age);}
}
