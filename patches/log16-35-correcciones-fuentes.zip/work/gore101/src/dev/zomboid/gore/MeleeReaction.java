package dev.zomboid.gore;
import java.util.*;
public final class MeleeReaction {
 private static final WeakHashMap<Object,Reaction> REACTIONS=new WeakHashMap<>();
 private static final WeakHashMap<Object,List<Offset>> OFFSETS=new WeakHashMap<>();
 private record Reaction(int tick,int variant){}
 private record Offset(Object part,float x,float y,float z){}
 public static void damage(Object event){
  Object victim=R.call(event,"getEntity");
  if(!Gore.zombie(victim)||Gore.shots.get()!=null||R.num(R.call(event,"getNewDamage"))<=0)return;
  Object level=R.call(victim,"level");if(R.yes(R.get(level,"isClientSide")))return;
  Object source=R.call(event,"getSource"),attacker=R.call(source,"getEntity"),direct=R.call(source,"getDirectEntity");
  if(attacker==null||direct!=attacker)return;
  String type=String.valueOf(R.call(source,"getMsgId"));
  if(!type.equals("player")&&!type.equals("mob")&&!type.equals("mob_attack")&&!type.equals("mob_attack_no_aggro"))return;
  int tick=(int)R.num(R.get(victim,"tickCount"));
  int variant=Math.floorMod(tick+(int)R.num(R.call(victim,"getId")),3);
  ((net.minecraft.world.entity.Entity)victim).level().broadcastEntityEvent((net.minecraft.world.entity.Entity)victim,(byte)(-101-variant));
 }
 public static boolean event(Object victim,byte event){
  if(event>-101||event<-103||!Gore.zombie(victim))return false;
  REACTIONS.put(victim,new Reaction((int)R.num(R.get(victim,"tickCount")),-101-event));return true;
 }
 public static float envelope(float age){
  if(age<0||age>=12)return 0;
  return age<2?age/2f:(float)Math.pow((12-age)/10f,2);
 }
 public static void reset(Object model){
  List<Offset> old=OFFSETS.remove(model);if(old==null)return;
  for(Offset a:old){adjust(a.part,"xRot",-a.x);adjust(a.part,"yRot",-a.y);adjust(a.part,"zRot",-a.z);}
 }
 private static void adjust(Object p,String field,float delta){if(delta!=0)R.set(p,field,(float)R.num(R.get(p,field))+delta);}
 private static void add(Object model,List<Offset> offsets,String name,float x,float y,float z){
  Object p=R.get(model,name);if(p==null)return;adjust(p,"xRot",x);adjust(p,"yRot",y);adjust(p,"zRot",z);offsets.add(new Offset(p,x,y,z));
 }
 public static void pose(Object model,Object entity,float ageInTicks){
  if(!Gore.zombie(entity))return;
  Reaction r=REACTIONS.get(entity);if(r==null)return;
  float age=ageInTicks-r.tick,weight=envelope(age);
  if(age>=12){REACTIONS.remove(entity);return;}if(weight==0)return;
  float side=r.variant==1?-1f:1f;
  List<Offset> offsets=new ArrayList<>(6);
  add(model,offsets,"head",-.32f*weight,.17f*weight*side,.18f*weight*side);
  add(model,offsets,"body",-.19f*weight,.08f*weight*side,.13f*weight*side);
  add(model,offsets,"rightArm",-.42f*weight,-.12f*weight,.38f*weight);
  add(model,offsets,"leftArm",-.42f*weight,.12f*weight,-.38f*weight);
  if(r.variant==2){add(model,offsets,"rightLeg",.21f*weight,0,.08f*weight);add(model,offsets,"leftLeg",-.16f*weight,0,-.08f*weight);}
  OFFSETS.put(model,offsets);
 }
}
