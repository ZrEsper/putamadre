import dev.zomboid.gore.*;
import net.minecraft.world.entity.monster.Zombie;
public class TestReaction {
 static int checks;
 static void check(boolean value){checks++;if(!value)throw new AssertionError("check "+checks);}
 public static class Source {public Object who=new Object(),direct=who;public String type="player";public Object getEntity(){return who;}public Object getDirectEntity(){return direct;}public String getMsgId(){return type;}}
 public static class Event {public Zombie entity=new Zombie();public Source source=new Source();public double amount=5;public Object getEntity(){return entity;}public Object getSource(){return source;}public double getNewDamage(){return amount;}}
 public static class Part {public float xRot=.4f,yRot=.1f,zRot=.2f;}
 public static class Model {public Part head=new Part(),body=new Part(),leftArm=new Part(),rightArm=new Part(),leftLeg=new Part(),rightLeg=new Part();}
 public static void main(String[] args){
  Event e=new Event();MeleeReaction.damage(e);check(e.entity.level.sent==1);check(e.entity.level.last<=-101&&e.entity.level.last>=-103);
  e.amount=0;MeleeReaction.damage(e);check(e.entity.level.sent==1);e.amount=5;e.source.direct=new Object();MeleeReaction.damage(e);check(e.entity.level.sent==1);
  e.source.direct=e.source.who;e.source.type="arrow";MeleeReaction.damage(e);check(e.entity.level.sent==1);e.source.type="mob";e.entity.level.isClientSide=true;MeleeReaction.damage(e);check(e.entity.level.sent==1);
  check(!MeleeReaction.event(e.entity,(byte)2));check(!MeleeReaction.event(new Object(),(byte)-101));
  for(int variant=0;variant<3;variant++){
   check(MeleeReaction.event(e.entity,(byte)(-101-variant)));Model m=new Model();
   MeleeReaction.pose(m,e.entity,102);check(m.head.xRot<.4f);check(m.rightArm.zRot>.2f);check(m.leftArm.zRot<.2f);
   MeleeReaction.reset(m);check(Math.abs(m.head.xRot-.4f)<.00001);check(Math.abs(m.body.zRot-.2f)<.00001);MeleeReaction.reset(m);check(Math.abs(m.head.xRot-.4f)<.00001);
   for(int frame=0;frame<200;frame++){MeleeReaction.pose(m,e.entity,102);MeleeReaction.reset(m);check(Math.abs(m.head.xRot-.4f)<.00001);}
   MeleeReaction.pose(m,e.entity,113);check(Math.abs(m.head.xRot-.4f)<.00001);
  }
  check(MeleeReaction.envelope(-1)==0);check(MeleeReaction.envelope(0)==0);check(MeleeReaction.envelope(2)==1);check(MeleeReaction.envelope(12)==0);
  System.out.println("Melee reaction checks passed: "+checks);
 }
}
