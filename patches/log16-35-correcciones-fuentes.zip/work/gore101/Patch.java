import java.nio.file.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
public class Patch {
 public static void main(String[] args)throws Exception{
  byte[] b=Files.readAllBytes(Path.of(args[0]));ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);int count=0;
  if(c.name.endsWith("BulletMixin")){
   for(MethodNode m:c.methods)if(m.name.equals("zg$hit")||m.name.equals("zg$end")){
    if(!m.desc.startsWith("(Ljava/lang/Object;"))throw new IllegalStateException(m.desc);
    m.desc=m.desc.replaceFirst("Ljava/lang/Object;","Lcom/tacz/guns/util/TacHitResult;");
    m.visibleParameterAnnotations=null;m.invisibleParameterAnnotations=null;count++;
   }
   if(count!=2)throw new IllegalStateException("Expected two handlers");
  }else if(c.name.endsWith("Events")){
   for(MethodNode m:c.methods)if(m.name.equals("damage"))for(AbstractInsnNode i=m.instructions.getFirst();i!=null;i=i.getNext())if(i.getOpcode()==Opcodes.RETURN){
    InsnList hook=new InsnList();hook.add(new VarInsnNode(Opcodes.ALOAD,0));hook.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"dev/zomboid/gore/MeleeReaction","damage","(Ljava/lang/Object;)V",false));m.instructions.insertBefore(i,hook);count++;
   }
   if(count!=1)throw new IllegalStateException("Expected one event hook");
  }else throw new IllegalStateException(c.name);
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.write(Path.of(args[1]),w.toByteArray());System.out.println(c.name+": "+count+" edits");
 }
}
