import zipfile,subprocess
from pathlib import Path
r=Path('work/crawl107');base=Path('attachments/2ac7d6a5-a907-401e-8f8c-18f5d3b2a496/zomboid-zombie-gore-1.0.6-neoforge-1.21.1-weapon-trauma.jar')
with zipfile.ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()}
old=dict(data);flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
for name in ['Rules','Gore']:
 n='dev/zomboid/gore/'+name+'.class';p=r/(name+'.class');out=r/(name+'-patched.class');p.write_bytes(data[n]);subprocess.run(['java',*flags,'-cp',str(r/'tools'),'PatchCrawl',str(p),str(out)],check=True);data[n]=out.read_bytes()
subprocess.run(['java','com.sun.tools.javac.Main','-cp',str(base),'-d',str(r/'classes'),'work/crawl103/src/dev/zomboid/gore/CrawlGeometry.java'],check=True)
data['dev/zomboid/gore/CrawlGeometry.class']=(r/'classes/dev/zomboid/gore/CrawlGeometry.class').read_bytes();data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'version="1.0.6"',b'version="1.0.7"')
jar=r/'zomboid-zombie-gore-1.0.7-neoforge-1.21.1-weapon-trauma-crawl-fix.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in data.items():z.writestr(n,b)
with zipfile.ZipFile(jar) as z:assert z.testzip() is None
for n,b in old.items():
 if n not in ['dev/zomboid/gore/Gore.class','dev/zomboid/gore/Rules.class','META-INF/neoforge.mods.toml']:assert data[n]==b
subprocess.run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/tools','Verify',str(jar)],check=True)
subprocess.run(['java','com.sun.tools.javac.Main','-cp',str(jar),'-d',str(r/'tests'),*[str(p) for p in Path('work/crawl103/testsrc').rglob('*.java')]],check=True)
subprocess.run(['java','-cp',str(r/'tests')+':'+str(jar),'dev.zomboid.gore.GeometryTest'],check=True)
# Compare all original methods by normalized ASM representation separately in VerifyPreserved.
print('All other archive entries preserved exactly; artifact',jar,jar.stat().st_size)
