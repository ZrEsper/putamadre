import java.nio.file.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public class PatchCrawl {
 static void empty(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();}
 public static void main(String[] args)throws Exception{
  ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(c,0);int edits=0;
  for(MethodNode m:c.methods){
   if(c.name.endsWith("/Rules")&&m.name.equals("crawling")&&m.desc.equals("(I)Z")){
    empty(m);LabelNode no=new LabelNode();m.instructions.add(new VarInsnNode(Opcodes.ILOAD,0));m.instructions.add(new IntInsnNode(Opcodes.BIPUSH,48));m.instructions.add(new InsnNode(Opcodes.IAND));m.instructions.add(new IntInsnNode(Opcodes.BIPUSH,48));m.instructions.add(new JumpInsnNode(Opcodes.IF_ICMPNE,no));m.instructions.add(new InsnNode(Opcodes.ICONST_1));m.instructions.add(new InsnNode(Opcodes.IRETURN));m.instructions.add(no);m.instructions.add(new FrameNode(Opcodes.F_SAME,0,null,0,null));m.instructions.add(new InsnNode(Opcodes.ICONST_0));m.instructions.add(new InsnNode(Opcodes.IRETURN));edits++;
   }
   if(c.name.endsWith("/Gore")&&m.name.equals("dimensions")&&m.desc.equals("(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")){
    empty(m);m.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));m.instructions.add(new VarInsnNode(Opcodes.ALOAD,1));m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"dev/zomboid/gore/CrawlGeometry","dimensions",m.desc,false));m.instructions.add(new InsnNode(Opcodes.ARETURN));edits++;
   }

  }
  if(edits!=(c.name.endsWith("/Rules")?1:1))throw new IllegalStateException("Unexpected patch targets");ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.write(Path.of(args[1]),w.toByteArray());System.out.println(c.name+" "+edits+" fixes");
 }
}
