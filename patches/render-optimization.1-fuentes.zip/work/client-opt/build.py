import zipfile,subprocess
from pathlib import Path
r=Path('work/client-opt');flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
inputs=[('attachments/a082b080-5af6-4202-a814-b78b573cc592/quietly-1_0_0-cooldown-v12-vehicle-interactions.jar','cn/kafei/interact/Interaction.class','quietly-1_0_0-cooldown-v13-reflection-cache.jar'),('attachments/16d11597-1951-48de-a2ce-a04113a24d8e/moonlight-1.21.1-3.7.1-neoforge.jar','net/mehvahdjukaar/moonlight/api/client/PostShadersHelper$ComposedPostChain.class','moonlight-1.21.1-3.7.1-neoforge-postshader-noop-fix.1.jar')]
for source,target,out in inputs:
 with zipfile.ZipFile(source) as z:data={n:z.read(n) for n in z.namelist()}
 old=dict(data);raw=r/('input'+str(len(data))+'.class');patched=raw.with_suffix('.patched.class');raw.write_bytes(data[target]);subprocess.run(['java',*flags,'-cp',str(r/'tools'),'Patch',str(raw),str(patched)],check=True);data[target]=patched.read_bytes()
 if 'quietly' in source:
  for p in (r/'classes').rglob('*.class'):data[str(p.relative_to(r/'classes'))]=p.read_bytes()
 changed=[n for n,b in old.items() if data[n]!=b]
 assert set(changed)==({target,'cn/kafei/interact/R.class'} if 'quietly' in source else {target}),changed
 with zipfile.ZipFile(r/out,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in data.items():z.writestr(n,b)
 with zipfile.ZipFile(r/out) as z:assert z.testzip() is None
 subprocess.run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/tools','Verify',str(r/out)],check=True)
 print(out,'entries changed:',changed)
