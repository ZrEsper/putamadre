from pathlib import Path
import subprocess,zipfile
r=Path('work/client-opt/budget')
subprocess.run(['java','com.sun.tools.javac.Main','-d',str(r/'classes'),*[str(p) for folder in ['src','stubs'] for p in (r/folder).rglob('*.java')]],check=True)
subprocess.run(['java','com.sun.tools.javac.Main','-cp',str(r/'classes'),'-d',str(r/'tests'),str(r/'TestBudget.java')],check=True)
subprocess.run(['java','-cp',str(r/'tests')+':'+str(r/'classes'),'TestBudget'],check=True)
meta='''modLoader="javafml"
loaderVersion="[4,)"
license="MIT"
[[mods]]
modId="zomboid_cosmetic_budget"
version="1.0.0"
displayName="Zomboid Cosmetic Debris Budget"
description="Bounded server-side lifetime and count for mobdismemberment:gib cosmetic debris."
[[dependencies.zomboid_cosmetic_budget]]
modId="neoforge"
type="required"
versionRange="[21.1,)"
ordering="NONE"
side="BOTH"
[[dependencies.zomboid_cosmetic_budget]]
modId="minecraft"
type="required"
versionRange="[1.21.1,1.21.2)"
ordering="NONE"
side="BOTH"
'''
jar=r.parent/'zomboid-cosmetic-budget-1.0.0-neoforge-1.21.1.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('META-INF/neoforge.mods.toml',meta)
 for p in (r/'classes/dev/zomboid/budget').glob('*.class'):z.write(p,str(p.relative_to(r/'classes')))
with zipfile.ZipFile(jar) as z:assert z.testzip() is None;assert all(not n.startswith('net/') for n in z.namelist())
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED']
subprocess.run(['java',*flags,'-cp','work/tools','Verify',str(jar)],check=True)
