import dev.zomboid.budget.CosmeticQueue;import java.util.*;
public class TestBudget {
 static class Gib{boolean removed;}static int checks;static void check(boolean b){checks++;if(!b)throw new AssertionError(checks);}
 public static void main(String[]args){List<Gib> all=new ArrayList<>();CosmeticQueue<Gib> q=new CosmeticQueue<>();for(int i=0;i<6317;i++){Gib g=new Gib();all.add(g);q.add(g,0,256,1200,x->x.removed,x->x.removed=true);check(q.size()<=256);}check(all.stream().filter(x->!x.removed).count()==256);q.prune(1199,1200,x->x.removed,x->x.removed=true);check(q.size()==256);q.prune(1200,1200,x->x.removed,x->x.removed=true);check(q.size()==0);check(all.stream().allMatch(x->x.removed));System.out.println("Budget: "+checks+" checks passed; 6317 fragments capped at 256, expiration boundary and complete cleanup.");}
}
