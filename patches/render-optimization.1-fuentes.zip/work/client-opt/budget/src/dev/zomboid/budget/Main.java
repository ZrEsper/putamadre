package dev.zomboid.budget;
import net.neoforged.fml.common.Mod;
@Mod("zomboid_cosmetic_budget") public final class Main {public Main(){}}
