package dev.zomboid.budget;
import java.lang.ref.WeakReference;import java.util.*;import java.util.function.*;
public final class CosmeticQueue<T>{
 private record Entry<T>(WeakReference<T> value,long born){}
 private final ArrayDeque<Entry<T>> entries=new ArrayDeque<>();
 public void add(T value,long now,int cap,long lifetime,Predicate<T> removed,Consumer<T> discard){prune(now,lifetime,removed,discard);entries.addLast(new Entry<>(new WeakReference<>(value),now));while(entries.size()>cap){T old=entries.removeFirst().value.get();if(old!=null&&!removed.test(old))discard.accept(old);}}
 public void prune(long now,long lifetime,Predicate<T> removed,Consumer<T> discard){for(Iterator<Entry<T>> i=entries.iterator();i.hasNext();){Entry<T> e=i.next();T value=e.value.get();if(value==null||removed.test(value)){i.remove();continue;}if(now-e.born>=lifetime){i.remove();discard.accept(value);}}}
 public int size(){return entries.size();}
}
