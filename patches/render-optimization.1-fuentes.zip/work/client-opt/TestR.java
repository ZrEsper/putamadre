import cn.kafei.interact.R;import java.util.concurrent.*;
public class TestR {
 public static class Parent{public int field=4;public int add(int x){return x+1;}public String overloaded(String v){return "s";}public String overloaded(Integer v){return "i";}public static int twice(int x){return x*2;}}
 public static class Child extends Parent{public Child(){}public Child(int x){field=x;}public String nullable(Object x){return x==null?"null":"object";}public String nullable(String x){return x==null?"null":"string";}}
 static int checks;static void check(boolean b){checks++;if(!b)throw new AssertionError(checks);}
 public static void main(String[]args)throws Exception{
  Child c=new Child();for(int i=0;i<10000;i++){
   check(R.is(Parent.class.getName(),c));check(!R.is("optional.mod.DoesNotExist",c));check(!R.is(Parent.class.getName(),null));check((int)R.call(c,"add",i)==i+1);check((int)R.call(Parent.class,"twice",i)==i*2);check(R.call(c,"overloaded","x").equals("s"));check(R.call(c,"overloaded",Integer.valueOf(3)).equals("i"));check(R.call(c,"nullable",new Object[]{null}).equals("null"));check((int)R.field(c,"field")==4);
  }
  check(((Child)R.make(Child.class.getName(),7)).field==7);c.field=99;check((int)R.field(c,"field")==99);
  ExecutorService e=Executors.newFixedThreadPool(4);try{for(Future<Boolean> f:e.invokeAll(java.util.Collections.<Callable<Boolean>>nCopies(4,()->{for(int i=0;i<10000;i++)if(!R.is(Parent.class.getName(),c)||(int)R.call(c,"add",i)!=i+1)return false;return true;})))check(f.get());}finally{e.shutdown();}
  System.out.println("Reflection cache: "+checks+" checks passed; inherited methods/fields, overloads, nulls, static dispatch, constructors, optional misses, concurrency.");
 }
}
