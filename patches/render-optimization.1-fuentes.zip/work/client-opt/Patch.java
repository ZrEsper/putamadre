import java.nio.file.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public class Patch {
 public static void main(String[]args)throws Exception{
 ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(c,0);int edits=0;
 for(MethodNode m:c.methods){
 if(c.name.equals("cn/kafei/interact/Interaction")&&m.name.equals("is")&&m.desc.equals("(Ljava/lang/String;Ljava/lang/Object;)Z")){
 m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));m.instructions.add(new VarInsnNode(Opcodes.ALOAD,1));m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"cn/kafei/interact/R","is",m.desc,false));m.instructions.add(new InsnNode(Opcodes.IRETURN));edits++;
 }
 if(c.name.endsWith("PostShadersHelper$ComposedPostChain")&&m.name.equals("with")&&m.desc.startsWith("(Lnet/minecraft/resources/ResourceLocation;")){
 InsnList p=new InsnList();LabelNode proceed=new LabelNode();p.add(new VarInsnNode(Opcodes.ALOAD,1));p.add(new JumpInsnNode(Opcodes.IFNONNULL,proceed));p.add(new VarInsnNode(Opcodes.ALOAD,0));p.add(new FieldInsnNode(Opcodes.GETFIELD,c.name,"chainsPerGroup","Ljava/util/Map;"));p.add(new VarInsnNode(Opcodes.ALOAD,2));p.add(new MethodInsnNode(Opcodes.INVOKEINTERFACE,"java/util/Map","containsKey","(Ljava/lang/Object;)Z",true));p.add(new JumpInsnNode(Opcodes.IFNE,proceed));p.add(new VarInsnNode(Opcodes.ALOAD,0));p.add(new InsnNode(Opcodes.ARETURN));p.add(proceed);p.add(new FrameNode(Opcodes.F_SAME,0,null,0,null));m.instructions.insert(p);edits++;
 }
 }
 if(edits!=1)throw new IllegalStateException("Unexpected patch count: "+edits);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.write(Path.of(args[1]),w.toByteArray());System.out.println(c.name+" patched");
 }
}
