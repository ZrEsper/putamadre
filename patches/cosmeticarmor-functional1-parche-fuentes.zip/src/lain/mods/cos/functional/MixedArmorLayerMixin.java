package lain.mods.cos.functional;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(targets="net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer",remap=false)
public abstract class MixedArmorLayerMixin {
    @Inject(method="renderArmorPiece(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/EquipmentSlot;ILnet/minecraft/client/model/HumanoidModel;)V",at=@At("RETURN"),require=1,remap=false)
    private void functional$overlay(com.mojang.blaze3d.vertex.PoseStack pose,net.minecraft.client.renderer.MultiBufferSource buffer,net.minecraft.world.entity.LivingEntity entity,net.minecraft.world.entity.EquipmentSlot slot,int light,net.minecraft.client.model.HumanoidModel model,CallbackInfo callback) {
        if(lain.mods.cos.impl.client.PlayerRenderHandler.Disabled || !OverlayChoice.enabled(entity) || !(entity instanceof net.minecraft.world.entity.player.Player player))return;
        int index=FunctionalArmor.index(slot);if(index<0)return;
        var inventory=lain.mods.cos.impl.ModObjects.invMan.getCosArmorInventoryClient(player.getUUID());
        if(inventory.isSkinArmor(index))return;
        var cosmetic=inventory.getStackInSlot(index);if(cosmetic.isEmpty())return;
        var original=player.getItemBySlot(slot);
        if(net.minecraft.world.item.ItemStack.isSameItemSameComponents(original,cosmetic))return;
        pose.pushPose();
        try {
            // Slightly separate the second layer to avoid fighting at identical surfaces.
            pose.scale(1.006f,1.006f,1.006f);
            player.getInventory().armor.set(index,cosmetic);
            ((zzik2.cosmeticarmorreworkedforked.mixin.HumanoidArmorLayerInvoker)(Object)this).invokeRenderArmorPiece(pose,buffer,entity,slot,light,model);
        } finally {
            player.getInventory().armor.set(index,original);
            pose.popPose();
        }
    }
}
