package lain.mods.cos.functional;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.damagesource.DamageSource;
@Pseudo
@Mixin(targets="ichttt.mods.firstaid.common.util.ArmorUtils",remap=false)
public abstract class FirstAidWearMixin {
    @Unique private static final ThreadLocal<FirstAidScope> functional$damageSlot=new ThreadLocal<>();
    @Inject(method="applyArmor(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/damagesource/DamageSource;FLnet/minecraft/world/entity/EquipmentSlot;)F",at=@At("HEAD"),require=0,remap=false)
    private static void functional$begin(Player player,ItemStack normal,DamageSource source,float amount,EquipmentSlot slot,CallbackInfoReturnable<Float> callback) {
        functional$damageSlot.set(new FirstAidScope(slot,amount));
    }
    @Inject(method="getGlobalRestAttribute(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/Holder;)D",at=@At("RETURN"),cancellable=true,require=0,remap=false)
    private static void functional$localizedArmor(Player player,net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> attribute,CallbackInfoReturnable<Double> callback) {
        var scope=functional$damageSlot.get();
        if(scope==null||!(player instanceof net.minecraft.server.level.ServerPlayer))return;
        double local=FunctionalArmor.slotAttribute(player,scope.slot(),attribute),scaled;
        if(attribute.equals(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR))scaled=ichttt.mods.firstaid.common.util.ArmorUtils.applyArmorModifier(scope.slot(),local);
        else if(attribute.equals(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS))scaled=ichttt.mods.firstaid.common.util.ArmorUtils.applyToughnessModifier(scope.slot(),local);
        else return;
        callback.setReturnValue(callback.getReturnValueD()-FunctionalArmor.cosmeticContribution(player,attribute)+scaled);
    }
    @Inject(method="applyArmor(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/damagesource/DamageSource;FLnet/minecraft/world/entity/EquipmentSlot;)F",at=@At("RETURN"),require=0,remap=false)
    private static void functional$wear(Player player,ItemStack normal,DamageSource source,float amount,EquipmentSlot slot,CallbackInfoReturnable<Float> callback) {
        var scope=functional$damageSlot.get();functional$damageSlot.remove();
        if(scope!=null)FunctionalArmor.firstAidDamage(player,source,scope.damage(),slot);
    }
}
