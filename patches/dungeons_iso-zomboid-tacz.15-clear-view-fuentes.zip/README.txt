Dungeons ISO · Zomboid TaCZ 15 · Clear view

INSTALACION
Sustituir Dungeons ISO 14 fast-zoom por este JAR. No conservar dos versiones. La modificacion es visual y funciona en el cliente. Conserva zoom rapido de rueda, integracion TaCZ y los recursos y funciones originales.

DESPEJE
Oculta visualmente todo bloque no vacio dentro del corredor continuo entre la camara real y una zona de 6 bloques alrededor del jugador. No filtra por material: hojas, troncos, terracota, paredes, techos, enredaderas, cristales y modelos personalizados pueden ocultarse. Los bloques con renderer especial tambien pasan por el filtro al renderizarse. La deteccion por linea de vista prevalece sobre excepciones de puertas/dispositivos y sobre zonas que el escaner de habitaciones antes protegia.

Se conserva el suelo por debajo del limite del escaner del jugador. El escenario exterior al corredor permanece visible. Los bloques siguen existiendo, con su colision e inventario; no se cambian datos del mundo ni se afectan otros jugadores. La camara normal desactiva el despeje. El renderizado de siluetas fantasma se desactiva para que los obstaculos ocultos no reaparezcan transparentes sobre el jugador.

EFICIENCIA
Reutiliza captura de chunks cargados, trabajador asincrono, preemption y presupuestos temporales, hashes de contenido/secciones y cola incremental de reconstruccion existentes. No fuerza chunks ni escanea todo el mapa. No aplica limites por tipo/tamano de estructura ni decide conservar obstaculos porque algunas muestras del jugador ya se vean. El calculo geometrico de prueba recorrio 9584 celdas a distancia de camara habitual. Esto no es una medida de FPS ni de rendimiento real en Minecraft.

PRUEBAS Y LIMITES
937722 comprobaciones geometricas simuladas: cobertura continua en siete posiciones de camara, suelo conservado, zona del jugador, escenario lejano y adaptacion al zoom. Bytecode de 125 clases/863 metodos revisado. CRC, mixin config y recursos originales verificados. No ejecutado en Minecraft: faltan validacion visual y aplicacion real de mixins, especialmente con shaders o renderizadores especiales de terceros. La actualizacion de mallas sigue la cola nativa y puede tardar algunos fotogramas al mover la camara.

FUENTES
PatchClear.java aplica ASM a cuatro clases originales y genera ClearBlockEntityMixin. src/ contiene ClearVolume y ClearSight. stubs/ solo permite compilar/verificar aqui sin Minecraft; NUNCA se incluye en el JAR. Para desarrollar con el SDK real, aplicar primero las visibilidades publicas del parche a SightlineScanner.tickBudget/buildSections/contentHash. Compilar las dos clases helper con el SDK mapeado 1.21.1 y los accesos ampliados. PatchClear acepta: JAR original14, JAR salida15, directorio classes. Requiere Java21 y exports JDK asm/asm.tree. ClearVolumeTest prueba la geometria sin juego.
