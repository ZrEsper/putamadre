import pathlib,json
P=pathlib.Path('work/moss6/data/mosslorn/function')
def write(n,s):(P/(n+'.mcfunction')).write_text(s+'\n')
write('loot/validar_posicion','''scoreboard players set #contenedor ml_tmp 0
$execute in $(dim) positioned $(x) $(y) $(z) if loaded ~ ~ ~ if data block ~ ~ ~ Items run scoreboard players set #contenedor ml_tmp 1
$execute in $(dim) positioned $(x) $(y) $(z) if loaded ~ ~ ~ if data block ~ ~ ~ LootTable run scoreboard players set #contenedor ml_tmp 1
execute if score #contenedor ml_tmp matches 1 run function mosslorn:loot/guardar with storage mosslorn:runtime entrada
execute if score #contenedor ml_tmp matches 1 run tellraw @s {"text":"Cofre registrado. Se conserva su contenido actual.","color":"green"}
execute unless score #contenedor ml_tmp matches 1 run tellraw @s {"text":"No hay un contenedor compatible cargado en esas coordenadas.","color":"red"}''')
write('loot/comprobar','''execute if data block ~ ~ ~ Items[0] run scoreboard players add #ocupados ml_tmp 1
execute if data block ~ ~ ~ Items[0] run function mosslorn:loot/marcar with storage mosslorn:runtime work
execute unless data block ~ ~ ~ Items unless data block ~ ~ ~ LootTable run scoreboard players add #ausentes ml_tmp 1
execute unless data block ~ ~ ~ Items unless data block ~ ~ ~ LootTable run function mosslorn:loot/marcar with storage mosslorn:runtime work
execute if data block ~ ~ ~ Items unless data block ~ ~ ~ Items[0] run function mosslorn:loot/reponer with storage mosslorn:runtime work
execute unless data block ~ ~ ~ Items if data block ~ ~ ~ LootTable run function mosslorn:loot/reponer with storage mosslorn:runtime work''')
p=P/'loot/scan/iniciar.mcfunction';s=p.read_text().replace('data modify storage mosslorn:runtime escaneo set value {fase:0}','data modify storage mosslorn:runtime escaneo set value {fase:0,dim:"minecraft:overworld"}\ndata modify storage mosslorn:runtime escaneo.dim set from entity @s Dimension');p.write_text(s)
p=P/'loot/scan/capturar.mcfunction';p.write_text(p.read_text().replace('data modify storage mosslorn:runtime entrada.dim set from entity @s Dimension','data modify storage mosslorn:runtime entrada.dim set from storage mosslorn:runtime escaneo.dim'))
p=P/'load.mcfunction';p.write_text(p.read_text()+'function mosslorn:loot/scan/cancelar\n')
p=pathlib.Path('work/moss6/data/mosslorn/tags/entity_type/zombies.json');d=json.loads(p.read_text());d['values'] += [{'id':'mutantszombies:'+x,'required':False} for x in ['rotten_mutant','mutant_brute','split_head_zombie','zombie_brute','spitter','crawler','blister_zombie']];p.write_text(json.dumps(d,indent=2)+'\n')
