import json,pathlib,copy,math
ROOT=pathlib.Path('work/moss6'); D=ROOT/'data/mosslorn'; F=D/'function'
def js(path,data):
 p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def fn(path,lines):
 p=F/(path+'.mcfunction');p.parent.mkdir(parents=True,exist_ok=True);p.write_text('\n'.join(lines)+'\n')
def tell(msg,color='yellow',selector='@s'):return 'tellraw '+selector+' '+json.dumps({'text':msg,'color':color},ensure_ascii=False)
# Global quantity affects unopened world chests as well as registered refill.
roots=sorted((D/'loot_table/chests').glob('*.json')); tables=[f'mosslorn:chests/{p.stem}' for p in roots]
originals={p.stem:json.loads(p.read_text()) for p in roots}
children=originals['crate_house']['pools'][2]['entries'][0]['children']
for p in roots:
 base=f'mosslorn:baseline/chests/{p.stem}';js(f'data/mosslorn/loot_table/baseline/chests/{p.name}',originals[p.stem])
 pools=[]
 for mode in range(3):
  conditions=[{'condition':'minecraft:value_check','value':{'type':'minecraft:score','target':{'type':'minecraft:fixed','name':'#cantidad'},'score':'ml_config'},'range':{'min':mode,'max':mode}}]
  if mode==0:conditions.append({'condition':'minecraft:random_chance','chance':.5})
  pools.append({'rolls':2 if mode==2 else 1,'entries':[{'type':'minecraft:loot_table','value':base}],'conditions':conditions})
 js(str(p.relative_to(ROOT)),{'type':'minecraft:chest','pools':pools})
for key,suffix in [('nuclear','central_nuclear'),('piramide','piramide'),('altos','edificios_altos')]:
 conds=[copy.deepcopy(e['conditions'][0]) for e in children if e.get('value')==f'mosslorn:danger/{suffix}']
 # The checks operate on the query player's current position.
 js(f'data/mosslorn/predicate/zona/{key}.json',conds[0] if len(conds)==1 else {'condition':'minecraft:any_of','terms':conds})
js('data/minecraft/tags/function/load.json',{'values':['mosslorn:load']});js('data/minecraft/tags/function/tick.json',{'values':['mosslorn:tick']})
# Count known zombie IDs only if their optional mods are installed.
zombies=['minecraft:zombie','minecraft:husk','minecraft:drowned','minecraft:zombie_villager']
# entity IDs come from the original Mutants mod's registries (added below after inspection).
js('data/mosslorn/tags/entity_type/zombies.json',{'values':zombies})
fn('load',['scoreboard objectives add ml_config dummy','scoreboard objectives add ml_tmp dummy','scoreboard objectives add moss_info trigger',
'execute unless data storage mosslorn:registro cofres run data modify storage mosslorn:registro cofres set value []',
'execute unless score #cantidad ml_config matches 0..2 run scoreboard players set #cantidad ml_config 1',
'execute unless score #epoca ml_config matches 0.. run scoreboard players set #epoca ml_config 0',
'execute unless score #auto ml_config matches 0..1728000 run scoreboard players set #auto ml_config 0',
'scoreboard players set #reloj ml_tmp 0','scoreboard players set #scan ml_tmp 0','scoreboard players set #1200 ml_tmp 1200','scoreboard players set #16 ml_tmp 16',
'data modify storage mosslorn:runtime cola set value []','data modify storage mosslorn:runtime activo set value 0b',
*[f'execute unless data storage mosslorn:zonas {z} run data modify storage mosslorn:zonas {z} set value {{min:-1,max:-1,probabilidad:-1,dificultad:-1}}' for z in ['general','nuclear','piramide','altos']],tell('Mosslorn v6: /function mosslorn:ayuda | consulta pública: /trigger moss_info','green','@a')])
fn('tick',['scoreboard players add #reloj ml_tmp 1','scoreboard players add #auto_timer ml_tmp 1',
'execute if score #auto ml_config matches 1.. if score #auto_timer ml_tmp >= #auto ml_config run function mosslorn:loot/reiniciar',
'execute if score #reloj ml_tmp matches 10.. run function mosslorn:segundo',
*[f'execute in minecraft:{dim} as @e[type=minecraft:marker,tag=ml_scan_anchor,limit=1] at @s run function mosslorn:loot/scan/paso' for dim in ['overworld','the_nether','the_end']]])
fn('segundo',['scoreboard players set #reloj ml_tmp 0','scoreboard players enable @a moss_info','execute as @a[scores={moss_info=1..}] at @s run function mosslorn:zona/info','scoreboard players set @a[scores={moss_info=1..}] moss_info 0',
'execute if data storage mosslorn:runtime {activo:1b} run function mosslorn:loot/procesar'])
for name,score in [('escaso',0),('normal',1),('abundante',2)]:fn('loot/cantidad/'+name,[f'scoreboard players set #cantidad ml_config {score}',tell(f'Cantidad de loot: {name}. Afecta generaciones nuevas; no borra contenido existente.','green')])
fn('loot/automatico',['$scoreboard players set #minutos ml_tmp $(minutos)','execute if score #minutos ml_tmp matches ..0 run scoreboard players set #minutos ml_tmp 0','execute if score #minutos ml_tmp matches 1441.. run scoreboard players set #minutos ml_tmp 1440',
'scoreboard players operation #auto ml_config = #minutos ml_tmp','scoreboard players operation #auto ml_config *= #1200 ml_tmp','scoreboard players set #auto_timer ml_tmp 0',tell('Reposición automática configurada. 0 minutos la desactiva; máximo 1440.','green')])
fn('loot/reiniciar',['scoreboard players add #epoca ml_config 1','scoreboard players set #auto_timer ml_tmp 0','data modify storage mosslorn:runtime cola set from storage mosslorn:registro cofres','data modify storage mosslorn:runtime activo set value 1b','function mosslorn:loot/contadores',tell('Reposición solicitada: se recorren los cofres registrados. Los ocupados se respetan; los descargados quedan pendientes.','green')])
fn('loot/contadores',[f'scoreboard players set #{s} ml_tmp 0' for s in ['repuestos','ocupados','descargados','ausentes']])
fn('loot/procesar',['execute unless data storage mosslorn:runtime cola[0] run function mosslorn:loot/nueva_vuelta','execute if data storage mosslorn:runtime cola[0] run function mosslorn:loot/siguiente'])
fn('loot/nueva_vuelta',['data modify storage mosslorn:runtime cola set from storage mosslorn:registro cofres','function mosslorn:loot/contadores'])
fn('loot/siguiente',['data modify storage mosslorn:runtime work set from storage mosslorn:runtime cola[0]','data remove storage mosslorn:runtime cola[0]','execute store result storage mosslorn:runtime work.epoca int 1 run scoreboard players get #epoca ml_config','execute store result score #prev ml_tmp run data get storage mosslorn:runtime work.ultima',
'execute if score #prev ml_tmp < #epoca ml_config run function mosslorn:loot/visitar with storage mosslorn:runtime work'])
fn('loot/visitar',['$execute in $(dim) positioned $(x) $(y) $(z) if loaded ~ ~ ~ run function mosslorn:loot/comprobar with storage mosslorn:runtime work',
'$execute in $(dim) positioned $(x) $(y) $(z) unless loaded ~ ~ ~ run scoreboard players add #descargados ml_tmp 1'])
fn('loot/comprobar',['execute if data block ~ ~ ~ Items[0] run scoreboard players add #ocupados ml_tmp 1',
'execute if data block ~ ~ ~ Items[0] run function mosslorn:loot/marcar with storage mosslorn:runtime work',
'execute unless data block ~ ~ ~ Items run scoreboard players add #ausentes ml_tmp 1',
'execute unless data block ~ ~ ~ Items run function mosslorn:loot/marcar with storage mosslorn:runtime work',
'execute if data block ~ ~ ~ Items unless data block ~ ~ ~ Items[0] run function mosslorn:loot/reponer with storage mosslorn:runtime work'])
fn('loot/reponer',['$data merge block ~ ~ ~ {LootTable:"$(tabla)"}','data remove block ~ ~ ~ LootTableSeed','scoreboard players add #repuestos ml_tmp 1','function mosslorn:loot/marcar with storage mosslorn:runtime work'])
fn('loot/marcar',['$data modify storage mosslorn:registro cofres[{dim:"$(dim)",x:$(x),y:$(y),z:$(z)}].ultima set value $(epoca)'])
# Explicit registration: validates the requested table, container and integer coordinates.
fn('loot/registrar',['data modify storage mosslorn:runtime entrada set value {dim:"minecraft:overworld",ultima:0}','data modify storage mosslorn:runtime entrada.dim set from entity @s Dimension',
'$data modify storage mosslorn:runtime entrada.x set value $(x)','$data modify storage mosslorn:runtime entrada.y set value $(y)','$data modify storage mosslorn:runtime entrada.z set value $(z)','$data modify storage mosslorn:runtime entrada.tabla set value "$(tabla)"',
'function mosslorn:loot/validar with storage mosslorn:runtime entrada'])
fn('loot/validar',['scoreboard players set #valido ml_tmp 0',*[f'execute if data storage mosslorn:runtime entrada {{tabla:"{t}"}} run scoreboard players set #valido ml_tmp 1' for t in tables],
'execute if score #valido ml_tmp matches 1 run function mosslorn:loot/validar_posicion with storage mosslorn:runtime entrada',
'execute unless score #valido ml_tmp matches 1 run '+tell('Tabla desconocida. Usa una tabla mosslorn:chests/* del pack.','red')])
fn('loot/validar_posicion',['$execute in $(dim) positioned $(x) $(y) $(z) if loaded ~ ~ ~ if data block ~ ~ ~ Items run function mosslorn:loot/guardar with storage mosslorn:runtime entrada',
'$execute in $(dim) positioned $(x) $(y) $(z) unless loaded ~ ~ ~ run '+tell('El chunk del cofre debe estar cargado para registrarlo.','red')])
fn('loot/guardar',['$data remove storage mosslorn:registro cofres[{dim:"$(dim)",x:$(x),y:$(y),z:$(z)}]',
'execute store result storage mosslorn:runtime entrada.ultima int 1 run scoreboard players get #epoca ml_config','data modify storage mosslorn:registro cofres append from storage mosslorn:runtime entrada'])
fn('loot/desregistrar',['data modify storage mosslorn:runtime entrada set value {dim:"minecraft:overworld"}','data modify storage mosslorn:runtime entrada.dim set from entity @s Dimension',
'$data modify storage mosslorn:runtime entrada.x set value $(x)','$data modify storage mosslorn:runtime entrada.y set value $(y)','$data modify storage mosslorn:runtime entrada.z set value $(z)',
'function mosslorn:loot/borrar_entrada with storage mosslorn:runtime entrada'])
fn('loot/borrar_entrada',['$data remove storage mosslorn:registro cofres[{dim:"$(dim)",x:$(x),y:$(y),z:$(z)}]'])
fn('loot/estado',['execute store result score #total ml_tmp run data get storage mosslorn:registro cofres','tellraw @s '+json.dumps([{'text':'Cofres registrados: ','color':'green'},{'score':{'name':'#total','objective':'ml_tmp'}},{'text':' | cantidad (0 escaso / 1 normal / 2 abundante): '},{'score':{'name':'#cantidad','objective':'ml_config'}},{'text':' | Última vuelta: repuestos '},{'score':{'name':'#repuestos','objective':'ml_tmp'}},{'text':', ocupados '},{'score':{'name':'#ocupados','objective':'ml_tmp'}},{'text':', descargados '},{'score':{'name':'#descargados','objective':'ml_tmp'}},{'text':', ausentes '},{'score':{'name':'#ausentes','objective':'ml_tmp'}}])])
# Manual discovery runs at most 64 block checks per tick, never forces chunks.
fn('loot/escanear',['execute if score #scan ml_tmp matches 1 run '+tell('Ya hay un escaneo activo.','red'),
'execute unless score #scan ml_tmp matches 1 at @s run function mosslorn:loot/scan/iniciar'])
fn('loot/scan/iniciar',['summon minecraft:marker ~ ~ ~ {Tags:["ml_scan_anchor"]}','scoreboard players set #scan ml_tmp 1','data modify storage mosslorn:runtime escaneo set value {fase:0}',tell('Escaneando 17×17×17 bloques alrededor de esta posición. Registra cofres sin abrir con tablas del pack.','green')])
fn('loot/scan/paso',['function mosslorn:loot/scan/ejecutar with storage mosslorn:runtime escaneo','execute store result score #fase ml_tmp run data get storage mosslorn:runtime escaneo.fase','scoreboard players add #fase ml_tmp 1','execute store result storage mosslorn:runtime escaneo.fase int 1 run scoreboard players get #fase ml_tmp',
'execute if score #fase ml_tmp matches 77.. run function mosslorn:loot/scan/terminar'])
fn('loot/scan/ejecutar',['$function mosslorn:loot/scan/batch_$(fase)'])
fn('loot/scan/terminar',['scoreboard players set #scan ml_tmp 0',tell('Escaneo de cofres terminado. /function mosslorn:loot/estado','green','@a'),'kill @s'])
fn('loot/scan/cancelar',['scoreboard players set #scan ml_tmp 0',*[f'execute in minecraft:{d} run kill @e[type=minecraft:marker,tag=ml_scan_anchor]' for d in ['overworld','the_nether','the_end']]])
checks=[f'execute positioned ~{x} ~{y} ~{z} if loaded ~ ~ ~ if data block ~ ~ ~ LootTable run function mosslorn:loot/scan/detectar' for x in range(-8,9) for y in range(-8,9) for z in range(-8,9)]
for batch in range(math.ceil(len(checks)/64)):fn(f'loot/scan/batch_{batch}',checks[batch*64:(batch+1)*64])
fn('loot/scan/detectar',[f'execute if data block ~ ~ ~ {{LootTable:"{t}"}} run function mosslorn:loot/scan/capturar' for t in tables])
fn('loot/scan/capturar',['data modify storage mosslorn:runtime entrada set value {dim:"minecraft:overworld",ultima:0}','data modify storage mosslorn:runtime entrada.dim set from entity @s Dimension',
'execute store result storage mosslorn:runtime entrada.x int 1 run data get block ~ ~ ~ x','execute store result storage mosslorn:runtime entrada.y int 1 run data get block ~ ~ ~ y','execute store result storage mosslorn:runtime entrada.z int 1 run data get block ~ ~ ~ z','data modify storage mosslorn:runtime entrada.tabla set from block ~ ~ ~ LootTable','function mosslorn:loot/guardar with storage mosslorn:runtime entrada'])
# Public query uses the exact loot zone predicates; spawning rules remain unknown until configured.
fn('zona/info',['execute at @s run function mosslorn:zona/consulta'])
fn('zona/consulta',['scoreboard players set #zona ml_tmp 0','execute if predicate mosslorn:zona/altos run scoreboard players set #zona ml_tmp 3','execute if predicate mosslorn:zona/piramide run scoreboard players set #zona ml_tmp 2','execute if predicate mosslorn:zona/nuclear run scoreboard players set #zona ml_tmp 1',
*[f'execute if score #zona ml_tmp matches {i} run function mosslorn:zona/{z}' for i,z in enumerate(['general','nuclear','piramide','altos'])],
'execute store result score #x ml_tmp run data get entity @s Pos[0] 1','execute store result score #z ml_tmp run data get entity @s Pos[2] 1','execute if score #x ml_tmp matches ..-1 run scoreboard players remove #x ml_tmp 15','execute if score #z ml_tmp matches ..-1 run scoreboard players remove #z ml_tmp 15',
'scoreboard players operation #x ml_tmp /= #16 ml_tmp','scoreboard players operation #z ml_tmp /= #16 ml_tmp','scoreboard players operation #cx ml_tmp = #x ml_tmp','scoreboard players operation #cz ml_tmp = #z ml_tmp','scoreboard players operation #x ml_tmp *= #16 ml_tmp','scoreboard players operation #z ml_tmp *= #16 ml_tmp',
'execute store result storage mosslorn:runtime chunk.x int 1 run scoreboard players get #x ml_tmp','execute store result storage mosslorn:runtime chunk.z int 1 run scoreboard players get #z ml_tmp','scoreboard players set #zombies ml_tmp 0','function mosslorn:zona/contar with storage mosslorn:runtime chunk',
 'tellraw @s '+json.dumps([{'text':'Chunk ','color':'gray'},{'score':{'name':'#cx','objective':'ml_tmp'}},{'text':', '},{'score':{'name':'#cz','objective':'ml_tmp'}},{'text':' | Zombies presentes (cargados): '},{'score':{'name':'#zombies','objective':'ml_tmp'}}]),
'function mosslorn:zona/mostrar_reglas'])
fn('zona/contar',['$execute positioned $(x) -64 $(z) as @e[type=#mosslorn:zombies,dx=15,dy=383,dz=15] run scoreboard players add #zombies ml_tmp 1'])
for z,title,bonus in [('general','General',0),('nuclear','Central nuclear',65),('piramide','Pirámide',40),('altos','Edificios altos',35)]:
 fn('zona/'+z,[tell(f'Zona: {title} | Bonus de loot de peligro: {bonus} %.','gold'),'data modify storage mosslorn:runtime reglas set from storage mosslorn:zonas '+z])
fn('zona/mostrar_reglas',['execute store result score #min ml_tmp run data get storage mosslorn:runtime reglas.min','execute store result score #max ml_tmp run data get storage mosslorn:runtime reglas.max','execute store result score #prob ml_tmp run data get storage mosslorn:runtime reglas.probabilidad','execute store result score #dificultad ml_tmp run data get storage mosslorn:runtime reglas.dificultad',
'execute if score #min ml_tmp matches -1 run '+tell('Spawn por chunk, probabilidad y dificultad: sin configurar. El ZIP original no contiene reglas de zombies.','gray'),
'execute if score #min ml_tmp matches 0.. run tellraw @s '+json.dumps([{'text':'Regla informativa: ','color':'aqua'},{'score':{'name':'#min','objective':'ml_tmp'}},{'text':'–'},{'score':{'name':'#max','objective':'ml_tmp'}},{'text':' zombies/chunk | probabilidad: '},{'score':{'name':'#prob','objective':'ml_tmp'}},{'text':' % | dificultad: '},{'score':{'name':'#dificultad','objective':'ml_tmp'}}]),
tell('Los zombies presentes son un conteo, no una probabilidad. Las reglas informativas no cambian el spawn del mod.','gray')])
fn('zona/configurar',['$data modify storage mosslorn:runtime config set value {zona:"$(zona)",min:$(min),max:$(max),probabilidad:$(probabilidad),dificultad:$(dificultad)}',
'scoreboard players set #valido ml_tmp 0',*[f'execute if data storage mosslorn:runtime config {{zona:"{z}"}} run scoreboard players set #valido ml_tmp 1' for z in ['general','nuclear','piramide','altos']],
'execute store result score #min ml_tmp run data get storage mosslorn:runtime config.min','execute store result score #max ml_tmp run data get storage mosslorn:runtime config.max','execute store result score #prob ml_tmp run data get storage mosslorn:runtime config.probabilidad','execute store result score #dif ml_tmp run data get storage mosslorn:runtime config.dificultad',
'execute unless score #min ml_tmp matches 0..10000 run scoreboard players set #valido ml_tmp 0','execute unless score #max ml_tmp matches 0..10000 run scoreboard players set #valido ml_tmp 0','execute if score #max ml_tmp < #min ml_tmp run scoreboard players set #valido ml_tmp 0','execute unless score #prob ml_tmp matches 0..100 run scoreboard players set #valido ml_tmp 0','execute unless score #dif ml_tmp matches 0..10 run scoreboard players set #valido ml_tmp 0',
'execute if score #valido ml_tmp matches 1 run function mosslorn:zona/guardar with storage mosslorn:runtime config','execute unless score #valido ml_tmp matches 1 run '+tell('Datos inválidos. Zona general/nuclear/piramide/altos; min ≤ max; probabilidad 0–100; dificultad 0–10.','red')])
fn('zona/guardar',['$data modify storage mosslorn:zonas $(zona) set value {min:$(min),max:$(max),probabilidad:$(probabilidad),dificultad:$(dificultad)}',tell('Regla informativa guardada. Copia aquí los valores del mod de spawn; esto no modifica su comportamiento.','green')])
fn('ayuda',[tell('Mosslorn v6 — administración e información','gold'),tell('/trigger moss_info — zona, bonus de loot, zombies presentes y reglas configuradas','aqua'),tell('/function mosslorn:loot/escanear — registra cofres sin abrir cerca (17×17×17)'),tell('/function mosslorn:loot/registrar {x:0,y:64,z:0,tabla:"mosslorn:chests/crate_house"}'),tell('/function mosslorn:loot/reiniciar — repone vacíos; respeta los ocupados'),tell('/function mosslorn:loot/cantidad/escaso | normal | abundante'),tell('/function mosslorn:loot/automatico {minutos:30} — 0 desactiva'),tell('/function mosslorn:loot/estado — registros y avance'),tell('/function mosslorn:zona/configurar {zona:"general",min:0,max:10,probabilidad:20,dificultad:3} — solo información')])
js('pack.mcmeta',{'pack':{'pack_format':48,'description':'Mosslorn v6: reposición segura, cantidad de loot e información de zonas'}})
print(f'Created {len(list(F.rglob("*.mcfunction")))} functions; {len(tables)} managed chest tables; {len(checks)} scan cells')
