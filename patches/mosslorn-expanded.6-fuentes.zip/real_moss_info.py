import pathlib,json
root=pathlib.Path('work/moss6');f=root/'data/mosslorn/function'
def fn(name,lines):(f/(name+'.mcfunction')).write_text('\n'.join(lines)+'\n')
def tell(s,color='gray'):return 'tellraw @s '+json.dumps({'text':s,'color':color},ensure_ascii=False)
rows=[list(map(int,l.split(','))) for l in pathlib.Path('work/moss-zones/zones.csv').read_text().splitlines() if l.strip()]
for name,rs in [('nuclear',rows[:1]),('piramide',rows[1:2]),('altos',rows[2:])]:
 terms=[{'condition':'minecraft:location_check','predicate':{'position':{'x':{'min':a,'max':b},'z':{'min':c,'max':d}}}} for a,b,c,d,m in rs]
 p=root/f'data/mosslorn/predicate/poblacion/{name}.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(terms[0] if len(terms)==1 else {'condition':'minecraft:any_of','terms':terms},indent=2)+'\n')
# Spawn classification is performed at the center of the queried chunk, exactly as Zones.missing does.
p=f/'zona/consulta.mcfunction';s=p.read_text().replace('function mosslorn:zona/mostrar_reglas', '''scoreboard players add #x ml_tmp 8
scoreboard players add #z ml_tmp 8
execute store result storage mosslorn:runtime chunk.x int 1 run scoreboard players get #x ml_tmp
execute store result storage mosslorn:runtime chunk.z int 1 run scoreboard players get #z ml_tmp
execute if dimension minecraft:overworld run function mosslorn:zona/poblacion with storage mosslorn:runtime chunk
execute unless dimension minecraft:overworld run tellraw @s {"text":"La población por chunks de Zomboid Hordes está limitada al Overworld.","color":"gray"}''');p.write_text(s)
fn('zona/poblacion',['scoreboard players set #poblacion ml_tmp 1',
'$execute positioned $(x) 0 $(z) if predicate mosslorn:poblacion/altos run scoreboard players set #poblacion ml_tmp 2',
'$execute positioned $(x) 0 $(z) if predicate mosslorn:poblacion/piramide run scoreboard players set #poblacion ml_tmp 2',
'$execute positioned $(x) 0 $(z) if predicate mosslorn:poblacion/nuclear run scoreboard players set #poblacion ml_tmp 3',
*[f'execute if score #poblacion ml_tmp matches {i} run function mosslorn:zona/poblacion_{i}' for i in [1,2,3]],
tell('Nuevo objetivo cada 5–10 min de juego. Solo repone lo que falta, si hay posiciones válidas.'),
tell('Selección de mutante en población: 1 % antes de comprobar el límite de 2 mutantes en 128 bloques.'),
tell('The Hordes: 99 % zombie / 1 % mutante por elección con los siete tipos instalados. Es un sistema de oleadas, no un límite por chunk.'),
tell('Fuente: los dos JAR que enviaste. Otras hordas pueden superar este objetivo; el conteo de arriba es la población actual.')])
for mult,label in [(1,'normal'),(2,'alta'),(3,'extrema')]:
 fn(f'zona/poblacion_{mult}',[tell(f'Dificultad de población: {label} (×{mult}) | Objetivo posible: {mult}–{mult*5} zombies/chunk.','red' if mult==3 else 'gold'),
 tell('Probabilidad de objetivo: '+ ' | '.join(f'{n*mult}: {prob} %' for n,prob in [(1,70),(2,18),(3,8),(4,3),(5,1)]),'aqua')])
# Remove the now-unnecessary user-supplied placeholder profiles.
for name in ['mostrar_reglas','configurar','guardar']:(f/f'zona/{name}.mcfunction').unlink()
p=f/'load.mcfunction';p.write_text('\n'.join(l for l in p.read_text().splitlines() if 'mosslorn:zonas' not in l)+'\n')
for name in ['general','nuclear','piramide','altos']:
 p=f/f'zona/{name}.mcfunction';p.write_text('\n'.join(l for l in p.read_text().splitlines() if 'mosslorn:zonas' not in l)+'\n')
p=f/'ayuda.mcfunction';p.write_text('\n'.join(l for l in p.read_text().splitlines() if 'zona/configurar' not in l).replace('reglas configuradas','reglas reales de los JAR de hordas')+'\n')
# Additional The Hordes zombie players are counted when that mod is installed.
p=root/'data/mosslorn/tags/entity_type/zombies.json';d=json.loads(p.read_text());d['values'] += [{'id':'hordes:'+x,'required':False} for x in ['zombie_player','husk_player','drowned_player']];p.write_text(json.dumps(d,indent=2)+'\n')
# Save the evidence, rather than substituting guessed settings.
p=root/'REFERENCIA-SPAWN-v6.json';p.write_text(json.dumps({'fuentes':['zomboid-hordes-1.8.3-neoforge-1.21.1-mosslorn-danger-zones.3.jar','The-Hordes-1.21.1-1.6.3f-zombies-mutants-only.1.jar'],'chunkPopulationTarget':{'values':[1,2,3,4,5],'probabilitiesPercent':[70,18,8,3,1],'chunkCenter':{'x':'chunkX*16+8','z':'chunkZ*16+8'},'multipliers':{'normal':1,'central_nuclear':3,'piramide':2,'edificios_altos':2},'rerollTicks':[6000,12000],'overworldOnly':True,'maxSpawnSuccessesPerPass':16,'positionProbeBudget':256},'mutantPopulationSelection':{'chancePercent':1,'horizontalRadiusCapBlocks':128,'maxExistingMutantsForEligibility':1},'theHordesWeightedSelection':{'zombieWeight':9900,'mutantWeights':{'crawler':18,'blister_zombie':25,'split_head_zombie':23,'rotten_mutant':18,'spitter':10,'zombie_brute':5,'mutant_brute':1},'missingEntityWeightGoesToZombie':True},'notes':['Difficulty label is derived from the population multiplier, not a separate vanilla difficulty setting.','Counts include loaded entities; probability means target selection or entity selection, not guaranteed successful spawning.']},ensure_ascii=False,indent=2)+'\n')
