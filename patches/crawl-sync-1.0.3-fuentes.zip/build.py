import zipfile,json,subprocess
from pathlib import Path
r=Path('work/crawl103');base=zipfile.ZipFile('work/gore101/zomboid-zombie-gore-1.0.2-neoforge-1.21.1-tacz-melee-reactions.jar');data={n:base.read(n) for n in base.namelist()};flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
for name in ['Rules','Gore']:
 n='dev/zomboid/gore/'+name+'.class';p=r/(name+'.class');out=r/(name+'-patched.class');p.write_bytes(data[n]);subprocess.run(['java',*flags,'-cp',str(r/'tools'),'PatchCrawl',str(p),str(out)],check=True);data[n]=out.read_bytes()
data['dev/zomboid/gore/CrawlGeometry.class']=(r/'classes/dev/zomboid/gore/CrawlGeometry.class').read_bytes();data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'version="1.0.2"',b'version="1.0.3"')
jar=r/'zomboid-zombie-gore-1.0.3-neoforge-1.21.1-crawl-hitbox-sync.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in data.items():z.writestr(n,b)
subprocess.run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/tools','Verify',str(jar)],check=True)
# Match the low, horizontal body to the updated native dimensions. All normal-pose expressions stay unchanged.
source=zipfile.ZipFile('work/tzp-fix/TZP_1.20.1_2.7-connected-zombies-fix.1.zip');pack=r/'TZP_1.20.1_2.7.zip';changed=[]
pose={
 'head.rx':'clamp(torad(head_pitch),-.2,.2)', 'head.ry':'clamp(torad(head_yaw),-pi/3,pi/3)', 'head.rz':'0','head.tx':'0','head.ty':'21+sin(age*.45)*.12','head.tz':'-2',
 'body.rx':'pi/2','body.ry':'0','body.rz':'sin(age*.45)*.025','body.tx':'0','body.ty':'21+sin(age*.45)*.12','body.tz':'0',
 'left_arm.rx':'-pi/2+sin(age*.45)*.2','right_arm.rx':'-pi/2-sin(age*.45)*.2','left_arm.ry':'0','right_arm.ry':'0',
 'left_arm.rz':'.08','right_arm.rz':'-.08','left_arm.tx':'5','right_arm.tx':'-5','left_arm.ty':'20','right_arm.ty':'20','left_arm.tz':'-1','right_arm.tz':'-1'
}
with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in source.namelist():
  b=source.read(n)
  if n.endswith('_animations.jpm'):
   obj=json.loads(b);anim=obj['animations'];anim[0]={'var.gore_loss':'zg_loss','varb.gore_crawl':'fmod(floor(var.gore_loss/16),2)>0&&fmod(floor(var.gore_loss/32),2)>0',**anim[0]}
   seen=set()
   for a in anim:
    for key in list(a):
     if key in pose:a[key]='if(varb.gore_crawl,'+pose[key]+','+a[key]+')';seen.add(key)
   assert seen==set(pose),(n,set(pose)-seen)
   # Appended after existing animations: hide only limbs whose loss bit is set.
   anim.append({'left_leg.visible':'fmod(floor(var.gore_loss/16),2)==0','right_leg.visible':'fmod(floor(var.gore_loss/32),2)==0'})
   b=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode();changed.append(n)
  if n=='ZOMBIES-LEEME.txt':b='TZP + Fresh Animations: posturas normales conservadas. Gore 1.0.3 sincroniza perdida de piernas, arrastre y hitbox. Requiere el mod de heridas 1.0.3 y EMF. Texturas de Tissou y modelos base de FreshLX.\n'.encode()
  z.writestr(n,b)
with zipfile.ZipFile(pack) as z:
 assert z.testzip() is None
 for n in source.namelist():
  if n not in changed and n!='ZOMBIES-LEEME.txt':assert z.read(n)==source.read(n)
print('Updated animations:',changed,'all textures/base geometry preserved; complete pack',pack.stat().st_size)
