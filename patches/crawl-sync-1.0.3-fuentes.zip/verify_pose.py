import math,itertools,zipfile,json
# Check the adult pose envelope using the standard humanoid part coordinates and Minecraft's model scale.
boxes={'head':(-4,-8,-4,8,8,8),'body':(-4,0,-2,8,12,4),'left_arm':(-1,-2,-2,4,12,4),'right_arm':(-3,-2,-2,4,12,4)}
checks=0
for frame in range(240):
 phase=frame*.45;step=math.sin(phase)
 for part,box in boxes.items():
  if part=='head':angles=(.2*math.sin(phase),math.sin(phase)*math.pi/3,0);pivot=(0,21+step*.12,-2)
  elif part=='body':angles=(math.pi/2,0,step*.025);pivot=(0,21+step*.12,0)
  elif part=='left_arm':angles=(-math.pi/2+step*.2,0,.08);pivot=(5,20,-1)
  else:angles=(-math.pi/2-step*.2,0,-.08);pivot=(-5,20,-1)
  ax,ay,az=angles;x0,y0,z0,dx,dy,dz=box
  for x,y,z in itertools.product((x0,x0+dx),(y0,y0+dy),(z0,z0+dz)):
   y,z=y*math.cos(ax)-z*math.sin(ax),y*math.sin(ax)+z*math.cos(ax)
   x,z=x*math.cos(ay)+z*math.sin(ay),-x*math.sin(ay)+z*math.cos(ay)
   x,y=x*math.cos(az)-y*math.sin(az),x*math.sin(az)+y*math.cos(az)
   wx=-(x+pivot[0])/16;wy=1.501-(y+pivot[1])/16;wz=(z+pivot[2])/16
   # The native box must enclose the geometry for any body yaw.
   assert math.hypot(wx,wz)<=.9 and -.01<=wy<=.82,(part,frame,wx,wy,wz)
   checks+=1
with zipfile.ZipFile('work/crawl103/TZP_1.20.1_2.7.zip') as z:
 for n in z.namelist():
  if n.endswith('_animations.jpm'):
   o=json.loads(z.read(n));assert o['animations'][0]['varb.gore_crawl'].count('>0')==2
print('Adult pose envelope:',checks,'corner projections fit crawler hitbox across movement phases/body yaw.')
