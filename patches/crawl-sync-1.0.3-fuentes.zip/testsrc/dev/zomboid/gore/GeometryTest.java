package dev.zomboid.gore;
import net.minecraft.world.entity.monster.Zombie;import net.minecraft.world.entity.EntityDimensions;
public class GeometryTest{
 static int checks;static void check(boolean b){checks++;if(!b)throw new AssertionError("check "+checks);}
 public static void main(String[]args){
  Gore.accessor=new Object();Zombie z=new Zombie();
  for(int state=0;state<65536;state++)check(Rules.crawling(state)==((state&48)==48));
  for(float width:new float[]{.3f,.6f,1.2f})for(int flags:new int[]{0,16,32,48,255}){
   z.flags=flags;EntityDimensions original=EntityDimensions.scalable(width,width*3.25f);Object result=CrawlGeometry.dimensions(z,original);
   if((flags&48)!=48)check(result==original);
   else{EntityDimensions dim=(EntityDimensions)result;check(Math.abs(dim.width-width*3)<.0001f);check(Math.abs(dim.height-width/.6f*.82f)<.0001f);check(Math.abs(dim.eyeHeight-width/.6f*.5f)<.0001f);check(CrawlGeometry.dimensions(z,dim)==dim);}
  }
  check(CrawlGeometry.dimensions(new Object(),EntityDimensions.scalable(.6f,1.95f)) instanceof EntityDimensions);
  System.out.println("Geometry: "+checks+" checks passed: leg states, normal-dimension identity, scaled crawler box/eye height, and duplicate-hook idempotence.");
 }
}
