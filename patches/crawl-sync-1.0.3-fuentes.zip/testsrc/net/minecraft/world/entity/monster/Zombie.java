package net.minecraft.world.entity.monster;
public class Zombie {public int flags;public Data data=new Data(this);public Data getEntityData(){return data;}public static class Data{Zombie entity;Data(Zombie e){entity=e;}public Integer get(Object key){return entity.flags;}}}
