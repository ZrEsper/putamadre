package net.minecraft.world.entity;
public class EntityDimensions{public final float width,height,eyeHeight;public EntityDimensions(float w,float h,float eye){width=w;height=h;eyeHeight=eye;}public static EntityDimensions scalable(float w,float h){return new EntityDimensions(w,h,h*.85f);}public EntityDimensions withEyeHeight(float h){return new EntityDimensions(width,height,h);}}
