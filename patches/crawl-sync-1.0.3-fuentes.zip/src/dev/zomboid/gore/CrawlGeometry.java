package dev.zomboid.gore;
public final class CrawlGeometry {
 public static final float WIDTH=1.8f,HEIGHT=.82f,EYE=.5f;
 public static Object dimensions(Object entity,Object original){
  if(!Gore.zombie(entity)||!Rules.crawling(Gore.state(entity)))return original;
  float width=((Number)R.get(original,"width")).floatValue(),height=((Number)R.get(original,"height")).floatValue();
  // Entity and LivingEntity can both pass through the dimensions hook. Never scale a second time.
  if(width>0&&Math.abs(height/width-HEIGHT/WIDTH)<.0001f)return original;
  float scale=width/.6f;
  Object result=R.call(R.type("net.minecraft.world.entity.EntityDimensions"),"scalable",WIDTH*scale,HEIGHT*scale);
  return R.call(result,"withEyeHeight",EYE*scale);
 }
}
