from pathlib import Path
import zipfile,json,hashlib
r=Path('work/survivor16');out=Path('work/survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v16-death-audio.jar')
with zipfile.ZipFile(r/'base16.jar') as z:data={n:z.read(n) for n in z.namelist()}
for p in (r/'classes').rglob('*.class'):
 n=str(p.relative_to(r/'classes'));assert n.startswith('dev/survivorcreator/hearing/');data[n]=p.read_bytes()
sounds=json.loads(data['assets/survivorcreator/sounds.json']);sounds['death_music']={'sounds':[{'name':'survivorcreator:music/death_theme','stream':True}]};data['assets/survivorcreator/sounds.json']=json.dumps(sounds,indent=2).encode()
data['assets/survivorcreator/sounds/music/death_theme.ogg']=Path('attachments/d6ebed1a-8912-4806-95b2-5594462f3313/Death.ogg').read_bytes()
labels={
'es_es':{'unknown':'Causa de muerte desconocida','unavailable':'No disponible','injuries':'Lesiones activas (zonas): %s','parts':'Zonas del cuerpo lesionadas: %s','survived':'Tiempo sobrevivido: %s','click':'Haz clic izquierdo para continuar'},
'en_us':{'unknown':'Unknown cause of death','unavailable':'Unavailable','injuries':'Active injuries (body areas): %s','parts':'Injured body areas: %s','survived':'Time survived: %s','click':'Left click to continue'}}
for lang,labels in labels.items():
 n=f'assets/survivorcreator/lang/{lang}.json';j=json.loads(data[n]);j.update({'screen.survivorcreator.death.'+k:v for k,v in labels.items()});data[n]=json.dumps(j,ensure_ascii=False,indent=2).encode()
n='META-INF/neoforge.mods.toml';s=data[n].decode();import re
s=re.sub(r'(?m)^version="[^"]+"', 'version="1.0.9-zomboid-v16-death-audio"',s,count=1);data[n]=s.encode()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in data.items():z.writestr(n,b)
b=out.read_bytes();print(out,len(b));print('SHA256',hashlib.sha256(b).hexdigest());print('Git blob',hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
assert data['assets/survivorcreator/sounds/music/creation_theme.ogg']==Path('attachments/c992ea33-60d0-4358-84e6-18e29f10d184/Project Zomboid B42.20 Main Menu.ogg').read_bytes()
