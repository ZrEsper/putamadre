package dev.survivorcreator.hearing;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.*;
import net.minecraft.sounds.SoundSource;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.api.distmarker.Dist;
@EventBusSubscriber(modid="survivorcreator",value=Dist.CLIENT)
public final class CreationAudio {
    private static SoundInstance music;
    private static long musicStarted;
    private static boolean deathTrack, deathPlayed, deathStarted;
    private static boolean wasMenu;
    private static net.minecraft.client.player.LocalPlayer owner;
    private static int previousAmplifier=-1,previousDuration;
    private static int beganTick;
    public static boolean menu() {
        var mc=Minecraft.getInstance();
        return mc.screen instanceof net.minecraft.client.gui.screens.DeathScreen || mc.screen instanceof dev.survivorcreator.client.CreatorScreen || mc.screen instanceof dev.survivorcreator.client.EndingScreen;
    }
    public static int level() {
        var mc=Minecraft.getInstance();
        if(mc.player==null) return menu()?3:0;
        if(menu() || !mc.player.isAlive()) return 3;
        var effect=mc.player.getEffect(HearingEffects.DEAFNESS);
        // A server-side creation effect may arrive just after the screen closes.
        if(effect!=null && effect.getAmplifier()<2) return effect.getAmplifier()+1;
        return HearingRules.hearingPerk(dev.survivorcreator.data.ClientState.character)?2:0;
    }
    public static float volume(SoundSource source) {
        if(menu() && (source==SoundSource.MUSIC || source==SoundSource.MASTER)) return 1f;
        return HearingRules.volume(level());
    }
    public static void finished(boolean death) { if(!death && Minecraft.getInstance().player!=null) net.neoforged.neoforge.network.PacketDistributor.sendToServer(new DeathReports.GameplayStarted()); }
    public static boolean enterDeathOnce() { if(deathStarted) return false; deathStarted=true;return true; }
    public static void begin() { deathStarted=false; switchTrack(false); start(); }
    public static void beginDeath() { switchTrack(true); start(); }
    private static void switchTrack(boolean death) { if(deathTrack!=death) { stop(); deathTrack=death; deathPlayed=false; } }
    private static boolean deathScreen() {
        var screen=Minecraft.getInstance().screen;return screen instanceof net.minecraft.client.gui.screens.DeathScreen || (screen instanceof dev.survivorcreator.client.EndingScreen e && e.survivorcreator$isDeath());
    }
    public static SoundInstance track() { start(); return music; }
    public static void start() {
        var mc=Minecraft.getInstance();
        if(!menu()) return;
        switchTrack(deathScreen());
        if(deathTrack && deathPlayed) return;
        if(music!=null && (mc.getSoundManager().isActive(music) || System.currentTimeMillis()-musicStarted<1500)) return;
        mc.getMusicManager().stopPlaying();
        music=SimpleSoundInstance.forMusic((deathTrack ? dev.survivorcreator.ModSounds.DEATH_MUSIC : dev.survivorcreator.ModSounds.CREATION_MUSIC).get());
        musicStarted=System.currentTimeMillis();
        mc.getSoundManager().play(music);
        if(deathTrack) deathPlayed=true;
    }
    private static void stop() {
        var mc=Minecraft.getInstance();
        if(music!=null) mc.getSoundManager().stop(music);
        music=null;
        deathPlayed=false;
    }
    @SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event) {
        var mc=Minecraft.getInstance(); boolean active=menu();
        if(active) {
            mc.getMusicManager().stopPlaying();
            if(!wasMenu) { ProgressHud.clear(); mc.getMusicManager().stopPlaying(); }
            if(mc.player!=null) {
                if(owner!=mc.player) {
                    owner=mc.player; beganTick=owner.tickCount;
                    var prior=owner.getEffect(HearingEffects.DEAFNESS);
                    previousAmplifier=prior==null||prior.getAmplifier()>=2?-1:prior.getAmplifier();
                    previousDuration=prior==null?0:prior.getDuration();
                }
                HearingEffects.set(owner,2,100,false);
            }
            if(deathScreen()&&!deathStarted)dev.survivorcreator.client.DeathAudio.beginDeath();
            // The song repeats if creation lasts longer than the track.
            start();
        } else {
            if(wasMenu) {
                // Retain the death song across the brief respawn / network screen transition.
                if(!deathStarted) stop();
                if(owner!=null && owner==mc.player) {
                    var current=owner.getEffect(HearingEffects.DEAFNESS);
                    if(current!=null && current.getAmplifier()>=2) owner.removeEffect(HearingEffects.DEAFNESS);
                    int remaining=previousDuration==-1?-1:previousDuration-(owner.tickCount-beganTick);
                    if(HearingRules.hearingPerk(dev.survivorcreator.data.ClientState.character)) HearingEffects.set(owner,1,-1,true);
                    else if(previousAmplifier>=0 && (remaining==-1||remaining>0)) HearingEffects.set(owner,previousAmplifier,remaining,true);
                }
                owner=null; previousAmplifier=-1;
            }
            if(mc.player==null) { deathStarted=false;stop(); ProgressHud.reset(); owner=null; }
        }
        wasMenu=active;
    }
}
