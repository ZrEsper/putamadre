package dev.survivorcreator.hearing;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.*;
import net.minecraft.nbt.CompoundTag;
import com.google.gson.*;
@EventBusSubscriber(modid="survivorcreator")
public final class DeathReports {
 private static final String REPORT="survivorcreator_death16", TICKS="survivorcreator_life16", WAIT="survivorcreator_creation16";
 @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post event) {
  if(!(event.getEntity() instanceof ServerPlayer p)||!p.isAlive())return;
  var c=((net.neoforged.neoforge.attachment.IAttachmentHolder)p).getData(dev.survivorcreator.SurvivorCreator.CHARACTER.get());
  var tag=p.getPersistentData();
  if(!c.completed()){tag.putBoolean(WAIT,true);tag.putLong(TICKS,0);return;}
  if(c.completed()&&!tag.getBoolean(WAIT)) { if(!tag.contains(TICKS))tag.putLong(TICKS,previousLifeTicks(p));tag.putLong(TICKS,tag.getLong(TICKS)+1);}
 }
 private static long previousLifeTicks(ServerPlayer p) {
  // Existing characters retain their vanilla survival statistic when installing this version.
  try {Object type=Class.forName("net.minecraft.stats.Stats").getField("CUSTOM").get(null);Object key=Class.forName("net.minecraft.stats.Stats").getField("TIME_SINCE_DEATH").get(null);Object stat=type.getClass().getMethod("get",Object.class).invoke(type,key); Object stats=p.getClass().getMethod("getStats").invoke(p);return ((Number)stats.getClass().getMethod("getValue",Class.forName("net.minecraft.stats.Stat")).invoke(stats,stat)).longValue();}catch(ReflectiveOperationException e){return 0;}
 }
 @SubscribeEvent(priority=EventPriority.HIGHEST) public static void death(net.neoforged.neoforge.event.entity.living.LivingDeathEvent event) {
  if(!(event.getEntity() instanceof ServerPlayer p))return;
  var message=p.getCombatTracker().getDeathMessage();String key="";String[] args=new String[0];
  try {Object contents=message.getClass().getMethod("getContents").invoke(message);key=(String)contents.getClass().getMethod("getKey").invoke(contents);Object[] raw=(Object[])contents.getClass().getMethod("getArgs").invoke(contents);args=new String[raw.length];for(int i=0;i<args.length;i++)args[i]=raw[i] instanceof net.minecraft.network.chat.Component c?c.getString():String.valueOf(raw[i]);}catch(ReflectiveOperationException ignored){}
  int injuries=-1;boolean clinical=false;
  try {Class<?> utils=Class.forName("ichttt.mods.firstaid.common.util.CommonUtils");Object model=utils.getMethod("getExistingDamageModel",Player.class).invoke(null,p);
   if(model!=null) {
    try {Class<?> data=Class.forName("ichttt.mods.firstaid.survival.ClinicalData");Object state=data.getMethod("state",Class.forName("ichttt.mods.firstaid.api.damagesystem.AbstractPlayerDamageModel")).invoke(null,model);injuries=DeathReport.countAreas((Iterable<?>)model,data.getMethod("wound",Class.forName("ichttt.mods.firstaid.api.damagesystem.AbstractDamageablePart")));clinical=true;}
    catch(ReflectiveOperationException unavailable) {injuries=DeathReport.countAreas((Iterable<?>)model,null);}
   }
  } catch(ReflectiveOperationException | LinkageError ignored) {}
  long ticks=p.getPersistentData().contains(TICKS)?p.getPersistentData().getLong(TICKS):previousLifeTicks(p);
  p.getPersistentData().putString(REPORT,new DeathReport(message.getString(),key,args,injuries,ticks,clinical).json());
 }
 @SubscribeEvent public static void clone(net.neoforged.neoforge.event.entity.player.PlayerEvent.Clone event) {
  CompoundTag old=event.getOriginal().getPersistentData(), now=event.getEntity().getPersistentData();
  now.putString(REPORT,old.getString(REPORT));
  if(event.isWasDeath()){now.putLong(TICKS,0);now.putBoolean(WAIT,true);}
  else {if(old.contains(TICKS))now.putLong(TICKS,old.getLong(TICKS));now.putBoolean(WAIT,old.getBoolean(WAIT));}
 }
 public record GameplayStarted() implements net.minecraft.network.protocol.common.custom.CustomPacketPayload {
  public static final Type<GameplayStarted> TYPE=new Type<>(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("survivorcreator","gameplay_started16"));
  public static final net.minecraft.network.codec.StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf,GameplayStarted> CODEC=net.minecraft.network.codec.StreamCodec.unit(new GameplayStarted());
  public Type<GameplayStarted> type(){return TYPE;}
 }
 public static void register(net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent event) {
  event.registrar("1").playToServer(GameplayStarted.TYPE,GameplayStarted.CODEC,(packet,context)->context.enqueueWork(()-> {
   if(!(context.player() instanceof ServerPlayer p)||!p.isAlive())return;
   var c=((net.neoforged.neoforge.attachment.IAttachmentHolder)p).getData(dev.survivorcreator.SurvivorCreator.CHARACTER.get());var tag=p.getPersistentData();
   if(c.completed()&&tag.getBoolean(WAIT)){tag.putBoolean(WAIT,false);tag.putLong(TICKS,0);}
  }));
 }
 public static void send(ServerPlayer p) {
  JsonObject j=new JsonObject();j.addProperty("player",p.getUUID().toString());JsonArray rows=new JsonArray();
  for(var skill:dev.survivorcreator.skills.Skills.all()){var row=new JsonObject();row.addProperty("id",skill.id());row.addProperty("level",dev.survivorcreator.skills.Skills.level(p,skill));row.addProperty("xp",dev.survivorcreator.skills.Skills.xp(p,skill));rows.add(row);}j.add("rows",rows);
  j.addProperty("death16",p.getPersistentData().getString(REPORT));
  net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(p,new dev.survivorcreator.skills.SkillSync.Snapshot(j.toString()));
 }
}
