package dev.survivorcreator.hearing;
import com.google.gson.*;
public record DeathReport(String cause,String causeKey,String[] causeArgs,int injuries,long ticks,boolean clinical) {
 public static final DeathReport UNKNOWN=new DeathReport("","",new String[0],-1,-1,false);
 public String json() { JsonObject j=new JsonObject(); j.addProperty("cause",cause);j.addProperty("key",causeKey);JsonArray a=new JsonArray();for(String v:causeArgs)a.add(v);j.add("args",a);j.addProperty("injuries",injuries);j.addProperty("ticks",ticks);j.addProperty("clinical",clinical);return j.toString(); }
 public static DeathReport parse(String text) { try { var j=JsonParser.parseString(text).getAsJsonObject(); var a=j.get("args").getAsJsonArray();String[] args=new String[a.size()];for(int i=0;i<args.length;i++)args[i]=a.get(i).getAsString();return new DeathReport(j.get("cause").getAsString(),j.get("key").getAsString(),args,j.get("injuries").getAsInt(),j.get("ticks").getAsLong(),j.get("clinical").getAsBoolean()); } catch(RuntimeException e){return UNKNOWN;} }
 public static String duration(long ticks) { long seconds=Math.max(0,ticks)/20;return String.format(java.util.Locale.ROOT,"%dd %02d:%02d:%02d",seconds/86400,seconds/3600%24,seconds/60%60,seconds%60); }
 public static int countAreas(Iterable<?> parts,java.lang.reflect.Method wound) throws ReflectiveOperationException {
  int count=0;for(Object part:parts){boolean injured=part.getClass().getField("currentHealth").getFloat(part)<((Number)part.getClass().getMethod("getMaxHealth").invoke(part)).floatValue();if(wound!=null){Object w=wound.invoke(null,part);if(w!=null)injured|=(boolean)w.getClass().getMethod("active").invoke(w);}if(injured)count++;}return count;
 }
 public static int countClinical(Object[] wounds) throws ReflectiveOperationException {int count=0;for(Object w:wounds) if(w!=null && (boolean)w.getClass().getMethod("active").invoke(w))count++;return count;}
}
