package dev.survivorcreator.hearing;
import net.minecraft.client.gui.*;
import net.minecraft.network.chat.Component;
public final class DeathPanel {
 private static DeathReport report=DeathReport.UNKNOWN;
 public static void accept(String json) { try { var j=com.google.gson.JsonParser.parseString(json).getAsJsonObject();if(j.has("death16"))report=DeathReport.parse(j.get("death16").getAsString());}catch(RuntimeException ignored){} }
 public static boolean canContinue(long elapsed) { return elapsed>=850; }
 public static void render(GuiGraphics g,Font font,int width,int height,long elapsed) {
  if(elapsed<850)return;
  int alpha=(int)(Math.min(1,(elapsed-850)/1100f)*255);if(alpha<=3)return;int color=(alpha<<24)|0xdcd6ca;
  int center=width/2, y=Math.max(12,height/2-52);
  draw(g,font,Component.translatable("screen.survivorcreator.death.1").getString(),center,y,(alpha<<24)|0xc97870);y+=24;
  String cause=report.causeKey().isEmpty()?report.cause():Component.translatable(report.causeKey(),(Object[])report.causeArgs()).getString();
  if(cause.isEmpty())cause=Component.translatable("screen.survivorcreator.death.unknown").getString();
  // Wrap long names / damage sources without extending beyond the screen.
  for(var line:font.split(Component.literal(cause),Math.max(60,width-48))) {g.drawString(font,line,(width-font.width(line))/2,y,color,false);y+=11;}
  y+=8;
  String injury=report.injuries()<0?Component.translatable("screen.survivorcreator.death.unavailable").getString():String.valueOf(report.injuries());
  draw(g,font,Component.translatable(report.clinical()?"screen.survivorcreator.death.injuries":"screen.survivorcreator.death.parts",injury).getString(),center,y,color);y+=15;
  String time=report.ticks()<0?Component.translatable("screen.survivorcreator.death.unavailable").getString():DeathReport.duration(report.ticks());
  draw(g,font,Component.translatable("screen.survivorcreator.death.survived",time).getString(),center,y,color);
  draw(g,font,Component.translatable("screen.survivorcreator.death.click").getString(),center,height-28,(alpha<<24)|0xa9baa2);
 }
 private static void draw(GuiGraphics g,Font f,String s,int x,int y,int c){g.drawString(f,s,x-f.width(s)/2,y,c,false);}
}
