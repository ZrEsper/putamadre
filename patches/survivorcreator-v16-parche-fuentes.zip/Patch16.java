import java.nio.file.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;
public class Patch16 implements Opcodes {
 static final String H="dev/survivorcreator/hearing/", E="dev/survivorcreator/client/EndingScreen";static int hooks;
 static byte[] patch(String file,byte[] b) {
  ClassReader r=new ClassReader(b);ClassWriter w=new ClassWriter(r,ClassWriter.COMPUTE_MAXS);
  r.accept(new ClassVisitor(ASM8,w) {
   public void visit(int v,int a,String n,String s,String p,String[] i){super.visit(v,a,n,s,p,i);if(n.equals("dev/survivorcreator/ModSounds"))super.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL,"DEATH_MUSIC","Ljava/util/function/Supplier;","Ljava/util/function/Supplier<Lnet/minecraft/sounds/SoundEvent;>;",null).visitEnd();}
   public void visitEnd(){
    if(file.equals("dev/survivorcreator/client/DeathAudio.class")){var m=super.visitMethod(ACC_PUBLIC|ACC_STATIC,"beginDeath","()V",null,null);m.visitCode();m.visitMethodInsn(INVOKESTATIC,H+"CreationAudio","enterDeathOnce","()Z",false);Label done=new Label();m.visitJumpInsn(IFEQ,done);m.visitMethodInsn(INVOKESTATIC,"dev/survivorcreator/client/DeathAudio","survivorcreator$beginDeath16","()V",false);m.visitLabel(done);m.visitFrame(F_SAME,0,null,0,null);m.visitInsn(RETURN);m.visitMaxs(1,0);m.visitEnd();hooks++;}
    if(file.equals(E+".class")){var m=super.visitMethod(ACC_PUBLIC,"survivorcreator$isDeath","()Z",null,null);m.visitCode();m.visitVarInsn(ALOAD,0);m.visitFieldInsn(GETFIELD,E,"deathMode","Z");m.visitInsn(IRETURN);m.visitMaxs(1,1);m.visitEnd();hooks++;}super.visitEnd();}
   public MethodVisitor visitMethod(int a,String n,String d,String s,String[] ex) {
    var m=super.visitMethod(a,file.equals("dev/survivorcreator/client/DeathAudio.class")&&n.equals("beginDeath")?"survivorcreator$beginDeath16":n,d,s,ex);
    if(file.equals(E+".class")&&n.equals("renderDeath")) {
     m.visitCode();m.visitVarInsn(ALOAD,1);m.visitVarInsn(ALOAD,0);m.visitFieldInsn(GETFIELD,E,"font","Lnet/minecraft/client/gui/Font;");m.visitVarInsn(ALOAD,0);m.visitFieldInsn(GETFIELD,E,"width","I");m.visitVarInsn(ALOAD,0);m.visitFieldInsn(GETFIELD,E,"height","I");m.visitVarInsn(LLOAD,2);m.visitMethodInsn(INVOKESTATIC,H+"DeathPanel","render","(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/gui/Font;IIJ)V",false);m.visitInsn(RETURN);m.visitMaxs(6,4);m.visitEnd();hooks++;return null;
    }
    if(file.equals(E+".class")&&(n.equals("keyPressed")||n.equals("mouseClicked"))) {
     m.visitCode();Label run=new Label(),done=new Label();m.visitVarInsn(ALOAD,0);m.visitFieldInsn(GETFIELD,E,"deathMode","Z");m.visitJumpInsn(IFEQ,run);
     if(n.equals("mouseClicked")){m.visitVarInsn(ILOAD,5);m.visitJumpInsn(IFEQ,run);}m.visitJumpInsn(GOTO,done);
     m.visitLabel(run);m.visitFrame(F_SAME,0,null,0,null);m.visitVarInsn(ALOAD,0);m.visitMethodInsn(INVOKEVIRTUAL,E,"nextPhase","()V",false);
     m.visitLabel(done);m.visitFrame(F_SAME,0,null,0,null);m.visitInsn(ICONST_1);m.visitInsn(IRETURN);m.visitMaxs(1,n.equals("keyPressed")?4:6);m.visitEnd();hooks++;return null;
    }
    if(file.equals("dev/survivorcreator/client/DeathTiming.class")&&n.equals("canSkip")) {
     m.visitCode();m.visitVarInsn(LLOAD,0);m.visitMethodInsn(INVOKESTATIC,H+"DeathPanel","canContinue","(J)Z",false);m.visitInsn(IRETURN);m.visitMaxs(2,2);m.visitEnd();hooks++;return null;
    }
    return new MethodVisitor(ASM8,m) {
     public void visitCode(){super.visitCode();if(file.equals("dev/survivorcreator/DeathHooks.class")&&n.equals("sendDeath")){super.visitVarInsn(ALOAD,0);super.visitMethodInsn(INVOKESTATIC,H+"DeathReports","send","(Lnet/minecraft/server/level/ServerPlayer;)V",false);hooks++;}}
     public void visitMethodInsn(int op,String owner,String name,String desc,boolean iface){
      super.visitMethodInsn(op,owner,name,desc,iface);
      if(file.equals(E+".class")&&n.equals("finish")&&owner.equals("net/minecraft/client/Minecraft")&&name.equals("setScreen")){super.visitVarInsn(ALOAD,0);super.visitFieldInsn(GETFIELD,E,"deathMode","Z");super.visitMethodInsn(INVOKESTATIC,H+"CreationAudio","finished","(Z)V",false);hooks++;}
     }
     public void visitInsn(int op){if(op==RETURN){
      if(file.equals("dev/survivorcreator/net/Net.class")&&n.equals("register")){super.visitVarInsn(ALOAD,0);super.visitMethodInsn(INVOKESTATIC,H+"DeathReports","register","(Lnet/neoforged/neoforge/network/event/RegisterPayloadHandlersEvent;)V",false);hooks++;}
      if(file.equals("dev/survivorcreator/ModSounds.class")&&n.equals("<clinit>")){super.visitLdcInsn("death_music");super.visitMethodInsn(INVOKESTATIC,"dev/survivorcreator/ModSounds","register","(Ljava/lang/String;)Ljava/util/function/Supplier;",false);super.visitFieldInsn(PUTSTATIC,"dev/survivorcreator/ModSounds","DEATH_MUSIC","Ljava/util/function/Supplier;");hooks++;}
      if(file.equals("dev/survivorcreator/client/DeathAudio.class")&&n.equals("beginDeath")){super.visitMethodInsn(INVOKESTATIC,H+"CreationAudio","beginDeath","()V",false);hooks++;}
      if(file.equals("dev/survivorcreator/skills/SkillSnapshot.class")&&n.equals("accept")){super.visitVarInsn(ALOAD,0);super.visitMethodInsn(INVOKESTATIC,H+"DeathPanel","accept","(Ljava/lang/String;)V",false);hooks++;}
     }super.visitInsn(op);}
    };
   }
  },0);return w.toByteArray();
 }
 public static void main(String[]args)throws Exception {try(ZipFile in=new ZipFile(args[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(args[1])))){for(var it=in.entries();it.hasMoreElements();){var e=it.nextElement();if(e.isDirectory())continue;byte[] b=in.getInputStream(e).readAllBytes();if(e.getName().endsWith(".class"))b=patch(e.getName(),b);out.putNextEntry(new ZipEntry(e.getName()));out.write(b);out.closeEntry();}}if(hooks!=12)throw new IllegalStateException("hooks="+hooks);System.out.println("Applied "+hooks+" hooks");}
}
