package lain.mods.cos.functional;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.api.distmarker.Dist;
@EventBusSubscriber(modid="cosmeticarmorreworkedforked",value=Dist.CLIENT)
public final class OverlayUI {
    private static final java.util.Map<net.minecraft.client.gui.screens.Screen,OverlayButton> BUTTONS=new java.util.WeakHashMap<>();
    public static Component label(){return Component.translatable(OverlayChoice.enabled(Minecraft.getInstance().player)?"cosarmor.functional.overlay.on":"cosarmor.functional.overlay.off");}
    public static void toggle(net.minecraft.client.gui.components.Button button) {
        var player=Minecraft.getInstance().player;if(player==null)return;
        var inventory=lain.mods.cos.api.CosArmorAPI.getCAStacksClient(player.getUUID());
        boolean active=!inventory.isHidden(OverlayChoice.MODID,OverlayChoice.FLAG);
        inventory.setHidden(OverlayChoice.MODID,OverlayChoice.FLAG,active);
        lain.mods.cos.impl.platform.PlatformHelper.sendToServer(new lain.mods.cos.impl.network.payload.PayloadSetHiddenFlags(OverlayChoice.MODID,OverlayChoice.FLAG,active));
        button.setMessage(label());
    }
    @SubscribeEvent public static void init(net.neoforged.neoforge.client.event.ScreenEvent.Init.Post event) {
        if(!(event.getScreen() instanceof lain.mods.cos.impl.client.gui.GuiCosArmorInventory screen))return;
        var access=(zzik2.cosmeticarmorreworkedforked.mixin.AbstractContainerScreenAccessor)(Object)screen;
        var button=new OverlayButton(access.getLeftPos(),Math.min(access.getTopPos()+170,screen.height-20));
        BUTTONS.put(screen,button);event.addListener(button);
    }
    @SubscribeEvent public static void render(net.neoforged.neoforge.client.event.ScreenEvent.Render.Pre event) {
        var button=BUTTONS.get(event.getScreen());if(button==null)return;
        var access=(zzik2.cosmeticarmorreworkedforked.mixin.AbstractContainerScreenAccessor)(Object)event.getScreen();
        button.setX(access.getLeftPos());button.setY(Math.min(access.getTopPos()+170,event.getScreen().height-20));
        button.setMessage(label());
    }
}
