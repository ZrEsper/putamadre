package lain.mods.cos.functional;
public record FirstAidScope(net.minecraft.world.entity.EquipmentSlot slot,float damage) {}
