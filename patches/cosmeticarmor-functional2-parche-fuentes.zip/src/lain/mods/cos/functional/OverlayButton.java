package lain.mods.cos.functional;
import net.minecraft.client.gui.components.Button;
public final class OverlayButton extends Button implements lain.mods.cos.impl.client.gui.IShiftingWidget {
    public OverlayButton(int x,int y) {
        super(x,y,176,18,OverlayUI.label(),OverlayUI::toggle,DEFAULT_NARRATION);
        setTooltip(net.minecraft.client.gui.components.Tooltip.create(net.minecraft.network.chat.Component.translatable("cosarmor.functional.overlay.tooltip")));
    }
    public void shiftLeft(int offset){setX(getX()+offset);}
}
