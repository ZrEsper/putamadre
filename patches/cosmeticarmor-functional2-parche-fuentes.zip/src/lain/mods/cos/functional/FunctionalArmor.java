package lain.mods.cos.functional;
import java.util.*;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.damagesource.DamageSource;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
@EventBusSubscriber(modid="cosmeticarmorreworkedforked")
public final class FunctionalArmor {
    public static final EquipmentSlot[] SLOTS={EquipmentSlot.FEET,EquipmentSlot.LEGS,EquipmentSlot.CHEST,EquipmentSlot.HEAD};
    public record Key(Holder<Attribute> attribute,ResourceLocation id) {}
    private static final Map<Player,Map<Key,AttributeModifier>> ACTIVE=new WeakHashMap<>();
    public static int index(EquipmentSlot slot) { for(int i=0;i<SLOTS.length;i++) if(SLOTS[i]==slot)return i;return -1; }
    public static ResourceLocation modifierId(int index,ResourceLocation original) {
        String hash=UUID.nameUUIDFromBytes(original.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString();
        return ResourceLocation.fromNamespaceAndPath("cosmeticarmorreworkedforked","functional/"+index+"/"+hash);
    }
    public static void refresh(Player player) {
        if(!(player instanceof ServerPlayer)) return;
        Map<Key,AttributeModifier> next=new LinkedHashMap<>();
        if(player.isAlive()) {
            var inventory=lain.mods.cos.api.CosArmorAPI.getCAStacks(player.getUUID());
            for(int i=0;i<SLOTS.length;i++) {
                final int index=i; var stack=inventory.getStackInSlot(i);
                if(stack.isEmpty()) continue;
                stack.forEachModifier(SLOTS[i],(attribute,modifier)->{
                    if(!Double.isFinite(modifier.amount())) return;
                    ResourceLocation id=modifierId(index,modifier.id());
                    next.put(new Key(attribute,id),new AttributeModifier(id,modifier.amount(),modifier.operation()));
                });
            }
        }
        var prior=ACTIVE.getOrDefault(player,Map.of());
        for(Key key:prior.keySet()) if(!next.containsKey(key)) { var attribute=player.getAttribute(key.attribute());if(attribute!=null)attribute.removeModifier(key.id()); }
        for(var entry:next.entrySet()) {
            var key=entry.getKey();var attribute=player.getAttribute(key.attribute());
            if(attribute==null) continue;
            if(!entry.getValue().equals(attribute.getModifier(key.id()))) {
                attribute.removeModifier(key.id());attribute.addTransientModifier(entry.getValue());
            }
        }
        if(next.isEmpty()) ACTIVE.remove(player); else ACTIVE.put(player,next);
        if(player.getHealth()>player.getMaxHealth()) player.setHealth(player.getMaxHealth());
    }
    public static double slotAttribute(Player player,EquipmentSlot slot,Holder<Attribute> attribute) {
        int i=index(slot);if(i<0)return 0;
        double[] values={0,0,1};
        var stack=lain.mods.cos.api.CosArmorAPI.getCAStacks(player.getUUID()).getStackInSlot(i);
        if(stack.isEmpty())return 0;
        stack.forEachModifier(slot,(holder,modifier)->{
            if(!holder.equals(attribute)||!Double.isFinite(modifier.amount()))return;
            switch(modifier.operation()) {
                case ADD_VALUE -> values[0]+=modifier.amount();
                case ADD_MULTIPLIED_BASE -> values[1]+=modifier.amount();
                case ADD_MULTIPLIED_TOTAL -> values[2]*=1+modifier.amount();
            }
        });
        return values[0]*(1+values[1])*values[2];
    }
    public static double cosmeticContribution(Player player,Holder<Attribute> holder) {
        var attribute=player.getAttribute(holder);if(attribute==null)return 0;
        double value=attribute.getBaseValue(),multiplyBase=0,multiplyTotal=1;
        for(var modifier:attribute.getModifiers()) {
            if(modifier.id().getNamespace().equals("cosmeticarmorreworkedforked")&&modifier.id().getPath().startsWith("functional/"))continue;
            switch(modifier.operation()) {
                case ADD_VALUE -> value+=modifier.amount();
                case ADD_MULTIPLIED_BASE -> multiplyBase+=modifier.amount();
                case ADD_MULTIPLIED_TOTAL -> multiplyTotal*=1+modifier.amount();
            }
        }
        double without=holder.value().sanitizeValue(value*(1+multiplyBase)*multiplyTotal);
        return attribute.getValue()-without;
    }
    public static void damage(Player player,DamageSource source,float amount) {
        if(!(player instanceof ServerPlayer) || player.isCreative() || player.isSpectator() || !Float.isFinite(amount) || amount<=0 || source.is(net.minecraft.tags.DamageTypeTags.BYPASSES_ARMOR)) return;
        int wear=Math.max(1,(int)(amount/4));
        for(int i=0;i<SLOTS.length;i++) damageSlot(player,source,i,wear);
        refresh(player);
    }
    public static void damageSlot(Player player,DamageSource source,int index,int wear) {
        if(index<0||index>=4||wear<=0||!(player instanceof ServerPlayer)||player.isCreative()||player.isSpectator()||source.is(net.minecraft.tags.DamageTypeTags.BYPASSES_ARMOR)) return;
        var inventory=lain.mods.cos.api.CosArmorAPI.getCAStacks(player.getUUID());
        var stack=inventory.getStackInSlot(index);
        if(stack.isEmpty() || !stack.isDamageableItem() || !stack.canBeHurtBy(source)) return;
        stack.hurtAndBreak(wear,player,SLOTS[index]);
        inventory.setStackInSlot(index,stack); // Notify the existing sync/persistence listeners.
    }
    public static void firstAidDamage(Player player,DamageSource source,float amount,EquipmentSlot slot) {
        if(!Float.isFinite(amount)||amount<=0||source.is(net.minecraft.tags.DamageTypeTags.IS_FIRE))return;
        damageSlot(player,source,index(slot),Math.max(1,(int)amount));refresh(player);
    }
    @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post event){refresh(event.getEntity());}
    @SubscribeEvent public static void logout(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent event) {
        Player player=event.getEntity();var previous=ACTIVE.remove(player);if(previous==null)return;
        for(var key:previous.keySet()){var attribute=player.getAttribute(key.attribute());if(attribute!=null)attribute.removeModifier(key.id());}
    }
}
