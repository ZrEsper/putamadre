package lain.mods.cos.functional.mixin;
import lain.mods.cos.functional.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(targets="net.minecraft.world.entity.player.Player",remap=false)
public abstract class FunctionalArmorMixin {
    @Inject(method="hurtArmor(Lnet/minecraft/world/damagesource/DamageSource;F)V",at=@At("TAIL"),require=1,remap=false)
    private void functional$wear(net.minecraft.world.damagesource.DamageSource source,float amount,CallbackInfo callback) {
        FunctionalArmor.damage((net.minecraft.world.entity.player.Player)(Object)this,source,amount);
    }
}
