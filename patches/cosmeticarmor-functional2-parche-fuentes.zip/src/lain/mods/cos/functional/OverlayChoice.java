package lain.mods.cos.functional;
public final class OverlayChoice {
    public static final String MODID="cosmeticarmorreworkedforked",FLAG="functional_overlay";
    public static boolean enabled(Object entity) {
        if(!(entity instanceof net.minecraft.world.entity.player.Player player))return false;
        return lain.mods.cos.api.CosArmorAPI.getCAStacksClient(player.getUUID()).isHidden(MODID,FLAG);
    }
    public static void finishPre(net.minecraft.world.entity.player.Player player) {
        if(lain.mods.cos.impl.client.PlayerRenderHandler.Disabled || !enabled(player))return;
        var inventory=lain.mods.cos.impl.ModObjects.invMan.getCosArmorInventoryClient(player.getUUID());
        for(int i=0;i<4;i++) if(inventory.isSkinArmor(i)) player.getInventory().armor.set(i,net.minecraft.world.item.ItemStack.EMPTY);
    }
}
