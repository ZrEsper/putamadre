import lain.mods.cos.functional.*;import net.minecraft.server.level.ServerPlayer;import net.minecraft.world.item.ItemStack;import net.minecraft.world.entity.EquipmentSlot;import net.minecraft.world.entity.ai.attributes.*;import net.minecraft.resources.ResourceLocation;import java.util.*;
public class TestArmor {
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 record Attr(Attribute value) implements net.minecraft.core.Holder<Attribute>{}
 static ResourceLocation id(String name){return ResourceLocation.fromNamespaceAndPath("minecraft",name);}
 static ItemStack item(EquipmentSlot slot,Attr attr,String id,double value,AttributeModifier.Operation op){var s=new ItemStack(false);s.attrs.put(slot,new LinkedHashMap<>());s.attrs.get(slot).put(attr,new ArrayList<>(List.of(new AttributeModifier(id(id),value,op))));return s;}
 static void eq(double v,double e,String m){check(Math.abs(v-e)<1e-8,m+" got "+v);}
 public static void main(String[]a){
  var p=new ServerPlayer();var armor=new Attr(new Attribute("armor"));var movement=new Attr(new Attribute("movement"));var health=new Attr(new Attribute("health"));
  p.attrs.put(armor,new AttributeInstance(0));p.attrs.put(movement,new AttributeInstance(1));p.attrs.put(health,new AttributeInstance(20));
  var nativeModifier=new AttributeModifier(id("armor.chestplate"),8,AttributeModifier.Operation.ADD_VALUE);p.getAttribute(armor).addTransientModifier(nativeModifier);
  var inv=lain.mods.cos.api.CosArmorAPI.getCAStacks(p.getUUID());var chest=item(EquipmentSlot.CHEST,armor,"armor.chestplate",6,AttributeModifier.Operation.ADD_VALUE);chest.damageable=true;
  chest.attrs.get(EquipmentSlot.CHEST).put(movement,List.of(new AttributeModifier(id("weight"),-.2,AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL)));
  inv.setStackInSlot(2,chest);FunctionalArmor.refresh(p);eq(p.getAttribute(armor).value(),14,"Both sets contribute");eq(p.getAttribute(movement).value(),.8,"Negative modifier retained");check(p.getAttribute(armor).getModifier(nativeModifier.id()).equals(nativeModifier),"Native modifier survives same original id");
  int mutations=p.getAttribute(armor).mutations;for(int i=0;i<100;i++)FunctionalArmor.refresh(p);eq(p.getAttribute(armor).value(),14,"No stat stacking over time");check(p.getAttribute(armor).mutations==mutations,"Unchanged attributes not churned each tick");
  inv.setHidden(OverlayChoice.MODID,OverlayChoice.FLAG,true);FunctionalArmor.refresh(p);eq(p.getAttribute(armor).value(),14,"Visual choice does not change stats");
  var feet=item(EquipmentSlot.FEET,armor,"armor.chestplate",2,AttributeModifier.Operation.ADD_VALUE);inv.setStackInSlot(0,feet);FunctionalArmor.refresh(p);eq(p.getAttribute(armor).value(),16,"Same identifier across cosmetic slots independent");
  eq(FunctionalArmor.cosmeticContribution(p,armor),8,"Exact cosmetic portion isolated from native armor");
  eq(FunctionalArmor.slotAttribute(p,EquipmentSlot.CHEST,armor),6,"First Aid local chest value");
  eq(FunctionalArmor.slotAttribute(p,EquipmentSlot.FEET,armor),2,"First Aid local boots value");
  eq(FunctionalArmor.slotAttribute(p,EquipmentSlot.HEAD,armor),0,"Boots and chest do not protect an empty cosmetic head slot");
  eq(FunctionalArmor.cosmeticContribution(p,movement),-.2,"Multiplicative penalty contribution computed correctly");
  inv.setStackInSlot(0,ItemStack.EMPTY);FunctionalArmor.refresh(p);eq(p.getAttribute(armor).value(),14,"Removed slot loses its bonus");
  chest.attrs.get(EquipmentSlot.CHEST).put(armor,List.of(new AttributeModifier(id("armor.chestplate"),3,AttributeModifier.Operation.ADD_VALUE)));FunctionalArmor.refresh(p);eq(p.getAttribute(armor).value(),11,"Changing item component updates stats");
  inv.setStackInSlot(2,item(EquipmentSlot.HEAD,armor,"wrong",20,AttributeModifier.Operation.ADD_VALUE));FunctionalArmor.refresh(p);eq(p.getAttribute(armor).value(),8,"Wrong slot attributes do not activate");
  var highHealth=item(EquipmentSlot.HEAD,health,"health",10,AttributeModifier.Operation.ADD_VALUE);inv.setStackInSlot(3,highHealth);FunctionalArmor.refresh(p);eq(p.getMaxHealth(),30,"Maximum health bonus");eq(p.health,20,"Equipping does not heal freely");p.health=30;inv.setStackInSlot(3,ItemStack.EMPTY);FunctionalArmor.refresh(p);eq(p.health,20,"Unequipping clamps health to valid maximum");
  inv.setStackInSlot(2,chest);FunctionalArmor.refresh(p);var damage=new net.minecraft.world.damagesource.DamageSource();FunctionalArmor.damage(p,damage,8);check(chest.wear==2,"Vanilla damage wear /4");check(inv.sync>0,"Durability changes synced");
  p.creative=true;FunctionalArmor.damage(p,damage,8);check(chest.wear==2,"No creative wear");p.creative=false;damage.bypass=true;FunctionalArmor.damage(p,damage,8);check(chest.wear==2,"Armor-bypassing damage no wear");damage.bypass=false;
  chest.fireproof=true;damage.fire=true;FunctionalArmor.damage(p,damage,8);check(chest.wear==2,"Fireproof cosmetic armor survives fire");damage.fire=false;
  feet.damageable=true;inv.setStackInSlot(0,feet);FunctionalArmor.firstAidDamage(p,damage,3,EquipmentSlot.FEET);check(feet.wear==3,"First Aid damages corresponding cosmetic slot");check(chest.wear==2,"First Aid foot hit does not wear cosmetic chest");
  chest.maxDamage=3;FunctionalArmor.damage(p,damage,4);check(chest.isEmpty(),"Cosmetic armor can break");eq(p.getAttribute(armor).value(),10,"Broken piece loses stats immediately, other slot remains");
  inv.setStackInSlot(2,item(EquipmentSlot.CHEST,armor,"armor.chestplate",6,AttributeModifier.Operation.ADD_VALUE));FunctionalArmor.refresh(p);p.alive=false;FunctionalArmor.refresh(p);eq(p.getAttribute(armor).value(),8,"Death cleans cosmetic stats");p.alive=true;FunctionalArmor.refresh(p);eq(p.getAttribute(armor).value(),16,"Recovery reapplies once");
  var other=new ServerPlayer();other.attrs.put(armor,new AttributeInstance(0));FunctionalArmor.refresh(other);eq(other.getAttribute(armor).value(),0,"Players isolated");
  var unknown=new Attr(new Attribute("unregistered"));inv.setStackInSlot(1,item(EquipmentSlot.LEGS,unknown,"custom",5,AttributeModifier.Operation.ADD_VALUE));FunctionalArmor.refresh(p);check(p.getAttribute(unknown)==null,"Unknown player attribute does not crash");
  check(!OverlayChoice.enabled(new Object()),"Non-player has no overlay");check(!OverlayChoice.enabled(other),"Overlay default off");check(OverlayChoice.enabled(p),"Overlay choice follows owner");
  var local=new net.minecraft.client.player.LocalPlayer();var ci=(lain.mods.cos.impl.inventory.InventoryCosArmor)lain.mods.cos.api.CosArmorAPI.getCAStacksClient(local.getUUID());ci.setHidden(OverlayChoice.MODID,OverlayChoice.FLAG,true);ci.hidden[3]=true;local.getInventory().armor.set(3,chest);OverlayChoice.finishPre(local);check(local.getInventory().armor.get(3).isEmpty(),"Hide slot suppresses base layer while mixing");
  System.out.println("Passed "+checks+" functional armor checks");
 }
}
