import lain.mods.cos.functional.*;import lain.mods.cos.functional.mixin.MixedArmorLayerMixin;import net.minecraft.world.entity.*;import net.minecraft.world.item.ItemStack;import net.minecraft.world.entity.player.Player;import com.mojang.blaze3d.vertex.PoseStack;
public class TestOverlay {
 static int checks;static java.lang.reflect.Method render;
 static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static class Layer extends MixedArmorLayerMixin implements zzik2.cosmeticarmorreworkedforked.mixin.HumanoidArmorLayerInvoker {
  int calls;boolean fail;ItemStack expected;
  public void invokeRenderArmorPiece(PoseStack pose,net.minecraft.client.renderer.MultiBufferSource buffer,LivingEntity entity,EquipmentSlot slot,int light,net.minecraft.client.model.HumanoidModel model){
   calls++;check(((Player)entity).getItemBySlot(slot)==expected,"Cosmetic equipped only during its render");
   if(fail)throw new IllegalStateException("renderer failed");
   run(this,pose,entity,slot); // Simulate the nested vanilla renderer callback.
  }
 }
 static void run(Layer layer,PoseStack pose,LivingEntity entity,EquipmentSlot slot) {
  try{render.invoke(layer,pose,null,entity,slot,0,null,new org.spongepowered.asm.mixin.injection.callback.CallbackInfo());}
  catch(java.lang.reflect.InvocationTargetException e){if(e.getCause() instanceof RuntimeException r)throw r;throw new RuntimeException(e.getCause());}catch(ReflectiveOperationException e){throw new RuntimeException(e);}
 }
 public static void main(String[]args)throws Exception{
  render=MixedArmorLayerMixin.class.getDeclaredMethods()[0];render.setAccessible(true);
  var player=new net.minecraft.client.player.LocalPlayer();var normal=new ItemStack(false);var cosmetic=new ItemStack(false);player.getInventory().armor.set(2,normal);
  var inv=(lain.mods.cos.impl.inventory.InventoryCosArmor)lain.mods.cos.api.CosArmorAPI.getCAStacksClient(player.getUUID());inv.setStackInSlot(2,cosmetic);
  var layer=new Layer();layer.expected=cosmetic;var pose=new PoseStack();run(layer,pose,player,EquipmentSlot.CHEST);check(layer.calls==0,"Off skips extra layer");
  inv.setHidden(OverlayChoice.MODID,OverlayChoice.FLAG,true);run(layer,pose,player,EquipmentSlot.CHEST);check(layer.calls==1,"On draws exactly one extra layer");check(player.getItemBySlot(EquipmentSlot.CHEST)==normal,"Original armor restored");check(pose.depth==0,"Pose restored");check(pose.scales==1,"Outer layer separated to reduce surface fighting");
  layer.fail=true;try{run(layer,pose,player,EquipmentSlot.CHEST);throw new AssertionError("Expected exception");}catch(IllegalStateException e){}check(player.getItemBySlot(EquipmentSlot.CHEST)==normal,"Render exception restores original inventory");check(pose.depth==0,"Render exception restores pose");layer.fail=false;
  inv.hidden[2]=true;int before=layer.calls;run(layer,pose,player,EquipmentSlot.CHEST);check(layer.calls==before,"Hidden slot skips cosmetic layer");inv.hidden[2]=false;
  inv.setStackInSlot(2,normal);run(layer,pose,player,EquipmentSlot.CHEST);check(layer.calls==before,"Identical appearances do not recurse or flicker");
  lain.mods.cos.impl.client.PlayerRenderHandler.Disabled=true;inv.setStackInSlot(2,cosmetic);run(layer,pose,player,EquipmentSlot.CHEST);check(layer.calls==before,"Existing client disable control respected");
  System.out.println("Passed "+checks+" overlay rendering checks");
 }
}
