import java.nio.file.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;
public class PatchCosArmor implements Opcodes {
 static int hooks;
 static byte[] patch(String file,byte[] data) {
  if(!file.equals("lain/mods/cos/impl/client/PlayerRenderHandler.class"))return data;
  var reader=new ClassReader(data);var writer=new ClassWriter(reader,ClassWriter.COMPUTE_MAXS);
  reader.accept(new ClassVisitor(ASM8,writer){
   public MethodVisitor visitMethod(int a,String n,String d,String s,String[] e){
    return new MethodVisitor(ASM8,super.visitMethod(a,n,d,s,e)){
     public void visitMethodInsn(int op,String owner,String name,String desc,boolean itf){
      if(owner.equals("lain/mods/cos/impl/ModConfigs")&&name.equals("getCosArmorStackRendering")) {
       super.visitVarInsn(ALOAD,1);super.visitMethodInsn(INVOKESTATIC,"lain/mods/cos/functional/OverlayChoice","enabled","(Ljava/lang/Object;)Z",false);hooks++;return;
      }super.visitMethodInsn(op,owner,name,desc,itf);
     }
     public void visitInsn(int op){if(op==RETURN&&n.equals("handlePreRenderPlayer")){super.visitVarInsn(ALOAD,1);super.visitMethodInsn(INVOKESTATIC,"lain/mods/cos/functional/OverlayChoice","finishPre","(Lnet/minecraft/world/entity/player/Player;)V",false);hooks++;}super.visitInsn(op);}
    };
   }
  },0);return writer.toByteArray();
 }
 public static void main(String[]a)throws Exception{
  try(var in=new ZipFile(a[0]);var out=new ZipOutputStream(Files.newOutputStream(Path.of(a[1])))){
   for(var it=in.entries();it.hasMoreElements();){var e=it.nextElement();if(e.isDirectory())continue;out.putNextEntry(new ZipEntry(e.getName()));out.write(patch(e.getName(),in.getInputStream(e).readAllBytes()));out.closeEntry();}
  }if(hooks!=4)throw new IllegalStateException("Expected 4 hooks, got "+hooks);System.out.println("Applied "+hooks+" rendering hooks");
 }
}
