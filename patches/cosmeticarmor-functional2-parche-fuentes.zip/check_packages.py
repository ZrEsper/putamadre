import zipfile,json,sys
from pathlib import Path
path=Path(sys.argv[1] if len(sys.argv)>1 else 'work/cosmeticarmorreworkedforked-neoforge-1.21.1-0.0.4-functional.2.jar')
with zipfile.ZipFile(path) as z:
 assert z.testzip() is None
 for name in z.namelist():
  if not name.endswith('mixins.json'):continue
  config=json.loads(z.read(name));prefix=config['package'].replace('.','/')+'/'
  for kind in ['mixins','client','server']:
   for cls in config.get(kind,[]):assert prefix+cls.replace('.','/')+'.class' in z.namelist(),cls
  for cls in z.namelist():
   if cls.startswith(prefix) and cls.endswith('.class'):
    outer=cls.split('$')[0]+'.class' if '$' in cls else cls
    b=z.read(outer);assert b'org/spongepowered/asm/mixin/Mixin' in b,(name,cls,'Non-mixin class in reserved package')
 for cls in ['OverlayUI','FunctionalArmor','OverlayChoice','FirstAidScope','OverlayButton']:
  path='lain/mods/cos/functional/'+cls+'.class';assert path in z.namelist()
 assert not any(n.startswith(('net/minecraft/','net/neoforged/','org/spongepowered/')) for n in z.namelist())
 print('All mixin packages contain only mixins; ordinary helpers/subscribers remain loadable')
