from pathlib import Path
import zipfile,json,hashlib
base=Path('work/cosarmor2');out=Path('work/cosmeticarmorreworkedforked-neoforge-1.21.1-0.0.4-functional.2.jar')
with zipfile.ZipFile(base/'base.jar') as z:data={n:z.read(n) for n in z.namelist()}
for p in (base/'classes').rglob('*.class'):
 n=str(p.relative_to(base/'classes'));assert n.startswith('lain/mods/cos/functional/');data[n]=p.read_bytes()
config=json.loads(data['cosmeticarmorreworkedforked.mixins.json']);config['client'].remove('HumanoidArmorLayerMixin');data['cosmeticarmorreworkedforked.mixins.json']=json.dumps(config,indent=2).encode()
data['cosmeticarmorreworkedforked-functional.mixins.json']=json.dumps({'required':True,'minVersion':'0.8','package':'lain.mods.cos.functional.mixin','compatibilityLevel':'JAVA_21','mixins':['FunctionalArmorMixin','FirstAidWearMixin'],'client':['MixedArmorLayerMixin'],'injectors':{'defaultRequire':1}},indent=2).encode()
s=data['META-INF/neoforge.mods.toml'].decode().replace('version = "1.21.1-0.0.4"','version = "1.21.1-0.0.4-functional.2"');s+='\n[[mixins]]\nconfig = "cosmeticarmorreworkedforked-functional.mixins.json"\n';data['META-INF/neoforge.mods.toml']=s.encode()
for lang in ['es_es','en_us']:
 n=f'assets/cosmeticarmorreworkedforked/lang/{lang}.json';j=json.loads(data[n]);j.update({'cosarmor.functional.overlay.on':'Superponer: Sí' if lang=='es_es' else 'Overlay: On','cosarmor.functional.overlay.off':'Superponer: No' if lang=='es_es' else 'Overlay: Off','cosarmor.functional.overlay.tooltip':'Muestra ambos conjuntos a la vez. Las dos ranuras aportan atributos aunque se oculten.' if lang=='es_es' else 'Show both armor sets together. Both slots grant attributes even when hidden.'});data[n]=json.dumps(j,ensure_ascii=False,indent=2).encode()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in data.items():z.writestr(n,b)
print(out,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
