package net.minecraft.world.entity.monster;
public class Zombie extends net.minecraft.world.entity.LivingEntity {
 public int tickCount=100; public int getId(){return 8;}
 public final Level level=new Level(); public Level level(){return level;}
 public static class Level {public boolean isClientSide=false;public byte last;public int sent;public void broadcastEntityEvent(Object entity,byte event){last=event;sent++;}}
}
