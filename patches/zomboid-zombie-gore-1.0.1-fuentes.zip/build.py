import zipfile,json,subprocess,hashlib
from pathlib import Path
r=Path('work/gore101');original=Path('attachments/d1a46eca-8b8c-4f63-8cc8-fc340c8b37d4/zomboid-zombie-gore-1.0.0-neoforge-1.21.1.jar');dest=r/'zomboid-zombie-gore-1.0.1-neoforge-1.21.1-tacz-melee-reactions.jar'
z=zipfile.ZipFile(original);assert z.testzip() is None
changed={}
for cls in ['BulletMixin','Events']:
 n=('dev/zomboid/gore/mixin/' if cls=='BulletMixin' else 'dev/zomboid/gore/')+cls+'.class';p=r/(cls+'.class');p.write_bytes(z.read(n));o=r/(cls+'-patched.class')
 subprocess.run(['java','--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED','-cp',str(r/'tools'),'Patch',str(p),str(o)],check=True);changed[n]=o.read_bytes()
config=json.loads(z.read('zomboid_gore.mixins.json'));config['mixins'].append('MeleeEventMixin');config['client']=['MeleePoseMixin'];changed['zomboid_gore.mixins.json']=(json.dumps(config,indent=2)+'\n').encode()
changed['META-INF/neoforge.mods.toml']=z.read('META-INF/neoforge.mods.toml').replace(b'version="1.0.0"',b'version="1.0.1"')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as w:
 for n in z.namelist():w.writestr(n,changed.get(n,z.read(n)))
 for p in (r/'classes/dev/zomboid/gore').rglob('*.class'):w.write(p,p.relative_to(r/'classes'))
with zipfile.ZipFile(dest) as w:
 assert w.testzip() is None
 for n in z.namelist():
  if n not in changed:assert w.read(n)==z.read(n)
subprocess.run(['java','--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/tools','Verify',str(dest)],check=True)
print(dest)
