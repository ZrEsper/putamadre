import java.nio.file.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public class PatchSiege {
 public static void main(String[] args)throws Exception{
 try(ZipFile in=new ZipFile(args[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(args[1])))){
 var files=in.entries();while(files.hasMoreElements()){var entry=files.nextElement();byte[] b=in.getInputStream(entry).readAllBytes();
 if(entry.getName().equals("dev/zomboid/reactive/Reactive.class")){
 ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);int changed=0;
 for(MethodNode m:c.methods){InsnList code=new InsnList();LabelNode old=new LabelNode();
 if(m.name.equals("sees")&&m.desc.equals("(Ljava/lang/Object;Ljava/lang/Object;)Z")){
 code.add(new VarInsnNode(Opcodes.ALOAD,0));code.add(new VarInsnNode(Opcodes.ALOAD,1));code.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"dev/zomboid/hordes/SiegeZombie","overrideSight","(Ljava/lang/Object;Ljava/lang/Object;)I",false));code.add(new InsnNode(Opcodes.DUP));code.add(new InsnNode(Opcodes.ICONST_M1));code.add(new JumpInsnNode(Opcodes.IF_ICMPEQ,old));code.add(new InsnNode(Opcodes.IRETURN));code.add(old);code.add(new FrameNode(Opcodes.F_SAME1,0,null,1,new Object[]{Opcodes.INTEGER}));code.add(new InsnNode(Opcodes.POP));m.instructions.insert(code);changed++;
 }else if(m.name.equals("speed")&&m.desc.equals("(ILjava/lang/Object;)D")){
 code.add(new VarInsnNode(Opcodes.ALOAD,1));code.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"dev/zomboid/hordes/SiegeZombie","isSiege","(Ljava/lang/Object;)Z",false));code.add(new JumpInsnNode(Opcodes.IFEQ,old));code.add(new LdcInsnNode(.56));code.add(new InsnNode(Opcodes.DRETURN));code.add(old);code.add(new FrameNode(Opcodes.F_SAME,0,null,0,null));m.instructions.insert(code);changed++;
 }}if(changed!=2)throw new IllegalStateException("Reactive hook mismatch "+changed);
 ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);b=w.toByteArray();
 }
 out.putNextEntry(new ZipEntry(entry.getName()));out.write(b);out.closeEntry();
 }
 for(String name:new String[]{"SiegeZombie","SiegeRules"}){out.putNextEntry(new ZipEntry("dev/zomboid/hordes/"+name+".class"));out.write(Files.readAllBytes(Path.of("work/siege6/classes/dev/zomboid/hordes/"+name+".class")));out.closeEntry();}
 }
 }
}
