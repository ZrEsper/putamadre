package dev.zomboid.hordes;
import java.util.*;
import java.nio.file.*;
import java.io.*;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.network.chat.Component;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
@EventBusSubscriber(modid="zomboid_hordes")
public final class SiegeZombie {
 private static final double CHANCE;
 private static final boolean BREAK,BUILD;
 private static final int BUDGET;
 static {
  Properties p=new Properties();Path file=Path.of("config/zomboid-hordes-siege.properties");
  p.setProperty("spawnChance","0.00005");p.setProperty("breakBlocks","true");p.setProperty("buildBlocks","true");p.setProperty("maxBuildBlocksPerZombie","128");
  try {if(Files.exists(file)){try(InputStream in=Files.newInputStream(file)){p.load(in);}}else{Files.createDirectories(file.getParent());try(OutputStream out=Files.newOutputStream(file)){p.store(out,"Asediador: 0.00005 = 1 in 20000 eligible adult zombies. Restart server after editing.");}}}catch(IOException e){System.err.println("[Zomboid Hordes] Cannot read/write siege configuration: "+e.getMessage());}
  double c=.00005;int b=128;try{c=Double.parseDouble(p.getProperty("spawnChance"));b=Integer.parseInt(p.getProperty("maxBuildBlocksPerZombie"));}catch(NumberFormatException e){System.err.println("[Zomboid Hordes] Invalid siege number; using defaults.");}
  CHANCE=Double.isFinite(c)?Math.max(0,Math.min(.01,c)):.00005;BUDGET=Math.max(0,Math.min(512,b));BREAK=Boolean.parseBoolean(p.getProperty("breakBlocks"));BUILD=Boolean.parseBoolean(p.getProperty("buildBlocks"));
 }
 @SubscribeEvent(priority=EventPriority.LOWEST)
 public static void tick(EntityTickEvent.Post event){
  if(!(event.getEntity() instanceof Zombie z)||!(z.level() instanceof ServerLevel l)||!z.isAlive()||z.isBaby())return;
  CompoundTag d=z.getPersistentData();
  if(!d.getBoolean("zh_siege_checked")){
   d.putBoolean("zh_siege_checked",true);
   if(SiegeRules.selected(z.getRandom().nextDouble(),CHANCE)){
    d.putBoolean("zh_siege",true);d.putDouble("zh_siege_vision",SiegeRules.vision(z.getRandom().nextDouble()));
    d.putInt("zh_siege_memory",SiegeRules.memory(z.getRandom().nextDouble()));d.putDouble("zh_siege_anger",SiegeRules.aggression(z.getRandom().nextDouble()));
    attribute(z,Attributes.MAX_HEALTH,300);z.setHealth(z.getMaxHealth());
    z.setCustomName(Component.literal("Asediador"));z.setCustomNameVisible(false);
   }
  }
  if(!d.getBoolean("zh_siege")||z.tickCount%4!=0)return;
  // Reassert total values after day/night and individual personality modifiers.
  total(z,Attributes.MAX_HEALTH,300);if(z.getHealth()>z.getMaxHealth())z.setHealth(z.getMaxHealth());total(z,Attributes.MOVEMENT_SPEED,.56);total(z,Attributes.ATTACK_DAMAGE,24);total(z,Attributes.FOLLOW_RANGE,d.getDouble("zh_siege_vision"));
  long now=l.getGameTime();LivingEntity target=z.getTarget();
  if(target==null&&d.hasUUID("zh_siege_target")){
   Entity saved=l.getEntity(d.getUUID("zh_siege_target"));if(saved instanceof LivingEntity living)target=living;
  }
  if(target instanceof Player p&&(p.isCreative()||p.isSpectator()))target=null;
  if(target!=null&&(!target.isAlive()||target.level()!=l||z.distanceToSqr(target)>128*128))target=null;
  if(target!=null&&z.hasLineOfSight(target))d.putLong("zh_siege_seen",now);
  if(target!=null&&now-d.getLong("zh_siege_seen")>d.getInt("zh_siege_memory"))target=null;
  if(target==null&&z.tickCount%20==0){
   double best=d.getDouble("zh_siege_vision");best*=best;
   for(ServerPlayer p:l.players()){
    if(p.isCreative()||p.isSpectator()||!p.isAlive())continue;
    double range=d.getDouble("zh_siege_vision");if(l.getMaxLocalRawBrightness(BlockPos.containing(p.getX(),p.getEyeY(),p.getZ()))<5)range*=.55;
    if(p.isShiftKeyDown())range*=.6;
    double dist=z.distanceToSqr(p);
    if(dist<best&&dist<range*range&&z.hasLineOfSight(p)&&z.getRandom().nextDouble()<d.getDouble("zh_siege_anger")){target=p;best=dist;}
   }
   if(target!=null)d.putLong("zh_siege_seen",now);
  }
  z.setTarget(target);
  if(target==null){clearCracks(z,l,d);d.remove("zh_siege_target");return;}
  d.putUUID("zh_siege_target",target.getUUID());
  z.getLookControl().setLookAt(target,30,30);
  if(z.tickCount%20==0)z.getNavigation().moveTo(target,1.15);
  double dx=target.getX()-z.getX(),dz=target.getZ()-z.getZ();double len=Math.sqrt(dx*dx+dz*dz);if(len<.15){if(target.getY()<=z.getY()+1.2)return;dx=0;dz=1;}else{dx/=len;dz/=len;}
  boolean stuck=z.horizontalCollision||z.getNavigation().isDone();
  if(!stuck && target.getY()<z.getY()+1.2){clearCracks(z,l,d);return;}
  if(!l.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)){clearCracks(z,l,d);return;}
  BlockPos feet=BlockPos.containing(z.getX(),z.getY(),z.getZ());BlockPos front=BlockPos.containing(z.getX()+dx*.9,z.getY()+.1,z.getZ()+dz*.9);
  if(!l.hasChunkAt(front)||!l.hasChunkAt(front.above()))return;
  if(BUILD&&target.getY()>z.getY()+1.2&&now>=d.getLong("zh_siege_build_at")&&d.getInt("zh_siege_built")<BUDGET&&!front.equals(feet)&&l.isEmptyBlock(front)&&l.isEmptyBlock(front.above())&&!l.isEmptyBlock(front.below())){
   Rotation rotation=Math.abs(dx)>Math.abs(dz)?(dx>0?Rotation.CLOCKWISE_90:Rotation.COUNTERCLOCKWISE_90):(dz>0?Rotation.CLOCKWISE_180:Rotation.NONE);
   if(placeState(z,l,d,front,now,Blocks.COBBLESTONE_STAIRS.defaultBlockState().rotate(rotation))){z.setDeltaMovement(dx*.20,.46,dz*.20);return;}
  }
  BlockPos obstruction=!l.getBlockState(front.above()).isAir()?front.above():!l.getBlockState(front).isAir()?front:null;
  // Step over a single low block when the two blocks above it are free.
  if(obstruction!=null&&obstruction.equals(front)&&l.isEmptyBlock(front.above())&&l.isEmptyBlock(front.above().above())&&z.onGround()){
   clearCracks(z,l,d);z.setDeltaMovement(dx*.20,.46,dz*.20);return;
  }
  if(obstruction!=null&&BREAK){
   BlockState wall=l.getBlockState(obstruction);
   if(SiegeRules.breakable(wall.getDestroySpeed(l,obstruction),wall.hasBlockEntity(),!wall.getFluidState().isEmpty())){breakBlock(z,l,d,obstruction,now);return;}
   // Protected or exceptionally hard walls: try a flank instead of punching forever.
   if(z.tickCount%20==0){int side=((z.getId()&1)==0?1:-1);for(int attempt=0;attempt<2;attempt++,side=-side){
    BlockPos detour=BlockPos.containing(z.getX()-dz*side*2+dx,z.getY(),z.getZ()+dx*side*2+dz);
    if(l.hasChunkAt(detour)&&l.isEmptyBlock(detour)&&l.isEmptyBlock(detour.above())){z.getNavigation().moveTo(detour.getX()+.5,detour.getY(),detour.getZ()+.5,1.15);break;}
   }}
   if(target.getY()<=z.getY()+1.2){clearCracks(z,l,d);return;}
  }
  clearCracks(z,l,d);
  if(!BUILD||now<d.getLong("zh_siege_build_at")||d.getInt("zh_siege_built")>=BUDGET)return;
  // Tower upwards, then bridge, using normal collision/placement rather than teleportation.
  if(target.getY()>z.getY()+1.2){
   if(l.isEmptyBlock(feet.above())&&l.isEmptyBlock(feet.above().above())){
    if(z.onGround()){z.setDeltaMovement(dx*.08,.46,dz*.08);return;}
    BlockPos floor=BlockPos.containing(z.getX(),z.getY()-.8,z.getZ());
    if(floor.getY()>=feet.getY()-1&&z.getY()-floor.getY()>=1.0)place(z,l,d,floor,now);
   }
  }else if(l.isEmptyBlock(front.below())&&!l.isEmptyBlock(feet.below()))place(z,l,d,front.below(),now);
 }
 public static boolean isSiege(Object mob){return mob instanceof Zombie z && z.getPersistentData().getBoolean("zh_siege");}
 public static int overrideSight(Object mob,Object player){
  if(!isSiege(mob))return -1;
  Zombie z=(Zombie)mob;if(!(player instanceof Player p)||p.isCreative()||p.isSpectator()||!p.isAlive()||p.level()!=z.level())return 0;
  CompoundTag d=z.getPersistentData();long now=z.level().getGameTime();
  if(d.hasUUID("zh_siege_target")&&d.getUUID("zh_siege_target").equals(p.getUUID())&&now-d.getLong("zh_siege_seen")<=d.getInt("zh_siege_memory")&&z.distanceToSqr(p)<128*128)return 1;
  double range=d.getDouble("zh_siege_vision");if(z.level().getMaxLocalRawBrightness(BlockPos.containing(p.getX(),p.getEyeY(),p.getZ()))<5)range*=.55;
  if(p.isShiftKeyDown())range*=.6;
  return z.distanceToSqr(p)<range*range&&z.hasLineOfSight(p)?1:0;
 }
 @SubscribeEvent public static void died(net.neoforged.neoforge.event.entity.living.LivingDeathEvent e){if(e.getEntity() instanceof Zombie z&&z.level() instanceof ServerLevel l&&isSiege(z))clearCracks(z,l,z.getPersistentData());}
 private static void attribute(Zombie z,net.minecraft.core.Holder<Attribute> key,double value){AttributeInstance a=z.getAttribute(key);if(a!=null)a.setBaseValue(value);}
 private static void total(Zombie z,net.minecraft.core.Holder<Attribute> key,double value){AttributeInstance a=z.getAttribute(key);if(a!=null&&a.getValue()>0&&Math.abs(a.getValue()-value)>.01)a.setBaseValue(Math.max(.01,a.getBaseValue()*value/a.getValue()));}
 private static void clearCracks(Zombie z,ServerLevel l,CompoundTag d){if(d.contains("zh_siege_bx")){l.destroyBlockProgress(z.getId(),new BlockPos(d.getInt("zh_siege_bx"),d.getInt("zh_siege_by"),d.getInt("zh_siege_bz")),-1);d.remove("zh_siege_bx");}}
 private static void breakBlock(Zombie z,ServerLevel l,CompoundTag d,BlockPos p,long now){
  BlockState state=l.getBlockState(p);float hardness=state.getDestroySpeed(l,p);
  if(!SiegeRules.breakable(hardness,state.hasBlockEntity(),!state.getFluidState().isEmpty())){clearCracks(z,l,d);return;}
  if(!d.contains("zh_siege_bx")||d.getInt("zh_siege_bx")!=p.getX()||d.getInt("zh_siege_by")!=p.getY()||d.getInt("zh_siege_bz")!=p.getZ()){
   clearCracks(z,l,d);d.putInt("zh_siege_bx",p.getX());d.putInt("zh_siege_by",p.getY());d.putInt("zh_siege_bz",p.getZ());d.putLong("zh_siege_break_start",now);
  }
  int need=SiegeRules.breakTicks(hardness);long elapsed=now-d.getLong("zh_siege_break_start");
  l.destroyBlockProgress(z.getId(),p,Math.min(9,(int)(elapsed*10/need)));
  if(z.tickCount%12==0){z.swing(InteractionHand.MAIN_HAND);z.playSound(SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR,.8f,.75f);}
  if(elapsed>=need){l.destroyBlock(p,true,z);clearCracks(z,l,d);z.getNavigation().moveTo(z.getTarget(),1.15);}
 }
 private static void place(Zombie z,ServerLevel l,CompoundTag d,BlockPos p,long now){placeState(z,l,d,p,now,Blocks.COBBLESTONE.defaultBlockState());}
 private static boolean placeState(Zombie z,ServerLevel l,CompoundTag d,BlockPos p,long now,BlockState state){
  if(!l.hasChunkAt(p)||!l.isEmptyBlock(p)||!l.getBlockState(p).getFluidState().isEmpty())return false;
  if(l.setBlock(p,state,3)){
   d.putInt("zh_siege_built",d.getInt("zh_siege_built")+1);d.putLong("zh_siege_build_at",now+20);z.swing(InteractionHand.MAIN_HAND);z.playSound(SoundEvents.STONE_PLACE,.8f,.7f);z.getNavigation().moveTo(z.getTarget(),1.15);return true;
  }
  return false;
 }
}
