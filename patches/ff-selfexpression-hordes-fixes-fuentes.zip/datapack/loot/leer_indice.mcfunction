$data modify storage mosslorn:runtime work set from storage mosslorn:registro cofres[$(i)]
