execute if score #loot_cursor ml_tmp >= #loot_total ml_tmp run function mosslorn:loot/nueva_vuelta
execute if score #loot_cursor ml_tmp < #loot_total ml_tmp run function mosslorn:loot/siguiente
