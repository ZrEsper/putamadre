data modify storage mosslorn:runtime work set value {}
execute store result storage mosslorn:runtime loot_pointer.i int 1 run scoreboard players get #loot_cursor ml_tmp
function mosslorn:loot/leer_indice with storage mosslorn:runtime loot_pointer
scoreboard players add #loot_cursor ml_tmp 1
execute store result storage mosslorn:runtime work.epoca int 1 run scoreboard players get #epoca ml_config
execute store result score #prev ml_tmp run data get storage mosslorn:runtime work.ultima
execute if data storage mosslorn:runtime work.tabla if score #prev ml_tmp < #epoca ml_config run function mosslorn:loot/visitar with storage mosslorn:runtime work
