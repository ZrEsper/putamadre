scoreboard players set #loot_cursor ml_tmp 0
scoreboard players set #loot_total ml_tmp 0
execute store result score #loot_total ml_tmp run data get storage mosslorn:registro cofres
function mosslorn:loot/contadores
