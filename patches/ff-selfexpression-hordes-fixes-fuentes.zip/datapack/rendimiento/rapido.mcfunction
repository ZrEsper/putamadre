scoreboard players set #scan_budget ml_config 512
scoreboard players set #loot_batch ml_config 4
scoreboard players set #force_index_batch ml_config 64
scoreboard players set #force_reset_batch ml_config 8
tellraw @s {"text":"Rendimiento del datapack: rapido. Registro y progreso conservados.","color":"green"}
