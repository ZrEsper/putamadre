scoreboard players set #scan_budget ml_config 64
scoreboard players set #loot_batch ml_config 1
scoreboard players set #force_index_batch ml_config 2
scoreboard players set #force_reset_batch ml_config 1
tellraw @s {"text":"Rendimiento del datapack: ligero. Registro y progreso conservados.","color":"green"}
