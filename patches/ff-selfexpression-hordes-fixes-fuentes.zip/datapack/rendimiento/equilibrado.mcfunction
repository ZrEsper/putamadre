scoreboard players set #scan_budget ml_config 128
scoreboard players set #loot_batch ml_config 2
scoreboard players set #force_index_batch ml_config 4
scoreboard players set #force_reset_batch ml_config 2
tellraw @s {"text":"Rendimiento del datapack: equilibrado. Registro y progreso conservados.","color":"green"}
