execute unless data storage mosslorn:force chunks run return 0
scoreboard players add #force_clock ml_tmp 1
execute if score #force_index_batch ml_config matches 1.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 2.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 3.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 4.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 5.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 6.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 7.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 8.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 9.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 10.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 11.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 12.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 13.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 14.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 15.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 16.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 17.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 18.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 19.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 20.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 21.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 22.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 23.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 24.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 25.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 26.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 27.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 28.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 29.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 30.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 31.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 32.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 33.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 34.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 35.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 36.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 37.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 38.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 39.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 40.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 41.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 42.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 43.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 44.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 45.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 46.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 47.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 48.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 49.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 50.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 51.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 52.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 53.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 54.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 55.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 56.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 57.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 58.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 59.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 60.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 61.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 62.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 63.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_index_batch ml_config matches 64.. if score #force_build ml_tmp matches 1 run function mosslorn:force/index_step
execute if score #force_build ml_tmp matches 1 if score #fi ml_tmp >= #ftotal ml_tmp run function mosslorn:force/listo
execute if score #force_build ml_tmp matches 1 if score #force_clock ml_tmp matches 100.. run tellraw @a [{"text":"Preparando reinicio: ","color":"yellow"},{"score":{"name":"#fi","objective":"ml_tmp"}},{"text":" / "},{"score":{"name":"#ftotal","objective":"ml_tmp"}}]
execute if score #force_clock ml_tmp matches 100.. run scoreboard players set #force_clock ml_tmp 0
execute if score #force_build ml_tmp matches 1 run return 0
execute if score #force_clock ml_tmp matches 10.. unless data storage mosslorn:force queue[0] as @a at @s run function mosslorn:force/cerca
execute if score #force_clock ml_tmp matches 10.. run scoreboard players set #force_clock ml_tmp 0
execute if score #force_reset_batch ml_config matches 1.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 2.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 3.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 4.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 5.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 6.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 7.. run function mosslorn:force/reset_step
execute if score #force_reset_batch ml_config matches 8.. run function mosslorn:force/reset_step
