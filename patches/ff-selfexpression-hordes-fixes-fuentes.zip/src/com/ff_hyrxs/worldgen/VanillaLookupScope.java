package com.ff_hyrxs.worldgen;
public final class VanillaLookupScope {
 public static boolean active(){return StackWalker.getInstance().walk(frames->frames.anyMatch(f->f.getClassName().equals("net.minecraft.data.registries.VanillaRegistries")||f.getClassName().equals("net.minecraft.server.Bootstrap")&&f.getMethodName().equals("validate")));}
}
