package net.mcreator.selfexpression.client;
import java.lang.reflect.*;import java.util.*;
public final class ArmorCacheEpoch {
 private static Method instanceMethod,modelsMethod;
 private static Object lastSet,lastRoots;private static Field rootsField;private static long epoch;
 public static long current(){try{if(instanceMethod==null){Class<?> mc=Class.forName("net.minecraft.client.Minecraft");instanceMethod=mc.getMethod("getInstance");modelsMethod=mc.getMethod("getEntityModels");}Object game=instanceMethod.invoke(null);Object set=modelsMethod.invoke(game);if(set!=lastSet){lastSet=set;rootsField=null;}if(rootsField==null){for(Class<?> c=set.getClass();c!=null&&rootsField==null;c=c.getSuperclass())for(Field f:c.getDeclaredFields())if(!Modifier.isStatic(f.getModifiers())&&Map.class.isAssignableFrom(f.getType())){f.setAccessible(true);rootsField=f;break;}}Object roots=rootsField==null?set:rootsField.get(set);if(roots!=lastRoots){lastRoots=roots;epoch++;}return epoch;}catch(ReflectiveOperationException error){throw new IllegalStateException("Cannot track armor model resource reload",error);}}
}
