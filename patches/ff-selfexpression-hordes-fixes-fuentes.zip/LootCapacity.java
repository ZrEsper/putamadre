package dev.zomboid.hordes;
import java.util.*;import net.minecraft.util.RandomSource;
public final class LootCapacity{
 public static <T> List<T> fit(List<T> generated,int slots,RandomSource random){int capacity=Math.max(0,slots);if(generated.size()<=capacity)return generated;if(capacity==0){generated.clear();return generated;}ArrayList<T> kept=new ArrayList<>(generated);for(int i=kept.size()-1;i>0;i--){int j=random.nextInt(i+1);T item=kept.get(i);kept.set(i,kept.get(j));kept.set(j,item);}generated.clear();generated.addAll(kept.subList(0,capacity));return generated;}
}
