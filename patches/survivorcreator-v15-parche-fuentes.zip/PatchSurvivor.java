import java.nio.file.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;
public class PatchSurvivor implements Opcodes {
 static final String H="dev/survivorcreator/hearing/";static int hooks;
 static byte[] patch(String file,byte[] bytes){
  ClassReader reader=new ClassReader(bytes);ClassWriter writer=new ClassWriter(reader,ClassWriter.COMPUTE_MAXS);
  reader.accept(new ClassVisitor(ASM8,writer){
   public void visit(int v,int a,String n,String s,String p,String[] i){super.visit(v,a,n,s,p,i);if(file.equals("dev/survivorcreator/ModSounds.class"))super.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL,"CREATION_MUSIC","Ljava/util/function/Supplier;","Ljava/util/function/Supplier<Lnet/minecraft/sounds/SoundEvent;>;",null).visitEnd();}
   public MethodVisitor visitMethod(int a,String n,String d,String s,String[] e){
    MethodVisitor m=super.visitMethod(a,n,d,s,e);String replace=null;
    if(file.equals("dev/survivorcreator/client/ClientHooks.class")&&n.equals("beginCreationAudio"))replace="begin";
    if(file.equals("dev/survivorcreator/client/ClientHooks.class")&&n.equals("playEndingMusic"))replace="track";
    if(file.equals("dev/survivorcreator/client/DeathAudio.class")&&n.equals("menuMusic"))replace="start";
    if(replace!=null){m.visitCode();m.visitMethodInsn(INVOKESTATIC,H+"CreationAudio",replace,d,false);m.visitInsn(d.endsWith("V")?RETURN:ARETURN);m.visitMaxs(1,0);m.visitEnd();hooks++;return null;}
    if(file.equals("dev/survivorcreator/skills/LevelUpQueue.class")&&n.equals("scale")){
      m.visitCode();m.visitVarInsn(ALOAD,0);m.visitVarInsn(ALOAD,1);m.visitVarInsn(DLOAD,2);m.visitMethodInsn(INVOKESTATIC,H+"XpRules","scale",d,false);m.visitInsn(DRETURN);m.visitMaxs(4,4);m.visitEnd();hooks++;return null;
    }
    return new MethodVisitor(ASM8,m){
      public void visitInsn(int op){
       if(op==RETURN&&file.equals("dev/survivorcreator/SurvivorCreator.class")&&n.equals("<init>")){super.visitVarInsn(ALOAD,1);super.visitMethodInsn(INVOKESTATIC,H+"HearingEffects","register","(Lnet/neoforged/bus/api/IEventBus;)V",false);hooks++;}
       if(op==RETURN&&file.equals("dev/survivorcreator/ModSounds.class")&&n.equals("<clinit>")){super.visitLdcInsn("creation_music");super.visitMethodInsn(INVOKESTATIC,"dev/survivorcreator/ModSounds","register","(Ljava/lang/String;)Ljava/util/function/Supplier;",false);super.visitFieldInsn(PUTSTATIC,"dev/survivorcreator/ModSounds","CREATION_MUSIC","Ljava/util/function/Supplier;");hooks++;}
       if(op==RETURN&&file.equals("dev/survivorcreator/skills/SkillSnapshot.class")&&n.equals("accept")){super.visitVarInsn(ALOAD,0);super.visitMethodInsn(INVOKESTATIC,H+"ProgressHud","accept","(Ljava/lang/String;)V",false);hooks++;}
       super.visitInsn(op);
      }
    };
   }
  },0);return writer.toByteArray();
 }
 public static void main(String[]args)throws Exception {
  try(ZipFile in=new ZipFile(args[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(args[1])))){
   for(var it=in.entries();it.hasMoreElements();){var e=it.nextElement();if(e.isDirectory())continue;byte[] b=in.getInputStream(e).readAllBytes();if(e.getName().endsWith(".class"))b=patch(e.getName(),b);out.putNextEntry(new ZipEntry(e.getName()));out.write(b);out.closeEntry();}
  }if(hooks!=7)throw new IllegalStateException("Unexpected hooks "+hooks);System.out.println("Applied "+hooks+" hooks");
 }
}
