package dev.survivorcreator.hearing;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
@EventBusSubscriber(modid="survivorcreator",value=Dist.CLIENT)
public final class ProgressHud {
    private static final ProgressModel MODEL=new ProgressModel();
    public static void clear(){MODEL.clear();}
    public static void reset(){MODEL.reset();}
    public static void accept(String json) {
        try {
            var mc=Minecraft.getInstance();
            if(mc.player==null) { reset(); return; }
            var data=com.google.gson.JsonParser.parseString(json).getAsJsonObject();
            String uuid=data.get("player").getAsString();
            if(!uuid.equals(mc.player.getUUID().toString())) return;
            var rows=new java.util.ArrayList<ProgressModel.Row>();
            for(var element:data.getAsJsonArray("rows")) {
                var row=element.getAsJsonObject(); String id=row.get("id").getAsString();
                var skill=dev.survivorcreator.skills.Skills.get(id); if(skill==null) continue;
                double xp=row.get("xp").getAsDouble(); int level=row.get("level").getAsInt();
                rows.add(new ProgressModel.Row(id,xp,level,skill.xpForLevel(level+1),skill.maxLevel()));
            }
            MODEL.accept(uuid,rows,!CreationAudio.menu() && mc.player.isAlive(),System.currentTimeMillis());
        } catch(RuntimeException invalidPayload) { reset(); }
    }
    @SubscribeEvent public static void draw(net.neoforged.neoforge.client.event.RenderGuiEvent.Post event) {
        var mc=Minecraft.getInstance();
        if(mc.player==null || mc.screen!=null || mc.options.hideGui || !mc.player.isAlive()) return;
        long now=System.currentTimeMillis(); var notices=MODEL.notices(now);
        if(notices.isEmpty()) return;
        var gui=event.getGuiGraphics(); float scale=.8f;
        gui.pose().pushPose(); gui.pose().scale(scale,scale,1f);
        int y=(int)((gui.guiHeight()-76)/scale);
        for(var notice:notices) {
            var skill=dev.survivorcreator.skills.Skills.get(notice.id); if(skill==null) continue;
            String tail=notice.maximum?Component.translatable("hud.survivorcreator.xp.maximum").getString():Component.translatable("hud.survivorcreator.xp.remaining",ProgressModel.number(notice.remaining)).getString();
            String text="↑ "+skill.name().getString()+" +"+ProgressModel.number(notice.gain)+" · "+tail;
            int alpha=(int)(255*Math.min(1,(2500-(now-notice.updated))/450.0));
            if(alpha>3) gui.drawString(mc.font,text,(int)(gui.guiWidth()/scale-mc.font.width(text))/2,y,(alpha<<24)|0x78db83,true);
            y-=12;
        }
        gui.pose().popPose();
    }
}
