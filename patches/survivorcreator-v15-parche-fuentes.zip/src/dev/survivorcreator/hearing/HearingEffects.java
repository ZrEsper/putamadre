package dev.survivorcreator.hearing;
import net.minecraft.world.effect.*;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.registries.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
@EventBusSubscriber(modid="survivorcreator")
public final class HearingEffects {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(net.minecraft.core.registries.Registries.MOB_EFFECT,"survivorcreator");
    public static final DeferredHolder<MobEffect,DeafnessEffect> DEAFNESS = EFFECTS.register("deafness",DeafnessEffect::new);
    public static void register(net.neoforged.bus.api.IEventBus bus) { EFFECTS.register(bus); }
    public static void set(net.minecraft.world.entity.LivingEntity player,int amplifier,int duration,boolean icon) {
        MobEffectInstance current = player.getEffect(DEAFNESS);
        if(current != null && current.getAmplifier()==amplifier && (current.getDuration()==-1 || current.getDuration()>40)) return;
        if(current!=null) player.removeEffect(DEAFNESS);
        player.addEffect(new MobEffectInstance(DEAFNESS,duration,amplifier,false,false,icon));
    }
    @SubscribeEvent public static void death(net.neoforged.neoforge.event.entity.living.LivingDeathEvent event) {
        if(event.getEntity() instanceof ServerPlayer p) set(p,2,100,false);
    }
    @SubscribeEvent public static void tick(net.neoforged.neoforge.event.tick.PlayerTickEvent.Post event) {
        if(!(event.getEntity() instanceof ServerPlayer p) || p.tickCount%20!=0) return;
        var data=((net.neoforged.neoforge.attachment.IAttachmentHolder)p).getData(dev.survivorcreator.SurvivorCreator.CHARACTER.get());
        if(!p.isAlive() || !data.completed()) { set(p,2,100,false); return; }
        var current=p.getEffect(DEAFNESS);
        if(current!=null && current.getAmplifier()>=2) p.removeEffect(DEAFNESS);
        if(HearingRules.hearingPerk(data)) set(p,1,-1,true);
    }
}
