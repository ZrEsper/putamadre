package dev.survivorcreator.hearing;
public final class DeafnessEffect extends net.minecraft.world.effect.MobEffect {
    public DeafnessEffect() { super(net.minecraft.world.effect.MobEffectCategory.HARMFUL, 0x8b9ba8); }
}
