package dev.survivorcreator.hearing;
import java.util.*;
public final class ProgressModel {
    public record Row(String id,double xp,int level,double next,int maximum) {}
    public static final class Notice {
        public final String id;
        public double gain,remaining;
        public boolean maximum;
        public long updated;
        Notice(Row row,double delta,long now) { id=row.id; update(row,delta,now); }
        void update(Row row,double delta,long now) { gain+=delta; remaining=Math.max(0,row.next-row.xp); maximum=row.level>=row.maximum; updated=now; }
    }
    private final Map<String,Double> previous=new HashMap<>();
    private final LinkedHashMap<String,Notice> notices=new LinkedHashMap<>();
    private String player="";
    public void accept(String owner,List<Row> rows,boolean show,long now) {
        expire(now);
        if(!owner.equals(player)) { reset(); player=owner; }
        for(var row:rows) {
            if(!Double.isFinite(row.xp)||row.xp<0) continue;
            Double old=previous.put(row.id,row.xp);
            if(!show || old==null || row.xp<old) { notices.remove(row.id); continue; }
            double delta=row.xp-old;
            if(delta<=1e-9) continue;
            Notice notice=notices.remove(row.id);
            if(notice==null) notice=new Notice(row,delta,now); else notice.update(row,delta,now);
            notices.put(row.id,notice);
            while(notices.size()>3) notices.remove(notices.keySet().iterator().next());
        }
        if(!show) clear();
    }
    public void expire(long now) { notices.values().removeIf(n->now-n.updated>2500); }
    public List<Notice> notices(long now) { expire(now); return new ArrayList<>(notices.values()); }
    public void clear(){notices.clear();}
    public void reset(){previous.clear();notices.clear();player="";}
    public static String number(double value) {
        if(Math.abs(value-Math.rint(value))<.00001) return String.format(Locale.ROOT,"%.0f",value);
        return String.format(Locale.ROOT,"%.3f",value).replaceAll("0+$","").replaceAll("\\.$","");
    }
}
