package dev.survivorcreator.hearing;
public final class XpRules {
    // The global multiplier is applied once by Skills.addXp, after this scaling.
    public static double scale(net.minecraft.server.level.ServerPlayer p,dev.survivorcreator.skills.Skill s,double amount) {
        if(s==null || !Double.isFinite(amount) || amount<=0 || dev.survivorcreator.GraceProtection.active(p)) return 0;
        return dev.survivorcreator.skills.ProgressRules.scale(s.id(),dev.survivorcreator.skills.Skills.level(p,s),amount);
    }
}
