package dev.survivorcreator.hearing;
public final class HearingRules {
    public static float volume(int level) { return switch (level) { case 1 -> .75f; case 2 -> .5f; case 3 -> 0f; default -> 1f; }; }
    public static boolean hearingPerk(dev.survivorcreator.data.CharacterData data) {
        return data != null && data.perks().stream().anyMatch(id -> id.getNamespace().equals("survivorcreator") && (id.getPath().equals("hard_of_hearing") || id.getPath().equals("deafness")));
    }
}
