package dev.survivorcreator.mixin;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import net.minecraft.sounds.SoundSource;
@Mixin(targets="net.minecraft.client.sounds.SoundEngine",remap=false)
public abstract class HearingSoundMixin {
    @Unique private int survivorcreator$audioState=-1;
    @Shadow public abstract void updateCategoryVolume(SoundSource source,float volume);
    @Inject(method="calculateVolume(FLnet/minecraft/sounds/SoundSource;)F",at=@At("RETURN"),cancellable=true,require=1,remap=false)
    private void survivorcreator$volume(float volume,SoundSource source,CallbackInfoReturnable<Float> callback) {
        callback.setReturnValue(callback.getReturnValueF()*dev.survivorcreator.hearing.CreationAudio.volume(source));
    }
    @Inject(method="play(Lnet/minecraft/client/resources/sounds/SoundInstance;)V",at=@At("HEAD"),cancellable=true,require=1,remap=false)
    private void survivorcreator$silent(net.minecraft.client.resources.sounds.SoundInstance sound,CallbackInfo callback) {
        if(dev.survivorcreator.hearing.CreationAudio.volume(sound.getSource())==0f) callback.cancel();
    }
    @Inject(method="tick(Z)V",at=@At("HEAD"),require=1,remap=false)
    private void survivorcreator$refresh(boolean paused,CallbackInfo callback) {
        int state=dev.survivorcreator.hearing.CreationAudio.level()+(dev.survivorcreator.hearing.CreationAudio.menu()?10:0);
        if(state!=survivorcreator$audioState) {
            survivorcreator$audioState=state;
            // Refresh sounds already playing, not only newly created sounds.
            updateCategoryVolume(SoundSource.AMBIENT,1f);
        }
    }
}
