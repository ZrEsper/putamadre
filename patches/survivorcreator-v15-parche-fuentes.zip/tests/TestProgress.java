import dev.survivorcreator.hearing.*;import java.util.*;
public class TestProgress {
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static ProgressModel.Row r(String id,double xp,int level){return new ProgressModel.Row(id,xp,level,level==0?30:80,10);}
 public static void main(String[]args){
  var model=new ProgressModel();model.accept("p",List.of(r("fitness",0,0)),true,0);check(model.notices(0).isEmpty(),"No initial fake XP");
  model.accept("p",List.of(r("fitness",.02,0)),true,1000);var n=model.notices(1000).get(0);check(Math.abs(n.gain-.02)<1e-9,"Fractional XP retained");check(Math.abs(n.remaining-29.98)<1e-9,"Remaining XP exact");check(ProgressModel.number(n.gain).equals("0.02"),"No +0 rounding");
  model.accept("p",List.of(r("fitness",2,0)),true,1500);check(model.notices(1500).size()==1,"Continuous actions merge");check(model.notices(1500).get(0).gain==2,"Merged gains equal actual delta");
  model.accept("p",List.of(r("fitness",32,1)),true,2000);check(model.notices(2000).get(0).remaining==48,"Level crossing uses next threshold");
  check(model.notices(4501).isEmpty(),"Toast expires");
  model.accept("p",List.of(r("fitness",0,0)),true,4600);check(model.notices(4600).isEmpty(),"Death reset does not create gain");
  model.accept("p",List.of(r("fitness",10,0)),false,4700);check(model.notices(4700).isEmpty(),"Character creation hides initial allocations");
  model.accept("p",List.of(r("fitness",12,0)),true,4800);check(model.notices(4800).get(0).gain==2,"Baseline stays current during menus");
  model.accept("another",List.of(r("fitness",100,2)),true,4900);check(model.notices(4900).isEmpty(),"World/player change clears baseline");
  model.reset();model.accept("p",List.of(r("a",0,0),r("b",0,0),r("c",0,0),r("d",0,0)),true,0);model.accept("p",List.of(r("a",1,0),r("b",1,0),r("c",1,0),r("d",1,0)),true,1000);check(model.notices(1000).size()==3,"HUD remains bounded");
  check(HearingRules.volume(0)==1,"Normal hearing");check(HearingRules.volume(1)==.75f,"Level I 25 percent quieter");check(HearingRules.volume(2)==.5f,"Level II 50 percent quieter");check(HearingRules.volume(3)==0,"Level III silent");
  check(ProgressModel.number(2).equals("2"),"Integer gain format");
  System.out.println("Passed "+checks+" progression/hearing checks");
 }
}
