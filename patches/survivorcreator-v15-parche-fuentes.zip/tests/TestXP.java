import dev.survivorcreator.hearing.XpRules;
public class TestXP {
 static int checks;static void eq(double got,double expected,String m){checks++;if(Math.abs(got-expected)>1e-9)throw new AssertionError(m+" "+got);}
 public static void main(String[]a){
  var p=new net.minecraft.server.level.ServerPlayer();var s=new dev.survivorcreator.skills.Skill(){public String id(){return "fitness";}};
  double scaled=XpRules.scale(p,s,10);eq(scaled,2,"Actual original fitness progression rate retained");
  eq(scaled*1,2,"Default multiplier");eq(scaled*3,6,"Multiplier 3 now yields triple XP");eq(scaled*.5,1,"Fractional multiplier");
  eq(XpRules.scale(p,s,Double.NaN),0,"NaN rejected");eq(XpRules.scale(p,s,Double.POSITIVE_INFINITY),0,"Infinity rejected");eq(XpRules.scale(p,s,-3),0,"Negative XP rejected");
  dev.survivorcreator.GraceProtection.grace=true;eq(XpRules.scale(p,s,10),0,"Spawn grace still suppresses XP");
  System.out.println("Passed "+checks+" XP checks using original ProgressRules bytecode");
 }
}
