import dev.survivorcreator.hearing.*;import net.minecraft.client.Minecraft;import net.minecraft.sounds.SoundSource;
public class TestAudio {
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static void tick(){CreationAudio.tick(new net.neoforged.neoforge.client.event.ClientTickEvent.Post());}
 public static void main(String[]a){
  dev.survivorcreator.ModSounds.CREATION_MUSIC=net.minecraft.sounds.SoundEvent::new;
  var mc=Minecraft.getInstance();mc.player=new net.minecraft.client.player.LocalPlayer();
  HearingEffects.set(mc.player,0,200,true);check(CreationAudio.volume(SoundSource.HOSTILE)==.75f,"Level I volume");
  mc.screen=new dev.survivorcreator.client.CreatorScreen();check(CreationAudio.level()==3,"Immediate menu deafness");check(CreationAudio.volume(SoundSource.HOSTILE)==0,"Menu world muted");check(CreationAudio.volume(SoundSource.MUSIC)==1,"Menu music audible");tick();
  check(mc.player.getEffect(HearingEffects.DEAFNESS).getAmplifier()==2,"Visible effect III while creating");check(mc.getSoundManager().plays==1,"One creation song");tick();check(mc.getSoundManager().plays==1,"No per-tick song stacking");
  mc.screen=new dev.survivorcreator.client.EndingScreen();mc.player.tickCount+=50;tick();check(CreationAudio.level()==3,"Deafness retained through final screen");check(mc.getSoundManager().plays==1,"Song retained across creation screens");
  mc.screen=null;tick();var effect=mc.player.getEffect(HearingEffects.DEAFNESS);check(effect.getAmplifier()==0&&effect.getDuration()==150,"Prior temporary hearing restored with elapsed duration");check(CreationAudio.volume(SoundSource.HOSTILE)==.75f,"Audio restored");check(mc.getSoundManager().active.isEmpty(),"Song stopped at gameplay");
  dev.survivorcreator.data.ClientState.character=new dev.survivorcreator.data.CharacterData(){public java.util.List<net.minecraft.resources.ResourceLocation> perks(){return java.util.List.of(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("survivorcreator","hard_of_hearing"));}};
  mc.screen=new dev.survivorcreator.client.CreatorScreen();tick();mc.screen=null;tick();check(mc.player.getEffect(HearingEffects.DEAFNESS).getAmplifier()==1,"Perk restored as II after creation");check(CreationAudio.volume(SoundSource.HOSTILE)==.5f,"Perk halves volume");
  mc.player.alive=false;check(CreationAudio.level()==3,"Death silences immediately");check(CreationAudio.volume(SoundSource.MUSIC)==0,"Complete death deafness outside menus");
  mc.player=null;mc.screen=null;tick();check(CreationAudio.volume(SoundSource.HOSTILE)==1,"Disconnect clears deafness");check(mc.getSoundManager().active.isEmpty(),"Disconnect stops creation song");
  System.out.println("Passed "+checks+" audio lifecycle checks");
 }
}
