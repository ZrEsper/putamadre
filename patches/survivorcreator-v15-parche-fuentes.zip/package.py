from pathlib import Path
import zipfile,json,io,hashlib
from PIL import Image,ImageDraw
base=Path('work/survivor'); out=Path('work/survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v15-hearing-xp.jar')
with zipfile.ZipFile(base/'base15.jar') as z: data={n:z.read(n) for n in z.namelist()}
for p in (base/'classes').rglob('*.class'):
 n=str(p.relative_to(base/'classes')); assert n.startswith('dev/survivorcreator/');data[n]=p.read_bytes()
n='data/survivorcreator/survivor/perks/hard_of_hearing.json'
j=json.loads(data[n]);j['name']='Sordera';j['description']='Sordera II: escuchas los sonidos al 50 % de su volumen normal.';data[n]=json.dumps(j,ensure_ascii=False,indent=2).encode()
sounds=json.loads(data['assets/survivorcreator/sounds.json']);sounds['creation_music']={'sounds':[{'name':'survivorcreator:music/creation_theme','stream':True}]};data['assets/survivorcreator/sounds.json']=json.dumps(sounds,indent=2).encode()
data['assets/survivorcreator/sounds/music/creation_theme.ogg']=Path('attachments/c992ea33-60d0-4358-84e6-18e29f10d184/Project Zomboid B42.20 Main Menu.ogg').read_bytes()
for lang in ['es_es','en_us']:
 n=f'assets/survivorcreator/lang/{lang}.json';j=json.loads(data[n]);j.update({'effect.survivorcreator.deafness':'Sordera' if lang=='es_es' else 'Deafness','hud.survivorcreator.xp.remaining':'faltan %s XP' if lang=='es_es' else '%s XP to next level','hud.survivorcreator.xp.maximum':'nivel máximo' if lang=='es_es' else 'max level'});data[n]=json.dumps(j,ensure_ascii=False,indent=2).encode()
data['survivorcreator-hearing15.mixins.json']=json.dumps({'required':True,'minVersion':'0.8','package':'dev.survivorcreator.mixin','compatibilityLevel':'JAVA_21','client':['HearingSoundMixin'],'injectors':{'defaultRequire':1}},indent=2).encode()
data['META-INF/neoforge.mods.toml']+=b'\n[[mixins]]\nconfig="survivorcreator-hearing15.mixins.json"\n'
# A dedicated effect icon (18x18): ear with a muted slash.
im=Image.new('RGBA',(18,18));d=ImageDraw.Draw(im);d.arc((4,2,14,13),185,530,fill=(139,185,205,255),width=2);d.line([(13,10),(10,14),(8,15),(6,13)],fill=(139,185,205,255),width=2);d.line([(8,6),(11,6),(11,9),(9,10)],fill=(139,185,205,255),width=1);d.line([(3,3),(15,15)],fill=(220,90,85,255),width=2);buf=io.BytesIO();im.save(buf,format='PNG');data['assets/survivorcreator/textures/mob_effect/deafness.png']=buf.getvalue()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in data.items():z.writestr(n,b)
print(out, out.stat().st_size, hashlib.sha256(out.read_bytes()).hexdigest())
