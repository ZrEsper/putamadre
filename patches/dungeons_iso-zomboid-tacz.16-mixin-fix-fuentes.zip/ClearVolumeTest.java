import com.cleannrooster.dungeons_iso.api.cullers.room.ClearVolume;import java.util.*;
public class ClearVolumeTest {static int checks;static void ok(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}static String key(int x,int y,int z){return x+","+y+","+z;}
 public static void main(String[] a){double[][] cameras={{20,85,20},{-20,85,20},{20,85,-20},{-20,85,-20},{0,95,0},{20,66,0},{0,66,0}};
 for(double[] c:cameras){Set<String> seen=new HashSet<>();ClearVolume.visit(c[0],c[1],c[2],0,66.9,0,66,100,(x,y,z)->{if(!seen.add(key(x,y,z)))throw new AssertionError("duplicate cell");});
  for(int x=-30;x<=30;x++)for(int y=64;y<=99;y++)for(int z=-30;z<=30;z++)ok(seen.contains(key(x,y,z))==ClearVolume.contains(c[0],c[1],c[2],0,66.9,0,66,x,y,z),"continuous coverage");
  ok(!seen.contains(key(0,65,0)),"floor preserved");ok(seen.contains(key(0,67,0)),"player center clear");ok(seen.contains(key(5,67,0)),"nearby area clear");ok(!seen.contains(key(29,67,29)),"remote scenery retained");
 }
 Set<String> near=new HashSet<>(),far=new HashSet<>();ClearVolume.visit(20,85,20,0,66.9,0,66,150,(x,y,z)->near.add(key(x,y,z)));ClearVolume.visit(40,105,40,0,66.9,0,66,150,(x,y,z)->far.add(key(x,y,z)));ok(far.size()>near.size(),"zoom adapts to actual camera distance");ok(far.contains(key(30,96,30)),"distant foreground cleared");
 long before=System.nanoTime();final int[] count={0};ClearVolume.visit(35,100,35,0,66.9,0,66,150,(x,y,z)->count[0]++);System.out.println("PASS "+checks+" geometry assertions, "+count[0]+" cells at typical far zoom in "+((System.nanoTime()-before)/1000000.0)+" ms; no Minecraft runtime");}
}
