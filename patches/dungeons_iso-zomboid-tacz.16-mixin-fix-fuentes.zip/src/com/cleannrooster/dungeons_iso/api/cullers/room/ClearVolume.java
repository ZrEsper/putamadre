package com.cleannrooster.dungeons_iso.api.cullers.room;
/** Continuous camera-to-player capsule; no shape filters or visibility threshold. */
public final class ClearVolume {
 public static final double RADIUS=6.0, MARGIN=.866025404, R=RADIUS+MARGIN;
 public interface Cell {void visit(int x,int y,int z);}
 public static boolean contains(double cx,double cy,double cz,double tx,double ty,double tz,int floor,int x,int y,int z){if(y<floor)return false;double dx=cx-tx,dy=cy-ty,dz=cz-tz,px=x+.5-tx,py=y+.5-ty,pz=z+.5-tz;double len=dx*dx+dy*dy+dz*dz,t=len<1e-12?0:Math.clamp((px*dx+py*dy+pz*dz)/len,0,1);px-=t*dx;py-=t*dy;pz-=t*dz;return px*px+py*py+pz*pz<=R*R;}
 public static void visit(double cx,double cy,double cz,double tx,double ty,double tz,int floor,int top,Cell sink){
  if(!Double.isFinite(cx+cy+cz+tx+ty+tz))return;
  double dx=cx-tx,dy=cy-ty,dz=cz-tz;
  int y0=Math.max(floor,(int)Math.floor(Math.min(cy,ty)-R)),y1=Math.min(top-1,(int)Math.ceil(Math.max(cy,ty)+R));
  for(int y=y0;y<=y1;y++){double lo=0,hi=1;if(Math.abs(dy)>1e-9){double a=(y+.5-ty-R)/dy,b=(y+.5-ty+R)/dy;lo=Math.max(0,Math.min(a,b));hi=Math.min(1,Math.max(a,b));if(lo>hi)continue;}else if(Math.abs(y+.5-ty)>R)continue;
   int x0=(int)Math.floor(Math.min(tx+lo*dx,tx+hi*dx)-R),x1=(int)Math.ceil(Math.max(tx+lo*dx,tx+hi*dx)+R);
   int z0=(int)Math.floor(Math.min(tz+lo*dz,tz+hi*dz)-R),z1=(int)Math.ceil(Math.max(tz+lo*dz,tz+hi*dz)+R);
   for(int x=x0;x<=x1;x++)for(int z=z0;z<=z1;z++)if(contains(cx,cy,cz,tx,ty,tz,floor,x,y,z))sink.visit(x,y,z);
  }
 }
}
