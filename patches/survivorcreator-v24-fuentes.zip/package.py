from pathlib import Path
import json,zipfile,re
root=Path('work/survivor24')
with zipfile.ZipFile(root/'base.jar') as z:data={n:z.read(n) for n in z.namelist()}
for p in (root/'classes/dev/survivorcreator/hearing').glob('*.class'):data['dev/survivorcreator/hearing/'+p.name]=p.read_bytes()
base={'es_es':{'cause':'Causa de muerte: %s','source':'Daño mortal: %s','body':'Estado del cuerpo','all':'Todas las lesiones','none':'Sin lesiones registradas','zombies':'Zombis eliminados: %s','survivors':'Supervivientes eliminados: %s','scroll':'Rueda del ratón: ver más','bandage.legend':'Vendas / férulas','bandaged':'vendado','splinted':'con férula'},'en_us':{'cause':'Cause of death: %s','source':'Fatal damage: %s','body':'Body condition','all':'All injuries','none':'No recorded injuries','zombies':'Zombies killed: %s','survivors':'Survivors killed: %s','scroll':'Mouse wheel: view more','bandage.legend':'Bandages / splints','bandaged':'bandaged','splinted':'splinted'}}
parts=['HEAD','BODY','LEFT_ARM','RIGHT_ARM','LEFT_LEG','RIGHT_LEG','LEFT_FOOT','RIGHT_FOOT']
injuries=['gunshot','bullet','cut','bite','infection','dirty','fracture','bleed','trauma']
for lang in base:
 labels=base[lang];names=['Cabeza','Torso','Brazo izquierdo','Brazo derecho','Pierna izquierda','Pierna derecha','Pie izquierdo','Pie derecho'] if lang=='es_es' else ['Head','Torso','Left arm','Right arm','Left leg','Right leg','Left foot','Right foot']
 wounds=['Herida de bala','Balas alojadas','Corte','Mordedura','Infección','Herida sucia','Fractura','Sangrado','Daño en la zona'] if lang=='es_es' else ['Gunshot wound','Lodged bullets','Cut','Bite','Infection','Dirty wound','Fracture','Bleeding','Damage to this area']
 labels.update({'part.'+k:v for k,v in zip(parts,names)});labels.update({'injury.'+k:v for k,v in zip(injuries,wounds)})
 codes={'generic':'Daño sin fuente específica','genericKill':'Muerte forzada','mob':'Ataque de una criatura','player':'Ataque de un jugador','fall':'Caída','inFire':'Fuego','onFire':'Quemaduras','drown':'Ahogamiento','starve':'Hambre','inWall':'Asfixia','outOfWorld':'Vacío','magic':'Daño de efecto','indirectMagic':'Daño de efecto indirecto','explosion':'Explosión','mobProjectile':'Proyectil de una criatura','arrow':'Flecha','trident':'Tridente','freeze':'Congelación','wither':'Wither','cactus':'Cactus','sweetBerryBush':'Espinas','hotFloor':'Suelo caliente','cramming':'Aplastamiento','flyIntoWall':'Choque','lightningBolt':'Rayo','lava':'Lava'}
 if lang=='en_us':codes={k:re.sub(r'([A-Z])',r' \1',k).capitalize() for k in codes};codes['generic']='Damage without a specific source'
 labels.update({'source.'+k:v for k,v in codes.items()})
 path=f'assets/survivorcreator/lang/{lang}.json';j=json.loads(data[path]);j.update({'screen.survivorcreator.death.'+k:v for k,v in labels.items()});data[path]=json.dumps(j,ensure_ascii=False,indent=2).encode()
n='META-INF/neoforge.mods.toml';data[n]=re.sub(r'(?m)^version="[^"]+"','version="1.0.9-zomboid-v24-death-body-report"',data[n].decode(),count=1).encode()
out=root/'survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v24-death-body-report.jar'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in data.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(out,out.stat().st_size)
