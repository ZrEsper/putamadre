import java.nio.file.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;
public class Patch24 implements Opcodes {
 public static void main(String[] args)throws Exception {try(ZipFile in=new ZipFile(args[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(args[1])))){
 for(var it=in.entries();it.hasMoreElements();){var e=it.nextElement();byte[] b=in.getInputStream(e).readAllBytes();if(e.getName().equals("dev/survivorcreator/client/EndingScreen.class")){
  ClassReader r=new ClassReader(b);ClassWriter w=new ClassWriter(r,ClassWriter.COMPUTE_MAXS);r.accept(new ClassVisitor(ASM8,w){public void visitEnd(){MethodVisitor m=super.visitMethod(ACC_PUBLIC,"mouseScrolled","(DDDD)Z",null,null);m.visitCode();Label normal=new Label();m.visitVarInsn(ALOAD,0);m.visitFieldInsn(GETFIELD,"dev/survivorcreator/client/EndingScreen","deathMode","Z");m.visitJumpInsn(IFEQ,normal);m.visitVarInsn(DLOAD,7);m.visitMethodInsn(INVOKESTATIC,"dev/survivorcreator/hearing/DeathPanel","scroll","(D)Z",false);m.visitInsn(IRETURN);m.visitLabel(normal);m.visitFrame(F_SAME,0,null,0,null);m.visitVarInsn(ALOAD,0);m.visitVarInsn(DLOAD,1);m.visitVarInsn(DLOAD,3);m.visitVarInsn(DLOAD,5);m.visitVarInsn(DLOAD,7);m.visitMethodInsn(INVOKESPECIAL,"net/minecraft/client/gui/screens/Screen","mouseScrolled","(DDDD)Z",false);m.visitInsn(IRETURN);m.visitMaxs(9,9);m.visitEnd();super.visitEnd();}},0);b=w.toByteArray();
 }
 out.putNextEntry(new ZipEntry(e.getName()));out.write(b);out.closeEntry();}
 }}
}
