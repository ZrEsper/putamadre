package ichttt.mods.firstaid.api.enums;public enum EnumPlayerPart{HEAD,BODY,LEFT_LEG,LEFT_ARM}
