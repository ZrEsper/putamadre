package ichttt.mods.firstaid.common.util;public class CommonUtils{public static Object model;public static Object getExistingDamageModel(net.minecraft.world.entity.player.Player p){return model;}}
