package dev.survivorcreator.hearing;
import com.google.gson.*;import java.util.*;import java.lang.reflect.*;
import net.minecraft.server.level.ServerPlayer;import net.minecraft.world.entity.player.Player;
import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.bus.api.*;
@EventBusSubscriber(modid="survivorcreator")
public final class DeathDetails {
 public static final String Z="survivorcreator_life_zombies24",S="survivorcreator_life_survivors24";
 public static String category(String id){String s=id.toLowerCase(Locale.ROOT);if(s.startsWith("entity.tacznpcs.")||s.startsWith("entity.survivorcreator.")&&(s.contains("survivor")||s.contains("bandit")))return S;if(s.contains("zombie")||s.equals("entity.minecraft.husk")||s.equals("entity.minecraft.drowned")||s.startsWith("entity.mutantszombies.")&&(s.contains("brute")||s.contains("crawler")||s.contains("spitter")||s.contains("split")||s.contains("rotten")||s.contains("blister")))return Z;return "";}
 @SubscribeEvent(priority=EventPriority.LOWEST) public static void killed(net.neoforged.neoforge.event.entity.living.LivingDeathEvent e){
  if(e.isCanceled()||!(e.getSource().getEntity() instanceof ServerPlayer p)||e.getEntity()==p)return;
  String key=category(e.getEntity().getType().getDescriptionId());if(!key.isEmpty()){var tag=p.getPersistentData();tag.putInt(key,(int)Math.min(Integer.MAX_VALUE,(long)Math.max(0,tag.getInt(key))+1));}
 }
 public static JsonArray body(Player p){JsonArray rows=new JsonArray();
  try {Class<?> utils=Class.forName("ichttt.mods.firstaid.common.util.CommonUtils");Object model=utils.getMethod("getExistingDamageModel",Player.class).invoke(null,p);if(!(model instanceof Iterable<?> parts))return rows;
   Method wound=null;try{wound=Class.forName("ichttt.mods.firstaid.survival.ClinicalData").getMethod("wound",Class.forName("ichttt.mods.firstaid.api.damagesystem.AbstractDamageablePart"));}catch(ReflectiveOperationException ignored){}
   for(Object part:parts){JsonObject row=new JsonObject();String name=((Enum<?>)part.getClass().getField("part").get(part)).name();float hp=part.getClass().getField("currentHealth").getFloat(part);float max=((Number)part.getClass().getMethod("getMaxHealth").invoke(part)).floatValue();row.addProperty("part",name);row.addProperty("hp",Math.max(0,hp));row.addProperty("max",max);JsonArray wounds=new JsonArray();
    Object w=wound==null?null:wound.invoke(null,part);if(w!=null){if(flag(w,"gunshot"))wounds.add("gunshot");int bullets=number(w,"bullets");if(bullets>0){wounds.add("bullet");row.addProperty("bullets",bullets);}if(flag(w,"cut"))wounds.add("cut");if(flag(w,"bitten"))wounds.add("bite");if(flag(w,"infected"))wounds.add("infection");if(flag(w,"dirty"))wounds.add("dirty");row.addProperty("bandaged",flag(w,"bandaged"));}
    if(name.equals("LEFT_LEG")||name.equals("RIGHT_LEG")){boolean left=name.equals("LEFT_LEG");try{Class<?> fractures=Class.forName("ichttt.mods.firstaid.fracture.Fractures");if((boolean)fractures.getMethod("isBroken",net.minecraft.world.entity.LivingEntity.class,boolean.class).invoke(null,p,left))wounds.add("fracture");row.addProperty("splint",(boolean)fractures.getMethod("isSplinted",net.minecraft.world.entity.LivingEntity.class,boolean.class).invoke(null,p,left));}catch(ReflectiveOperationException ignored){}}
    try{Class<?> bleed=Class.forName("ichttt.mods.firstaid.fracture.Bleeding");Object enumPart=part.getClass().getField("part").get(part);if((boolean)bleed.getMethod("isBleeding",net.minecraft.world.entity.LivingEntity.class,enumPart.getClass()).invoke(null,p,enumPart))wounds.add("bleed");}catch(ReflectiveOperationException ignored){}
    if(hp<max&&wounds.size()==0)wounds.add("trauma");row.add("wounds",wounds);rows.add(row);
   }
  }catch(ReflectiveOperationException|LinkageError ex){System.err.println("[SurvivorCreator] Death body snapshot unavailable: "+ex.getClass().getSimpleName());}
  return rows;
 }
 private static boolean flag(Object o,String key){try{return o.getClass().getField(key).getBoolean(o);}catch(ReflectiveOperationException e){return false;}}
 private static int number(Object o,String key){try{return o.getClass().getField(key).getInt(o);}catch(ReflectiveOperationException e){return 0;}}
 public static String enrich(ServerPlayer p,String original,net.minecraft.world.damagesource.DamageSource source){JsonObject j=JsonParser.parseString(original).getAsJsonObject();j.add("body24",body(p));j.addProperty("zombies24",p.getPersistentData().getInt(Z));j.addProperty("survivors24",p.getPersistentData().getInt(S));j.addProperty("damage24",source.getMsgId());return j.toString();}
}
