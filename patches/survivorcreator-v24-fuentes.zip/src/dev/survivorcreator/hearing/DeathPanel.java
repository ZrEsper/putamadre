package dev.survivorcreator.hearing;
import net.minecraft.client.gui.*;import net.minecraft.network.chat.Component;import com.google.gson.*;import java.util.*;
public final class DeathPanel {
 private static DeathReport report=DeathReport.UNKNOWN;private static JsonObject detail=new JsonObject();private static int scroll,maxScroll;
 public static void accept(String json){try{JsonObject j=JsonParser.parseString(json).getAsJsonObject();if(j.has("death16")){String text=j.get("death16").getAsString();if(!text.isEmpty()){detail=JsonParser.parseString(text).getAsJsonObject();report=DeathReport.parse(text);scroll=0;}else{detail=new JsonObject();report=DeathReport.UNKNOWN;scroll=0;}}}catch(RuntimeException ignored){}}
 public static boolean canContinue(long elapsed){return elapsed>=850;}
 public static boolean scroll(double amount){scroll=Math.max(0,Math.min(maxScroll,scroll-(int)Math.round(amount*22)));return true;}
 private static String tr(String key,Object... args){return Component.translatable("screen.survivorcreator.death."+key,args).getString();}
 private static int num(JsonObject o,String k){return o.has(k)?o.get(k).getAsInt():0;}
 private static boolean flag(JsonObject o,String k){return o.has(k)&&o.get(k).getAsBoolean();}
 public static void render(GuiGraphics g,Font font,int width,int height,long elapsed){
  if(elapsed<850)return;int alpha=(int)(Math.min(1,(elapsed-850)/1100f)*255);if(alpha<=3)return;int color=alpha<<24|0xdcd6ca;
  int y=16;center(g,font,tr("1"),width/2,y,alpha<<24|0xc97870);y+=20;
  String cause=report.causeKey().isEmpty()?report.cause():Component.translatable(report.causeKey(),(Object[])report.causeArgs()).getString();if(cause.isEmpty())cause=tr("unknown");
  for(var line:font.split(Component.literal(tr("cause",cause)),Math.max(60,width-32))){g.drawString(font,line,(width-font.width(line))/2,y,color,false);y+=11;}
  if(detail.has("damage24")){String id=detail.get("damage24").getAsString();String label=tr("source."+id);if(label.equals("screen.survivorcreator.death.source."+id))label=id;center(g,font,tr("source",label),width/2,y,color);y+=13;}
  center(g,font,tr("survived",report.ticks()<0?tr("unavailable"):DeathReport.duration(report.ticks())),width/2,y,color);y+=14;
  String kills=tr("zombies",num(detail,"zombies24"));if(num(detail,"survivors24")>0)kills+="   ·   "+tr("survivors",num(detail,"survivors24"));center(g,font,kills,width/2,y,alpha<<24|0xb9c9a6);y+=20;
  int left=Math.max(90,width/3),top=y,bottom=height-44;JsonArray parts=detail.has("body24")?detail.getAsJsonArray("body24"):new JsonArray();
  center(g,font,tr("body"),left/2,top,color);int unit=Math.max(1,Math.min(2,(bottom-top-24)/64));int bodyX=left/2-18*unit,bodyY=top+16;
  for(JsonElement e:parts){JsonObject p=e.getAsJsonObject();body(g,p,bodyX,bodyY,unit,alpha);}
  if(parts.size()==0)center(g,font,tr("unavailable"),left/2,top+24,color);
  center(g,font,tr("bandage.legend"),left/2,Math.min(bottom-10,bodyY+65*unit+4),alpha<<24|0xbab8ad);
  int x=left+8,right=width-14;g.drawString(font,tr("all"),x,top,color,false);int textTop=top+15;List<String> rows=new ArrayList<>();
  for(JsonElement e:parts){JsonObject p=e.getAsJsonObject();JsonArray wounds=p.getAsJsonArray("wounds");if(wounds.size()==0)continue;StringJoiner types=new StringJoiner(", ");for(JsonElement w:wounds){String key=w.getAsString();String label=tr("injury."+key);if(key.equals("bullet"))label+=" ×"+num(p,"bullets");types.add(label);}String line=tr("part."+p.get("part").getAsString())+": "+types;if(flag(p,"bandaged"))line+=" · "+tr("bandaged");if(flag(p,"splint"))line+=" · "+tr("splinted");rows.add(line);}
  if(rows.isEmpty())rows.add(tr(parts.size()==0?"unavailable":"none"));
  int total=0;for(String row:rows)total+=font.split(Component.literal(row),Math.max(50,right-x)).size()*11+5;maxScroll=Math.max(0,total-(bottom-textTop));scroll=Math.min(scroll,maxScroll);
  g.enableScissor(x,textTop,right,bottom);int ry=textTop-scroll;for(String row:rows){for(var line:font.split(Component.literal(row),Math.max(50,right-x))){g.drawString(font,line,x,ry,color,false);ry+=11;}ry+=5;}g.disableScissor();
  if(maxScroll>0)g.drawString(font,tr("scroll"),x,bottom+3,alpha<<24|0xa9baa2,false);
  center(g,font,tr("click"),width/2,height-22,alpha<<24|0xa9baa2);
 }
 private static void center(GuiGraphics g,Font f,String s,int x,int y,int c){g.drawString(f,s,x-f.width(s)/2,y,c,false);}
 private static void body(GuiGraphics g,JsonObject p,int ox,int oy,int unit,int alpha){
  int[] r=switch(p.get("part").getAsString()){case "HEAD"->new int[]{12,0,12,12};case "BODY"->new int[]{10,14,16,20};case "LEFT_ARM"->new int[]{28,14,8,21};case "RIGHT_ARM"->new int[]{0,14,8,21};case "LEFT_LEG"->new int[]{19,36,7,20};case "RIGHT_LEG"->new int[]{10,36,7,20};case "LEFT_FOOT"->new int[]{19,57,9,6};case "RIGHT_FOOT"->new int[]{8,57,9,6};default->new int[]{0,0,0,0};};
  int x=ox+r[0]*unit,y=oy+r[1]*unit,w=r[2]*unit,h=r[3]*unit;double max=p.get("max").getAsDouble(),hp=p.get("hp").getAsDouble(),ratio=max<=0?0:hp/max;int c=ratio>=.95?0x6b975e:ratio>.5?0xc5a151:ratio>0?0xb55748:0x5e2424;
  g.fill(x-1,y-1,x+w+1,y+h+1,alpha<<24|0x3e3835);g.fill(x,y,x+w,y+h,alpha<<24|c);
  JsonArray wounds=p.getAsJsonArray("wounds");for(JsonElement e:wounds){String type=e.getAsString();if(type.equals("fracture")){for(int i=0;i<Math.min(h,w);i+=2)g.fill(x+i,y+h/2+i/2,x+i+unit+1,y+h/2+i/2+unit+1,alpha<<24|0xe4b7df);}if(type.equals("bleed")||type.equals("cut")||type.equals("bite"))g.fill(x+w/3,y+h/4,x+w/3+2*unit,y+3*h/4,alpha<<24|0xe63e35);if(type.equals("bullet"))g.fill(x+w/2,y+h/3,x+w/2+2*unit,y+h/3+2*unit,alpha<<24|0x211816);}
  if(flag(p,"bandaged")){g.fill(x,y+h/2-2*unit,x+w,y+h/2+3*unit,alpha<<24|0xded8c7);g.fill(x,y+h/2,x+w,y+h/2+unit,alpha<<24|0xaaa593);}
  if(flag(p,"splint"))g.fill(x+w-2*unit,y+unit,x+w-unit,y+h-unit,alpha<<24|0xccb185);
 }
}
