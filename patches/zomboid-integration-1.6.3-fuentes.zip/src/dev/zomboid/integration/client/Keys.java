package dev.zomboid.integration.client;
import dev.zomboid.integration.*;import net.minecraft.client.*;import net.minecraft.network.chat.Component;import net.minecraft.world.item.Item;import net.neoforged.fml.common.EventBusSubscriber;import net.neoforged.api.distmarker.Dist;import net.neoforged.bus.api.SubscribeEvent;
@EventBusSubscriber(modid="zomboid_integration",value=Dist.CLIENT)
public final class Keys {
 public static final KeyMapping LAMP=new KeyMapping("key.zomboid_integration.lamp",com.mojang.blaze3d.platform.InputConstants.Type.KEYSYM,88,"key.categories.zomboid_integration");
 private static final PressEdge PRESS=new PressEdge();
 private static Item lastMain,lastOff;private static long lastHint=-100;
 @SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post e){
  Minecraft mc=Minecraft.getInstance();boolean queued=LAMP.consumeClick();while(LAMP.consumeClick()){}boolean physical=LampInput.physical(mc,LAMP);boolean allowed=mc.player!=null&&mc.screen==null&&LampInput.focused(mc);boolean fire=PRESS.tick(physical,queued,allowed);
  if(mc.player==null){lastMain=lastOff=null;lastHint=-100;return;}
  if(!allowed)return;
  if(fire)net.neoforged.neoforge.network.PacketDistributor.sendToServer(Network.Toggle.INSTANCE);
  var main=mc.player.getMainHandItem();var off=mc.player.getOffhandItem();
  if((main.getItem()!=lastMain||off.getItem()!=lastOff)&&(Lamps.isLamp(main)||Lamps.isLamp(off))&&mc.player.tickCount-lastHint>=60){mc.player.displayClientMessage(Component.translatable("zomboid_integration.hint",LAMP.getTranslatedKeyMessage()),true);lastHint=mc.player.tickCount;}
  lastMain=main.getItem();lastOff=off.getItem();
 }
 @EventBusSubscriber(modid="zomboid_integration",value=Dist.CLIENT,bus=EventBusSubscriber.Bus.MOD)
 public static final class Registration{@SubscribeEvent public static void keys(net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent e){e.register(LAMP);}}
}
