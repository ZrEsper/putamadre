import ichttt.mods.firstaid.survival.*;
import net.minecraft.nbt.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.*;
import net.minecraft.world.*;
import net.minecraft.client.Minecraft;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import java.util.*;

/** Executes the actual new classes from the final JAR against signature-based API doubles. */
public final class IntegrationChecks {
    static int assertions;
    static void check(boolean ok,String text){assertions++;if(!ok)throw new AssertionError(text);}
    public static class Model {
        public int unconscious,resyncs;
        public int getUnconsciousTicks(){return unconscious;}
        public void scheduleResync(){resyncs++;}
    }
    public static class Screen {
        public Minecraft minecraft=Minecraft.INSTANCE; public List<String> lines=new ArrayList<>();
        private int wetnessNativeThermal(Object g,int x,int y){return y+10;}
        private int wetnessNativeStatus(Object g,Object m,int x,int y){return y+5;}
        private int heading(Object g,String text,int x,int y){lines.add(text);return y+15;}
        private int line(Object g,String text,int x,int y,int color){lines.add(text);return y+12;}
        private int wrapped(Object g,String text,int x,int y,int color){lines.add(text);return y+24;}
    }
    public static void main(String[] args) {
        DeferredRegister.Items items=new DeferredRegister.Items();DeferredRegister sounds=new DeferredRegister();
        WetGameplay.register(items,sounds);
        check(items.entries.size()==1 && items.entries.containsKey("towel"),"Deferred towel registration");
        check(sounds.entries.containsKey("sneeze"),"Deferred sound registration");
        Item towel=(Item)WetReflection.call(WetGameplay.TOWEL,"get");
        check(towel instanceof TowelItem && towel.stackSize==1,"Real generated towel class and properties");
        BuildCreativeModeTabContentsEvent tab=new BuildCreativeModeTabContentsEvent();WetGameplay.creative(tab);
        check(tab.items.contains(towel),"Towel in First Aid creative tab");
        Level level=new Level();ServerPlayer p=new ServerPlayer();p.world=level;p.hand=towel.getDefaultInstance();
        Model model=new Model();p.model=model;
        level.waterHeight=.2;WetGameplay.tick(model,p);
        WetState s=WetGameplay.state(model);
        check(s.wet[3]==2400 && s.wet[7]==2400,"Fluid-height detection wets feet only");
        for(int i:new int[]{0,1,2,4,5,6})check(s.wet[i]==0,"Higher parts stay dry");
        check(p.syncs>0 && model.resyncs>0,"Initial contact synchronized to clients");
        int exposure=s.exposure;WetGameplay.tick(model,p);check(s.exposure==exposure,"Duplicate model tick cannot accelerate timers");
        p.tickCount++;level.waterHeight=1.2;WetGameplay.tick(model,p);
        check(s.wet[4]==2400 && s.wet[1]==2400 && s.wet[5]==2400 && s.wet[0]==0,"Chest-deep water leaves head dry");
        p.tickCount++;level.waterHeight=2;WetGameplay.tick(model,p);
        check(Arrays.stream(s.wet).allMatch(i->i==2400),"Fully submerged body");
        p.tickCount++;level.waterHeight=-100;WetGameplay.tick(model,p);
        check(Arrays.stream(s.wet).allMatch(i->i==2399),"Leaving water starts retained wetness countdown");
        p.creative=true;p.tickCount++;WetGameplay.tick(model,p);check(s.wet[0]==2399,"Creative excluded");p.creative=false;
        p.spectator=true;p.tickCount++;WetGameplay.tick(model,p);check(s.wet[0]==2399,"Spectator excluded");p.spectator=false;
        net.minecraft.world.entity.player.Player client=new net.minecraft.world.entity.player.Player();client.model=model;client.world=level;client.tickCount++;
        WetGameplay.tick(model,client);check(s.wet[0]==2399,"Client cannot mutate gameplay timers");

        s.flu=1700;s.sneeze=210;s.immune=true;s.exposure=800;
        s.wet[1]=1234;CompoundTag tag=new CompoundTag();WetGameplay.write(model,tag);
        Model restored=new Model();WetGameplay.read(restored,tag);WetState loaded=WetGameplay.state(restored);
        check(Arrays.equals(s.wet,loaded.wet),"Per-part NBT persistence and packet roundtrip");
        check(loaded.flu==1700 && loaded.sneeze==210 && loaded.immune && loaded.exposure==800,"Illness NBT persistence");
        check(loaded.lastTick==Integer.MIN_VALUE,"Relog does not retain old tick guard");
        CompoundTag bad=new CompoundTag(),data=new CompoundTag();data.putIntArray("parts",new int[]{-9,999999,100});
        data.putInt("flu",Integer.MAX_VALUE);data.putInt("sneeze",99999);bad.put("zomboidWetness",data);
        WetGameplay.read(restored,bad);loaded=WetGameplay.state(restored);
        check(loaded.wet[0]==0 && loaded.wet[1]==2400 && loaded.wet[2]==100 && loaded.wet[7]==0,"Invalid/missing wetness values clamped");
        check(loaded.flu==2400 && loaded.sneeze==400 && loaded.immune,"Invalid illness values bounded");
        WetGameplay.read(restored,new CompoundTag());check(WetGameplay.state(restored).average()==0,"Old saved games migrate dry");

        int count=p.hand.count;InteractionResultHolder<ItemStack> use=towel.use(level,p,InteractionHand.MAIN_HAND);
        check(use.success() && use.object()==p.hand,"Real towel Item.use delegates and succeeds");
        check(s.average()==0 && s.exposure==0,"Towel dries every part");
        check(s.flu==1700 && p.hand.count==count,"Towel reusable; flu still recovers over time");
        s.wet[0]=100;model.unconscious=5;use=towel.use(level,p,InteractionHand.MAIN_HAND);
        check(!use.success() && s.wet[0]==100,"Unconscious players cannot dry themselves");model.unconscious=0;
        level.client=true;use=towel.use(level,p,InteractionHand.MAIN_HAND);
        check(use.success() && s.wet[0]==100,"Client towel use acknowledges without mutation");level.client=false;
        Zombie nearby=new Zombie();nearby.x=8;level.mobs.add(nearby);
        Zombie boundary=new Zombie();boundary.x=32;level.mobs.add(boundary);
        Zombie far=new Zombie();far.x=32.1;level.mobs.add(far);
        Zombie dead=new Zombie();dead.alive=false;level.mobs.add(dead);
        Mob cow=new Mob();cow.type="minecraft:cow";level.mobs.add(cow);
        Mob custom=new Mob();custom.type="hordes:zombie_runner";level.mobs.add(custom);
        WetGameplay.sneeze(p,level);
        check(level.sounds==1 && level.particles==8,"Sneeze broadcasts sound and green particles");
        check(level.mucus.item().item==Items.SLIME_BALL,"Mucus uses green slime item particles");
        check(Math.abs(level.particleY-(p.getEyeY()-.08))<.001 && level.particleZ>p.z,"Particles start at face in look direction");
        check(nearby.target==p && nearby.nav.destination==p,"Nearby zombies target and approach player");
        check(boundary.target==p && far.target==null,"Spherical 32-block hearing limit");
        check(dead.target==null && cow.target==null && custom.target==p,"Dead mobs/animals excluded; modded zombies included");
        s.flu=2;s.sneeze=1;int before=level.sounds;p.tickCount++;WetGameplay.tick(model,p);
        check(level.sounds==before+1 && s.flu==1,"Server countdown dispatches an actual sneeze");
        p.tickCount++;WetGameplay.tick(model,p);check(s.flu==0 && level.sounds==before+1,"Recovery stops sneezing immediately");

        Minecraft.INSTANCE.player=p;Screen screen=new Screen();s.wet[3]=1200;s.flu=100;
        check(WetClient.homeostasis(p)==null,"Missing optional Homeostatic cannot crash wetness menu");
        check(WetClient.humidity()==s.average(),"Global menu humidity reflects independent per-part state");
        int end=WetClient.thermal(screen,new Object(),5,20);
        check(end>20 && screen.lines.contains("Pie izquierdo: 50 %") && screen.lines.contains("Gripe: 5 s"),"Menu lists wetness and remaining illness without Homeostatic");
        screen.lines.clear();WetClient.status(screen,new Object(),model,5,20);
        check(screen.lines.stream().anyMatch(t->t.contains("Gripe: 5 s")),"Illness appears in health status tab");
        System.out.println("PASS: "+assertions+" runtime integration assertions (API doubles)");
    }
}
