import ichttt.mods.firstaid.survival.*;
import java.util.Arrays;

public final class WetChecks {
    static int assertions;
    static void check(boolean ok,String message) {assertions++;if(!ok)throw new AssertionError(message);}
    public static void main(String[] args) {
        WetState s=new WetState();boolean[] water=new boolean[8];
        water[3]=true;water[7]=true;
        s.advance(water,1,300);
        check(s.wet[3]==2400 && s.wet[7]==2400,"Only feet get wet in shallow water");
        for(int i:new int[]{0,1,2,4,5,6}) check(s.wet[i]==0,"Other parts stay dry");
        Arrays.fill(water,false);
        for(int t=1;t<=2400;t++) {
            s.advance(water,1,300);
            check(s.wet[3]==2400-t,"Exactly 2 minutes drying");
        }
        check(s.average()==0 && s.exposure==0,"Dry state resets exposure");
        Arrays.fill(water,true);
        for(int t=0;t<299;t++) s.advance(water,0,200);
        check(s.flu==0,"No immediate flu from short contact");
        check((s.advance(water,0,200)&1)!=0 && s.flu==2400,"Prolonged humidity can trigger flu");
        int sneezes=0,recovery=0;
        for(int t=1;t<=2400;t++) {
            int flags=s.advance(water,0,200);
            if((flags&4)!=0) sneezes++;
            if((flags&2)!=0) recovery++;
            check(s.flu==2400-t,"Water never extends the current illness");
        }
        check(sneezes==11 && recovery==1,"Bounded periodic sneezes and one recovery");
        for(int t=0;t<10000;t++) {s.advance(water,0,200);check(s.flu==0,"No endless reinfection while wet");}
        s.dry();check(!s.immune && s.average()==0,"Towel clears all parts/exposure and allows a future wet episode");
        s.flu=100;s.immune=true;s.dry();check(s.flu==100 && s.immune,"Towel does not instantly cure existing flu");
        Arrays.fill(water,false);for(int t=0;t<100;t++) s.advance(water,1,300);
        check(s.flu==0 && !s.immune,"Dry convalescence clears immunity after recovery");

        var parts=WetGeometry.parts(0,0,0,.6,1.8,0,false);
        var shallow=new WetGeometry.Box(-5,0,-5,5,.20,5);
        for(int i=0;i<8;i++) check(parts[i].intersects(shallow)==(i==3 || i==7),"Shallow water affects only feet");
        var waist=new WetGeometry.Box(-5,0,-5,5,.75,5);
        check(parts[2].intersects(waist) && parts[6].intersects(waist),"Waist-deep water wets legs");
        check(!parts[0].intersects(waist) && !parts[4].intersects(waist),"Waist-deep water leaves head and torso dry");
        var left=new WetGeometry.Box(.18,.9,-.08,.28,1.15,.08);
        check(parts[1].intersects(left) && !parts[5].intersects(left) && !parts[4].intersects(left),"Side contact distinguishes arms and torso");
        var rotated=WetGeometry.parts(0,0,0,.6,1.8,90,false);
        var side=new WetGeometry.Box(-.08,.9,.18,.08,1.15,.28);
        check(rotated[1].intersects(side) && !rotated[5].intersects(side),"Regions rotate with body yaw");
        var swimming=WetGeometry.parts(0,0,0,.6,.6,0,true);
        check(swimming[0].minZ()>swimming[3].maxZ(),"Swimming head and feet remain distinct horizontally");
        check(!new WetGeometry.Box(0,0,0,1,1,1).intersects(new WetGeometry.Box(1,0,0,2,1,1)),"Boundary alone is not contact");
        System.out.println("PASS: "+assertions+" wetness/flu/geometry assertions");
    }
}
