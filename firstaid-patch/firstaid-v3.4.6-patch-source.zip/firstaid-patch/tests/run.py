from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,zipfile

ROOT=Path(__file__).resolve().parent.parent
JAR=Path(sys.argv[1])
CACHE=Path(os.environ.get('FIRSTAID_BUILD_CACHE',str(ROOT/'tools')))
SOURCES={
'net/minecraft/nbt/Tag.java':'''package net.minecraft.nbt; public class Tag {}''',
'net/minecraft/nbt/CompoundTag.java':'''package net.minecraft.nbt;
import java.util.*;
public class CompoundTag extends Tag {
 public Map<String,Object> v=new HashMap<>();
 public void put(String k,Tag t){v.put(k,t);} public CompoundTag getCompound(String k){return v.get(k) instanceof CompoundTag t?t:new CompoundTag();}
 public void putInt(String k,int t){v.put(k,t);} public int getInt(String k){return v.get(k) instanceof Integer i?i:0;}
 public void putIntArray(String k,int[] t){v.put(k,t.clone());} public int[] getIntArray(String k){return v.get(k) instanceof int[] a?a.clone():new int[0];}
 public void putBoolean(String k,boolean t){v.put(k,t);} public boolean getBoolean(String k){return Boolean.TRUE.equals(v.get(k));}
}''',
'net/minecraft/core/BlockPos.java':'''package net.minecraft.core; public record BlockPos(int x,int y,int z){}''',
'net/minecraft/tags/FluidTags.java':'''package net.minecraft.tags; public class FluidTags {public static final Object WATER=new Object();}''',
'net/minecraft/world/phys/Vec3.java':'''package net.minecraft.world.phys; public class Vec3 {public final double x,y,z;public Vec3(double x,double y,double z){this.x=x;this.y=y;this.z=z;}}''',
'net/minecraft/world/phys/AABB.java':'''package net.minecraft.world.phys;public class AABB {
 public double minX,minY,minZ,maxX,maxY,maxZ;
 public AABB(double x,double y,double z,double a,double b,double c){minX=x;minY=y;minZ=z;maxX=a;maxY=b;maxZ=c;}
 public AABB inflate(double d){return new AABB(minX-d,minY-d,minZ-d,maxX+d,maxY+d,maxZ+d);}
}''',
'net/minecraft/world/entity/Entity.java':'''package net.minecraft.world.entity;
import net.minecraft.world.phys.*;import net.minecraft.world.level.Level;
public class Entity {
 public double x,y,z;public boolean alive=true;public int tickCount;public Level world;public String type="minecraft:entity";
 public double getX(){return x;}public double getY(){return y;}public double getZ(){return z;}
 public boolean isAlive(){return alive;}public Level level(){return world;}
 public Object getType(){return type;}public double distanceToSqr(Entity e){return (x-e.x)*(x-e.x)+(y-e.y)*(y-e.y)+(z-e.z)*(z-e.z);}
 public AABB getBoundingBox(){return new AABB(x-.3,y,z-.3,x+.3,y+1.8,z+.3);}
}''',
'net/minecraft/world/entity/LivingEntity.java':'''package net.minecraft.world.entity;public class LivingEntity extends Entity {public float yBodyRot;public double getEyeY(){return y+1.62;}}''',
'net/minecraft/world/entity/Mob.java':'''package net.minecraft.world.entity;
public class Mob extends LivingEntity {public LivingEntity target;public Navigation nav=new Navigation();
 public void setTarget(LivingEntity e){target=e;}public Navigation getNavigation(){return nav;}
 public static class Navigation {public Entity destination;public boolean moveTo(Entity e,double speed){destination=e;return true;}}
}''',
'net/minecraft/world/entity/monster/Zombie.java':'''package net.minecraft.world.entity.monster;public class Zombie extends net.minecraft.world.entity.Mob {public Zombie(){type="minecraft:zombie";}}''',
'net/minecraft/world/InteractionHand.java':'''package net.minecraft.world;public enum InteractionHand {MAIN_HAND,OFF_HAND}''',
'net/minecraft/world/InteractionResultHolder.java':'''package net.minecraft.world;public record InteractionResultHolder<T>(T object,boolean success) {
 public static <T> InteractionResultHolder<T> fail(T t){return new InteractionResultHolder<>(t,false);}
 public static <T> InteractionResultHolder<T> sidedSuccess(T t,boolean client){return new InteractionResultHolder<>(t,true);}
}''',
'net/minecraft/world/level/ItemLike.java':'''package net.minecraft.world.level;public interface ItemLike {}''',
'net/minecraft/world/item/Item.java':'''package net.minecraft.world.item;
import net.minecraft.world.*;import net.minecraft.world.entity.player.Player;import net.minecraft.world.level.*;
public class Item implements ItemLike {public int stackSize;public Item(Properties p){stackSize=p.size;}
 public ItemStack getDefaultInstance(){return new ItemStack(this);}
 public InteractionResultHolder<ItemStack> use(Level l,Player p,InteractionHand h){return InteractionResultHolder.fail(p.getItemInHand(h));}
 public static class Properties {public int size=64;public Properties stacksTo(int i){size=i;return this;}}
}''',
'net/minecraft/world/item/ItemStack.java':'''package net.minecraft.world.item;public class ItemStack {public Item item;public int count=1;public ItemStack(Item i){item=i;}}''',
'net/minecraft/world/item/Items.java':'''package net.minecraft.world.item;public class Items {public static final Item SLIME_BALL=new Item(new Item.Properties());}''',
'net/minecraft/network/chat/Component.java':'''package net.minecraft.network.chat;public record Component(String text) {public static Component literal(String text){return new Component(text);}}''',
'net/minecraft/world/entity/player/Player.java':'''package net.minecraft.world.entity.player;
import net.minecraft.world.*;import net.minecraft.world.entity.*;import net.minecraft.world.item.*;import net.minecraft.world.phys.*;
import net.minecraft.network.chat.Component;import java.util.*;
public class Player extends LivingEntity {
 public boolean creative,spectator,swimming;public Object model;public ItemStack hand;public List<String> messages=new ArrayList<>();public int syncs;
 public boolean isCreative(){return creative;}public boolean isSpectator(){return spectator;}public boolean isVisuallySwimming(){return swimming;}
 public ItemStack getItemInHand(InteractionHand h){return hand;}public Vec3 getLookAngle(){return new Vec3(0,0,1);}
 public void displayClientMessage(Component c,boolean actionbar){messages.add(c.text());}
}''',
'net/minecraft/server/level/ServerPlayer.java':'''package net.minecraft.server.level;public class ServerPlayer extends net.minecraft.world.entity.player.Player {}''',
'net/minecraft/world/level/material/FluidState.java':'''package net.minecraft.world.level.material;
import net.minecraft.world.level.Level;import net.minecraft.core.BlockPos;
public class FluidState {public float height;public FluidState(float h){height=h;}public boolean is(Object tag){return height>0;}
 public float getHeight(Level l,BlockPos p){return height;}}
''',
'net/minecraft/core/particles/ParticleTypes.java':'''package net.minecraft.core.particles;public class ParticleTypes {public static final Object ITEM=new Object();}''',
'net/minecraft/core/particles/ItemParticleOption.java':'''package net.minecraft.core.particles;
import net.minecraft.world.item.ItemStack;public record ItemParticleOption(Object type,ItemStack item){}''',
'net/minecraft/resources/ResourceLocation.java':'''package net.minecraft.resources;public record ResourceLocation(String ns,String path) {
 public static ResourceLocation fromNamespaceAndPath(String ns,String path){return new ResourceLocation(ns,path);}
 public String toString(){return ns+":"+path;}}
''',
'net/minecraft/sounds/SoundEvent.java':'''package net.minecraft.sounds;import net.minecraft.resources.ResourceLocation;
public record SoundEvent(ResourceLocation location) {public static SoundEvent createVariableRangeEvent(ResourceLocation id){return new SoundEvent(id);}}''',
'net/minecraft/sounds/SoundSource.java':'''package net.minecraft.sounds;public enum SoundSource {PLAYERS}''',
'net/minecraft/world/level/Level.java':'''package net.minecraft.world.level;
import net.minecraft.core.*;import net.minecraft.world.level.material.*;import net.minecraft.world.entity.*;import net.minecraft.world.entity.player.*;
import net.minecraft.world.phys.*;import net.minecraft.sounds.*;import net.minecraft.core.particles.*;import java.util.*;import java.util.function.Predicate;
public class Level {
 public boolean client;public double waterHeight=-100;public List<Mob> mobs=new ArrayList<>();public int sounds,particles;public double particleY,particleZ;public ItemParticleOption mucus;
 public boolean isClientSide(){return client;}
 public FluidState getFluidState(BlockPos p){return new FluidState((float)Math.max(0,Math.min(1,waterHeight-p.y())));}
 public void playSound(Player except,double x,double y,double z,SoundEvent s,SoundSource src,float volume,float pitch){sounds++;}
 public int sendParticles(ItemParticleOption p,double x,double y,double z,int count,double dx,double dy,double dz,double speed){particles++;particleY=y;particleZ=z;mucus=p;return 1;}
 public <T extends Entity> List<T> getEntitiesOfClass(Class<T> c,AABB b,Predicate<? super T> f){List<T> out=new ArrayList<>();for(Mob m:mobs)if(c.isInstance(m)&&f.test(c.cast(m)))out.add(c.cast(m));return out;}
}''',
'net/minecraft/core/registries/BuiltInRegistries.java':'''package net.minecraft.core.registries;
public class BuiltInRegistries {public static final Registry ENTITY_TYPE=new Registry();public static class Registry {public Object getKey(Object t){return t;}}}''',
'net/neoforged/neoforge/registries/DeferredRegister.java':'''package net.neoforged.neoforge.registries;
import java.util.*;import java.util.function.*;import net.minecraft.world.item.Item;
public class DeferredRegister {
 public Map<String,Object> entries=new HashMap<>();
 public DeferredHolder register(String n,Supplier<?> s){DeferredHolder h=new DeferredHolder(s.get());entries.put(n,h);return h;}
 public static class DeferredHolder {public Object value;public DeferredHolder(Object v){value=v;}public Object get(){return value;}public Object getKey(){return "firstaid:main_tab";}}
 public static class Items extends DeferredRegister {public DeferredHolder registerItem(String n,Function<Item.Properties,Item> factory){DeferredHolder h=new DeferredHolder(factory.apply(new Item.Properties()));entries.put(n,h);return h;}}
}''',
'ichttt/mods/firstaid/common/util/CommonUtils.java':'''package ichttt.mods.firstaid.common.util;
import net.minecraft.world.entity.player.Player;import net.minecraft.server.level.ServerPlayer;
public class CommonUtils {public static Object getDamageModel(Player p){return p.model;}public static void syncDamageModel(ServerPlayer p){p.syncs++;}}
''',
'ichttt/mods/firstaid/common/RegistryObjects.java':'''package ichttt.mods.firstaid.common;
import net.neoforged.neoforge.registries.DeferredRegister.DeferredHolder;
public class RegistryObjects {public static final DeferredHolder CREATIVE_TAB=new DeferredHolder("tab");}''',
'net/neoforged/neoforge/event/BuildCreativeModeTabContentsEvent.java':'''package net.neoforged.neoforge.event;
import java.util.*;import net.minecraft.world.level.ItemLike;
public class BuildCreativeModeTabContentsEvent {public List<ItemLike> items=new ArrayList<>();public Object getTabKey(){return "firstaid:main_tab";}public void accept(ItemLike i){items.add(i);}}''',
'net/minecraft/client/Minecraft.java':'''package net.minecraft.client;import net.minecraft.world.entity.player.Player;
public class Minecraft {public Player player;public static final Minecraft INSTANCE=new Minecraft();public static Minecraft getInstance(){return INSTANCE;}}''',
'ichttt/mods/firstaid/api/enums/EnumPlayerPart.java':'''package ichttt.mods.firstaid.api.enums;public enum EnumPlayerPart {HEAD,LEFT_ARM,LEFT_LEG,LEFT_FOOT,BODY,RIGHT_ARM,RIGHT_LEG,RIGHT_FOOT}'''
}
def run(*args): subprocess.run([str(a) for a in args],check=True)
with tempfile.TemporaryDirectory(prefix='firstaid-checks-') as folder:
 folder=Path(folder);stubs=folder/'stubs';runtime=folder/'runtime';classes=folder/'classes'
 for name,source in SOURCES.items():
  p=stubs/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(source)
 with zipfile.ZipFile(JAR) as z:
  assert z.testzip() is None
  for name in z.namelist():
   if name.startswith('ichttt/mods/firstaid/survival/Wet') or name=='ichttt/mods/firstaid/survival/TowelItem.class':
    p=runtime/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
  recipe=json.loads(z.read('data/firstaid/recipe/towel.json'))
  assert recipe['ingredients']==[{'item':'firstaid:cloth'}]*3 and recipe['result']=={'id':'firstaid:towel','count':1}
  assert json.loads(z.read('assets/firstaid/sounds.json'))['debuff.heartbeat']['sounds']==[]
  assert not any('SubtlePanic' in n for n in json.loads(z.read('firstaid.mixins.json'))['client'])
  assert z.read('assets/firstaid/sounds/sneeze.ogg').startswith(b'OggS')
  assert z.read('assets/firstaid/textures/item/towel.png').startswith(b'\x89PNG')
  sound=folder/'sneeze.ogg';sound.write_bytes(z.read('assets/firstaid/sounds/sneeze.ogg'))
  run('ffmpeg','-hide_banner','-loglevel','error','-i',sound,'-f','null','-')
 compiler=['java','-jar',CACHE/'ecj.jar','-21','-proc:none','-warn:none']
 run(*compiler,'-cp',runtime,'-d',classes,*sorted(stubs.rglob('*.java')),ROOT/'tests/WetChecks.java',ROOT/'tests/IntegrationChecks.java')
 cp=str(classes)+':'+str(runtime)
 run('java','-Xverify:all','-cp',cp,'WetChecks')
 run('java','-Xverify:all','-cp',cp,'IntegrationChecks')
 asmcp=':'.join(str(CACHE/n) for n in ['asm.jar','asm-tree.jar','asm-analysis.jar','asm-util.jar'])
 run(*compiler,'-cp',asmcp,'-d',classes,ROOT/'tests/BytecodeChecks.java')
 run('java','-cp',str(classes)+':'+asmcp,'BytecodeChecks',JAR)
 print('PASS: JAR resources, towel recipe, global heartbeat mute and removed panic mixins')
