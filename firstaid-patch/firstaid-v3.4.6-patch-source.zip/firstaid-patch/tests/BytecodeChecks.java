import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import org.objectweb.asm.util.CheckClassAdapter;
import java.util.*;
import java.util.zip.*;

public final class BytecodeChecks implements Opcodes {
    static final String FA="ichttt/mods/firstaid/";
    static int methods,checks;
    static void check(boolean ok,String text){checks++;if(!ok)throw new AssertionError(text);}
    static ClassNode read(ZipFile z,String name)throws Exception {
        ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(FA+name+".class"))).accept(c,0);return c;
    }
    static MethodNode method(ClassNode c,String name){return c.methods.stream().filter(m->m.name.equals(name)).findFirst().orElseThrow();}
    static List<AbstractInsnNode> ops(MethodNode m){return Arrays.stream(m.instructions.toArray()).filter(i->i.getOpcode()>=0).toList();}
    static boolean calls(ClassNode c,String owner,String name) {
        for(MethodNode m:c.methods)for(AbstractInsnNode i:m.instructions)
            if(i instanceof MethodInsnNode v && v.owner.equals(FA+owner) && v.name.equals(name))return true;
        return false;
    }
    public static void main(String[] args)throws Exception {
        try(ZipFile z=new ZipFile(args[0])) {
            List<String> targets=List.of("client/HeartbeatSoundController","client/SubtlePanicController",
                "client/ProjectileNearMissDetector","client/SuppressionFeedbackController","client/PainVisualEffectsController",
                "common/damagesystem/PlayerDamageModel","common/EventHandler","survival/ClinicalHooks","survival/ClinicalData",
                "common/RegistryObjects","fracture/FractureMod","client/gui/GuiHealthScreen",
                "survival/WetGameplay","survival/WetState","survival/WetGeometry","survival/WetGeometry$Box",
                "survival/WetReflection","survival/WetClient","survival/TowelItem");
            for(String n:targets) {
                ClassNode c=read(z,n);
                c.accept(new CheckClassAdapter(new ClassWriter(0),false));
                for(MethodNode m:c.methods) {
                    if((m.access&(ACC_ABSTRACT|ACC_NATIVE))!=0)continue;
                    try {new Analyzer<>(new BasicVerifier()).analyze(c.name,m);methods++;}
                    catch(AnalyzerException e){throw new AssertionError(n+"."+m.name+m.desc,e);}
                }
            }
            check(ops(method(read(z,"client/HeartbeatSoundController"),"tick")).size()==1,"Heartbeat has no playback path");
            check(ops(method(read(z,"client/SubtlePanicController"),"update")).size()==1,"Panic scan removed");
            check(ops(method(read(z,"client/ProjectileNearMissDetector"),"tick")).size()==1,"Client near-miss scan disabled");
            ClassNode model=read(z,"common/damagesystem/PlayerDamageModel");
            for(MethodNode m:model.methods) {
                if(m.name.equals("ensureEncounterAdrenaline") || m.name.equals("registerAdrenalineNearMiss") || m.name.equals("forceMaxSuppression"))
                    check(ops(m).size()==1,"Automatic panic disabled: "+m.name);
            }
            List<AbstractInsnNode> intensity=ops(method(model,"getSuppressionIntensity"));
            check(intensity.size()==2 && intensity.get(0).getOpcode()==FCONST_0,"No model-driven suppression overlay");
            ClassNode feedback=read(z,"client/SuppressionFeedbackController");
            for(String n:List.of("getTinnitusStrength","getVisualStrength"))
                check(ops(method(feedback,n)).get(0).getOpcode()==FCONST_0,"No white/gray screen edge: "+n);
            check(calls(read(z,"survival/ClinicalHooks"),"survival/WetGameplay","tick"),"Server tick wired");
            check(calls(read(z,"survival/ClinicalData"),"survival/WetGameplay","write") && calls(read(z,"survival/ClinicalData"),"survival/WetGameplay","read"),"Saved/wire model serialization wired");
            check(calls(read(z,"common/RegistryObjects"),"survival/WetGameplay","register"),"Deferred registry startup wired");
            check(calls(read(z,"fracture/FractureMod"),"survival/WetGameplay","creative"),"Creative tab wired");
            check(calls(read(z,"survival/TowelItem"),"survival/WetGameplay","towelUse"),"Item use wired");
            ClassNode gui=read(z,"client/gui/GuiHealthScreen");
            check(calls(gui,"survival/WetClient","thermal") && calls(gui,"survival/WetClient","status") && calls(gui,"survival/WetClient","humidity"),"Body wetness UI wired");
            // Mixin 0.8.7 requires @Mixin to have CLASS retention (invisible in bytecode).
            for(ZipEntry e:Collections.list(z.entries())) if(e.getName().endsWith(".class") && e.getName().contains("/mixin/")) {
                ClassNode c=new ClassNode();new ClassReader(z.getInputStream(e)).accept(c,ClassReader.SKIP_CODE);
                if(c.name.contains("Accessor") || c.name.contains("Mixin"))
                    check(c.invisibleAnnotations!=null && c.invisibleAnnotations.stream().anyMatch(a->a.desc.equals("Lorg/spongepowered/asm/mixin/Mixin;")),"Preserved CLASS-retained Mixin annotation: "+c.name);
            }
            System.out.println("PASS: "+methods+" methods analyzed for stack/type correctness; "+checks+" bytecode wiring/suppression/mixin checks");
        }
    }
}
