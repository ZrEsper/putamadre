package ichttt.mods.firstaid.survival;

/** Body volumes in the existing EnumPlayerPart order; rotates with body yaw. */
public final class WetGeometry {
    public record Box(double minX, double minY, double minZ,
                      double maxX, double maxY, double maxZ) {
        public boolean intersects(Box b) {
            return maxX > b.minX && minX < b.maxX && maxY > b.minY && minY < b.maxY
                    && maxZ > b.minZ && minZ < b.maxZ;
        }
    }
    public static Box[] parts(double x, double y, double z, double width, double height,
                              double yaw, boolean horizontal) {
        double scale = width / 0.6;
        double[][] regions = {
            {-.14,.78,-.14,.14,1,.14}, // head
            {.15,.43,-.10,.30,.78,.10}, // left arm
            {.015,.15,-.12,.14,.44,.12}, // left leg
            {.015,0,-.13,.14,.15,.13}, // left foot
            {-.15,.44,-.12,.15,.78,.12}, // torso
            {-.30,.43,-.10,-.15,.78,.10}, // right arm
            {-.14,.15,-.12,-.015,.44,.12}, // right leg
            {-.14,0,-.13,-.015,.15,.13} // right foot
        };
        Box[] out = new Box[8];
        double sin = Math.sin(Math.toRadians(yaw)), cos = Math.cos(Math.toRadians(yaw));
        for (int i = 0; i < 8; i++) {
            double[] r = regions[i];
            double minX=Double.POSITIVE_INFINITY,minY=minX,minZ=minX;
            double maxX=Double.NEGATIVE_INFINITY,maxY=maxX,maxZ=maxX;
            for (int a=0;a<2;a++) for (int b=0;b<2;b++) for (int c=0;c<2;c++) {
                double right=r[a==0?0:3]*scale, up=r[b==0?1:4], depth=r[c==0?2:5]*scale;
                double forward = horizontal ? (up-.5)*1.8*scale : depth;
                double px=x+right*cos-forward*sin;
                double py=horizontal ? y+height/2+depth : y+up*height;
                double pz=z+right*sin+forward*cos;
                minX=Math.min(minX,px); maxX=Math.max(maxX,px);
                minY=Math.min(minY,py); maxY=Math.max(maxY,py);
                minZ=Math.min(minZ,pz); maxZ=Math.max(maxZ,pz);
            }
            out[i]=new Box(minX,minY,minZ,maxX,maxY,maxZ);
        }
        return out;
    }
}
