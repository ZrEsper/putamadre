package ichttt.mods.firstaid.survival;

import static ichttt.mods.firstaid.survival.WetReflection.*;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.Predicate;

public final class WetGameplay {
    private static final Map<Object,WetState> STATES=Collections.synchronizedMap(new WeakHashMap<>());
    public static Object TOWEL, SNEEZE;
    private static final String MC="net.minecraft.";
    private static final String FA="ichttt.mods.firstaid.";

    public static WetState state(Object model) {return STATES.computeIfAbsent(model,k->new WetState());}
    public static Object model(Object player) {return stat(FA+"common.util.CommonUtils","getDamageModel",player);}
    private static void sync(Object model,Object player) {
        call(model,"scheduleResync");
        stat(FA+"common.util.CommonUtils","syncDamageModel",player);
    }
    private static void say(Object player,String text) {
        call(player,"displayClientMessage",stat(MC+"network.chat.Component","literal",text),true);
    }
    public static void register(Object itemRegister,Object soundRegister) {
        Function<Object,Object> factory=properties -> create(FA+"survival.TowelItem",call(properties,"stacksTo",1));
        TOWEL=call(itemRegister,"registerItem","towel",factory);
        Supplier<Object> sound=()->stat(MC+"sounds.SoundEvent","createVariableRangeEvent",
                stat(MC+"resources.ResourceLocation","fromNamespaceAndPath","firstaid","sneeze"));
        SNEEZE=call(soundRegister,"register","sneeze",sound);
    }
    public static void creative(Object event) {
        Object tab=constant(FA+"common.RegistryObjects","CREATIVE_TAB");
        if(call(event,"getTabKey").equals(call(tab,"getKey"))) call(event,"accept",call(TOWEL,"get"));
    }
    public static void tick(Object model,Object player) {
        if(player==null || !type(MC+"server.level.ServerPlayer").isInstance(player)) return;
        if(!(Boolean)call(player,"isAlive") || (Boolean)call(player,"isCreative") || (Boolean)call(player,"isSpectator")) return;
        WetState s=state(model);
        int tick=integer(get(player,"tickCount"));
        if(s.lastTick==tick) return;
        s.lastTick=tick;
        Object level=call(player,"level");
        Object bounds=call(player,"getBoundingBox");
        double y=number(get(bounds,"minY"));
        double height=number(get(bounds,"maxY"))-y;
        double width=number(get(bounds,"maxX"))-number(get(bounds,"minX"));
        boolean horizontal=(Boolean)call(player,"isVisuallySwimming");
        double yaw=number(get(player,"yBodyRot"));
        WetGeometry.Box[] parts=WetGeometry.parts(number(call(player,"getX")),y,
                number(call(player,"getZ")),width,height,yaw,horizontal);
        boolean[] contact=new boolean[8];
        boolean started=false;
        for(int i=0;i<8;i++) {
            contact[i]=touchesWater(level,parts[i]);
            if(contact[i] && s.wet[i]==0) started=true;
        }
        ThreadLocalRandom rng=ThreadLocalRandom.current();
        int events=s.advance(contact,rng.nextDouble(),rng.nextInt(200,401));
        if((events&1)!=0) say(player,"Has contraído gripe por permanecer húmedo. Se recupera en unos 2 minutos.");
        if((events&2)!=0) say(player,"Te has recuperado de la gripe.");
        if((events&4)!=0) sneeze(player,level);
        if(s.flu>0 && tick%400==0) say(player,"Gripe: "+(s.flu+19)/20+" s. Tus estornudos atraen zombis.");
        if(started || events!=0 || tick%20==0) sync(model,player);
    }

    public static boolean touchesWater(Object level,WetGeometry.Box b) {
        Object water=constant(MC+"tags.FluidTags","WATER");
        for(int x=(int)Math.floor(b.minX());x<(int)Math.ceil(b.maxX());x++)
            for(int y=(int)Math.floor(b.minY());y<(int)Math.ceil(b.maxY());y++)
                for(int z=(int)Math.floor(b.minZ());z<(int)Math.ceil(b.maxZ());z++) {
                    Object pos=create(MC+"core.BlockPos",x,y,z);
                    Object fluid=call(level,"getFluidState",pos);
                    if(!(Boolean)call(fluid,"is",water)) continue;
                    double h=number(call(fluid,"getHeight",level,pos));
                    if(b.intersects(new WetGeometry.Box(x,y,z,x+1,y+h,z+1))) return true;
                }
        return false;
    }

    public static void sneeze(Object player,Object level) {
        double x=number(call(player,"getX")),y=number(call(player,"getEyeY"))-.08,z=number(call(player,"getZ"));
        Object look=call(player,"getLookAngle");
        double dx=number(get(look,"x")),dy=number(get(look,"y")),dz=number(get(look,"z"));
        Object sound=call(SNEEZE,"get");
        call(level,"playSound",null,x,y,z,sound,constant(MC+"sounds.SoundSource","PLAYERS"),1.0f,1.0f);
        Object slime=call(constant(MC+"world.item.Items","SLIME_BALL"),"getDefaultInstance");
        Object particles=create(MC+"core.particles.ItemParticleOption",constant(MC+"core.particles.ParticleTypes","ITEM"),slime);
        // A directional mucus spray, beginning at the face; sent by the server to observers.
        for(int i=0;i<8;i++) call(level,"sendParticles",particles,
                x+dx*.24,y+dy*.24,z+dz*.24,0,dx*.6,dy*.6+.05,dz*.6,.18);
        attract(player,level);
    }
    public static void attract(Object player,Object level) {
        Object box=call(call(player,"getBoundingBox"),"inflate",32.0);
        Predicate<Object> zombie=mob -> {
            if(!(Boolean)call(mob,"isAlive") || number(call(mob,"distanceToSqr",player))>1024.0) return false;
            if(type(MC+"world.entity.monster.Zombie").isInstance(mob)) return true;
            Object registry=constant(MC+"core.registries.BuiltInRegistries","ENTITY_TYPE");
            String id=String.valueOf(call(registry,"getKey",call(mob,"getType"))).toLowerCase(Locale.ROOT);
            return id.contains("zombie") || id.endsWith(":husk") || id.endsWith(":drowned");
        };
        for(Object mob:(Collection<?>)call(level,"getEntitiesOfClass",type(MC+"world.entity.Mob"),box,zombie)) {
            call(mob,"setTarget",player);
            call(call(mob,"getNavigation"),"moveTo",player,1.0);
        }
    }

    /** Called only by the actual towel item; no client-side gameplay mutation. */
    public static Object towelUse(Object level,Object player,Object hand) {
        Object stack=call(player,"getItemInHand",hand);
        boolean client=(Boolean)call(level,"isClientSide");
        Object model=model(player);
        if(model==null || integer(call(model,"getUnconsciousTicks"))>0)
            return stat(MC+"world.InteractionResultHolder","fail",stack);
        if(!client) {
            WetState s=state(model);
            if(s.average()>0) {
                s.dry(); sync(model,player);
                say(player,"Te has secado con la toalla."+(s.flu>0?" La gripe seguirá su curso.":""));
            } else say(player,"Tu cuerpo ya está seco.");
        }
        return stat(MC+"world.InteractionResultHolder","sidedSuccess",stack,client);
    }

    public static void write(Object model,Object tag) {
        WetState s=state(model);
        Object data=create(MC+"nbt.CompoundTag");
        call(data,"putIntArray","parts",s.wet.clone());
        call(data,"putInt","exposure",s.exposure);
        call(data,"putInt","flu",s.flu);
        call(data,"putInt","sneeze",s.sneeze);
        call(data,"putBoolean","immune",s.immune);
        call(tag,"put","zomboidWetness",data);
    }
    public static void read(Object model,Object tag) {
        Object data=call(tag,"getCompound","zomboidWetness");
        WetState s=new WetState();
        int[] parts=(int[])call(data,"getIntArray","parts");
        for(int i=0;i<Math.min(8,parts.length);i++) s.wet[i]=Math.max(0,Math.min(WetState.DRY_TICKS,parts[i]));
        s.exposure=Math.max(0,Math.min(1000000,integer(call(data,"getInt","exposure"))));
        s.flu=Math.max(0,Math.min(WetState.FLU_TICKS,integer(call(data,"getInt","flu"))));
        s.sneeze=Math.max(0,Math.min(400,integer(call(data,"getInt","sneeze"))));
        s.immune=(Boolean)call(data,"getBoolean","immune") || s.flu>0;
        STATES.put(model,s);
    }
}
