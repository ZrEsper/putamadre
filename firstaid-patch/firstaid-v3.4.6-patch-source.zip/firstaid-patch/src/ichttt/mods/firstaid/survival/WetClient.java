package ichttt.mods.firstaid.survival;

import static ichttt.mods.firstaid.survival.WetReflection.*;

/** Loaded exclusively by the client health screen; works without Homeostatic. */
public final class WetClient {
    private static Object player(Object screen) {return get(get(screen,"minecraft"),"player");}
    public static Object homeostasis(Object player) {
        try {
            return stat("ichttt.mods.firstaid.client.gui.HomeostasisView","read",player);
        } catch (RuntimeException | LinkageError unavailable) {
            // Homeostatic is optional; its absence must not hide the new wetness panel.
            return null;
        }
    }
    public static double humidity() {
        Object mc=stat("net.minecraft.client.Minecraft","getInstance");
        Object player=get(mc,"player");
        Object model=player==null?null:WetGameplay.model(player);
        return model==null?0:WetGameplay.state(model).average();
    }
    public static int thermal(Object screen,Object graphics,int x,int y) {
        y=integer(call(screen,"wetnessNativeThermal",graphics,x,y));
        Object player=player(screen);
        Object model=player==null?null:WetGameplay.model(player);
        if(model==null) return y;
        WetState s=WetGameplay.state(model);
        y+=8;
        y=integer(call(screen,"heading",graphics,"Humedad por parte del cuerpo",x,y));
        String[] names={"Cabeza","Brazo izquierdo","Pierna izquierda","Pie izquierdo","Torso","Brazo derecho","Pierna derecha","Pie derecho"};
        for(int i=0;i<8;i++) {
            int percent=(int)Math.ceil(100.0*s.wet[i]/WetState.DRY_TICKS);
            y=integer(call(screen,"line",graphics,names[i]+": "+percent+" %",x,y,
                    s.wet[i]>0?0xFF70BCE8:0xFF9AAEAA));
        }
        y=integer(call(screen,"line",graphics,s.flu>0?"Gripe: "+(s.flu+19)/20+" s":"Sin gripe",x,y,
                s.flu>0?0xFF9DCE65:0xFF9AAEAA));
        return integer(call(screen,"wrapped",graphics,"Secado natural: unos 2 minutos fuera del agua. Usa una toalla para secarte. Los estornudos atraen zombis a 32 bloques.",x,y+4,0xFF9AAEAA));
    }
    public static int status(Object screen,Object graphics,Object model,int x,int y) {
        y=integer(call(screen,"wetnessNativeStatus",graphics,model,x,y));
        WetState s=WetGameplay.state(model);
        if(s.flu>0) y=integer(call(screen,"line",graphics,"Gripe: "+(s.flu+19)/20+" s · Estornudos",x,y,0xFF9DCE65));
        return y;
    }
}
