package ichttt.mods.firstaid.survival;

/** Server-owned timers, mirrored through the existing First Aid model packet. */
public final class WetState {
    public static final int DRY_TICKS = 2400, FLU_TICKS = 2400;
    public final int[] wet = new int[8];
    public int exposure, flu, sneeze;
    public boolean immune;
    public int lastTick = Integer.MIN_VALUE;

    public double average() {
        long total = 0;
        for (int value : wet) total += value;
        return total / (8.0 * DRY_TICKS);
    }

    /** Returns 1 for a new illness, 2 for recovery, 4 for a sneeze. */
    public int advance(boolean[] contact, double roll, int sneezeDelay) {
        for (int i = 0; i < 8; i++) wet[i] = contact[i] ? DRY_TICKS : Math.max(0, wet[i] - 1);
        int events = 0;
        if (flu > 0) {
            if (--flu == 0) {
                sneeze = 0;
                events |= 2;
            } else if (--sneeze <= 0) {
                sneeze = Math.max(200, Math.min(400, sneezeDelay));
                events |= 4;
            }
        }
        if (average() > 0) {
            exposure = Math.min(1000000, exposure + 1);
            // No risk from a brief splash: 15 seconds of retained wetness first.
            // At most one illness per wet episode; continuous water cannot extend it.
            if (flu == 0 && !immune && exposure >= 300 && exposure % 100 == 0
                    && roll < 0.15 * average()) {
                flu = FLU_TICKS;
                sneeze = Math.max(200, Math.min(400, sneezeDelay));
                immune = true;
                events |= 1;
            }
        } else {
            exposure = 0;
            if (flu == 0) immune = false;
        }
        return events;
    }

    public void dry() {
        java.util.Arrays.fill(wet, 0);
        exposure = 0;
        // Drying prevents further exposure; an existing flu still runs its course.
        if (flu == 0) immune = false;
    }
}
