#!/usr/bin/env python3
"""Patch the supplied First Aid JAR without changing its source checkout."""
from pathlib import Path
import hashlib, json, math, os, random, struct, subprocess, sys, tempfile, wave, zipfile, zlib

ROOT = Path(__file__).resolve().parent
BASE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/workspace/attachments/b9b1cab8-3970-473b-a7fe-ef4b850cf4c0/firstaid-1.21.1-ZOMBOID-v3.4.5-skills-menu.jar')
CACHE = Path(os.environ.get('FIRSTAID_BUILD_CACHE', str(ROOT / 'tools')))
OUTPUT = ROOT / 'output/firstaid-1.21.1-ZOMBOID-v3.4.6-wetness-no-panic.jar'
EXPECTED_BASE = '2a3ffba198d4be73a2060d0426d95630a3cc4b75c17f78115a8facd8922a6a40'
EXPECTED_TOOLS = {
    'ecj.jar':'01f5a92ac19bb2b3bf85e295a68f2c73c264369109158b566ce9b490af982948',
    'asm.jar':'8cadd43ac5eb6d09de05faecca38b917a040bb9139c7edeb4cc81c740b713281',
    'asm-tree.jar':'9929881f59eb6b840e86d54570c77b59ce721d104e6dfd7a40978991c2d3b41f',
    'asm-util.jar':'f885be71b5c90556f5f1ad1c4f9276b29b96057c497d46666fe4ddbec3cb43c6',
    'asm-analysis.jar':'85b29371884ba31bb76edf22323c2c24e172c3267a67152eba3d1ccc2e041ef2',
}
def run(*args): subprocess.run([str(a) for a in args], check=True)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def png():
    # Original 16x16 folded linen towel sprite.
    pixels=[]
    for y in range(16):
        row=bytearray([0])
        for x in range(16):
            if not (2<=x<=13 and 3<=y<=12): rgba=(0,0,0,0)
            elif x in (2,13) or y in (3,12): rgba=(134,139,130,255)
            elif y in (5,10): rgba=(91,147,166,255)
            elif x in (11,12): rgba=(184,189,176,255)
            else:
                tone=222 if (x+y)%2 else 235
                rgba=(tone,tone,min(255,tone-7),255)
            row.extend(rgba)
        pixels.append(row)
    def chunk(n,d): return struct.pack('>I',len(d))+n+d+struct.pack('>I',zlib.crc32(n+d)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',16,16,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(pixels)))+chunk(b'IEND',b'')
def audio(folder):
    # Original short breath/aspiration sound; no third-party sound samples.
    rng=random.Random(346); samples=[]; low=0.0; rate=22050
    for i in range(int(.72*rate)):
        t=i/rate; noise=rng.uniform(-1,1); low=.7*low+.3*noise
        if t<.20: env=.10*math.sin(math.pi*t/.20)**2
        elif t<.26: env=0.0
        elif t<.38: env=.8*math.sin(math.pi*(t-.26)/.12)**.65
        else: env=.30*math.exp(-(t-.38)*12)
        sample=env*(.78*(noise-low)+.22*math.sin(2*math.pi*155*t))
        samples.append(struct.pack('<h',int(max(-1,min(1,sample))*30000)))
    wav=folder/'sneeze.wav'
    with wave.open(str(wav),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(b''.join(samples))
    ogg=folder/'sneeze.ogg'
    run('ffmpeg','-hide_banner','-loglevel','error','-y','-i',wav,'-c:a','libvorbis','-q:a','4',ogg)
    # Normalize the otherwise random Ogg stream serial and repair page CRCs.
    data=bytearray(ogg.read_bytes()); start=0
    while start<len(data):
        assert data[start:start+4]==b'OggS'
        segments=data[start+26]
        length=27+segments+sum(data[start+27:start+27+segments])
        data[start+14:start+18]=struct.pack('<I',0xFA346)
        data[start+22:start+26]=b'\0'*4
        crc=0
        for byte in data[start:start+length]:
            crc^=byte<<24
            for _ in range(8): crc=((crc<<1)^0x04C11DB7 if crc&0x80000000 else crc<<1)&0xffffffff
        data[start+22:start+26]=struct.pack('<I',crc)
        start+=length
    return bytes(data)

def main():
    if EXPECTED_BASE!='TO_BE_FILLED' and digest(BASE)!=EXPECTED_BASE: raise RuntimeError('Unexpected input JAR; refuse to patch a different version')
    for n,h in EXPECTED_TOOLS.items():
        if digest(CACHE/n)!=h: raise RuntimeError('Compiler/ASM checksum mismatch: '+n)
    OUTPUT.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='firstaid-wetness-') as temp:
        temp=Path(temp); classes=temp/'classes'; tools=temp/'tools'
        compiler=['java','-jar',CACHE/'ecj.jar','-21','-proc:none','-warn:none']
        run(*compiler,'-d',classes,*sorted((ROOT/'src').rglob('*.java')))
        cp=str(CACHE/'asm.jar')+':'+str(CACHE/'asm-tree.jar')
        run(*compiler,'-cp',cp,'-d',tools,ROOT/'tools/PatchFirstAid.java')
        patched=temp/'patched.jar'
        run('java','-cp',str(tools)+':'+cp,'PatchFirstAid',BASE,classes,patched)
        resources={}
        with zipfile.ZipFile(patched) as original:
            mixins=json.loads(original.read('firstaid.mixins.json'))
            mixins['client']=[n for n in mixins['client'] if n not in ('client.SubtlePanicMixin','client.SubtlePanicLoopMixin')]
            resources['firstaid.mixins.json']=json.dumps(mixins,indent=2).encode()
            sounds=json.loads(original.read('assets/firstaid/sounds.json'))
            # Silence this registered event globally, including the separate morphine controller.
            sounds['debuff.heartbeat']['sounds']=[]
            sounds['sneeze']={'sounds':[{'name':'firstaid:sneeze'}],'subtitle':'subtitles.firstaid.sneeze'}
            resources['assets/firstaid/sounds.json']=json.dumps(sounds,indent=2).encode()
            for name in original.namelist():
                if name.startswith('assets/firstaid/lang/') and name.endswith('.json'):
                    lang=json.loads(original.read(name)); spanish='/es_' in name
                    lang['item.firstaid.towel']='Toalla' if spanish else 'Towel'
                    lang['subtitles.firstaid.sneeze']='Estornudo' if spanish else 'Sneeze'
                    resources[name]=json.dumps(lang,ensure_ascii=False,indent=2).encode()
            metadata=original.read('META-INF/neoforge.mods.toml').decode()
            metadata=metadata.replace('zomboid-v3.4.5-skills-menu','zomboid-v3.4.6-wetness-no-panic')
            metadata=metadata.replace('First Aid · Zomboid v3.4 · Heridas y telas','First Aid · Zomboid v3.4.6 · Humedad y gripe')
            resources['META-INF/neoforge.mods.toml']=metadata.encode()
        resources['data/firstaid/recipe/towel.json']=json.dumps({
            'type':'minecraft:crafting_shapeless',
            'ingredients':[{'item':'firstaid:cloth'} for _ in range(3)],
            'result':{'id':'firstaid:towel','count':1}},indent=2).encode()
        resources['assets/firstaid/models/item/towel.json']=json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':'firstaid:item/towel'}}).encode()
        resources['assets/firstaid/items/towel.json']=json.dumps({'model':{'type':'minecraft:model','model':'firstaid:item/towel'}}).encode()
        resources['assets/firstaid/textures/item/towel.png']=png()
        resources['assets/firstaid/sounds/sneeze.ogg']=audio(temp)
        with zipfile.ZipFile(patched) as original, zipfile.ZipFile(OUTPUT,'w',zipfile.ZIP_DEFLATED) as out:
            for name in original.namelist():
                if name in resources: continue
                entry=zipfile.ZipInfo(name,(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
                out.writestr(entry,original.read(name))
            for name,data in sorted(resources.items()):
                entry=zipfile.ZipInfo(name,(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
                out.writestr(entry,data)
        with zipfile.ZipFile(BASE) as base, zipfile.ZipFile(OUTPUT) as result:
            changed={n for n in base.namelist() if base.read(n)!=result.read(n)}
            expected={'ichttt/mods/firstaid/'+n+'.class' for n in [
                'client/HeartbeatSoundController','client/SubtlePanicController',
                'client/ProjectileNearMissDetector','client/SuppressionFeedbackController','client/PainVisualEffectsController',
                'common/damagesystem/PlayerDamageModel','common/EventHandler','survival/ClinicalHooks','survival/ClinicalData',
                'common/RegistryObjects','fracture/FractureMod','client/gui/GuiHealthScreen']}
            expected.update(n for n in resources if n in base.namelist())
            assert changed==expected,(changed-expected,expected-changed)
            assert not (set(base.namelist())-set(result.namelist())), 'An original entry was removed'
            added=set(result.namelist())-set(base.namelist())
            expected_new={'ichttt/mods/firstaid/survival/'+n+'.class' for n in [
                'WetGameplay','WetState','WetGeometry','WetGeometry$Box','WetReflection','WetClient','TowelItem']}
            expected_new.update(n for n in resources if n not in base.namelist())
            assert added==expected_new,(added-expected_new,expected_new-added)
            for name in resources:
                if name.startswith('assets/firstaid/lang/'):
                    old=json.loads(base.read(name));new=json.loads(result.read(name))
                    assert all(new[k]==v for k,v in old.items()),name
            assert len(result.namelist())==len(set(result.namelist())), 'Duplicate ZIP entries'
            print('PASS: only 12 explicitly patched original classes and declared resources changed; all other mod entries preserved')
        run(sys.executable,ROOT/'tests/run.py',OUTPUT)
    print('Output:',OUTPUT)
    print('SHA256:',digest(OUTPUT))
    print('Full Minecraft/NeoForge modpack startup is not tested by the API doubles.')
if __name__=='__main__': main()
