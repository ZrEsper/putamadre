import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

public final class PatchFirstAid implements Opcodes {
    static final String ROOT="ichttt/mods/firstaid/", GAME=ROOT+"survival/WetGameplay", CLIENT=ROOT+"survival/WetClient";
    static int edits;
    static MethodNode method(ClassNode c,String name,String desc) {
        return c.methods.stream().filter(m->m.name.equals(name) && (desc==null || m.desc.equals(desc)))
                .findFirst().orElseThrow(()->new IllegalStateException(c.name+" missing "+name+desc));
    }
    static void clear(MethodNode m) {
        m.instructions.clear(); m.tryCatchBlocks.clear();
        if(m.localVariables!=null) m.localVariables.clear();
        m.visibleLocalVariableAnnotations=null; m.invisibleLocalVariableAnnotations=null;
        edits++;
    }
    static void constant(MethodNode m,int push,int ret) {clear(m);m.instructions.add(new InsnNode(push));m.instructions.add(new InsnNode(ret));}
    static void noop(MethodNode m) {clear(m);m.instructions.add(new InsnNode(RETURN));}
    static InsnList hook(String owner,String name,String desc,int...vars) {
        InsnList code=new InsnList(); for(int v:vars) code.add(new VarInsnNode(ALOAD,v));
        code.add(new MethodInsnNode(INVOKESTATIC,owner,name,desc,false)); return code;
    }
    static void atReturns(MethodNode m,String name,int...vars) {
        for(AbstractInsnNode i:m.instructions.toArray()) if(i.getOpcode()==RETURN || i.getOpcode()==ARETURN)
            m.instructions.insertBefore(i,hook(GAME,name,"(Ljava/lang/Object;Ljava/lang/Object;)V",vars));
        edits++;
    }
    static void zeroSuppression(ClassNode c,MethodNode m) {
        clear(m);
        for(String field:List.of("adrenalineLevel","adrenalineTicks","adrenalineHeartbeatTriggerId","suppressionIntensity",
                "suppressionHoldTicks","suppressionDecayTicker","suppressionPainReliefTicks","adrenalineExposureTicks",
                "adrenalineFatiguePending","adrenalineFatigueTriggered","adrenalineFatigueTicksLeft")) {
            FieldNode f=c.fields.stream().filter(v->v.name.equals(field)).findFirst().orElseThrow();
            m.instructions.add(new VarInsnNode(ALOAD,0));
            m.instructions.add(new InsnNode(f.desc.equals("F")?FCONST_0:ICONST_0));
            m.instructions.add(new FieldInsnNode(PUTFIELD,c.name,field,f.desc));
        }
        m.instructions.add(new InsnNode(RETURN));
    }
    static void wrapScreen(ClassNode c,String name,boolean model) {
        MethodNode old=method(c,name,null);
        old.name=name.equals("thermal")?"wetnessNativeThermal":"wetnessNativeStatus";
        MethodNode wrapper=new MethodNode(ACC_PRIVATE,name,old.desc,null,null);
        wrapper.instructions.add(new VarInsnNode(ALOAD,0));
        wrapper.instructions.add(new VarInsnNode(ALOAD,1));
        if(model) wrapper.instructions.add(new VarInsnNode(ALOAD,2));
        wrapper.instructions.add(new VarInsnNode(ILOAD,model?3:2));
        wrapper.instructions.add(new VarInsnNode(ILOAD,model?4:3));
        wrapper.instructions.add(new MethodInsnNode(INVOKESTATIC,CLIENT,name,
                model?"(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)I":"(Ljava/lang/Object;Ljava/lang/Object;II)I",false));
        wrapper.instructions.add(new InsnNode(IRETURN)); c.methods.add(wrapper); edits++;
    }
    static byte[] patch(byte[] bytes) {
        ClassNode c=new ClassNode(); new ClassReader(bytes).accept(c,0);
        String name=c.name.substring(ROOT.length());
        switch(name) {
            case "client/HeartbeatSoundController": noop(method(c,"tick",null));break;
            case "client/SubtlePanicController":
                noop(method(c,"update",null));constant(method(c,"getPanicVolume",null),FCONST_1,FRETURN);
                MethodNode volume=method(c,"getPanicVolume",null);volume.instructions.insertBefore(volume.instructions.getLast(),new InsnNode(FNEG));break;
            case "client/ProjectileNearMissDetector":noop(method(c,"tick",null));break;
            case "client/SuppressionFeedbackController":
                for(String getter:List.of("getVisualStrength","getSuppressionIntensity","getTinnitusStrength"))
                    constant(method(c,getter,null),FCONST_0,FRETURN);
                noop(method(c,"onNearMiss",null));break;
            case "client/PainVisualEffectsController":constant(method(c,"isAdrenalineRushActive",null),ICONST_0,IRETURN);break;
            case "common/damagesystem/PlayerDamageModel":
                for(String n:List.of("getAdrenalineLevel","getAdrenalineTicks","getAdrenalineHeartbeatTriggerId","getSuppressionLevel",
                        "getSuppressionPainReliefTicks","getSuppressionHoldTicks","calculateAdrenalineLevel"))
                    constant(method(c,n,null),ICONST_0,IRETURN);
                constant(method(c,"getSuppressionIntensity",null),FCONST_0,FRETURN);
                constant(method(c,"isAdrenalineFatigueReady",null),ICONST_0,IRETURN);
                for(MethodNode m:c.methods) if(List.of("ensureEncounterAdrenaline","registerAdrenalineNearMiss","forceMaxSuppression",
                        "applyAdrenalineFatigue","tickAdrenalineFatigue","tickAdrenalineCombatEffects","startSuppressionPainRelief").contains(m.name)) noop(m);
                zeroSuppression(c,method(c,"tickSuppressionState",null));
                zeroSuppression(c,method(c,"refreshSuppressionSnapshot",null));break;
            case "common/EventHandler":noop(method(c,"tickEncounterAdrenaline",null));break;
            case "survival/ClinicalHooks":
                method(c,"tick",null).instructions.insert(hook(GAME,"tick","(Ljava/lang/Object;Ljava/lang/Object;)V",0,1));edits++;break;
            case "survival/ClinicalData":
                atReturns(method(c,"write",null),"write",0,1);
                atReturns(method(c,"read",null),"read",0,1);break;
            case "common/RegistryObjects":
                MethodNode init=method(c,"<clinit>",null);
                for(AbstractInsnNode i:init.instructions.toArray()) if(i.getOpcode()==RETURN) {
                    InsnList code=new InsnList();
                    code.add(new FieldInsnNode(GETSTATIC,c.name,"ITEM_REGISTER","Lnet/neoforged/neoforge/registries/DeferredRegister$Items;"));
                    code.add(new FieldInsnNode(GETSTATIC,c.name,"SOUND_EVENT_REGISTER","Lnet/neoforged/neoforge/registries/DeferredRegister;"));
                    code.add(new MethodInsnNode(INVOKESTATIC,GAME,"register","(Ljava/lang/Object;Ljava/lang/Object;)V",false));
                    init.instructions.insertBefore(i,code);edits++;
                }break;
            case "fracture/FractureMod":
                method(c,"onBuildTab",null).instructions.insert(hook(GAME,"creative","(Ljava/lang/Object;)V",0));edits++;break;
            case "client/gui/GuiHealthScreen":
                for(MethodNode m:c.methods) for(AbstractInsnNode i:m.instructions.toArray())
                    if(i instanceof MethodInsnNode call && call.name.equals("wetness") && call.owner.equals(ROOT+"client/gui/HomeostasisView$Values")) {
                        m.instructions.insertBefore(i,new InsnNode(POP));
                        m.instructions.set(i,new MethodInsnNode(INVOKESTATIC,CLIENT,"humidity","()D",false));edits++;
                    } else if(i instanceof MethodInsnNode call && call.name.equals("read") && call.owner.equals(ROOT+"client/gui/HomeostasisView")) {
                        MethodInsnNode bridge=new MethodInsnNode(INVOKESTATIC,CLIENT,"homeostasis","(Ljava/lang/Object;)Ljava/lang/Object;",false);
                        m.instructions.set(i,bridge);
                        m.instructions.insert(bridge,new TypeInsnNode(CHECKCAST,ROOT+"client/gui/HomeostasisView$Values"));edits++;
                    }
                wrapScreen(c,"thermal",false);wrapScreen(c,"status",true);break;
            default:throw new IllegalArgumentException(name);
        }
        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);return w.toByteArray();
    }
    static byte[] towel() {
        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);
        String item="net/minecraft/world/item/Item", type=ROOT+"survival/TowelItem";
        w.visit(V21,ACC_PUBLIC|ACC_SUPER,type,null,item,null);
        MethodVisitor m=w.visitMethod(ACC_PUBLIC,"<init>","(L"+item+"$Properties;)V",null,null);
        m.visitCode();m.visitVarInsn(ALOAD,0);m.visitVarInsn(ALOAD,1);
        m.visitMethodInsn(INVOKESPECIAL,item,"<init>","(L"+item+"$Properties;)V",false);
        m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();
        String desc="(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder;";
        m=w.visitMethod(ACC_PUBLIC,"use",desc,null,null);m.visitCode();
        m.visitVarInsn(ALOAD,1);m.visitVarInsn(ALOAD,2);m.visitVarInsn(ALOAD,3);
        m.visitMethodInsn(INVOKESTATIC,GAME,"towelUse","(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",false);
        m.visitTypeInsn(CHECKCAST,"net/minecraft/world/InteractionResultHolder");
        m.visitInsn(ARETURN);m.visitMaxs(0,0);m.visitEnd();w.visitEnd();return w.toByteArray();
    }
    public static void main(String[] args)throws Exception {
        Set<String> targets=new HashSet<>(List.of("client/HeartbeatSoundController","client/SubtlePanicController",
                "client/ProjectileNearMissDetector","client/SuppressionFeedbackController","client/PainVisualEffectsController",
                "common/damagesystem/PlayerDamageModel","common/EventHandler","survival/ClinicalHooks","survival/ClinicalData",
                "common/RegistryObjects","fracture/FractureMod","client/gui/GuiHealthScreen"));
        try(ZipFile input=new ZipFile(args[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(args[2])))) {
            for(ZipEntry e:Collections.list(input.entries())) {
                byte[] data=input.getInputStream(e).readAllBytes();
                if(e.getName().startsWith(ROOT) && e.getName().endsWith(".class")) {
                    String n=e.getName().substring(ROOT.length(),e.getName().length()-6);
                    if(targets.remove(n)) data=patch(data);
                }
                ZipEntry entry=new ZipEntry(e.getName());entry.setTime(0);out.putNextEntry(entry);out.write(data);out.closeEntry();
            }
            if(!targets.isEmpty()) throw new IllegalStateException("Missing targets "+targets);
            try(var files=Files.walk(Path.of(args[1]))) {
                for(Path p:files.filter(p->p.toString().endsWith(".class")).sorted().toList()) {
                    ZipEntry e=new ZipEntry(Path.of(args[1]).relativize(p).toString());e.setTime(0);out.putNextEntry(e);out.write(Files.readAllBytes(p));out.closeEntry();
                }
            }
            ZipEntry e=new ZipEntry(ROOT+"survival/TowelItem.class");e.setTime(0);out.putNextEntry(e);out.write(towel());out.closeEntry();
        }
        System.out.println("Patched "+edits+" methods/hooks; original gameplay entries preserved outside explicit targets.");
    }
}
