from pathlib import Path
import json,zipfile,shutil,subprocess,hashlib,re,ast,math
from PIL import Image
r=Path(__file__).resolve().parent
for n,h in json.loads((r/'inputs.sha256.json').read_text()).items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
work=r/'build';shutil.rmtree(work,ignore_errors=True);work.mkdir()
with zipfile.ZipFile(r/'bases/mutants.zip') as z:z.extractall(work)
cem=work/'assets/mutantszombies/optifine/cem';cem.mkdir(parents=True)
def run(*args):subprocess.run(args,check=True)
def gore(base,art,out,strength):
 original=Image.open(base).convert('RGBA');w,h=original.size;layer=r/'layer.png';mask=r/'mask.png';raw=r/'raw.png'
 expr=f'(u.r>u.g*1.32&&u.r>u.b*1.25&&u.r>.15)?u.a*{strength}:((u.r>.65&&u.g>.57&&u.b>.4&&u.r>u.b*1.1&&u.g>u.b*1.05)?u.a*{strength}:0)'
 run('magick',str(art),'-filter','point','-resize',f'{w}x{h}!','-channel','A','-fx',expr,'+channel',str(layer))
 run('magick',str(layer),str(base),'-compose','DstIn','-composite',str(mask))
 run('magick',str(base),str(mask),'-compose','Over','-composite',str(raw))
 run('magick',str(raw),str(base),'-compose','CopyOpacity','-composite','-strip',str(out))
 changed=Image.open(out).convert('RGBA');assert original.size==changed.size and original.getchannel('A').tobytes()==changed.getchannel('A').tobytes()
profiles={
 'Crawler':('crawler_layer','crawler',1.0,.45,.035,15,.6),
 'BlisterZombie':('blister_zombie_layer','blisterzombie',.8,.55,.05,25,.75),
 'RottenMutant':('rotten_mutant_layer','rottenmutant',.62,.42,.025,18,.85),
 'ZombieBrute':('zombie_brute_layer','zombiebrute',.5,.42,.02,12,.95),
 'MutantBrute':('mutant_brute','mutantbrute',.4,.32,.015,10,1.0),
 'SplitHeadZombie':('split_head_zombie','splitheadzombie',.9,.5,.045,20,.7),
 'Spitter':('spitter_layer','spitter',.58,.38,.03,16,.9)}
poses=json.loads((r/'native-poses.json').read_text());tests=0
for species,(layer,texture,rate,stride,sway,fall,duration) in profiles.items():
 native=poses[species+'Model'];assert 'torso' in native
 base=work/'assets/mutantszombies/textures/entities'/f'{texture}.png';native_size=list(Image.open(base).size)
 for variant,strength in [(1,.55),(2,.8),(3,1)]:
  tex=cem/f'{texture}-native{variant}.png';gore(base,r/'art'/f'{texture}.png',tex,strength)
  anim={
   'var.native_death':'clamp(death_time / '+str(20*duration)+', 0, 1)',
   'var.native_fall':f'torad({fall}) * var.native_death * var.native_death * (3 - 2 * var.native_death)',
   'var.native_recoil':f'if(is_hurt, sin(age * 1.8) * .035, 0)',
  }
  # Driver is empty and attached; EMF keeps EVERY original cube and child.
  for index,(part,data) in enumerate(native.items()):
   pose=data['pose'];x,y,z=pose[:3];rx,ry,rz=(pose[3:]+[0,0,0])[:3]
   # Transform native anchors coherently around the feet; preserve all original spacing at rest.
   anim[part+'.tx']=str(x)
   anim[part+'.ty']=f'24 + ({y} - 24) * cos(var.native_fall) - ({z}) * sin(var.native_fall)'
   anim[part+'.tz']=f'({y} - 24) * sin(var.native_fall) + ({z}) * cos(var.native_fall)'
   if part.startswith('head'):
    anim[part+'.rx']=f'{rx} + torad(head_pitch) + sin(age * {sway*2} + {index}) * {sway} + var.native_fall'
    anim[part+'.ry']=f'{ry} + torad(head_yaw)'
    anim[part+'.rz']=str(rz)
   elif part=='torso':
    anim[part+'.rx']=f'{rx} + sin(age * .08) * {sway} + var.native_recoil + var.native_fall'
    anim[part+'.rz']=f'{rz} + sin(limb_swing * {rate}) * limb_speed * {sway}'
   elif part in ['left_leg','right_leg','leftleg','rightleg']:
    sign=-1 if part.startswith('left') else 1
    anim[part+'.rx']=f'{rx} + {sign} * sin(limb_swing * {rate}) * limb_speed * {stride} * (1 - var.native_death) + var.native_fall'
   elif part in ['left_arm','right_arm']:
    anim[part+'.rx']=f'{part}.rx + var.native_fall'
   # Native arms are reset by prepareMobModel/setupAnim each frame; only death adds the common fall angle.
  d={'credit':'Native MutantsZombies geometry preserved; custom species animation inspired by Blues','texture':tex.name,'textureSize':native_size,'models':[{'part':'torso','id':'native_gore_driver','attach':True,'animations':[anim]}]}
  path=cem/(layer+('' if variant==1 else str(variant))+'.jem');path.write_text(json.dumps(d,indent=2))
  assert all(m.get('attach') is True and not any(k in m for k in ['boxes','submodels','scale','translate','rotate']) for m in d['models']);tests+=1
  assert d['textureSize']==native_size and (cem/d['texture']).exists();tests+=1
  assert not any('zombie_new_' in str(v) or '300'==str(v) for v in anim.values());tests+=1
  # Check zero-death anchors exactly equal native poses and preserve pivot distances while falling.
  for part,data in native.items():
   x,y,z=data['pose'][:3]
   for death in [0,.25,.5,1]:
    angle=math.radians(fall)*death*death*(3-2*death)
    yp=24+(y-24)*math.cos(angle)-z*math.sin(angle);zp=(y-24)*math.sin(angle)+z*math.cos(angle)
    assert math.isclose((yp-24)**2+zp*zp,(y-24)**2+z*z,abs_tol=1e-7)
    if death==0:assert math.isclose(yp,y) and math.isclose(zp,z)
    tests+=1
   for suffix in ['tx','ty','tz']:assert part+'.'+suffix in anim
  for key,expression in anim.items():assert isinstance(expression,str) and expression.count('(')==expression.count(')'),key
 # Native renderer fallback remains species-specific, never a vanilla zombie atlas.
 gore(base,r/'art'/f'{texture}.png',base,.8)
 (cem/f'{layer}.properties').write_text('models.1=1 2 3\nweights.1=55 30 15\n')
meta=json.loads((work/'pack.mcmeta').read_text());meta['pack']['description']='MutantsZombies - native anatomy, species animations and gore v2';(work/'pack.mcmeta').write_text(json.dumps(meta,indent=2))
(work/'LEEME.txt').write_text((r/'README.md').read_text())
(r/'output').mkdir(exist_ok=True);out=r/'output/MutantsZombies-Native-Blues-Inspired-Gore.2.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(work.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(work))
print('PASS',tests,'native-anatomy, texture, anchor and coherent-fall checks')
(r/'output/validation.json').write_text(json.dumps({'checks':tests,'species':7,'native_texture_variants':21,'geometry_replacement':False,'native_children_preserved':True,'vanilla_zombie_atlases':False,'minecraft_visual_tested':False,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
