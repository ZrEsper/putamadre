data modify storage mosslorn:force chunks."minecraft:overworld"."-39_68" set value {"entries":[{"dim":"minecraft:overworld","x":-617,"y":68,"z":1103,"tabla":"mosslorn:chests/world_mix"}],"done":0}
