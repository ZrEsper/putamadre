data modify storage mosslorn:force chunks."minecraft:overworld"."-59_52" set value {"entries":[{"dim":"minecraft:overworld","x":-938,"y":53,"z":846,"tabla":"mosslorn:chests/world_mix"}],"done":0}
