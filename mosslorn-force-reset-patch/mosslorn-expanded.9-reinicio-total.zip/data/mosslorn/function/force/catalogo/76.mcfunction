data modify storage mosslorn:force chunks."minecraft:overworld"."-83_63" set value {"entries":[{"dim":"minecraft:overworld","x":-1314,"y":40,"z":1008,"tabla":"mosslorn:chests/world_mix"}],"done":0}
