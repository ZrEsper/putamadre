data modify storage mosslorn:force chunks."minecraft:overworld"."-76_-38" set value {"entries":[{"dim":"minecraft:overworld","x":-1214,"y":8,"z":-594,"tabla":"mosslorn:chests/world_mix"}],"done":0}
