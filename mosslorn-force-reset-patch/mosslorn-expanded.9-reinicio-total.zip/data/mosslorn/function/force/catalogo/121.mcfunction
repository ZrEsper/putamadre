data modify storage mosslorn:force chunks."minecraft:overworld"."-76_62" set value {"entries":[{"dim":"minecraft:overworld","x":-1215,"y":-42,"z":1005,"tabla":"mosslorn:chests/world_mix"}],"done":0}
