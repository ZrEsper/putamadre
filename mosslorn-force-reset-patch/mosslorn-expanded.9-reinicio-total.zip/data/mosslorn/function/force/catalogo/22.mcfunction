data modify storage mosslorn:force chunks."minecraft:overworld"."-92_14" set value {"entries":[{"dim":"minecraft:overworld","x":-1460,"y":-47,"z":229,"tabla":"mosslorn:chests/world_mix"}],"done":0}
