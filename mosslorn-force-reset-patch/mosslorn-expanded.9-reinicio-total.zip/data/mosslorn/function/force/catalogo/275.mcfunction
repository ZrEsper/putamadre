data modify storage mosslorn:force chunks."minecraft:overworld"."-47_76" set value {"entries":[{"dim":"minecraft:overworld","x":-747,"y":-49,"z":1228,"tabla":"mosslorn:chests/world_mix"}],"done":0}
