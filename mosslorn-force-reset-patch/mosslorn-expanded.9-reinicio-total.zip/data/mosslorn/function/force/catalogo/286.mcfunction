data modify storage mosslorn:force chunks."minecraft:overworld"."-45_-38" set value {"entries":[{"dim":"minecraft:overworld","x":-705,"y":-33,"z":-602,"tabla":"mosslorn:chests/world_mix"}],"done":0}
