data modify storage mosslorn:force chunks."minecraft:overworld"."-41_-44" set value {"entries":[{"dim":"minecraft:overworld","x":-655,"y":-40,"z":-694,"tabla":"mosslorn:chests/world_mix"}],"done":0}
