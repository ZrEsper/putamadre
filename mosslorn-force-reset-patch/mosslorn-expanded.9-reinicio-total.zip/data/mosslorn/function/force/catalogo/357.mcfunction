data modify storage mosslorn:force chunks."minecraft:overworld"."-39_0" set value {"entries":[{"dim":"minecraft:overworld","x":-616,"y":66,"z":7,"tabla":"mosslorn:chests/world_mix"}],"done":0}
