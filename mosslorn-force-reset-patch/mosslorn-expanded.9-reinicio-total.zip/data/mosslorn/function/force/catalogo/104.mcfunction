data modify storage mosslorn:force chunks."minecraft:overworld"."-78_94" set value {"entries":[{"dim":"minecraft:overworld","x":-1241,"y":16,"z":1508,"tabla":"mosslorn:chests/world_mix"}],"done":0}
