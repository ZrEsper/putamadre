data modify storage mosslorn:force chunks."minecraft:overworld"."-44_71" set value {"entries":[{"dim":"minecraft:overworld","x":-703,"y":-39,"z":1138,"tabla":"mosslorn:chests/world_mix"}],"done":0}
