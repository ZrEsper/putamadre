data modify storage mosslorn:force chunks."minecraft:overworld"."-55_39" set value {"entries":[{"dim":"minecraft:overworld","x":-874,"y":59,"z":624,"tabla":"mosslorn:chests/world_mix"}],"done":0}
