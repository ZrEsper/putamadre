data modify storage mosslorn:force chunks."minecraft:overworld"."-58_-11" set value {"entries":[{"dim":"minecraft:overworld","x":-925,"y":54,"z":-175,"tabla":"mosslorn:chests/world_mix"}],"done":0}
