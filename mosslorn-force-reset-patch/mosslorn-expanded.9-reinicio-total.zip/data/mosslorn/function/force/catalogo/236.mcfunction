data modify storage mosslorn:force chunks."minecraft:overworld"."-51_17" set value {"entries":[{"dim":"minecraft:overworld","x":-814,"y":72,"z":284,"tabla":"mosslorn:chests/world_mix"}],"done":0}
