data modify storage mosslorn:force chunks."minecraft:overworld"."-83_-28" set value {"entries":[{"dim":"minecraft:overworld","x":-1315,"y":-6,"z":-441,"tabla":"mosslorn:chests/world_mix"}],"done":0}
