data modify storage mosslorn:force chunks."minecraft:overworld"."-58_-12" set value {"entries":[{"dim":"minecraft:overworld","x":-924,"y":55,"z":-184,"tabla":"mosslorn:chests/world_mix"}],"done":0}
