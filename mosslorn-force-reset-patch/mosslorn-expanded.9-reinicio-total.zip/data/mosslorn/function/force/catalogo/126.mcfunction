data modify storage mosslorn:force chunks."minecraft:overworld"."-75_24" set value {"entries":[{"dim":"minecraft:overworld","x":-1189,"y":-54,"z":385,"tabla":"mosslorn:chests/world_mix"}],"done":0}
