data modify storage mosslorn:force chunks."minecraft:overworld"."-75_-3" set value {"entries":[{"dim":"minecraft:overworld","x":-1193,"y":94,"z":-35,"tabla":"mosslorn:chests/world_mix"}],"done":0}
