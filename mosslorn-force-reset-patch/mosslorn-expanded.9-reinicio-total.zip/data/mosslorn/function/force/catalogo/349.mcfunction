data modify storage mosslorn:force chunks."minecraft:overworld"."-39_-11" set value {"entries":[{"dim":"minecraft:overworld","x":-621,"y":66,"z":-175,"tabla":"mosslorn:chests/world_mix"}],"done":0}
