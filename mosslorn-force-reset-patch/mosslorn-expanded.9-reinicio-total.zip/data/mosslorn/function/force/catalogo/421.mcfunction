data modify storage mosslorn:force chunks."minecraft:overworld"."-38_20" set value {"entries":[{"dim":"minecraft:overworld","x":-594,"y":227,"z":326,"tabla":"mosslorn:chests/world_mix"}],"done":0}
