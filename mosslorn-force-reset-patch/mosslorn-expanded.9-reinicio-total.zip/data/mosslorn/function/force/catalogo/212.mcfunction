data modify storage mosslorn:force chunks."minecraft:overworld"."-55_-37" set value {"entries":[{"dim":"minecraft:overworld","x":-875,"y":-16,"z":-586,"tabla":"mosslorn:chests/world_mix"}],"done":0}
