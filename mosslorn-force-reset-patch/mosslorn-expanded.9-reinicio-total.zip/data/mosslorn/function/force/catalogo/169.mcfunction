data modify storage mosslorn:force chunks."minecraft:overworld"."-62_1" set value {"entries":[{"dim":"minecraft:overworld","x":-986,"y":-41,"z":17,"tabla":"mosslorn:chests/world_mix"}],"done":0}
