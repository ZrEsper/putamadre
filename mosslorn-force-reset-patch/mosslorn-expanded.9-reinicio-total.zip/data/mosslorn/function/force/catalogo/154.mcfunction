data modify storage mosslorn:force chunks."minecraft:overworld"."-66_-43" set value {"entries":[{"dim":"minecraft:overworld","x":-1044,"y":-42,"z":-683,"tabla":"mosslorn:chests/world_mix"}],"done":0}
