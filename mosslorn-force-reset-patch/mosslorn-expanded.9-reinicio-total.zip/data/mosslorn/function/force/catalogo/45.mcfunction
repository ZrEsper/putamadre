data modify storage mosslorn:force chunks."minecraft:overworld"."-89_3" set value {"entries":[{"dim":"minecraft:overworld","x":-1410,"y":-48,"z":61,"tabla":"mosslorn:chests/world_mix"}],"done":0}
