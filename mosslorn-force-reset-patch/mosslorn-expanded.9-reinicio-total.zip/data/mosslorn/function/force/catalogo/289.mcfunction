data modify storage mosslorn:force chunks."minecraft:overworld"."-45_2" set value {"entries":[{"dim":"minecraft:overworld","x":-720,"y":116,"z":40,"tabla":"mosslorn:chests/crate_fish"}],"done":0}
