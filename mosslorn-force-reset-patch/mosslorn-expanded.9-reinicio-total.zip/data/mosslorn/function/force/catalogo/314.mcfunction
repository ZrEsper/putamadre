data modify storage mosslorn:force chunks."minecraft:overworld"."-42_0" set value {"entries":[{"dim":"minecraft:overworld","x":-670,"y":-26,"z":3,"tabla":"mosslorn:chests/world_mix"}],"done":0}
