data modify storage mosslorn:force chunks."minecraft:overworld"."-86_7" set value {"entries":[{"dim":"minecraft:overworld","x":-1366,"y":-48,"z":118,"tabla":"mosslorn:chests/world_mix"}],"done":0}
