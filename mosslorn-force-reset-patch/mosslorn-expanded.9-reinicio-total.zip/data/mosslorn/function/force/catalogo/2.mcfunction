data modify storage mosslorn:force chunks."minecraft:overworld"."-96_9" set value {"entries":[{"dim":"minecraft:overworld","x":-1527,"y":-50,"z":145,"tabla":"mosslorn:chests/world_mix"}],"done":0}
