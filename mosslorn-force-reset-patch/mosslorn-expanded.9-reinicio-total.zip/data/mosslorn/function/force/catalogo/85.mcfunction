data modify storage mosslorn:force chunks."minecraft:overworld"."-81_6" set value {"entries":[{"dim":"minecraft:overworld","x":-1283,"y":109,"z":109,"tabla":"mosslorn:chests/world_mix"}],"done":0}
