data modify storage mosslorn:force chunks."minecraft:overworld"."-77_-44" set value {"entries":[{"dim":"minecraft:overworld","x":-1231,"y":-5,"z":-703,"tabla":"mosslorn:chests/world_mix"}],"done":0}
