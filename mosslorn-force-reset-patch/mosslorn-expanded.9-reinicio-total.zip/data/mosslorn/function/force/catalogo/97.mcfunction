data modify storage mosslorn:force chunks."minecraft:overworld"."-79_45" set value {"entries":[{"dim":"minecraft:overworld","x":-1263,"y":0,"z":728,"tabla":"mosslorn:chests/world_mix"}],"done":0}
