data modify storage mosslorn:force chunks."minecraft:overworld"."-52_-19" set value {"entries":[{"dim":"minecraft:overworld","x":-830,"y":41,"z":-300,"tabla":"mosslorn:chests/world_mix"}],"done":0}
