data modify storage mosslorn:force chunks."minecraft:overworld"."-67_-11" set value {"entries":[{"dim":"minecraft:overworld","x":-1058,"y":22,"z":-174,"tabla":"mosslorn:chests/world_mix"}],"done":0}
