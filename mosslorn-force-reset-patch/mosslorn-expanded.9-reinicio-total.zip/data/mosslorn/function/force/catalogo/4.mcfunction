data modify storage mosslorn:force chunks."minecraft:overworld"."-95_-41" set value {"entries":[{"dim":"minecraft:overworld","x":-1512,"y":50,"z":-646,"tabla":"mosslorn:chests/world_mix"}],"done":0}
