data modify storage mosslorn:force chunks."minecraft:overworld"."-44_-24" set value {"entries":[{"dim":"minecraft:overworld","x":-701,"y":-46,"z":-378,"tabla":"mosslorn:chests/world_mix"}],"done":0}
