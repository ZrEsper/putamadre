data modify storage mosslorn:force chunks."minecraft:overworld"."-94_4" set value {"entries":[{"dim":"minecraft:overworld","x":-1489,"y":-25,"z":76,"tabla":"mosslorn:chests/world_mix"}],"done":0}
