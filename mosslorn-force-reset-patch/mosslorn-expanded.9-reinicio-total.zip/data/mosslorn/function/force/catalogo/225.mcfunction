data modify storage mosslorn:force chunks."minecraft:overworld"."-53_73" set value {"entries":[{"dim":"minecraft:overworld","x":-843,"y":47,"z":1170,"tabla":"mosslorn:chests/world_mix"}],"done":0}
