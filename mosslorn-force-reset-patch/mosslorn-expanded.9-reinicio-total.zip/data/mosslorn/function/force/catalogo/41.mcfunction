data modify storage mosslorn:force chunks."minecraft:overworld"."-90_71" set value {"entries":[{"dim":"minecraft:overworld","x":-1438,"y":72,"z":1145,"tabla":"mosslorn:chests/world_mix"}],"done":0}
