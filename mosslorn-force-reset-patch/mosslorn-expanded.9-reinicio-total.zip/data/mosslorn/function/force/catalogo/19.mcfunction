data modify storage mosslorn:force chunks."minecraft:overworld"."-92_-28" set value {"entries":[{"dim":"minecraft:overworld","x":-1466,"y":57,"z":-438,"tabla":"mosslorn:chests/world_mix"}],"done":0}
