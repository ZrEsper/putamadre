data modify storage mosslorn:force chunks."minecraft:overworld"."-75_-2" set value {"entries":[{"dim":"minecraft:overworld","x":-1193,"y":94,"z":-31,"tabla":"mosslorn:chests/world_mix"}],"done":0}
