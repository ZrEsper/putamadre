data modify storage mosslorn:force chunks."minecraft:overworld"."-68_-45" set value {"entries":[{"dim":"minecraft:overworld","x":-1087,"y":29,"z":-716,"tabla":"mosslorn:chests/world_mix"}],"done":0}
