data modify storage mosslorn:force chunks."minecraft:overworld"."-46_24" set value {"entries":[{"dim":"minecraft:overworld","x":-730,"y":-9,"z":398,"tabla":"mosslorn:chests/world_mix"}],"done":0}
