data modify storage mosslorn:force chunks."minecraft:overworld"."-77_-39" set value {"entries":[{"dim":"minecraft:overworld","x":-1221,"y":38,"z":-609,"tabla":"mosslorn:chests/world_mix"}],"done":0}
