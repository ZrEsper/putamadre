data modify storage mosslorn:force chunks."minecraft:overworld"."-55_38" set value {"entries":[{"dim":"minecraft:overworld","x":-876,"y":59,"z":621,"tabla":"mosslorn:chests/world_mix"}],"done":0}
