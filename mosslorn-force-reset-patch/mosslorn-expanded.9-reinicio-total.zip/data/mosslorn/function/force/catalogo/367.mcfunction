data modify storage mosslorn:force chunks."minecraft:overworld"."-39_29" set value {"entries":[{"dim":"minecraft:overworld","x":-621,"y":66,"z":474,"tabla":"mosslorn:chests/crate_car"}],"done":0}
