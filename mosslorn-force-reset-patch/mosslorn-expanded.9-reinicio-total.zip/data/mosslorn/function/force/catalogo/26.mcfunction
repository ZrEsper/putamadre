data modify storage mosslorn:force chunks."minecraft:overworld"."-91_-26" set value {"entries":[{"dim":"minecraft:overworld","x":-1454,"y":93,"z":-407,"tabla":"mosslorn:chests/world_mix"}],"done":0}
