data modify storage mosslorn:force chunks."minecraft:overworld"."-78_76" set value {"entries":[{"dim":"minecraft:overworld","x":-1242,"y":49,"z":1219,"tabla":"mosslorn:chests/world_mix"}],"done":0}
