data modify storage mosslorn:force chunks."minecraft:overworld"."-48_22" set value {"entries":[{"dim":"minecraft:overworld","x":-756,"y":76,"z":353,"tabla":"mosslorn:chests/world_mix"}],"done":0}
