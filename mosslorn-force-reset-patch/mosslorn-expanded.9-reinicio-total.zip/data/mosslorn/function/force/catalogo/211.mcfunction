data modify storage mosslorn:force chunks."minecraft:overworld"."-56_36" set value {"entries":[{"dim":"minecraft:overworld","x":-894,"y":-53,"z":588,"tabla":"mosslorn:chests/world_mix"}],"done":0}
