data modify storage mosslorn:force chunks."minecraft:overworld"."-94_9" set value {"entries":[{"dim":"minecraft:overworld","x":-1490,"y":-49,"z":144,"tabla":"mosslorn:chests/world_mix"}],"done":0}
