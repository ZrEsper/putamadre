data modify storage mosslorn:force chunks."minecraft:overworld"."-57_-46" set value {"entries":[{"dim":"minecraft:overworld","x":-899,"y":-41,"z":-736,"tabla":"mosslorn:chests/world_mix"}],"done":0}
