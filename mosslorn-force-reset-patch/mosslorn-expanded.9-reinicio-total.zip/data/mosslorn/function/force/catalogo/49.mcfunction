data modify storage mosslorn:force chunks."minecraft:overworld"."-88_-36" set value {"entries":[{"dim":"minecraft:overworld","x":-1393,"y":85,"z":-576,"tabla":"mosslorn:chests/world_mix"}],"done":0}
