data modify storage mosslorn:force chunks."minecraft:overworld"."-65_37" set value {"entries":[{"dim":"minecraft:overworld","x":-1040,"y":-42,"z":598,"tabla":"mosslorn:chests/world_mix"}],"done":0}
