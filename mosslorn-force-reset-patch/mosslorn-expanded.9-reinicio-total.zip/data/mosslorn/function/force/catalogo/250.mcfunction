data modify storage mosslorn:force chunks."minecraft:overworld"."-50_72" set value {"entries":[{"dim":"minecraft:overworld","x":-798,"y":-35,"z":1153,"tabla":"mosslorn:chests/world_mix"}],"done":0}
