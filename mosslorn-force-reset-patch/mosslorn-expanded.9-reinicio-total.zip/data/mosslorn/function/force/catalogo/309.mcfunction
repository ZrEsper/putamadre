data modify storage mosslorn:force chunks."minecraft:overworld"."-43_0" set value {"entries":[{"dim":"minecraft:overworld","x":-676,"y":-26,"z":2,"tabla":"mosslorn:chests/world_mix"}],"done":0}
