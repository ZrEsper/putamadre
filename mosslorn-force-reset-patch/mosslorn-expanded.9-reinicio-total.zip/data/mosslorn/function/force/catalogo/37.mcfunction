data modify storage mosslorn:force chunks."minecraft:overworld"."-90_4" set value {"entries":[{"dim":"minecraft:overworld","x":-1440,"y":-47,"z":76,"tabla":"mosslorn:chests/world_mix"}],"done":0}
