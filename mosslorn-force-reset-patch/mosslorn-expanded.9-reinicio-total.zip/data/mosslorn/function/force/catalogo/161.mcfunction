data modify storage mosslorn:force chunks."minecraft:overworld"."-65_46" set value {"entries":[{"dim":"minecraft:overworld","x":-1029,"y":-36,"z":742,"tabla":"mosslorn:chests/world_mix"}],"done":0}
