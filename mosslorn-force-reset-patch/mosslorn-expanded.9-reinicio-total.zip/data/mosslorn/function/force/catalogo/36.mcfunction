data modify storage mosslorn:force chunks."minecraft:overworld"."-90_-27" set value {"entries":[{"dim":"minecraft:overworld","x":-1428,"y":49,"z":-421,"tabla":"mosslorn:chests/world_mix"}],"done":0}
