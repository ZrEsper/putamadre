data modify storage mosslorn:force chunks."minecraft:overworld"."-65_-17" set value {"entries":[{"dim":"minecraft:overworld","x":-1028,"y":-1,"z":-257,"tabla":"mosslorn:chests/world_mix"}],"done":0}
