data modify storage mosslorn:force chunks."minecraft:overworld"."-83_62" set value {"entries":[{"dim":"minecraft:overworld","x":-1316,"y":40,"z":1005,"tabla":"mosslorn:chests/world_mix"}],"done":0}
