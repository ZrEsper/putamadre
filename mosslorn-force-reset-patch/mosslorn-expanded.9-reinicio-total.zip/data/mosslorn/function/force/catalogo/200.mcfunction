data modify storage mosslorn:force chunks."minecraft:overworld"."-57_88" set value {"entries":[{"dim":"minecraft:overworld","x":-912,"y":-32,"z":1411,"tabla":"mosslorn:chests/world_mix"}],"done":0}
