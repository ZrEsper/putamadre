data modify storage mosslorn:force chunks."minecraft:overworld"."-49_21" set value {"entries":[{"dim":"minecraft:overworld","x":-775,"y":76,"z":346,"tabla":"mosslorn:chests/crate_car"}],"done":0}
