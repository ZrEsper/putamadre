data modify storage mosslorn:force chunks."minecraft:overworld"."-84_7" set value {"entries":[{"dim":"minecraft:overworld","x":-1337,"y":-47,"z":118,"tabla":"mosslorn:chests/world_mix"}],"done":0}
