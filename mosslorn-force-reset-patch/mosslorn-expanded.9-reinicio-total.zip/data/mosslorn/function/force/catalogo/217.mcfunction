data modify storage mosslorn:force chunks."minecraft:overworld"."-54_-38" set value {"entries":[{"dim":"minecraft:overworld","x":-860,"y":54,"z":-600,"tabla":"mosslorn:chests/world_mix"}],"done":0}
