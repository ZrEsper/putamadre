data modify storage mosslorn:force chunks."minecraft:overworld"."-48_39" set value {"entries":[{"dim":"minecraft:overworld","x":-759,"y":63,"z":633,"tabla":"mosslorn:chests/world_mix"}],"done":0}
