data modify storage mosslorn:force chunks."minecraft:overworld"."-50_71" set value {"entries":[{"dim":"minecraft:overworld","x":-797,"y":-35,"z":1149,"tabla":"mosslorn:chests/world_mix"}],"done":0}
