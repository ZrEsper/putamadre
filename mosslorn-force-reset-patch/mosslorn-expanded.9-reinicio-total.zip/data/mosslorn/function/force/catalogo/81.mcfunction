data modify storage mosslorn:force chunks."minecraft:overworld"."-82_4" set value {"entries":[{"dim":"minecraft:overworld","x":-1304,"y":-2,"z":77,"tabla":"mosslorn:chests/world_mix"}],"done":0}
