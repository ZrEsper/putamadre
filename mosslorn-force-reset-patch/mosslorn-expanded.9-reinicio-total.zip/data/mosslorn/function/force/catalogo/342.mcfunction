data modify storage mosslorn:force chunks."minecraft:overworld"."-39_-24" set value {"entries":[{"dim":"minecraft:overworld","x":-616,"y":66,"z":-376,"tabla":"mosslorn:chests/world_mix"}],"done":0}
