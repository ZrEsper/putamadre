data modify storage mosslorn:force chunks."minecraft:overworld"."-49_66" set value {"entries":[{"dim":"minecraft:overworld","x":-775,"y":44,"z":1065,"tabla":"mosslorn:chests/world_mix"}],"done":0}
