data modify storage mosslorn:force chunks."minecraft:overworld"."-57_-37" set value {"entries":[{"dim":"minecraft:overworld","x":-906,"y":48,"z":-587,"tabla":"mosslorn:chests/world_mix"}],"done":0}
