data modify storage mosslorn:force chunks."minecraft:overworld"."-38_22" set value {"entries":[{"dim":"minecraft:overworld","x":-606,"y":66,"z":355,"tabla":"mosslorn:chests/world_mix"}],"done":0}
