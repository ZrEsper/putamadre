data modify storage mosslorn:force chunks."minecraft:overworld"."-39_-64" set value {"entries":[{"dim":"minecraft:overworld","x":-610,"y":-2,"z":-1020,"tabla":"mosslorn:chests/world_mix"}],"done":0}
