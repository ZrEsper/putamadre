data modify storage mosslorn:force chunks."minecraft:overworld"."-75_61" set value {"entries":[{"dim":"minecraft:overworld","x":-1187,"y":-22,"z":991,"tabla":"mosslorn:chests/world_mix"}],"done":0}
