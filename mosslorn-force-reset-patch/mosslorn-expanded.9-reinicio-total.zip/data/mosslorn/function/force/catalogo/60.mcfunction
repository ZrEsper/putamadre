data modify storage mosslorn:force chunks."minecraft:overworld"."-87_7" set value {"entries":[{"dim":"minecraft:overworld","x":-1378,"y":-37,"z":113,"tabla":"mosslorn:chests/world_mix"}],"done":0}
