data modify storage mosslorn:force chunks."minecraft:overworld"."-73_69" set value {"entries":[{"dim":"minecraft:overworld","x":-1155,"y":-7,"z":1115,"tabla":"mosslorn:chests/world_mix"}],"done":0}
