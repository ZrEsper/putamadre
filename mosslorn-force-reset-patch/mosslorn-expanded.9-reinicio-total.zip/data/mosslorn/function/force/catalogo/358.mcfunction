data modify storage mosslorn:force chunks."minecraft:overworld"."-39_1" set value {"entries":[{"dim":"minecraft:overworld","x":-621,"y":66,"z":27,"tabla":"mosslorn:chests/world_mix"}],"done":0}
