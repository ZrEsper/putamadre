data modify storage mosslorn:force chunks."minecraft:overworld"."-92_91" set value {"entries":[{"dim":"minecraft:overworld","x":-1465,"y":-6,"z":1471,"tabla":"mosslorn:chests/world_mix"}],"done":0}
