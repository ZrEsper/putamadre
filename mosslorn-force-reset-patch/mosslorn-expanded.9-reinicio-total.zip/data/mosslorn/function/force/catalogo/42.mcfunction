data modify storage mosslorn:force chunks."minecraft:overworld"."-90_84" set value {"entries":[{"dim":"minecraft:overworld","x":-1433,"y":-10,"z":1345,"tabla":"mosslorn:chests/world_mix"}],"done":0}
