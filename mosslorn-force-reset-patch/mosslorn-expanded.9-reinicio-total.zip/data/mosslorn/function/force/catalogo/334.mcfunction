data modify storage mosslorn:force chunks."minecraft:overworld"."-39_-41" set value {"entries":[{"dim":"minecraft:overworld","x":-617,"y":66,"z":-654,"tabla":"mosslorn:chests/world_mix"}],"done":0}
