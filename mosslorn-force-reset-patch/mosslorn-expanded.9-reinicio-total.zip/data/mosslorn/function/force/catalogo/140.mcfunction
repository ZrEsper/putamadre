data modify storage mosslorn:force chunks."minecraft:overworld"."-71_-59" set value {"entries":[{"dim":"minecraft:overworld","x":-1127,"y":-8,"z":-943,"tabla":"mosslorn:chests/world_mix"}],"done":0}
