data modify storage mosslorn:force chunks."minecraft:overworld"."-57_90" set value {"entries":[{"dim":"minecraft:overworld","x":-901,"y":-39,"z":1441,"tabla":"mosslorn:chests/world_mix"}],"done":0}
