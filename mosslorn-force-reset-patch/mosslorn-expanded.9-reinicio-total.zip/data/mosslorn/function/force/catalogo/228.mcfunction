data modify storage mosslorn:force chunks."minecraft:overworld"."-52_-38" set value {"entries":[{"dim":"minecraft:overworld","x":-826,"y":-54,"z":-606,"tabla":"mosslorn:chests/world_mix"}],"done":0}
