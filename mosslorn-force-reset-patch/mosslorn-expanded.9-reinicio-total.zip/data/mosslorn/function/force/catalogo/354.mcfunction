data modify storage mosslorn:force chunks."minecraft:overworld"."-39_-4" set value {"entries":[{"dim":"minecraft:overworld","x":-623,"y":66,"z":-50,"tabla":"mosslorn:chests/world_mix"}],"done":0}
