data modify storage mosslorn:force chunks."minecraft:overworld"."-78_60" set value {"entries":[{"dim":"minecraft:overworld","x":-1237,"y":-46,"z":965,"tabla":"mosslorn:chests/world_mix"}],"done":0}
