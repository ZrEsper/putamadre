data modify storage mosslorn:force chunks."minecraft:overworld"."-71_-58" set value {"entries":[{"dim":"minecraft:overworld","x":-1132,"y":47,"z":-920,"tabla":"mosslorn:chests/world_mix"}],"done":0}
