data modify storage mosslorn:force chunks."minecraft:overworld"."-49_78" set value {"entries":[{"dim":"minecraft:overworld","x":-771,"y":-23,"z":1256,"tabla":"mosslorn:chests/world_mix"}],"done":0}
