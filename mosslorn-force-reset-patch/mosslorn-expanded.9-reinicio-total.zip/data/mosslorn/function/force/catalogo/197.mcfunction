data modify storage mosslorn:force chunks."minecraft:overworld"."-57_-36" set value {"entries":[{"dim":"minecraft:overworld","x":-901,"y":45,"z":-568,"tabla":"mosslorn:chests/world_mix"}],"done":0}
