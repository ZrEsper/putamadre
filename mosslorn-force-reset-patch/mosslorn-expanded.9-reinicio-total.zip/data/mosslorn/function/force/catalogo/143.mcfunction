data modify storage mosslorn:force chunks."minecraft:overworld"."-71_59" set value {"entries":[{"dim":"minecraft:overworld","x":-1127,"y":-7,"z":954,"tabla":"mosslorn:chests/world_mix"}],"done":0}
