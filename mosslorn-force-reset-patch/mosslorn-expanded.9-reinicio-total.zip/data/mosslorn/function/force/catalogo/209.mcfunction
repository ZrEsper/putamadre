data modify storage mosslorn:force chunks."minecraft:overworld"."-56_27" set value {"entries":[{"dim":"minecraft:overworld","x":-886,"y":-31,"z":432,"tabla":"mosslorn:chests/world_mix"}],"done":0}
