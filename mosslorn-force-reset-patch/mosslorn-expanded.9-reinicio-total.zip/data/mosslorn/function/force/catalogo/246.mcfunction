data modify storage mosslorn:force chunks."minecraft:overworld"."-50_23" set value {"entries":[{"dim":"minecraft:overworld","x":-795,"y":-47,"z":382,"tabla":"mosslorn:chests/world_mix"}],"done":0}
