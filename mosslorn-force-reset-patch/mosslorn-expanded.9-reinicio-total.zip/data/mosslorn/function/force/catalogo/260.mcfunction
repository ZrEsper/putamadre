data modify storage mosslorn:force chunks."minecraft:overworld"."-48_-38" set value {"entries":[{"dim":"minecraft:overworld","x":-767,"y":-32,"z":-597,"tabla":"mosslorn:chests/world_mix"}],"done":0}
