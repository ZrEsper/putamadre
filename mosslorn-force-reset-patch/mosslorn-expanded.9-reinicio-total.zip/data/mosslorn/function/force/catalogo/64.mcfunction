data modify storage mosslorn:force chunks."minecraft:overworld"."-86_9" set value {"entries":[{"dim":"minecraft:overworld","x":-1362,"y":-50,"z":146,"tabla":"mosslorn:chests/world_mix"}],"done":0}
