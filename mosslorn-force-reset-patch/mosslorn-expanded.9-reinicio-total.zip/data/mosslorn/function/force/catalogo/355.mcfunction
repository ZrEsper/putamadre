data modify storage mosslorn:force chunks."minecraft:overworld"."-39_-2" set value {"entries":[{"dim":"minecraft:overworld","x":-620,"y":90,"z":-23,"tabla":"mosslorn:chests/world_mix"}],"done":0}
