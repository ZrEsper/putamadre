data modify storage mosslorn:force chunks."minecraft:overworld"."-45_71" set value {"entries":[{"dim":"minecraft:overworld","x":-705,"y":-39,"z":1136,"tabla":"mosslorn:chests/world_mix"}],"done":0}
