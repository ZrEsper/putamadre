data modify storage mosslorn:force chunks."minecraft:overworld"."-90_62" set value {"entries":[{"dim":"minecraft:overworld","x":-1432,"y":-47,"z":1006,"tabla":"mosslorn:chests/world_mix"}],"done":0}
