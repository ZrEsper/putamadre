data modify storage mosslorn:force chunks."minecraft:overworld"."-95_7" set value {"entries":[{"dim":"minecraft:overworld","x":-1505,"y":-49,"z":120,"tabla":"mosslorn:chests/world_mix"}],"done":0}
