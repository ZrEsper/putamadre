data modify storage mosslorn:force chunks."minecraft:overworld"."-69_-45" set value {"entries":[{"dim":"minecraft:overworld","x":-1091,"y":29,"z":-717,"tabla":"mosslorn:chests/world_mix"}],"done":0}
