data modify storage mosslorn:force chunks."minecraft:overworld"."-56_-46" set value {"entries":[{"dim":"minecraft:overworld","x":-896,"y":-41,"z":-732,"tabla":"mosslorn:chests/world_mix"}],"done":0}
