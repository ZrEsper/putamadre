data modify storage mosslorn:force chunks."minecraft:overworld"."-39_2" set value {"entries":[{"dim":"minecraft:overworld","x":-622,"y":66,"z":38,"tabla":"mosslorn:chests/crate_office"}],"done":0}
