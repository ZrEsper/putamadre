data modify storage mosslorn:force chunks."minecraft:overworld"."-61_61" set value {"entries":[{"dim":"minecraft:overworld","x":-962,"y":-52,"z":988,"tabla":"mosslorn:chests/world_mix"}],"done":0}
