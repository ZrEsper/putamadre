data modify storage mosslorn:force chunks."minecraft:overworld"."-87_-36" set value {"entries":[{"dim":"minecraft:overworld","x":-1389,"y":85,"z":-573,"tabla":"mosslorn:chests/world_mix"}],"done":0}
