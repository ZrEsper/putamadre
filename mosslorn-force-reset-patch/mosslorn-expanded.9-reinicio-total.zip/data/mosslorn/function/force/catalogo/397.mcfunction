data modify storage mosslorn:force chunks."minecraft:overworld"."-38_-24" set value {"entries":[{"dim":"minecraft:overworld","x":-602,"y":66,"z":-370,"tabla":"mosslorn:chests/world_mix"}],"done":0}
