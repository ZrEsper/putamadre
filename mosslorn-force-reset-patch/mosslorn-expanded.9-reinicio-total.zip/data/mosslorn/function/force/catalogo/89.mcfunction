data modify storage mosslorn:force chunks."minecraft:overworld"."-80_-51" set value {"entries":[{"dim":"minecraft:overworld","x":-1265,"y":-54,"z":-810,"tabla":"mosslorn:chests/world_mix"}],"done":0}
