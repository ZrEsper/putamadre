data modify storage mosslorn:force chunks."minecraft:overworld"."-93_11" set value {"entries":[{"dim":"minecraft:overworld","x":-1487,"y":-48,"z":189,"tabla":"mosslorn:chests/world_mix"}],"done":0}
