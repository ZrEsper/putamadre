data modify storage mosslorn:force chunks."minecraft:overworld"."-49_17" set value {"entries":[{"dim":"minecraft:overworld","x":-770,"y":55,"z":287,"tabla":"mosslorn:chests/world_mix"}],"done":0}
