data modify storage mosslorn:force chunks."minecraft:overworld"."-66_71" set value {"entries":[{"dim":"minecraft:overworld","x":-1041,"y":29,"z":1139,"tabla":"mosslorn:chests/world_mix"}],"done":0}
