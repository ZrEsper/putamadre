data modify storage mosslorn:force chunks."minecraft:overworld"."-58_-16" set value {"entries":[{"dim":"minecraft:overworld","x":-928,"y":-19,"z":-255,"tabla":"mosslorn:chests/world_mix"}],"done":0}
