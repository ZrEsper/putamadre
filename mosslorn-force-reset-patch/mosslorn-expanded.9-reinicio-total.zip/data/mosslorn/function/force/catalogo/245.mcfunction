data modify storage mosslorn:force chunks."minecraft:overworld"."-50_21" set value {"entries":[{"dim":"minecraft:overworld","x":-794,"y":76,"z":343,"tabla":"mosslorn:chests/world_mix"}],"done":0}
