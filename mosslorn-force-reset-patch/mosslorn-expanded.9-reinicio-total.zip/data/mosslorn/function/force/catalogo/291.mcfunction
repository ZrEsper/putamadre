data modify storage mosslorn:force chunks."minecraft:overworld"."-45_22" set value {"entries":[{"dim":"minecraft:overworld","x":-716,"y":187,"z":364,"tabla":"mosslorn:chests/world_mix"}],"done":0}
