data modify storage mosslorn:force chunks."minecraft:overworld"."-40_23" set value {"entries":[{"dim":"minecraft:overworld","x":-638,"y":-22,"z":380,"tabla":"mosslorn:chests/world_mix"}],"done":0}
