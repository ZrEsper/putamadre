data modify storage mosslorn:force chunks."minecraft:overworld"."-47_60" set value {"entries":[{"dim":"minecraft:overworld","x":-737,"y":93,"z":962,"tabla":"mosslorn:chests/crate_office"}],"done":0}
