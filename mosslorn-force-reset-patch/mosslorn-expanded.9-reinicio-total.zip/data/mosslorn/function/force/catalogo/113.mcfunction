data modify storage mosslorn:force chunks."minecraft:overworld"."-77_60" set value {"entries":[{"dim":"minecraft:overworld","x":-1220,"y":-25,"z":975,"tabla":"mosslorn:chests/world_mix"}],"done":0}
