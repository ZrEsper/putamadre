data modify storage mosslorn:force chunks."minecraft:overworld"."-48_-36" set value {"entries":[{"dim":"minecraft:overworld","x":-765,"y":11,"z":-563,"tabla":"mosslorn:chests/world_mix"}],"done":0}
