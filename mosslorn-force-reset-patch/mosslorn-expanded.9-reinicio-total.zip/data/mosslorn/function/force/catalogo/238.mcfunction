data modify storage mosslorn:force chunks."minecraft:overworld"."-51_36" set value {"entries":[{"dim":"minecraft:overworld","x":-814,"y":-41,"z":580,"tabla":"mosslorn:chests/world_mix"}],"done":0}
