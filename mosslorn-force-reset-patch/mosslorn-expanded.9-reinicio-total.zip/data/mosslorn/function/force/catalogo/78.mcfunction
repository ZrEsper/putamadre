data modify storage mosslorn:force chunks."minecraft:overworld"."-82_-28" set value {"entries":[{"dim":"minecraft:overworld","x":-1310,"y":-6,"z":-438,"tabla":"mosslorn:chests/world_mix"}],"done":0}
