data modify storage mosslorn:force chunks."minecraft:overworld"."-41_22" set value {"entries":[{"dim":"minecraft:overworld","x":-641,"y":76,"z":353,"tabla":"mosslorn:chests/crate_car"}],"done":0}
