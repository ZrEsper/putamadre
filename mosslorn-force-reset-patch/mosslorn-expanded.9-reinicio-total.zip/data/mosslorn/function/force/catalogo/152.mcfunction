data modify storage mosslorn:force chunks."minecraft:overworld"."-67_32" set value {"entries":[{"dim":"minecraft:overworld","x":-1072,"y":38,"z":513,"tabla":"mosslorn:chests/world_mix"}],"done":0}
