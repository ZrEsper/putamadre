data modify storage mosslorn:force chunks."minecraft:overworld"."-79_-51" set value {"entries":[{"dim":"minecraft:overworld","x":-1264,"y":-54,"z":-804,"tabla":"mosslorn:chests/world_mix"}],"done":0}
