data modify storage mosslorn:force chunks."minecraft:overworld"."-62_-59" set value {"entries":[{"dim":"minecraft:overworld","x":-985,"y":6,"z":-939,"tabla":"mosslorn:chests/world_mix"}],"done":0}
