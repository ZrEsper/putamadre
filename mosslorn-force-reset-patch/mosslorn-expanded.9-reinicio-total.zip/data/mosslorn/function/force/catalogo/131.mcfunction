data modify storage mosslorn:force chunks."minecraft:overworld"."-74_-16" set value {"entries":[{"dim":"minecraft:overworld","x":-1176,"y":55,"z":-243,"tabla":"mosslorn:chests/world_mix"}],"done":0}
