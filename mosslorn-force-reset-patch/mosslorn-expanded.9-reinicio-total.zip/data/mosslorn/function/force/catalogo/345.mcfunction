data modify storage mosslorn:force chunks."minecraft:overworld"."-39_-17" set value {"entries":[{"dim":"minecraft:overworld","x":-621,"y":11,"z":-271,"tabla":"mosslorn:chests/world_mix"}],"done":0}
