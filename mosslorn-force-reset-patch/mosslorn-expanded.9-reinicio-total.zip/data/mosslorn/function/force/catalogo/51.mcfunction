data modify storage mosslorn:force chunks."minecraft:overworld"."-88_-23" set value {"entries":[{"dim":"minecraft:overworld","x":-1393,"y":-51,"z":-360,"tabla":"mosslorn:chests/world_mix"}],"done":0}
