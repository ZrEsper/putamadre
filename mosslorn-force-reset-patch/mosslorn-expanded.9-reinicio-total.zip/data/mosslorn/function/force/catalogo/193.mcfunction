data modify storage mosslorn:force chunks."minecraft:overworld"."-58_25" set value {"entries":[{"dim":"minecraft:overworld","x":-919,"y":31,"z":415,"tabla":"mosslorn:chests/world_mix"}],"done":0}
