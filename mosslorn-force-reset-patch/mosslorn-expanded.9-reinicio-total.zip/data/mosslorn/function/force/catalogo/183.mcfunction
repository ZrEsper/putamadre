data modify storage mosslorn:force chunks."minecraft:overworld"."-59_-23" set value {"entries":[{"dim":"minecraft:overworld","x":-939,"y":-51,"z":-360,"tabla":"mosslorn:chests/world_mix"}],"done":0}
