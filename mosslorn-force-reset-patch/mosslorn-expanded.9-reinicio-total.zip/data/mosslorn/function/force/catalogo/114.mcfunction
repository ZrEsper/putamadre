data modify storage mosslorn:force chunks."minecraft:overworld"."-76_-57" set value {"entries":[{"dim":"minecraft:overworld","x":-1216,"y":-10,"z":-909,"tabla":"mosslorn:chests/world_mix"}],"done":0}
