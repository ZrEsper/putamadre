data modify storage mosslorn:force chunks."minecraft:overworld"."-66_80" set value {"entries":[{"dim":"minecraft:overworld","x":-1041,"y":-15,"z":1290,"tabla":"mosslorn:chests/world_mix"}],"done":0}
