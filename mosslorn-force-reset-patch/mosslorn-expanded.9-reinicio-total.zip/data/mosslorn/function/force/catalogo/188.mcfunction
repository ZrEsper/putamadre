data modify storage mosslorn:force chunks."minecraft:overworld"."-58_-37" set value {"entries":[{"dim":"minecraft:overworld","x":-926,"y":51,"z":-578,"tabla":"mosslorn:chests/world_mix"}],"done":0}
