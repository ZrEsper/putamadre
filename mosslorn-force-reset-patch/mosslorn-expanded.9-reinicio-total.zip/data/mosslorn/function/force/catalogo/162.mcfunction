data modify storage mosslorn:force chunks."minecraft:overworld"."-65_54" set value {"entries":[{"dim":"minecraft:overworld","x":-1038,"y":67,"z":864,"tabla":"mosslorn:chests/world_mix"}],"done":0}
