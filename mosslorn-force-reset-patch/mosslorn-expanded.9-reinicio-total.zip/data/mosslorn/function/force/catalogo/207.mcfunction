data modify storage mosslorn:force chunks."minecraft:overworld"."-56_19" set value {"entries":[{"dim":"minecraft:overworld","x":-886,"y":-46,"z":316,"tabla":"mosslorn:chests/world_mix"}],"done":0}
