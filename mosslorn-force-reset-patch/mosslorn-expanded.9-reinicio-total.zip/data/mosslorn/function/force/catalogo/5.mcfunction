data modify storage mosslorn:force chunks."minecraft:overworld"."-95_-2" set value {"entries":[{"dim":"minecraft:overworld","x":-1513,"y":-40,"z":-29,"tabla":"mosslorn:chests/world_mix"}],"done":0}
