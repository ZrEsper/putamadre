data modify storage mosslorn:force chunks."minecraft:overworld"."-61_62" set value {"entries":[{"dim":"minecraft:overworld","x":-961,"y":-52,"z":992,"tabla":"mosslorn:chests/world_mix"}],"done":0}
