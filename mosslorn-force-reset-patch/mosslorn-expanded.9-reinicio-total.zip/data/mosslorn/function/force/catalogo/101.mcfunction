data modify storage mosslorn:force chunks."minecraft:overworld"."-78_62" set value {"entries":[{"dim":"minecraft:overworld","x":-1237,"y":-46,"z":1000,"tabla":"mosslorn:chests/world_mix"}],"done":0}
