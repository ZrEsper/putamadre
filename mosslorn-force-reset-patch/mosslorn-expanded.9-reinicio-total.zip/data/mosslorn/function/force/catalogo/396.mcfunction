data modify storage mosslorn:force chunks."minecraft:overworld"."-38_-26" set value {"entries":[{"dim":"minecraft:overworld","x":-600,"y":66,"z":-402,"tabla":"mosslorn:chests/world_mix"}],"done":0}
