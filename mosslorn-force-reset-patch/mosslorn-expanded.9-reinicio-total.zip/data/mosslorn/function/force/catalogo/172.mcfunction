data modify storage mosslorn:force chunks."minecraft:overworld"."-62_34" set value {"entries":[{"dim":"minecraft:overworld","x":-987,"y":-6,"z":554,"tabla":"mosslorn:chests/world_mix"}],"done":0}
