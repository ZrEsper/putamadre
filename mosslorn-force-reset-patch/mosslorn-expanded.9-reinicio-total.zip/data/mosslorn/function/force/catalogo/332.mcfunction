data modify storage mosslorn:force chunks."minecraft:overworld"."-39_-44" set value {"entries":[{"dim":"minecraft:overworld","x":-616,"y":66,"z":-697,"tabla":"mosslorn:chests/world_mix"}],"done":0}
