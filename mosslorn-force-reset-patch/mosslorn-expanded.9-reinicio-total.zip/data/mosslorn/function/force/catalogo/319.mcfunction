data modify storage mosslorn:force chunks."minecraft:overworld"."-41_21" set value {"entries":[{"dim":"minecraft:overworld","x":-649,"y":76,"z":345,"tabla":"mosslorn:chests/crate_car"}],"done":0}
