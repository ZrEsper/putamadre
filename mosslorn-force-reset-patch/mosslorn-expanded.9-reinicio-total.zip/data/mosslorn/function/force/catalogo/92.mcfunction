data modify storage mosslorn:force chunks."minecraft:overworld"."-80_37" set value {"entries":[{"dim":"minecraft:overworld","x":-1275,"y":-11,"z":606,"tabla":"mosslorn:chests/world_mix"}],"done":0}
