data modify storage mosslorn:force chunks."minecraft:overworld"."-38_-27" set value {"entries":[{"dim":"minecraft:overworld","x":-601,"y":66,"z":-426,"tabla":"mosslorn:chests/world_mix"}],"done":0}
