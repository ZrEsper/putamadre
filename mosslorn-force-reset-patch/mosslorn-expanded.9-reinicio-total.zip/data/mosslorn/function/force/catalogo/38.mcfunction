data modify storage mosslorn:force chunks."minecraft:overworld"."-90_56" set value {"entries":[{"dim":"minecraft:overworld","x":-1426,"y":35,"z":905,"tabla":"mosslorn:chests/world_mix"}],"done":0}
