data modify storage mosslorn:force chunks."minecraft:overworld"."-58_26" set value {"entries":[{"dim":"minecraft:overworld","x":-922,"y":31,"z":417,"tabla":"mosslorn:chests/world_mix"}],"done":0}
