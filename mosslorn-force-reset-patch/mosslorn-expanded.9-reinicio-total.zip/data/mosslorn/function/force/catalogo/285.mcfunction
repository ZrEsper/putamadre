data modify storage mosslorn:force chunks."minecraft:overworld"."-46_84" set value {"entries":[{"dim":"minecraft:overworld","x":-724,"y":-9,"z":1356,"tabla":"mosslorn:chests/world_mix"}],"done":0}
