data modify storage mosslorn:force chunks."minecraft:overworld"."-44_21" set value {"entries":[{"dim":"minecraft:overworld","x":-697,"y":76,"z":344,"tabla":"mosslorn:chests/crate_car"}],"done":0}
