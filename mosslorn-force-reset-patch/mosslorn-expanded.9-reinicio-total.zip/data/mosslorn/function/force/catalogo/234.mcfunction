data modify storage mosslorn:force chunks."minecraft:overworld"."-51_-18" set value {"entries":[{"dim":"minecraft:overworld","x":-816,"y":39,"z":-280,"tabla":"mosslorn:chests/world_mix"}],"done":0}
