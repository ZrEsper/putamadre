data modify storage mosslorn:force chunks."minecraft:overworld"."-50_33" set value {"entries":[{"dim":"minecraft:overworld","x":-792,"y":-41,"z":531,"tabla":"mosslorn:chests/world_mix"}],"done":0}
