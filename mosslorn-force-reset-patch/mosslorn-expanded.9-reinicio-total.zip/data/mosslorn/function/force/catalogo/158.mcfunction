data modify storage mosslorn:force chunks."minecraft:overworld"."-65_-16" set value {"entries":[{"dim":"minecraft:overworld","x":-1030,"y":-1,"z":-253,"tabla":"mosslorn:chests/world_mix"}],"done":0}
