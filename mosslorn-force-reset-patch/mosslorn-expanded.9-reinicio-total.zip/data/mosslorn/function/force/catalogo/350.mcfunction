data modify storage mosslorn:force chunks."minecraft:overworld"."-39_-10" set value {"entries":[{"dim":"minecraft:overworld","x":-617,"y":66,"z":-156,"tabla":"mosslorn:chests/world_mix"}],"done":0}
