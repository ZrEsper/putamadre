data modify storage mosslorn:force chunks."minecraft:overworld"."-39_-45" set value {"entries":[{"dim":"minecraft:overworld","x":-616,"y":66,"z":-711,"tabla":"mosslorn:chests/world_mix"}],"done":0}
