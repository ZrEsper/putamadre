data modify storage mosslorn:force chunks."minecraft:overworld"."-58_-36" set value {"entries":[{"dim":"minecraft:overworld","x":-924,"y":50,"z":-561,"tabla":"mosslorn:chests/world_mix"}],"done":0}
