data modify storage mosslorn:force chunks."minecraft:overworld"."-65_80" set value {"entries":[{"dim":"minecraft:overworld","x":-1037,"y":-15,"z":1292,"tabla":"mosslorn:chests/world_mix"}],"done":0}
