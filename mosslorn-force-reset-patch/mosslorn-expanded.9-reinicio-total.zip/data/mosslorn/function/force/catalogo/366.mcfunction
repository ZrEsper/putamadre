data modify storage mosslorn:force chunks."minecraft:overworld"."-39_27" set value {"entries":[{"dim":"minecraft:overworld","x":-622,"y":66,"z":443,"tabla":"mosslorn:chests/crate_car"}],"done":0}
