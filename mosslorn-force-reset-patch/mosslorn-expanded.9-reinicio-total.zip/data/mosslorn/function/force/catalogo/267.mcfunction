data modify storage mosslorn:force chunks."minecraft:overworld"."-47_-34" set value {"entries":[{"dim":"minecraft:overworld","x":-751,"y":-48,"z":-538,"tabla":"mosslorn:chests/world_mix"}],"done":0}
