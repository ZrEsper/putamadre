data modify storage mosslorn:force chunks."minecraft:overworld"."-89_12" set value {"entries":[{"dim":"minecraft:overworld","x":-1416,"y":-12,"z":199,"tabla":"mosslorn:chests/world_mix"}],"done":0}
