data modify storage mosslorn:force chunks."minecraft:overworld"."-71_15" set value {"entries":[{"dim":"minecraft:overworld","x":-1130,"y":115,"z":251,"tabla":"mosslorn:chests/world_mix"}],"done":0}
