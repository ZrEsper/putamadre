data modify storage mosslorn:force chunks."minecraft:overworld"."-39_55" set value {"entries":[{"dim":"minecraft:overworld","x":-622,"y":66,"z":880,"tabla":"mosslorn:chests/world_mix"}],"done":0}
