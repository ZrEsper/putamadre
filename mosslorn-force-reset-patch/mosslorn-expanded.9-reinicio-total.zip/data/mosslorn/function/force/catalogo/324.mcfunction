data modify storage mosslorn:force chunks."minecraft:overworld"."-40_-7" set value {"entries":[{"dim":"minecraft:overworld","x":-628,"y":75,"z":-102,"tabla":"mosslorn:chests/world_mix"}],"done":0}
