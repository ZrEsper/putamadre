data modify storage mosslorn:force chunks."minecraft:overworld"."-38_-43" set value {"entries":[{"dim":"minecraft:overworld","x":-598,"y":80,"z":-676,"tabla":"mosslorn:chests/world_mix"}],"done":0}
