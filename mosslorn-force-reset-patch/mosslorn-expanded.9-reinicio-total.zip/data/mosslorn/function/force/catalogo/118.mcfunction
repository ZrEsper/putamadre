data modify storage mosslorn:force chunks."minecraft:overworld"."-76_56" set value {"entries":[{"dim":"minecraft:overworld","x":-1215,"y":-42,"z":905,"tabla":"mosslorn:chests/world_mix"}],"done":0}
