data modify storage mosslorn:force chunks."minecraft:overworld"."-45_-8" set value {"entries":[{"dim":"minecraft:overworld","x":-714,"y":-39,"z":-124,"tabla":"mosslorn:chests/world_mix"}],"done":0}
