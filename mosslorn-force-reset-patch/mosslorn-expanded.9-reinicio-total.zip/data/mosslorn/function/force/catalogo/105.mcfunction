data modify storage mosslorn:force chunks."minecraft:overworld"."-77_-58" set value {"entries":[{"dim":"minecraft:overworld","x":-1218,"y":-10,"z":-914,"tabla":"mosslorn:chests/world_mix"}],"done":0}
