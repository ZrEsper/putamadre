data modify storage mosslorn:force chunks."minecraft:overworld"."-81_-13" set value {"entries":[{"dim":"minecraft:overworld","x":-1296,"y":-29,"z":-197,"tabla":"mosslorn:chests/world_mix"}],"done":0}
