data modify storage mosslorn:force chunks."minecraft:overworld"."-51_23" set value {"entries":[{"dim":"minecraft:overworld","x":-801,"y":-47,"z":381,"tabla":"mosslorn:chests/world_mix"}],"done":0}
