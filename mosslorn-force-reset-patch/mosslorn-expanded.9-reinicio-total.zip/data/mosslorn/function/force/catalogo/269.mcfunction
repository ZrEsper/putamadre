data modify storage mosslorn:force chunks."minecraft:overworld"."-47_-15" set value {"entries":[{"dim":"minecraft:overworld","x":-744,"y":-28,"z":-238,"tabla":"mosslorn:chests/world_mix"}],"done":0}
