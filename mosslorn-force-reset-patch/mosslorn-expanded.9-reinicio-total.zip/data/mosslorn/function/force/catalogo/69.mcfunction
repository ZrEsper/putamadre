data modify storage mosslorn:force chunks."minecraft:overworld"."-84_-40" set value {"entries":[{"dim":"minecraft:overworld","x":-1344,"y":-45,"z":-636,"tabla":"mosslorn:chests/world_mix"}],"done":0}
