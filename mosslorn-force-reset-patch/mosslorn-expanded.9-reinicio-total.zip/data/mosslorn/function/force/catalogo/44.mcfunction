data modify storage mosslorn:force chunks."minecraft:overworld"."-89_2" set value {"entries":[{"dim":"minecraft:overworld","x":-1412,"y":-50,"z":47,"tabla":"mosslorn:chests/world_mix"}],"done":0}
