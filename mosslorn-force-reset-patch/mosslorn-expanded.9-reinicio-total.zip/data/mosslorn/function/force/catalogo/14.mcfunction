data modify storage mosslorn:force chunks."minecraft:overworld"."-93_4" set value {"entries":[{"dim":"minecraft:overworld","x":-1485,"y":-25,"z":79,"tabla":"mosslorn:chests/world_mix"}],"done":0}
