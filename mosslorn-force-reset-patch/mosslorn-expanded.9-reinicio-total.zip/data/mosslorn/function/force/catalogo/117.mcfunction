data modify storage mosslorn:force chunks."minecraft:overworld"."-76_38" set value {"entries":[{"dim":"minecraft:overworld","x":-1214,"y":-25,"z":621,"tabla":"mosslorn:chests/world_mix"}],"done":0}
