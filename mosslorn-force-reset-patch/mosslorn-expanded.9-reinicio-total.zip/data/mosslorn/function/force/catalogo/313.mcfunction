data modify storage mosslorn:force chunks."minecraft:overworld"."-43_77" set value {"entries":[{"dim":"minecraft:overworld","x":-678,"y":-9,"z":1246,"tabla":"mosslorn:chests/world_mix"}],"done":0}
