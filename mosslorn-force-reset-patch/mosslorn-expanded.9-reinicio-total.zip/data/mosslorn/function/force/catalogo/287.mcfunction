data modify storage mosslorn:force chunks."minecraft:overworld"."-45_-25" set value {"entries":[{"dim":"minecraft:overworld","x":-715,"y":-3,"z":-387,"tabla":"mosslorn:chests/world_mix"}],"done":0}
