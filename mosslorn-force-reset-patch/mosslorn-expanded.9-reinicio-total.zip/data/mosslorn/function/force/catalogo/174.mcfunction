data modify storage mosslorn:force chunks."minecraft:overworld"."-61_-17" set value {"entries":[{"dim":"minecraft:overworld","x":-966,"y":-15,"z":-261,"tabla":"mosslorn:chests/world_mix"}],"done":0}
