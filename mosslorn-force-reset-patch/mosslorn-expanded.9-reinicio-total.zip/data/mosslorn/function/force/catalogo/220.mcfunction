data modify storage mosslorn:force chunks."minecraft:overworld"."-53_-20" set value {"entries":[{"dim":"minecraft:overworld","x":-841,"y":47,"z":-317,"tabla":"mosslorn:chests/world_mix"}],"done":0}
