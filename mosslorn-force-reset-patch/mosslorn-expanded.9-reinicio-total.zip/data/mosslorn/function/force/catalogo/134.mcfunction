data modify storage mosslorn:force chunks."minecraft:overworld"."-73_-38" set value {"entries":[{"dim":"minecraft:overworld","x":-1164,"y":-36,"z":-600,"tabla":"mosslorn:chests/world_mix"}],"done":0}
