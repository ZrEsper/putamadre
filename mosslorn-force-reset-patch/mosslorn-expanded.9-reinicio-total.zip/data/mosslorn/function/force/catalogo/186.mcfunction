data modify storage mosslorn:force chunks."minecraft:overworld"."-59_53" set value {"entries":[{"dim":"minecraft:overworld","x":-933,"y":54,"z":849,"tabla":"mosslorn:chests/world_mix"}],"done":0}
