data modify storage mosslorn:force chunks."minecraft:overworld"."-52_-20" set value {"entries":[{"dim":"minecraft:overworld","x":-825,"y":40,"z":-311,"tabla":"mosslorn:chests/world_mix"}],"done":0}
