data modify storage mosslorn:force chunks."minecraft:overworld"."-80_38" set value {"entries":[{"dim":"minecraft:overworld","x":-1279,"y":-11,"z":610,"tabla":"mosslorn:chests/world_mix"}],"done":0}
