data modify storage mosslorn:force chunks."minecraft:overworld"."-52_-39" set value {"entries":[{"dim":"minecraft:overworld","x":-822,"y":-54,"z":-609,"tabla":"mosslorn:chests/world_mix"}],"done":0}
