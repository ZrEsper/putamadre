data modify storage mosslorn:force chunks."minecraft:overworld"."-84_6" set value {"entries":[{"dim":"minecraft:overworld","x":-1337,"y":-47,"z":110,"tabla":"mosslorn:chests/world_mix"}],"done":0}
