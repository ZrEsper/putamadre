data modify storage mosslorn:force chunks."minecraft:overworld"."-60_-21" set value {"entries":[{"dim":"minecraft:overworld","x":-956,"y":49,"z":-335,"tabla":"mosslorn:chests/world_mix"}],"done":0}
