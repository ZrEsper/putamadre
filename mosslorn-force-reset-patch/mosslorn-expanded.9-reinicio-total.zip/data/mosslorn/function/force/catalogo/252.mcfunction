data modify storage mosslorn:force chunks."minecraft:overworld"."-49_-66" set value {"entries":[{"dim":"minecraft:overworld","x":-782,"y":26,"z":-1048,"tabla":"mosslorn:chests/world_mix"}],"done":0}
