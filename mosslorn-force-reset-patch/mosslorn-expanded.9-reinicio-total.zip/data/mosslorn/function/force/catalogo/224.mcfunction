data modify storage mosslorn:force chunks."minecraft:overworld"."-53_46" set value {"entries":[{"dim":"minecraft:overworld","x":-846,"y":-20,"z":747,"tabla":"mosslorn:chests/world_mix"}],"done":0}
