data modify storage mosslorn:force chunks."minecraft:overworld"."-93_13" set value {"entries":[{"dim":"minecraft:overworld","x":-1477,"y":-47,"z":221,"tabla":"mosslorn:chests/world_mix"}],"done":0}
