data modify storage mosslorn:force chunks."minecraft:overworld"."-45_75" set value {"entries":[{"dim":"minecraft:overworld","x":-715,"y":-34,"z":1214,"tabla":"mosslorn:chests/world_mix"}],"done":0}
