data modify storage mosslorn:force chunks."minecraft:overworld"."-59_35" set value {"entries":[{"dim":"minecraft:overworld","x":-936,"y":-18,"z":561,"tabla":"mosslorn:chests/world_mix"}],"done":0}
