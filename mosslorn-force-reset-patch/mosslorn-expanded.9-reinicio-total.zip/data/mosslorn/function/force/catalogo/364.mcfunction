data modify storage mosslorn:force chunks."minecraft:overworld"."-39_23" set value {"entries":[{"dim":"minecraft:overworld","x":-622,"y":66,"z":377,"tabla":"mosslorn:chests/crate_car"}],"done":0}
