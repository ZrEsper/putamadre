data modify storage mosslorn:force chunks."minecraft:overworld"."-76_89" set value {"entries":[{"dim":"minecraft:overworld","x":-1214,"y":-9,"z":1437,"tabla":"mosslorn:chests/world_mix"}],"done":0}
