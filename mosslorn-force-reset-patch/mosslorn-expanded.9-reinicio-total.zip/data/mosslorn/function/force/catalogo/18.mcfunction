data modify storage mosslorn:force chunks."minecraft:overworld"."-93_14" set value {"entries":[{"dim":"minecraft:overworld","x":-1477,"y":-47,"z":229,"tabla":"mosslorn:chests/world_mix"}],"done":0}
