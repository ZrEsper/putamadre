data modify storage mosslorn:force chunks."minecraft:overworld"."-47_-16" set value {"entries":[{"dim":"minecraft:overworld","x":-746,"y":-28,"z":-241,"tabla":"mosslorn:chests/world_mix"}],"done":0}
