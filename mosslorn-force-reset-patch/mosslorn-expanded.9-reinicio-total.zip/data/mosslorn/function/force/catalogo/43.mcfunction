data modify storage mosslorn:force chunks."minecraft:overworld"."-89_1" set value {"entries":[{"dim":"minecraft:overworld","x":-1413,"y":-49,"z":30,"tabla":"mosslorn:chests/world_mix"}],"done":0}
