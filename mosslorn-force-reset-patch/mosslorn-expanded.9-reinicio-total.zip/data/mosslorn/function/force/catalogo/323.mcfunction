data modify storage mosslorn:force chunks."minecraft:overworld"."-40_-11" set value {"entries":[{"dim":"minecraft:overworld","x":-632,"y":-30,"z":-175,"tabla":"mosslorn:chests/world_mix"}],"done":0}
