data modify storage mosslorn:force chunks."minecraft:overworld"."-43_-32" set value {"entries":[{"dim":"minecraft:overworld","x":-682,"y":-37,"z":-510,"tabla":"mosslorn:chests/world_mix"}],"done":0}
