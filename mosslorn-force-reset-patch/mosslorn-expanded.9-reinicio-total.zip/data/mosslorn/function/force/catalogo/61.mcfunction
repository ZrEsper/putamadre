data modify storage mosslorn:force chunks."minecraft:overworld"."-87_17" set value {"entries":[{"dim":"minecraft:overworld","x":-1391,"y":-10,"z":281,"tabla":"mosslorn:chests/world_mix"}],"done":0}
