data modify storage mosslorn:force chunks."minecraft:overworld"."-87_-23" set value {"entries":[{"dim":"minecraft:overworld","x":-1392,"y":-51,"z":-357,"tabla":"mosslorn:chests/world_mix"}],"done":0}
