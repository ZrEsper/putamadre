data modify storage mosslorn:force chunks."minecraft:overworld"."-80_20" set value {"entries":[{"dim":"minecraft:overworld","x":-1277,"y":-18,"z":325,"tabla":"mosslorn:chests/world_mix"}],"done":0}
