data modify storage mosslorn:force chunks."minecraft:overworld"."-59_-37" set value {"entries":[{"dim":"minecraft:overworld","x":-930,"y":49,"z":-584,"tabla":"mosslorn:chests/world_mix"}],"done":0}
