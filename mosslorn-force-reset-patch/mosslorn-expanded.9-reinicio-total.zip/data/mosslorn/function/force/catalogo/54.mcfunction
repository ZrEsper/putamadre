data modify storage mosslorn:force chunks."minecraft:overworld"."-88_54" set value {"entries":[{"dim":"minecraft:overworld","x":-1400,"y":-8,"z":872,"tabla":"mosslorn:chests/world_mix"}],"done":0}
