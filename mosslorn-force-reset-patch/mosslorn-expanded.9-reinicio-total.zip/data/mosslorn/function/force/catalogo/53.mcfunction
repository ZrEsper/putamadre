data modify storage mosslorn:force chunks."minecraft:overworld"."-88_11" set value {"entries":[{"dim":"minecraft:overworld","x":-1396,"y":-35,"z":185,"tabla":"mosslorn:chests/world_mix"}],"done":0}
