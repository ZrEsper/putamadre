data modify storage mosslorn:force chunks."minecraft:overworld"."-65_13" set value {"entries":[{"dim":"minecraft:overworld","x":-1033,"y":-4,"z":213,"tabla":"mosslorn:chests/world_mix"}],"done":0}
