scoreboard players set #reloj ml_tmp 0
scoreboard players enable @a moss_info
execute as @a[scores={moss_info=1..}] at @s run function mosslorn:zona/info
execute as @a[scores={moss_info=2}] at @s run function mosslorn:zona/mutantes
scoreboard players set @a[scores={moss_info=1..}] moss_info 0
execute if data storage mosslorn:runtime {activo:1b} run function mosslorn:loot/procesar
execute if data storage mosslorn:runtime {activo:1b} run function mosslorn:loot/procesar
execute if data storage mosslorn:runtime {activo:1b} run function mosslorn:loot/procesar
execute if data storage mosslorn:runtime {activo:1b} run function mosslorn:loot/procesar
