tellraw @s {"text": "Mosslorn v7 — cofres y barriles, generación inmediata", "color": "gold"}
tellraw @s {"text": "/trigger moss_info | /trigger moss_info set 2", "color": "aqua"}
tellraw @s {"text": "/function mosslorn:loot/escanear — escaneo completo de chunks cercanos; también es automático", "color": "green"}
tellraw @s {"text": "/function mosslorn:loot/listar {pagina:1} — lista persistente de contenedores", "color": "green"}
tellraw @s {"text": "/function mosslorn:loot/estado | /function mosslorn:loot/reiniciar", "color": "green"}
tellraw @s {"text": "/function mosslorn:loot/cantidad/escaso | normal | abundante", "color": "green"}
tellraw @s {"text": "/function mosslorn:loot/automatico {minutos:30} — 0 desactiva reposición", "color": "green"}
tellraw @s {"text": "/function mosslorn:loot/scan/automatico_no | automatico_si", "color": "green"}
