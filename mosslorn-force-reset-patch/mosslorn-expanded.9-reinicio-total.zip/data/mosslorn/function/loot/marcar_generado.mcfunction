$data modify storage mosslorn:registro cofres[{dim:"$(dim)",x:$(x),y:$(y),z:$(z)}].generado set value 1b
