$data modify storage mosslorn:registro cofres[{dim:"$(dim)",x:$(x),y:$(y),z:$(z)}].ultima set value $(epoca)
