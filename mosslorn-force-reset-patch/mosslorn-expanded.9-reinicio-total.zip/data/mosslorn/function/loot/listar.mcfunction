$scoreboard players set #pagina ml_tmp $(pagina)
execute if score #pagina ml_tmp matches ..0 run scoreboard players set #pagina ml_tmp 1
scoreboard players remove #pagina ml_tmp 1
scoreboard players set #diez ml_tmp 10
scoreboard players operation #pagina ml_tmp *= #diez ml_tmp
scoreboard players operation #indice ml_tmp = #pagina ml_tmp
tellraw @s {"text": "Cofres y barriles registrados — página solicitada:", "color": "gold"}
function mosslorn:loot/lista/siguiente
function mosslorn:loot/lista/siguiente
function mosslorn:loot/lista/siguiente
function mosslorn:loot/lista/siguiente
function mosslorn:loot/lista/siguiente
function mosslorn:loot/lista/siguiente
function mosslorn:loot/lista/siguiente
function mosslorn:loot/lista/siguiente
function mosslorn:loot/lista/siguiente
function mosslorn:loot/lista/siguiente
