$data remove storage mosslorn:registro cofres[{dim:"$(dim)",x:$(x),y:$(y),z:$(z)}]
