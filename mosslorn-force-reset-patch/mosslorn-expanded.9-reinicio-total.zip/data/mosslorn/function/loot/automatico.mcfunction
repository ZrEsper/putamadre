$scoreboard players set #minutos ml_tmp $(minutos)
execute if score #minutos ml_tmp matches ..0 run scoreboard players set #minutos ml_tmp 0
execute if score #minutos ml_tmp matches 1441.. run scoreboard players set #minutos ml_tmp 1440
scoreboard players operation #auto ml_config = #minutos ml_tmp
scoreboard players operation #auto ml_config *= #1200 ml_tmp
scoreboard players set #auto_timer ml_tmp 0
tellraw @s {"text": "Reposición automática configurada. 0 minutos la desactiva; máximo 1440.", "color": "green"}
