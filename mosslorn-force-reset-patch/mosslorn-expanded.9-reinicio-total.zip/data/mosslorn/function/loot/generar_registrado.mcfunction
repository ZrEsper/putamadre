data modify storage mosslorn:runtime work set from storage mosslorn:runtime entrada
$execute in $(dim) positioned $(x) $(y) $(z) unless data block ~ ~ ~ Items[0] run function mosslorn:loot/llenar with storage mosslorn:runtime work
