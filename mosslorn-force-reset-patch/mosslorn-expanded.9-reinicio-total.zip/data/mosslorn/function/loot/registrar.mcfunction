data modify storage mosslorn:runtime entrada set value {dim:"minecraft:overworld",ultima:0,generado:0b}
data modify storage mosslorn:runtime entrada.dim set from entity @s Dimension
$data modify storage mosslorn:runtime entrada.x set value $(x)
$data modify storage mosslorn:runtime entrada.y set value $(y)
$data modify storage mosslorn:runtime entrada.z set value $(z)
$data modify storage mosslorn:runtime entrada.tabla set value "$(tabla)"
function mosslorn:loot/validar with storage mosslorn:runtime entrada
