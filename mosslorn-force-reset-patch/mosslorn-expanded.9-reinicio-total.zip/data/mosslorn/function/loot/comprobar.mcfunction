execute if data block ~ ~ ~ Items[0] run scoreboard players add #ocupados ml_tmp 1
execute if data block ~ ~ ~ Items[0] run function mosslorn:loot/marcar with storage mosslorn:runtime work
execute unless data block ~ ~ ~ Items unless data block ~ ~ ~ LootTable run scoreboard players add #ausentes ml_tmp 1
execute unless data block ~ ~ ~ Items unless data block ~ ~ ~ LootTable run function mosslorn:loot/marcar with storage mosslorn:runtime work
execute if data block ~ ~ ~ Items unless data block ~ ~ ~ Items[0] run function mosslorn:loot/reponer with storage mosslorn:runtime work
execute unless data block ~ ~ ~ Items if data block ~ ~ ~ LootTable run function mosslorn:loot/reponer with storage mosslorn:runtime work
