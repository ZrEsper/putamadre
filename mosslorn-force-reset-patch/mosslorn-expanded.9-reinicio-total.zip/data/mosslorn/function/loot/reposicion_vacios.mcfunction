scoreboard players add #epoca ml_config 1
scoreboard players set #auto_timer ml_tmp 0
data modify storage mosslorn:runtime cola set from storage mosslorn:registro cofres
data modify storage mosslorn:runtime activo set value 1b
function mosslorn:loot/contadores
tellraw @s {"text": "Reposición solicitada: se recorren los cofres registrados. Los ocupados se respetan; los descargados quedan pendientes.", "color": "green"}
