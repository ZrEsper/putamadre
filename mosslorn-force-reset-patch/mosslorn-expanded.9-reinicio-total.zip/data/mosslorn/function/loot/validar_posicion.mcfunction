scoreboard players set #contenedor ml_tmp 0
$execute in $(dim) positioned $(x) $(y) $(z) if loaded ~ ~ ~ if data block ~ ~ ~ Items run scoreboard players set #contenedor ml_tmp 1
$execute in $(dim) positioned $(x) $(y) $(z) if loaded ~ ~ ~ if data block ~ ~ ~ LootTable run scoreboard players set #contenedor ml_tmp 1
execute if score #contenedor ml_tmp matches 1 run function mosslorn:loot/guardar with storage mosslorn:runtime entrada
execute if score #contenedor ml_tmp matches 1 run tellraw @s {"text":"Cofre registrado. Se conserva su contenido actual.","color":"green"}
execute unless score #contenedor ml_tmp matches 1 run tellraw @s {"text":"No hay un contenedor compatible cargado en esas coordenadas.","color":"red"}
execute if score #contenedor ml_tmp matches 1 run function mosslorn:loot/generar_registrado with storage mosslorn:runtime entrada
