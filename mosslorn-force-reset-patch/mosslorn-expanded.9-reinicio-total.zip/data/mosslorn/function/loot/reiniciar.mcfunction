function mosslorn:force/reiniciar
