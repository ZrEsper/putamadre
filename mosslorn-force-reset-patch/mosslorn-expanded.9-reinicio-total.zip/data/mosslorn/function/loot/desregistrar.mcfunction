data modify storage mosslorn:runtime entrada set value {dim:"minecraft:overworld"}
data modify storage mosslorn:runtime entrada.dim set from entity @s Dimension
$data modify storage mosslorn:runtime entrada.x set value $(x)
$data modify storage mosslorn:runtime entrada.y set value $(y)
$data modify storage mosslorn:runtime entrada.z set value $(z)
function mosslorn:loot/borrar_entrada with storage mosslorn:runtime entrada
