data modify storage mosslorn:runtime cola set from storage mosslorn:registro cofres
function mosslorn:loot/contadores
