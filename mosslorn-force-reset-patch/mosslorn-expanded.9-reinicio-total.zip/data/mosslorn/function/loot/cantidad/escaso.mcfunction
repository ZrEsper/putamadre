scoreboard players set #cantidad ml_config 0
tellraw @s {"text": "Cantidad de loot: escaso. Afecta generaciones nuevas; no borra contenido existente.", "color": "green"}
