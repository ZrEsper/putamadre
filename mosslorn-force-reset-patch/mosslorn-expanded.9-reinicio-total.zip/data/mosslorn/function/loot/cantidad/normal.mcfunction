scoreboard players set #cantidad ml_config 1
tellraw @s {"text": "Cantidad de loot: normal. Afecta generaciones nuevas; no borra contenido existente.", "color": "green"}
