scoreboard players set #cantidad ml_config 2
tellraw @s {"text": "Cantidad de loot: abundante. Afecta generaciones nuevas; no borra contenido existente.", "color": "green"}
