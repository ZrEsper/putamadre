function mosslorn:loot/llenar with storage mosslorn:runtime work
scoreboard players add #repuestos ml_tmp 1
function mosslorn:loot/marcar with storage mosslorn:runtime work
