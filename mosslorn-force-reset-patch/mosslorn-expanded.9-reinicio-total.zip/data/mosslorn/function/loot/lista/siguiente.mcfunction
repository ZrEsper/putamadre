execute store result storage mosslorn:runtime lista.indice int 1 run scoreboard players get #indice ml_tmp
function mosslorn:loot/lista/entrada with storage mosslorn:runtime lista
scoreboard players add #indice ml_tmp 1
