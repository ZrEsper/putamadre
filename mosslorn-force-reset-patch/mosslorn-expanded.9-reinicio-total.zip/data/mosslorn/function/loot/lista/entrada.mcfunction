$execute if data storage mosslorn:registro cofres[$(indice)] run tellraw @s {"nbt":"cofres[$(indice)]","storage":"mosslorn:registro","interpret":false,"color":"aqua"}
