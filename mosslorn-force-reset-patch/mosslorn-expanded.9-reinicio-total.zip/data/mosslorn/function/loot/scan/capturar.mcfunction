data modify storage mosslorn:runtime entrada set value {dim:"minecraft:overworld",tabla:"mosslorn:chests/world_mix",ultima:0,generado:0b}
data modify storage mosslorn:runtime entrada.dim set from storage mosslorn:runtime escaneo.dim
execute store result storage mosslorn:runtime entrada.x int 1 run data get block ~ ~ ~ x
execute store result storage mosslorn:runtime entrada.y int 1 run data get block ~ ~ ~ y
execute store result storage mosslorn:runtime entrada.z int 1 run data get block ~ ~ ~ z
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_bathroom"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_bathroom"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_books"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_books"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_camping"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_camping"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_car"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_car"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_electronics"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_electronics"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_farm"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_farm"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_fish"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_fish"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_fridge"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_fridge"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_house"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_house"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_kitchen"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_kitchen"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_mechanic"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_mechanic"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_military"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_military"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_office"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_office"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_pharmacy"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_pharmacy"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_police"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_police"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_safehouse"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_safehouse"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/crate_workshop"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/crate_workshop"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/moss_megastructure"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/moss_megastructure"
execute if data block ~ ~ ~ {LootTable:"mosslorn:chests/world_mix"} run data modify storage mosslorn:runtime entrada.tabla set value "mosslorn:chests/world_mix"
execute if data block ~ ~ ~ LootTable run data modify storage mosslorn:runtime entrada.tabla set from block ~ ~ ~ LootTable
function mosslorn:loot/scan/registrar with storage mosslorn:runtime entrada
