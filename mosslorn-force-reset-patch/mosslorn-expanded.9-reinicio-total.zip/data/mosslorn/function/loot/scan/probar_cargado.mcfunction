$execute if score #edad_visita ml_tmp matches 6000.. in $(dim) positioned $(x) 0 $(z) if loaded ~ ~ ~ run function mosslorn:loot/scan/iniciar with storage mosslorn:runtime candidato
