scoreboard players operation #sx ml_tmp = #scan_x ml_tmp
scoreboard players operation #sz ml_tmp = #scan_z ml_tmp
scoreboard players remove #sx ml_tmp 16
scoreboard players add #sz ml_tmp 16
execute store result storage mosslorn:runtime candidato.x int 1 run scoreboard players get #sx ml_tmp
execute store result storage mosslorn:runtime candidato.z int 1 run scoreboard players get #sz ml_tmp
function mosslorn:loot/scan/probar with storage mosslorn:runtime candidato
