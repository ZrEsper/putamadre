execute unless data block ~ ~ ~ Items[0] unless data block ~ ~ ~ LootTable run function mosslorn:loot/llenar with storage mosslorn:runtime work
execute if data block ~ ~ ~ LootTable run function mosslorn:loot/marcar_generado with storage mosslorn:runtime work
execute if data block ~ ~ ~ Items[0] run function mosslorn:loot/marcar_generado with storage mosslorn:runtime work
