execute store result score #fila ml_tmp run data get storage mosslorn:runtime escaneo.fase
scoreboard players operation #sy ml_tmp = #fila ml_tmp
scoreboard players operation #sy ml_tmp /= #16 ml_tmp
scoreboard players remove #sy ml_tmp 64
scoreboard players operation #sz_fila ml_tmp = #fila ml_tmp
scoreboard players operation #sz_fila ml_tmp %= #16 ml_tmp
execute store result storage mosslorn:runtime fila.y int 1 run scoreboard players get #sy ml_tmp
execute store result storage mosslorn:runtime fila.z int 1 run scoreboard players get #sz_fila ml_tmp
function mosslorn:loot/scan/posicionar with storage mosslorn:runtime fila
scoreboard players add #fila ml_tmp 1
execute store result storage mosslorn:runtime escaneo.fase int 1 run scoreboard players get #fila ml_tmp
execute if score #fila ml_tmp matches 6144.. run function mosslorn:loot/scan/terminar
