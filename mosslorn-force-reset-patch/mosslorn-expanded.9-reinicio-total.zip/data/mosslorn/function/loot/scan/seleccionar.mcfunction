execute if score #scan ml_tmp matches 1 run return 0
execute store result score #scan_x ml_tmp run data get entity @s Pos[0] 1
execute store result score #scan_z ml_tmp run data get entity @s Pos[2] 1
execute if score #scan_x ml_tmp matches ..-1 run scoreboard players remove #scan_x ml_tmp 15
execute if score #scan_z ml_tmp matches ..-1 run scoreboard players remove #scan_z ml_tmp 15
scoreboard players operation #scan_x ml_tmp /= #16 ml_tmp
scoreboard players operation #scan_z ml_tmp /= #16 ml_tmp
scoreboard players operation #scan_x ml_tmp *= #16 ml_tmp
scoreboard players operation #scan_z ml_tmp *= #16 ml_tmp
data modify storage mosslorn:runtime candidato set value {dim:"minecraft:overworld"}
data modify storage mosslorn:runtime candidato.dim set from entity @s Dimension
execute unless score #scan ml_tmp matches 1 run function mosslorn:loot/scan/candidato_0
execute unless score #scan ml_tmp matches 1 run function mosslorn:loot/scan/candidato_1
execute unless score #scan ml_tmp matches 1 run function mosslorn:loot/scan/candidato_2
execute unless score #scan ml_tmp matches 1 run function mosslorn:loot/scan/candidato_3
execute unless score #scan ml_tmp matches 1 run function mosslorn:loot/scan/candidato_4
execute unless score #scan ml_tmp matches 1 run function mosslorn:loot/scan/candidato_5
execute unless score #scan ml_tmp matches 1 run function mosslorn:loot/scan/candidato_6
execute unless score #scan ml_tmp matches 1 run function mosslorn:loot/scan/candidato_7
execute unless score #scan ml_tmp matches 1 run function mosslorn:loot/scan/candidato_8
