execute store result score #anchor_x ml_tmp run data get entity @s Pos[0]
execute store result score #anchor_z ml_tmp run data get entity @s Pos[2]
execute store result score #expected_x ml_tmp run data get storage mosslorn:runtime escaneo.x
execute store result score #expected_z ml_tmp run data get storage mosslorn:runtime escaneo.z
execute unless score #anchor_x ml_tmp = #expected_x ml_tmp run kill @s
execute unless score #anchor_z ml_tmp = #expected_z ml_tmp run kill @s
execute if entity @s if score #scan ml_tmp matches 1 run function mosslorn:loot/scan/paso_dimension with storage mosslorn:runtime escaneo
