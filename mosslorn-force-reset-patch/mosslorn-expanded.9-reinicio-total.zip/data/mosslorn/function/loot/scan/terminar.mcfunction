function mosslorn:loot/scan/visita with storage mosslorn:runtime escaneo
scoreboard players set #scan ml_tmp 0
kill @s
