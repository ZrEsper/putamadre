summon minecraft:marker ~ ~ ~ {Tags:["ml_scan_anchor"]}
scoreboard players set #scan ml_tmp 1
data modify storage mosslorn:runtime escaneo set from storage mosslorn:runtime candidato
data modify storage mosslorn:runtime escaneo.fase set value 0
execute store result storage mosslorn:runtime escaneo.tiempo int 1 run scoreboard players get #scan_clock ml_tmp
