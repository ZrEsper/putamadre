scoreboard players set #scan ml_tmp 0
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=ml_scan_anchor]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=ml_scan_anchor]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=ml_scan_anchor]
