scoreboard players set #auto_scan ml_config 1
tellraw @s {"text": "Registro y generación automáticos activados: cofres y barriles de chunks cargados cercanos.", "color": "green"}
