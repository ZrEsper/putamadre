scoreboard players set #ultima_visita ml_tmp -6000
$execute if data storage mosslorn:runtime visitados[{dim:"$(dim)",x:$(x),z:$(z)}] store result score #ultima_visita ml_tmp run data get storage mosslorn:runtime visitados[{dim:"$(dim)",x:$(x),z:$(z)}].tiempo
scoreboard players operation #edad_visita ml_tmp = #scan_clock ml_tmp
scoreboard players operation #edad_visita ml_tmp -= #ultima_visita ml_tmp
execute if dimension minecraft:overworld run function mosslorn:loot/scan/probar_cargado with storage mosslorn:runtime candidato
execute if dimension minecraft:the_nether run function mosslorn:loot/scan/probar_cargado with storage mosslorn:runtime candidato
execute if dimension minecraft:the_end run function mosslorn:loot/scan/probar_cargado with storage mosslorn:runtime candidato
