$execute if dimension $(dim) run function mosslorn:loot/scan/lote
$execute unless dimension $(dim) run kill @s
