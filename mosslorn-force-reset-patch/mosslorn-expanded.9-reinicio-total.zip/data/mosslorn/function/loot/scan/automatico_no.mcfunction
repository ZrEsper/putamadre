scoreboard players set #auto_scan ml_config 0
function mosslorn:loot/scan/cancelar
tellraw @s {"text": "Registro automático detenido. El registro existente se conserva.", "color": "green"}
