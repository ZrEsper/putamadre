$data remove storage mosslorn:runtime visitados[{dim:"$(dim)",x:$(x),z:$(z)}]
data modify storage mosslorn:runtime visitados append from storage mosslorn:runtime escaneo
