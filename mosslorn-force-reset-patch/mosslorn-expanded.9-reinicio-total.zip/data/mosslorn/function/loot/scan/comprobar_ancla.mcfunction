scoreboard players set #ancla ml_tmp 0
execute in minecraft:overworld if entity @e[type=minecraft:marker,tag=ml_scan_anchor] run scoreboard players set #ancla ml_tmp 1
execute in minecraft:the_nether if entity @e[type=minecraft:marker,tag=ml_scan_anchor] run scoreboard players set #ancla ml_tmp 1
execute in minecraft:the_end if entity @e[type=minecraft:marker,tag=ml_scan_anchor] run scoreboard players set #ancla ml_tmp 1
execute if score #ancla ml_tmp matches 0 run function mosslorn:loot/scan/cancelar
