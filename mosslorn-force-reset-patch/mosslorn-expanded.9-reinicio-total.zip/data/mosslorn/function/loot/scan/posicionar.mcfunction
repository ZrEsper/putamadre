$execute positioned ~ $(y) ~$(z) run function mosslorn:loot/scan/fila
