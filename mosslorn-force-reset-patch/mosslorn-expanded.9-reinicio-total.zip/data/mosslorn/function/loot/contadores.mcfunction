scoreboard players set #repuestos ml_tmp 0
scoreboard players set #ocupados ml_tmp 0
scoreboard players set #descargados ml_tmp 0
scoreboard players set #ausentes ml_tmp 0
