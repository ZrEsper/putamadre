scoreboard players set #auto_scan ml_config 1
tellraw @s {"text": "Se revisarán cofres Y barriles en 3×3 chunks, de Y=-64 a 319. El contenido existente se conserva.", "color": "green"}
function mosslorn:loot/scan/cancelar
data modify storage mosslorn:runtime visitados set value []
execute at @s run function mosslorn:loot/scan/seleccionar
