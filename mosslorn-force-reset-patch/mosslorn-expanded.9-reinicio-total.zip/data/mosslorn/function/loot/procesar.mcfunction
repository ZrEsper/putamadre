execute unless data storage mosslorn:runtime cola[0] run function mosslorn:loot/nueva_vuelta
execute if data storage mosslorn:runtime cola[0] run function mosslorn:loot/siguiente
