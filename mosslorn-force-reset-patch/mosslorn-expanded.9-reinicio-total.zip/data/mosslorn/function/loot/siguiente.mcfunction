data modify storage mosslorn:runtime work set from storage mosslorn:runtime cola[0]
data remove storage mosslorn:runtime cola[0]
execute store result storage mosslorn:runtime work.epoca int 1 run scoreboard players get #epoca ml_config
execute store result score #prev ml_tmp run data get storage mosslorn:runtime work.ultima
execute if score #prev ml_tmp < #epoca ml_config run function mosslorn:loot/visitar with storage mosslorn:runtime work
