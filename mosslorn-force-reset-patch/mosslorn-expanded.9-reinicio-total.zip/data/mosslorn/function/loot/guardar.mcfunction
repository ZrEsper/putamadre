$data remove storage mosslorn:registro cofres[{dim:"$(dim)",x:$(x),y:$(y),z:$(z)}]
execute store result storage mosslorn:runtime entrada.ultima int 1 run scoreboard players get #epoca ml_config
data modify storage mosslorn:registro cofres append from storage mosslorn:runtime entrada
