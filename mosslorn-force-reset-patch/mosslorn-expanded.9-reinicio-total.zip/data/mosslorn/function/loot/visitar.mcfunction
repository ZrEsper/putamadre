$execute in $(dim) positioned $(x) $(y) $(z) if loaded ~ ~ ~ run function mosslorn:loot/comprobar with storage mosslorn:runtime work
$execute in $(dim) positioned $(x) $(y) $(z) unless loaded ~ ~ ~ run scoreboard players add #descargados ml_tmp 1
