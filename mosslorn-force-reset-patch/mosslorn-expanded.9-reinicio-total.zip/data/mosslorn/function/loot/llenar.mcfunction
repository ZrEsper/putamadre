$data modify block ~ ~ ~ LootTable set value "$(tabla)"
data remove block ~ ~ ~ LootTableSeed
function mosslorn:loot/marcar_generado with storage mosslorn:runtime work
