tellraw @s {"text": "Zona: Edificios altos | Bonus de loot de peligro: 35 %.", "color": "gold"}
