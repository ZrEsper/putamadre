tellraw @s {"text": "Dificultad de población: extrema (×3) | Objetivo posible: 3–15 zombies/chunk.", "color": "red"}
tellraw @s {"text": "Probabilidad de objetivo: 3: 70 % | 6: 18 % | 9: 8 % | 12: 3 % | 15: 1 %", "color": "aqua"}
