scoreboard players set #zona ml_tmp 0
execute if predicate mosslorn:zona/altos run scoreboard players set #zona ml_tmp 3
execute if predicate mosslorn:zona/piramide run scoreboard players set #zona ml_tmp 2
execute if predicate mosslorn:zona/nuclear run scoreboard players set #zona ml_tmp 1
execute if score #zona ml_tmp matches 0 run function mosslorn:zona/general
execute if score #zona ml_tmp matches 1 run function mosslorn:zona/nuclear
execute if score #zona ml_tmp matches 2 run function mosslorn:zona/piramide
execute if score #zona ml_tmp matches 3 run function mosslorn:zona/altos
execute store result score #x ml_tmp run data get entity @s Pos[0] 1
execute store result score #z ml_tmp run data get entity @s Pos[2] 1
execute if score #x ml_tmp matches ..-1 run scoreboard players remove #x ml_tmp 15
execute if score #z ml_tmp matches ..-1 run scoreboard players remove #z ml_tmp 15
scoreboard players operation #x ml_tmp /= #16 ml_tmp
scoreboard players operation #z ml_tmp /= #16 ml_tmp
scoreboard players operation #cx ml_tmp = #x ml_tmp
scoreboard players operation #cz ml_tmp = #z ml_tmp
scoreboard players operation #x ml_tmp *= #16 ml_tmp
scoreboard players operation #z ml_tmp *= #16 ml_tmp
execute store result storage mosslorn:runtime chunk.x int 1 run scoreboard players get #x ml_tmp
execute store result storage mosslorn:runtime chunk.z int 1 run scoreboard players get #z ml_tmp
scoreboard players set #zombies ml_tmp 0
function mosslorn:zona/contar with storage mosslorn:runtime chunk
tellraw @s [{"text": "Chunk ", "color": "gray"}, {"score": {"name": "#cx", "objective": "ml_tmp"}}, {"text": ", "}, {"score": {"name": "#cz", "objective": "ml_tmp"}}, {"text": " | Zombies presentes (cargados): "}, {"score": {"name": "#zombies", "objective": "ml_tmp"}}]
scoreboard players add #x ml_tmp 8
scoreboard players add #z ml_tmp 8
execute store result storage mosslorn:runtime chunk.x int 1 run scoreboard players get #x ml_tmp
execute store result storage mosslorn:runtime chunk.z int 1 run scoreboard players get #z ml_tmp
execute if dimension minecraft:overworld run function mosslorn:zona/poblacion with storage mosslorn:runtime chunk
execute unless dimension minecraft:overworld run tellraw @s {"text":"La población por chunks de Zomboid Hordes está limitada al Overworld.","color":"gray"}
