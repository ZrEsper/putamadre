tellraw @s {"text": "Zona: General | Bonus de loot de peligro: 0 %.", "color": "gold"}
