tellraw @s {"text": "Mutantes — selección de The Hordes por entidad, con los siete tipos instalados:", "color": "gold"}
tellraw @s {"text": "Crawler 0.18 % | Blister 0.25 % | Split Head 0.23 %", "color": "aqua"}
tellraw @s {"text": "Rotten Mutant 0.18 % | Spitter 0.10 % | Zombie Brute 0.05 % | Mutant Brute 0.01 %", "color": "aqua"}
tellraw @s {"text": "Total: 1 % mutante y 99 % zombie. Los tipos no instalados ceden su peso al zombie.", "color": "gray"}
tellraw @s {"text": "Zomboid Hordes: selección base de mutante 1 %, limitada a menos de 2 mutantes vivos a 128 bloques horizontales.", "color": "gray"}
