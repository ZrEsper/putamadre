$execute positioned $(x) -64 $(z) as @e[type=#mosslorn:zombies,dx=15,dy=383,dz=15] run scoreboard players add #zombies ml_tmp 1
