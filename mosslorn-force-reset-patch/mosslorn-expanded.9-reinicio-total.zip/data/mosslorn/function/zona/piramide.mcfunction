tellraw @s {"text": "Zona: Pirámide | Bonus de loot de peligro: 40 %.", "color": "gold"}
