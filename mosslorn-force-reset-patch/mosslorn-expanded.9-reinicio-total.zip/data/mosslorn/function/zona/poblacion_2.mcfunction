tellraw @s {"text": "Dificultad de población: alta (×2) | Objetivo posible: 2–10 zombies/chunk.", "color": "gold"}
tellraw @s {"text": "Probabilidad de objetivo: 2: 70 % | 4: 18 % | 6: 8 % | 8: 3 % | 10: 1 %", "color": "aqua"}
