scoreboard players set #poblacion ml_tmp 1
$execute positioned $(x) 0 $(z) if predicate mosslorn:poblacion/altos run scoreboard players set #poblacion ml_tmp 2
$execute positioned $(x) 0 $(z) if predicate mosslorn:poblacion/piramide run scoreboard players set #poblacion ml_tmp 2
$execute positioned $(x) 0 $(z) if predicate mosslorn:poblacion/nuclear run scoreboard players set #poblacion ml_tmp 3
execute if score #poblacion ml_tmp matches 1 run function mosslorn:zona/poblacion_1
execute if score #poblacion ml_tmp matches 2 run function mosslorn:zona/poblacion_2
execute if score #poblacion ml_tmp matches 3 run function mosslorn:zona/poblacion_3
tellraw @s {"text": "Nuevo objetivo cada 5–10 min de juego. Solo repone lo que falta, si hay posiciones válidas.", "color": "gray"}
tellraw @s {"text": "Selección de mutante en población: 1 % antes de comprobar el límite de 2 mutantes en 128 bloques.", "color": "gray"}
tellraw @s {"text": "The Hordes: 99 % zombie / 1 % mutante por elección con los siete tipos instalados. Es un sistema de oleadas, no un límite por chunk.", "color": "gray"}
tellraw @s {"text": "Fuente: los dos JAR que enviaste. Otras hordas pueden superar este objetivo; el conteo de arriba es la población actual.", "color": "gray"}
