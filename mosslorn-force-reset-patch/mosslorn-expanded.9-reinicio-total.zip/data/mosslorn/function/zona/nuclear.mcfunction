tellraw @s {"text": "Zona: Central nuclear | Bonus de loot de peligro: 65 %.", "color": "gold"}
