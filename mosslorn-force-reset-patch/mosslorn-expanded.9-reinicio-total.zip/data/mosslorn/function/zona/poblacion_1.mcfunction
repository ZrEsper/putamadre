tellraw @s {"text": "Dificultad de población: normal (×1) | Objetivo posible: 1–5 zombies/chunk.", "color": "gold"}
tellraw @s {"text": "Probabilidad de objetivo: 1: 70 % | 2: 18 % | 3: 8 % | 4: 3 % | 5: 1 %", "color": "aqua"}
