execute at @s run function mosslorn:zona/consulta
