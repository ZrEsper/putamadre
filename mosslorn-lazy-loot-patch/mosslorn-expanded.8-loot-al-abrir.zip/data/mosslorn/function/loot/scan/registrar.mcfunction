$execute unless data storage mosslorn:registro cofres[{dim:"$(dim)",x:$(x),y:$(y),z:$(z)}] run function mosslorn:loot/guardar with storage mosslorn:runtime entrada
$data modify storage mosslorn:runtime work set from storage mosslorn:registro cofres[{dim:"$(dim)",x:$(x),y:$(y),z:$(z)}]
execute store result storage mosslorn:runtime work.epoca int 1 run scoreboard players get #epoca ml_config
execute unless data storage mosslorn:runtime work {generado:1b} run function mosslorn:loot/scan/generar with storage mosslorn:runtime work
