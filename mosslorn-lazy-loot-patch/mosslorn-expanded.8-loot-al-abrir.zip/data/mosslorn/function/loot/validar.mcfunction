scoreboard players set #valido ml_tmp 0
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_bathroom"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_books"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_camping"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_car"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_electronics"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_farm"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_fish"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_fridge"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_house"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_kitchen"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_mechanic"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_military"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_office"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_pharmacy"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_police"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_safehouse"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/crate_workshop"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/moss_megastructure"} run scoreboard players set #valido ml_tmp 1
execute if data storage mosslorn:runtime entrada {tabla:"mosslorn:chests/world_mix"} run scoreboard players set #valido ml_tmp 1
execute if score #valido ml_tmp matches 1 run function mosslorn:loot/validar_posicion with storage mosslorn:runtime entrada
execute unless score #valido ml_tmp matches 1 run tellraw @s {"text": "Tabla desconocida. Usa una tabla mosslorn:chests/* del pack.", "color": "red"}
