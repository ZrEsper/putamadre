scoreboard players add #scan_clock ml_tmp 1
scoreboard players add #reloj ml_tmp 1
scoreboard players add #auto_timer ml_tmp 1
execute if score #auto ml_config matches 1.. if score #auto_timer ml_tmp >= #auto ml_config run function mosslorn:loot/reiniciar
execute if score #reloj ml_tmp matches 10.. run function mosslorn:segundo
execute in minecraft:overworld as @e[type=minecraft:marker,tag=ml_scan_anchor,limit=1] at @s run function mosslorn:loot/scan/paso
execute in minecraft:the_nether as @e[type=minecraft:marker,tag=ml_scan_anchor,limit=1] at @s run function mosslorn:loot/scan/paso
execute in minecraft:the_end as @e[type=minecraft:marker,tag=ml_scan_anchor,limit=1] at @s run function mosslorn:loot/scan/paso
execute if score #reloj ml_tmp matches 0 if score #scan ml_tmp matches 1 run function mosslorn:loot/scan/comprobar_ancla
execute if score #reloj ml_tmp matches 0 if score #auto_scan ml_config matches 1 unless score #scan ml_tmp matches 1 as @a at @s run function mosslorn:loot/scan/seleccionar
