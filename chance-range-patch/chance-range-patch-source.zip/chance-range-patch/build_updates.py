from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,zipfile

ROOT=Path(__file__).resolve().parent
TOOLS=ROOT/'hordes-patch/tools'
OUTPUT=ROOT/'output'
OUTPUT.mkdir(exist_ok=True)
EXPECTED={
 'ecj.jar':'01f5a92ac19bb2b3bf85e295a68f2c73c264369109158b566ce9b490af982948',
 'asm.jar':'8cadd43ac5eb6d09de05faecca38b917a040bb9139c7edeb4cc81c740b713281',
 'asm-tree.jar':'9929881f59eb6b840e86d54570c77b59ce721d104e6dfd7a40978991c2d3b41f',
 'asm-util.jar':'f885be71b5c90556f5f1ad1c4f9276b29b96057c497d46666fe4ddbec3cb43c6',
 'asm-analysis.jar':'85b29371884ba31bb76edf22323c2c24e172c3267a67152eba3d1ccc2e041ef2',
 'gson.jar':'4241c14a7727c34feea6507ec801318a3d4a90f070e4525681079fb94ee4c593',
}
for name,digest in EXPECTED.items():
 assert hashlib.sha256((TOOLS/name).read_bytes()).hexdigest()==digest, name
def run(*args):subprocess.run([str(a) for a in args],check=True)
def check_base(path,expected):
 assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,'Wrong input JAR: '+str(path)
def rewrite(base,out,changes,added):
 with zipfile.ZipFile(base) as original,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as result:
  assert not (set(added)&set(original.namelist()))
  for entry in original.infolist():
   result.writestr(entry,changes.get(entry.filename,original.read(entry)))
  for name,data in sorted(added.items()):
   entry=zipfile.ZipInfo(name,(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
   result.writestr(entry,data)
 with zipfile.ZipFile(base) as original,zipfile.ZipFile(out) as result:
  assert result.testzip() is None
  assert len(result.namelist())==len(set(result.namelist()))
  assert set(result.namelist())==set(original.namelist())|set(added)
  assert all(original.read(n)==result.read(n) for n in original.namelist() if n not in changes)
 print('PASS: all undeclared original JAR entries preserved')

def main():
 if len(sys.argv)!=3:raise SystemExit('Usage: python3 -B build_updates.py HORDES_1.8.1.jar MELEE_2.3.0.jar')
 hordes,melee=map(lambda p:Path(p).resolve(),sys.argv[1:])
 check_base(hordes,'2d7e1c663bc09793c6b9fdc597d3294f4130bec5fb7ea90cd45999e8bfca1e3e')
 check_base(melee,'bbd28af59fa53cd178ed27ecd4c71f102a283847c1a9ccc51d2d8c70c0934ac6')
 compiler=['java','-jar',TOOLS/'ecj.jar','-21','-proc:none','-warn:none']
 asmcp=':'.join(str(TOOLS/n) for n in ('asm.jar','asm-tree.jar','asm-analysis.jar','asm-util.jar'))
 with tempfile.TemporaryDirectory(prefix='chance-range-') as temp:
  temp=Path(temp);classes=temp/'hordes'
  run(*compiler,'-d',classes,*sorted((ROOT/'hordes-patch/src').rglob('*.java')))
  changes={p.relative_to(classes).as_posix():p.read_bytes() for p in classes.rglob('*.class')}
  with zipfile.ZipFile(hordes) as z:
   assert set(changes)<=set(z.namelist())
   name='META-INF/neoforge.mods.toml'
   changes[name]=z.read(name).decode().replace('version="1.8.1"','version="1.8.2"').replace('Zomboid Hordes — Chunk Population','Zomboid Hordes — Chance Population').replace('At least two zombies per loaded two-chunk pair, with a shared 5–10 minute replenishment cooldown. Existing zombies count toward the minimum.','Random target of zero to five zombies per loaded two-chunk pair; chances 40/30/18/8/3/1 percent, shared 5–10 minute cooldown. Existing zombies count toward the target.').encode()
  houtput=OUTPUT/'zomboid-hordes-1.8.2-neoforge-1.21.1-chance-population.jar'
  rewrite(hordes,houtput,changes,{})
  run(sys.executable,'-B',ROOT/'hordes-patch/tests/run.py',houtput)
  mroot=ROOT/'melee-patch';mclasses=temp/'melee';runtime=temp/'runtime';tools=temp/'tools'
  run(*compiler,'-d',mclasses,*sorted((mroot/'tests/api-doubles').rglob('*.java')),*sorted((mroot/'src').rglob('*.java')))
  run(*compiler,'-cp',asmcp,'-d',tools,mroot/'PatchMelee.java')
  raw=temp/'melee.jar';run('java','-cp',str(tools)+':'+asmcp,'PatchMelee',melee,raw)
  with zipfile.ZipFile(melee) as original,zipfile.ZipFile(raw) as patched:
   changes={n:patched.read(n) for n in original.namelist() if original.read(n)!=patched.read(n)}
   assert set(changes)=={'dev/zomboidmelee/combat/CombatRules.class','dev/zomboidmelee/combat/ShoveCombat.class'}
   name='META-INF/neoforge.mods.toml'
   changes[name]=original.read(name).decode().replace('version="2.3.0"','version="2.3.1"').encode()
   name='zomboid_global_melee.mixins.json';config=json.loads(original.read(name))
   config['mixins']+=['ConeRangeMixin','RayRangeMixin','OBBRangeMixin']
   changes[name]=json.dumps(config,indent=2).encode()
  added={p.relative_to(mclasses).as_posix():p.read_bytes() for p in (mclasses/'dev/zomboidmelee').rglob('*.class')}
  moutput=OUTPUT/'zomboid-global-melee-animations-2.3.1-range-plus-one.jar'
  rewrite(melee,moutput,changes,added)
  with zipfile.ZipFile(moutput) as z:
   name='dev/zomboidmelee/combat/CombatRules.class';p=runtime/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
  run(*compiler,'-cp',str(runtime)+':'+str(mclasses),'-d',temp/'tests',mroot/'tests/MeleeChecks.java')
  run('java','-Xverify:all','-cp',str(temp/'tests')+':'+str(runtime)+':'+str(mclasses),'MeleeChecks')
  # Production class and injection-annotation validation, without packaging any doubles.
  run(*compiler,'-cp',asmcp,'-d',tools,mroot/'tests/BytecodeChecks.java')
  run('java','-cp',str(tools)+':'+asmcp,'BytecodeChecks',moutput)
 for p in (houtput,moutput):
  print('Output:',p)
  print('SHA256:',hashlib.sha256(p.read_bytes()).hexdigest())
 print('Minecraft/modpack startup is not verified by API doubles or bytecode checks.')
if __name__=='__main__':main()
