import dev.zomboid.hordes.ChunkPopulationRules;
import dev.zomboid.hordes.ChunkPopulationRules.*;
import java.util.*;
public class PopulationChecks {
 static int checks;
 static void check(boolean v,String m){checks++;if(!v)throw new AssertionError(m);}
 public static void main(String[] args) {
  int[] weights=new int[6];
  for(int r=0;r<100;r++)weights[ChunkPopulationRules.target(r)]++;
  check(Arrays.equals(weights,new int[]{40,30,18,8,3,1}),"Exact chance distribution");
  for(int target=0;target<=5;target++)for(int live=0;live<=1000;live++) {
   check(ChunkPopulationRules.missing(live,target)==Math.max(0,target-live),"Fill only target, capped at five");
  }
  for(int r=0;r<=6000;r++){long next=ChunkPopulationRules.cooldown(100,r);check(next>=6100 && next<=12100,"Cooldown");}
  for(int x=-1000;x<=1000;x++){Pair p=Pair.of(x,7);check(p.equals(Pair.of(p.x()+1,7)) && x>=p.x() && x<=p.x()+1,"Negative pairs");}
  State s=new State();Pair p=Pair.of(-1,3);s.next.put(p,200L);s.targets.put(p,5);s.rolls.put(p,7000L);
  State restored=new State();restored.decode(s.encode());restored.plans(s.plans());
  check(restored.next.equals(s.next) && restored.targets.equals(s.targets) && restored.rolls.equals(s.rolls),"Persist retry and roll");
  check(!restored.due(p,199) && restored.due(p,200),"Retry deadline");
  restored.pausedUntil=8000;check(!restored.due(p,7000),"Pause");
  boolean rejected=false;try{ChunkPopulationRules.target(100);}catch(IllegalArgumentException e){rejected=true;}check(rejected,"Invalid roll");
  System.out.println("PASS: "+checks+" chance/cap/cooldown/persistence assertions");
 }
}
