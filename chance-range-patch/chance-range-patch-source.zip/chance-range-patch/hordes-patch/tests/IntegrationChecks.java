import dev.zomboid.hordes.*;
import dev.zomboid.hordes.ChunkPopulationRules.*;
import net.minecraft.server.level.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.event.entity.living.MobSpawnEvent;
import net.minecraft.commands.CommandSourceStack;
import com.mojang.brigadier.context.CommandContext;
import java.util.*;
public class IntegrationChecks {
 static int checks;
 static void check(boolean v,String m){checks++;if(!v)throw new AssertionError(m);}
 static final class Rolls extends Random {
  int percent=99;
  public int nextInt(int bound){return bound==100?percent:bound==16?8:0;}
  public boolean nextBoolean(){return true;}
 }
 static ServerLevel world() {
  ServerLevel l=new ServerLevel();l.random=new Rolls();l.chunks.add("4,4");
  ServerPlayer p=new ServerPlayer();p.world=l;p.x=0;p.y=64;p.z=0;l.players.add(p);return l;
 }
 static List<Object> players(ServerLevel l){return new ArrayList<>(l.players);}
 public static void main(String[] args)throws Exception {
  HordeConfig cfg=HordeConfig.load();check(cfg.balanceVersion==10 && cfg.populationRadiusChunks==4,"Config migration");
  ZomboidHordes.CONFIG=cfg;cfg.helicopterChance=0;
  for(int r:new int[]{0,40,70,88,96,99}) {
   ServerLevel l=world();((Rolls)l.random).percent=r;HordeData d=HordeData.get(l);
   int target=ChunkPopulationRules.target(r);
   check(ChunkPopulation.pairs(l,players(l)).size()==1,"One loaded chunk without neighbor");
   check(ChunkPopulation.populate(l,d,players(l),0)==target,"Exact rolled target "+target);
   check(ChunkPopulation.populate(l,d,players(l),20)==0,"No immediate stacking");
   check(l.chunkLoads==0,"No forced chunk generation");
   for(Entity e:l.entities){Mob mob=(Mob)e;
    check(mob.persistent && mob.finalized && !mob.loot && mob.profiled,"Spawn initialization");
    check(e.tags.getBoolean("zh_population") && e.tags.getBoolean("zh_spawned"),"Population tags");
    check(e.x*e.x+e.z*e.z>=576,"Safe distance");
   }
   HordeData restored=HordeData.load(d.save(new CompoundTag(),null),null);
   check(ChunkPopulation.state(restored).targets.equals(ChunkPopulation.state(d).targets),"SavedData target roundtrip");
   check(ChunkPopulation.populate(l,restored,players(l),20)==0,"Restart cannot bypass cooldown");
   if(target>0){l.entities.get(0).alive=false;
    check(ChunkPopulation.populate(l,d,players(l),5999)==0,"Kill not refilled early");
    check(ChunkPopulation.populate(l,d,players(l),6000)==1,"Cooldown fills only deficit");
   }
  }
  ServerLevel l=world();HordeData d=HordeData.get(l);Pair pair=Pair.of(4,4);
  l.dry=false;check(ChunkPopulation.populate(l,d,players(l),0)==0,"No water spawn");
  check(ChunkPopulation.state(d).targets.get(pair)==5 && ChunkPopulation.state(d).next.get(pair)==200,"Blocked search retains chance");
  ((Rolls)l.random).percent=0;l.dry=true;
  check(ChunkPopulation.populate(l,d,players(l),200)==5,"Retry does not reroll");
  l.entities.get(0).alive=false;
  check(ChunkPopulation.populate(l,d,players(l),6000)==0,"Zero roll adds none");
  check(l.entities.size()==5,"Zero target deletes none");
  ServerPlayer p=l.players.get(0);l.time=12000;l.difficulty=Difficulty.PEACEFUL;
  ChunkPopulation.tick(new ServerTickEvent.Post(new MinecraftServer(l)));check(l.added==5,"Peaceful respected");
  l.difficulty=Difficulty.NORMAL;l.rules.spawn=false;
  ChunkPopulation.tick(new ServerTickEvent.Post(new MinecraftServer(l)));check(l.added==5,"Gamerule respected");
  l.rules.spawn=true;p.creative=true;
  ChunkPopulation.tick(new ServerTickEvent.Post(new MinecraftServer(l)));check(l.added==5,"Creative excluded");
  p.creative=false;ChunkPopulation.pause(p);
  check(ChunkPopulation.populate(l,d,players(l),12000)==0,"Pause respected");
  CommandSourceStack source=new CommandSourceStack(p);ChunkPopulation.status(new CommandContext<>(source));
  check(source.messages.get(0).contains("0–5") && source.messages.get(0).contains("Supervivencia activa"),"Status diagnostics");
  l=world();d=HordeData.get(l);
  for(int i=0;i<7;i++){Zombie existing=new Zombie();existing.world=l;existing.x=72;existing.y=64;existing.z=72;l.entities.add(existing);}
  check(ChunkPopulation.populate(l,d,players(l),0)==0 && l.entities.size()==7,"Existing/manual excess receives no added zombies and is not deleted");
  l=world();l.chunks.add("5,4");check(ChunkPopulation.pairs(l,players(l)).size()==1,"Loaded neighbors share one chance roll");
  l=world();l.solid=false;check(!ChunkPopulation.spawnInChunk(l,players(l),4,4,new int[]{24}),"Invalid floor");
  l.solid=true;l.collisionFree=false;check(!ChunkPopulation.spawnInChunk(l,players(l),4,4,new int[]{24}),"Collision");
  l.collisionFree=true;l.border.valid=false;check(!ChunkPopulation.spawnInChunk(l,players(l),4,4,new int[]{24}),"World border");
  l.border.valid=true;l.accept=false;int[] attempts={7};
  check(!ChunkPopulation.spawnInChunk(l,players(l),4,4,attempts) && attempts[0]==0,"Canceled insertion and work budget");
  check(!ChunkPopulation.spawnInChunk(l,players(l),5,4,new int[]{24}) && l.chunkLoads==0,"Unloaded neighbor");
  Zombie z=new Zombie();z.world=l;
  MobSpawnEvent.PositionCheck event=new MobSpawnEvent.PositionCheck(z,l,MobSpawnType.NATURAL);
  ChunkPopulation.spawnCheck(event);check(event.result==MobSpawnEvent.PositionCheck.Result.FAIL,"Natural spawn cannot bypass chances");
  event=new MobSpawnEvent.PositionCheck(z,l,MobSpawnType.COMMAND);ChunkPopulation.spawnCheck(event);
  check(event.result==MobSpawnEvent.PositionCheck.Result.DEFAULT,"Command spawns preserved");
  System.out.println("PASS: "+checks+" actual spawn/SavedData/config regression checks with API doubles");
 }
}
