import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import java.util.*;
import java.util.zip.*;
public class BytecodeChecks implements Opcodes {
 static int checks,methods;
 static void check(boolean v,String m){checks++;if(!v)throw new AssertionError(m);}
 static Object value(AnnotationNode a,String key) {
  for(int i=0;i<a.values.size();i+=2)if(a.values.get(i).equals(key))return a.values.get(i+1);
  throw new AssertionError("Missing annotation value "+key);
 }
 public static void main(String[] args)throws Exception {
  try(ZipFile z=new ZipFile(args[0])) {
   for(ZipEntry e:Collections.list(z.entries()))if(e.getName().endsWith(".class")) {
    check(e.getName().startsWith("dev/zomboidmelee/"),"No compiler/test doubles in production JAR");
    ClassNode c=new ClassNode();new ClassReader(z.getInputStream(e)).accept(c,0);
    for(MethodNode m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0) {
     new Analyzer<>(new BasicVerifier()).analyze(c.name,m);methods++;
    }
    if(c.name.startsWith("dev/zomboidmelee/mixin/")) {
     check(c.invisibleAnnotations!=null && c.invisibleAnnotations.stream().anyMatch(a->a.desc.equals("Lorg/spongepowered/asm/mixin/Mixin;")),"Mixin annotations have official CLASS retention");
    }
    if(c.name.endsWith("RangeMixin")) {
     AnnotationNode mixin=c.invisibleAnnotations.stream().filter(a->a.desc.endsWith("/Mixin;")).findFirst().orElseThrow();
     String shape=c.name.substring(c.name.lastIndexOf('/')+1).replace("RangeMixin","");
     String target="me.xjqsh.lrtactical.api.collision."+shape+"Filter";
     check(value(mixin,"targets").equals(List.of(target)),"Correct LesRaisins target");
     check(value(mixin,"remap").equals(false),"External API is not remapped");
     MethodNode redirect=c.methods.stream().filter(m->m.name.equals("zga$searchRange")).findFirst().orElseThrow();
     AnnotationNode a=redirect.visibleAnnotations.stream().filter(n->n.desc.endsWith("/Redirect;")).findFirst().orElseThrow();
     check(value(a,"require").equals(1),"Missing field injection fails instead of silently ignoring reach");
     AnnotationNode at=(AnnotationNode)value(a,"at");
     check(value(at,"value").equals("FIELD") && value(at,"opcode").equals(GETFIELD),"Only range reads redirected");
     check(value(at,"target").equals("L"+target.replace('.','/')+";maxRange:D"),"Exact double range field descriptor");
     check(value(a,"method").equals(shape.equals("Ray")?List.of("filterTargets","findEntitiesOnPath"):List.of("filterTargets")),"Both ray path and candidate search boosted");
     MethodNode inject=c.methods.stream().filter(m->m.name.equals("zga$validateRange")).findFirst().orElseThrow();
     AnnotationNode b=inject.visibleAnnotations.stream().filter(n->n.desc.endsWith("/Inject;")).findFirst().orElseThrow();
     check(value(b,"method").equals(List.of("getMaxRange()D")) && value(b,"cancellable").equals(true) && value(b,"require").equals(1),"Server range validation hook");
    }
   }
   String config=new String(z.getInputStream(z.getEntry("zomboid_global_melee.mixins.json")).readAllBytes());
   for(String shape:List.of("Cone","Ray","OBB"))check(config.contains(shape+"RangeMixin"),"New mixin registered");
  }
  System.out.println("PASS: "+methods+" methods analyzed and "+checks+" production/annotation/range-wiring checks");
 }
}
