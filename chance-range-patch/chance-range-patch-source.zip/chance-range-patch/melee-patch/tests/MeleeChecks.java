import dev.zomboidmelee.combat.*;
import dev.zomboidmelee.mixin.*;
import me.xjqsh.lrtactical.api.collision.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.lang.reflect.*;
public class MeleeChecks {
 static int checks;
 static void check(boolean v,String m){checks++;if(!v)throw new AssertionError(m);}
 public static void main(String[] args)throws Exception {
  check(CombatRules.inCone(2.5,0.7),"V includes exact new reach boundary");
  check(!CombatRules.inCone(2.500001,1),"V excludes beyond new reach");
  check(!CombatRules.inCone(2,0.6999),"V still requires forward cone");
  check(CombatRules.damage(4,true)==6 && CombatRules.damage(4,false)==4,"Damage unchanged");
  check(CombatRules.cooldown(20,false)==15 && CombatRules.cooldown(20,true)==20,"Timing unchanged");
  Class<?>[] mixins={ConeRangeMixin.class,RayRangeMixin.class,OBBRangeMixin.class};
  Object[] hooks={new ConeRangeMixin(){},new RayRangeMixin(){},new OBBRangeMixin(){}};
  Class<?>[] filters={ConeFilter.class,RayFilter.class,OBBFilter.class};
  for(int i=0;i<3;i++)for(double base:new double[]{1.5,2.5,4.0,8.0}) {
   Object filter=filters[i].getConstructor(double.class).newInstance(base);
   Method search=mixins[i].getDeclaredMethod("zga$searchRange",filters[i]);search.setAccessible(true);
   Method validation=mixins[i].getDeclaredMethod("zga$validateRange",CallbackInfoReturnable.class);validation.setAccessible(true);
   for(int repeat=0;repeat<1000;repeat++) {
    check((double)search.invoke(hooks[i],filter)==base+1,"Search gets exactly +1");
    CallbackInfoReturnable<Double> result=new CallbackInfoReturnable<>(base);validation.invoke(hooks[i],result);
    check(result.getReturnValue()==base+1,"Server validation gets exactly +1");
    check((double)filters[i].getMethod("getMaxRange").invoke(filter)==base,"No shared range mutation or accumulation");
   }
   check(base+0.5<=MeleeReach.read(filter) && base+1.01>MeleeReach.read(filter),"Extended hit boundary");
  }
  System.out.println("PASS: "+checks+" real range-hook and V-rule assertions with API doubles");
 }
}
