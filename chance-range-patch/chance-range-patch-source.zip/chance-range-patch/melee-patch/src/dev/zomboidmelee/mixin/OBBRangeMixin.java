package dev.zomboidmelee.mixin;
import dev.zomboidmelee.combat.MeleeReach;
import me.xjqsh.lrtactical.api.collision.OBBFilter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/** Boost both target collection and the server's final range validation. */
@Mixin(targets="me.xjqsh.lrtactical.api.collision.OBBFilter",remap=false)
public abstract class OBBRangeMixin {
 @Redirect(method={"filterTargets"},at=@At(value="FIELD",target="Lme/xjqsh/lrtactical/api/collision/OBBFilter;maxRange:D",opcode=180),require=1,remap=false)
 private double zga$searchRange(OBBFilter filter){return MeleeReach.read(filter);}
 @Inject(method="getMaxRange()D",at=@At("RETURN"),cancellable=true,require=1,remap=false)
 private void zga$validateRange(CallbackInfoReturnable<Double> result){result.setReturnValue(MeleeReach.extend(result.getReturnValueD()));}
}
