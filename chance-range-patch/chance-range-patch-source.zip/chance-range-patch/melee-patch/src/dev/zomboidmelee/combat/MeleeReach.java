package dev.zomboidmelee.combat;
import java.lang.reflect.Field;
/** Read the original weapon range without mutating shared attack/filter data. */
public final class MeleeReach {
 public static double extend(double original){return original+1.0;}
 private static final ClassValue<Field> RANGE=new ClassValue<>() {
  protected Field computeValue(Class<?> type) {
   for(Class<?> c=type;c!=null;c=c.getSuperclass()) {
    try {Field f=c.getDeclaredField("maxRange");f.setAccessible(true);return f;}
    catch(NoSuchFieldException ignored){}
   }
   throw new IllegalStateException("Unsupported LesRaisins range filter: "+type.getName());
  }
 };
 public static double read(Object filter) {
  try {return extend(RANGE.get(filter.getClass()).getDouble(filter));}
  catch(IllegalAccessException e){throw new IllegalStateException("Cannot read LesRaisins range",e);}
 }
}
