import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
public class PatchMelee implements Opcodes {
 static byte[] patch(byte[] bytes,String method) throws Exception {
  ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);int changed=0;
  for(MethodNode m:c.methods)if(m.name.equals(method)) {
   for(AbstractInsnNode i:m.instructions)if(i instanceof LdcInsnNode n && Double.valueOf(1.5).equals(n.cst)){n.cst=2.5;changed++;}
  }
  if(changed!=1)throw new IllegalStateException("Expected exactly one reach constant in "+c.name+"."+method+", found "+changed);
  for(MethodNode m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<>(new BasicVerifier()).analyze(c.name,m);
  ClassWriter w=new ClassWriter(0);c.accept(w);return w.toByteArray();
 }
 public static void main(String[] args)throws Exception {
  try(ZipFile input=new ZipFile(args[0]);ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Path.of(args[1])))) {
   for(ZipEntry e:Collections.list(input.entries())) {
    byte[] data=input.getInputStream(e).readAllBytes();
    if(e.getName().equals("dev/zomboidmelee/combat/CombatRules.class"))data=patch(data,"inCone");
    if(e.getName().equals("dev/zomboidmelee/combat/ShoveCombat.class"))data=patch(data,"push");
    ZipEntry n=new ZipEntry(e.getName());n.setTime(0);out.putNextEntry(n);out.write(data);out.closeEntry();
   }
  }
  System.out.println("PASS: V reach and search area both increased 1.5 -> 2.5; bytecode verified");
 }
}
