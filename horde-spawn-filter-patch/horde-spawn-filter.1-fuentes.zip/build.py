from pathlib import Path
import sys,hashlib,json,subprocess,shutil,zipfile,copy
r=Path(__file__).resolve().parent;base=Path(sys.argv[1]).resolve()
assert hashlib.sha256(base.read_bytes()).hexdigest()==json.loads((r/'base.sha256.json').read_text())['sha256']
for n,h in json.loads((r/'tools.sha256.json').read_text()).items():assert hashlib.sha256((r/'tools'/n).read_bytes()).hexdigest()==h
for d in ['patch-tool','patched','test-classes']:shutil.rmtree(r/d,ignore_errors=True);(r/d).mkdir()
def run(*a):subprocess.run(a,cwd=r,check=True)
ecj=['java','-jar',str(r/'tools/ecj.jar'),'-21','-nowarn'];asm=':'.join(str(r/'tools'/n) for n in ['asm.jar','asm-tree.jar','asm-analysis.jar','asm-util.jar'])
run(*ecj,'-cp',asm,'-d',str(r/'patch-tool'),str(r/'Patch.java'))
run('java','-Xverify:all','-cp',str(r/'patch-tool')+':'+asm,'Patch',str(base),str(r/'patched'),str(r/'test-classes'))
run(*ecj,'-cp',str(r/'test-classes'),'-d',str(r/'test-classes'),*[str(p) for p in (r/'tests').rglob('*.java')])
run('java','-Xverify:all','-cp',str(r/'test-classes'),'Checks')
add={p.relative_to(r/'patched').as_posix():p.read_bytes() for p in (r/'patched').rglob('*.class')};add['META-INF/horde-spawn-filter-patch.json']=json.dumps({'revision':'spawn-filter.1','base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'inherits':'rare-mutants-reactive-ai.1'}).encode();changed=set(add)
(r/'output').mkdir(exist_ok=True);out=r/'output/zomboid-hordes-1.8.3-neoforge-1.21.1-rare-mutants-reactive-ai-spawn-filter.1.jar'
with zipfile.ZipFile(base) as z,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
 for e in z.infolist():w.writestr(copy.copy(e),add.pop(e.filename,z.read(e)))
 for n,b in sorted(add.items()):w.writestr(n,b)
with zipfile.ZipFile(base) as z,zipfile.ZipFile(out) as w:
 assert w.testzip() is None
 for n in z.namelist():
  if n not in changed:assert w.read(n)==z.read(n),n
 assert not any(n.startswith('net/minecraft/') or n=='SpawnPredicate.class' for n in w.namelist())
print('PASS every unmodified class/resource preserved; no test doubles packaged')
(r/'output/validation.json').write_text(json.dumps({'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'predicate_cases':13,'asm_methods':45,'minecraft_runtime_tested':False},indent=2))
