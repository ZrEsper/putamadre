from pathlib import Path
import subprocess,zipfile,copy,sys,hashlib,json
r=Path(__file__).resolve().parent
weight,hud,survivor=map(lambda s:Path(s).resolve(),sys.argv[1:4])
for key,p in [('weight',weight),('hud',hud),('survivor',survivor)]:assert hashlib.sha256(p.read_bytes()).hexdigest()==json.loads((r/'bases.sha256.json').read_text())[key]
for p in (r/'tools').glob('*.jar'):assert hashlib.sha256(p.read_bytes()).hexdigest()==json.loads((r/'tools.sha256.json').read_text())[p.name]
ecj=['java','-jar',str(r/'tools/ecj.jar'),'-21','-proc:none','-warn:none'];asm=':'.join(map(str,(r/'tools').glob('asm*.jar')))
def run(*a):subprocess.run(list(a),check=True)
run(*ecj,'-cp',str(weight)+':'+str(survivor),'-d',str(r/'classes'),*[str(p) for f in ['src','stubs'] for p in (r/f).rglob('*.java')])
run(*ecj,'-cp',str(r/'classes')+':'+str(survivor),'-d',str(r/'survivor-classes'),*[str(p) for p in (r/'survivor-src').rglob('*.java')])
run(*ecj,'-cp',asm,'-d',str(r/'patch-tool'),str(r/'Patch.java'))
run('java','-cp',str(r/'patch-tool')+':'+asm,'Patch',str(weight),str(r/'patched'),str(hud),str(r/'hud-patched'))
run(*ecj,'-cp',':'.join(map(str,[r/'classes',r/'patched',weight,survivor])),'-d',str(r/'test-classes'),*[str(p) for p in (r/'tests').rglob('*.java')])
run('java','-Xverify:all','-cp',':'.join(map(str,[r/'test-classes',r/'classes',r/'survivor-classes',r/'patched',weight,survivor])),'StaminaChecks')
def package(base,output,added):
 modified=set(added);output.parent.mkdir(exist_ok=True)
 with zipfile.ZipFile(base) as z:
  with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as w:
   for e in z.infolist():w.writestr(copy.copy(e),added.pop(e.filename,z.read(e)))
   for n,b in sorted(added.items()):w.writestr(n,b)
  with zipfile.ZipFile(output) as w:
   assert w.testzip() is None
   for n in z.namelist():
    if n not in modified:assert z.read(n)==w.read(n),n
   assert not any(n.startswith('net/') for n in w.namelist())
 print('PASS preserved original entries:',output.name)
add={p.relative_to(r/'classes').as_posix():p.read_bytes() for p in (r/'classes/com/armilp').rglob('*.class')}
add.update({p.relative_to(r/'patched').as_posix():p.read_bytes() for p in (r/'patched').rglob('*.class')})
add.update({p.relative_to(r/'resources').as_posix():p.read_bytes() for p in (r/'resources').rglob('*') if p.is_file()})
package(weight,r/'output/eZWeight-neoforge-1.21.1-1.8.4-stamina-v10-fitness-limbs.jar',add)
package(hud,r/'output/zomboid-project-progression-1.21.1-1.0.2-stamina-hud-v2.jar',{p.relative_to(r/'hud-patched').as_posix():p.read_bytes() for p in (r/'hud-patched').rglob('*.class')})

add={p.relative_to(r/'survivor-classes').as_posix():p.read_bytes() for p in (r/'survivor-classes/dev').rglob('*.class')}
add.update({p.relative_to(r/'survivor-resources').as_posix():p.read_bytes() for p in (r/'survivor-resources').rglob('*') if p.is_file()})
package(survivor,r/'output/survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v18-stamina.jar',add)
