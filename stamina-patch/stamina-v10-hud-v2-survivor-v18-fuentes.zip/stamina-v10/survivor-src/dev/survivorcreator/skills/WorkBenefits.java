package dev.survivorcreator.skills;

import dev.survivorcreator.skills.CombatSkillRules;
import dev.survivorcreator.skills.Rules13;
import dev.survivorcreator.skills.Skill;
import java.util.Locale;
import net.minecraft.network.chat.Component;

public final class WorkBenefits {
    public static Component describe(Skill skill, int n) {
        int n2 = Rules13.level(n);
        String string = CombatSkillRules.benefit(skill.id(), n2);
        if (string != null) {
            return Component.literal((String)string);
        }
        String string2 = switch (skill.id()) {
            case "fitness" -> String.format(Locale.ROOT, "Estamina máxima +%d%%; armadura +%.1f; vida m\u00e1xima +%d; carga +%.1f kg", n2*5, (double)n2 * 0.4, n2, (double)n2 * 1.5);
            case "strength" -> String.format(Locale.ROOT, "Da\u00f1o cuerpo a cuerpo +%.1f; vida m\u00e1xima +%d; carga +%d kg", (double)n2 * 0.8, n2, n2 * 2);
            case "sprinting" -> String.format(Locale.ROOT, "Estamina máxima +%d%%; capacidad de carga +%.1f kg", n2*3, (double)n2 * 0.5);
            case "carpentry", "metalworking" -> "Velocidad de trabajo +" + n2 * 3 + "%";
            case "cooking" -> String.format(Locale.ROOT, "Saturaci\u00f3n al comer +%.1f", (double)n2 * 0.1);
            case "farming" -> "Posibilidad de cosecha extra +" + n2 * 2 + "%";
            case "fishing" -> String.format(Locale.ROOT, "Espera \u2212%d%%; suerte +%.1f; pez extra %d%%", n2 * 4, (double)n2 * 0.2, n2 * 5);
            case "first_aid" -> "Tiempo de tratamiento \u2212" + n2 * 4 + "%; curaci\u00f3n +" + n2 * 5 + "%";
            default -> "Sin efecto activo";
        };
        return Component.literal((String)string2);
    }
}

