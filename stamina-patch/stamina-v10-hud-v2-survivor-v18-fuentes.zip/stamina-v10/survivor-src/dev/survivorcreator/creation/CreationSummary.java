package dev.survivorcreator.creation;
import dev.survivorcreator.data.*;
import java.util.*;
import java.lang.reflect.*;
import net.minecraft.resources.ResourceLocation;
public final class CreationSummary {
 public record Boost(String name,String detail,int level,boolean positive){}
 private static final Map<String,Map<String,Integer>> PROFESSIONS=Map.ofEntries(
  job("blacksmith","strength",1,"maintenance",2),job("burger_flipper","cooking",1),job("burglar","sprinting",2,"maintenance",1),
  job("carpenter","carpentry",3),job("chef","cooking",3),job("construction_worker","strength",1,"long_blunt",2),
  job("diy_expert","carpentry",1,"maintenance",2),job("doctor","first_aid",3),job("electrician","maintenance",2,"metalworking",1),
  job("engineer","carpentry",2,"metalworking",1),job("farmer","farming",3),job("fire_officer","fitness",1,"axe",1),
  job("fishing_guide","fishing",3),job("fitness_instructor","fitness",3),job("lumberjack","axe",2,"strength",1),
  job("mechanic","maintenance",3,"metalworking",1),job("nurse","first_aid",2),job("park_ranger","fitness",1,"fishing",1),
  job("police_officer","aiming",3,"reloading",2),job("rancher","farming",2),job("security_guard","fitness",1,"long_blunt",1),
  job("tailor","maintenance",2),job("veteran","aiming",2,"reloading",2),job("welder","metalworking",3),job("paramedic","first_aid",2,"fitness",1),job("hunter","aiming",2,"reloading",1,"fishing",1),job("supply_runner","sprinting",2,"maintenance",1),job("delivery_worker","sprinting",2),job("maintenance_worker","maintenance",3,"carpentry",1),job("fisherman","fishing",3,"cooking",1),job("butcher","short_blade",2,"cooking",2),job("scrap_worker","metalworking",2,"maintenance",2),job("scout","aiming",1,"fitness",1));
 private static final Map<String,Map<String,Integer>> PERKS=Map.ofEntries(
  job("athletic","fitness",2),job("strong","strength",2),job("weak","strength",-2),job("asthmatic","fitness",-1),
  job("good_aim","aiming",1),job("bad_aim","aiming",-1),job("handy","maintenance",1),job("first_aid","first_aid",1),
  job("outdoorsman","fishing",1),job("fast","sprinting",1),job("slow","sprinting",-1),job("clumsy","nimble",-1),job("marksman","aiming",2,"reloading",1),job("runner","fitness",1,"sprinting",2),job("brawler","short_blunt",2,"strength",1),job("field_medic","first_aid",2),job("scavenger","maintenance",1),job("angler","fishing",2),job("sedentary","fitness",-1,"sprinting",-1),job("shaky_hands","aiming",-1,"reloading",-1),job("poor_fighter","strength",-1,"short_blunt",-1),job("resourceful","maintenance",1));
 private static Map.Entry<String,Map<String,Integer>> job(String name,Object... values){Map<String,Integer> map=new LinkedHashMap<>();for(int i=0;i<values.length;i+=2)map.put((String)values[i],(Integer)values[i+1]);return Map.entry(name,Map.copyOf(map));}
 public static List<Perk> perks(Optional<ResourceLocation> profession,List<ResourceLocation> chosen){List<Perk> out=new ArrayList<>();Profession p=profession.map(DataRegistry::profession).orElse(null);if(p!=null)for(var id:p.grantedPerks()){Perk perk=DataRegistry.perk(id);if(perk!=null)out.add(perk);}for(var id:chosen){Perk perk=DataRegistry.perk(id);if(perk!=null)out.add(perk);}return out;}
 public static Map<String,Integer> levels(Optional<ResourceLocation> profession,List<ResourceLocation> chosen){Map<String,Integer> result=new TreeMap<>();profession.filter(id->id.getNamespace().equals("survivorcreator")).ifPresent(id->merge(result,PROFESSIONS.get(id.getPath())));Profession prof=profession.map(DataRegistry::profession).orElse(null);List<ResourceLocation> ids=new ArrayList<>(chosen);if(prof!=null)ids.addAll(prof.grantedPerks());for(var id:ids)if(id.getNamespace().equals("survivorcreator"))merge(result,PERKS.get(id.getPath()));result.replaceAll((k,v)->Math.max(0,Math.min(10,v)));result.entrySet().removeIf(e->e.getValue()==0||!Set.of("fitness","strength","sprinting","aiming","reloading","axe","long_blade","short_blade","long_blunt","short_blunt","spear","maintenance","carpentry","metalworking","cooking","farming","first_aid","fishing").contains(e.getKey()));return result;}
 private static void merge(Map<String,Integer> out,Map<String,Integer> values){if(values!=null)values.forEach((k,v)->out.merge(k,v,Integer::sum));}
 private static String skillName(String id){return net.minecraft.network.chat.Component.translatable("skill.survivorcreator."+id).getString();}
 public static List<Boost> boosts(Optional<ResourceLocation> profession,List<ResourceLocation> chosen){
  List<Boost> list=new ArrayList<>();
  levels(profession,chosen).forEach((id,n)->{var skill=dev.survivorcreator.skills.Skills.get(id);if(skill!=null)list.add(new Boost(skillName(id)+" +"+n,dev.survivorcreator.skills.WorkBenefits.describe(skill,n).getString(),n,true));});
  Profession p=profession.map(DataRegistry::profession).orElse(null);List<Object> effects=new ArrayList<>();if(p!=null)effects.addAll(p.effects());for(Perk perk:perks(profession,chosen))effects.addAll(perk.effects());
  for(Object effect:effects){String type=effect.getClass().getSimpleName();try{switch(type){
   case "AttributeEffect"->{String attr=call(effect,"attribute").toString();double amount=((Number)call(effect,"amount")).doubleValue();String op=call(effect,"op").toString();String key="attribute.name."+attr.substring(attr.indexOf(':')+1);String label=net.minecraft.network.chat.Component.translatable(key).getString();String detail=(amount>=0?"+":"")+fmt(op.equals("ADD_VALUE")?amount:amount*100)+(op.equals("ADD_VALUE")?"":"%");list.add(new Boost(label,detail,0,amount>=0));}
   case "ExhaustionEffect"->{double m=((Number)call(effect,"multiplier")).doubleValue();list.add(new Boost("Consumo de energía",signed((m-1)*100)+"%",0,m<=1));}
   case "DamageTakenEffect"->{double m=((Number)call(effect,"multiplier")).doubleValue();list.add(new Boost("Daño recibido",signed((m-1)*100)+"%",0,m<=1));}
   case "MobEffectEffect"->list.add(new Boost(call(effect,"effect").toString(),"Nivel "+(((Number)call(effect,"amplifier")).intValue()+1),0,true));
  }}catch(ReflectiveOperationException e){throw new IllegalStateException("No se puede resumir el efecto "+type,e);}}
  List<ResourceLocation> allIds=new ArrayList<>(chosen);if(p!=null)allIds.addAll(p.grantedPerks());
  if(allIds.contains(ResourceLocation.tryParse("survivorcreator:runner")))list.add(new Boost("Corredor","Estamina máxima +15% adicional",0,true));
  if(allIds.contains(ResourceLocation.tryParse("survivorcreator:fast_learner")))list.add(new Boost("Aprendizaje","XP de habilidades +20%",0,true));
  if(allIds.contains(ResourceLocation.tryParse("survivorcreator:slow_learner")))list.add(new Boost("Aprendizaje","XP de habilidades −20%",0,false));
  if(allIds.contains(ResourceLocation.tryParse("survivorcreator:hard_of_hearing")))list.add(new Boost("Audición","Sonidos atenuados",0,false));
  if(list.isEmpty())list.add(new Boost("Sin mejoras seleccionadas","Elige una profesión y rasgos",0,true));return list;
 }
 private static Object call(Object target,String method)throws ReflectiveOperationException{Method m=target.getClass().getDeclaredMethod(method);m.setAccessible(true);return m.invoke(target);}
 private static String fmt(double v){return String.format(Locale.ROOT,"%.2f",v).replaceAll("0+$","").replaceAll("\\.$","");}
 private static String signed(double v){return (v>=0?"+":"")+fmt(v);}
 // Server only: called by the original firstGrant, which runs once for a new character.
 public static void seed(Object player){
  try{Class<?> root=Class.forName("dev.survivorcreator.SurvivorCreator");Object character=root.getField("CHARACTER").get(null);Object skills=root.getField("SKILLS").get(null);
   CharacterData data=(CharacterData)getData(player,character);Object skillData=getData(player,skills);
   for(var entry:levels(data.profession(),data.perks()).entrySet()){var skill=dev.survivorcreator.skills.Skills.get(entry.getKey());if(skill==null||!skill.isActive())continue;double current=((Number)skillData.getClass().getMethod("xp",String.class).invoke(skillData,entry.getKey())).doubleValue();double starting=skill.xpForLevel(entry.getValue());skillData=skillData.getClass().getMethod("with",String.class,double.class).invoke(skillData,entry.getKey(),Math.max(current,starting));}
   setData(player,skills,skillData);
   Class.forName("dev.survivorcreator.effects.Effects").getMethod("refresh",Class.forName("net.minecraft.server.level.ServerPlayer")).invoke(null,player);
  }catch(ReflectiveOperationException e){throw new IllegalStateException("No se pudo aplicar los niveles iniciales",e);}
 }
 public static double xp(Object player,double amount){
  try{CharacterData data=(CharacterData)getData(player,Class.forName("dev.survivorcreator.SurvivorCreator").getField("CHARACTER").get(null));List<ResourceLocation> ids=new ArrayList<>(data.perks());Profession p=data.profession().map(DataRegistry::profession).orElse(null);if(p!=null)ids.addAll(p.grantedPerks());double factor=1;if(ids.contains(ResourceLocation.tryParse("survivorcreator:fast_learner")))factor*=1.2;if(ids.contains(ResourceLocation.tryParse("survivorcreator:slow_learner")))factor*=.8;return amount*factor;}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
 }
 private static Object attachment(Object value){return value instanceof java.util.function.Supplier<?> s?s.get():value;}
 private static Object getData(Object p,Object holder)throws ReflectiveOperationException{Object type=attachment(holder);for(Method m:p.getClass().getMethods())if(m.getName().equals("getData")&&m.getParameterCount()==1){if(m.getParameterTypes()[0].isInstance(holder))return m.invoke(p,holder);if(m.getParameterTypes()[0].isInstance(type))return m.invoke(p,type);}throw new NoSuchMethodException("getData");}
 private static void setData(Object p,Object holder,Object data)throws ReflectiveOperationException{Object type=attachment(holder);for(Method m:p.getClass().getMethods())if(m.getName().equals("setData")&&m.getParameterCount()==2){if(m.getParameterTypes()[0].isInstance(holder)){m.invoke(p,holder,data);return;}if(m.getParameterTypes()[0].isInstance(type)){m.invoke(p,type,data);return;}}throw new NoSuchMethodException("setData");}
}
