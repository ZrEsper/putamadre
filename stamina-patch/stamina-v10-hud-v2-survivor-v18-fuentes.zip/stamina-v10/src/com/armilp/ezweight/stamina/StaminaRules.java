package com.armilp.ezweight.stamina;

public final class StaminaRules {
    public static final double MAX = 3000.0;
    public static final double UNLOCK = 600.0;
    public static final double NORMAL = 60.0;
    public static final double HEAVY = 120.0;
    public static final double SHOVE = 45.0;
    public static final double JUMP = 25.0;
    public static final int REST = 40;

    public static State spend(State state, double d) {
        double d2 = Math.max(0.0, state.energy - d);
        return new State(d2, state.locked || d2 <= 0.0, 40);
    }

    public static State tick(State state, boolean bl, boolean bl2, boolean bl3) {
        return tickScaled(state,bl,bl2,bl3,1.0);
    }

    public static State tickScaled(State state,boolean bl,boolean bl2,boolean bl3,double factor) {
        factor=Math.max(1.0,Math.min(1.95,factor));
        double d = state.energy;
        boolean bl4 = state.locked;
        int n = state.delay;
        if (d <= 0.0 && !bl4) {
            bl4 = true;
            n = 40;
        }
        if (bl && !bl4 && d > 0.0) {
            d -= (1.0 + (bl2 ? 0.25 : 0.0))/factor;
            n = 40;
        } else if (n > 0) {
            --n;
        } else {
            d += (bl3 ? 2.5 : 5.0)/factor;
        }
        d = Math.max(0.0, Math.min(3000.0, d));
        if (d <= 0.0) {
            bl4 = true;
            if (state.energy > 0.0) {
                n = 40;
            }
        }
        if (bl4 && d >= 600.0) {
            bl4 = false;
        }
        return new State(d, bl4, n);
    }

    public static boolean canSpend(State state, double d) {
        return !state.locked && Double.isFinite(d) && d >= 0.0 && state.energy >= d;
    }

    public record State(double energy, boolean locked, int delay) {
    }
}

