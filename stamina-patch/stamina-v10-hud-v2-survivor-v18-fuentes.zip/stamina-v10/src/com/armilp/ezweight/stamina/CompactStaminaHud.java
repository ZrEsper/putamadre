package com.armilp.ezweight.stamina;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import com.armilp.ezweight.player.PlayerWeightHandler;
import com.armilp.ezweight.data.WeightSyncData;
public final class CompactStaminaHud {
 private static final ResourceLocation FRAME=ResourceLocation.fromNamespaceAndPath("ezweight","textures/gui/stamina_frame10.png");
 public static int width(int screen){return Math.max(48,Math.min(86,screen/2-100));}
 public static int x(int screen){int width=width(screen);return Math.max(2,Math.min(screen-width-2,screen/2+96));}
 public static String state(double percent,boolean locked,int delay,boolean moving){return locked?"Espera 20%":moving?"En uso":delay>0?"Descansando":percent<.999?"Recuperando":"Listo";}
 public static void render(RenderGuiEvent.Post event){
  Minecraft mc=Minecraft.getInstance();if(mc.player==null||mc.options.hideGui||mc.player.isCreative()||mc.player.isSpectator())return;
  GuiGraphics g=event.getGuiGraphics();int x=x(g.guiWidth()),w=width(g.guiWidth()),y=g.guiHeight()-26;
  double energy=StaminaCommon.getStaminaPercent(mc.player);boolean locked=StaminaCommon.exhausted(mc.player);
  String state=state(energy,locked,StaminaCapacity.delay(mc.player),mc.player.isSprinting());
  g.drawString(mc.font,mc.font.plainSubstrByWidth(state,w),x,y-10,locked?0xffff9b82:0xffded8bf,false);
  bar(g,mc,x,y,w,energy,locked,"Energía",true);
  double max=WeightSyncData.getMaxWeight();double load=max>0?PlayerWeightHandler.getTotalWeight(mc.player)/max:0;
  bar(g,mc,x,y+13,w,load,load>1,"Carga",false);
 }
 private static void bar(GuiGraphics g,Minecraft mc,int x,int y,int w,double amount,boolean warning,String label,boolean stamina){
  g.blit(FRAME,x,y,0,0f,0f,w,10,86,10);
  g.fill(x+w-1,y,x+w,y+10,0xff776b53);
  double fraction=Double.isFinite(amount)?Math.max(0,Math.min(1,amount)):0;
  int color=warning?0xffb65a44:stamina?(amount>.55?0xff709c58:amount>.25?0xffbda34e:0xffb65a44):(amount>.95?0xffbda34e:0xff587f9c);
  int filled=(int)Math.round((w-4)*fraction);
  if(filled>0){g.fill(x+2,y+2,x+2+filled,y+8,color);g.fill(x+2,y+2,x+2+filled,y+3,0x66ffffff);}
  if(stamina){int mark=x+2+(int)Math.round((w-4)*.2);g.fill(mark,y+2,mark+1,y+8,0x99e4d6b5);}
  String text=(w>=78?label:(stamina?"E":"P"))+" "+(int)Math.round(Math.max(0,amount)*100)+"%";
  g.drawString(mc.font,text,x+4,y+1,0xfff2eedc,true);
 }
}
