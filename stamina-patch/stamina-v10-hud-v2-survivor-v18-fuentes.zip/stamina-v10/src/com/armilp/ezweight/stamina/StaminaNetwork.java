package com.armilp.ezweight.stamina;

import com.armilp.ezweight.stamina.StaminaCommon;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@EventBusSubscriber(modid="ezweight", bus=EventBusSubscriber.Bus.MOD)
public final class StaminaNetwork {
    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent registerPayloadHandlersEvent) {
        registerPayloadHandlersEvent.registrar("10").playToClient(Update.TYPE, Update.CODEC, (update, iPayloadContext) -> {
            CompletableFuture completableFuture = iPayloadContext.enqueueWork(() -> StaminaNetwork.accept(update));
        });
    }

    public static void send(ServerPlayer serverPlayer) {
        CompoundTag compoundTag = serverPlayer.getPersistentData();
        PacketDistributor.sendToPlayer((ServerPlayer)serverPlayer, (CustomPacketPayload)new Update(serverPlayer.getUUID(), compoundTag.contains("ezs_energy") ? compoundTag.getDouble("ezs_energy") : 3000.0, compoundTag.getBoolean("ezs_locked"), compoundTag.getInt("ezs_delay"), serverPlayer.level().getGameTime(), StaminaCapacity.factor(serverPlayer)), (CustomPacketPayload[])new CustomPacketPayload[0]);
    }

    public static void accept(Update update) {
        if(StaminaCapacity.acceptClient(update.player(),update.factor(),update.delay(),update.tick()))
            StaminaCommon.accept(update.player(),update.energy(),update.locked(),update.delay(),update.tick());
    }

    public record Update(UUID player, double energy, boolean locked, int delay, long tick, double factor) implements CustomPacketPayload
    {
        public static final CustomPacketPayload.Type<Update> TYPE = new CustomPacketPayload.Type(ResourceLocation.fromNamespaceAndPath((String)"ezweight", (String)"stamina_v10"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Update> CODEC = StreamCodec.of((registryFriendlyByteBuf, update) -> {
            registryFriendlyByteBuf.writeUUID(update.player);
            registryFriendlyByteBuf.writeDouble(update.energy);
            registryFriendlyByteBuf.writeBoolean(update.locked);
            registryFriendlyByteBuf.writeVarInt(update.delay);
            registryFriendlyByteBuf.writeLong(update.tick);
            registryFriendlyByteBuf.writeDouble(update.factor);
        }, registryFriendlyByteBuf -> new Update(registryFriendlyByteBuf.readUUID(), registryFriendlyByteBuf.readDouble(), registryFriendlyByteBuf.readBoolean(), registryFriendlyByteBuf.readVarInt(), registryFriendlyByteBuf.readLong(),registryFriendlyByteBuf.readDouble()));

        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }
}

