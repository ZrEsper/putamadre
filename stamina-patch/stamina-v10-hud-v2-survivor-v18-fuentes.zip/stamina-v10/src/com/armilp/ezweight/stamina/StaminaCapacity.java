package com.armilp.ezweight.stamina;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import dev.survivorcreator.data.*;
import dev.survivorcreator.skills.*;
import java.util.*;
import java.lang.reflect.*;
public final class StaminaCapacity {
 public static double multiplier(int fitness,int sprinting,boolean runner){return 1+.05*Math.max(0,Math.min(10,fitness))+.03*Math.max(0,Math.min(10,sprinting))+(runner?.15:0);}
 private static final Map<UUID,ClientState> CLIENT=new HashMap<>();
 private record ClientState(double factor,int delay,long tick){}
 public static boolean acceptClient(UUID id,double factor,int delay,long tick){ClientState before=CLIENT.get(id);if(before!=null&&tick<before.tick())return false;if(!Double.isFinite(factor))factor=1;CLIENT.put(id,new ClientState(Math.max(1,Math.min(1.95,factor)),Math.max(0,delay),tick));return true;}
 public static void clearClient(){CLIENT.clear();}
 public static int delay(Player p){ClientState state=CLIENT.get(p.getUUID());return state==null?0:state.delay();}
 public static double factor(Player p){
  if(p!=null&&p.level().isClientSide()){ClientState state=CLIENT.get(p.getUUID());return state==null?1:state.factor();}
  if(!(p instanceof ServerPlayer s))return 1;
  try{int f=Skills.level(s,Skills.get("fitness")),r=Skills.level(s,Skills.get("sprinting"));
   Object holder=Class.forName("dev.survivorcreator.SurvivorCreator").getField("CHARACTER").get(null);Object type=((java.util.function.Supplier<?>)holder).get();CharacterData data=null;
   for(Method m:p.getClass().getMethods())if(m.getName().equals("getData")&&m.getParameterCount()==1){Class<?> t=m.getParameterTypes()[0];if(t.isInstance(holder)){data=(CharacterData)m.invoke(p,holder);break;}if(t.isInstance(type)){data=(CharacterData)m.invoke(p,type);break;}}
   boolean runner=false;if(data!=null){var key=net.minecraft.resources.ResourceLocation.tryParse("survivorcreator:runner");runner=data.perks().contains(key);Profession job=data.profession().map(DataRegistry::profession).orElse(null);if(job!=null)runner|=job.grantedPerks().contains(key);}
   return multiplier(f,r,runner);
  }catch(ClassNotFoundException|NoClassDefFoundError e){return 1;}catch(ReflectiveOperationException e){throw new IllegalStateException("Cannot read stamina traits",e);}
 }
 public static double rescale(double energy,double before,double after){return Math.max(0,Math.min(3000,energy*before/after));}
 public static void prepare(Player p){
  if(p==null||p.level().isClientSide())return;
  var tag=p.getPersistentData();double factor=factor(p),old=tag.contains("ezs_capacity_factor10")?tag.getDouble("ezs_capacity_factor10"):1;
  if(!Double.isFinite(old)||old<1||old>1.95)old=1;
  if(tag.contains("ezs_energy")&&Math.abs(old-factor)>1e-9){double energy=tag.getDouble("ezs_energy");if(!Double.isFinite(energy))energy=0;tag.putDouble("ezs_energy",rescale(energy,old,factor));}
  tag.putDouble("ezs_capacity_factor10",factor);
 }
 public static double maximum(Player p){return 3000*factor(p);}
}
