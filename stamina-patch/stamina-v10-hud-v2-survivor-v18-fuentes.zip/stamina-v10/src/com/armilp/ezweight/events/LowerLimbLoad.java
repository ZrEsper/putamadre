package com.armilp.ezweight.events;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.damagesource.DamageSource;
import java.lang.reflect.*;
import java.util.*;
public final class LowerLimbLoad {
 public static boolean over(double ratio){return Double.isFinite(ratio)&&ratio>1.0;}
 public static boolean protectedPlayer(Player p){return p==null||!p.isAlive()||p.isCreative()||p.isSpectator();}
 public static boolean damage(Player p,DamageSource source,float amount){
  if(protectedPlayer(p)||!Float.isFinite(amount)||amount<=0)return false;
  try{
   Class<?> utils=Class.forName("ichttt.mods.firstaid.common.util.CommonUtils");
   Object model=utils.getMethod("getDamageModel",Player.class).invoke(null,p);if(model==null)return false;
   List<Object> parts=new ArrayList<>();
   for(String name:List.of("LEFT_LEG","RIGHT_LEG","LEFT_FOOT","RIGHT_FOOT")){Object part=model.getClass().getField(name).get(model);if(((Number)part.getClass().getField("currentHealth").get(part)).floatValue()>0)parts.add(part);}
   if(parts.isEmpty())return false;
   float share=amount/parts.size();
   for(Object part:parts)part.getClass().getMethod("damage",float.class,Player.class,boolean.class).invoke(part,share,p,true);
   model.getClass().getMethod("scheduleResync").invoke(model);
   model.getClass().getMethod("syncVanillaHealth",Player.class).invoke(model,p);
   return true;
  }catch(ClassNotFoundException e){return p.hurt(source,amount);}catch(ReflectiveOperationException e){throw new IllegalStateException("Cannot apply overweight injury to First Aid lower limbs",e);}
 }
}
