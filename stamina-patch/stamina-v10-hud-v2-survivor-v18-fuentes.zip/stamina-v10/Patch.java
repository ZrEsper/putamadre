import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;import java.nio.file.*;import java.util.*;import java.util.zip.*;
public class Patch implements Opcodes {
 static String CAP="com/armilp/ezweight/stamina/StaminaCapacity",LIMB="com/armilp/ezweight/events/LowerLimbLoad";
 static void reset(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;}
 static MethodInsnNode call(String owner,String name,String desc){return new MethodInsnNode(INVOKESTATIC,owner,name,desc,false);}
 public static void main(String[] args)throws Exception{
  try(ZipFile z=new ZipFile(args[0])){int methods=0;
   for(String name:List.of("com/armilp/ezweight/stamina/StaminaCommon","com/armilp/ezweight/stamina/StaminaHudOverlay","com/armilp/ezweight/events/WeightDamage")){
    ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class"))).accept(c,ClassReader.EXPAND_FRAMES);int changed=0;
    for(MethodNode m:c.methods){
     if(name.endsWith("StaminaCommon")){
      if(m.name.equals("state")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(call(CAP,"prepare","(Lnet/minecraft/world/entity/player/Player;)V"));m.instructions.insert(l);changed++;}
      if(m.name.equals("canSpend")){InsnList l=new InsnList();l.add(new VarInsnNode(DLOAD,1));l.add(new VarInsnNode(ALOAD,0));l.add(call(CAP,"factor","(Lnet/minecraft/world/entity/player/Player;)D"));l.add(new InsnNode(DDIV));l.add(new VarInsnNode(DSTORE,1));m.instructions.insert(l);changed++;}
      if(m.name.equals("consume"))for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.owner.endsWith("StaminaRules")&&x.name.equals("spend")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(call(CAP,"factor","(Lnet/minecraft/world/entity/player/Player;)D"));l.add(new InsnNode(DDIV));m.instructions.insertBefore(i,l);changed++;}
      if(m.name.equals("clearClient")){m.instructions.insert(call(CAP,"clearClient","()V"));changed++;}
      if(m.name.equals("onPlayerTick"))for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.owner.endsWith("StaminaRules")&&x.name.equals("tick")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,1));l.add(call(CAP,"factor","(Lnet/minecraft/world/entity/player/Player;)D"));m.instructions.insertBefore(i,l);x.name="tickScaled";x.desc=x.desc.replace("ZZZ)","ZZZD)");changed++;}
     }
     if(name.endsWith("StaminaHudOverlay")&&m.name.equals("onRender")){reset(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(call("com/armilp/ezweight/stamina/CompactStaminaHud","render",m.desc));m.instructions.add(new InsnNode(RETURN));changed++;}
     if(name.endsWith("WeightDamage")){
      if(m.name.equals("isOverThreshold")){reset(m);m.instructions.add(new VarInsnNode(DLOAD,0));m.instructions.add(call(LIMB,"over","(D)Z"));m.instructions.add(new InsnNode(IRETURN));changed++;}
      if(m.name.equals("onPlayerTick")){
       int cooldown=0,damage=0;for(AbstractInsnNode i:m.instructions.toArray()){
        if(i instanceof IntInsnNode x&&x.operand==20){x.operand=100;cooldown++;}
        if(i instanceof MethodInsnNode x&&x.name.equals("hurt")){x.setOpcode(INVOKESTATIC);x.owner=LIMB;x.name="damage";x.desc="(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/damagesource/DamageSource;F)Z";x.itf=false;damage++;}
       }if(cooldown!=1||damage!=1)throw new IllegalStateException("Damage transform boundaries");changed+=2;
       // Guard placed immediately after local Player assignment, with the original frame for the return branch.
       AbstractInsnNode assignment=null;for(AbstractInsnNode i:m.instructions)if(i instanceof VarInsnNode x&&x.getOpcode()==ASTORE&&x.var==1){assignment=i;break;}
       if(assignment==null)throw new IllegalStateException("Player local missing");InsnList l=new InsnList();LabelNode proceed=new LabelNode();l.add(new VarInsnNode(ALOAD,1));l.add(call(LIMB,"protectedPlayer","(Lnet/minecraft/world/entity/player/Player;)Z"));l.add(new JumpInsnNode(IFEQ,proceed));l.add(new VarInsnNode(ALOAD,1));l.add(call(c.name,"resetTickCounter","(Lnet/minecraft/world/entity/player/Player;)V"));l.add(new InsnNode(RETURN));l.add(proceed);l.add(new FrameNode(F_NEW,2,new Object[]{"net/neoforged/neoforge/event/tick/PlayerTickEvent$Post","net/minecraft/world/entity/player/Player"},0,null));m.instructions.insert(assignment,l);changed++;
      }
     }
    }
    int expected=name.endsWith("StaminaCommon")?5:name.endsWith("WeightDamage")?4:1;if(changed!=expected)throw new IllegalStateException(name+" "+changed);
    ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] out=w.toByteArray();ClassNode checked=new ClassNode();new ClassReader(out).accept(checked,0);for(MethodNode m:checked.methods)if(m.instructions.size()>0){new Analyzer<>(new BasicVerifier()).analyze(c.name,m);methods++;}
    Path p=Path.of(args[1],name+".class");Files.createDirectories(p.getParent());Files.write(p,out);System.out.println("PASS "+name);
   }System.out.println("PASS "+methods+" transformed methods verified");
  }
  try(ZipFile z=new ZipFile(args[2])){String name="dev/zomboidprogression/ProgressionEvents";ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class"))).accept(c,ClassReader.EXPAND_FRAMES);for(MethodNode m:c.methods)if(m.name.equals("onHud")){reset(m);m.instructions.add(new InsnNode(RETURN));}ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=Path.of(args[3],name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());}
 }
}
