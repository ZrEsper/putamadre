from pathlib import Path
import json,copy,re,zipfile,hashlib,shutil
r=Path(__file__).resolve().parent;out=r/'build';shutil.rmtree(out,ignore_errors=True);root=out/'data/mosslorn/loot_table';root.mkdir(parents=True)
source={p.stem:json.loads(p.read_text()) for p in (r/'bases/loot_table/chests').glob('*.json')}
original_items=set(); catalog={}
def walk(x):
 if isinstance(x,dict):
  if x.get('type')=='minecraft:item':
   original_items.add(x['name']);catalog.setdefault(x['name'],copy.deepcopy(x))
  for v in x.values():yield from walk(v)
  yield x
 elif isinstance(x,list):
  for v in x:yield from walk(v)
for d in source.values():list(walk(d))
verified=json.loads((r/'new-items.json').read_text());added=set();fixes=0
for d in source.values():
 d['type']='minecraft:chest'
 for node in walk(d):
  if node.get('function')=='minecraft:set_custom_data' and 'StoredEnchantments' in node.get('tag',''):
   enchant=re.search(r'id:\\?"([\w:]+)\\?",lvl:(\d+)s',node['tag']);assert enchant,node
   node.clear();node.update(function='minecraft:set_enchantments',enchantments={enchant[1]:int(enchant[2])});fixes+=1

def item(name,weight=1,lo=1,hi=1,worn=False):
 if not name.startswith('minecraft:'):assert name in original_items or name in verified,name
 if name not in original_items:added.add(name)
 e={'type':'minecraft:item','name':name,'weight':weight}
 if hi!=1 or lo!=1:e['functions']=[{'function':'minecraft:set_count','count':{'type':'minecraft:uniform','min':lo,'max':hi}}]
 if worn:e.setdefault('functions',[]).append({'function':'minecraft:set_damage','damage':{'type':'minecraft:uniform','min':.2,'max':.85}})
 return e

def pool(entries,lo=1,hi=2,chance=1):
 p={'rolls':{'type':'minecraft:uniform','min':lo,'max':hi},'entries':entries}
 if chance<1:p['conditions']=[{'condition':'minecraft:random_chance','chance':chance}]
 return p

def ref(path,w=1):return {'type':'minecraft:loot_table','value':'mosslorn:'+path,'weight':w}
def save(path,d):
 p=root/(path+'.json');p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(d,indent=2)+'\n')

def frommod(ns,patterns):return [copy.deepcopy(e) for n,e in catalog.items() if n.startswith(ns+':') and any(s in n for s in patterns)]
def clothes(prefixes):return [item(n) for n in verified if n.startswith('selfexpression:') and any(n.split(':')[1].startswith(p+'_') for p in prefixes)]
# Independent loadout subtables: each supplies the matching gun AND ammo through two pools.
loadouts={}
for gun,ammo in [('glock_17','9mm'),('m1911','45acp'),('m870','12g'),('ak47','762x39'),('m4a1','556x45'),('m700','308')]:
 def find(key,value):
  for d in source.values():
   for e in walk(d):
    if e.get('type')=='minecraft:item' and any(key+':"tacz:'+value+'"' in f.get('tag','') for f in e.get('functions',[])):return copy.deepcopy(e)
  raise AssertionError((key,value))
 g=find('GunId',gun);a=find('AmmoId',ammo);g['weight']=a['weight']=1
 for f in a['functions']:
  if f.get('function')=='minecraft:set_count':f['count']={'type':'minecraft:uniform','min':6 if ammo=='12g' else 8,'max':12 if ammo=='12g' else 24}
 path='loadouts/'+gun;save(path,{'type':'minecraft:chest','pools':[pool([g],1,1),pool([a],1,1)]});loadouts[gun]=ref(path)

heal=frommod('firstaid',['bandage','plaster','cloth','splint','painkillers']);meds=frommod('lrtactical',['ibuprofen','amoxycillin','blood_pack','ai2','cms','vaseline']);food=frommod('farmersdelight',['sandwich','cabbage','tomato','rice','milk','beef_stew'])
new={
 'crate_mechanic':[pool([item('minecraft:iron_ingot',8,1,4),item('minecraft:copper_ingot',8,2,6),item('minecraft:redstone',4,1,6),item('minecraft:chain',3,1,3),item('minecraft:iron_pickaxe',2,worn=True),item('minecraft:iron_axe',2,worn=True),item('okadditions:crowbar',3)],2,4),pool(clothes(['woodworker','black_work_apron']),1,1,.35)],
 'crate_pharmacy':[pool(heal,2,4),pool(meds,1,2,.55),pool([item('okadditions:ice_pack'),item('okadditions:smelling_salts'),item('minecraft:glass_bottle',3,1,3)],1,2),pool(clothes(['doctor']),1,1,.3)],
 'crate_farm':[pool([item('minecraft:wheat_seeds',5,3,12),item('minecraft:beetroot_seeds',3,2,8),item('minecraft:potato',4,2,6),item('minecraft:carrot',4,2,6),item('minecraft:bone_meal',3,2,8),item('minecraft:iron_hoe',2,worn=True),item('minecraft:lead',1)],2,4),pool(clothes(['autumn_gardener','work_apron']),1,1,.35)],
 'crate_workshop':[pool([item('minecraft:iron_shovel',2,worn=True),item('minecraft:iron_axe',2,worn=True),item('minecraft:iron_pickaxe',2,worn=True),item('minecraft:iron_nugget',4,3,12),item('minecraft:string',4,2,8),item('minecraft:leather',3,1,4),item('okadditions:iron_rod',2),item('minecraft:torch',3,2,8)],2,4),pool(clothes(['woodworker']),1,1,.3)],
 'crate_camping':[pool([item('minecraft:campfire'),item('minecraft:compass'),item('minecraft:leather',3,1,3),item('minecraft:cooked_beef',3,1,3),item('minecraft:torch',5,2,8),item('okadditions:binoculars'),item('minecraft:fishing_rod',2,worn=True)],2,3),pool(heal,1,1,.4),pool(clothes(['survivor','apocalypsise_survivor']),1,1,.25)],
 'crate_electronics':[pool([item('minecraft:redstone',8,2,8),item('minecraft:copper_ingot',6,1,4),item('minecraft:comparator',2),item('minecraft:repeater',2),item('minecraft:clock'),item('minecraft:iron_nugget',4,2,8),item('okadditions:mounted_light',2)],2,3)],
 'crate_police':[pool([loadouts['glock_17'],loadouts['m1911'],loadouts['m870']],1,1,.2),pool(clothes(['police','police_2']),1,2,.6),pool(heal,1,2),pool([item('okadditions:flashbang'),item('okadditions:bola_iron'),item('okadditions:binoculars')],1,1,.25)],
 'crate_safehouse':[pool(food,2,3),pool(heal,1,2),pool(clothes(['survivor','apocalypsise_survivor']),1,2,.5),pool([loadouts['glock_17'],loadouts['m1911'],loadouts['m870']],1,1,.1),pool([item('okadditions:energy_drink'),item('minecraft:coal',3,1,4),item('minecraft:string',3,1,4)],1,2)],
 'crate_military':[pool([loadouts['ak47'],loadouts['m4a1'],loadouts['m700']],1,1,.4),pool(frommod('fracturepoint',['iz_','helmet','soviet']),1,2,.65),pool(meds,1,2),pool(frommod('tacz',['attachment']),1,1,.2)]
}
alltables={**source,**{n:{'type':'minecraft:chest','pools':p} for n,p in new.items()}}
for name,d in alltables.items():
 for state,chance,rollcap in [('ransacked',.2,1),('normal',.65,2),('stocked',1,3)]:
  variant=copy.deepcopy(d)
  for p in variant.get('pools',[]):
   old=p.get('rolls',1); maximum=old.get('max',1) if isinstance(old,dict) else old
   p['rolls']={'type':'minecraft:uniform','min':1,'max':max(1,min(rollcap,int(maximum)))}
   p['conditions']=p.get('conditions',[])+[{'condition':'minecraft:random_chance','chance':chance}]
   p.pop('bonus_rolls',None)
  save('variants/'+name+'_'+state,variant)
 save('chests/'+name,{'type':'minecraft:chest','pools':[pool([ref('variants/'+name+'_ransacked',30),ref('variants/'+name+'_normal',55),ref('variants/'+name+'_stocked',15)],1,1)]})
weights={'crate_house':28,'crate_kitchen':10,'crate_bathroom':8,'crate_office':8,'crate_books':5,'crate_fish':3,'crate_fridge':5,'crate_mechanic':7,'crate_pharmacy':6,'crate_farm':5,'crate_workshop':5,'crate_camping':3,'crate_electronics':3,'crate_police':1,'crate_safehouse':2,'crate_military':1}
assert sum(weights.values())==100
save('chests/world_mix',{'type':'minecraft:chest','pools':[pool([ref('chests/'+n,w) for n,w in weights.items()],1,1)]})
(out/'pack.mcmeta').write_text(json.dumps({'pack':{'pack_format':48,'description':'Mosslorn: 18 contextos, estados de saqueo, suministros y ropa — 1.21.1'}},indent=2))
# 1.21–1.21.1 data pack format is 48 (resource pack format is 34).
files=list(root.rglob('*.json'));ids={p.relative_to(root).with_suffix('').as_posix() for p in files};checks=0
for p in files:
 for node in walk(json.loads(p.read_text())):
  if node.get('type')=='minecraft:loot_table' and node.get('value','').startswith('mosslorn:'):assert node['value'][9:] in ids;checks+=1
  if node.get('type')=='minecraft:item':assert node['name'].startswith('minecraft:') or node['name'] in original_items or node['name'] in verified;checks+=1
  if node.get('condition')=='minecraft:random_chance':assert 0<=node['chance']<=1;checks+=1
  if node.get('function')=='minecraft:set_custom_data':assert 'StoredEnchantments' not in node.get('tag','');checks+=1
assert len(ids)==79,len(ids)
(r/'output').mkdir(exist_ok=True)
with zipfile.ZipFile(r/'output/mosslorn-expanded.1.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(out))
(r/'output/validation.json').write_text(json.dumps({'tables':len(ids),'contexts':len(alltables),'states':3,'checks':checks,'enchanted_books_fixed':fixes,'new_items':sorted(added),'mix_weights':weights,'minecraft_runtime_tested':False,'baseline_mod_ids_verified_against_original_json_only':True},indent=2));print('PASS',len(ids),'tables',checks,'reference/item/schema checks;',fixes,'enchantment fixes')
