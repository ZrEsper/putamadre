from pathlib import Path
import tempfile,io,zlib,gzip,struct,subprocess,sys,json,shutil
import nbtlib
import convert_world as c
r=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as td:
 root=Path(td);world=root/'original';reg=world/'region';reg.mkdir(parents=True);(world/'level.dat').write_bytes(b'fixture')
 for compression in [1,2,3]:
  entities=[]
  for i,id in enumerate(['minecraft:chest','minecraft:barrel','minecraft:trapped_chest','minecraft:furnace']):
   entities.append(nbtlib.Compound({'id':nbtlib.String(id),'x':nbtlib.Int(i),'y':nbtlib.Int(64),'z':nbtlib.Int(0),'Items':nbtlib.List[nbtlib.Compound]([nbtlib.Compound({'id':nbtlib.String('minecraft:diamond'),'count':nbtlib.Int(12)})]),'LootTable':nbtlib.String('mosslorn:chests/crate_house' if i==0 else 'minecraft:chests/simple_dungeon'),'CustomName':nbtlib.String('keep me')}))
  n=nbtlib.File({'block_entities':nbtlib.List[nbtlib.Compound](entities),'DataVersion':nbtlib.Int(3955),'unchanged':nbtlib.String('preserve')});s=io.BytesIO();n.write(s);raw=s.getvalue();new,counts=c.transform(raw);assert counts['containers']==3 and counts['kept_context']==1 and counts['replaced_item_stacks']==3
  parsed=nbtlib.File.parse(io.BytesIO(new));assert str(parsed['unchanged'])=='preserve'
  for i,be in enumerate(parsed['block_entities']):
   assert str(be['CustomName'])=='keep me'
   if i<3:assert len(be['Items'])==0 and str(be['LootTable'])==('mosslorn:chests/crate_house' if i==0 else 'mosslorn:chests/world_mix')
   else:assert len(be['Items'])==1 and str(be['LootTable'])=='minecraft:chests/simple_dungeon'
  encoded=gzip.compress(raw) if compression==1 else zlib.compress(raw) if compression==2 else raw;record=struct.pack('>I',len(encoded)+1)+bytes([compression])+encoded;sectors=(len(record)+4095)//4096;header=bytearray(8192);header[:4]=((2<<8)|sectors).to_bytes(4,'big');path=reg/f'r.{compression}.0.mca';path.write_bytes(header+record+bytes(sectors*4096-len(record)))
  before=path.read_bytes();assert c.region(path)['containers']==3 and before==path.read_bytes()
 snapshots={p.name:p.read_bytes() for p in reg.glob('*.mca')}
 # CLI copies instead of editing original; requires actual built datapack beside tool.
 shutil.copyfile(r/'output/mosslorn-expanded.1.zip',r/'mosslorn-expanded.1.zip')
 dest=root/'converted';subprocess.run([sys.executable,str(r/'convert_world.py'),str(world),'--apply','--output',str(dest)],check=True,stdout=subprocess.DEVNULL)
 assert (dest/c.MARKER).exists() and (dest/'datapacks/mosslorn-expanded.1.zip').exists()
 assert all((reg/n).read_bytes()==b for n,b in snapshots.items())
 assert subprocess.run([sys.executable,str(r/'convert_world.py'),str(dest)],capture_output=True).returncode!=0
 for path in (dest/'region').glob('*.mca'):
  assert c.region(path)['replaced_item_stacks']==0
 print('PASS actual NBT+region roundtrips gzip/zlib/raw, chest/barrel/trapped chest, other inventory preserved, CLI copy/install, original untouched, second conversion refused')
