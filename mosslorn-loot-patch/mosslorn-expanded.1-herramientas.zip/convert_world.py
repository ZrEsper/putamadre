#!/usr/bin/env python3
"""Offline, one-time conversion of vanilla chest/barrel block entities. Default: read-only scan."""
from pathlib import Path
import argparse,io,json,gzip,zlib,struct,shutil,hashlib,time
import nbtlib
SECTOR=4096;TARGETS={'minecraft:chest','minecraft:trapped_chest','minecraft:barrel'}
MARKER='mosslorn-conversion-once.json'

def transform(raw):
 nbt=nbtlib.File.parse(io.BytesIO(raw));data=nbt.get('Level',nbt);entities=data.get('block_entities',data.get('TileEntities',[]));counts={'containers':0,'replaced_item_stacks':0,'kept_context':0}
 for be in entities:
  if str(be.get('id','')) not in TARGETS:continue
  counts['containers']+=1;counts['replaced_item_stacks']+=len(be.get('Items',[]))
  old=str(be.get('LootTable',''))
  # Keep a known Mosslorn room context; other containers get the weighted world mix.
  table=old if old in TABLES else 'mosslorn:chests/world_mix'
  counts['kept_context']+=int(table==old)
  be['Items']=nbtlib.List[nbtlib.Compound]([])
  be['LootTable']=nbtlib.String(table)
  seed=int.from_bytes(hashlib.sha256((str(be.get('x',0))+','+str(be.get('y',0))+','+str(be.get('z',0))).encode()).digest()[:8],'big',signed=True)
  be['LootTableSeed']=nbtlib.Long(seed or 1)
 if not counts['containers']:return raw,counts
 stream=io.BytesIO();nbt.write(stream);return stream.getvalue(),counts
TABLES={'mosslorn:chests/'+n for n in ['crate_house','crate_kitchen','crate_fridge','crate_bathroom','crate_office','crate_car','crate_fish','crate_books','moss_megastructure','crate_mechanic','crate_pharmacy','crate_farm','crate_workshop','crate_camping','crate_electronics','crate_police','crate_safehouse','crate_military','world_mix']}

def region(path,apply=False):
 b=path.read_bytes()
 if len(b)<8192:raise ValueError('Truncated region '+str(path))
 header=bytearray(b[:8192]);records=[];total={'containers':0,'replaced_item_stacks':0,'kept_context':0,'skipped_chunks':0};changed=False
 for index in range(1024):
  value=int.from_bytes(header[index*4:index*4+4],'big');offset=value>>8;sectors=value&255
  if not offset:records.append(None);continue
  if offset<2 or offset*SECTOR+sectors*SECTOR>len(b):raise ValueError('Invalid region location '+str(path))
  length=int.from_bytes(b[offset*SECTOR:offset*SECTOR+4],'big')
  if length<1 or length+4>sectors*SECTOR:raise ValueError('Invalid region record '+str(path))
  record=b[offset*SECTOR:offset*SECTOR+4+length];compression=record[4]
  if compression not in [1,2,3]:total['skipped_chunks']+=1;records.append(record);continue
  payload=record[5:];raw=gzip.decompress(payload) if compression==1 else zlib.decompress(payload) if compression==2 else payload
  new,c=transform(raw)
  for k,v in c.items():total[k]+=v
  if c['containers']:
   encoded=gzip.compress(new,mtime=0) if compression==1 else zlib.compress(new) if compression==2 else new
   record=struct.pack('>I',len(encoded)+1)+bytes([compression])+encoded;changed=True
  records.append(record)
 if apply and changed:
  body=bytearray();offset=2
  for index,record in enumerate(records):
   if record is None:header[index*4:index*4+4]=bytes(4);continue
   size=(len(record)+SECTOR-1)//SECTOR
   if size>255:raise ValueError('Converted chunk exceeds region size limit; output not written')
   header[index*4:index*4+4]=((offset<<8)|size).to_bytes(4,'big');body.extend(record);body.extend(bytes(size*SECTOR-len(record)));offset+=size
  temp=path.with_suffix('.mca.tmp');temp.write_bytes(header+body);temp.replace(path)
 return total

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('world',type=Path);p.add_argument('--apply',action='store_true');p.add_argument('--output',type=Path);a=p.parse_args();world=a.world.resolve()
 if not (world/'level.dat').is_file():p.error('Provide the world folder containing level.dat')
 if (world/'session.lock').exists():
  # The lock file remains after Minecraft exits; its presence does not prove a running server.
  print('Minecraft/server MUST be closed; session.lock may remain after exit.')
 if (world/MARKER).exists():p.error('This world copy has already been converted; refusing a second conversion')
 if a.apply:
  if not a.output:p.error('--apply requires --output NEW_WORLD_FOLDER; original world is never modified')
  dest=a.output.resolve()
  if dest==world or world in dest.parents or dest in world.parents:p.error('Output must be separate from original world')
  if dest.exists():p.error('Output folder already exists; choose a new folder')
  shutil.copytree(world,dest);world=dest
 total={'regions':0,'containers':0,'replaced_item_stacks':0,'kept_context':0,'skipped_chunks':0}
 for path in sorted(world.rglob('r.*.*.mca')):
  if path.parent.name!='region':continue
  c=region(path,a.apply);total['regions']+=1
  for k,v in c.items():total[k]+=v
 if a.apply:
  pack=Path(__file__).resolve().parent/'mosslorn-expanded.1.zip'
  if not pack.exists():raise FileNotFoundError('Place mosslorn-expanded.1.zip beside this script')
  dp=world/'datapacks';dp.mkdir(exist_ok=True);shutil.copyfile(pack,dp/pack.name)
  (world/MARKER).write_text(json.dumps({'completed':True,'time':time.time(),'report':total},indent=2))
 print(json.dumps({'mode':'converted copy' if a.apply else 'read-only preview','world':str(world),'report':total},indent=2))
 if total['skipped_chunks']:print('Some externally stored/LZ4 chunks were skipped; this report is not a complete conversion.')
if __name__=='__main__':main()
