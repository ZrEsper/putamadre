from pathlib import Path
import zipfile,json,hashlib
r=Path(__file__).parent;o=r/'release';base=Path('/workspace/npc75/release/tacznpcs-2.1.0-1.21.1-tactical.39-open-conversations.jar');jar=next(o.glob('*.jar'))
(o/'LEEME.txt').write_text('''TaCZ NPCs .40 — Confianza, regalos, movimiento y encuentros
Minecraft 1.21.1 / NeoForge. Reemplaza .39 en cliente y servidor; no mantengas ambas.

CONFIANZA
Escuchar un tema nuevo de una charla normal suma 2 de confianza, máximo 12 por día
(24000 ticks de juego), por NPC y jugador. Navegar, repetir temas o interrumpir antes
de escuchar no suma. Tras una tregua o confianza >=25 y hostilidad <=45, los antiguos
hostiles pueden usar la conversación abierta si no hay violencia reciente/grave.
Regalos: Estado -> ayuda/apoyo -> regalar desde inventario. Menú paginado de objetos
reales, una unidad por elección, conserva componentes. Comida +3, medicina +6,
munición +4; otros valores editables. Repetir un mismo objeto da valor completo,
luego mitad, después cero; máximo 18 por día. Una agresión reciente impide regalos.
No borra recuerdos negativos. Las ayudas de misiones y donaciones anteriores conservan
sus efectos: estos límites corresponden a los regalos nuevos y temas de charla.

REGISTRAR DURANTE UN ROBO
Con arma en mano, sin apuntar/disparar, inicia intimidación. Si cede (miedo >=50),
aparece revisar la bolsa. Verás nombres y cantidades reales, dos objetos por página;
cada clic toma una unidad. Requiere visión, distancia <=8 bloques y sesión vigente.
Las opciones viejas no sirven; cambios de objetos y falta de espacio cancelan la operación.
El registro es un menú de chat, no una ventana de cofre. Solo expone la bolsa:
no permite quitar el arma equipada ni la armadura por esta vía. El NPC recuerda el robo.

EVENTOS OCASIONALES
NPCs existentes neutrales/pasivos con comida o medicina sobrante pueden acercarse,
por navegación normal, y ofrecer intercambiar una unidad por una de la otra categoría.
No aparecen suministros gratuitos: ambas partes entregan objetos reales.
Por defecto: búsqueda 32 bloques; comprobación escalonada cada 200 ticks, probabilidad
20% al habilitarse, espera de un día por NPC y 10 minutos por jugador; acercamiento
máximo 20 segundos. Una sola visita reservada por jugador. Sin generar NPCs, teletransportar
ni cargar chunks. Se cancela con combate, amenazas, arma, distancia o plazo agotado.
La emboscada de compañeros ocultos mantiene sus dos NPCs reales: corregida su visión
contra jugadores (antes intentaba usar getSensing de criaturas sobre Player).
Los casos antiguos sin_cobertura pueden reintentarse una vez, sin duplicar actores.
No hay una nueva IA para perseguirte fuera de chunks cargados ni sociedades nuevas.

MOVIMIENTO
Cuello limitado a 65 grados respecto al torso y pitch a 45; giros por el camino angular
más corto, cuerpo acompañando al mirar detrás durante conversación. Suavizado visual
sin alterar posiciones/velocidades ni el cálculo de disparo. Se suprime la rutina de
expresión que competía con estos giros y alternaba agacharse durante la charla/visita.
La puntería de combate conserva su orientación nativa en servidor, con límites del cuello.

CONFIGURACIÓN
config/tacznpcs/dialogue-phase2.json: nuevas secciones interaccion, movimiento y eventos.
JSON .39 original migra con copia dialogue-phase2.pre40.bak.json. Los personalizados
conservan su contenido y reciben valores opcionales. /npcreload y /npcvalidate siguen.
/npcdebug muestra también contadores de confianza diaria.

VERIFICACIÓN Y LÍMITES
171 clases verificadas por ASM. Pruebas JVM con APIs simuladas: 277 regresión,
15126 identidad/chat/emboscada, 124 memoria, 2249 conversación abierta y 20368 nuevas
comprobaciones de confianza, regalos, ángulos, registro y visitas; 13 casos de configuración.
NO se ejecutó Minecraft real, NeoForge, GPU, servidor dedicado ni el modpack completo.
Los videos/logs recibidos sí se revisaron; no prueban la nueva .40. Ver PRUEBAS.md.
''')
(o/'PRUEBAS.md').write_text('''Pruebas en Minecraft pendientes: esta tabla indica cómo comprobar la .40 en juego.

| Caso | Cómo probar | Resultado esperado |
|---|---|---|
| Confianza | Preguntar varios temas, repetir uno; /npcdebug | +2 por tema nuevo escuchado, repetición sin premio; límite 12/día |
| Regalos | Ayuda/apoyo -> regalar; dar comida tres veces | Consume objetos reales; +3/+1/+0; máximo 18/día |
| Historia negativa | Agredir e intentar regalar | Rechaza regalar; conserva recuerdo |
| Registro | Intimidar un NPC que ceda, revisar bolsa | Objetos/cantidades reales; una unidad por clic; no duplicación |
| Distancia | Alejarse y usar una opción de registro vieja | Se rechaza, sin pérdida/creación de objetos |
| Giros | Rodear al NPC durante una charla, cruzar su espalda | Cuerpo acompaña; cuello no da vueltas completas; transiciones suaves |
| Visitas | NPC neutral con comida/medicina sobrante y jugador desarmado | Puede acercarse y proponer trueque; no insiste tras rechazar |
| Trueque | Aceptar con el recurso pedido; repetir clic viejo | Intercambio real de una unidad por parte; token viejo inválido |
| Cancelación | Aparece amenaza durante acercamiento | Abandona visita y recupera su IA normal |
| Emboscada | Encuentro familiar herido/compañeros ocultos en terreno con cobertura | Dos compañeros reales; sin error Player.getSensing ni duplicados |
| Persistencia | Guardar y reiniciar mundo | Mantiene identidad, relaciones y contadores del día |
| Config | /npcvalidate y /npcreload | Valida JSON; invalida sesiones, mantiene datos persistentes |

Resultado automatizado: build-output.txt, test-output.txt y config-output.txt incluidos
en fuentes-pruebas.zip. Son pruebas JVM simuladas; no son pruebas de Minecraft.
Limitaciones: registro en chat solo de bolsa, no equipo; intercambios de suministros,
no economía general. Eventos solo dentro de entidades/chunks activos; aleatoriedad no
garantiza una visita inmediata. Sin prueba visual GPU de las animaciones.
''')
(o/'dialogue-phase2.json').write_bytes((r/'data/dialogue-phase2.json').read_bytes())
a=zipfile.ZipFile(base);b=zipfile.ZipFile(jar)
assert all(a.read(n)==b.read(n)for n in a.namelist()if n.startswith('assets/'))
assert not any(n.startswith('net/minecraft/')for n in b.namelist())
manifest={'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'minecraft_run':False,'asm_classes':171,'regression_checks':277,'phase26_checks':15126,'phase3_checks':124,'open_checks':2249,'new_checks':20368,'config_cases':13,'changed':[n for n in a.namelist()if n in b.namelist()and a.read(n)!=b.read(n)],'added':sorted(set(b.namelist())-set(a.namelist()))}
(o/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(o/'CAMBIOS.txt').write_text('Base exacta .39. Clases y datos cambiados en el JAR:\n'+'\n'.join(manifest['changed'])+'\nAñadidos:\n'+'\n'.join(manifest['added'])+'\nFuentes correspondientes en fuentes-pruebas.zip, src/mod/cdv/tnpc/tactical/. Assets intactos.\n')
with zipfile.ZipFile(o/'fuentes-pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for name in ['Patch76.java','Extract70.java','Extract71.java','Extract73.java','build.py','test.py','config_test.py','make_data.py','package.py','build-output.txt','test-output.txt','config-output.txt']:z.write(r/name,name)
 for folder in ['src','testsrc','data','api']:
  for p in sorted((r/folder).rglob('*')):
   if p.is_file() and p.suffix in ['.java','.json']:z.write(p,p.relative_to(r))
 dep=Path('/workspace/npc71/brigadier-source')
 for p in (dep/'src/main/java').rglob('*.java'):z.write(p,'brigadier-source/'+str(p.relative_to(dep)))
 z.write(dep/'LICENSE','brigadier-source/LICENSE')
 z.writestr('REPRODUCIR.txt','Java 21, Python3, ECJ, Gson, ASM/asm-tree/asm-analysis y asm-commons; base .39 exacta. build.py admite NPC_BASE_JAR, NPC_BUILD_TOOLS y NPC_GSON_JAR. Ajustar rutas de test.py/config_test.py para dependencias locales. Brigadier fuente MIT incluido. Ejecutar make_data.py, build.py, test.py y config_test.py. api/ es solo para compilación, no se incorpora al mod. testsrc/ son simulaciones, no Minecraft.')
archive='NPCs-40-Confianza-Regalos-Movimiento-Eventos.zip'
(o/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'for p in sorted(o.iterdir())if p.name not in [archive,'SHA256SUMS.txt']))
with zipfile.ZipFile(o/archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(o.iterdir()):
  if p.name!=archive:z.write(p,p.name)
print('SHA256',manifest['jar_sha256']);print('ZIP_BYTES',(o/archive).stat().st_size)
