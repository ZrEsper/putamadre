package net.minecraft.client;public class Minecraft{static final Minecraft INSTANCE=new Minecraft();public Object level;public static Minecraft getInstance(){return INSTANCE;}}
