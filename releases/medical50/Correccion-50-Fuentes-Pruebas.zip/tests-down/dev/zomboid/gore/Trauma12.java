package dev.zomboid.gore;public class Trauma12{public static void packet(Object s,Object p){}}
