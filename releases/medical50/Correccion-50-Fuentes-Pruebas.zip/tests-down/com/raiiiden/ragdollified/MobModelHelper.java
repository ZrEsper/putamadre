package com.raiiiden.ragdollified;public class MobModelHelper{public enum ModelType{HUMANOID_STANDARD}}
