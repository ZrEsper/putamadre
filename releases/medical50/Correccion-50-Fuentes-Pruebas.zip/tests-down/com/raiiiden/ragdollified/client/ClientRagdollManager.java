package com.raiiiden.ragdollified.client;public class ClientRagdollManager{public static boolean hidden;public static void setEntityHidden(int id,boolean h){hidden=h;}}
