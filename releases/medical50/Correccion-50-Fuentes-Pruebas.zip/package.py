from pathlib import Path
import zipfile,json,hashlib,tomllib,re
r=Path(__file__).parent;out=r/'release';out.mkdir(exist_ok=True)
names={'gore':'zomboid-zombie-gore-1.0.20-neoforge-1.21.1-survivor-loot-depth.34.jar','rag':'ragdollified-1.21.1-1.1.5-live-survivor-impacts.27.jar','npc':'tacznpcs-2.1.0-1.21.1-tactical.33-live-downed.jar','fa':'firstaid-1.21.1-ZOMBOID-v3.6.17-revive-rearm.jar','loot':'zombie-remains-loot-1.6.1-neoforge-1.21.1-loot-recovery.24.jar','petrichor':'petrichor-neoforge-1.21.1-1.4.0-depth-copy.1.jar','compat':'tacz-firstaid-compat-1.0.5-firstaid-3.6.17.jar'}
versions={'gore':'1.0.20.50','rag':'1.1.5-gore20-medical50','npc':'2.1.0-tactical.33-live-downed','fa':'1.3.3+neoforge1.21.1-zomboid-v3.6.17-revive-rearm','loot':'1.6.1-physical-loot24-medical50','petrichor':'1.4.0-depth-copy1','compat':'1.0.5'}
entries=[]
for k,name in names.items():
 p=r/'output'/f'{k}.jar' if k!='compat' else Path('/workspace/medical47/output/tacz-firstaid-compat-1.0.4-firstaid-3.6.16.jar')
 with zipfile.ZipFile(p)as z:data={n:z.read(n)for n in z.namelist()}
 meta=data['META-INF/neoforge.mods.toml'].decode();old=tomllib.loads(meta)['mods'][0]['version'];meta=meta.replace('version="'+old+'"','version="'+versions[k]+'"',1).replace('version = "'+old+'"','version = "'+versions[k]+'"',1)
 if k=='gore':
  meta=meta.replace('Gore .32','Gore .34').replace('[1.1.5-gore13,1.1.6)','[1.1.5-gore20-medical50]');cfg=json.loads(data['zomboid_gore.mixins.json']);cfg['mixins'].append('CorpseTarget49');data['zomboid_gore.mixins.json']=(json.dumps(cfg,indent=2)+'\n').encode()
 if k=='rag':meta=meta.replace('[1.0.20.48,1.0.21)','[1.0.20.50,1.0.21)')
 if k=='npc':meta+='\n[[dependencies.tacznpcs]]\nmodId="zomboid_gore"\ntype="required"\nversionRange="[1.0.20.50,1.0.21)"\nordering="NONE"\nside="BOTH"\n'
 if k=='loot':meta=meta.replace('[1.0.20,1.0.21)','[1.0.20.50,1.0.21)')
 if k=='compat':meta=meta.replace('[1.3.3+neoforge1.21.1-zomboid-v3.6.16-bite-class-fix]','['+versions['fa']+']')
 data['META-INF/neoforge.mods.toml']=meta.encode();parsed=tomllib.loads(meta);assert parsed['mods'][0]['version']==versions[k],(k,parsed['mods'][0]);assert not any(n.startswith(('net/minecraft/','org/lwjgl/'))for n in data)
 for m in parsed.get('mixins',[]):
  cfg=json.loads(data[m['config']]);pkg=cfg.get('package','').replace('.','/')
  for group in ['mixins','client','server']:
   for c in cfg.get(group,[]):assert pkg+'/'+c.replace('.','/')+'.class' in data,(k,c)
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED)as z:
  for n,v in sorted(data.items()):z.writestr(n,v)
 with zipfile.ZipFile(out/name)as z:assert z.testzip()is None;assert len(z.namelist())==len(set(z.namelist()))
 entries.append({'file':name,'mod_id':parsed['mods'][0]['modId'],'version':versions[k],'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()})
manifest={'minecraft':'1.21.1','loader':'NeoForge','runtime_tested':False,'base_repository':'https://github.com/baconwithd/Steph','base_branch':'codex/medical49-armor-entry-643629d8','base_commit':'af11cf3b584927f0eb958bf64043b1f6421d0356','artifacts':entries}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(''.join(e['sha256']+'  mods/'+e['file']+'\n'for e in entries))
for n in ['LEEME.md','test-results.json','spark-analysis.json']:(out/n).write_bytes((r/n).read_bytes())
with zipfile.ZipFile(out/'Correccion-50-Supervivientes-Loot-Petrichor.zip','w',zipfile.ZIP_DEFLATED)as z:
 for e in entries:z.write(out/e['file'],'mods/'+e['file'])
 for n in ['LEEME.md','test-results.json','spark-analysis.json','manifest.json','SHA256SUMS.txt']:z.write(out/n,n)
with zipfile.ZipFile(out/'Correccion-50-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','api','tests-fa','tests-down','tests-scene','tests-geometry']:
  for p in(r/folder).rglob('*'):
   if p.is_file():z.write(p,p.relative_to(r))
 for n in ['build.py','package.py','regressions.py','Patch50.java','TargetMixin50.java','test.py','Contracts50.java','LEEME.md','test-results.json','spark-analysis.json']:z.write(r/n,n)
for name in ['Correccion-50-Supervivientes-Loot-Petrichor.zip','Correccion-50-Fuentes-Pruebas.zip']:print(name,(out/name).stat().st_size,hashlib.sha256((out/name).read_bytes()).hexdigest())
