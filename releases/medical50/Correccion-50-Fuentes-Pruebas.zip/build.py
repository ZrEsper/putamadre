from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');base=Path('/workspace/steph-reference/release49/mods');g=next(base.glob('zomboid*.jar'));rag=next(base.glob('ragdoll*.jar'));fa=Path('/workspace/medical47/output/firstaid-1.21.1-ZOMBOID-v3.6.16-bite-class-fix.jar');npc=Path('/workspace/medical48/release/tacznpcs-2.1.0-1.21.1-tactical.32-corpse-guard.jar');loot=Path('/workspace/putamadre/mods/zombie-remains-loot-1.6.1-neoforge-1.21.1-physical-corpse-loot.23-gore20.jar');pet=Path('/workspace/attachments/1bc6fe70-1663-43b6-b0d4-e331aa846be3/petrichor-neoforge-1.21.1-1.4.0.jar')
for p in ['build/classes','build/api','build/tools','output']:(r/p).mkdir(parents=True,exist_ok=True)
e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(x+'.jar'))for x in ['asm','asm-tree','asm-analysis'])
subprocess.run(e+['-d',str(r/'build/api')]+list(map(str,(r/'api').rglob('*.java'))),check=True)
subprocess.run(e+['-cp',':'.join(map(str,[g,fa,r/'build/api'])),'-d',str(r/'build/classes')]+list(map(str,(r/'src').rglob('*.java'))),check=True)
subprocess.run(e+['-cp',asm,'-d',str(r/'build/tools'),str(r/'Patch50.java'),str(r/'TargetMixin50.java')],check=True)
subprocess.run(['java','-cp',str(r/'build/tools')+':'+asm,'TargetMixin50',str(r/'CorpseTarget49.class')],check=True)
subprocess.run(['java','-cp',str(r/'build/tools')+':'+asm,'Patch50',str(g),str(r/'build/classes'),str(r/'CorpseTarget49.class'),str(r/'output/gore.jar'),str(rag),str(r/'output/rag.jar'),str(npc),str(r/'output/npc.jar'),str(fa),str(r/'output/fa.jar'),str(loot),str(r/'output/loot.jar'),str(pet),str(r/'output/petrichor.jar')],check=True)
