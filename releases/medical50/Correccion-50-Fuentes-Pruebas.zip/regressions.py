from pathlib import Path
import subprocess,shutil,json
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(x+'.jar'))for x in ['asm','asm-tree','asm-analysis']);g=r/'output/gore.jar';ref=Path('/workspace/steph-reference/source49');reports=[]
def run(cmd):
 p=subprocess.run(list(map(str,cmd)),capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();reports.append(p.stdout.strip())
# Run previous published geometry checks against the new production JAR.
out=r/'build/geometry-tests';out.mkdir(exist_ok=True,parents=True)
run(e+['-cp',asm,'-d',r/'build/tools','/workspace/medical49/ExtractCleanup48.java'])
run(['java','-cp',str(r/'build/tools')+':'+asm,'ExtractCleanup48',r/'output/rag.jar',out])
f=list((ref/'src/medical48/tests').rglob('*.java'))+[ref/'src/medical45/tests/dev/zomboid/gore/Render45.java',ref/'src/medical45/tests/net/minecraft/resources/ResourceLocation.java',ref/'src/medical45/tests/net/minecraft/client/renderer/RenderType.java',ref/'src/medical46/tests/net/minecraft/world/phys/Vec3.java']+list((ref/'tests').rglob('*.java'))
p=ref/'src/medical48/tests/dev/zomboid/gore/Check48.java';p.write_text(p.read_text().replace('public float yRot(){return 0;}','public float yRot;'))
run(e+['-cp',g,'-d',out]+f);shutil.copytree(ref/'src/medical48/resources',out,dirs_exist_ok=True)
for name in ['Check48','Check49']:run(['java','-Xverify:all','-cp',str(out)+':'+str(g),'dev.zomboid.gore.'+name])
out=r/'build/medical-tests';cp=':'.join(map(str,[g,r/'output/fa.jar',r/'output/npc.jar']));run(e+['-cp',cp,'-d',out]+list(Path('/workspace/medical45/tests').rglob('*.java')));run(['java','-Xverify:all','-cp',str(out)+':'+cp,'dev.zomboid.gore.Test45'])
out=r/'build/bullet-tests';f=[p for p in(ref/'src/medical46/tests').rglob('*.java')if p.name!='EntityUtil.java']+list((ref/'bullet-tests').rglob('*.java'));run(e+['-cp',g,'-d',out]+f);run(['java','-Xverify:all','-cp',str(out)+':'+str(g),'dev.zomboid.gore.BulletCheck49'])
(r/'regression-results.json').write_text(json.dumps(reports,indent=2)+'\n')
