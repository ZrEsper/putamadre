package com.mojang.blaze3d.pipeline;public class RenderTarget{public int width,height,frameBufferId;public int getDepthTextureId(){return 0;}public void bindWrite(boolean b){}}
