package dev.zomboid.gore;
import java.util.concurrent.*;
/** Cache absence as well as presence; optional loot/render integrations must not resolve classes per frame. */
public final class Types50 {
 static final ConcurrentMap<String,Class<?>> FOUND=new ConcurrentHashMap<>();static final java.util.Set<String> ABSENT=ConcurrentHashMap.newKeySet();
 public static Class<?> type(String name){Class<?> cls=FOUND.get(name);if(cls!=null)return cls;if(ABSENT.contains(name))throw new IllegalStateException(name,new ClassNotFoundException(name));try{cls=Class.forName(name);FOUND.putIfAbsent(name,cls);return cls;}catch(ClassNotFoundException e){ABSENT.add(name);throw new IllegalStateException(name,e);}}
}
