package dev.zomboid.gore;
/** The accepted entry point is resolved before hurt callbacks can move or turn the victim. */
public final class Frozen50 {
 record Entry(Gore.Shot shot,Hit28.Hit hit){}static final ThreadLocal<Entry> CACHE=new ThreadLocal<>();
 public static void clear(){CACHE.remove();}public static void freeze(){Gore.Shot shot=Gore.shots.get();if(shot!=null)CACHE.set(new Entry(shot,Hit49.locate(shot)));}
 public static Hit28.Hit locate(Gore.Shot shot){Entry e=CACHE.get();return e!=null&&e.shot()==shot?e.hit():Hit49.locate(shot);}
}
