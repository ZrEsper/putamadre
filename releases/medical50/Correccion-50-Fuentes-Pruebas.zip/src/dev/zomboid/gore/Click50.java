package dev.zomboid.gore;
public final class Click50 {
 public static Object hitType(Object hit){Object type=R.call(hit,"getType");if(type.toString().equals("ENTITY")){Object e=R.call(hit,"getEntity");if(!R.yes(R.call(e,"isAlive"))||Targets49.transparent(e))return R.get(R.type("net.minecraft.world.phys.HitResult$Type"),"MISS");}return type;}
}
