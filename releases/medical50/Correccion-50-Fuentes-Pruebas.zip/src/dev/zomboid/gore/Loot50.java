package dev.zomboid.gore;
public final class Loot50 {
 public static long lifetime(long configured){if(configured<=0)return configured;long nativeTicks=((Number)R.call(R.type("com.raiiiden.ragdollified.config.RagdollifiedConfig"),"getRagdollLifetime")).longValue();return nativeTicks>0?Math.min(configured,nativeTicks):configured;}
 public static boolean npcDrops(Object event){return Npc29.npc(R.call(event,"getEntity"));}
 public static void expired(Object body,boolean spill){if(!spill||R.yes(R.get(body,"deleting")))return;int id=((Number)R.get(body,"id")).intValue();Object retained=Corpse13.retained(id);if(retained!=null)Remains48.expire(retained);}
}
