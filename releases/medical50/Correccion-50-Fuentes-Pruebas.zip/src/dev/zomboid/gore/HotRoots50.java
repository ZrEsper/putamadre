package dev.zomboid.gore;
import java.util.*;
/** Render-thread memo of positive model roots. Bounded references, no cached misses during model binding. */
public final class HotRoots50 {
 static final Set<Object> ROOTS=Collections.newSetFromMap(new IdentityHashMap<>());static Object owner;
 public static boolean contains(Map<?,?> map,Object part){if(owner!=map){ROOTS.clear();owner=map;}if(ROOTS.contains(part))return true;if(!map.containsKey(part))return false;if(ROOTS.size()>=2048)ROOTS.clear();ROOTS.add(part);return true;}
}
