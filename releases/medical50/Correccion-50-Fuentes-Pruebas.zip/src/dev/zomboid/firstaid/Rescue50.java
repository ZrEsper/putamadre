package dev.zomboid.firstaid;
/** Only bleeding without an attacker is passive. Fire, falls and attacks still interrupt. */
public final class Rescue50 {
 static final ThreadLocal<Boolean> BLEEDING=ThreadLocal.withInitial(()->false);
 public static void bleeding(Object event){boolean old=BLEEDING.get();BLEEDING.set(true);try{R.call(R.type("ichttt.mods.firstaid.fracture.Bleeding"),"nativeBleeding50",event);}finally{if(old)BLEEDING.set(true);else BLEEDING.remove();}}
 public static boolean passive(Object source){if(source==null)return false;if(R.call(source,"getEntity")!=null||R.call(source,"getDirectEntity")!=null)return false;if(BLEEDING.get())return true;String id=String.valueOf(R.call(source,"getMsgId")).toLowerCase(java.util.Locale.ROOT);return id.equals("firstaid.bleeding")||id.equals("bleeding")||id.equals("firstaid:bleeding")||id.equals("firstaid_bleeding");}
}
