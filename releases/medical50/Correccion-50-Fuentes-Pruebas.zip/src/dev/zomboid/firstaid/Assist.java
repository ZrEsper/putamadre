/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.firstaid;

import dev.zomboid.firstaid.ClickRevival;
import dev.zomboid.firstaid.DownedSupport;
import dev.zomboid.firstaid.R;
import dev.zomboid.firstaid.Revival;
import dev.zomboid.firstaid.ReviveFix33;
import java.util.Map;
import java.util.WeakHashMap;

public final class Assist {
    static final Map<Object, Attempt> attempts = new WeakHashMap<Object, Attempt>();
    static Object completing;

    public static Object model(Object object) {
        return R.call(R.type("ichttt.mods.firstaid.common.util.CommonUtils"), "getDamageModel", object);
    }

    static long time(Object object) {
        return ((Number)R.call(R.call(object, "level", new Object[0]), "getGameTime", new Object[0])).longValue();
    }

    static void message(Object object, String string) {
        DownedSupport.message(object, string);
    }

    public static void hearts(Object object) {
        Object object2 = R.call(object, "getAttribute", R.get(R.type("net.minecraft.world.entity.ai.attributes.Attributes"), "MAX_HEALTH"));
        if (object2 == null) {
            return;
        }
        Object object3 = R.call(R.type("net.minecraft.resources.ResourceLocation"), "parse", "firstaid:zomboid_extra_hearts");
        if (R.call(object2, "getModifier", object3) == null) {
            R.call(object2, "addPermanentModifier", R.make("net.minecraft.world.entity.ai.attributes.AttributeModifier", object3, 6.0, R.get(R.type("net.minecraft.world.entity.ai.attributes.AttributeModifier$Operation"), "ADD_VALUE")));
        }
    }

    static Object defib(Object object) {
        return DownedSupport.defib(object);
    }

    public static void self(Object object) {
        Object object2 = Assist.model(object);
        if (object2 == null || !Revival.active(object2) || Assist.defib(object) == null || attempts.containsKey(object)) {
            return;
        }
        attempts.put(object, new Attempt(object, Assist.time(object)));
        ReviveFix33.message(object, "Desfibrilador \u00b7 reanimaci\u00f3n en 8 segundos");
    }

    public static boolean v352OriginalInteract(Object object) {
        Object object2 = R.call(object, "getEntity", new Object[0]);
        Object object3 = R.call(object, "getTarget", new Object[0]);
        if (!R.type("net.minecraft.world.entity.player.Player").isInstance(object3)) {
            return false;
        }
        Object object4 = Assist.model(object3);
        if (object4 == null || !Revival.active(object4)) {
            return false;
        }
        R.call(object, "setCanceled", true);
        if (R.yes(R.call(R.call(object2, "level", new Object[0]), "isClientSide", new Object[0]))) {
            return true;
        }
        if (object2 == object3 || !R.yes(R.call(object2, "isAlive", new Object[0])) || R.yes(R.call(Assist.model(object2), "isUnconscious", new Object[0]))) {
            return true;
        }
        Object[] objectArray = new Object[]{object3};
        Object[] objectArray2 = objectArray;
        if (R.num(R.call(object2, "distanceToSqr", objectArray2)) > 9.0) {
            return true;
        }
        Attempt attempt = attempts.get(object2);
        if (attempt == null || attempt.target() != object3) {
            attempts.put(object2, new Attempt(object3, Assist.time(object2)));
        }
        ReviveFix33.message(object2, "Reanimando \u00b7 8 segundos \u00b7 permanece cerca");
        return true;
    }

    public static void tick(Object object) {
        Attempt attempt;
        Object object2 = R.call(object, "getEntity", new Object[0]);
        if (R.yes(R.call(R.call(object2, "level", new Object[0]), "isClientSide", new Object[0]))) {
            return;
        }
        Object object3 = Assist.model(object2);
        if (object3 != null && R.yes(R.call(object2, "isAlive", new Object[0]))) {
            Revival.clock(object3, object2);
        }
        if ((attempt = attempts.get(object2)) == null) {
            return;
        }
        Object object4 = attempt.target();
        Object object5 = Assist.model(object4);
        if (!R.yes(R.call(object2, "isAlive", new Object[0])) || !R.yes(R.call(object4, "isAlive", new Object[0])) || R.yes(R.call(object4, "isRemoved", new Object[0])) || R.call(object4, "level", new Object[0]) != R.call(object2, "level", new Object[0]) || R.num(R.call(object2, "distanceToSqr", object4)) > 9.0 || object5 == null || !Revival.active(object5) || object2 != object4 && R.yes(R.call(Assist.model(object2), "isUnconscious", new Object[0])) || object2 == object4 && Assist.defib(object2) == null) {
            attempts.remove(object2);
            ReviveFix33.message(object2, "Reanimaci\u00f3n interrumpida");
            return;
        }
        long l = Assist.time(object2) - attempt.start();
        if (l < 0L) {
            attempts.remove(object2);
            return;
        }
        if (l % 10L == 0L) {
            R.call(object2, "swing", R.get(R.type("net.minecraft.world.InteractionHand"), "MAIN_HAND"));
            ReviveFix33.message(object2, "Reanimando [" + "|".repeat((int)Math.min(16L, l / 10L)) + "\u00b7".repeat((int)Math.max(0L, 16L - l / 10L)) + "] " + Math.min(100L, l * 100L / ReviveFix33.duration(object2, object4)) + "%");
        }
        if (l % 40L == 0L) {
            Assist.sound(object2, "revive_work");
        }
        if (l >= ReviveFix33.duration(object2, object4)) {
            attempts.remove(object2);
            if (!ReviveFix33.finishBy(object5, object4, object2)) {
                ReviveFix33.message(object2, "Reanimacion interrumpida");
                return;
            }
            Assist.sound(object4, "revive_complete");
            ReviveFix33.message(object2, "Reanimaci\u00f3n completada \u00b7 necesita curarse");
        }
    }

    public static boolean allowed(Object object) {
        return !Revival.active(object) || completing == object;
    }

    static void finish(Object object, Object object2) {
        ReviveFix33.finish(object, object2);
    }

    public static boolean bleedingGrace(Object object) {
        return Assist.time(object) < ((Number)R.call(R.call(object, "getPersistentData", new Object[0]), "getLong", "FABleedGraceUntil")).longValue();
    }

    public static Boolean damage(Object object, Object object2, float f) {
        Object object3;
        if (f > 0.0f && !Rescue50.passive(object2)) {
            attempts.entrySet().removeIf(entry -> entry.getKey() == object || entry.getValue().target() == object);
        }
        if ((object3 = Assist.model(object)) == null || !Revival.active(object3) || Revival.bypass(object2)) {
            return null;
        }
        Object object4 = R.call(object2, "getEntity", new Object[0]);
        Object object5 = R.call(object2, "getDirectEntity", new Object[0]);
        if (f > 0.0f && (object4 != null || object5 != null)) {
            Object object6 = R.call(object, "getPersistentData", new Object[0]);
            int n = ((Number)R.call(object6, "getInt", "FAFinishHits")).intValue() + 1;
            R.call(object6, "putInt", "FAFinishHits", n);
            attempts.entrySet().removeIf(entry -> entry.getKey() == object || ((Attempt)entry.getValue()).target() == object);
            if (n >= 3) {
                R.set(object3, "criticalConditionActive", false);
                R.call(object3, "clearUnconsciousState", new Object[0]);
                R.call(R.type("ichttt.mods.firstaid.common.util.CommonUtils"), "killPlayerDirectly", object, object2);
            }
        }
        return Boolean.FALSE;
    }

    static void sound(Object object, String string) {
        try {
            Object object2 = R.call(R.type("net.minecraft.resources.ResourceLocation"), "parse", "firstaid:" + string);
            Object object3 = R.call(R.type("net.minecraft.sounds.SoundEvent"), "createVariableRangeEvent", object2);
            R.call(R.call(object, "level", new Object[0]), "playSound", null, R.call(object, "blockPosition", new Object[0]), object3, R.get(R.type("net.minecraft.sounds.SoundSource"), "PLAYERS"), Float.valueOf(0.65f), Float.valueOf(1.0f));
        }
        catch (Exception exception) {
            R.warn("revival sound", exception);
        }
    }

    public static boolean interact(Object object) {
        return ClickRevival.interact(object);
    }

    record Attempt(Object target, long start) {
    }
}

