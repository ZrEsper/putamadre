package com.pockyl.petrichor.client.render;
import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.platform.GlStateManager;
import net.minecraft.client.Minecraft;
/** Scene color and depth use the same depth representation as the active main target. */
public final class SceneCopy {
 private static TextureTarget world;private static long frame,worldFrame=-1;
 private static int depthFormat,depthId=-1;
 public static void newFrame(){frame++;}
 public static TextureTarget world(){if(worldFrame!=frame||world==null){world=copy(world);worldFrame=frame;}return world;}
 static Object gl(int version,String name,Class<?>[] types,Object...args){try{return Class.forName("org.lwjgl.opengl.GL"+version).getMethod(name,types).invoke(null,args);}catch(ReflectiveOperationException e){throw new IllegalStateException(name,e);}}
 static int get(int key){return (Integer)gl(11,"glGetInteger",new Class[]{int.class},key);}
 static int format(int tex){GlStateManager._bindTexture(tex);return(Integer)gl(11,"glGetTexLevelParameteri",new Class[]{int.class,int.class,int.class},3553,0,4099);}
 static int external(int f){return f==35056||f==36013?34041:6402;}
 static int dataType(int f){return f==36013?36269:f==35056?34042:5126;}
 private static TextureTarget copy(TextureTarget target){RenderTarget main=Minecraft.getInstance().getMainRenderTarget();boolean resized=false;
  if(target==null){target=new TextureTarget(main.width,main.height,true,Minecraft.ON_OSX);target.setFilterMode(9729);resized=true;}
  else if(target.width!=main.width||target.height!=main.height){target.resize(main.width,main.height,Minecraft.ON_OSX);target.setFilterMode(9729);resized=true;}
  int texture=get(32873),src=main.getDepthTextureId(),dst=target.getDepthTextureId();
  try{int f=format(src);if(f!=6402&&f!=33189&&f!=33190&&f!=33191&&f!=36012&&f!=35056&&f!=36013)throw new IllegalStateException("Unsupported scene depth format "+f);
   if(resized||dst!=depthId||f!=depthFormat){GlStateManager._bindTexture(dst);gl(11,"glTexImage2D",new Class[]{int.class,int.class,int.class,int.class,int.class,int.class,int.class,int.class,long.class},3553,0,f,main.width,main.height,0,external(f),dataType(f),0L);depthId=dst;depthFormat=f;}
   GlStateManager._glBindFramebuffer(36008,main.frameBufferId);GlStateManager._glBindFramebuffer(36009,target.frameBufferId);
   GlStateManager._glBlitFrameBuffer(0,0,main.width,main.height,0,0,target.width,target.height,16640,9728);
  }finally{GlStateManager._bindTexture(texture);main.bindWrite(false);}return target;
 }
}
