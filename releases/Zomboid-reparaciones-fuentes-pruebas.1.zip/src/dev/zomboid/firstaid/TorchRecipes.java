package dev.zomboid.firstaid;
import java.lang.reflect.Array;
public final class TorchRecipes{public static void join(Object event){Object p=R.call(event,"getEntity");if(!R.type("net.minecraft.server.level.ServerPlayer").isInstance(p))return;Class<?> loc=R.type("net.minecraft.resources.ResourceLocation");Object keys=Array.newInstance(loc,1);Array.set(keys,0,R.call(loc,"parse","firstaid:restored_torches"));R.call(p,"awardRecipesByKey",keys);}}
