package dev.zomboid.firstaid;
import java.util.Locale;
public final class Wash{
 static String id(Object stack){return String.valueOf(R.call(R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ITEM"),"getKey",R.call(stack,"getItem"))).toLowerCase(Locale.ROOT);}
 public static boolean liquid(Object stack){if(stack==null||R.yes(R.call(stack,"isEmpty")))return false;String id=id(stack);if(id.contains("empty")||id.endsWith(":glass_bottle"))return false;if(id.endsWith(":water_bucket"))return true;return String.valueOf(R.call(stack,"getUseAnimation")).equals("DRINK");}
 static Object item(String id){return R.call(R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ITEM"),"get",R.call(R.type("net.minecraft.resources.ResourceLocation"),"parse",id));}
 public static Object use(Object item,Object level,Object player,Object hand){Object cloth=R.call(player,"getItemInHand",hand);if(!R.yes(R.call(R.type("ichttt.mods.firstaid.compat.lrtactical.TreatmentV33"),"dirtyStack",cloth)))return null;
 Object inv=R.call(player,"getInventory"),fluid=null;Object off=R.call(player,"getOffhandItem");if(off!=cloth&&liquid(off))fluid=off;else for(int i=0;i<((Number)R.call(inv,"getContainerSize")).intValue();i++){Object s=R.call(inv,"getItem",i);if(s!=cloth&&liquid(s)){fluid=s;break;}}if(fluid==null)return null;
 boolean client=R.yes(R.call(level,"isClientSide"));if(!client){if(!R.yes(R.call(player,"isCreative"))){Object remaining=R.call(fluid,"getCraftingRemainingItem");if(remaining==null||R.yes(R.call(remaining,"isEmpty"))){String id=id(fluid);String container=id.endsWith(":water_bucket")?"minecraft:bucket":id.contains("bottle")||id.contains("potion")?"minecraft:glass_bottle":null;if(container!=null)remaining=R.make("net.minecraft.world.item.ItemStack",item(container));}R.call(fluid,"shrink",1);if(remaining!=null&&!R.yes(R.call(remaining,"isEmpty"))&&!R.yes(R.call(inv,"add",remaining)))R.call(player,"drop",remaining,false);R.call(cloth,"shrink",1);}
 Object clean=R.make("net.minecraft.world.item.ItemStack",item("firstaid:cloth"));if(!R.yes(R.call(inv,"add",clean)))R.call(player,"drop",clean,false);R.call(inv,"setChanged");R.call(R.get(player,"containerMenu"),"broadcastChanges");R.call(player,"displayClientMessage",R.call(R.type("net.minecraft.network.chat.Component"),"literal","Tela lavada: usa una venda limpia para tratar la infección de la herida."),true);}
 return R.call(R.type("net.minecraft.world.InteractionResultHolder"),"sidedSuccess",cloth,client);
 }
}
