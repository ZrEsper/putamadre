package dev.zomboid.tacz;
public final class CameraSafe{
 private static Object owner,view,vehicle;private static boolean previousIso;
 public static void track(){Object mc=Bridge.mc(),p=R.get(mc,"player"),mode=R.call(R.get(mc,"options"),"getCameraType"),ride=p==null?null:R.call(p,"getVehicle");boolean iso=Bridge.isoActive();if(p!=owner||mode!=view||ride!=vehicle||iso!=previousIso){owner=p;view=mode;vehicle=ride;previousIso=iso;Class<?> c=R.type("com.tacz.guns.client.event.CameraSetupEvent");R.set(c,"shootTimeStamp",-1L);R.set(c,"pitchSplineFunction",null);R.set(c,"yawSplineFunction",null);R.set(c,"xRotO",0d);R.set(c,"yRotO",0d);try{Object plugin=R.call(R.type("mod.chloeprime.thirdpersonshooting.client.TpsSsPlugin"),"getInstance");R.set(plugin,"deltaXRot",0d);R.set(plugin,"deltaYRot",0d);}catch(RuntimeException absent){}}}
 public static boolean animation(){track();return !previousIso&&vehicle==null&&String.valueOf(view).equals("FIRST_PERSON");}
 public static boolean recoil(){track();return !previousIso;}
}
