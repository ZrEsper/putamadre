package dev.zomboid.clans;
import net.minecraft.client.gui.screens.Screen;import net.minecraft.client.gui.GuiGraphics;import net.minecraft.network.chat.Component;
public final class GuideScreen extends Screen{
 static boolean advanced;private int x,y,w,cell;
 static final String[] TITLES={"Mi facción","Territorio","Compañeros","Depósito","Oleadas PvE","Opciones avanzadas"};
 static final String[] NOTES={"Crear, unirse o administrar","Reclamar y proteger tu zona","Revisar y gestionar tu equipo","Retirar los suministros ganados","Elegir dificultad y defender el nexo","Diplomacia, permisos y conflictos"};
 public GuideScreen(){super(Component.literal("Facciones"));}
 static Object mc(){return R.call(R.type("net.minecraft.client.Minecraft"),"getInstance");}
 public static boolean redirect(){if(advanced){advanced=false;return false;}R.call(mc(),"setScreen",new GuideScreen());return true;}
 protected void init(){w=Math.min(520,Math.max(260,width-24));x=(width-w)/2;y=Math.max(4,(height-240)/2);cell=(w-12)/2;R.call(R.type("dev.zomboid.clans.ClanPacket"),"send",0,"","",0);}
 private void text(Object g,String s,int xx,int yy,int c){R.call(g,"drawString",R.get(this,"font"),s,xx,yy,c,false);}
 public void render(GuiGraphics g,int mx,int my,float pt){R.call(g,"fill",0,0,width,height,0xd9141915);text(g,"FACCIONES",x,y,0xffe4ddc9);text(g,"Elige qué quieres hacer",x,y+18,0xffa6b59d);for(int i=0;i<6;i++){int xx=x+(i%2)*(cell+12),yy=y+44+(i/2)*52;boolean hover=mx>=xx&&mx<xx+cell&&my>=yy&&my<yy+44;R.call(g,"fill",xx,yy,xx+cell,yy+44,hover?0xff354834:0xff242e25);text(g,TITLES[i],xx+8,yy+8,0xfff2eddb);String note=NOTES[i];int limit=Math.max(12,(cell-16)/6);if(note.length()>limit){int split=note.lastIndexOf(' ',limit);if(split<1)split=limit;text(g,note.substring(0,split),xx+8,yy+23,0xffb7c5b0);text(g,note.substring(split).trim(),xx+8,yy+34,0xffb7c5b0);}else text(g,note,xx+8,yy+25,0xffb7c5b0);}
 text(g,"PvE: territorio + nexo + dificultad.",x,y+208,0xffa6b59d);text(g,"ESC · cerrar",x,y+224,0xffc9c1ac);}
 public boolean mouseClicked(double mx,double my,int button){if(button!=0)return false;for(int i=0;i<6;i++){int xx=x+(i%2)*(cell+12),yy=y+44+(i/2)*52;if(mx<xx||mx>=xx+cell||my<yy||my>=yy+44)continue;Object screen;if(i==0||i==5){advanced=true;screen=R.make("me.danialisntcool.factionfriction.client.screen.MainFactionScreen");}else{screen=new ClanScreen();R.set(screen,"tab",switch(i){case 1->0;case 2->2;case 3->3;default->4;});}R.call(mc(),"setScreen",screen);return true;}return false;}
 public boolean isPauseScreen(){return false;}
}
