package dev.zomboid.clans;
public final class WaveCapacity{public static int pending(Object raw){Pve.Wave w=(Pve.Wave)raw;return w.alive>=16?0:w.pending;}public static void protect(Object mob){R.call(mob,"setCustomName",R.call(R.type("net.minecraft.network.chat.Component"),"literal","Infectado · oleada PvE"));R.call(mob,"setCustomNameVisible",false);}}
