from pathlib import Path
import json,zipfile,re,copy
p=Path('work/repair-oct14');inputs=json.loads((p/'inputs.json').read_text());out=p/'release';out.mkdir(exist_ok=True)
names={'fa':'firstaid-1.21.1-ZOMBOID-v3.5.4-revival-injury-recovery.jar','lr':'LesRaisins-Tactical-Equipements-1.21.1-0.4.3-zomboid-isometric-melee.3-block-mining.jar','melee':'zomboid-global-melee-animations-2.3.1-range-plus-one-ezweight-v14-block-mining.jar','clans':'factionfriction-1.8.0R-1.21.1-NEOFORGE-zomboid-clans.12-simple-menu-pve-spawns.jar','tacz':'tacz-neoforge-1.21.1-1.1.8-hotfix-r7-third-person-pz.14-camera-state-reset.jar','tp':'tp_shooting-neoforge-1.21.1-tacz1.1.8-ssr5-6.0.1-camera-state-reset.3.jar'}
roots={'fa':['dev/zomboid/firstaid'],'lr':['dev/zomboid/lriso'],'melee':['dev/zomboidmelee/combat'],'clans':['dev/zomboid/clans'],'tacz':['dev/zomboid/tacz'],'tp':[]}
for k,src in inputs.items():
 if k not in names:continue
 changes={str(f.relative_to(p/'patched'/k)):f.read_bytes() for f in (p/'patched'/k).rglob('*.class')} if (p/'patched'/k).exists() else {}
 for prefix in roots[k]:
  for f in (p/'classes'/prefix).rglob('*.class'):changes[str(f.relative_to(p/'classes'))]=f.read_bytes()
 if k=='fa':
  changes['data/firstaid/recipe/restored_torches.json']=json.dumps({'type':'minecraft:crafting_shaped','category':'misc','pattern':['C','S'],'key':{'C':[{'item':'minecraft:coal'},{'item':'minecraft:charcoal'}],'S':{'item':'minecraft:stick'}},'result':{'id':'minecraft:torch','count':4}}).encode()
  changes['data/firstaid/advancement/recipes/restored_torches.json']=json.dumps({'parent':'minecraft:recipes/root','criteria':{'sticks':{'trigger':'minecraft:inventory_changed','conditions':{'items':[{'items':'minecraft:stick'}]}}},'rewards':{'recipes':['firstaid:restored_torches']}}).encode()
 with zipfile.ZipFile(src) as z:
  if k in ['fa','clans']:
   n='META-INF/neoforge.mods.toml'
   if n in z.namelist():
    t=z.read(n).decode();t=t.replace('First Aid · Zomboid v3.4.8 · Humedad y gripe','First Aid · Zomboid v3.5.4 · Reanimación y recuperación');t=t.replace('zomboid-v3.4.8-wetness-no-panic','zomboid-v3.5.4-revival-recovery').replace('zomboid-clans.10','zomboid-clans.12');changes[n]=t.encode()
  dest=out/names[k]
  with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as target:
   for info in z.infolist():
    if info.filename not in changes:target.writestr(copy.copy(info),z.read(info.filename))
   for n,b in changes.items():target.writestr(n,b)
  with zipfile.ZipFile(dest) as fixed:
   assert fixed.testzip() is None
   for n in z.namelist():
    if n not in changes:assert fixed.read(n)==z.read(n),n
  print(k,len(changes),'patched/new entries',dest.stat().st_size)
(p/'outputs.json').write_text(json.dumps(names,indent=2))
