package net.minecraft.client;public class Minecraft{static final Minecraft I=new Minecraft();public Object player,screen,hitResult;public static Minecraft getInstance(){return I;}}
