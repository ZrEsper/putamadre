package me.xjqsh.lrtactical.api.item;public class IMeleeWeapon{public static Object of(Object stack){return Boolean.TRUE.equals(stack)?new Object():null;}}
