package net.minecraft.world;public class InteractionResultHolder{public static Object sidedSuccess(Object stack,boolean client){return new InteractionResultHolder();}}
