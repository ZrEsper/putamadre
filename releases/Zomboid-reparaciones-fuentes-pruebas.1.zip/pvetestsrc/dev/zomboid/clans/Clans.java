package dev.zomboid.clans;public class Clans{public static long now(Object server){return 100;}}
