package net.minecraft.world.effect;public class MobEffectInstance {public Object type;public int duration,amplifier;public MobEffectInstance(Object t,int d,int a){type=t;duration=d;amplifier=a;}}
