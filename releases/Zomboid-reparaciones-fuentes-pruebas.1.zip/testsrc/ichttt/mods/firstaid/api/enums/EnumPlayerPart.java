package ichttt.mods.firstaid.api.enums;public enum EnumPlayerPart{HEAD,BODY,LEFT_ARM,RIGHT_ARM,LEFT_LEG,RIGHT_LEG,LEFT_FOOT,RIGHT_FOOT}
