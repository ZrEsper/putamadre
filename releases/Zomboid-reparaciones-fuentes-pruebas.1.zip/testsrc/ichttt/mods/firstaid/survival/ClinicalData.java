package ichttt.mods.firstaid.survival;public class ClinicalData{public static ClinicalState state(Object m){return ((dev.zomboid.firstaid.RecoveryTest.Model)m).state;}}
