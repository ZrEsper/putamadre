package ichttt.mods.firstaid.common.util;
import net.minecraft.world.entity.player.Player;
public class CommonUtils {public static int syncs;public static Object getDamageModel(Player p){return p.model;}public static void syncDamageModel(Player p){syncs++;}}
