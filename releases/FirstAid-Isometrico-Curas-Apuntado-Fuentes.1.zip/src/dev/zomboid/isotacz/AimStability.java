package dev.zomboid.isotacz;
public final class AimStability {
 public static boolean medical(){try{Object mc=Bridge.mc(),p=R.get(mc,"player");if(!Bridge.active()||p==null||Bridge.gun(p))return false;
  if(!R.yes(R.call(p,"isUsingItem"))&&!Bridge.key(mc,"keyUse"))return false;
  Object stack=R.call(p,"getMainHandItem"),item=R.call(stack,"getItem");String id=String.valueOf(R.call(R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ITEM"),"getKey",item));
  return id.startsWith("firstaid:")||id.contains("bandage")||id.contains("medkit")||id.contains("syringe")||id.contains("splint")||id.equals("minecraft:shears")||id.contains("medical");
 }catch(Throwable t){Bridge.warn("medical camera",t);return false;}}
 public static boolean suppress(Object player){return Bridge.active()&&player==R.get(Bridge.mc(),"player")&&(Bridge.gun(player)||medical());}
 public static Object viewCall(Object player,String ignored,Object... args){return direction(player,((Number)args[0]).floatValue());}
 public static Object direction(Object player,float partial){if(!Bridge.active())return R.call(player,"getViewVector",partial);Object point=CursorAim.point(Bridge.mc());return R.call(R.call(point,"subtract",R.call(player,"getEyePosition")),"normalize");}
}
