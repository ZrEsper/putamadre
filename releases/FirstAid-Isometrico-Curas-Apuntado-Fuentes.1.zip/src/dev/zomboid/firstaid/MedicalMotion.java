package dev.zomboid.firstaid;
import java.util.*;
/** Cosmetic only: never rotates the entity or changes treatment outcomes. */
public final class MedicalMotion {
 private static final Map<Object,int[]> JOBS=Collections.synchronizedMap(new WeakHashMap<>());
 private static final Map<Object,float[]> BLENDS=Collections.synchronizedMap(new WeakHashMap<>());
 private static boolean warned;
 static Object c(Object o,String m,Object...a){return R.call(o,m,a);} static int n(Object o){return ((Number)o).intValue();}
 static void warn(Throwable t){if(!warned){warned=true;System.err.println("[FirstAid] Medical animation unavailable: "+t);}}
 public static void selected(Object part){try {Object mc=c(R.type("net.minecraft.client.Minecraft"),"getInstance");Object p=R.get(mc,"player");if(p!=null)JOBS.put(p,new int[]{((Enum<?>)part).ordinal(),1});}catch(Throwable t){warn(t);}}
 public static void screen(Object gui){try{selected(R.get(gui,"selected"));}catch(Throwable t){warn(t);}}
 public static void tick(Object model,Object player){try {
  if(Boolean.TRUE.equals(c(c(player,"level"),"isClientSide")))return;
  Object s=c(R.type("ichttt.mods.firstaid.survival.ClinicalData"),"state",model);int extraction=n(R.get(s,"extractionPart")),dress=n(R.get(s,"dressingPart"));
  int[] next=extraction>=0?new int[]{extraction,3}:dress>=0?new int[]{dress,1}:new int[]{-1,0};int[] old=JOBS.put(model,next);
  if(!Arrays.equals(old,next))c(model,"scheduleResync");
 }catch(Throwable t){warn(t);}}
 public static void write(Object model,Object tag){int[] j=JOBS.get(model);if(j!=null){c(tag,"putInt","faMotionPart",j[0]);c(tag,"putInt","faMotionKind",j[1]);}}
 public static void read(Object model,Object tag){int kind=n(c(tag,"getInt","faMotionKind")),part=n(c(tag,"getInt","faMotionPart"));JOBS.put(model,new int[]{part,kind});}
 static boolean medical(Object stack){Object item=c(stack,"getItem");String id=String.valueOf(c(R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ITEM"),"getKey",item));
  return R.type("ichttt.mods.firstaid.api.healing.ItemHealing").isInstance(item)||R.type("ichttt.mods.firstaid.api.medicine.ItemMedicine").isInstance(item)||id.startsWith("firstaid:")||id.contains("bandage")||id.contains("medkit")||id.contains("splint")||id.contains("syringe");}
 public static void pose(Object model,Object player,float age){try{
  if(!R.type("net.minecraft.world.entity.player.Player").isInstance(player))return;
  Object damage=Assist.model(player);if(damage==null||Revival.active(damage))return;
  boolean use=Boolean.TRUE.equals(c(player,"isUsingItem"));Object stack=c(player,"getUseItem");int part=4,kind=0;int[] j=JOBS.get(damage);
  if(use&&j!=null&&j[1]>0){part=j[0];kind=j[1];}
  if(use&&medical(stack)){
   if(kind==0)kind=1;int[] chosen=JOBS.get(player);if(chosen!=null)part=chosen[0];
   String id=String.valueOf(c(R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ITEM"),"getKey",c(stack,"getItem")));
   if(id.contains("splint")){part=Boolean.TRUE.equals(c(R.type("ichttt.mods.firstaid.fracture.Fractures"),"isBroken",player,true))?2:6;kind=2;}
   else if(id.contains("inject")||id.contains("syringe")){part=1;kind=4;}
   else if(R.type("ichttt.mods.firstaid.api.medicine.ItemMedicine").isInstance(c(stack,"getItem"))){part=0;kind=5;}
  }
  // Client-selected clinical extraction uses vanilla shears, not a medical item class.
  Object mc=c(R.type("net.minecraft.client.Minecraft"),"getInstance");
  if(player==R.get(mc,"player")&&use){Class<?> t=R.type("ichttt.mods.firstaid.compat.lrtactical.TreatmentV33");int mode=n(R.get(t,"autoMode"));if(R.get(t,"autoPlayer")==player&&mode>0){kind=mode==3?3:1;int[] chosen=JOBS.get(player);if(chosen!=null)part=chosen[0];}}
  float[] blend=BLENDS.computeIfAbsent(player,k->new float[]{0,age,4,1});float dt=Math.max(0,Math.min(2,age-blend[1]));blend[1]=age;
  blend[0]=Math.max(0,Math.min(1,blend[0]+(kind>0?1:-1)*dt/4));if(kind>0){blend[2]=part;blend[3]=kind;}if(blend[0]<=0)return;
  float[] pose=angles((int)blend[2],(int)blend[3],age);String[] names={"rightArm","leftArm","body","head"};
  for(int i=0;i<4;i++){Object b=R.get(model,names[i]);for(int axis=0;axis<3;axis++){String f=new String[]{"xRot","yRot","zRot"}[axis];float old=((Number)R.get(b,f)).floatValue();R.set(b,f,old+(pose[i*3+axis]-old)*blend[0]);}}
  for(String[] pair:new String[][]{{"rightSleeve","rightArm"},{"leftSleeve","leftArm"},{"jacket","body"},{"hat","head"}})c(R.get(model,pair[0]),"copyFrom",R.get(model,pair[1]));
 }catch(Throwable t){warn(t);}}
 public static float[] angles(int part,int kind,float age){
  float pulse=(float)Math.sin(age*(kind==3?.8:.35));float movement=kind==2?.07f:kind==3?.12f:.18f;
  float rx=-1.05f+movement*pulse,lx=-1.05f-movement*pulse,ry=-.45f,ly=.45f,bx=0,hx=.3f,rz=.1f,lz=-.1f;
  if(part==0){rx=-2.1f+movement*pulse;lx=-2.1f-movement*pulse;ry=-.3f;ly=.3f;hx=.1f;}
  else if(part==1){rx=-1.2f+movement*pulse;ry=-1.0f;lx=-.7f;ly=.1f;}
  else if(part==5){lx=-1.2f+movement*pulse;ly=1.0f;rx=-.7f;ry=-.1f;}
  else if(part==2||part==3||part==6||part==7){bx=part==3||part==7?.85f:.6f;hx=.6f;rx=-.15f+movement*pulse;lx=-.15f-movement*pulse;ry=part<4?-.3f:.05f;ly=part<4?-.05f:.3f;}
  if(kind==4){rx=-1.2f;ry=-1;lx=-.6f;}
  return new float[]{rx,ry,rz,lx,ly,lz,bx,0,0,hx,0,0};
 }
}
