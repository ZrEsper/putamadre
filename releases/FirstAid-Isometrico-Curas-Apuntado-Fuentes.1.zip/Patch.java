import java.nio.file.*;import java.util.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public class Patch implements Opcodes {
 static String H="dev/zomboid/firstaid/MedicalMotion",A="dev/zomboid/isotacz/AimStability";
 static InsnList call(String owner,String name,String desc,int...locals){InsnList l=new InsnList();for(int i:locals)l.add(new VarInsnNode(ALOAD,i));l.add(new MethodInsnNode(INVOKESTATIC,owner,name,desc,false));return l;}
 static void replace(MethodNode m,InsnList l,int ret){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(l);m.instructions.add(new InsnNode(ret));}
 public static void main(String[] args)throws Exception {try(ZipFile z=new ZipFile(args[0])){String path=args[1];ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(path))).accept(c,0);int edits=0;
 for(MethodNode m:c.methods){
  if(path.endsWith("ClinicalHooks.class")&&m.name.equals("tick")){m.instructions.insert(call(H,"tick","(Ljava/lang/Object;Ljava/lang/Object;)V",0,1));edits++;}
  if(path.endsWith("ClinicalData.class")&&(m.name.equals("write")||m.name.equals("read"))){for(AbstractInsnNode i:m.instructions.toArray())if(i.getOpcode()==(m.name.equals("read")?RETURN:ARETURN)){m.instructions.insertBefore(i,call(H,m.name,"(Ljava/lang/Object;Ljava/lang/Object;)V",0,1));edits++;}}
  if(path.endsWith("TreatmentV33.class")&&(m.name.equals("autoSelected")||m.name.equals("clientBegin"))){for(AbstractInsnNode i:m.instructions.toArray())if(i.getOpcode()==RETURN){m.instructions.insertBefore(i,call(H,m.name.equals("autoSelected")?"selected":"screen","(Ljava/lang/Object;)V",0));edits++;}}
  if(path.endsWith("Bridge.class")&&m.name.equals("suppressNativeLook")){replace(m,call(A,"suppress","(Ljava/lang/Object;)Z",0),IRETURN);edits++;}
  if(path.endsWith("Bridge.class")&&m.name.equals("finishCamera")){InsnList l=new InsnList();l.add(new MethodInsnNode(INVOKESTATIC,A,"medical","()Z",false));LabelNode go=new LabelNode();l.add(new JumpInsnNode(IFEQ,go));l.add(new InsnNode(LCONST_0));l.add(new FieldInsnNode(PUTSTATIC,c.name,"edgeFrame","J"));l.add(new InsnNode(RETURN));l.add(go);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(l);edits++;}
  if(path.endsWith("Bridge.class")&&m.name.equals("render")){for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode n&&n.owner.equals("dev/zomboid/isotacz/R")&&n.name.equals("call")){
    // The reflective view-vector call is built with one Float argument. Match its string constant.
    AbstractInsnNode p=i;boolean found=false;for(int k=0;k<15&&p!=null;k++,p=p.getPrevious())if(p instanceof LdcInsnNode s&&"getViewVector".equals(s.cst)){found=true;break;}
    if(found){n.owner=A;n.name="viewCall";edits++;}
  }}
 }
 if(path.endsWith("PlayerModelMixin.class")){
  MethodNode m=new MethodNode(ACC_PRIVATE,"firstaid$medicalPose","(Lnet/minecraft/world/entity/LivingEntity;FFFFFLorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;)V",null,null);
  AnnotationNode an=new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/Inject;");AnnotationNode at=new AnnotationNode("Lorg/spongepowered/asm/mixin/injection/At;");at.values=new ArrayList<>(List.of("value","TAIL"));an.values=new ArrayList<>(List.of("method",new ArrayList<>(List.of("setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V")),"at",new ArrayList<>(List.of(at))));m.visibleAnnotations=new ArrayList<>(List.of(an));
  m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(new VarInsnNode(FLOAD,4));m.instructions.add(new MethodInsnNode(INVOKESTATIC,H,"pose","(Ljava/lang/Object;Ljava/lang/Object;F)V",false));m.instructions.add(new InsnNode(RETURN));c.methods.add(m);edits++;
 }
 if(edits==0)throw new IllegalStateException(path);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path out=Path.of(args[2],path);Files.createDirectories(out.getParent());Files.write(out,w.toByteArray());System.out.println(path+": "+edits);
 }}
}
