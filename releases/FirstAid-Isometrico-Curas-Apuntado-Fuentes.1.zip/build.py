from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import copy,hashlib,json,subprocess
root=Path('work/medical363');out=root/'release';out.mkdir(exist_ok=True)
jobs=[(next(Path('attachments/fe122d10-f2ef-4c09-b6ac-b489c51448fd').glob('*.jar')),'firstaid-1.21.1-ZOMBOID-v3.6.3-treatment-animations.jar',['ichttt/','dev/zomboid/firstaid/'],'v3.6.1','v3.6.3'),(next(Path('attachments/700298ae-39dc-4a97-b131-16a846488986').glob('*.jar')),'dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.28-medical-cursor-stability.jar',['dev/zomboid/isotacz/'],'zomboid.27','zomboid.28')]
for source,name,prefixes,old,new in jobs:
 changes={}
 for directory in ['classes','patched']:
  for p in (root/directory).rglob('*.class'):
   rel=p.relative_to(root/directory).as_posix()
   if any(rel.startswith(pre) for pre in prefixes):changes[rel]=p.read_bytes()
 with ZipFile(source) as src:
  meta='META-INF/neoforge.mods.toml';changes[meta]=src.read(meta).decode().replace(old,new).encode()
  with ZipFile(out/name,'w',ZIP_DEFLATED) as dst:
   for info in src.infolist():dst.writestr(copy.copy(info),changes.pop(info.filename,src.read(info)))
   for path,data in changes.items():dst.writestr(path,data)
 with ZipFile(source) as src,ZipFile(out/name) as dst:
  assert dst.testzip() is None
  changed=[n for n in dst.namelist() if n not in src.namelist() or dst.read(n)!=src.read(n)]
  assert all(n==meta or any(n.startswith(pre) for pre in prefixes) for n in changed)
  print(name,len(changed),'changed entries; all other original entries preserved')
(out/'LEEME.txt').write_text('''First Aid 3.6.3 + Isométrico 28 — tratamiento y apuntado

Sustituir SOLO First Aid 3.6.2 e Isométrico 27 por estos dos JAR. No mantener duplicados.
Instalar First Aid en servidor y clientes. Instalar el isométrico en clientes.
Se conserva el balance balístico y de armadura del First Aid 3.6.2 adjuntado.

Animaciones: vendaje/curación, férula, extracción, inyección y medicamentos.
La parte seleccionada determina cabeza, torso, brazo o pierna; pies tienen mayor inclinación.
Entrada/salida gradual. Solo se modifica el modelo visual, no la rotación del jugador,
los objetos consumidos, la duración ni el resultado del tratamiento.
Las tareas clínicas de vendaje/extracción se sincronizan con los observadores mediante
el canal existente de First Aid. La selección previa de curación normal es local;
un observador puede ver el gesto genérico hasta que exista una tarea clínica sincronizada.

Cámara: bloquea el autoapuntado y giro por borde durante el uso de curas.
La búsqueda de bloques bajo el cursor comienza a altura del tirador, descartando
techo/marco alto del lado de la cámara. Los seres vivos elevados siguen siendo objetivos.
Los proyectiles no se seleccionan como enemigos. La guía isométrica usa el objetivo
del cursor, independiente del retroceso; el impacto real continúa sujeto a paredes y arma.
Este corte de altura limita apuntar directamente a bloques por encima de la cabeza.

Verificado: integridad ZIP, conservación de archivos ajenos al cambio, bytecode,
8.000 combinaciones de posturas y pruebas aisladas de selección/oclusión.
NO probado en un cliente Minecraft con el modpack completo. Probar curas en cada parte,
cancelación, cambio de objeto, disparos en puertas y objetivos elevados antes de desplegar.
''')
(out/'SHA256.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name for p in sorted(out.glob('*.jar')))+'\n')
bundle=root/'FirstAid-Isometrico-Curas-Apuntado.1.zip'
with ZipFile(bundle,'w',ZIP_DEFLATED) as z:
 for p in out.iterdir():z.write(p,p.name)
sources=root/'FirstAid-Isometrico-Curas-Apuntado-Fuentes.1.zip'
with ZipFile(sources,'w',ZIP_DEFLATED) as z:
 for folder in ['src','cursortestsrc']:
  for p in (root/folder).rglob('*.java'):z.write(p,p.relative_to(root))
 for name in ['Patch.java','MotionTest.java','build.py']:z.write(root/name,name)
files=[]
for p in [bundle,sources]:
 b=p.read_bytes();files.append(dict(local=str(p),path='releases/'+p.name,sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
(root/'upload.json').write_text(json.dumps(files))
parent=subprocess.check_output(['git','--git-dir=work/tzp-fix/publish.git','rev-parse','FETCH_HEAD']).decode().strip()
s=Path('work/horror39/publish.py').read_text().replace('work/horror39','work/medical363').replace('3bb2982497ab2de5ad7665f3ec86b28995051b3d',parent).replace('codex/horror39','codex/medical363').replace('Add configurable reliable breaching, Screamer, area vomit and bile, and head8 torso15 ballistic protection','Add medical treatment poses and stabilize isometric medical use and cursor targeting')
(root/'publish.py').write_text(s)
