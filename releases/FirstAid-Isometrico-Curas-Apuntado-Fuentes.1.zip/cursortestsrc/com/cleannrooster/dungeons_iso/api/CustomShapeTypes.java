package com.cleannrooster.dungeons_iso.api;public class CustomShapeTypes{public static final Object CULLED=new Object();}
