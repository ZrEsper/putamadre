package com.cleannrooster.dungeons_iso.api;public class RaycastContextCull{public RaycastContextCull(Object a,Object b,Object c,Object d,Object e,Object f){}}
