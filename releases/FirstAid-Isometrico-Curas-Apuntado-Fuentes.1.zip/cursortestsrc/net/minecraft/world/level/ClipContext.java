package net.minecraft.world.level;public class ClipContext{public enum Block{OUTLINE}public enum Fluid{NONE}}
