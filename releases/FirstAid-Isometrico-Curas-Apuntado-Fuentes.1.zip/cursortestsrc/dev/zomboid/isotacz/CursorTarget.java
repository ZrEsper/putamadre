package dev.zomboid.isotacz;public class CursorTarget{static Object[] ray(Object mc){return new Object[]{new CursorTest.V(0,10,0),new CursorTest.V(0,-10,20)};}}
