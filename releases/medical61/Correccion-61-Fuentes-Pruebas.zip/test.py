from pathlib import Path
import subprocess,json
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');old=Path('/workspace/light60/release/flashlight-5.1-neoforge-1.21.1-player-priority-depth-recovery.26.jar');new=r/'output/flash.jar';mts=Path('/workspace/light59/output/mts.jar');e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];reports=[]
for folder,main in [('slots','SlotsTest60'),('copy','CopyTest60')]:
 out=r/'build'/folder;out.mkdir(exist_ok=True);subprocess.run(e+['-cp',str(new)+':'+str(mts),'-d',str(out)]+list(map(str,(r/'tests'/folder).rglob('*.java'))),check=True)
 for label,jar,args in ([('old',old,['old']),('new',new,[])] if folder=='slots' else [('new',new,[])]):
  p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(jar)+':'+str(mts),'net.flashlight.battery.'+main]+args,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();reports.append({'case':folder+'-'+label,'result':p.stdout.strip()})
(r/'test-results.json').write_text(json.dumps({'minecraft_runtime_tested':False,'results':reports,'limits':'Production helpers with simulated world, lamp states, GL texture storage and clock. Actual MTS geometry classes for vehicle registration; no complete modpack/camera validation.'},indent=2)+'\n')
