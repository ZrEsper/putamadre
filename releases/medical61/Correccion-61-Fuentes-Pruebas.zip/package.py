from pathlib import Path
import zipfile,json,hashlib,subprocess,tomllib
r=Path(__file__).parent;out=r/'release';out.mkdir(exist_ok=True);name='flashlight-5.1-neoforge-1.21.1-surface-depth-vehicle-npc.27.jar'
with zipfile.ZipFile(r/'output/flash.jar') as z:data={n:z.read(n) for n in z.namelist()}
meta=data['META-INF/neoforge.mods.toml'].decode().replace('version="5.1.26"','version="5.1.27"');data['META-INF/neoforge.mods.toml']=meta.encode();assert tomllib.loads(meta)['mods'][0]['version']=='5.1.27';assert not any(n.startswith(('net/minecraft/','org/joml/','tests/')) for n in data)
with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in sorted(data.items()):z.writestr(n,b)
with zipfile.ZipFile(out/name) as z:assert z.testzip() is None;assert z.read('assets/flashlight/shaders/portable6.frag')==(r/'portable6.frag').read_bytes()
checks=[]
for script,args in [('stripes_gpu_test.py',['/workspace/light58/ref56/portable6.frag']),('stripes_gpu_test.py',[str(r/'portable6.frag')]),('render_test.py',[]),('three_gpu_test.py',[]),('depth_gpu_test.py',[])]:
 p=subprocess.run(['python',str(r/script)]+args,capture_output=True,text=True);p.check_returncode();print(p.stdout);checks.append({'test':script,'input':args,'result':p.stdout.strip()})
results=json.loads((r/'test-results.json').read_text());assert any('BUDGET=23' in c['result'] for c in results['results']);results['real_opengl_tests']=checks;results['verified_class_count']=66;results['engine_patches']={'buffer_capacity':1728,'atlas_width':12,'atlas_height':36,'upload_lamp_limit':3};(out/'test-results.json').write_text(json.dumps(results,indent=2)+'\n')
base=Path('/workspace/light60/release/flashlight-5.1-neoforge-1.21.1-player-priority-depth-recovery.26.jar');sha=hashlib.sha256((out/name).read_bytes()).hexdigest();(out/'manifest.json').write_text(json.dumps({'base_commit':'f2fb69b9e8a7929fe8c6eeebfc44cd934ac82950','minecraft':'1.21.1','loader':'NeoForge','minecraft_runtime_tested':False,'file':name,'version':'5.1.27','sha256':sha,'input_sha256':hashlib.sha256(base.read_bytes()).hexdigest()},indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(sha+'  mods/'+name+'\n');(out/'LEEME.md').write_bytes((r/'LEEME.md').read_bytes())
with zipfile.ZipFile(out/'Correccion-61-Linterna-Coches-NPCs.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(out/name,'mods/'+name)
 for n in ['LEEME.md','test-results.json','manifest.json','SHA256SUMS.txt']:z.write(out/n,n)
with zipfile.ZipFile(out/'Correccion-61-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['src','tests']:
  for p in(r/folder).rglob('*.java'):z.write(p,p.relative_to(r))
 for n in ['Patch61.java','build.py','test.py','shader_test.py','stripes_gpu_test.py','render_test.py','three_gpu_test.py','portable6.frag','depth_gpu_test.py','package.py','LEEME.md']:z.write(r/n,n)
 for n in ['test-results.json','manifest.json']:z.write(out/n,n)
print('PACKAGE_READY',name,sha)
