from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');f=Path('/workspace/light60/release/flashlight-5.1-neoforge-1.21.1-player-priority-depth-recovery.26.jar');e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis'])
for p in ['build/classes','build/tools','output']:(r/p).mkdir(parents=True,exist_ok=True)
subprocess.run(e+['-cp',str(f),'-d',str(r/'build/classes')]+list(map(str,(r/'src').rglob('*.java'))),check=True);subprocess.run(e+['-cp',asm,'-d',str(r/'build/tools'),str(r/'Patch61.java')],check=True);subprocess.run(['java','-cp',str(r/'build/tools')+':'+asm,'Patch61',str(f),str(r/'build/classes'),str(r/'output/flash.jar'),str(r/'portable6.frag')],check=True)
