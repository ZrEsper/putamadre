package dev.zomboid.isotacz;
/** Keep native consumption input, but retain isometric locomotion and cursor-facing. */
public final class ConsumableFree36 {
 private static Object cachedPlayer,cachedLevel;private static long nextUpdate;
 public static double plane(double y0,double y1,double y){double d=y1-y0;if(!Double.isFinite(d)||Math.abs(d)<1e-7)return -1;double t=(y-y0)/d;return Double.isFinite(t)&&t>=0&&t<=1?t:-1;}
 public static boolean held(){
  Object mc=Bridge.mc(),p=R.get(mc,"player");
  if(!Bridge.active()||p==null)return false;
  if(MedicalInput30.held())return true;
  if(!Bridge.gun(p)&&NativeActions.food(mc))return true;
  if(R.yes(R.call(p,"isUsingItem"))){Object stack=R.call(p,"getUseItem");String a=String.valueOf(R.call(stack,"getUseAnimation"));return a.equals("EAT")||a.equals("DRINK");}
  return false;
 }
 public static double wrap(double a){return ((a+180)%360+360)%360-180;}
 public static double yaw(double dx,double dz){return Math.toDegrees(Math.atan2(-dx,dz));}
 public static void aim(){
  try{
   Object mc=Bridge.mc(),p=R.get(mc,"player");
   if(!Bridge.active()||p==null||R.get(mc,"level")==null||R.get(mc,"screen")!=null||NativeActions.riding()||!held()||Bridge.gun(p))return;
   Object level=R.get(mc,"level");long now=System.nanoTime();if(p==cachedPlayer&&level==cachedLevel&&now<nextUpdate)return;cachedPlayer=p;cachedLevel=level;nextUpdate=now+45_000_000L;
   Object eye=R.call(p,"getEyePosition");Object[] ray=CursorTarget.ray(mc);Object start=ray[0],end=ray[1];double t=plane(R.num(R.get(start,"y")),R.num(R.get(end,"y")),R.num(R.get(eye,"y"))-.8);
   if(t<0)return;
   double dx=R.num(R.get(start,"x"))+(R.num(R.get(end,"x"))-R.num(R.get(start,"x")))*t-R.num(R.get(eye,"x"));
   double dz=R.num(R.get(start,"z"))+(R.num(R.get(end,"z"))-R.num(R.get(start,"z")))*t-R.num(R.get(eye,"z"));
   if(!Double.isFinite(dx)||!Double.isFinite(dz)||dx*dx+dz*dz<.04)return;
   float y=(float)yaw(dx,dz);
   // Keep previous rotations equivalent across +/-180 so interpolation cannot spin a full turn.
   for(String field:new String[]{"yRotO","yHeadRotO","yBodyRotO"}){double previous=R.num(R.get(p,field));R.set(p,field,(float)(y+wrap(previous-y)));}
   R.call(p,"setYRot",y);R.call(p,"setYHeadRot",y);R.set(p,"yBodyRot",y);
   R.set(Bridge.mod(),"livingYaw",y);R.set(Bridge.mod(),"livingHeadYaw",y);R.set(Bridge.mod(),"livingBodyYaw",y);
   // Do not steer pitch/camera or change speed, use progress, item state or use keys.
  }catch(Throwable t){Bridge.warn("consumable free movement",t);}
 }
}
