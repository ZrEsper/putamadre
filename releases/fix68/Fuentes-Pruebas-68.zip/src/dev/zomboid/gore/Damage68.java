package dev.zomboid.gore;
/** Keep impact context without capping damage to a fraction of remaining health. */
public final class Damage68 {
 public static void incoming(Object event){
  Ballistics11.ZONE.remove();Ballistics11.SOURCE.remove();
  Object entity=R.call(event,"getEntity");
  if(Gore.zombie(entity))Ballistics11.SOURCE.set(R.call(event,"getSource"));
  Gore.Shot shot=Gore.shots.get();
  if(shot==null||shot.entity()!=entity||shot.bullet()==null||!Gore.zombie(entity))return;
  double damage=R.num(R.call(event,"getAmount"));if(!(damage>0))return;
  Ballistics11.ZONE.set(Ballistics11.zone(shot));Ballistics11.SOURCE.set(R.call(event,"getSource"));
 }
}
