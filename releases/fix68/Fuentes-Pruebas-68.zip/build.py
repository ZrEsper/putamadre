from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis'])
g='/workspace/attachments/87171c79-cb03-4ba2-8741-4ed557fd8cd1/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-weapon-power.42.jar';i='/workspace/iso36/release/dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.36-consumable-free-movement.jar'
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'Patch68.java')],check=True)
for kind,base,pkg,out in [('gore',g,'gore','zomboid-zombie-gore-1.0.20-neoforge-1.21.1-direct-lethal-damage.43.jar'),('iso',i,'isotacz','dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.37-lightweight-food-turn.jar')]:
 subprocess.run(ecj+['-cp',base,'-d',str(r/'build'/kind)]+list(map(str,(r/'src/dev/zomboid'/pkg).glob('*.java'))),check=True)
 subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'Patch68',kind,base,str(r/'build'/kind),str(r/'release'/out)],check=True)
