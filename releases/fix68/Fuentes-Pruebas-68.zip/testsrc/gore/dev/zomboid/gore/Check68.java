package dev.zomboid.gore;import net.minecraft.world.entity.monster.Zombie;
public class Check68{
 public static class Event {public Object entity;public float amount;public Object source=new Object();public int writes;public Event(Object e,float a){entity=e;amount=a;}public Object getEntity(){return entity;}public Object getSource(){return source;}public float getAmount(){return amount;}public void setAmount(float f){amount=f;writes++;}}
 public static void main(String[]a){int count=0;boolean old=Boolean.getBoolean("baseline");
 for(boolean head:new boolean[]{false,true})for(float health:new float[]{40,20,1,.01f})for(float damage:new float[]{1,10,40,100}){
 Zombie z=new Zombie();z.health=health;Object bullet=new Object();Gore.shots.set(new Gore.Shot(bullet,z,new Object(),head,Rules.Weapon.OTHER));Event e=new Event(z,damage);Ballistics11.incoming(e);
 if(old){if(!(e.amount<health))throw new Error("expected remaining-health cap");}else{if(e.amount!=damage||e.writes!=0||Ballistics11.SOURCE.get()!=e.source||Ballistics11.ZONE.get()!=(head?0:4))throw new Error("native damage/context");if(damage>=health&&Math.max(0,health-e.amount)!=0)throw new Error("lethal hit delayed");}count++;}
 Gore.shots.remove();Event e=new Event(new Zombie(),10);Ballistics11.incoming(e);if(e.amount!=10||Ballistics11.ZONE.get()!=null)throw new Error();count++;
 System.out.println((old?"BASELINE reproduced fractional cap: ":"PASS native/lethal damage preserved: ")+count+" cases; mocked incoming event, not Minecraft.");
 }
}
