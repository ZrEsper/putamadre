package dev.zomboid.gore;public class Cuts24{public static int zone(Gore.Shot s){return s.head()?0:4;}}
