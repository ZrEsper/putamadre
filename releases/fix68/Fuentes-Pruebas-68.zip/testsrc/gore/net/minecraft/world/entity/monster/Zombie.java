package net.minecraft.world.entity.monster;public class Zombie{public float health=20;public float getHealth(){return health;}}
