from pathlib import Path
import subprocess
r=Path(__file__).parent;ecj=['java','-jar','/workspace/putamadre/hordes-melee-interiors-patch/build/tools/ecj.jar','-21','-proc:none','-nowarn'];base='/workspace/attachments/87171c79-cb03-4ba2-8741-4ed557fd8cd1/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-weapon-power.42.jar'
for kind,name,main in [('gore','zomboid-zombie-gore-1.0.20-neoforge-1.21.1-direct-lethal-damage.43.jar','dev.zomboid.gore.Check68'),('iso','dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.37-lightweight-food-turn.jar','dev.zomboid.isotacz.Fixture')]:
 jar=r/'release'/name;subprocess.run(ecj+['-cp',str(jar),'-d',str(r/'tests'/kind)]+list(map(str,(r/'testsrc'/kind).rglob('*.java'))),check=True)
 if kind=='gore':subprocess.run(['java','-Xverify:all','-Dbaseline=true','-cp',str(r/'tests'/kind)+':'+base,main],check=True)
 subprocess.run(['java','-Xverify:all','-cp',str(r/'tests'/kind)+':'+str(jar),main],check=True)
