from pathlib import Path
import subprocess
r=Path(__file__).parent;j=next((r/'release').glob('*.jar'));cp=str(j)+':/workspace/npc79/tests:/workspace/npc85/api-build:/workspace/medical63/gson.jar';ecj=['java','-jar','/workspace/putamadre/hordes-melee-interiors-patch/build/tools/ecj.jar','-21','-nowarn','-proc:none'];subprocess.run(ecj+['-cp',cp,'-d',str(r/'checks')]+[str(p)for p in (r/'checksrc').rglob('*.java')],check=True);t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');asm=str(t/'asm.jar')+':'+str(t/'asm-tree.jar');subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'ExtractPhysics87.java')],check=True);subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'ExtractPhysics87',str(j),str(r/'checks')],check=True);cp=str(r/'checks')+':/workspace/npc79/tests:'+str(j)+':/workspace/npc85/api-build:/workspace/medical63/gson.jar';x=subprocess.run(['java','-Xverify:all','-cp',cp,'mod.cdv.tnpc.tactical.CheckCommunity87'],capture_output=True,text=True,cwd=r);(r/'test-output.txt').write_text(x.stdout+x.stderr);print(x.stdout+x.stderr);
if x.returncode:raise SystemExit(x.returncode)

subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'ExtractDispatch88.java')],check=True)
subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'ExtractDispatch88',str(j),str(r/'checks')],check=True)
for cls in ['CheckSchedule88','CheckDispatch88','CheckUtilities89']:
 x=subprocess.run(['java','-Xverify:all','-cp',cp,'mod.cdv.tnpc.tactical.'+cls],capture_output=True,text=True,cwd=r)
 with (r/'test-output.txt').open('a') as out:out.write(x.stdout+x.stderr)
 print(x.stdout+x.stderr)
 if x.returncode:raise SystemExit(x.returncode)
