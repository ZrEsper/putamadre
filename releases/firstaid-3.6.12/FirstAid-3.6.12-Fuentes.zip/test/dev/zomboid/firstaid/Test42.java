package dev.zomboid.firstaid;
import java.util.*;
import ichttt.mods.firstaid.survival.ClinicalState.Wound;
public class Test42{
 public static class Graphics{List<int[]> calls=new ArrayList<>();public void fill(int x,int y,int xx,int yy,int color){calls.add(new int[]{x,y,xx,yy,color});}}
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 public static void main(String[] args){
  List<String> labels=MedicalView40.labels(true,1,true,false,false,false,true,true,true,false,false,false,3,6);
  var p=new MedicalView40.Part(null,null,null,3,6,true,false,false,labels);
  check(!Marks42.shown(p).contains("gunshot")&&!Marks42.shown(p).contains("cut")&&Marks42.shown(p).contains("bandaged"),"covered injury labels");
  for(double scale:new double[]{.36,1,2})for(int i=0;i<8;i++){Graphics g=new Graphics();Marks42.marks(g,i,p,5,7,scale);check(!g.calls.isEmpty(),"dressing visible");for(int[]r:g.calls)check((r[4]&0xFFFFFF)!=0xCC3434,"no wound through bandage");check(HealthTab40.contains(HealthTab40.shapes()[i],Marks42.ANCHOR[i][0],Marks42.ANCHOR[i][1]),"anatomical anchor");}
  var uncovered=new MedicalView40.Part(null,null,null,3,6,false,false,false,List.of("cut"));check(Marks42.shown(uncovered).contains("cut"),"removal reveals wound");
  Wound w=new Wound();w.cut=true;w.infected=true;w.healingLeft=30;check(w.bandage(),"can dress infected");check(w.infected,"ordinary application cannot erase infection");w.infected=false;w.dirty=true;w.tick();check(w.healingLeft==30,"irritated dirty wound pauses recovery");w.dirty=false;w.tick();check(w.healingLeft==29,"clean recovery resumes");check(Hygiene42.extraWear(true,false)>Hygiene42.extraWear(true,true)&&Hygiene42.extraWear(false,false)==0,"sterile/activity wear");System.out.println("PASS: covered/uncovered marks, 8 anatomical anchors, 3 scales, infection retention, dirty healing pause, sterile wear");
 }
}
