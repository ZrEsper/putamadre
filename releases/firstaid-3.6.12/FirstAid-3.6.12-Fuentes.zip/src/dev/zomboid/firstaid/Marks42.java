package dev.zomboid.firstaid;
import java.util.*;
public final class Marks42 {
 static final int[][] ANCHOR={{50,22},{50,61},{75,75},{25,75},{57,137},{43,137},{59,190},{41,190}};
 static void rect(Object g,double bx,double by,double scale,int x,int y,int w,int h,int color){int x1=(int)Math.floor(bx+x*scale),y1=(int)Math.floor(by+y*scale),x2=(int)Math.ceil(bx+(x+w)*scale),y2=(int)Math.ceil(by+(y+h)*scale);R.call(g,"fill",x1,y1,Math.max(x1+1,x2),Math.max(y1+1,y2),color);}
 static void clipped(Object g,int index,double bx,double by,double scale,int x,int y,int w,int h,int color){int[][] poly=HealthTab40.shapes()[index];for(int yy=y;yy<y+h;yy++){int start=-1;for(int xx=x;xx<=x+w;xx++){boolean in=xx<x+w&&HealthTab40.contains(poly,xx+.5,yy+.5);if(in&&start<0)start=xx;else if(!in&&start>=0){rect(g,bx,by,scale,start,yy,xx-start,1,color);start=-1;}}}}
 public static List<String> shown(MedicalView40.Part p){if(!p.injuries().contains("bandaged"))return p.injuries();List<String> a=new ArrayList<>();a.add("bandaged");for(String s:new String[]{"dirty_bandage","irritation","infection","splinted","treating","healing"})if(p.injuries().contains(s))a.add(s);return a;}
 public static void marks(Object g,int i,MedicalView40.Part p,double x,double y,double scale){int cx=ANCHOR[i][0],cy=ANCHOR[i][1];var labels=p.injuries();if(labels.contains("bandaged")){clipped(g,i,x,y,scale,cx-12,cy-6,24,12,0xFFE8DCC2);for(int yy=cy-5;yy<cy+6;yy+=4)clipped(g,i,x,y,scale,cx-12,yy,24,1,0xFFB6AA90);if(labels.contains("dirty_bandage"))clipped(g,i,x,y,scale,cx-2,cy-2,5,4,0xFF9E7142);if(labels.contains("infection"))clipped(g,i,x,y,scale,cx-2,cy-3,4,6,0xFFD0A344);}else{
  if(MedicalView40.affected(p)){clipped(g,i,x,y,scale,cx-4,cy,8,2,0xFFCC3434);clipped(g,i,x,y,scale,cx,cy-2,3,2,0xFFFF6666);}
  if(labels.contains("bullet")||labels.contains("gunshot"))clipped(g,i,x,y,scale,cx-2,cy-2,4,4,0xFF641313);
  if(p.bleeding())clipped(g,i,x,y,scale,cx+1,cy+3,3,5,0xFFCC2020);
 }if(p.splinted())clipped(g,i,x,y,scale,cx+3,cy-13,3,26,0xFFC39B61);}
 static final Map<Integer,List<int[]>> SPANS=new HashMap<>(),EDGES=new HashMap<>();
 public static void silhouette(Object g,int index,double bx,double by,double scale,int color){
  if(!SPANS.containsKey(index)){List<int[]> spans=new ArrayList<>(),edges=new ArrayList<>();int[][]p=HealthTab40.shapes()[index];for(int yy=0;yy<200;yy++){int start=-1;for(int xx=0;xx<=100;xx++){boolean in=xx<100&&HealthTab40.contains(p,xx+.5,yy+.5);if(in&&start<0)start=xx;else if(!in&&start>=0){spans.add(new int[]{start,yy,xx-start,1});start=-1;}}}for(int j=0;j<p.length;j++){int[]a=p[j],b=p[(j+1)%p.length];int steps=Math.max(Math.abs(a[0]-b[0]),Math.abs(a[1]-b[1]));for(int k=0;k<=steps;k++){double t=steps==0?0:k/(double)steps;edges.add(new int[]{(int)(a[0]+(b[0]-a[0])*t),(int)(a[1]+(b[1]-a[1])*t),1,1});}}SPANS.put(index,spans);EDGES.put(index,edges);}
  for(int[]p:SPANS.get(index))rect(g,bx,by,scale,p[0],p[1],p[2],p[3],color);for(int[]p:EDGES.get(index))rect(g,bx,by,scale,p[0],p[1],p[2],p[3],0xFFFFFFFF);
 }
}
