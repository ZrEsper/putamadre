package dev.zomboid.firstaid;
import java.util.*;
import java.util.function.Function;
public final class Hygiene42 {
 static final ThreadLocal<Boolean> infectedBefore=new ThreadLocal<>();
 static Object c(Object o,String n,Object...a){return R.call(o,n,a);}static int number(Object o,String field){return ((Number)R.get(o,field)).intValue();}
 public static void register(Object registry){Function<Object,Object> cloth=p->R.make("ichttt.mods.firstaid.compat.lrtactical.ClothDressingItem",c(p,"stacksTo",16));c(registry,"registerItem","sterile_cloth",cloth);c(registry,"registerItem","sterile_bandage",cloth);c(registry,"registerItem","medical_alcohol",(Function<Object,Object>)(p->R.make("net.minecraft.world.item.Item",c(p,"stacksTo",16))));}
 static String id(Object stack){return String.valueOf(c(c(stack,"getItem"),"getDescriptionId"));}
 public static boolean sterile(Object stack){return Set.of("item.firstaid.sterile_cloth","item.firstaid.sterile_bandage").contains(id(stack));}
 public static boolean dressing(boolean old,Object stack){return old||sterile(stack);}
 static Object wound(Object model,int i){return ((Object[])R.get(c(R.type("ichttt.mods.firstaid.survival.ClinicalData"),"state",model),"wounds"))[i];}
 public static void before(Object model,int i){infectedBefore.set(R.yes(R.get(wound(model,i),"infected")));}
 public static void applied(Object model,Object player,int i,Object stack){Object w=wound(model,i);boolean sterile=sterile(stack);c(c(player,"getPersistentData"),"putBoolean","fa42_sterile_"+i,sterile);if(!sterile&&Boolean.TRUE.equals(infectedBefore.get()))R.set(w,"infected",true);infectedBefore.remove();if(sterile){R.set(w,"dirty",false);R.set(w,"infected",false);R.set(w,"deteriorationTicks",0);}Antibiotic.guard(model,player);c(model,"scheduleResync");}
 public static boolean inflamed(Object wound){return R.yes(R.get(wound,"infected"))||R.yes(R.get(wound,"dirty"));}
 public static boolean recovery(boolean original,Object wound){return original&&!R.yes(R.get(wound,"dirty"));}
 public static int extraWear(boolean active,boolean sterile){return active?(sterile?40:100):0;}
 public static void activity(Object model,Object player){if(!R.type("net.minecraft.server.level.ServerPlayer").isInstance(player)||R.yes(c(player,"isCreative"))||R.yes(c(player,"isSpectator"))||!R.yes(c(player,"isAlive")))return;int tick=number(player,"tickCount");if(tick%20!=0)return;Object data=c(player,"getPersistentData");if(((Number)c(data,"getInt","fa42_hygiene_tick")).intValue()==tick)return;c(data,"putInt","fa42_hygiene_tick",tick);
  boolean active=R.yes(c(player,"isSprinting"))||R.yes(c(player,"isSwimming"))||R.yes(R.get(player,"swinging"))||Exercise40.sessions.containsKey(player);boolean changed=false;Object[] wounds=(Object[])R.get(c(R.type("ichttt.mods.firstaid.survival.ClinicalData"),"state",model),"wounds");
  for(int i=0;i<wounds.length;i++){Object w=wounds[i];if(!R.yes(R.get(w,"bandaged")))continue;boolean sterile=R.yes(c(data,"getBoolean","fa42_sterile_"+i));int age=number(w,"dressingAge");age=Math.min(1000000,age+extraWear(active,sterile));R.set(w,"dressingAge",age);if(age>=7200&&!R.yes(R.get(w,"dirty"))){R.set(w,"dirty",true);changed=true;}
   if(age>=7800&&R.yes(R.get(w,"dirty"))&&R.yes(c(w,"active"))&&!R.yes(R.get(w,"infected"))&&((Number)c(c(player,"getRandom"),"nextFloat")).floatValue()<.003f){R.set(w,"infected",true);changed=true;}
  }if(changed){c(model,"scheduleResync");c(R.type("ichttt.mods.firstaid.common.util.CommonUtils"),"syncDamageModel",player);}
 }
}
