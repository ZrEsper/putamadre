import java.nio.file.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public class Patch implements Opcodes{
 static String H="dev/zomboid/firstaid/Hygiene42",out="work/medical42/classes";
 static MethodInsnNode call(String n,String d){return new MethodInsnNode(INVOKESTATIC,H,n,d,false);}
 static ClassNode read(ZipFile z,String n)throws Exception{ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(n+".class")).readAllBytes()).accept(c,0);return c;}
 static MethodNode m(ClassNode c,String n){return c.methods.stream().filter(x->x.name.equals(n)).findFirst().orElseThrow();}
 static void write(ClassNode c)throws Exception{ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=Path.of(out,c.name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());}
 public static void main(String[]args)throws Exception{try(ZipFile z=new ZipFile(args[0])){
 ClassNode c=read(z,"ichttt/mods/firstaid/compat/lrtactical/TreatmentV33");MethodNode m=m(c,"registerDirty");for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==RETURN){InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,0));i.add(call("register","(Ljava/lang/Object;)V"));m.instructions.insertBefore(n,i);}
 m=m(c,"dressing");for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==IRETURN){InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,0));i.add(call("dressing","(ZLjava/lang/Object;)Z"));m.instructions.insertBefore(n,i);}
 m=m(c,"applied");InsnList before=new InsnList();before.add(new VarInsnNode(ALOAD,0));before.add(new VarInsnNode(ILOAD,2));before.add(call("before","(Ljava/lang/Object;I)V"));m.instructions.insert(before);for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==RETURN){InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,0));i.add(new VarInsnNode(ALOAD,1));i.add(new VarInsnNode(ILOAD,2));i.add(new VarInsnNode(ALOAD,3));i.add(call("applied","(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)V"));m.instructions.insertBefore(n,i);}
 m=m(c,"tickHygiene");InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,0));i.add(new VarInsnNode(ALOAD,1));i.add(call("activity","(Ljava/lang/Object;Ljava/lang/Object;)V"));m.instructions.insert(i);
 m=m(c,"recoveryAllowed");for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==IRETURN){i=new InsnList();i.add(new VarInsnNode(ALOAD,0));i.add(call("recovery","(ZLjava/lang/Object;)Z"));m.instructions.insertBefore(n,i);}write(c);
 c=read(z,"ichttt/mods/firstaid/survival/ClinicalState$Wound");m=m(c,"bandage");int removed=0;for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof FieldInsnNode f&&f.name.equals("infected")&&f.getOpcode()==PUTFIELD){if(n.getPrevious().getOpcode()!=ICONST_0)throw new Error("unexpected infection write");m.instructions.remove(n.getPrevious().getPrevious());m.instructions.remove(n.getPrevious());m.instructions.remove(n);removed++;}if(removed!=1)throw new Error("infection reset="+removed);
 m=m(c,"tick");for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof FieldInsnNode f&&f.name.equals("infected")&&f.getOpcode()==GETFIELD)m.instructions.set(n,call("inflamed","(Ljava/lang/Object;)Z"));write(c);
 }}
}
