from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import subprocess,json
r=Path('work/medical42');base=Path('attachments/92b375ea-65c1-4365-b95a-2e1089182f76/firstaid-1.21.1-ZOMBOID-v3.6.11-injuries-exercise-hud.jar');out=r/'firstaid-1.21.1-ZOMBOID-v3.6.12-dressing-hygiene.jar'
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
subprocess.run(['java','com.sun.tools.javac.Main','-cp',str(base),'-d',str(r/'classes'),*map(str,(r/'src').rglob('*.java'))],check=True)
subprocess.run(['java','com.sun.tools.javac.Main',*flags,'-d',str(r/'tools'),str(r/'Patch.java')],check=True)
subprocess.run(['java',*flags,'-cp',str(r/'tools'),'Patch',str(base)],check=True)
subprocess.run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/belroft3/classes','Verify',str(r/'classes')],check=True)
with ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()}
original=data.copy()
for p in (r/'classes').rglob('*.class'):data[p.relative_to(r/'classes').as_posix()]=p.read_bytes()
for p in (r/'resources').rglob('*'):
 if p.is_file():
  name=p.relative_to(r/'resources').as_posix()
  if '/lang/' in name and name in data:d=json.loads(data[name]);d.update(json.loads(p.read_text()));data[name]=json.dumps(d,ensure_ascii=False,indent=2).encode()
  else:data[name]=p.read_bytes()
data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'zomboid-v3.6.11-injuries-exercise-hud',b'zomboid-v3.6.12-dressing-hygiene')
with ZipFile(out,'w',ZIP_DEFLATED) as z:
 for n,b in data.items():z.writestr(n,b)
with ZipFile(out) as z:assert z.testzip() is None;assert len(z.namelist())==len(set(z.namelist()))
print(out)
