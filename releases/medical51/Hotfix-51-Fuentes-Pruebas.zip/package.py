from pathlib import Path
import zipfile,json,tomllib,hashlib
r=Path(__file__).parent;out=r/'release';out.mkdir(exist_ok=True);entries=[]
names={'gore':'zomboid-zombie-gore-1.0.20-neoforge-1.21.1-medical-buffer-torso.35.jar','rag':'ragdollified-1.21.1-1.1.5-single-player-zombie-corpse.28.jar'}
for kind,name in names.items():
 with zipfile.ZipFile(r/'output'/f'{kind}.jar')as z:data={n:z.read(n)for n in z.namelist()}
 meta=data['META-INF/neoforge.mods.toml'].decode()
 if kind=='gore':meta=meta.replace('version="1.0.20.50"','version="1.0.20.51"').replace('Gore .34','Gore .35').replace('[1.1.5-gore20-medical50]','[1.1.5-gore20-medical51]')
 else:meta=meta.replace('version="1.1.5-gore20-medical50"','version="1.1.5-gore20-medical51"').replace('[1.0.20.50,1.0.21)','[1.0.20.51,1.0.21)')
 parsed=tomllib.loads(meta);data['META-INF/neoforge.mods.toml']=meta.encode();assert not any(n.startswith(('net/minecraft/','org/lwjgl/'))for n in data)
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in sorted(data.items()):z.writestr(n,b)
 with zipfile.ZipFile(out/name)as z:assert z.testzip()is None;assert len(z.namelist())==len(set(z.namelist()))
 entries.append({'file':name,'mod_id':parsed['mods'][0]['modId'],'version':parsed['mods'][0]['version'],'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'base_commit':'ab7aa8bb62107b75a191ab6e6e577715e04719e0','minecraft':'1.21.1','loader':'NeoForge','minecraft_runtime_tested':False,'artifacts':entries},indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(''.join(e['sha256']+'  mods/'+e['file']+'\n'for e in entries))
results=json.loads((r/'test-results.json').read_text());results['native_hooks']='PASS: Skin12 end, server factory and both client factories';results['medical_persistence_regressions']=4030;results['actual_bullet_tick_regression']='PASS: inventory collider and posed body';results['survivor_downed_revive_regressions']=12;(r/'test-results.json').write_text(json.dumps(results,indent=2)+'\n')
for n in ['LEEME.md','test-results.json']:(out/n).write_bytes((r/n).read_bytes())
with zipfile.ZipFile(out/'Hotfix-51-Crash-Torso-Cadaver-Unico.zip','w',zipfile.ZIP_DEFLATED)as z:
 for e in entries:z.write(out/e['file'],'mods/'+e['file'])
 for n in ['LEEME.md','test-results.json','manifest.json','SHA256SUMS.txt']:z.write(out/n,n)
with zipfile.ZipFile(out/'Hotfix-51-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','tests','fixtures']:
  for p in(r/folder).rglob('*'):
   if p.is_file():z.write(p,p.relative_to(r))
 for n in ['Patch51.java','Contracts51.java','build.py','test.py','package.py','LEEME.md','test-results.json']:z.write(r/n,n)
for n in ['Hotfix-51-Crash-Torso-Cadaver-Unico.zip','Hotfix-51-Fuentes-Pruebas.zip']:print(n,(out/n).stat().st_size,hashlib.sha256((out/n).read_bytes()).hexdigest())
