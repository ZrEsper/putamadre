package net.smileycorp.hordes.common.entities;public class PlayerZombie{public boolean isAlive(){return false;}}
