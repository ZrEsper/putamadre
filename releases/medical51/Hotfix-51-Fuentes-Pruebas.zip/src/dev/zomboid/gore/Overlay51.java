package dev.zomboid.gore;
/** Medical layers cannot switch the caller's BufferSource while its skin consumer is in use. */
public final class Overlay51 {
 static Object marks,flesh;static boolean marksUsed,fleshUsed;
 static Object create(){return R.call(R.type("net.minecraft.client.renderer.MultiBufferSource"),"immediate",R.make("com.mojang.blaze3d.vertex.ByteBufferBuilder",4096));}
 public static Object marks(){if(marks==null)marks=create();marksUsed=true;return marks;}
 public static Object flesh(){if(flesh==null)flesh=create();fleshUsed=true;return flesh;}
 public static void end(){try{if(marksUsed)R.call(marks,"endBatch");if(fleshUsed)R.call(flesh,"endBatch");}finally{marksUsed=false;fleshUsed=false;}}
}
