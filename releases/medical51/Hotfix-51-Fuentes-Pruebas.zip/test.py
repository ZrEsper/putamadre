from pathlib import Path
import subprocess,json
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];g=r/'output/gore.jar';out=r/'build/tests';out.mkdir(exist_ok=True,parents=True)
f=list((r/'tests').rglob('*.java'))+list((r/'fixtures').rglob('*.java'))
subprocess.run(e+['-cp',str(g),'-d',str(out)]+list(map(str,f)),check=True)
results=[]
for name,jar,args in [('old',next(Path('/workspace/medical50/release').glob('zomboid-zombie*.jar')),['old']),('new',g,[])]:
 p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(jar),'dev.zomboid.gore.RenderCheck51']+args,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
(r/'test-results.json').write_text(json.dumps({'minecraft_runtime_tested':False,'boundary':'Production Player45.draw and Bite48.render with immediate BufferSource lifecycle simulation; real reflection implementation and native geometry helpers. No GPU/Minecraft instance.','results':results,'bytecode_classes':998},indent=2)+'\n')

asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree']);subprocess.run(e+['-cp',asm,'-d',str(r/'build/tools'),str(r/'Contracts51.java')],check=True);subprocess.run(['java','-cp',str(r/'build/tools')+':'+asm,'Contracts51',str(g),str(r/'output/rag.jar')],check=True)
