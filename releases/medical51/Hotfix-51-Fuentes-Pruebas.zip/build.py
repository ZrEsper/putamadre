from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');base=Path('/workspace/medical50/release');g=next(base.glob('zomboid-zombie*.jar'));rag=next(base.glob('ragdoll*.jar'))
for p in ['build/classes','build/tools','output']:(r/p).mkdir(parents=True,exist_ok=True)
e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis']);subprocess.run(e+['-cp',str(g),'-d',str(r/'build/classes')]+list(map(str,(r/'src').rglob('*.java'))),check=True);subprocess.run(e+['-cp',asm,'-d',str(r/'build/tools'),str(r/'Patch51.java')],check=True);subprocess.run(['java','-cp',str(r/'build/tools')+':'+asm,'Patch51',str(g),str(r/'build/classes'),str(r/'output/gore.jar'),str(rag),str(r/'output/rag.jar')],check=True)
