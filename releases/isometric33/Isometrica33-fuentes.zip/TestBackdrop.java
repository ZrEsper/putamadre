import com.cleannrooster.dungeons_iso.api.cullers.room.CullingBackdrop;
import com.cleannrooster.dungeons_iso.mod.Mod;
import net.minecraft.client.Minecraft;
public class TestBackdrop {
 static void check(boolean active) { CullingBackdrop.update(); if(CullingBackdrop.hidesSky()!=active || CullingBackdrop.strength()!=(active?1f:0f))throw new AssertionError(); CullingBackdrop.setColor(1f,.8f,.4f); if(CullingBackdrop.red()!=0 || CullingBackdrop.green()!=0 || CullingBackdrop.blue()!=0)throw new AssertionError(); }
 public static void main(String[] args) { Minecraft c=Minecraft.getInstance(); check(false); Mod.enabled=true; check(false); c.level=new net.minecraft.client.multiplayer.ClientLevel(); check(false); c.cameraEntity=new net.minecraft.world.entity.Entity(); check(true); check(true); Mod.enabled=false;check(false); Mod.enabled=true;check(true);c.level=null;check(false);System.out.println("PASS: immediate black, camera modes, missing world/entity, no stale fade or color"); }
}