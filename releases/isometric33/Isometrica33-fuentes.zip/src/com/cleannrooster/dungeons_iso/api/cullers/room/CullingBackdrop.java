package com.cleannrooster.dungeons_iso.api.cullers.room;
import com.cleannrooster.dungeons_iso.mod.Mod;
import net.minecraft.client.Minecraft;
/** Black background only while the isometric camera has a live world. No room scans or fades. */
public final class CullingBackdrop {
 private CullingBackdrop() {}
 private static boolean active() {
   Minecraft client = Minecraft.getInstance();
   return Mod.enabled && client.level != null && client.cameraEntity != null;
 }
 public static void update() {}
 public static float strength() { return active() ? 1.0f : 0.0f; }
 public static boolean hidesSky() { return active(); }
 public static void setColor(float red,float green,float blue) {}
 public static float red() { return 0.0f; }
 public static float green() { return 0.0f; }
 public static float blue() { return 0.0f; }
}
