package dev.zomboid.isotacz;
public class Fixture {
 public static class Vec{public double x,y,z;public Vec(double x,double y,double z){this.x=x;this.y=y;this.z=z;}}
 public static class Item{public String id;public Item(String s){id=s;}}
 public static class Stack{public Item item;public String animation="NONE";public Stack(String s){item=new Item(s);}public boolean isEmpty(){return item.id.isEmpty();}public Item getItem(){return item;}public String getUseAnimation(){return animation;}}
 public static class Player{public Stack main=new Stack("firstaid:bandage"),off=new Stack(""),use=main;public boolean using;public float yaw,head,yBodyRot,yRotO,yHeadRotO,yBodyRotO,pitch=17;public boolean isUsingItem(){return using;}public Stack getUseItem(){return use;}public Stack getMainHandItem(){return main;}public Stack getOffhandItem(){return off;}public Vec getEyePosition(){return new Vec(0,1.6,0);}public void setYRot(float v){yaw=v;}public void setYHeadRot(float v){head=v;}}
 public static class Mod{public static boolean using;public static float livingYaw,livingHeadYaw,livingBodyYaw;}
 public static class MC{public Player player=new Player();public Object level=new Object(),screen;public boolean useKey;public void setLocation(Object x){}public void setOriginalLocation(Object x){}}
 static int checks;static void check(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
 public static void main(String[]a){
  Player p=Bridge.MC.player;
  check(MedicalInput30.nativeInput(),"medicine still uses native consume input");
  check(!MedicalInput30.skipMovement(),"held: isometric movement mapping retained");
  check(AimStability.suppress(p),"only cursor controller writes consumable yaw");
  for(double[] v:new double[][]{{0,5,0},{5,0,-90},{0,-5,-180},{-5,0,90}}){CursorTarget.point=new Vec(v[0],0,v[1]);ConsumableFree36.aim();check(Math.abs(ConsumableFree36.wrap(p.yaw-v[2]))<.001,"cursor quadrant");check(p.head==p.yaw&&p.yBodyRot==p.yaw,"head/body aligned");check(Bridge.MOD.livingYaw==p.yaw,"rotation cache coherent");}
  p.using=true;check(!MedicalInput30.skipMovement(),"using: movement mapping retained");check(MedicalInput30.medical(),"active treatment recognized");ConsumableFree36.aim();check(p.using,"use not cancelled");check(p.pitch==17,"pitch untouched");
  p.yaw=73;Bridge.MC.screen=new Object();ConsumableFree36.aim();check(p.yaw==73,"GUI no rotation");Bridge.MC.screen=null;
  Bridge.active=false;ConsumableFree36.aim();check(p.yaw==73,"first person no rotation");Bridge.active=true;
  NativeActions.riding=true;ConsumableFree36.aim();check(p.yaw==73&&MedicalInput30.skipMovement(),"riding retains native movement");NativeActions.riding=false;
  CursorTarget.point=new Vec(0,0,0);ConsumableFree36.aim();check(p.yaw==73,"degenerate cursor no rotation");
  p.using=false;p.main=new Stack("gun");p.off=new Stack("firstaid:bandage");CursorTarget.point=new Vec(5,0,5);ConsumableFree36.aim();check(p.yaw==73,"offhand medicine does not override gun");
  p.main=new Stack("minecraft:apple");p.off=new Stack("");NativeActions.food=true;check(ConsumableFree36.held(),"food held");ConsumableFree36.aim();check(p.yaw==-45,"food rotates");
  p.main.animation="DRINK";p.use=p.main;p.using=true;check(ConsumableFree36.held(),"drink active");check(!MedicalInput30.skipMovement(),"drink movement mapping");
  p.main=new Stack("firstaid:splint");p.use=p.main;p.using=false;NativeActions.food=false;p.yRotO=179;p.yHeadRotO=179;p.yBodyRotO=179;CursorTarget.point=new Vec(.01,0,-5);ConsumableFree36.aim();check(Math.abs(p.yRotO-p.yaw)<3,"no 360 degree interpolation spin");
  CursorTarget.point=new Vec(Double.NaN,0,5);float before=p.yaw;ConsumableFree36.aim();check(p.yaw==before,"invalid cursor guarded");
  System.out.println("PASS "+checks+" runtime fixture checks against patched MedicalInput30/AimStability and production helper; not a Minecraft launch.");
 }
}
