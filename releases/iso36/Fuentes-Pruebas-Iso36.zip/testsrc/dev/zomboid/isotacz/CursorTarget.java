package dev.zomboid.isotacz;
public class CursorTarget {public static Fixture.Vec point=new Fixture.Vec(0,0,5);public static Object aimPoint(Object mc){return point;}}
