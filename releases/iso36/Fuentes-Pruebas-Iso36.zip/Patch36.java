import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
public class Patch36 implements Opcodes{public static void main(String[]a)throws Exception{Map<String,byte[]>d=new TreeMap<>();try(var z=new ZipFile(a[0])){for(var e:Collections.list(z.entries()))d.put(e.getName(),z.getInputStream(e).readAllBytes());}int hooks=0;
 for(String key:List.of("MedicalInput30","AimStability","ShotAim32")){
 String path="dev/zomboid/isotacz/"+key+".class";ClassNode c=new ClassNode();new ClassReader(d.get(path)).accept(c,0);
 for(var m:c.methods){
 if(key.equals("MedicalInput30")&&m.name.equals("skipMovement")){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new MethodInsnNode(INVOKESTATIC,"dev/zomboid/isotacz/NativeActions","riding","()Z",false));m.instructions.add(new InsnNode(IRETURN));hooks++;}
 if(key.equals("MedicalInput30")&&m.name.equals("nativeInput")){for(var i:m.instructions.toArray())if(i.getOpcode()==IRETURN){m.instructions.insertBefore(i,new MethodInsnNode(INVOKESTATIC,"dev/zomboid/isotacz/ConsumableFree36","aim","()V",false));hooks++;}}
 if(key.equals("AimStability")&&m.name.equals("suppress")){for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.owner.equals(c.name)&&call.name.equals("medical")){call.owner="dev/zomboid/isotacz/ConsumableFree36";call.name="held";hooks++;}}
 if(key.equals("ShotAim32")&&m.name.equals("before")){m.instructions.insert(new MethodInsnNode(INVOKESTATIC,"dev/zomboid/isotacz/ConsumableFree36","aim","()V",false));hooks++;}
 }
 var w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);d.put(path,w.toByteArray());}
 if(hooks!=4)throw new Error("Unexpected hooks "+hooks);
 d.put("dev/zomboid/isotacz/ConsumableFree36.class",Files.readAllBytes(Path.of(a[1])));
 String key="META-INF/neoforge.mods.toml",toml=new String(d.get(key),java.nio.charset.StandardCharsets.UTF_8);if(!toml.contains("3.6.2+zomboid.35"))throw new Error("Unexpected base version");d.put(key,toml.replace("3.6.2+zomboid.35","3.6.2+zomboid.36").getBytes(java.nio.charset.StandardCharsets.UTF_8));
 int count=0;for(var e:d.entrySet())if(e.getKey().endsWith(".class")){var c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);for(var m:c.methods)if((m.access&(ACC_NATIVE|ACC_ABSTRACT))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);count++;}
 try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(a[2])))){for(var e:d.entrySet()){z.putNextEntry(new ZipEntry(e.getKey()));z.write(e.getValue());z.closeEntry();}}System.out.println("PASS: "+hooks+" hooks, "+count+" classes verified with ASM BasicVerifier.");}}
