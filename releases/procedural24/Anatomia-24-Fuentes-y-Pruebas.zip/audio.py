from pathlib import Path
import wave,math,random,struct,subprocess,json
r=Path(__file__).resolve().parent;(r/'audio').mkdir(exist_ok=True)
# Original filtered cloth/low thump foley; no sampled assets from Valve or other games.
for kind in ['body_impact24','body_scrape24']:
 for variant in range(3):
  rng=random.Random(240+variant+(50 if 'scrape'in kind else 0));rate=22050;duration=.26 if 'impact'in kind else .38;low=0;values=[]
  for i in range(int(rate*duration)):
   t=i/rate;noise=rng.uniform(-1,1);low+=.12*(noise-low)
   if 'impact'in kind:
    env=math.exp(-t*19);v=(math.sin(2*math.pi*(68+variant*9)*t)*.50+low*.8+noise*.12)*env*(1-math.exp(-t*900))
   else:
    env=math.sin(math.pi*t/duration)**1.4;v=(low*.9+noise*.06)*env*(.75+.25*math.sin(2*math.pi*33*t))
   values.append(int(max(-1,min(1,v))*.85*32767))
  wav=r/'audio'/f'{kind}_{variant}.wav';ogg=wav.with_suffix('.ogg')
  with wave.open(str(wav),'wb')as w:w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes(struct.pack('<'+'h'*len(values),*values))
  subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(wav),'-c:a','libvorbis','-q:a','4',str(ogg)],check=True)
print('Original contact foley: 6 short ogg variants')
