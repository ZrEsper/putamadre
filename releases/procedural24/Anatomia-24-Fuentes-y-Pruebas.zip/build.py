from pathlib import Path
import subprocess,zipfile,json,hashlib
r=Path(__file__).resolve().parent;workspace=r.parent.parent
GORE=workspace/'attachments/5c66adf4-b814-4ab1-b208-98315a4b3c7e/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-visible-tissue-debris.23.jar'
RAG=workspace/'attachments/25733045-2a0b-4ede-9d9b-d4874a9d8987/ragdollified-1.21.1-1.1.5-low-impact.19.jar'
exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{s}=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']]
for d in ['build/classes','build/tools','output']:(r/d).mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(GORE),'-d',str(r/'build/classes'),*map(str,(r/'src').rglob('*.java'))],check=True)
subprocess.run(['java',*exports,'com.sun.tools.javac.Main',*exports,'-d',str(r/'build/tools'),str(r/'Patch.java')],check=True)
g=r/'output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-procedural-anatomy.24.jar';rag=r/'output/ragdollified-1.21.1-1.1.5-procedural-anatomy.20.jar'
subprocess.run(['java',*exports,'-cp',str(r/'build/tools'),'Patch',str(GORE),str(RAG),str(r/'build/classes'),str(g),str(rag)],check=True)
with zipfile.ZipFile(g)as z:e={n:z.read(n)for n in z.namelist()}
sounds=json.loads(e['assets/zomboid_gore/sounds.json'])
for kind in ['body_impact24','body_scrape24']:
 sounds[kind]={'sounds':[{'name':f'zomboid_gore:{kind}_{i}','attenuation_distance':24}for i in range(3)]}
 for i in range(3):e[f'assets/zomboid_gore/sounds/{kind}_{i}.ogg']=(r/'audio'/f'{kind}_{i}.ogg').read_bytes()
e['assets/zomboid_gore/sounds.json']=(json.dumps(sounds,indent=2)+'\n').encode()
e['META-INF/zomboid-procedural24.json']=json.dumps({'patch':24,'original_version_retained_for_consumers':'1.0.20','protocol':'16-procedural24','minecraft_runtime_tested':False}).encode()
with zipfile.ZipFile(g,'w',zipfile.ZIP_DEFLATED)as z:
 for n,b in sorted(e.items()):z.writestr(n,b)
(r/'build-validation.json').write_text(json.dumps({'inputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [GORE,RAG]},'outputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [g,rag]},'minecraft_runtime_tested':False},indent=2)+'\n')
