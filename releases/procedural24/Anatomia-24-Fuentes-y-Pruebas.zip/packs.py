from pathlib import Path
import zipfile,json,re,hashlib
r=Path(__file__).resolve().parent;root=r.parent.parent;out=r/'output'
inputs=[(root/'attachments/0957488b-d39c-4a3b-8032-1ef816ad8c04/TZP_1.20.1_2.7.zip','TZP-1.21.1-Procedural-Anatomy.24.zip'),(root/'attachments/1a1141e9-6044-4aa1-b6af-88e0f72cc91b/Zomboid_Poldos.zip','Zomboid-Poldos-ETF-Fix.24.zip')]
audit={}
def clean(m):
 if 'submodels'in m:m['submodels']=[clean(c)for c in m['submodels']if not c.get('id','').startswith('zg_')]
 if 'animations'in m:m['animations']=[{k:v for k,v in a.items()if 'zg'not in k and 'zg'not in str(v)}for a in m['animations']];m['animations']=[a for a in m['animations']if a]
 return m
for source,name in inputs:
 with zipfile.ZipFile(source)as z:original={n:z.read(n)for n in z.namelist()}
 e=original.copy();changed=[]
 for n,b in original.items():
  if n.endswith('.jem'):
   d=json.loads(b);d['models']=[clean(m)for m in d.get('models',[])if not m.get('id','').startswith('zg_')]
   # Existing Fresh animations remain; broken-leg sway is additive and does not recenter the torso.
   rootmodel=next((m for m in d['models']if m.get('part')=='root'),None)
   if rootmodel is not None:
    rootmodel.setdefault('animations',[]).append({'var.zg_limp_left':'fmod(floor(zg_broken/4),2)','var.zg_limp_right':'fmod(floor(zg_broken/8),2)','left_leg.rx':'left_leg.rx*if(var.zg_limp_left>0,0.35,1)','right_leg.rx':'right_leg.rx*if(var.zg_limp_right>0,0.35,1)','body.rz':'body.rz+if(var.zg_limp_left+var.zg_limp_right>0,sin(limb_swing)*0.045*clamp(limb_speed*3,0,1),0)'})
   e[n]=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();changed.append(n)
  if '/random/entity/' in n and n.endswith('.properties'):
   s=b.decode();s=re.sub(r'(?m)^(skins\.\d+\s*=\s*)0(?=\s|$)',r'\g<1>1',s)
   if s.encode()!=b:e[n]=s.encode();changed.append(n)
 # Preserve every texture byte, including pack skins.
 assert all(e[n]==b for n,b in original.items()if n.endswith('.png'))
 if name.startswith('TZP'):
  e['pack.mcmeta']=json.dumps({'pack':{'pack_format':34,'description':'TZP + anatomía procedural .24. Pieles originales; sin heridas duplicadas.'}},ensure_ascii=False).encode()
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in sorted(e.items()):z.writestr(n,b)
 audit[name]={'modified':changed,'all_png_unchanged':True,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()}
(r/'pack-validation.json').write_text(json.dumps(audit,indent=2)+'\n')
print('PACKS: all original PNG bytes preserved; fixed injury overlays and ETF skin zero')
