package dev.zomboid.gore;
import java.util.*;import java.util.function.Function;
/** Per model-part LRU keyed by local wounds. Shared entity models never flush each other's meshes. */
public final class MeshCache24 extends AbstractMap<Integer,List<Mesh12.Quad>> {
 record Key(int shape,List<Integer> cuts){}
 final LinkedHashMap<Key,List<Mesh12.Quad>> states=new LinkedHashMap<>(16,.75f,true){protected boolean removeEldestEntry(Map.Entry<Key,List<Mesh12.Quad>>e){return size()>24;}};
 @Override public List<Mesh12.Quad> computeIfAbsent(Integer shape,Function<? super Integer,? extends List<Mesh12.Quad>> fn){int region=shape/4096;List<Integer>local=new ArrayList<>();int[]a=Cuts24.CURRENT.get();for(int i=0;i<a.length;i+=2){int r=a[i]&7;if(r==region||region==6&&r==7){local.add(a[i]);local.add(a[i+1]);}}Key key=new Key(shape,List.copyOf(local));List<Mesh12.Quad>value=states.get(key);if(value==null){value=fn.apply(shape);if(value!=null)states.put(key,value);}return value;}
 @Override public Set<Entry<Integer,List<Mesh12.Quad>>>entrySet(){return Set.of();}
 @Override public void clear(){states.clear();}
}
