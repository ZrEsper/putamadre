package dev.zomboid.gore;
import java.util.*;
/** Original foley assets. No physics forces or server traffic; four contact sounds/s globally. */
public final class Foley24 {
 static class Motion {double x,y,z,vx,vy,vz;long tick,sound=-100;boolean grounded;}
 static final Map<Object,Motion> MOTION=new WeakHashMap<>();static Object world;static long window=-100;static int sounds;static boolean warned;
 static int contact(boolean ground,boolean wasGround,double previousY,double currentY,double speed){return ground&&(!wasGround&&previousY<-.05||previousY<-.08&&currentY-previousY>.055)?2:ground&&speed>.022&&speed<.6?1:0;}
 public static void ragdoll(Object rag){try{
 Object mc=R.call(R.type("net.minecraft.client.Minecraft"),"getInstance"),level=R.get(mc,"level"),player=R.get(mc,"player");if(level==null||player==null||R.yes(R.call(mc,"isPaused")))return;if(level!=world){world=level;MOTION.clear();window=-100;}
 long now=((Number)R.call(level,"getGameTime")).longValue();Motion old=MOTION.get(rag);if(old!=null&&now-old.tick<2)return;
 Object t=R.call(rag,"getSmoothedTorsoPos");double x=R.num(R.get(t,"x")),y=R.num(R.get(t,"y")),z=R.num(R.get(t,"z"));if(R.num(R.call(player,"distanceToSqr",x,y,z))>24*24)return;
 if(old==null){old=new Motion();old.x=x;old.y=y;old.z=z;old.tick=now;MOTION.put(rag,old);return;}
 double dt=Math.max(1,now-old.tick),vx=(x-old.x)/dt,vy=(y-old.y)/dt,vz=(z-old.z)/dt,speed=Math.sqrt(vx*vx+vz*vz);
 boolean ground=false;for(String part:new String[]{"TORSO","LEFT_LEG","RIGHT_LEG"}){Object transform=R.call(rag,"getSmoothedTransform",R.get(R.type("com.raiiiden.ragdollified.RagdollPart"),part));if(transform==null)continue;Object pos=R.get(transform,"position"),end=R.call(pos,"add",0d,-.48d,0d),ctx=R.make("net.minecraft.world.level.ClipContext",pos,end,R.get(R.type("net.minecraft.world.level.ClipContext$Block"),"COLLIDER"),R.get(R.type("net.minecraft.world.level.ClipContext$Fluid"),"NONE"),player);if(R.call(R.call(level,"clip",ctx),"getType").toString().equals("BLOCK")){ground=true;break;}}
 if(now-window>=20){window=now;sounds=0;}
 int contact=contact(ground,old.grounded,old.vy,vy,speed);boolean impact=contact==2,scrape=contact==1;
 if(sounds<4&&now-old.sound>=(impact?7:13)&&(impact||scrape)){old.sound=now;sounds++;String path=impact?"body_impact24":"body_scrape24";float volume=impact?(float)Math.min(.8,.22+Math.abs(old.vy)*1.8):(float)Math.min(.35,.07+speed*.6);R.call(level,"playLocalSound",x,y,z,Artery14.makeSound(path),R.get(R.type("net.minecraft.sounds.SoundSource"),"HOSTILE"),volume,.9f+(now%7)*.025f,false);}
 old.x=x;old.y=y;old.z=z;old.vx=vx;old.vy=vy;old.vz=vz;old.tick=now;old.grounded=ground;
 }catch(RuntimeException e){if(!warned){warned=true;System.err.println("[Gore24] Ragdoll foley unavailable: "+e);}}}
}
