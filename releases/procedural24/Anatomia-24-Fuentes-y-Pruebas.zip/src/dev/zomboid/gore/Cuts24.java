package dev.zomboid.gore;
import java.util.*;
import java.nio.*;
/** Server-owned bounded cuts in each anatomical part's local normalized frame. */
public final class Cuts24 {
 public record Cut(int region,double x,double y,double z,double radius){}
 public static final int MAX=32;
 static final int[] EMPTY=new int[0];
 public static final ThreadLocal<int[]> CURRENT=ThreadLocal.withInitial(()->EMPTY);
 static Object accessor;
 static final Map<Object,int[]> LAST=new WeakHashMap<>();
 static final String KEY="zg_cuts24";
 public static void init(){accessor=R.call(R.type("net.minecraft.network.syncher.SynchedEntityData"),"defineId",R.type("net.minecraft.world.entity.monster.Zombie"),R.get(R.type("net.minecraft.network.syncher.EntityDataSerializers"),"STRING"));}
 public static void define(Object b){R.call(b,"define",accessor,"");}
 public static int[] sanitize(int[] a){if(a==null||a.length%2!=0||a.length>MAX*2)return EMPTY;for(int i=0;i<a.length;i+=2)if((a[i]&7)==1||(a[i]&7)>7||a[i+1]<1||a[i+1]>255)return EMPTY;return a;}
 public static String encode(int[]a){ByteBuffer b=ByteBuffer.allocate(a.length*4);for(int n:a)b.putInt(n);return Base64.getEncoder().encodeToString(b.array());}
 public static int[] decode(String s){if(s==null||s.length()>MAX*12)return EMPTY;try{byte[] raw=Base64.getDecoder().decode(s);if(raw.length%8!=0||raw.length>MAX*8)return EMPTY;int[]a=new int[raw.length/4];ByteBuffer b=ByteBuffer.wrap(raw);for(int i=0;i<a.length;i++)a[i]=b.getInt();return sanitize(a);}catch(IllegalArgumentException bad){return EMPTY;}}
 public static int[] get(Object n){return Gore.zombie(n)?decode((String)R.call(R.call(n,"getEntityData"),"get",accessor)):EMPTY;}
 static void set(Object n,int[] a){R.call(R.call(n,"getEntityData"),"set",accessor,encode(a));R.call(Gore.tag(n),"putIntArray",KEY,a);}
 public static void save(Object n,Object tag){R.call(tag,"putIntArray",KEY,get(n));}
 public static void restore(Object n,Object tag){set(n,sanitize((int[])R.call(tag,"getIntArray",KEY)));}
 static double clamp(double x){return Math.max(0,Math.min(1,x));}
 static int position(Cut c){return c.region()|((int)Math.round(clamp(c.x())*255)<<3)|((int)Math.round(clamp(c.y())*255)<<11)|((int)Math.round(clamp(c.z())*255)<<19);}
 public static Cut cut(int[] a,int i){int p=a[i];return new Cut(p&7,((p>>>3)&255)/255d,((p>>>11)&255)/255d,((p>>>19)&255)/255d,a[i+1]/16d);}
 static double width(int z){return z==0||z>=6?8:4;}
 static double height(int z){return z==0?8:12;}
 static double depth(int z){return z==0?8:4;}
 static double distance(Cut a,Cut b){return Math.sqrt(Math.pow((a.x()-b.x())*width(a.region()),2)+Math.pow((a.y()-b.y())*height(a.region()),2)+Math.pow((a.z()-b.z())*depth(a.region()),2));}
 public static int[] add(int[] old,Cut c){int[]a=sanitize(old).clone();if(c.region()==1||c.region()<0||c.region()>7||!Double.isFinite(c.x()+c.y()+c.z()+c.radius())||c.radius()<=0)return a;
 for(int i=0;i<a.length;i+=2){Cut b=cut(a,i);if(b.region()!=c.region())continue;double d=distance(b,c);if(d<=Math.min(b.radius(),c.radius())*.45){double v=Math.pow(b.radius(),3)+Math.pow(c.radius(),3),t=Math.pow(c.radius(),3)/v,r=Math.min(15.9375,Math.max(Math.cbrt(v),Math.max(b.radius()+d*t,c.radius()+d*(1-t))));a[i]=position(new Cut(c.region(),b.x()+(c.x()-b.x())*t,b.y()+(c.y()-b.y())*t,b.z()+(c.z()-b.z())*t,r));a[i+1]=Math.min(255,(int)Math.ceil(r*16));return a;}}
 if(a.length>=MAX*2){int p=-1,q=-1;double best=Double.MAX_VALUE;for(int i=0;i<a.length;i+=2)for(int j=i+2;j<a.length;j+=2){Cut b=cut(a,i),d=cut(a,j);double v=distance(b,d);if(b.region()==d.region()&&v<best){p=i;q=j;best=v;}}if(p<0)return a;Cut b=cut(a,p),d=cut(a,q);double radius=Math.min(15.9375,(best+b.radius()+d.radius())/2),t=best==0?0:clamp((radius-b.radius())/best);a[p]=position(new Cut(b.region(),b.x()+(d.x()-b.x())*t,b.y()+(d.y()-b.y())*t,b.z()+(d.z()-b.z())*t,radius));a[p+1]=Math.min(255,(int)Math.ceil(Math.max(radius,Math.max(b.radius(),d.radius()))*16));int[]room=new int[a.length-2];System.arraycopy(a,0,room,0,q);System.arraycopy(a,q+2,room,q,a.length-q-2);a=room;}
 int i=a.length;a=Arrays.copyOf(a,i+2);a[i]=position(c);a[i+1]=Math.max(1,Math.min(255,(int)Math.ceil(c.radius()*16)));return a;
 }
 public static boolean has(int region){for(int i=0;i<CURRENT.get().length;i+=2){int r=CURRENT.get()[i]&7;if(r==region||region==6&&r==7)return true;}return false;}
 public static void living(Object n){CURRENT.set(get(n));}
 public static void ragdoll(Object n){CURRENT.set(field(n));}
 public static int[] field(Object n){try{return sanitize((int[])R.get(n,"goreCuts24"));}catch(RuntimeException absent){return EMPTY;}}
 public static void copy(Object a,Object b){R.set(b,"goreCuts24",field(a).clone());}
 public static void packet(Object n,Object p){R.set(p,"goreCuts24",get(n));}
 public static void clear(){CURRENT.remove();}
 public static void prepare(Object part){}
 public static void write(Object packet,Object buf){int[]a=field(packet);R.call(buf,"writeVarInt",a.length);for(int v:a)R.call(buf,"writeInt",v);}
 public static void read(Object packet,Object buf){if(((Number)R.call(buf,"readableBytes")).intValue()==0){R.set(packet,"goreCuts24",EMPTY);return;}int n=((Number)R.call(buf,"readVarInt")).intValue();if(n<0||n>MAX*2||n%2!=0)throw new IllegalArgumentException("Invalid wound count: "+n);int[]a=new int[n];for(int i=0;i<n;i++)a[i]=((Number)R.call(buf,"readInt")).intValue();if(sanitize(a).length!=n)throw new IllegalArgumentException("Invalid wound payload");R.set(packet,"goreCuts24",a);}
 static double radius(float damage,int kind,Rules.Weapon gun){double r=.65+Math.sqrt(Math.max(0,damage))*.27;if(kind==2)r*=1.55;if(gun==Rules.Weapon.SHOTGUN)r*=1.35;return Math.min(5.5,r);}
 public static int zone(Gore.Shot s){Object n=s.entity();double yaw=Math.toRadians(R.num(R.get(n,"yBodyRot"))),dx=R.num(R.get(s.point(),"x"))-R.num(R.call(n,"getX")),dz=R.num(R.get(s.point(),"z"))-R.num(R.call(n,"getZ"));return Rules.zone((R.num(R.get(s.point(),"y"))-R.num(R.call(n,"getY")))/Math.max(.1,R.num(R.call(n,"getBbHeight"))),-dx*Math.cos(yaw)-dz*Math.sin(yaw),s.head());}
 public static void hit(Object n,Gore.Shot s,float damage,int kind){if(!Gore.zombie(n)||!Float.isFinite(damage)||damage<=0)return;if(s.bullet()==null){Object source=Ballistics11.SOURCE.get();if(source!=null){Object owner=R.call(source,"getEntity");if(owner!=null)kind=Damage13.kindOf(R.call(owner,"getMainHandItem"));}}int region=Ballistics11.zone(s);if(region==1)region=0;double h=Math.max(.1,R.num(R.call(n,"getBbHeight"))),scale=h/1.95;double yaw=Math.toRadians(R.num(R.get(n,"yBodyRot"))),dx=R.num(R.get(s.point(),"x"))-R.num(R.call(n,"getX")),dz=R.num(R.get(s.point(),"z"))-R.num(R.call(n,"getZ")),y=(R.num(R.get(s.point(),"y"))-R.num(R.call(n,"getY")))/scale;double x=(-dx*Math.cos(yaw)-dz*Math.sin(yaw))*16/scale,z=(dx*Math.sin(yaw)-dz*Math.cos(yaw))*16/scale;
 double nx,ny,nz;if(region==0){nx=x/8+.5;ny=(1.95-y)/.5;nz=z/8+.5;}else if(region>=6){nx=x/8+.5;ny=(1.45-y)/.75;nz=z/4+.5;}else{boolean arm=region<4;double center=(region==2?5:region==3?-5:region==4?2:-2);nx=(x-center)/4+.5;ny=((arm?1.45:.75)-y)/.75;nz=z/4+.5;}
 int[]a=add(get(n),new Cut(region,clamp(nx),clamp(ny),clamp(nz),radius(damage,kind,s.gun())));set(n,a);Gore.surfaceSet(n,Gore.surfaces(n)|(1<<(8+region)));Trauma12.set(n,Trauma12.withStage(Trauma12.details(n),region,Math.max(1,Trauma12.stage(Trauma12.details(n),region))));Gore.set(n,Gore.state(n)|(1<<(8+region)));if(region==4||region==5){Gore.set(n,Gore.state(n)|(1<<(26+region-2)));}
 if(region==0&&s.bullet()!=null&&brainDestroyed(a)){R.call(n,"setHealth",0f);R.call(n,"die",R.call(R.call(n,"damageSources"),"generic"));}
 }
 public static boolean detached(String name,int region,boolean left){boolean found=false;for(var p:Anatomy14.anatomy(region))if(p.name().equals(name)&&(!name.equals("eyeball")||((p.box().x0()+p.box().x1())/2<.5)==left)){found=true;var b=p.box();for(double x:new double[]{b.x0(),b.x1()})for(double y:new double[]{b.y0(),b.y1()})for(double z:new double[]{b.z0(),b.z1()})if(!covered(CURRENT.get(),region,x,y,z,.65))return false;}return found;}
 public static boolean brainDestroyed(int[]a){int count=0;for(double x:new double[]{.35,.5,.65})for(double y:new double[]{.28,.4,.52})for(double z:new double[]{.38,.55,.7})if(covered(a,0,x,y,z,.72))count++;return count>=11;}
 public static boolean covered(int[] a,int region,double x,double y,double z,double inset){for(int i=0;i<a.length;i+=2){Cut c=cut(a,i);if(c.region()!=region&&!(region==6&&c.region()==7))continue;double dx=(x-c.x())*width(region),dy=(y-c.y())*height(region),dz=(z-c.z())*depth(region),r=Math.max(0,c.radius()-inset);if(dx*dx+dy*dy+dz*dz<r*r)return true;}return false;}
 public static void dead(Object level,Object sender,int id,int part,Object impact,float damage){Object retained=Corpse13.retained(id);if(retained==null||impact==null)return;Object packet=R.get(retained,"spawnPacket"),pose=Corpse13.pose(retained,part);if(pose==null)return;Object p=R.get(pose,"position"),q=R.get(pose,"rotation");double x=R.num(R.get(impact,"x"))-R.num(R.get(p,"x")),y=R.num(R.get(impact,"y"))-R.num(R.get(p,"y")),z=R.num(R.get(impact,"z"))-R.num(R.get(p,"z"));double a=R.num(R.get(q,"x")),b=R.num(R.get(q,"y")),c=R.num(R.get(q,"z")),d=R.num(R.get(q,"w"));double X=(1-2*(b*b+c*c))*x+2*(a*b+c*d)*y+2*(a*c-b*d)*z,Y=2*(a*b-c*d)*x+(1-2*(a*a+c*c))*y+2*(b*c+a*d)*z,Z=2*(a*c+b*d)*x+2*(b*c-a*d)*y+(1-2*(a*a+b*b))*z;int region=Damage13.region(part);if(region==7)region=6;int kind=sender==null?1:Damage13.kindOf(R.call(sender,"getMainHandItem"));Cut hit=new Cut(region,clamp(.5-X*16/width(region)),clamp(.5-Y*16/height(region)),clamp(.5+Z*16/depth(region)),radius(damage,kind,Rules.Weapon.OTHER));R.set(packet,"goreCuts24",add(field(packet),hit));}
}
