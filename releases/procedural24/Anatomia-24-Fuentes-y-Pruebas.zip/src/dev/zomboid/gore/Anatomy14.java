package dev.zomboid.gore;
import java.util.*;
/** Anatomy stays in the same local frame as the damaged model part. */
public final class Anatomy14 {
 public record Piece(String name,Mesh12.Box box,int material){}
 static void add(List<Piece>p,String name,int mat,float a,float b,float c,float d,float e,float f){if(Set.of("proximal_muscle","distal_muscle","brain_lobe","left_lung","right_lung","heart","liver","stomach").contains(name)){float midX=(a+d)/2,midZ=(c+f)/2;float[]profile=name.equals("heart")?new float[]{.72f,1,.9f,.65f,.3f}:new float[]{.55f,.86f,1,.86f,.55f};for(int i=0;i<5;i++){float k=profile[i],lo=b+(e-b)*i/5,hi=Math.min(e,b+(e-b)*(i+1)/5+.0001f);p.add(new Piece(name,new Mesh12.Box(midX-(d-a)*k/2,lo,midZ-(f-c)*k/2,midX+(d-a)*k/2,hi,midZ+(f-c)*k/2),mat));}}else p.add(new Piece(name,new Mesh12.Box(a,b,c,d,e,f),mat));}
 public static List<Piece> anatomy(int region){List<Piece>p=new ArrayList<>();
 if(region==0){
 add(p,"tongue_root",1,.40f,.76f,.40f,.60f,.87f,.69f);
 add(p,"tongue",3,.35f,.78f,.22f,.65f,.84f,.46f);
 add(p,"tongue_tip",3,.40f,.79f,.16f,.60f,.84f,.25f);
 for(float x:new float[]{.28f,.68f}){add(p,"jugular",4,x,.77f,.50f,x+.045f,1,.56f);add(p,"carotid",1,x+.055f,.79f,.47f,x+.085f,1,.52f);}
 add(p,"trachea",5,.46f,.85f,.41f,.54f,1,.50f);

 add(p,"brow",2,.14f,.26f,.12f,.86f,.37f,.27f);
 add(p,"nose_bridge",2,.46f,.35f,.12f,.54f,.63f,.29f);
 add(p,"maxilla",2,.19f,.59f,.12f,.81f,.71f,.29f);
 for(float x:new float[]{.14f,.77f})add(p,"cheek",2,x,.36f,.12f,x+.09f,.65f,.3f);

 add(p,"occipital",2,.24f,.08f,.68f,.76f,.85f,.88f);add(p,"cranial_roof",2,.16f,.06f,.18f,.84f,.18f,.84f);
 for(float x:new float[]{.13f,.77f}){add(p,"temporal",2,x,.15f,.2f,x+.1f,.76f,.82f);add(p,"jaw_ramus",2,x,.67f,.18f,x+.11f,.98f,.74f);}
 add(p,"jaw_chin",2,.15f,.86f,.12f,.85f,.98f,.28f);add(p,"palate",2,.22f,.69f,.18f,.78f,.77f,.72f);add(p,"cervical",2,.41f,.75f,.6f,.59f,1,.8f);
 for(float x:new float[]{.26f,.53f}){add(p,"brain_lobe",3,x,.19f,.32f,x+.22f,.58f,.72f);add(p,"optic_stalk",1,x+.06f,.42f,.21f,x+.12f,.52f,.7f);add(p,"orbit",2,x-.02f,.33f,.16f,x+.25f,.4f,.35f);add(p,"eye_socket",4,x+.02f,.4f,.16f,x+.19f,.54f,.29f);
 add(p,"eyeball",5,x+.03f,.41f,.10f,x+.18f,.54f,.25f);
 add(p,"pupil",4,x+.08f,.45f,.095f,x+.13f,.5f,.11f);}
 for(int i=0;i<6;i++)add(p,"tooth",5,.25f+i*.08f,.76f,.14f,.30f+i*.08f,.88f,.22f);
 }else if(region==6){
 for(float x:new float[]{.29f,.67f}){
 add(p,"jugular",4,x,0,.43f,x+.04f,.14f,.52f);
 add(p,"carotid",1,x+.04f,0,.44f,x+.07f,.18f,.50f);
 add(p,"kidney",1,x,.65f,.60f,x+.11f,.79f,.76f);
 }
 add(p,"aorta",1,.47f,.15f,.53f,.51f,.91f,.60f);
 add(p,"vena_cava",4,.54f,.17f,.56f,.58f,.91f,.63f);
 add(p,"trachea",5,.47f,0,.38f,.53f,.28f,.45f);
 for(int i=0;i<6;i++)add(p,"tracheal_ring",2,.46f,i*.035f,.38f,.54f,i*.035f+.012f,.46f);
 add(p,"esophagus",3,.49f,0,.49f,.55f,.60f,.55f);
 add(p,"spine",2,.45f,0,.65f,.55f,1,.86f);add(p,"sternum",2,.46f,.13f,.16f,.54f,.62f,.3f);add(p,"clavicle",2,0,.055f,.22f,1,.14f,.73f);
 for(int i=0;i<6;i++){float y=.18f+i*.074f;for(boolean left:new boolean[]{true,false}){float x=left?.08f:.84f;add(p,"rib_posterior",2,left?.08f:.5f,y,.67f,left?.5f:.92f,y+.034f,.76f);add(p,"rib_lateral",2,x,y,.48f,x+.08f,y+.034f,.74f);add(p,"rib_curve",2,left?.11f:.81f,y,.30f,left?.19f:.89f,y+.034f,.53f);add(p,"rib_curve",2,left?.16f:.76f,y,.23f,left?.24f:.84f,y+.034f,.36f);add(p,"rib_anterior",2,left?.18f:.5f,y,.22f,left?.5f:.82f,y+.034f,.3f);}}
 add(p,"pelvis_back",2,.15f,.86f,.58f,.85f,1,.84f);add(p,"pelvis_left",2,.12f,.79f,.25f,.28f,1,.76f);add(p,"pelvis_right",2,.72f,.79f,.25f,.88f,1,.76f);add(p,"pubic_arch",2,.24f,.95f,.24f,.76f,1,.4f);
 add(p,"pectoral_left",1,.06f,.12f,.08f,.46f,.51f,.3f);
 add(p,"pectoral_right",1,.54f,.12f,.08f,.94f,.51f,.3f);
 add(p,"abdominal_wall",1,.16f,.51f,.13f,.84f,.94f,.28f);
 add(p,"mediastinum",1,.43f,.2f,.28f,.57f,.69f,.73f);add(p,"heart",1,.38f,.34f,.22f,.57f,.53f,.54f);
 add(p,"left_lung",3,.17f,.21f,.3f,.45f,.56f,.67f);add(p,"right_lung",3,.55f,.21f,.3f,.83f,.56f,.67f);
 add(p,"diaphragm",1,.16f,.55f,.25f,.84f,.6f,.71f);add(p,"liver",1,.22f,.59f,.27f,.69f,.69f,.65f);add(p,"stomach",3,.64f,.61f,.29f,.83f,.75f,.64f);
 add(p,"mesentery",1,.36f,.64f,.48f,.65f,.93f,.73f);
 for(int i=0;i<4;i++){float y=.71f+i*.055f;add(p,"bowel_loop",3,.24f,y,.27f,.77f,y+.04f,.5f);add(p,"bowel_join",3,i%2==0?.72f:.24f,y,.3f,i%2==0?.77f:.29f,y+.09f,.5f);}
 }else{
 boolean arm=region==2||region==3;
 add(p,arm?"brachial_artery":"femoral_artery",1,.24f,.05f,.48f,.29f,.94f,.54f);
 add(p,arm?"arm_vein":"leg_vein",4,.67f,.08f,.40f,.71f,.96f,.46f);
 add(p,arm?"biceps":"quadriceps",1,.15f,.12f,.11f,.40f,.45f,.35f);
 add(p,arm?"triceps":"hamstring",1,.57f,.12f,.58f,.82f,.45f,.83f);

 add(p,"proximal_joint",2,0,0,.23f,1,.12f,.77f);add(p,"upper_bone",2,.41f,.08f,.43f,.59f,.51f,.62f);add(p,"joint",2,.34f,.46f,.34f,.66f,.57f,.7f);
 for(float x:new float[]{.32f,.55f})add(p,arm?"radius_ulna":"tibia_fibula",2,x,.53f,.43f,x+.13f,.93f,.59f);
 add(p,"distal_joint",2,.26f,.88f,.26f,.74f,1,.75f);
 add(p,"tendon",1,.4f,0,.26f,.6f,1,.47f);
 add(p,"proximal_muscle",1,.23f,.12f,.22f,.77f,.43f,.5f);add(p,"distal_muscle",1,.27f,.57f,.22f,.73f,.85f,.47f);
 if(arm)for(int i=0;i<4;i++)add(p,"metacarpal",2,.28f+i*.12f,.93f,.21f,.35f+i*.12f,1,.59f);
 }
 p.removeIf(Anatomy14::bone);Skeleton17.add(p,region);
 add(p,"posterior_fascia",1,.45f,0,.82f,.55f,1,.96f);return List.copyOf(p);}
 static boolean bone(Piece p){return p.material()==2||p.name().equals("tooth")||p.name().equals("socket_shadow");}
 static boolean organ(Piece p){return Set.of("brain_lobe","left_lung","right_lung","heart","liver","stomach","bowel_loop","bowel_join","mesentery","diaphragm","mediastinum","optic_stalk","eyeball","pupil").contains(p.name());}
 static List<Piece> layer(int region,int level){
 List<Piece> out=new ArrayList<>();if(level>=7)return out;
 for(Piece p:anatomy(region)){
  Mesh12.Box b=p.box();boolean hard=bone(p),inside=organ(p);
  if(level>=3&&Set.of("eyeball","pupil","optic_stalk","heart","liver","stomach").contains(p.name()))continue;
  if(!hard&&!inside&&level>=3)continue;
  if(inside&&level>=4)continue;
  // At the open-wound tier the eye and bowel slump out on attached tissue.
  if(level==2&&(p.name().equals("eyeball")||p.name().equals("pupil"))){b=new Mesh12.Box(b.x0(),b.y0()+.08f,b.z0()-.12f,b.x1(),b.y1()+.08f,b.z1()-.12f);}
  if(level==2&&p.name().equals("optic_stalk"))b=new Mesh12.Box(b.x0(),.42f,-.02f,b.x1(),.6f,.7f);
  if(level==3&&region==6&&p.name().startsWith("bowel"))b=new Mesh12.Box(b.x0(),b.y0(),.10f,b.x1(),b.y1(),b.z1());
  if(hard&&level>=5){
   // Successive cuts consume every bone, including jaw, spine and joints.
   float edge=level==5?.65f:.50f;
   if(b.x0()>=edge)continue;
   b=new Mesh12.Box(b.x0(),b.y0(),b.z0(),Math.min(b.x1(),edge),b.y1(),b.z1());
  }
  out.add(new Piece(p.name(),b,p.material()));
 }
 return out;
 }
 public static List<Piece> damaged(int region,int stage){
 if(region!=6)return layer(region,stage&7);
 List<Piece>out=new ArrayList<>();int[]levels={stage&7,(stage>>5)&7};
 for(int side=0;side<2;side++)for(Piece p:layer(region,levels[side])){if(Set.of("heart","liver","stomach").contains(p.name())&&levels[p.name().equals("stomach")?0:1]>=3)continue;Mesh12.Box b=p.box();float lo=Math.max(b.x0(),side==0?.5f:0),hi=Math.min(b.x1(),side==0?1:.5f);if(hi>lo)out.add(new Piece(p.name(),new Mesh12.Box(lo,b.y0(),b.z0(),hi,b.y1(),b.z1()),p.material()));}
 return out;
 }
 static Mesh12.Box scale(Mesh12.Box p,Mesh12.Box b){float w=b.x1()-b.x0(),h=b.y1()-b.y0(),d=b.z1()-b.z0();return new Mesh12.Box(b.x0()+p.x0()*w,b.y0()+p.y0()*h,b.z0()+p.z0()*d,b.x0()+p.x1()*w,b.y0()+p.y1()*h,b.z0()+p.z1()*d);}
 public static List<Mesh12.Quad> build(List<Mesh12.Cube> cubes,int region,int stage){return Surface19.build(cubes,region,stage);}
}
