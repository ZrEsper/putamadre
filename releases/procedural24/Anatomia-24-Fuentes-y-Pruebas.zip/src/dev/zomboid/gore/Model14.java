package dev.zomboid.gore;
import java.util.*;
/** Distinguish anatomical roots from decorative descendants in EMF hierarchies. */
public final class Model14 {
 static final Map<Object,Boolean> ROOTS=new WeakHashMap<>(),BOUND=new WeakHashMap<>();static final ThreadLocal<Object> PART=new ThreadLocal<>();
 public static void bind(Object model){if(BOUND.putIfAbsent(model,true)!=null)return;String[]main={"head","body","leftArm","rightArm","leftLeg","rightLeg"},outer={"hat","jacket","leftSleeve","rightSleeve","leftPants","rightPants"};for(int i=0;i<main.length;i++)try{Object p=R.get(model,main[i]);if(p!=null){ROOTS.put(p,true);Object owner=Owner20.resolve(p,main[i]);if(owner!=null)ROOTS.put(owner,true);if(owner==null||!Surface19.readable(owner)){Object layer=R.get(model,outer[i]);if(layer!=null){Object fallback=Owner20.resolve(layer,main[i]);if(fallback!=null&&Surface19.readable(fallback)){ROOTS.put(layer,true);ROOTS.put(fallback,true);}}}}}catch(RuntimeException optional){}}

 public static void part(Object part){PART.set(part);}public static void end(){PART.remove();}
 static boolean skin(){Object p=PART.get();if(p==null)return true;try{Object cubes=R.get(p,"cubes");return cubes instanceof List<?> l&&!l.isEmpty();}catch(RuntimeException missing){return false;}}
 static boolean internal(){Object p=PART.get();return p==null||ROOTS.containsKey(p);}
 public static void children(Object part,Object pose,Object vertex,int light,int overlay,int color){Object children;try{children=R.get(part,"children");}catch(RuntimeException absent){return;}if(!(children instanceof Map<?,?>map)||map.isEmpty())return;R.call(pose,"pushPose");try{R.call(part,"translateAndRotate",pose);for(Object child:map.values())R.call(child,"render",pose,vertex,light,overlay,color);}finally{R.call(pose,"popPose");}}
}
