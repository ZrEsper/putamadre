from pathlib import Path
import subprocess,json
r=Path(__file__).resolve().parent;g=r/'output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-procedural-anatomy.24.jar';rag=r/'output/ragdollified-1.21.1-1.1.5-procedural-anatomy.20.jar';out=r/'build/test';out.mkdir(exist_ok=True)
exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{s}=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']]
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(g),'-d',str(out),*map(str,(r/'tests').rglob('*.java'))],check=True)
subprocess.run(['java',*exports,'com.sun.tools.javac.Main',*exports,'-d',str(out),str(r/'Inspect.java')],check=True)
results=[]
for args in [['java','-Xverify:all','-cp',str(out)+':'+str(g),'dev.zomboid.gore.Checks24',str(r/'geometry.json')],['java',*exports,'-cp',str(out),'Inspect',str(g),str(rag)]]:
 p=subprocess.run(args,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
(r/'test-results.json').write_text(json.dumps({'results':results,'minecraft_runtime_tested':False},indent=2)+'\n')
