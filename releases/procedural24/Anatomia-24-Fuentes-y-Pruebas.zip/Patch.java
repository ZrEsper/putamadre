import java.nio.file.*;import java.util.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;import jdk.internal.org.objectweb.asm.tree.analysis.*;
public class Patch implements Opcodes {
 static final String G="dev/zomboid/gore/";static int changes;
 static Map<String,byte[]>read(String p)throws Exception{var out=new TreeMap<String,byte[]>();try(var z=new ZipFile(p)){for(var e:Collections.list(z.entries()))out.put(e.getName(),z.getInputStream(e).readAllBytes());}return out;}
 static void write(String p,Map<String,byte[]>e)throws Exception{try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(p)))){for(var a:e.entrySet()){var n=new ZipEntry(a.getKey());n.setTime(0);z.putNextEntry(n);z.write(a.getValue());z.closeEntry();}}}
 static MethodInsnNode call(String c,String m,String d){return new MethodInsnNode(INVOKESTATIC,G+c,m,d,false);}
 static InsnList args(int...slots){var l=new InsnList();for(int s:slots)l.add(new VarInsnNode(ALOAD,s));return l;}
 static void end(MethodNode m,InsnList code){for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN){m.instructions.insertBefore(n,copy(code));changes++;}}
 static InsnList copy(InsnList l){var out=new InsnList();for(var n:l)out.add(n.clone(new HashMap<>()));return out;}
 static void tail(MethodNode m,String cls,String name,String desc,int...slots){var l=args(slots);l.add(call(cls,name,desc));end(m,l);}
 static void save(Map<String,byte[]>jar,String path,ClassNode c){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);jar.put(path,w.toByteArray());}
 public static void main(String[]a)throws Exception{var gore=read(a[0]);var rag=read(a[1]);
 for(var e:new ArrayList<>(gore.entrySet())){if(!e.getKey().endsWith(".class")||!e.getKey().startsWith(G))continue;ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);String name=c.name.substring(G.length());for(var m:c.methods){
 if(name.equals("Gore")){switch(m.name){case "init":tail(m,"Cuts24","init","()V");break;case "define":tail(m,"Cuts24","define","(Ljava/lang/Object;)V",0);break;case "save":case "restore":tail(m,"Cuts24",m.name,"(Ljava/lang/Object;Ljava/lang/Object;)V",0,1);break;}}
 if(name.equals("Ballistics11")&&m.name.equals("zone")){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(call("Cuts24","zone",m.desc));m.instructions.add(new InsnNode(IRETURN));changes++;}
 if(name.equals("Trauma13")&&m.name.equals("injure")){var l=args(0,1);l.add(new VarInsnNode(FLOAD,2));l.add(new VarInsnNode(ILOAD,3));l.add(call("Cuts24","hit","(Ljava/lang/Object;Ldev/zomboid/gore/Gore$Shot;FI)V"));m.instructions.insert(l);changes++;}
 if(name.equals("Trauma12")&&m.name.equals("packet"))tail(m,"Cuts24","packet","(Ljava/lang/Object;Ljava/lang/Object;)V",0,1);
 if(name.equals("Trauma12")&&m.name.equals("snapshot"))tail(m,"Cuts24","copy","(Ljava/lang/Object;Ljava/lang/Object;)V",0,1);
 if(name.equals("Skin12")){if(m.name.equals("living"))tail(m,"Cuts24","living","(Ljava/lang/Object;)V",1);if(m.name.equals("ragdoll")){tail(m,"Cuts24","ragdoll","(Ljava/lang/Object;)V",0);tail(m,"Foley24","ragdoll","(Ljava/lang/Object;)V",0);}if(m.name.equals("end"))tail(m,"Cuts24","clear","()V");if(m.name.equals("renderSurface19")){var l=args(0);l.add(call("Cuts24","prepare","(Ljava/lang/Object;)V"));m.instructions.insert(l);changes++;}}
 if(name.equals("Skin12")&&(m.name.startsWith("lambda$renderSurface19$")||m.name.startsWith("lambda$render$"))){for(var n:m.instructions.toArray()){if(n instanceof TypeInsnNode t&&t.getOpcode()==NEW&&t.desc.equals("java/util/HashMap")){t.desc=G+"MeshCache24";changes++;}if(n instanceof MethodInsnNode i&&i.owner.equals("java/util/HashMap")&&i.name.equals("<init>"))i.owner=G+"MeshCache24";}}
 for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode i&&i.owner.equals(G+"Anatomy14")&&i.name.equals("build")){i.owner=G+"CSG24";i.name="mesh";changes++;}
 }save(gore,e.getKey(),c);}
 int fields=0,enc=0,dec=0,centers=0;
 for(var e:new ArrayList<>(rag.entrySet())){if(!e.getKey().endsWith(".class")||!e.getKey().startsWith("com/raiiiden/"))continue;ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);String simple=c.name.substring(c.name.lastIndexOf('/')+1);boolean packets=Set.of("RagdollSpawnPacket","RagdollImpulsePacket").contains(simple);if(packets||simple.equals("ClientRagdoll")||simple.equals("ClientRagdoll$SpawnData")){c.fields.add(new FieldNode(ACC_PUBLIC|ACC_VOLATILE,"goreCuts24","[I",null,null));fields++;}
 for(var m:c.methods){
  if(packets&&m.name.equals("encode")){tail(m,"Cuts24","write","(Ljava/lang/Object;Ljava/lang/Object;)V",0,1);enc++;}
  if(packets&&m.name.equals("decode")){for(var n:m.instructions.toArray())if(n.getOpcode()==ARETURN){InsnList l=new InsnList();l.add(new InsnNode(DUP));l.add(new VarInsnNode(ALOAD,0));l.add(call("Cuts24","read","(Ljava/lang/Object;Ljava/lang/Object;)V"));m.instructions.insertBefore(n,l);}dec++;}
  if(simple.equals("ModNetwork"))for(var n:m.instructions)if(n instanceof LdcInsnNode l&&l.cst instanceof String s&&s.contains("gore13")){l.cst="16-procedural24";changes++;}
  if(simple.equals("ClientRagdollRenderer")&&(m.name.equals("renderHumanoidPartPhysics")||m.name.equals("renderHumanoidPartPhysicsTinted"))&&Type.getArgumentTypes(m.desc).length>=8){for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode i&&i.owner.equals("net/minecraft/client/model/geom/ModelPart")&&i.name.equals("render")){var l=args(2,6);l.add(call("Center24","align","(Ljava/lang/Object;Ljava/lang/Object;)V"));m.instructions.insertBefore(n,l);centers++;}}
 }save(rag,e.getKey(),c);}
 if(fields!=4||enc!=2||dec!=2||centers!=2)throw new AssertionError(fields+"/"+enc+"/"+dec+"/"+centers);
 try(var walk=Files.walk(Path.of(a[2]))){for(var p:walk.filter(p->p.toString().endsWith(".class")).toList())gore.put(Path.of(a[2]).relativize(p).toString(),Files.readAllBytes(p));}
 // Keep the existing declared Gore version so optional exact-version consumers remain compatible.
 for(var jar:List.of(gore,rag))for(var e:jar.entrySet())if(e.getKey().endsWith(".class")&&(e.getKey().startsWith(G)||e.getKey().startsWith("com/raiiiden/"))){ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);for(var m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);}
 write(a[3],gore);write(a[4],rag);System.out.println("PROCEDURAL24_HOOKS="+changes+" FIELDS="+fields+" CODECS="+enc+"/"+dec+" TORSO="+centers);
 }
}
