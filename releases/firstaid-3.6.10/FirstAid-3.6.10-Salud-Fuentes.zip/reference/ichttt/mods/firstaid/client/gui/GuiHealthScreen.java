/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dev.zomboid.firstaid.InjuryGrid20
 *  ichttt.mods.firstaid.FirstAid
 *  ichttt.mods.firstaid.api.damagesystem.AbstractDamageablePart
 *  ichttt.mods.firstaid.api.damagesystem.AbstractPlayerDamageModel
 *  ichttt.mods.firstaid.api.enums.EnumPlayerPart
 *  ichttt.mods.firstaid.api.healing.ItemHealing
 *  ichttt.mods.firstaid.api.medicine.MedicineStatusDisplay
 *  ichttt.mods.firstaid.client.ClientEventHandler
 *  ichttt.mods.firstaid.client.ClientHooks
 *  ichttt.mods.firstaid.client.MedicineStatusClientHelper
 *  ichttt.mods.firstaid.client.gui.GuiHealthScreen$RowHit
 *  ichttt.mods.firstaid.client.gui.HomeostasisView
 *  ichttt.mods.firstaid.client.gui.HomeostasisView$Values
 *  ichttt.mods.firstaid.client.gui.SkillsPanel
 *  ichttt.mods.firstaid.client.gui.SurvivalButton
 *  ichttt.mods.firstaid.client.gui.SurvivalLayout
 *  ichttt.mods.firstaid.client.gui.SurvivorSkillsView
 *  ichttt.mods.firstaid.common.network.MessageApplyHealingItem
 *  ichttt.mods.firstaid.common.util.CommonUtils
 *  ichttt.mods.firstaid.compat.lrtactical.TreatmentV33
 *  ichttt.mods.firstaid.fracture.Bleeding
 *  ichttt.mods.firstaid.fracture.Fractures
 *  ichttt.mods.firstaid.survival.ClinicalData
 *  ichttt.mods.firstaid.survival.ClinicalHooks
 *  ichttt.mods.firstaid.survival.ClinicalState
 *  ichttt.mods.firstaid.survival.ClinicalState$Wound
 *  ichttt.mods.firstaid.survival.WetClient
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.gui.components.Button
 *  net.minecraft.client.gui.components.events.GuiEventListener
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.FormattedText
 *  net.minecraft.network.protocol.common.custom.CustomPacketPayload
 *  net.minecraft.util.FormattedCharSequence
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.ai.attributes.Attributes
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.ItemLike
 */
package ichttt.mods.firstaid.client.gui;

import dev.zomboid.firstaid.HealthTab40;
import dev.zomboid.firstaid.InjuryGrid20;
import ichttt.mods.firstaid.FirstAid;
import ichttt.mods.firstaid.api.damagesystem.AbstractDamageablePart;
import ichttt.mods.firstaid.api.damagesystem.AbstractPlayerDamageModel;
import ichttt.mods.firstaid.api.enums.EnumPlayerPart;
import ichttt.mods.firstaid.api.healing.ItemHealing;
import ichttt.mods.firstaid.api.medicine.MedicineStatusDisplay;
import ichttt.mods.firstaid.client.ClientEventHandler;
import ichttt.mods.firstaid.client.ClientHooks;
import ichttt.mods.firstaid.client.MedicineStatusClientHelper;
import ichttt.mods.firstaid.client.gui.GuiHealthScreen;
import ichttt.mods.firstaid.client.gui.HomeostasisView;
import ichttt.mods.firstaid.client.gui.SkillsPanel;
import ichttt.mods.firstaid.client.gui.SurvivalButton;
import ichttt.mods.firstaid.client.gui.SurvivalLayout;
import ichttt.mods.firstaid.client.gui.SurvivorSkillsView;
import ichttt.mods.firstaid.common.network.MessageApplyHealingItem;
import ichttt.mods.firstaid.common.util.CommonUtils;
import ichttt.mods.firstaid.compat.lrtactical.TreatmentV33;
import ichttt.mods.firstaid.fracture.Bleeding;
import ichttt.mods.firstaid.fracture.Fractures;
import ichttt.mods.firstaid.survival.ClinicalData;
import ichttt.mods.firstaid.survival.ClinicalHooks;
import ichttt.mods.firstaid.survival.ClinicalState;
import ichttt.mods.firstaid.survival.WetClient;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;

public class GuiHealthScreen
extends Screen {
    public static final int xSize = 450;
    public static final int ySize = 310;
    public static final ItemStack BED_ITEMSTACK = new ItemStack((ItemLike)Items.RED_BED);
    public static GuiHealthScreen INSTANCE;
    public static boolean isOpen;
    private static int funTicks;
    private final AbstractPlayerDamageModel damageModel;
    public int guiLeft;
    public int guiTop;
    public Button cancelButton;
    private SurvivalLayout layout;
    private SurvivalButton treatment;
    private final SurvivorSkillsView survivorSkills = new SurvivorSkillsView();
    private final List<SurvivalButton> tabs = new ArrayList<SurvivalButton>();
    private int tab = 2;
    private int scroll;
    private int contentHeight;
    private EnumPlayerPart selected = EnumPlayerPart.BODY;
    private HomeostasisView.Values temperature;
    private int lastTemperatureTick = Integer.MIN_VALUE;
    private final List<RowHit> rowHits = new ArrayList<RowHit>();
    private static final String[] TAB_NAMES;
    private static final EnumPlayerPart[] PARTS;
    private static final String[] PART_NAMES;
    private static final int TEXT = -2170409;
    private static final int MUTED = -6511979;
    private static final int GOLD = -2963554;
    private static final int GREEN = -7227269;
    private static final int RED = -2132880;
    private double bodyScale;
    private double bodyX;
    private double bodyY;

    static {
        TAB_NAMES = new String[]{"Info", "Habilidades", "Salud", "Protecci\u00f3n", "Temperatura"};
        PARTS = new EnumPlayerPart[]{EnumPlayerPart.HEAD, EnumPlayerPart.BODY, EnumPlayerPart.LEFT_ARM, EnumPlayerPart.RIGHT_ARM, EnumPlayerPart.LEFT_LEG, EnumPlayerPart.RIGHT_LEG, EnumPlayerPart.LEFT_FOOT, EnumPlayerPart.RIGHT_FOOT};
        PART_NAMES = new String[]{"Cabeza", "Torso", "Brazo izquierdo", "Brazo derecho", "Pierna izquierda", "Pierna derecha", "Pie izquierdo", "Pie derecho"};
    }

    public GuiHealthScreen(AbstractPlayerDamageModel abstractPlayerDamageModel) {
        this(abstractPlayerDamageModel, null);
    }

    public GuiHealthScreen(AbstractPlayerDamageModel abstractPlayerDamageModel, InteractionHand interactionHand) {
        super((Component)Component.translatable((String)"firstaid.gui.healthscreen", (Object[])new Object[0]));
        this.damageModel = abstractPlayerDamageModel;
    }

    public static void tickFun() {
        if (++funTicks > 500) {
            funTicks = 0;
        }
    }

    protected void init() {
        isOpen = true;
        this.layout = new SurvivalLayout(this.width, this.height);
        this.guiLeft = this.layout.left;
        this.guiTop = this.layout.top;
        this.tabs.clear();
        int n = this.guiLeft + 8;
        int n2 = this.layout.width - 16;
        boolean bl = this.layout.width < 360;
        int n3 = 0;
        while (n3 < 5) {
            int n4;
            int n5;
            int n6 = n3;
            n5 = bl ? (n3 < 3 ? 0 : 1) : 0;
            n4 = bl ? (n5 == 0 ? 3 : 2) : 5;
            int n9 = bl ? (n5 == 0 ? n3 : n3 - 3) : n3;
            int n10 = n2 / n4;
            SurvivalButton survivalButton = new SurvivalButton(n + n9 * n10, this.guiTop + (bl ? 4 : 23) + n5 * 20, n10 - 2, 19, (Component)Component.literal((String)TAB_NAMES[n3]), button -> {
                this.tab = n6;
                this.scroll = 0;
            });
            this.tabs.add((SurvivalButton)this.addRenderableWidget((GuiEventListener)survivalButton));
            ++n3;
        }
        this.cancelButton = (Button)this.addRenderableWidget((GuiEventListener)new SurvivalButton(this.guiLeft + 8, this.guiTop + this.layout.height - 24, this.layout.split - 16, 18, (Component)Component.literal((String)"Cerrar"), button -> this.onClose()));
        this.treatment = (SurvivalButton)this.addRenderableWidget((GuiEventListener)new SurvivalButton(this.layout.rightX, this.guiTop + this.layout.height - 24, this.layout.rightWidth, 18, (Component)Component.literal((String)"Tratar parte"), button -> this.applyHealing(this.selected)));
    }

    private AbstractPlayerDamageModel live() {
        AbstractPlayerDamageModel abstractPlayerDamageModel;
        if (this.minecraft != null && this.minecraft.player != null && (abstractPlayerDamageModel = CommonUtils.getDamageModel((Player)this.minecraft.player)) != null) {
            return abstractPlayerDamageModel;
        }
        return this.damageModel;
    }

    private InteractionHand v34NativeTreatmentHand(EnumPlayerPart enumPlayerPart) {
        if (this.minecraft == null || this.minecraft.player == null) {
            return null;
        }
        ClinicalState.Wound wound = ClinicalData.state((AbstractPlayerDamageModel)this.live()).wounds[enumPlayerPart.ordinal()];
        InteractionHand[] interactionHandArray = InteractionHand.values();
        int n = interactionHandArray.length;
        int n2 = 0;
        while (n2 < n) {
            InteractionHand interactionHand = interactionHandArray[n2];
            ItemStack itemStack = this.minecraft.player.getItemInHand(interactionHand);
            if (wound.active()) {
                if (wound.bullets > 0 && ClinicalHooks.extraction((ItemStack)itemStack)) {
                    return interactionHand;
                }
                if (wound.canBandage() && ClinicalHooks.dressing((ItemStack)itemStack)) {
                    return interactionHand;
                }
            } else if (itemStack.getItem() instanceof ItemHealing && this.live().getFromEnum((EnumPlayerPart)enumPlayerPart).activeHealer == null && !CommonUtils.isPartVisuallyFull((AbstractDamageablePart)this.live().getFromEnum(enumPlayerPart))) {
                return interactionHand;
            }
            ++n2;
        }
        return null;
    }

    private boolean canTreat(AbstractDamageablePart abstractDamageablePart) {
        return this.treatmentHand(this.selected) != null;
    }

    private void applyHealing(EnumPlayerPart enumPlayerPart) {
        if (!InjuryGrid20.canTreat((Object)((Object)this), (Object)enumPlayerPart)) {
            return;
        }
        InteractionHand interactionHand = this.treatmentHand(enumPlayerPart);
        if (interactionHand == null) {
            return;
        }
        if (TreatmentV33.isClinical((Object)ClinicalData.state((AbstractPlayerDamageModel)this.live()).wounds[enumPlayerPart.ordinal()])) {
            TreatmentV33.clientBegin((Object)((Object)this), (Object)interactionHand);
            FirstAid.NETWORKING.sendToServer((CustomPacketPayload)new MessageApplyHealingItem(enumPlayerPart, interactionHand));
            this.onClose();
        } else if (ClientEventHandler.selectPendingHealing((EnumPlayerPart)enumPlayerPart, (InteractionHand)interactionHand)) {
            this.onClose();
        }
    }

    private String treatmentLabel() {
        return TreatmentV33.treatmentLabel((Object)((Object)this));
    }

    public void render(GuiGraphics guiGraphics, int n, int n2, float f) {
        if (HealthTab40.active((Object)this)) {
            HealthTab40.render((Object)this, guiGraphics, n, n2, f);
            return;
        }
        if (this.layout == null) {
            SkillsPanel.tooltip((Object)((Object)this), (GuiGraphics)guiGraphics, (int)n, (int)n2);
            return;
        }
        AbstractPlayerDamageModel abstractPlayerDamageModel = this.live();
        if (this.minecraft != null && this.minecraft.player != null && (this.lastTemperatureTick == Integer.MIN_VALUE || this.minecraft.player.tickCount - this.lastTemperatureTick >= 10)) {
            this.temperature = (HomeostasisView.Values)WetClient.homeostasis((Object)this.minecraft.player);
            this.lastTemperatureTick = this.minecraft.player.tickCount;
        }
        this.rowHits.clear();
        guiGraphics.fill(0, 0, this.width, this.height, -2013265920);
        guiGraphics.fill(this.guiLeft - 1, this.guiTop - 1, this.guiLeft + this.layout.width + 1, this.guiTop + this.layout.height + 1, -9603995);
        guiGraphics.fill(this.guiLeft, this.guiTop, this.guiLeft + this.layout.width, this.guiTop + this.layout.height, -234090483);
        if (this.layout.width >= 360) {
            this.text(guiGraphics, "SUPERVIVIENTE", this.guiLeft + 10, this.guiTop + 8, -2963554, this.layout.width - 20);
        }
        guiGraphics.fill(this.guiLeft + this.layout.split, this.layout.contentTop - 2, this.guiLeft + this.layout.split + 1, this.layout.contentBottom, -13354190);
        int n3 = 0;
        while (n3 < this.tabs.size()) {
            this.tabs.get((int)n3).selected = this.tab == n3;
            ++n3;
        }
        this.treatment.visible = this.tab == 2;
        this.treatment.active = this.canTreat(abstractPlayerDamageModel.getFromEnum(this.selected));
        this.treatment.setMessage((Component)Component.literal((String)this.treatmentLabel()));
        this.drawBody(guiGraphics, abstractPlayerDamageModel);
        n3 = this.layout.rightX;
        int n4 = this.layout.contentTop - this.scroll;
        guiGraphics.enableScissor(n3, this.layout.contentTop, n3 + this.layout.rightWidth, this.layout.contentBottom);
        switch (this.tab) {
            case 0: {
                n4 = this.info(guiGraphics, abstractPlayerDamageModel, n3, n4);
                break;
            }
            case 1: {
                n4 = this.skills(guiGraphics, n3, n4);
                break;
            }
            case 2: {
                n4 = this.health(guiGraphics, abstractPlayerDamageModel, n3, n4);
                break;
            }
            case 3: {
                n4 = this.protection(guiGraphics, n3, n4);
                break;
            }
            case 4: {
                n4 = this.thermal(guiGraphics, n3, n4);
            }
        }
        guiGraphics.disableScissor();
        this.contentHeight = n4 - (this.layout.contentTop - this.scroll) + 5;
        this.scroll = Math.min(this.scroll, this.layout.scrollLimit(this.contentHeight));
        int n5 = this.layout.scrollLimit(this.contentHeight);
        if (n5 > 0) {
            int n6 = this.layout.viewHeight();
            int n7 = Math.max(12, n6 * n6 / this.contentHeight);
            int n8 = this.layout.contentTop + (n6 - n7) * this.scroll / n5;
            guiGraphics.fill(this.guiLeft + this.layout.width - 5, this.layout.contentTop, this.guiLeft + this.layout.width - 3, this.layout.contentBottom, -14406878);
            guiGraphics.fill(this.guiLeft + this.layout.width - 5, n8, this.guiLeft + this.layout.width - 3, n8 + n7, -7498111);
        }
        super.render(guiGraphics, n, n2, f);
        SkillsPanel.tooltip((Object)((Object)this), (GuiGraphics)guiGraphics, (int)n, (int)n2);
    }

    private int health(GuiGraphics guiGraphics, AbstractPlayerDamageModel abstractPlayerDamageModel, int n, int n2) {
        return TreatmentV33.grid((Object)((Object)this), (Object)guiGraphics, (Object)abstractPlayerDamageModel, (int)n, (int)n2);
    }

    private List<String> v33NativeInjuries(AbstractDamageablePart abstractDamageablePart) {
        ArrayList<String> arrayList = new ArrayList<String>();
        ClinicalState.Wound wound = ClinicalData.state((AbstractPlayerDamageModel)this.live()).wounds[abstractDamageablePart.part.ordinal()];
        if (wound.gunshot) {
            arrayList.add("Herida por disparo");
        }
        if (wound.bullets > 0) {
            arrayList.add((String)(wound.bullets == 1 ? "Bala alojada" : wound.bullets + " balas alojadas"));
        }
        if (wound.cut) {
            arrayList.add("Cortadura");
        }
        if (this.minecraft != null && this.minecraft.player != null) {
            if (Bleeding.isBleeding((LivingEntity)this.minecraft.player, (EnumPlayerPart)abstractDamageablePart.part)) {
                arrayList.add("Sangrado");
            }
            if (abstractDamageablePart.part == EnumPlayerPart.LEFT_LEG || abstractDamageablePart.part == EnumPlayerPart.RIGHT_LEG) {
                boolean bl;
                boolean bl2 = bl = abstractDamageablePart.part == EnumPlayerPart.LEFT_LEG;
                if (Fractures.isBroken((LivingEntity)this.minecraft.player, (boolean)bl)) {
                    arrayList.add("Fractura");
                }
                if (Fractures.isSplinted((LivingEntity)this.minecraft.player, (boolean)bl)) {
                    arrayList.add("F\u00e9rula: " + GuiHealthScreen.duration(Fractures.splintTicksLeft((LivingEntity)this.minecraft.player, (boolean)bl)));
                }
            }
        }
        if (wound.bandaged) {
            arrayList.add("Vendaje aplicado");
        }
        if (wound.bandaged && wound.healingLeft > 0) {
            arrayList.add("Cicatrizando: " + GuiHealthScreen.duration(wound.healingLeft));
        }
        if (abstractDamageablePart.activeHealer != null && !wound.bandaged) {
            arrayList.add("En tratamiento");
        }
        if (arrayList.isEmpty() && abstractDamageablePart.currentHealth < (float)abstractDamageablePart.getMaxHealth() - 0.01f) {
            arrayList.add("Lesi\u00f3n");
        }
        return arrayList;
    }

    private int wetnessNativeStatus(GuiGraphics guiGraphics, AbstractPlayerDamageModel abstractPlayerDamageModel, int n, int n2) {
        if (abstractPlayerDamageModel.isCriticalConditionActive()) {
            n2 = this.line(guiGraphics, "Condici\u00f3n cr\u00edtica", n, n2, -2132880);
        }
        if (abstractPlayerDamageModel.getUnconsciousTicks() > 0) {
            n2 = this.line(guiGraphics, "Inconsciente: " + GuiHealthScreen.duration(abstractPlayerDamageModel.getUnconsciousTicks()), n, n2, -2132880);
        }
        if (abstractPlayerDamageModel.getPainLevel() > 0) {
            n2 = this.line(guiGraphics, "Dolor: " + abstractPlayerDamageModel.getPainLevel() + " / 5", n, n2, -2132880);
        }
        if (abstractPlayerDamageModel.getAdrenalineLevel() > 0) {
            n2 = this.line(guiGraphics, "Adrenalina: " + abstractPlayerDamageModel.getAdrenalineLevel(), n, n2, -2963554);
        }
        if (this.minecraft != null && this.minecraft.player != null) {
            for (MedicineStatusDisplay medicineStatusDisplay : MedicineStatusClientHelper.collect((Player)this.minecraft.player)) {
                n2 = this.wrapped(guiGraphics, medicineStatusDisplay.getText().getString(), n, n2, 0xFF000000 | medicineStatusDisplay.getColor());
            }
        }
        return n2;
    }

    private int wetnessNativeThermal(GuiGraphics guiGraphics, int n, int n2) {
        n2 = this.heading(guiGraphics, "Temperatura", n, n2);
        if (this.temperature == null) {
            return this.wrapped(guiGraphics, "Homeostatic: datos de temperatura no disponibles todav\u00eda.", n, n2, -6511979);
        }
        String string = this.temperature.fahrenheit() ? " \u00b0F" : " \u00b0C";
        int n3 = GuiHealthScreen.thermalColor(this.temperature.rawCore());
        n2 = this.line(guiGraphics, HomeostasisView.status((float)this.temperature.rawCore()), n, n2, n3);
        n2 += 6;
        n2 = this.metric(guiGraphics, "Corporal", String.format(Locale.ROOT, "%.1f%s", this.temperature.core(), string), n, n2, n3);
        n2 = this.metric(guiGraphics, "Piel", String.format(Locale.ROOT, "%.1f%s", this.temperature.skin(), string), n, n2, -2170409);
        n2 = this.metric(guiGraphics, "Ambiente", String.format(Locale.ROOT, "%.1f%s", this.temperature.ambient(), string), n, n2, -2170409);
        n2 += 8;
        n2 = this.heading(guiGraphics, "Hidrataci\u00f3n", n, n2);
        n2 = this.line(guiGraphics, Math.round(this.temperature.water() * 100.0) + " %", n, n2, -7227269);
        this.bar(guiGraphics, n, n2, this.layout.rightWidth - 9, 6, this.temperature.water(), -9787722);
        n2 += 15;
        n2 = this.heading(guiGraphics, "Humedad corporal", n, n2);
        n2 = this.line(guiGraphics, Math.round(WetClient.humidity() * 100.0) + " %", n, n2, -2170409);
        this.bar(guiGraphics, n, n2, this.layout.rightWidth - 9, 6, WetClient.humidity(), -10185042);
        return this.wrapped(guiGraphics, "La silueta muestra la temperatura corporal global. Homeostatic no calcula una temperatura distinta para cada extremidad.", n, n2 += 17, -6511979);
    }

    private int protection(GuiGraphics guiGraphics, int n, int n2) {
        n2 = this.heading(guiGraphics, "Protecci\u00f3n", n, n2);
        if (this.minecraft == null || this.minecraft.player == null) {
            return n2;
        }
        n2 = this.line(guiGraphics, "Defensa total: " + this.minecraft.player.getArmorValue(), n, n2, -2963554);
        n2 = this.line(guiGraphics, String.format(Locale.ROOT, "Tenacidad: %.1f", this.minecraft.player.getAttributeValue(Attributes.ARMOR_TOUGHNESS)), n, n2, -2170409);
        n2 += 5;
        EnumPlayerPart[] enumPlayerPartArray = PARTS;
        int n3 = PARTS.length;
        int n4 = 0;
        while (n4 < n3) {
            EnumPlayerPart enumPlayerPart = enumPlayerPartArray[n4];
            ItemStack itemStack = this.minecraft.player.getItemBySlot(enumPlayerPart.slot);
            n2 = this.heading(guiGraphics, GuiHealthScreen.partName(enumPlayerPart), n, n2);
            if (itemStack.isEmpty()) {
                n2 = this.line(guiGraphics, "Sin armadura", n, n2, -6511979);
            } else {
                n2 = this.wrapped(guiGraphics, itemStack.getHoverName().getString(), n, n2, -2170409);
                if (itemStack.isDamageableItem()) {
                    double d = SurvivalLayout.clamp((double)(1.0 - (double)itemStack.getDamageValue() / (double)Math.max(1, itemStack.getMaxDamage())), (double)0.0, (double)1.0);
                    n2 = this.line(guiGraphics, "Durabilidad: " + Math.round(d * 100.0) + " %", n, n2, -6511979);
                    this.bar(guiGraphics, n, n2, this.layout.rightWidth - 9, 4, d, GuiHealthScreen.healthColor(d));
                    n2 += 10;
                }
            }
            ++n4;
        }
        return this.wrapped(guiGraphics, "La armadura del torso cubre los brazos; las grebas, las piernas; las botas, los pies. La defensa no equivale a un porcentaje fijo de bloqueo.", n, n2, -6511979);
    }

    private int info(GuiGraphics guiGraphics, AbstractPlayerDamageModel abstractPlayerDamageModel, int n, int n2) {
        n2 = this.heading(guiGraphics, "Informaci\u00f3n", n, n2);
        ClinicalState clinicalState = ClinicalData.state((AbstractPlayerDamageModel)abstractPlayerDamageModel);
        n2 = this.line(guiGraphics, "Cordura: " + Math.round(clinicalState.sanity()) + " %", n, n2, clinicalState.sanity() > 30.0 ? -2170409 : -2132880);
        n2 = this.line(guiGraphics, String.format(Locale.ROOT, "Despierto: %.1f / 6 d\u00edas", (double)clinicalState.awakeTicks / 24000.0), n, n2, -6511979);
        if (clinicalState.sanity() <= 0.0) {
            n2 = this.wrapped(guiGraphics, "Necesitas dormir. Tu cabeza est\u00e1 perdiendo vida.", n, n2, -2132880);
        }
        if (this.minecraft == null || this.minecraft.player == null) {
            return n2;
        }
        n2 = this.wrapped(guiGraphics, this.minecraft.player.getName().getString(), n, n2, -2963554);
        n2 += 4;
        n2 = this.line(guiGraphics, "Experiencia: nivel " + this.minecraft.player.experienceLevel, n, n2, -2170409);
        n2 = this.line(guiGraphics, "Alimentaci\u00f3n: " + this.minecraft.player.getFoodData().getFoodLevel() + " / 20", n, n2, -2170409);
        if (this.temperature != null) {
            n2 = this.line(guiGraphics, "Hidrataci\u00f3n: " + Math.round(this.temperature.water() * 100.0) + " %", n, n2, -2170409);
        }
        n2 += 7;
        n2 = this.heading(guiGraphics, "Estado f\u00edsico", n, n2);
        n2 = this.status(guiGraphics, abstractPlayerDamageModel, n, n2);
        n2 += 7;
        n2 = this.heading(guiGraphics, "Efectos activos", n, n2);
        if (this.minecraft.player.getActiveEffects().isEmpty()) {
            n2 = this.line(guiGraphics, "Sin efectos activos", n, n2, -6511979);
        }
        for (MobEffectInstance mobEffectInstance : this.minecraft.player.getActiveEffects()) {
            n2 = this.wrapped(guiGraphics, Component.translatable((String)mobEffectInstance.getDescriptionId(), (Object[])new Object[0]).getString() + " " + (mobEffectInstance.getAmplifier() + 1) + " \u00b7 " + (mobEffectInstance.isInfiniteDuration() ? "Permanente" : GuiHealthScreen.duration(mobEffectInstance.getDuration())), n, n2, -2170409);
        }
        return n2;
    }

    private int skills(GuiGraphics guiGraphics, int n, int n2) {
        return SkillsPanel.draw((Object)((Object)this), (GuiGraphics)guiGraphics, (int)n, (int)n2);
    }

    private int metric(GuiGraphics guiGraphics, String string, String string2, int n, int n2, int n3) {
        n2 = this.line(guiGraphics, string, n, n2, -6511979);
        return this.line(guiGraphics, string2, n, n2, n3) + 6;
    }

    private int heading(GuiGraphics guiGraphics, String string, int n, int n2) {
        this.text(guiGraphics, string, n, n2, -2963554, this.layout.rightWidth - 8);
        return n2 + 15;
    }

    private int line(GuiGraphics guiGraphics, String string, int n, int n2, int n3) {
        this.text(guiGraphics, string, n, n2, n3, this.layout.rightWidth - 8);
        return n2 + 12;
    }

    private int wrapped(GuiGraphics guiGraphics, String string, int n, int n2, int n3) {
        for (FormattedCharSequence formattedCharSequence : this.font.split((FormattedText)Component.literal((String)string), Math.max(20, this.layout.rightWidth - 10))) {
            guiGraphics.drawString(this.font, formattedCharSequence, n, n2, n3);
            n2 += 11;
        }
        return n2 + 3;
    }

    private void text(GuiGraphics guiGraphics, String string, int n, int n2, int n3, int n4) {
        guiGraphics.drawString(this.font, this.font.plainSubstrByWidth(string, Math.max(1, n4)), n, n2, n3, false);
    }

    private static String duration(int n) {
        int n2 = Math.max(0, n / 20);
        return n2 / 60 + ":" + String.format(Locale.ROOT, "%02d", n2 % 60);
    }

    private static String partName(EnumPlayerPart enumPlayerPart) {
        int n = 0;
        while (n < PARTS.length) {
            if (PARTS[n] == enumPlayerPart) {
                return PART_NAMES[n];
            }
            ++n;
        }
        return enumPlayerPart.name();
    }

    private static int healthColor(double d) {
        return d >= 0.75 ? -7227269 : (d >= 0.4 ? -2963554 : -2132880);
    }

    private static int thermalColor(float f) {
        return f < 1.5898795f ? -8865572 : (f > 1.7659639f ? -2127760 : -7227269);
    }

    private void bar(GuiGraphics guiGraphics, int n, int n2, int n3, int n4, double d, int n5) {
        guiGraphics.fill(n, n2, n + n3, n2 + n4, -13617363);
        guiGraphics.fill(n, n2, n + (int)Math.round((double)n3 * SurvivalLayout.clamp((double)d, (double)0.0, (double)1.0)), n2 + n4, n5);
    }

    private void drawBody(GuiGraphics guiGraphics, AbstractPlayerDamageModel abstractPlayerDamageModel) {
        int n = Math.max(42, this.layout.viewHeight() - 32);
        this.bodyScale = Math.min((double)(this.layout.split - 16) / 100.0, (double)n / 200.0);
        this.bodyX = (double)this.guiLeft + ((double)this.layout.split - 100.0 * this.bodyScale) / 2.0;
        this.bodyY = this.layout.contentTop + 3;
        int n2 = 0;
        while (n2 < PARTS.length) {
            int n3;
            EnumPlayerPart enumPlayerPart = PARTS[n2];
            AbstractDamageablePart abstractDamageablePart = abstractPlayerDamageModel.getFromEnum(enumPlayerPart);
            n3 = this.tab == 4 && this.temperature != null ? GuiHealthScreen.thermalColor(this.temperature.rawCore()) : (this.injuries(abstractDamageablePart).isEmpty() ? -7038837 : -2132880);
            if (this.tab == 2 && this.minecraft != null && this.minecraft.player != null && Bleeding.isBleeding((LivingEntity)this.minecraft.player, (EnumPlayerPart)enumPlayerPart)) {
                n3 = -2132880;
            }
            if (this.tab == 3 && this.minecraft != null && this.minecraft.player != null) {
                n3 = this.minecraft.player.getItemBySlot(enumPlayerPart.slot).isEmpty() ? -9406870 : -6572092;
            }
            this.polygon(guiGraphics, SurvivalLayout.BODY[n2], enumPlayerPart == this.selected ? 1714764080 : 857415704, enumPlayerPart == this.selected ? -2963554 : n3);
            ClinicalState.Wound wound = ClinicalData.state((AbstractPlayerDamageModel)abstractPlayerDamageModel).wounds[enumPlayerPart.ordinal()];
            if (this.tab == 2) {
                if (0 > 0) {
                    int[][] nArray = SurvivalLayout.BODY[n2];
                    double d = 0.0;
                    double d2 = 0.0;
                    int[][] nArray2 = nArray;
                    int n5 = nArray.length;
                    int n6 = 0;
                    while (n6 < n5) {
                        int[] nArray3 = nArray2[n6];
                        d += (double)nArray3[0];
                        d2 += (double)nArray3[1];
                        ++n6;
                    }
                    int n7 = (int)(this.bodyX + (d /= (double)nArray.length) * this.bodyScale);
                    n6 = (int)(this.bodyY + (d2 /= (double)nArray.length) * this.bodyScale);
                    guiGraphics.fill(n7 - 2, n6 - 2, n7 + 3, n6 + 3, -1989518);
                    guiGraphics.fill(n7, n6 - 1, n7 + 1, n6 + 2, -13622756);
                }
            }
            ++n2;
        }
        n2 = this.layout.contentBottom - 26;
        this.text(guiGraphics, this.tab == 4 ? "Temperatura global" : (this.tab == 3 ? "Cobertura de equipo" : "Selecciona una parte"), this.guiLeft + 8, n2, -6511979, this.layout.split - 16);
        this.text(guiGraphics, GuiHealthScreen.partName(this.selected), this.guiLeft + 8, n2 + 12, -2963554, this.layout.split - 16);
        TreatmentV33.menuMarkers((Object)((Object)this), (Object)guiGraphics, (Object)abstractPlayerDamageModel);
    }

    private void polygon(GuiGraphics guiGraphics, int[][] nArray, int n, int n2) {
        int n3 = 200;
        int n4 = 0;
        int[][] vertices = nArray;
        int n5 = nArray.length;
        int n6 = 0;
        while (n6 < n5) {
            int[] nArray2 = vertices[n6];
            n3 = Math.min(n3, nArray2[1]);
            n4 = Math.max(n4, nArray2[1]);
            ++n6;
        }
        int n7 = n3;
        while (n7 < n4) {
            ArrayList<Double> arrayList = new ArrayList<Double>();
            n5 = 0;
            int n8 = nArray.length - 1;
            while (n5 < nArray.length) {
                int[] nArray3;
                int[] nArray4 = nArray[n5];
                if (nArray4[1] > n7 != (nArray3 = nArray[n8])[1] > n7) {
                    arrayList.add((double)nArray4[0] + (double)(nArray3[0] - nArray4[0]) * (double)(n7 - nArray4[1]) / (double)(nArray3[1] - nArray4[1]));
                }
                n8 = n5++;
            }
            Collections.sort(arrayList);
            n5 = 0;
            while (n5 + 1 < arrayList.size()) {
                guiGraphics.fill((int)(this.bodyX + (Double)arrayList.get(n5) * this.bodyScale), (int)(this.bodyY + (double)n7 * this.bodyScale), (int)(this.bodyX + (Double)arrayList.get(n5 + 1) * this.bodyScale), (int)(this.bodyY + (double)(n7 + 1) * this.bodyScale) + 1, n);
                n5 += 2;
            }
            ++n7;
        }
        n7 = 0;
        int n9 = nArray.length - 1;
        while (n7 < nArray.length) {
            int[] nArray5 = nArray[n7];
            int[] object = nArray[n9];
            int n10 = Math.max(Math.abs((int)(object[0] - nArray5[0])), Math.abs((int)(object[1] - nArray5[1])));
            int n11 = 0;
            while (n11 <= n10) {
                double d = n10 == 0 ? 0.0 : (double)n11 / (double)n10;
                int n12 = (int)(this.bodyX + ((double)nArray5[0] + (double)(object[0] - nArray5[0]) * d) * this.bodyScale);
                int n13 = (int)(this.bodyY + ((double)nArray5[1] + (double)(object[1] - nArray5[1]) * d) * this.bodyScale);
                guiGraphics.fill(n12, n13, n12 + 1, n13 + 1, n2);
                ++n11;
            }
            n9 = n7++;
        }
    }

    public boolean v33NativeMouseClicked(double d, double d2, int n) {
        if (super.mouseClicked(d, d2, n)) {
            return true;
        }
        if (this.layout == null) {
            return false;
        }
        int n2 = 0;
        while (n2 < PARTS.length) {
            if (SurvivalLayout.contains((int[][])SurvivalLayout.BODY[n2], (double)((d - this.bodyX) / this.bodyScale), (double)((d2 - this.bodyY) / this.bodyScale))) {
                this.selected = PARTS[n2];
                if (n == 1 && this.tab == 2) {
                    this.applyHealing(this.selected);
                }
                return true;
            }
            ++n2;
        }
        if (this.tab == 2 && d >= (double)this.layout.rightX && d < (double)(this.layout.rightX + this.layout.rightWidth) && d2 >= (double)this.layout.contentTop && d2 < (double)this.layout.contentBottom) {
            for (RowHit rowHit : this.rowHits) {
                if (!(d2 >= (double)rowHit.top) || !(d2 < (double)rowHit.bottom)) continue;
                this.selected = rowHit.part;
                if (n == 1) {
                    this.applyHealing(rowHit.part);
                }
                return true;
            }
        }
        return false;
    }

    public boolean v33NativemouseScrolled(double d, double d2, double d3, double d4) {
        if (this.layout != null && d >= (double)this.layout.rightX && d <= (double)(this.guiLeft + this.layout.width) && d2 >= (double)this.layout.contentTop && d2 <= (double)this.layout.contentBottom) {
            this.scroll = (int)SurvivalLayout.clamp((double)((double)this.scroll - d4 * 24.0), (double)0.0, (double)this.layout.scrollLimit(this.contentHeight));
            return true;
        }
        return super.mouseScrolled(d, d2, d3, d4);
    }

    public boolean keyPressed(int n, int n2, int n3) {
        if (HealthTab40.active((Object)this) && HealthTab40.escape((Object)this, n)) {
            return true;
        }
        if (ClientHooks.SHOW_WOUNDS.matches(n, n2)) {
            this.onClose();
            return true;
        }
        return super.keyPressed(n, n2, n3);
    }

    public void renderBackground(GuiGraphics guiGraphics, int n, int n2, float f) {
    }

    public boolean isPauseScreen() {
        return false;
    }

    public void onClose() {
        isOpen = false;
        super.onClose();
    }

    private List injuries(AbstractDamageablePart abstractDamageablePart) {
        return (List)InjuryGrid20.filter((Object)abstractDamageablePart, (Object)TreatmentV33.extraInjuries((Object)((Object)this), (Object)abstractDamageablePart, this.v33NativeInjuries(abstractDamageablePart)));
    }

    public boolean mouseClicked(double d, double d2, int n) {
        if (HealthTab40.active((Object)this)) {
            return HealthTab40.click((Object)this, d, d2, n);
        }
        if (TreatmentV33.gridClick((Object)((Object)this), (double)d, (double)d2, (int)n)) {
            return true;
        }
        return this.v33NativeMouseClicked(d, d2, n);
    }

    public boolean mouseScrolled(double d, double d2, double d3, double d4) {
        if (HealthTab40.active((Object)this)) {
            return HealthTab40.scroll((Object)this, d, d2, d4);
        }
        if (TreatmentV33.gridScroll((Object)((Object)this))) {
            return true;
        }
        return this.v33NativemouseScrolled(d, d2, d3, d4);
    }

    private InteractionHand treatmentHand(EnumPlayerPart enumPlayerPart) {
        return (InteractionHand)TreatmentV33.treatmentHand((Object)((Object)this), (Object)enumPlayerPart);
    }

    private int thermal(GuiGraphics guiGraphics, int n, int n2) {
        return WetClient.thermal((Object)((Object)this), (Object)guiGraphics, (int)n, (int)n2);
    }

    private int status(GuiGraphics guiGraphics, AbstractPlayerDamageModel abstractPlayerDamageModel, int n, int n2) {
        return WetClient.status((Object)((Object)this), (Object)guiGraphics, (Object)abstractPlayerDamageModel, (int)n, (int)n2);
    }

    public void medical40Widgets(GuiGraphics guiGraphics, int n, int n2, float f) {
        super.render(guiGraphics, n, n2, f);
    }

    public boolean medical40WidgetsClick(double d, double d2, int n) {
        return super.mouseClicked(d, d2, n);
    }
}
