from pathlib import Path
import sys,subprocess,zipfile,json,shutil
root=Path(__file__).resolve().parent
base=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();build=root/'build';build.mkdir(exist_ok=True)
exports=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
def run(*args):subprocess.run(args,check=True)
run('java','com.sun.tools.javac.Main','-proc:none','-cp',str(base),'-d',str(build),*[str(x) for x in (root/'src').rglob('*.java')])
run('java','com.sun.tools.javac.Main',*exports,'-d',str(build),str(root/'Patch.java'))
cls='ichttt/mods/firstaid/client/gui/GuiHealthScreen.class'
with zipfile.ZipFile(base) as z:
 p=build/cls;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(cls))
run('java',*exports,'-cp',str(build),'Patch',str(p));run(sys.executable,str(root/'lang.py'))
with zipfile.ZipFile(base) as z,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as dest:
 for entry in z.infolist():
  data=z.read(entry.filename)
  if entry.filename==cls:data=p.read_bytes()
  if entry.filename=='META-INF/neoforge.mods.toml':data=data.replace(b'zomboid-v3.6.9-body-care',b'zomboid-v3.6.10-health-context-ui').replace('First Aid · Zomboid v3.6.3 · Reanimación y recuperación'.encode(),'First Aid · Zomboid v3.6.10 · Salud contextual'.encode())
  if entry.filename.startswith('assets/firstaid/lang/') and (root/'lang'/Path(entry.filename).name).exists():
   d=json.loads(data);d.update(json.loads((root/'lang'/Path(entry.filename).name).read_text()));data=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
  dest.writestr(entry,data)
 for file in (build/'dev/zomboid/firstaid').glob('*40*.class'):dest.write(file,file.relative_to(build).as_posix())
 for lang in (root/'lang').glob('*.json'):
  name='assets/firstaid/lang/'+lang.name
  if name not in z.namelist():dest.write(lang,name)
print(out)
