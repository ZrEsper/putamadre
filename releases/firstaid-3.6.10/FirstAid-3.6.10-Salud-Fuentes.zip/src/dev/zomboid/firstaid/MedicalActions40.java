package dev.zomboid.firstaid;
import java.util.*;
/** Inventory selection and existing treatment entry points; no new network message or healing rules. */
public final class MedicalActions40 {
 public record Action(String key,int slot,String reason){public boolean enabled(){return reason==null;}}
 static final String T="ichttt.mods.firstaid.compat.lrtactical.TreatmentV33",C="ichttt.mods.firstaid.survival.ClinicalHooks";
 static Object c(Object o,String m,Object...a){return R.call(o,m,a);}static Object stat(String cls,String m,Object...a){return c(R.type(cls),m,a);}static boolean yes(Object o){return Boolean.TRUE.equals(o);}static boolean b(Object o,String f){return yes(R.get(o,f));}
 static String itemId(Object stack){return String.valueOf(c(c(stack,"getItem"),"getDescriptionId"));}
 static boolean matches(Object stack,String action,boolean clinical){if(yes(c(stack,"isEmpty")))return false;String id=itemId(stack);return switch(action){case "splint"->id.equals("item.firstaid.splint");case "extract"->yes(stat(C,"extraction",stack));case "plaster"->id.equals("item.firstaid.plaster");case "bandage"->!id.equals("item.firstaid.plaster")&&(clinical?yes(stat(C,"dressing",stack)):R.type("ichttt.mods.firstaid.api.healing.ItemHealing").isInstance(c(stack,"getItem")));default->false;};}
 static int find(Object player,String action,boolean clinical){if(player==null)return -1;Object inv=c(player,"getInventory");int selected=((Number)R.get(inv,"selected")).intValue();if(matches(c(inv,"getItem",selected),action,clinical))return selected;for(int i=0;i<36;i++)if(matches(c(inv,"getItem",i),action,clinical))return i;if(matches(c(player,"getOffhandItem"),action,clinical))return 40;return -1;}
 public static List<Action> list(MedicalView40.Snapshot snap,int index){MedicalView40.Part p=snap.parts().get(index);Object w=p.wound();boolean bandaged=b(w,"bandaged"),clinical=yes(c(w,"active")),needs=clinical?yes(c(w,"canBandage")):p.health()<p.max()-.01&&R.get(p.part(),"activeHealer")==null;
  List<Action> out=new ArrayList<>();for(String k:new String[]{"bandage","plaster","splint","extract","remove","clean"}){
   int slot=k.equals("remove")?-1:find(snap.player(),k,clinical);String reason=null;
   if(k.equals("clean"))reason="clean_unavailable";
   else if(k.equals("remove")){if(!bandaged)reason="no_bandage";}
   else if(k.equals("splint")){if(!p.broken())reason="no_fracture";else if(index==5&&snap.parts().get(4).broken())reason="left_leg_first";else if(slot<0)reason="need_splint";}
   else if(k.equals("extract")){if(((Number)R.get(w,"bullets")).intValue()<=0)reason="no_bullet";else if(bandaged)reason="remove_first";else if(slot<0)reason="need_shears";}
   else if(bandaged)reason="remove_first";else if(!needs)reason="no_wound";else if(slot<0)reason=k.equals("plaster")?"need_plaster":"need_bandage";
   out.add(new Action(k,slot,reason));
  }return List.copyOf(out);
 }
 static Object equip(Object mc,Object player,int slot){Object inv=c(player,"getInventory"),main=R.get(R.type("net.minecraft.world.InteractionHand"),"MAIN_HAND");if(slot<0)return main;
  int selected=((Number)R.get(inv,"selected")).intValue();Object game=R.get(mc,"gameMode");
  if(slot<9){R.set(inv,"selected",slot);c(R.get(player,"connection"),"send",R.make("net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket",slot));}
  else {if(R.get(player,"containerMenu")!=R.get(player,"inventoryMenu"))return null;int menu=((Number)R.get(R.get(player,"inventoryMenu"),"containerId")).intValue();c(game,"handleInventoryMouseClick",menu,slot==40?45:slot,selected,R.get(R.type("net.minecraft.world.inventory.ClickType"),"SWAP"),player);}
  return main;
 }
 public static void run(Object screen,int index,String key){MedicalView40.Snapshot snap=MedicalView40.read(screen);Action a=list(snap,index).stream().filter(x->x.key.equals(key)).findFirst().orElse(null);if(a==null||!a.enabled()||snap.player()==null)return;
  Object mc=c(R.type("net.minecraft.client.Minecraft"),"getInstance"),player=snap.player(),hand=equip(mc,player,a.slot);if(hand==null)return;MedicalView40.Part part=snap.parts().get(index);R.set(screen,"selected",part.id());
  if(key.equals("remove")){Object message=R.make("ichttt.mods.firstaid.common.network.MessageApplyHealingItem",part.id(),hand);c(R.get(R.type("ichttt.mods.firstaid.FirstAid"),"NETWORKING"),"sendToServer",message);c(screen,"onClose");return;}
  if(key.equals("splint")){c(screen,"onClose");c(R.get(mc,"gameMode"),"useItem",player,hand);stat(T,"startClient",hand,4,60);stat(T,"set",R.type(T),"autoDuration",60);return;}
  // Main-hand choice is explicit, so the context action cannot silently use a different offhand item.
  if(yes(stat(T,"isClinical",part.wound()))){stat(T,"clientBegin",screen,hand);Object message=R.make("ichttt.mods.firstaid.common.network.MessageApplyHealingItem",part.id(),hand);c(R.get(R.type("ichttt.mods.firstaid.FirstAid"),"NETWORKING"),"sendToServer",message);c(screen,"onClose");}
  else if(yes(stat("ichttt.mods.firstaid.client.ClientEventHandler","selectPendingHealing",part.id(),hand)))c(screen,"onClose");
 }
}
