package dev.zomboid.firstaid;
import java.util.*;
/** Health-tab-only renderer/controller, in the screen's existing GUI coordinate space. */
public final class HealthTab40 {
 static final int WHITE=0xFFFFFFFF,GRAY=0xFFAAAAAA,RED=0xFFFF5555,YELLOW=0xFFFFFF55;
 static final Map<Object,State> STATES=new WeakHashMap<>();
 static final class State{int scroll,limit,selected=1;boolean menu;int menuX,menuY,menuWidth;List<MedicalActions40.Action> actions=List.of();Layout layout;MedicalView40.Snapshot snapshot;}
 public record Layout(int left,int top,int width,int height,int contentTop,int contentBottom,int bodyWidth,int barX,int rightX,int rightWidth,double scale,double bodyX,double bodyY){}
 public static Layout layout(int left,int top,int width,int height,int contentTop,int contentBottom,int split){int bodyWidth=Math.max(50,split-17),right=left+split+10;double scale=Math.max(.08,Math.min((bodyWidth-8)/100d,(contentBottom-contentTop-6)/200d));return new Layout(left,top,width,height,contentTop,contentBottom,bodyWidth,left+split-9,right,width-split-20,scale,left+(bodyWidth-100*scale)/2,contentTop+2);}
 static Object c(Object o,String m,Object...a){return R.call(o,m,a);}static int n(Object o,String f){return ((Number)R.get(o,f)).intValue();}static Object font(Object s){return R.get(s,"font");}
 static Object tr(String key,Object...args){return c(R.type("net.minecraft.network.chat.Component"),"translatable","firstaid.medical."+key,args);}
 static Object literal(String text){return c(R.type("net.minecraft.network.chat.Component"),"literal",text);}
 static void fill(Object g,int x,int y,int x2,int y2,int color){c(g,"fill",x,y,x2,y2,color);}
 static void panel(Object g,int x,int y,int w,int h,int edge,int bg){fill(g,x,y,x+w,y+h,edge);fill(g,x+1,y+1,x+w-1,y+h-1,bg);}
 static int wrap(Object s,Object g,Object text,int x,int y,int width,int color){for(Object line:(Iterable<?>)c(font(s),"split",text,Math.max(16,width))){c(g,"drawString",font(s),line,x,y,color,false);y+=10;}return y;}
 static void text(Object s,Object g,Object text,int x,int y,int color){c(g,"drawString",font(s),text,x,y,color,false);}
 static State state(Object s){return STATES.computeIfAbsent(s,k->new State());}
 public static boolean active(Object s){return n(s,"tab")==2;}
 static int[][][] shapes(){return (int[][][])R.get(R.type("ichttt.mods.firstaid.client.gui.SurvivalLayout"),"BODY");}
 public static boolean contains(int[][] points,double x,double y){boolean inside=false;for(int i=0,j=points.length-1;i<points.length;j=i++){int[] a=points[i],b=points[j];if((a[1]>y)!=(b[1]>y)&&x<(b[0]-a[0])*(y-a[1])/(double)(b[1]-a[1])+a[0])inside=!inside;}return inside;}
 static int hit(Layout l,double x,double y){int[][][] body=shapes();for(int i=0;i<body.length;i++)if(contains(body[i],(x-l.bodyX)/l.scale,(y-l.bodyY)/l.scale))return i;return -1;}
 static Object name(int index){return tr("part."+MedicalView40.PARTS[index].toLowerCase(Locale.ROOT));}
 public static void render(Object s,Object g,int mx,int my,float partial){Object old=R.get(s,"layout");if(old==null)return;State st=state(s);int hintHeight=((List<?>)c(font(s),"split",tr("hint.right_click"),n(old,"width")-16)).size()*10+5;Layout l=layout(n(old,"left"),n(old,"top"),n(old,"width"),n(old,"height"),n(old,"contentTop"),n(old,"contentBottom")-hintHeight,n(old,"split"));st.layout=l;MedicalView40.Snapshot snap=MedicalView40.read(s);st.snapshot=snap;
  Object selected=R.get(s,"selected");for(int i=0;i<8;i++)if(snap.parts().get(i).id()==selected)st.selected=i;
  fill(g,0,0,n(s,"width"),n(s,"height"),0x88000000);panel(g,l.left-1,l.top-1,l.width+2,l.height+2,0xFF777777,0xEF161616);
  if(l.width>=360)text(s,g,tr("survivor"),l.left+10,l.top+8,YELLOW);
  List<?> tabs=(List<?>)R.get(s,"tabs");for(int i=0;i<tabs.size();i++)R.set(tabs.get(i),"selected",i==2);
  R.set(R.get(s,"treatment"),"visible",false);R.set(R.get(s,"treatment"),"active",false);c(R.get(s,"cancelButton"),"setMessage",tr("close"));
  R.set(s,"bodyScale",l.scale);R.set(s,"bodyX",l.bodyX);R.set(s,"bodyY",l.bodyY);int hovered=hit(l,mx,my);
  for(int i=0;i<8;i++){c(s,"polygon",g,shapes()[i],i==st.selected?0x665E8FAD:i==hovered?0x445E8FAD:0x18111111,WHITE);marks(g,l,i,snap.parts().get(i));}
  int bt=l.contentTop+7,bh=Math.max(12,l.contentBottom-bt-9);panel(g,l.barX-2,bt-2,12,bh+4,0xFF555555,0xFF101010);
  for(int dy=0;dy<bh;dy++){int shade=(int)(225-175d*dy/Math.max(1,bh-1));if(dy<bh*(1-snap.fraction()))shade/=4;int color=0xFF000000|(shade<<16)|(shade<<8)|shade;fill(g,l.barX,bt+dy,l.barX+8,bt+dy+1,color);}
  int heartY=bt+(int)((1-snap.fraction())*(bh-9));if(snap.player()!=null){Object helper=R.type("ichttt.mods.firstaid.client.util.HeartSpriteHelper");c(g,"blitSprite",c(helper,"container",snap.player(),false),l.barX-1,heartY,9,9);c(g,"blitSprite",c(helper,"heart",snap.player(),false,snap.fraction()<.5,false),l.barX-1,heartY,9,9);}
  c(g,"enableScissor",l.rightX,l.contentTop,l.rightX+l.rightWidth,l.contentBottom);
  int y=l.contentTop-st.scroll;panel(g,l.rightX,y,l.rightWidth,20,0xFF555555,0xFF303030);text(s,g,tr("exercise"),l.rightX+5,y+6,0xFF777777);y+=27;
  y=wrap(s,g,tr("overall_status"),l.rightX,y,l.rightWidth,WHITE);y+=3;y=wrap(s,g,tr("damage."+MedicalView40.severity(snap.fraction())),l.rightX,y,l.rightWidth,snap.fraction()>=.999?GRAY:RED);
  y=wrap(s,g,tr("pain."+MedicalView40.pain(snap.pain())),l.rightX,y,l.rightWidth,snap.pain()==0?GRAY:RED);y+=12;
  int lines=((List<?>)c(font(s),"split",name(st.selected),Math.max(16,l.rightWidth-8))).size();fill(g,l.rightX,y-3,l.rightX+l.rightWidth,y+lines*10+3,0xFF383838);y=wrap(s,g,name(st.selected),l.rightX+4,y,l.rightWidth-8,YELLOW)+9;
  MedicalView40.Part p=snap.parts().get(st.selected);if(p.injuries().isEmpty())y=wrap(s,g,tr("no_injuries"),l.rightX+4,y,l.rightWidth-8,GRAY);
  else for(String key:p.injuries()){Object label=key.equals("health_loss")?tr("injury.health_loss",decimal(p.health()),decimal(p.max())):key.equals("bullet")?tr("injury.bullet",R.get(p.wound(),"bullets")):tr("injury."+key);Object line=c(literal("- "),"append",label);y=wrap(s,g,line,l.rightX+4,y,l.rightWidth-8,RED)+3;}
  st.limit=Math.max(0,y+st.scroll-l.contentBottom+4);st.scroll=Math.min(st.scroll,st.limit);c(g,"disableScissor");
  if(st.limit>0){int h=l.contentBottom-l.contentTop,size=Math.max(10,h*h/(h+st.limit)),sy=l.contentTop+(h-size)*st.scroll/st.limit;fill(g,l.left+l.width-5,l.contentTop,l.left+l.width-3,l.contentBottom,0xFF333333);fill(g,l.left+l.width-5,sy,l.left+l.width-3,sy+size,0xFFAAAAAA);}
  // Hint shares the existing footer with Close and wraps in the available column.
  wrap(s,g,tr("hint.right_click"),l.left+8,l.contentBottom+5,l.width-16,GRAY);
  c(s,"medical40Widgets",g,mx,my,partial);
  if(st.menu)menu(s,g,st,mx,my);else if(mx>=l.barX-3&&mx<=l.barX+11&&my>=bt-2&&my<=bt+bh+2)tip(s,g,tr("global_health",decimal(snap.health()),decimal(snap.max()),Math.round(snap.fraction()*100)),mx,my);
  else if(mx>=l.rightX&&mx<l.rightX+l.rightWidth&&my>=l.contentTop-st.scroll&&my<l.contentTop-st.scroll+20)tip(s,g,tr("exercise_unavailable"),mx,my);
 }
 static String decimal(double n){return String.format(Locale.ROOT,"%.1f",n);}
 static void tip(Object s,Object g,Object message,int x,int y){c(g,"renderTooltip",font(s),message,x,y);}
 static void marks(Object g,Layout l,int index,MedicalView40.Part p){int[][] poly=shapes()[index];double cx=0,cy=0;for(int[] point:poly){cx+=point[0];cy+=point[1];}int x=(int)(l.bodyX+cx/poly.length*l.scale),y=(int)(l.bodyY+cy/poly.length*l.scale);List<String> types=p.injuries();
  if(types.contains("cut")){fill(g,x-3,y,x,y+1,RED);fill(g,x,y-1,x+4,y,RED);}else if(types.contains("health_loss"))fill(g,x-2,y,x+2,y+1,RED);
  if(p.bleeding()){fill(g,x+2,y+4,x+5,y+7,0xFFCC2222);fill(g,x+3,y+2,x+4,y+4,RED);}
  if(p.broken()){fill(g,x-4,y-5,x-1,y-4,RED);fill(g,x-2,y-4,x-1,y-2,RED);fill(g,x-2,y-2,x+1,y-1,RED);}
  if(types.contains("gunshot")||types.contains("bullet")){fill(g,x+1,y-4,x+4,y-1,0xFFAA2222);fill(g,x+2,y-3,x+3,y-2,0xFF220000);}
  if(types.contains("bite")){fill(g,x-4,y+3,x-3,y+5,RED);fill(g,x-1,y+3,x,y+5,RED);}
  if(types.contains("infection"))fill(g,x-3,y+7,x+1,y+8,RED);
  if(types.contains("bandaged")||p.splinted()){fill(g,x-4,y-1,x+5,y+2,0xFFE2D4AE);fill(g,x-1,y-2,x+1,y+3,WHITE);}
 }
 static void menu(Object s,Object g,State st,int mx,int my){st.actions=MedicalActions40.list(MedicalView40.read(s),st.selected);int h=st.actions.size()*19+4;st.menuWidth=Math.min(210,n(s,"width")-12);int longest=100;for(var a:st.actions)longest=Math.max(longest,((Number)c(font(s),"width",tr("context."+a.key()))).intValue()+16);st.menuWidth=Math.min(st.menuWidth,longest);st.menuX=Math.max(3,Math.min(st.menuX,n(s,"width")-st.menuWidth-3));st.menuY=Math.max(3,Math.min(st.menuY,n(s,"height")-h-3));
  Object pose=c(g,"pose");c(pose,"pushPose");try{c(pose,"translate",0d,0d,300d);panel(g,st.menuX,st.menuY,st.menuWidth,h,0xFF888888,0xFF181818);for(int i=0;i<st.actions.size();i++){var a=st.actions.get(i);int y=st.menuY+2+i*19;boolean hover=mx>=st.menuX+1&&mx<st.menuX+st.menuWidth-1&&my>=y&&my<y+19;if(hover)fill(g,st.menuX+1,y,st.menuX+st.menuWidth-1,y+19,a.enabled()?0xFF505050:0xFF292929);text(s,g,tr("context."+a.key()),st.menuX+6,y+5,a.enabled()?WHITE:0xFF777777);}}finally{c(pose,"popPose");}
  int row=(my-st.menuY-2)/19;if(mx>=st.menuX&&mx<st.menuX+st.menuWidth&&my>=st.menuY+2&&row>=0&&row<st.actions.size()){var a=st.actions.get(row);tip(s,g,tr("requirement."+(a.enabled()?a.key():a.reason())),mx,my);}
 }
 public static boolean click(Object s,double x,double y,int button){State st=state(s);if(st.menu){if(button==0&&x>=st.menuX&&x<st.menuX+st.menuWidth&&y>=st.menuY+2&&y<st.menuY+2+st.actions.size()*19){int row=(int)(y-st.menuY-2)/19;var a=st.actions.get(row);if(a.enabled()){st.menu=false;MedicalActions40.run(s,st.selected,a.key());}return true;}st.menu=false;return true;}
  if(st.layout!=null){int part=hit(st.layout,x,y);if(part>=0&&(button==0||button==1)){st.selected=part;st.scroll=0;R.set(s,"selected",st.snapshot.parts().get(part).id());if(button==1){st.menu=true;st.menuX=(int)x;st.menuY=(int)y;st.actions=MedicalActions40.list(MedicalView40.read(s),part);}return true;}}
  return Boolean.TRUE.equals(c(s,"medical40WidgetsClick",x,y,button));
 }
 public static boolean scroll(Object s,double x,double y,double amount){State st=state(s);if(st.menu)return true;if(st.layout!=null&&x>=st.layout.rightX&&x<=st.layout.rightX+st.layout.rightWidth&&y>=st.layout.contentTop&&y<=st.layout.contentBottom){st.scroll=Math.max(0,Math.min(st.limit,st.scroll-(int)(amount*20)));return true;}return false;}
 public static boolean escape(Object s,int key){State st=state(s);if(key==256&&st.menu){st.menu=false;return true;}return false;}
}
