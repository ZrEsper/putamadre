package dev.zomboid.firstaid;
import java.util.*;
public class HealthTab40Test {
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 public static void main(String[] args){
  check(MedicalView40.labels(false,0,false,false,false,false,false,false,false,false,false,false,10,10).isEmpty(),"healthy");
  check(MedicalView40.labels(false,0,false,false,false,false,false,false,false,false,false,false,5,10).equals(List.of("health_loss")),"no invented injury");
  var wounds=MedicalView40.labels(true,2,true,true,true,true,true,true,true,true,true,true,5,10);check(wounds.containsAll(List.of("gunshot","bullet","cut","bite","infection","dirty_bandage","bandaged","healing","bleeding","fracture","splinted","treating")),"clinical labels");
  check(MedicalView40.severity(.8).equals("slight")&&MedicalView40.severity(.5).equals("moderate")&&MedicalView40.severity(.3).equals("severe")&&MedicalView40.severity(.1).equals("critical"),"severity");
  check(MedicalView40.pain(0).equals("none")&&MedicalView40.pain(5).equals("extreme"),"pain");
  for(int scale: new int[]{2,3,4})for(int[] resolution:new int[][]{{1920,1080},{1280,720},{854,480}}){int w=resolution[0]/scale,h=resolution[1]/scale;if(w<320||h<240)continue;int width=Math.min(450,Math.max(180,w-16)),height=Math.min(310,Math.max(120,h-16)),left=(w-width)/2,top=(h-height)/2,split=Math.min(136,Math.max(72,width/3));var l=HealthTab40.layout(left,top,width,height,top+49,top+height-62,split);check(l.bodyY()+200*l.scale()<l.contentBottom(),"silhouette bounds");check(l.rightWidth()>0&&l.contentTop()<l.contentBottom(),"columns");check(l.bodyX()+100*l.scale()<l.barX(),"no bar overlap");}
  int[][] square={{0,0},{10,0},{10,10},{0,10}};check(HealthTab40.contains(square,5,5)&&!HealthTab40.contains(square,15,5),"hit testing");
  var snap=new MedicalView40.Snapshot(null,null,List.of(),300,100,0);check(snap.fraction()==1,"health cap");
  System.out.println("PASS: injury labels, severity, pain, GUI scale geometry, hit detection, health bounds");
 }
}
