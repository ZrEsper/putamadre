package dev.zomboid.mts;
import java.lang.reflect.*;
import minecrafttransportsimulator.rendering.RenderableData;
import minecrafttransportsimulator.jsondefs.JSONLight;
/** One physical headlight renderer. Keep native geometry only without the flashlight bridge. */
public final class VehicleLight59 {
 static boolean checked,warned,handedOff;static Method hook;
 public static void emit(Object entity,Object definition,Object transform,float brightness){
  handedOff=false;
  if(!(definition instanceof JSONLight def)||def.blendableComponents==null||def.blendableComponents.stream().noneMatch(c->c.beamLength>2&&c.beamDiameter>0))return;
  if(!checked){checked=true;try{hook=Class.forName("net.flashlight.battery.Vehicle59").getMethod("register",Object.class,Object.class,Object.class,float.class);}catch(ClassNotFoundException|NoSuchMethodException absent){return;}}
  if(hook==null)return;
  try{hook.invoke(null,entity,definition,transform,brightness);handedOff=true;}catch(ReflectiveOperationException|RuntimeException error){if(!warned){warned=true;System.err.println("[VehicleLight62] Registration failed, retaining native beam: "+error);}}
 }
 public static void draw(RenderableData beam){boolean skip=handedOff;handedOff=false;if(!skip)beam.render();}
}
