from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');f=Path('/workspace/light61/release/flashlight-5.1-neoforge-1.21.1-surface-depth-vehicle-npc.27.jar');mts=Path('/workspace/attachments/b7a0ed9d-be56-49e2-b623-31b43cf51c36/Immersive-Vehicles-1.21.1-24.0.0-zomboid-mechanics.17-headlight-cones.jar');e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis'])
for p in ['build/classes','build/mts','build/tools','output']:(r/p).mkdir(parents=True,exist_ok=True)
subprocess.run(e+['-cp',str(f),'-d',str(r/'build/classes')]+list(map(str,(r/'src').rglob('*.java'))),check=True)
subprocess.run(e+['-cp',str(mts),'-d',str(r/'build/mts')]+list(map(str,(r/'mts-src').rglob('*.java'))),check=True)
subprocess.run(e+['-cp',asm,'-d',str(r/'build/tools'),str(r/'Patch62.java')],check=True)
for base,classes,out,mode in [(f,'classes','flash',str(r/'portable6.frag')),(mts,'mts','mts','mts')]:subprocess.run(['java','-cp',str(r/'build/tools')+':'+asm,'Patch62',str(base),str(r/'build'/classes),str(r/'output'/f'{out}.jar'),mode],check=True)
