package net.flashlight.battery;import java.util.*;public class G6{static Map<String,Float>values=new HashMap<>();static void scalar(int p,String n,float v){values.put(n,v);}}
