package net.flashlight.battery;public class Power{static Object active(Object p){return null;}}
