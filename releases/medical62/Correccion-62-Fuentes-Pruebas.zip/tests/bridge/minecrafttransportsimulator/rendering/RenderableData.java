package minecrafttransportsimulator.rendering;public class RenderableData{public int draws;public void render(){draws++;}}
