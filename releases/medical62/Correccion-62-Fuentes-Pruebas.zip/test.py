from pathlib import Path
import subprocess,json
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');old=Path('/workspace/light61/release/flashlight-5.1-neoforge-1.21.1-surface-depth-vehicle-npc.27.jar');new=r/'output/flash.jar';mts=r/'output/mts.jar';e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];out=r/'build/entity';out.mkdir(exist_ok=True)
subprocess.run(e+['-cp',str(new)+':'+str(mts),'-d',str(out)]+list(map(str,(r/'tests/entity').rglob('*.java'))),check=True)
reports=[]
for label,jar,args in [('old',old,['old']),('new',new,[])]:
 p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(jar)+':'+str(mts),'net.flashlight.battery.EntityTest62']+args,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();reports.append({'case':'entity-'+label,'result':p.stdout.strip()})

for folder,main in [('slots','net.flashlight.battery.SlotsTest60'),('bridge','dev.zomboid.mts.BridgeTest62')]:
 out=r/'build'/folder;out.mkdir(exist_ok=True)
 subprocess.run(e+['-cp',str(new)+':'+str(mts),'-d',str(out)]+list(map(str,(r/'tests'/folder).rglob('*.java'))),check=True)
 p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(new)+':'+str(mts),main],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();reports.append({'case':folder,'result':p.stdout.strip()})
(r/'test-results.json').write_text(json.dumps({'minecraft_runtime_tested':False,'results':reports},indent=2)+'\n')
