from pathlib import Path
import zipfile,json,hashlib,subprocess,tomllib
r=Path(__file__).parent;out=r/'release';out.mkdir(exist_ok=True)
items=[('flash','flashlight-5.1-neoforge-1.21.1-unified-vehicle-character-light.28.jar','5.1.27','5.1.28'),('mts','Immersive-Vehicles-1.21.1-24.0.0-zomboid-mechanics.18-unified-headlights.jar','24.0.0.17','24.0.0.18')];files=[]
for stem,name,old,new in items:
 with zipfile.ZipFile(r/'output'/f'{stem}.jar') as z:data={n:z.read(n) for n in z.namelist()}
 meta=data['META-INF/neoforge.mods.toml'].decode().replace(old,new);assert tomllib.loads(meta)['mods'][0]['version']==new;data['META-INF/neoforge.mods.toml']=meta.encode();assert not any(n.startswith(('net/minecraft/','org/joml/','tests/')) for n in data)
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in sorted(data.items()):z.writestr(n,b)
 with zipfile.ZipFile(out/name) as z:assert z.testzip() is None
 files.append({'name':name,'version':new,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()})
checks=[]
for script,args in [('character_gpu_test.py',['/workspace/light61/portable6.frag']),('character_gpu_test.py',[str(r/'portable6.frag')]),('stripes_gpu_test.py',[str(r/'portable6.frag')]),('render_test.py',[]),('three_gpu_test.py',[]),('depth_gpu_test.py',[])]:
 p=subprocess.run(['python',str(r/script)]+args,capture_output=True,text=True);p.check_returncode();print(p.stdout);checks.append({'test':script,'input':args,'result':p.stdout.strip()})
results=json.loads((r/'test-results.json').read_text());assert any('CHECKS=68' in c['result'] for c in results['results']);results['real_opengl_tests']=checks;results['verified_classes']={'flashlight':67,'mts':873};results['native_beam_replacements']=1;(out/'test-results.json').write_text(json.dumps(results,indent=2)+'\n');(out/'manifest.json').write_text(json.dumps({'base_commit':'96a7b91767f7209d8f892181c77e2d4461886f53','minecraft':'1.21.1','loader':'NeoForge','minecraft_runtime_tested':False,'files':files},indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(''.join(f['sha256']+'  mods/'+f['name']+'\n' for f in files));(out/'LEEME.md').write_bytes((r/'LEEME.md').read_bytes())
with zipfile.ZipFile(out/'Correccion-62-Faros-Unificados-Personajes.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(out/f['name'],'mods/'+f['name'])
 for n in ['LEEME.md','test-results.json','manifest.json','SHA256SUMS.txt']:z.write(out/n,n)
with zipfile.ZipFile(out/'Correccion-62-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['src','mts-src','tests']:
  for p in(r/folder).rglob('*.java'):z.write(p,p.relative_to(r))
 for n in ['Patch62.java','build.py','test.py','shader_test.py','character_gpu_test.py','stripes_gpu_test.py','render_test.py','three_gpu_test.py','portable6.frag','depth_gpu_test.py','package.py','LEEME.md']:z.write(r/n,n)
 for n in ['test-results.json','manifest.json']:z.write(out/n,n)
print('PACKAGE_READY',json.dumps(files))
