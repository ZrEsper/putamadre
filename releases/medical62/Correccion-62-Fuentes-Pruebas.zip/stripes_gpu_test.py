from pathlib import Path
import ctypes as C
r=Path(__file__).resolve().parent
s=(r/'shader_test.py').read_text();import sys
s=s.replace("(r/'portable6.frag').read_text()","Path(sys.argv[1]).read_text()")
exec(s[:s.index("fn(e,'eglMakeCurrent'",s.index('program=') )])
# Draw the production fragment on a controlled plane with a real OpenGL framebuffer.
W=128;H=128
texgen=fn(g,'glGenTextures',None,[I,C.POINTER(U)]);bind=fn(g,'glBindTexture',None,[U,U]);teximage=fn(g,'glTexImage2D',None,[U,I,I,I,I,I,U,U,P]);param=fn(g,'glTexParameteri',None,[U,U,I]);active=fn(g,'glActiveTexture',None,[U])
def texture(unit,internal,fmt,ty,values,w=W,h=H):
 n=U();texgen(1,C.byref(n));active(0x84C0+unit);bind(0x0DE1,n);param(0x0DE1,0x2801,0x2600);param(0x0DE1,0x2800,0x2600);param(0x0DE1,0x2802,0x812F);param(0x0DE1,0x2803,0x812F);teximage(0x0DE1,0,internal,w,h,0,fmt,ty,values);return n

# A flat receding surface with half-resolution nearest depth, as used with Iris.
# Under the old per-pixel depth comparison every second captured row can be discarded.
def floats(v):return (C.c_float*len(v))(*v)
rgba=floats([.025,.025,.025,1.]*(W*H));alb=floats([.25,.25,.25,1.]*(W//2*H//2))
dep=floats([.5+.35*((y+.5)/H*2-1) for y in range(H) for x in range(W)])
cap=floats([.5+.35*((y+.5)/(H//2)*2-1) for y in range(H//2) for x in range(W//2)])
texture(0,0x8814,0x1908,0x1406,rgba);texture(1,0x822E,0x1903,0x1406,dep)
texture(2,0x8814,0x1908,0x1406,alb,W//2,H//2)
texture(3,0x822E,0x1903,0x1406,floats([100.]*(12*36)),12,36)
texture(4,0x822E,0x1903,0x1406,cap,W//2,H//2)
out=texture(5,0x8814,0x1908,0x1406,None);fbo=U();fn(g,'glGenFramebuffers',None,[I,C.POINTER(U)])(1,C.byref(fbo));fn(g,'glBindFramebuffer',None,[U,U])(0x8D40,fbo);fn(g,'glFramebufferTexture2D',None,[U,U,U,U,I])(0x8D40,0x8CE0,0x0DE1,out,0);assert fn(g,'glCheckFramebufferStatus',U,[U])(0x8D40)==0x8CD5
fn(g,'glUseProgram',None,[U])(program);loc=fn(g,'glGetUniformLocation',I,[U,C.c_char_p]);ui=fn(g,'glUniform1i',None,[I,I]);uf=fn(g,'glUniform1f',None,[I,C.c_float]);u3=fn(g,'glUniform3f',None,[I,C.c_float,C.c_float,C.c_float])
for i,n in enumerate(['Scene','Depth','Albedo','Shadow','AlbedoDepth']):ui(loc(program,n.encode()),i)
ui(loc(program,b'Count'),1)
for n,v in [('CapturedLit',0),('IsoView',0),('Range[0]',100),('HalfTan[0]',2.5),('NearFill[0]',0),('Gain[0]',1)]:uf(loc(program,n.encode()),v)
for n,v in [('Origin[0]',(0,0,.5)),('Forward[0]',(0,0,-1)),('ShadowOrigin[0]',(0,0,.5)),('ShadowForward[0]',(0,0,-1)),('ShadowRight[0]',(1,0,0)),('ShadowUp[0]',(0,1,0))]:u3(loc(program,n.encode()),*v)

# World plane p=(10*x,10*y,21*y-25), viewed through a depth buffer.
inv=(C.c_float*16)(10,0,0,0,0,10,0,0,0,0,30,0,0,0,-25,1)
for n in ['InverseViewProjection','ViewProjection']:fn(g,'glUniformMatrix4fv',None,[I,I,U,P])(loc(program,n.encode()),1,0,inv)
fn(g,'glUniform2f',None,[I,C.c_float,C.c_float])(loc(program,b'FogDistance'),0,100)
vao=U();fn(g,'glGenVertexArrays',None,[I,C.POINTER(U)])(1,C.byref(vao));fn(g,'glBindVertexArray',None,[U])(vao);fn(g,'glViewport',None,[I,I,I,I])(0,0,W,H);fn(g,'glDrawArrays',None,[U,I,I])(4,0,3)
pixels=(C.c_float*(W*H*4))();fn(g,'glReadPixels',None,[I,I,I,I,U,U,P])(0,0,W,H,0x1908,0x1406,pixels)

row=[pixels[(y*W+W//2)*4] for y in range(H//4,3*H//4)]
variation=sum(abs(row[i+1]-row[i]) for i in range(len(row)-1))/(len(row)-1)
contrast=max(row)-min(row)
print('STRIPE_MEAN_ADJACENT_ROW_CHANGE',variation,'CONTRAST',contrast)
assert fn(g,'glGetError',U,[])()==0
if 'light61' in sys.argv[1] or 'light62' in sys.argv[1]:
 assert variation<.006,variation
 assert min(row)>.03,min(row)
 print('HALF_RESOLUTION_SLOPED_PLANE_NO_DISCARDED_ROWS=PASS')
else:
 assert variation>.008,variation
 print('OLD_HALF_RESOLUTION_STRIPES=REPRODUCED')
