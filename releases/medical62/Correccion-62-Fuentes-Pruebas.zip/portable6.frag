#version 150
uniform sampler2D Scene,Depth,Albedo,Shadow,AlbedoDepth;
uniform mat4 InverseViewProjection,ViewProjection;
uniform float CapturedLit,IsoView;
uniform int Count;uniform vec2 FogDistance;
uniform vec3 Origin[3],Forward[3],Right[3],Up[3];
uniform vec3 ShadowOrigin[3],ShadowForward[3],ShadowRight[3],ShadowUp[3];
uniform float Range[3],HalfTan[3],NearFill[3],Gain[3];
in vec2 texCoord;out vec4 fragColor;
// Bilinear percentage-closer filtering avoids the old 12x12 stepping pattern.
float shadow(int i,vec3 p,vec3 normal){
 float current=1.;vec3 d=p-ShadowOrigin[i];float z=dot(d,ShadowForward[i]);
 vec2 uv=vec2(dot(d,ShadowRight[i]),dot(d,ShadowUp[i]))/(max(.01,z)*HalfTan[i]*1.4)*.5+.5;
 if(z<=0.||any(lessThan(uv,vec2(0)))||any(greaterThan(uv,vec2(1))))return current;
 vec2 grid=uv*12.-.5,cell=floor(grid),blend=fract(grid);float sum=0.;
 for(int y=0;y<2;y++)for(int x=0;x<2;x++){
  vec2 q=(clamp(cell+vec2(x,y),vec2(0),vec2(11))+.5)/12.;
  vec3 ray=ShadowForward[i]+ShadowRight[i]*((q.x*2.-1.)*HalfTan[i]*1.4)+ShadowUp[i]*((q.y*2.-1.)*HalfTan[i]*1.4);
  float denom=dot(normal,ray),compareDepth=z;
  if(abs(denom)>.025){float planeDepth=dot(normal,d)/denom;if(planeDepth>0.&&planeDepth<Range[i]*2.)compareDepth=planeDepth;}
  q.y=(q.y+float(i))/3.;float limit=texture(Shadow,q).r;
  float weight=(x==0?1.-blend.x:blend.x)*(y==0?1.-blend.y:blend.y);
  sum+=weight*(1.-smoothstep(limit+.12,limit+.40,compareDepth));
 }
 float edge=min(min(uv.x,uv.y),min(1.-uv.x,1.-uv.y));return mix(1.,sum,smoothstep(0.,.12,edge));
}

void main(){vec4 base=texture(Scene,texCoord);float depth=texture(Depth,texCoord).r;if(depth>=.999999||abs(base.a-251./255.)<.0015){fragColor=base;return;}vec4 h=InverseViewProjection*vec4(texCoord*2.-1.,depth*2.-1.,1);vec3 p=h.xyz/h.w;vec3 gradient=cross(dFdx(p),dFdy(p));float gradientLength=length(gradient);vec3 normal=gradientLength>.000001?gradient/gradientLength:normalize(-p);if(dot(normal,p)>0.)normal=-normal;float fog=FogDistance.y>FogDistance.x+.1?1.-smoothstep(FogDistance.x,FogDistance.y,mix(length(p),length(p-Origin[0]),IsoView)):1.;// Capture is half resolution with Iris. Compare points on the local surface,
// not raw depth from two different pixel centres (which stripes sloped ground).
vec4 albedo=vec4(base.rgb,1.);float best=1e20;
if(CapturedLit<.5){
vec2 size=vec2(textureSize(AlbedoDepth,0));vec2 corner=floor(texCoord*size-.5);
for(int y=0;y<2;y++)for(int x=0;x<2;x++){
 vec2 uv=(clamp(corner+vec2(x,y),vec2(0.),size-1.)+.5)/size;
 float cd=texture(AlbedoDepth,uv).r;if(cd>=.999999)continue;
 vec4 cp=InverseViewProjection*vec4(uv*2.-1.,cd*2.-1.,1.);
 vec3 delta=cp.xyz/cp.w-p;
 float error=abs(dot(delta,normal));
 // Limit tangential reach at silhouettes, but allow the footprint of a low-res pixel.
 float reach=max(.15,4.*(length(dFdx(p))+length(dFdy(p))));
 vec4 candidate=texture(Albedo,uv);
 if(error<best&&error<max(.025,length(p)*.0005)&&length(delta)<reach&&candidate.a>.01){best=error;albedo=candidate;}
}
}
if(CapturedLit>.5){float peak=max(albedo.r,max(albedo.g,albedo.b));albedo.rgb=clamp(pow(max(albedo.rgb,vec3(0.)),vec3(.55))*1.35,0.,.85);}
vec3 light=vec3(0);float coverage=0.;for(int i=0;i<Count;i++){vec3 v=p-Origin[i];float distance=length(v);vec3 direction=normalize(Forward[i]-vec3(0.,.35*NearFill[i],0.));float aperture=HalfTan[i]*mix(1.,1.35,NearFill[i])*mix(1.,1.25,IsoView);float c=dot(v/max(.001,distance),direction);float outer=inversesqrt(1.+aperture*aperture),inner=inversesqrt(1.+aperture*aperture*.40);float spot=smoothstep(outer,inner,c);float fade=pow(clamp(1.-distance/Range[i],0.,1.),1.3);float beamPower=spot*fade;if(distance>=Range[i]||beamPower<.0001)continue;float incidence=.55+.45*max(0.,dot(normal,-v/max(.001,distance)));float power=beamPower*shadow(i,p,normal)*incidence*fog*Gain[i];light+=vec3(1.,.96,.88)*power*1.15;coverage=max(coverage,power);}
vec3 response=light/(vec3(1.)+light*.35);vec3 ambient=albedo.rgb*vec3(.065,.075,.10)*IsoView;vec3 lit=base.rgb+(vec3(1.)-base.rgb)*albedo.rgb*response*.95+ambient;float a=coverage>.002&&abs(base.a-253./255.)>.0015?250./255.:base.a;fragColor=vec4(lit,a);}
