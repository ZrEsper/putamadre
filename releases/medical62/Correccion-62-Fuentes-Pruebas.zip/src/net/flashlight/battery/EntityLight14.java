/*
 * Decompiled with CFR 0.152.
 */
package net.flashlight.battery;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.flashlight.battery.Light6;
import net.flashlight.battery.Matrix6;
import net.flashlight.battery.Power;
import net.flashlight.battery.R;

public final class EntityLight14 {
    static final LinkedHashMap<Object, Frame> FRAMES=new LinkedHashMap<>(16,.75f,true);
    static final class Frame {long tick=Long.MIN_VALUE;int level;}
    static int stable(Object entity,long now,int base,double power){
        Frame f=FRAMES.get(entity);if(f==null){f=new Frame();FRAMES.put(entity,f);if(FRAMES.size()>128)FRAMES.remove(FRAMES.keySet().iterator().next());}
        if(f.tick!=now){int target=pack(0,power)>>4&15;int gap=f.tick==Long.MIN_VALUE?1:(int)Math.max(1,Math.min(4,now-f.tick));
            f.level=target>f.level?Math.min(target,f.level+2*gap):Math.max(target,f.level-3*gap);f.tick=now;}
        return base&0xFFFFFF0F|Math.max(base>>4&15,f.level)<<4;
    }
    static Object world;
    static long tick;
    static int rays;
    static boolean playerLit;
    static final ArrayList<Light6.Lamp> active;
    static final int BUDGET = 24;
    static final int MAX = 128;
    static final LinkedHashMap<Object, Map<Object, Hit>> CACHE;

    static {
        tick = Long.MIN_VALUE;
        active = new ArrayList(2);
        CACHE = new LinkedHashMap(16, 0.75f, true);
    }

    public static void reset(Object object) {
        if (world != object) {
            world = object;
            CACHE.clear();FRAMES.clear();
            tick = Long.MIN_VALUE;
            active.clear();
            playerLit = false;
        }
    }

    public static void invalidate() {
        tick = Long.MIN_VALUE;
    }

    static double d(double[] dArray, double[] dArray2) {
        double d = 0.0;
        int n = 0;
        while (n < 3) {
            d += (dArray[n] - dArray2[n]) * (dArray[n] - dArray2[n]);
            ++n;
        }
        return Math.sqrt(d);
    }

    static double smooth(double d) {
        d = Math.max(0.0, Math.min(1.0, d));
        return d * d * (3.0 - 2.0 * d);
    }

    static double strength(Light6.Lamp lamp, double[] dArray, double d) {
        double[] dArray2 = new double[]{dArray[0] - lamp.origin[0], dArray[1] - lamp.origin[1], dArray[2] - lamp.origin[2]};
        double d2 = Math.sqrt(Light6.dot(dArray2, dArray2));
        double d3 = Light6.dot(dArray2, lamp.forward);
        if (d2 > lamp.range || d3 <= 0.0) {
            return 0.0;
        }
        double d4 = Math.sqrt(Math.max(0.0, d2 * d2 - d3 * d3));
        double d5 = d3 * lamp.tan + Math.min(0.45, d);
        double d6 = 1.0 - EntityLight14.smooth((d4 - d5 * 0.6) / Math.max(0.01, d5 * 0.4));
        return d6 * Math.pow(Math.max(0.0, 1.0 - d2 / lamp.range), 1.1);
    }

    static int pack(int n, double d) {
        if (d <= 0.002) {
            return n;
        }
        int n2 = Math.min(15, (int)Math.ceil(12.0 * Math.pow(Math.min(1.0, d), 0.35)));
        return n & 0xFFFFFF0F | Math.max(n >> 4 & 0xF, n2) << 4;
    }

    static boolean clear(Object object, Light6.Lamp lamp, double[] dArray, long l) {
        Hit hit;
        Map<Object, Hit> map = CACHE.get(object);
        if (map == null) {
            map = new IdentityHashMap<Object, Hit>();
            CACHE.put(object, map);
            if (CACHE.size() > 128) {
                CACHE.remove(CACHE.keySet().iterator().next());
            }
        }
        if ((hit = map.get(lamp)) != null && l - hit.tick() < 3L && EntityLight14.d(hit.from(), lamp.origin) < 0.2 && EntityLight14.d(hit.to(), dArray) < 0.35) {
            return hit.clear();
        }
        if (rays >= 24) {
            return hit != null && l - hit.tick() < 6L && EntityLight14.d(hit.from(), lamp.origin) < 1.5 && EntityLight14.d(hit.to(), dArray) < 1.5 && hit.clear();
        }
        ++rays;
        double d = EntityLight14.d(lamp.origin, dArray);
        double[] dArray2 = new double[]{dArray[0] - lamp.origin[0], dArray[1] - lamp.origin[1], dArray[2] - lamp.origin[2]};
        boolean bl = d < 0.6 || Light6.trace(lamp, lamp.origin, Light6.normal(dArray2)) >= d - 0.1;
        if(map.size()>=8&&!map.containsKey(lamp))map.clear();
        map.put(lamp, new Hit(l, (double[])lamp.origin.clone(), (double[])dArray.clone(), bl));
        return bl;
    }

    public static int light(Object object, float f, int n) {
        try {
            Object object3 = Light6.mc();
            Object object4 = R.get(object3, "level");
            if (object4 == null) {
                world = null;
                CACHE.clear();FRAMES.clear();
                active.clear();
                playerLit = false;
                return n;
            }
            if (object == null) {
                return n;
            }
            if (world != object4) {
                world = object4;
                CACHE.clear();FRAMES.clear();
                tick = Long.MIN_VALUE;
            }
            long l = ((Number)R.call(object4, "getGameTime", new Object[0])).longValue();
            Object object5 = R.get(object3, "player");
            if (l != tick) {
                tick = l;
                rays = 0;
                active.clear();
                boolean bl = playerLit = object5 != null && Power.active(object5) != null;
                if (Light6.world == object4) {
                    for (Light6.Lamp object22 : Light6.cache.values()) {
                        if (!Light6.source(object22.owner)) continue;
                        active.add(object22);
                    }
                    if(Vehicle59.world==object4)for(Light6.Lamp vehicle:Vehicle59.last)if(Vehicle59.vehicles.contains(vehicle)&&!active.contains(vehicle))active.add(vehicle);
                }
            }
            if (object == object5 && playerLit) {
                return n & 0xFFFFFF0F | Math.max(n >> 4 & 0xF, 6) << 4;
            }
            if (Light6.world != object4 || active.isEmpty()) {
                CACHE.clear();
                return stable(object,l,n,0);
            }
            Frame previous=FRAMES.get(object);if(previous!=null&&previous.tick==l)return stable(object,l,n,0);
            double[] dArray = Matrix6.xyz(R.call(R.call(object, "getBoundingBox", new Object[0]), "getCenter", new Object[0]));
            double d = ((Number)R.call(object, "getBbWidth", new Object[0])).doubleValue() * 0.5;
            double d2 = 0.0;
            for (Light6.Lamp lamp : active) {
                double d3 = EntityLight14.strength(lamp, dArray, d);
                if (!(d3 > d2) || !(d3 > 0.002) || !EntityLight14.clear(object, lamp, dArray, l)) continue;
                d2 = d3;
            }
            return stable(object,l,n,d2);
        }
        catch (RuntimeException runtimeException) {
            return n;
        }
    }

    record Hit(long tick, double[] from, double[] to, boolean clear) {
    }
}

