from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import subprocess,json,hashlib
r=Path('work/gore12')
inputs=[next(Path('attachments/'+p).glob('*.jar')) for p in ['258f1de9-de84-416f-b7f2-4a351cd758c4','c6625f9d-c74f-4427-a61d-d6e94911b74f','0e9297d0-5a7c-43a5-962f-6181858d3f04','2aa218b1-7b0f-4032-aca6-23fe6d32e10a']]
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
def run(args):subprocess.run(args,check=True)
run(['java','com.sun.tools.javac.Main','-cp',str(inputs[0]),'-d',str(r/'classes'),*map(str,(r/'src').rglob('*.java')),*map(str,(r/'stubs').rglob('*.java'))])
run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(r/'tools'),str(r/'Patch.java')])
run(['java',*flags,'-cp',str(r/'tools'),'Patch',*map(str,inputs[:3])])
run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/belroft3/classes','Verify',str(r/'classes')])
out=r/'release';out.mkdir(exist_ok=True);manifest=[]
names=['zomboid-zombie-gore-1.0.12-neoforge-1.21.1-ragdoll-trauma.jar','ragdollified-1.21.1-1.1.5-gore-preservation.1.jar','mobdismembermentneoforge-1.21.1-1.4.0-explosions-only.2.jar',inputs[3].name]
prefixes=['dev/zomboid/gore/','com/raiiiden/ragdollified/','me/ichun/mods/mobdismemberment/',None]
for index,(base,name,prefix) in enumerate(zip(inputs,names,prefixes)):
 with ZipFile(base) as z: data={n:z.read(n) for n in z.namelist()};original=data.copy()
 changes={p.relative_to(r/'classes').as_posix():p.read_bytes() for p in (r/'classes'/prefix).rglob('*.class')} if prefix else {}
 data.update(changes)
 if index==0:
  config=json.loads(data['zomboid_gore.mixins.json']);config['mixins'].append('ExplosionEvent12');config['client']+=['LivingWound12','WoundModel12'];data['zomboid_gore.mixins.json']=json.dumps(config,indent=2).encode()
  data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'version="1.0.11"',b'version="1.0.12"')
  for p in (r/'assets').rglob('*.png'):data[p.relative_to(r/'assets').as_posix()]=p.read_bytes()
 elif index in (1,2):
  mod='ragdollified' if index==1 else 'mobdismemberment';metadata=data['META-INF/neoforge.mods.toml'].decode()
  if index==1:metadata=metadata.replace('version="1.1.5"','version="1.1.5-gore12"')
  else:metadata=metadata.replace('version="1.21.1-1.4.0"','version="1.21.1-1.4.0-explosions2"')
  metadata+='\n[[dependencies.'+mod+']]\nmodId="zomboid_gore"\ntype="required"\nversionRange="[1.0.12,1.0.13)"\nordering="AFTER"\nside="'+('BOTH' if index==1 else 'CLIENT')+'"\n'
  data['META-INF/neoforge.mods.toml']=metadata.encode()
 if index==3:(out/name).write_bytes(base.read_bytes())
 else:
  with ZipFile(out/name,'w',ZIP_DEFLATED) as z:
   for n,b in data.items():z.writestr(n,b)
 with ZipFile(out/name) as z:
  assert z.testzip() is None
  assert not any(n.startswith('net/minecraft/') or n.startswith('com/mojang/') for n in z.namelist())
  modified=[n for n in original if data[n]!=original[n]]
 manifest.append(dict(input=str(base),input_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),file=name,sha256=hashlib.sha256((out/name).read_bytes()).hexdigest(),modified=modified,added=[n for n in data if n not in original]))
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('PASS: JAR integrity, no Minecraft stubs packaged, Splatter unchanged; release built')
