import java.nio.file.*;import java.util.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public class CheckPatch {
 static ClassNode read(String path)throws Exception{ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of("work/gore12/classes/"+path+".class"))).accept(c,0);return c;}
 static int calls(ClassNode c,String method,String owner,String name){int n=0;for(MethodNode m:c.methods)if(method==null||m.name.equals(method))for(AbstractInsnNode x:m.instructions.toArray())if(x instanceof MethodInsnNode a&&a.owner.equals(owner)&&a.name.equals(name))n++;return n;}
 static void check(boolean x,String s){if(!x)throw new AssertionError(s);}
 public static void main(String[] args)throws Exception{
  String G="dev/zomboid/gore/",D="com/raiiiden/ragdollified/";
  ClassNode packet=read(D+"network/RagdollSpawnPacket");check(calls(packet,"encode","net/minecraft/network/RegistryFriendlyByteBuf","writeInt")==4,"id and 3 snapshot integers encoded");check(calls(packet,"decode","net/minecraft/network/RegistryFriendlyByteBuf","readInt")==4,"id and 3 snapshot integers decoded");
  for(MethodNode m:packet.methods)for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.name.equals("writeInt"))check(x.desc.equals("(I)Lnet/minecraft/network/FriendlyByteBuf;"),"actual vanilla writeInt linkage");
  check(calls(packet,"handleClient",G+"Trauma12","snapshot")==1,"network packet copies wound snapshot");check(calls(read(D+"client/ClientRagdollManager"),"createFromEntity",G+"Rag12","local")==1,"local death path copies wounds");check(calls(read(D+"server/ServerRagdollSyncManager"),"register",G+"Trauma12","packet")==1,"retained snapshots store wounds for late viewers");
  ClassNode renderer=read(D+"client/ClientRagdollRenderer");check(calls(renderer,"renderHumanoidMob",G+"Skin12","ragdollModel")==1,"actual humanoid render overload bound");check(calls(renderer,"renderMobRagdoll",G+"Skin12","ragdoll")==1,"per-ragdoll context");
  ClassNode gib=read("me/ichun/mods/mobdismemberment/client/core/EventHandlerClient");check(calls(gib,"queueDismember",G+"Trauma12","blastAllowed")==1&&calls(gib,"dismember",G+"Trauma12","blastAllowed")==1,"both dismember paths require explosion marker");check(calls(gib,"dismember",G+"Blood12","nativeBlood")==1,"native particles share blood budget");
  System.out.println("PASS: both death paths, late-observer snapshots, wire fields and descriptors, humanoid render hook, explosion-only gates and shared particle budget");
 }
}
