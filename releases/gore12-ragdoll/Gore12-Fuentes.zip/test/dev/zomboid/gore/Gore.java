package dev.zomboid.gore;
public class Gore {
 static ThreadLocal<Shot> shots=new ThreadLocal<>();
 static boolean zombie(Object e){return e instanceof Test12.Entity;}
 static Object tag(Object e){return ((Test12.Entity)e).tag;}
 static int state(Object e){return ((Test12.Entity)e).state;}static void set(Object e,int n){((Test12.Entity)e).state=n;}
 static int surfaces(Object e){return ((Test12.Entity)e).surfaces;}static void surfaceSet(Object e,int n){((Test12.Entity)e).surfaces=n;}
 static void push(Object e,Object b,Rules.Weapon w){}
 record Shot(Object bullet,Object entity,Object point,boolean head,Rules.Weapon gun){}
}
