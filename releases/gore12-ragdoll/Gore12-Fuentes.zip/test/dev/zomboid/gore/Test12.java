package dev.zomboid.gore;
import java.util.*;
public class Test12 {
 public static class Pos{public double x,y,z;Pos(double x,double y){this.x=x;this.y=y;}}
 public static class Tag{Map<String,Object> m=new HashMap<>();public int getInt(String k){return ((Number)m.getOrDefault(k,0)).intValue();}public void putInt(String k,int v){m.put(k,v);}public float getFloat(String k){return ((Number)m.getOrDefault(k,0)).floatValue();}public void putFloat(String k,float v){m.put(k,v);}public boolean getBoolean(String k){return Boolean.TRUE.equals(m.get(k));}public void putBoolean(String k,boolean v){m.put(k,v);}}
 public static class Data{int d;public int get(Object key){return d;}public void set(Object key,int val){d=val;}}
 public static class Level{public boolean isClientSide;int sent;public long getGameTime(){return 120;}public void broadcastEntityEvent(Object e,byte b){sent++;check(b==121,"blast event byte");}}
 public static class Entity{Tag tag=new Tag();Data data=new Data();Level level=new Level();float hp=40,max=40;boolean dead;int state,surfaces;public Data getEntityData(){return data;}public int getId(){return 15;}public double getY(){return 0;}public Pos position(){return new Pos(0,0);}public float getYRot(){return 0;}public float getBbHeight(){return 2;}public float getHealth(){return hp;}public float getMaxHealth(){return max;}public void setHealth(float h){hp=h;}public void die(Object s){dead=true;}public Level level(){return level;}}
 public static class Source{boolean blast;Source(boolean b){blast=b;}public boolean is(Object tag){return blast;}}
 public static class Event{Entity e;float amount;Source source;Event(Entity e,float a,boolean b){this.e=e;amount=a;source=new Source(b);}public Entity getEntity(){return e;}public float getAmount(){return amount;}public void setAmount(float a){amount=a;}public Object getSource(){return source;}}
 public static class Packet{public int goreState12,goreDetails12,goreSurface12;int mask;public Packet severedMask(int mask){this.mask=mask;return this;}public byte severedMask(){return (byte)mask;}}
 public static class Spawn{public int goreState12,goreDetails12,goreSurface12,severedMask;}
 static void hit(Entity e,boolean head,double x,double y,Rules.Weapon w){Gore.shots.set(new Gore.Shot(new Object(),e,new Pos(x,y),head,w));Event ev=new Event(e,100,false);Ballistics11.incoming(ev);e.hp-=ev.amount;Ballistics11.injure(e,Gore.shots.get(),ev.amount,0);Ballistics11.clear();Gore.shots.remove();}
 static void check(boolean b,String msg){if(!b)throw new AssertionError(msg);}
 static double volume(Mesh12.Box b){return (b.x1()-b.x0())*(b.y1()-b.y0())*(b.z1()-b.z0());}
 public static void main(String[] args){Trauma12.accessor="details";
  int bits=0;for(int z=0;z<8;z++)bits=Trauma12.withStage(bits,z,z);for(int z=0;z<8;z++)check(Trauma12.stage(bits,z)==z,"independent region bits");
  Entity e=new Entity();hit(e,true,0,1.9,Rules.Weapon.PISTOL);check(!e.dead&&Trauma12.stage(Trauma12.details(e),0)==6,"open head on first hit");hit(e,true,0,1.9,Rules.Weapon.PISTOL);check(e.dead&&(e.state&255)==0&&Trauma12.stage(Trauma12.details(e),0)==7,"fatal second head retains partial cranium and eye");
  e=new Entity();for(int k=0;k<5;k++)hit(e,false,.24,1.02,Rules.Weapon.PISTOL);check(!e.dead&&(e.state&255)==0&&Trauma12.stage(Trauma12.details(e),2)==1,"hand damage, no full arm sever");
  e=new Entity();for(int k=0;k<3;k++)hit(e,false,.24,1.2,Rules.Weapon.PISTOL);check(Trauma12.stage(Trauma12.details(e),2)==2,"elbow hit region");
  e=new Entity();for(int k=0;k<3;k++)hit(e,false,.24,1.4,Rules.Weapon.PISTOL);check(Trauma12.stage(Trauma12.details(e),2)==4,"upper arm region");
  hit(e,false,.24,1.02,Rules.Weapon.PISTOL);check(Trauma12.stage(Trauma12.details(e),2)==5,"upper arm and hand injuries accumulate without regrowth");
  e=new Entity();Ballistics11.injure(e,new Gore.Shot(null,e,new Pos(.24,1.3),false,Rules.Weapon.OTHER),100,2);check((e.state&255)==0,"melee never severs full members");
  Entity normal=new Entity();Trauma12.death(new Event(normal,40,false));check(normal.state==0&&normal.level.sent==0,"non-explosion death untouched");
  e=new Entity();Trauma12.death(new Event(e,40,true));check((e.state&60)!=0&&e.level.sent==1,"explosion detaches limbs and broadcasts");Trauma12.death(new Event(e,40,true));check(e.level.sent==1,"death event deduplicates");check(Trauma12.ragMask(4)==16&&Trauma12.ragMask(8)==32&&Trauma12.ragMask(16)==4&&Trauma12.ragMask(32)==8&&Trauma12.ragMask(1)==2,"exact limb mask order");
  Packet p=new Packet();p.mask=2;Trauma12.packet(e,p);check((p.mask&Trauma12.ragMask(e.state))==Trauma12.ragMask(e.state),"packet carries absent limbs");Spawn sp=new Spawn();Trauma12.snapshot(p,sp);check(sp.goreState12==e.state&&sp.goreDetails12==e.data.d,"snapshot survives entity removal");
  Tag save=new Tag();Trauma12.save(e,save);Entity loaded=new Entity();Trauma12.restore(loaded,save);check(loaded.data.d==e.data.d,"wounds persist");
  Object remote=new Object();check(!Trauma12.blastAllowed(remote),"ordinary mobs not dismembered");check(!Trauma12.entityEvent(remote,(byte)3),"ordinary entity event untouched");Trauma12.entityEvent(remote,(byte)121);check(Trauma12.blastAllowed(remote),"server-marked blast allowed");
  Mesh12.Box box=new Mesh12.Box(0,0,0,4,12,4),cut=new Mesh12.Box(2,4,-1,5,8,2);double sum=0;for(Mesh12.Box b:Mesh12.subtract(box,cut))sum+=volume(b);check(Math.abs(sum-(192-16))<.001,"partial mesh subtracts volume");check(Mesh12.subtract(box,new Mesh12.Box(-1,-1,-1,5,13,5)).isEmpty(),"whole cuboid subtraction");
  for(int zone:new int[]{0,2,3,4,5,6})for(int stage=1;stage<=7;stage++){var mesh=Mesh12.build(List.of(Skin12.fallback(zone)),zone,stage);check(!mesh.isEmpty()&&mesh.size()<=64,"bounded wound mesh");for(var q:mesh)for(var v:q.vertices())check(Float.isFinite(v.x())&&Float.isFinite(v.u()),"finite mesh coordinates");}
  System.out.println("PASS: firearm and melee explosion-only severing, hand/elbow/upper-arm damage, head death, blast events, ragdoll masks, snapshots, NBT, mesh clipping and bounds");
 }
}
