package net.minecraft.tags; public class DamageTypeTags {public static final Object IS_EXPLOSION=new Object();}
