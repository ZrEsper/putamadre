package dev.zomboid.gore;
import java.util.*;
/** Small cached voxel meshes: skin fragments, exposed muscle, bone and a tethered eye. */
public final class Mesh12 {
 public record Box(float x0,float y0,float z0,float x1,float y1,float z1) {
  boolean valid(){return x1-x0>.001f&&y1-y0>.001f&&z1-z0>.001f;}
 }
 public record Vertex(float x,float y,float z,float u,float v) {}
 public record Quad(Vertex[] vertices,int material,float nx,float ny,float nz) {}
 public record Face(float[][] xyz,float[] u,float[] v,float nx,float ny,float nz){}
 public record Cube(Box bounds,List<Face> faces){}
 static final Map<String,List<Quad>> CACHE=new LinkedHashMap<>(){protected boolean removeEldestEntry(Map.Entry<String,List<Quad>> e){return size()>192;}};
 static Box intersect(Box a,Box b){return new Box(Math.max(a.x0,b.x0),Math.max(a.y0,b.y0),Math.max(a.z0,b.z0),Math.min(a.x1,b.x1),Math.min(a.y1,b.y1),Math.min(a.z1,b.z1));}
 public static List<Box> subtract(Box a,Box cut){Box c=intersect(a,cut);if(!c.valid())return List.of(a);List<Box> out=new ArrayList<>();
  for(Box b:List.of(new Box(a.x0,a.y0,a.z0,c.x0,a.y1,a.z1),new Box(c.x1,a.y0,a.z0,a.x1,a.y1,a.z1),new Box(c.x0,a.y0,a.z0,c.x1,c.y0,a.z1),new Box(c.x0,c.y1,a.z0,c.x1,a.y1,a.z1),new Box(c.x0,c.y0,a.z0,c.x1,c.y1,c.z0),new Box(c.x0,c.y0,c.z1,c.x1,c.y1,a.z1)))if(b.valid())out.add(b);return out;
 }
 public static Box canonical(int z){return z==0?new Box(-4,-8,-4,4,0,4):z==2?new Box(-1,-2,-2,3,10,2):z==3?new Box(-3,-2,-2,1,10,2):z==4||z==5?new Box(-2,0,-2,2,12,2):new Box(-4,0,-2,4,12,2);}
 static Box cut(Box b,int z,int stage){float w=b.x1-b.x0,h=b.y1-b.y0,d=b.z1-b.z0;
  if(z==0&&stage>=6)return new Box(b.x0+w*.47f,b.y0-1,b.z0-1,b.x1+1,b.y0+h*.54f,b.z0+d*.72f);
  if((z==2||z==3)&&stage==3)return new Box(b.x0-1,b.y0+h*.72f,b.z0-1,b.x1+1,b.y1+1,b.z1+1);
  float low=z==2||z==3?(stage==4?.38f:stage==5?.14f:.48f):z>=4&&z<6?.64f:.35f;
  return new Box(b.x0+w*(stage==1?.28f:.38f),b.y0+h*low,b.z0-1,b.x1+1,b.y0+h*Math.min(.96f,low+(stage==1?.16f:.27f)),b.z0+d*(stage==1?.23f:.65f));
 }
 public static List<Quad> build(List<Cube> original,int zone,int stage){List<Quad> out=new ArrayList<>();if(original.isEmpty())return out;
  float x0=Float.MAX_VALUE,y0=x0,z0=x0,x1=-x0,y1=-x0,z1=-x0;
  for(Cube c:original){Box b=c.bounds;x0=Math.min(x0,b.x0);y0=Math.min(y0,b.y0);z0=Math.min(z0,b.z0);x1=Math.max(x1,b.x1);y1=Math.max(y1,b.y1);z1=Math.max(z1,b.z1);}
  Box all=new Box(x0,y0,z0,x1,y1,z1);boolean arm=zone==2||zone==3;
  List<Box> cuts=new ArrayList<>();
  if(arm&&stage!=8){if((stage&1)!=0)cuts.add(cut(all,zone,3));if((stage&2)!=0)cuts.add(cut(all,zone,4));if((stage&4)!=0)cuts.add(cut(all,zone,5));}else cuts.add(cut(all,zone,stage==8?1:stage));
  if(cuts.isEmpty())cuts.add(cut(all,zone,1));Box cut=cuts.get(0);
  for(Cube c:original){List<Box> fragments=List.of(c.bounds);for(Box wound:cuts){List<Box> next=new ArrayList<>();for(Box f:fragments)next.addAll(subtract(f,wound));fragments=next;}for(Box frag:fragments)box(out,frag,0,c);}
  float cx=(cut.x0+Math.min(cut.x1,all.x1))*.5f,cy=(cut.y0+Math.min(cut.y1,all.y1))*.5f;
  if(zone==0&&stage>=6){
   box(out,new Box(all.x0+(x1-x0)*.55f,all.y0+.3f,all.z0+(z1-z0)*.68f,all.x1-.4f,all.y0+1.0f,all.z0+(z1-z0)*.80f),2,null);
   // Broken cranial edges and a small exposed brain silhouette, all attached to the wound.
   float brainY=all.y0+(y1-y0)*.50f,back=all.z0+(z1-z0)*.63f;
   for(int j=0;j<3;j++){float bx=all.x0+(x1-x0)*(.53f+j*.12f);box(out,new Box(bx,brainY-.5f-(j%2)*.25f,back-.8f,bx+.8f,brainY+.12f,back+.3f),5,null);}
   if(stage==7){float ex=all.x0+(x1-x0)*.72f,ey=all.y0+(y1-y0)*.61f,ez=all.z0-1.4f;
    box(out,new Box(ex-.13f,ey-1.7f,ez+.35f,ex+.13f,ey,ez+.6f),1,null);
    box(out,new Box(ex-.7f,ey-.6f,ez-.5f,ex+.7f,ey+.6f,ez+.6f),3,null);
    box(out,new Box(ex-.28f,ey-.28f,ez-.57f,ex+.28f,ey+.28f,ez-.5f),4,null);
   }
  }else if(arm&&stage!=8&&(stage&1)!=0){float y=all.y0+(y1-y0)*.72f;box(out,new Box((x0+x1)*.5f-.35f,y-.1f,(z0+z1)*.5f-.35f,(x0+x1)*.5f+.35f,y+1.2f,(z0+z1)*.5f+.35f),2,null);
  }else if(stage>=2){box(out,new Box(cx-.25f,cy-.65f,Math.max(all.z0,cut.z1)-.25f,cx+.25f,cy+.65f,Math.max(all.z0,cut.z1)+.25f),2,null);}
  return List.copyOf(out);
 }
 static void box(List<Quad> out,Box b,int mat,Cube original){
  float a=b.x0,c=b.y0,e=b.z0,d=b.x1,f=b.y1,g=b.z1;
  float[][][] faces={{{a,c,e},{a,c,g},{a,f,g},{a,f,e}},{{d,c,g},{d,c,e},{d,f,e},{d,f,g}},{{a,c,g},{a,c,e},{d,c,e},{d,c,g}},{{a,f,e},{a,f,g},{d,f,g},{d,f,e}},{{d,c,e},{a,c,e},{a,f,e},{d,f,e}},{{a,c,g},{d,c,g},{d,f,g},{a,f,g}}};
  float[][] norms={{-1,0,0},{1,0,0},{0,-1,0},{0,1,0},{0,0,-1},{0,0,1}};
  for(int i=0;i<6;i++){Face source=null;int material=mat;
   if(original!=null){Box o=original.bounds;boolean outside=switch(i){case 0->Math.abs(a-o.x0)<.001;case 1->Math.abs(d-o.x1)<.001;case 2->Math.abs(c-o.y0)<.001;case 3->Math.abs(f-o.y1)<.001;case 4->Math.abs(e-o.z0)<.001;default->Math.abs(g-o.z1)<.001;};
    if(outside){for(Face face:original.faces)if(face.nx*norms[i][0]+face.ny*norms[i][1]+face.nz*norms[i][2]>.9f){source=face;break;}}else material=1;
    if(source==null)material=1;
   }
   Vertex[] vs=new Vertex[4];for(int j=0;j<4;j++){float[] p=faces[i][j];float u=.05f+(j==1||j==2?.4f:0),v=.05f+(j>=2?.4f:0);
    if(source!=null){float[] q=source.xyz[0],r=source.xyz[1],s=source.xyz[3];float du=0,dv=0,l1=0,l2=0;for(int k=0;k<3;k++){du+=(p[k]-q[k])*(r[k]-q[k]);l1+=(r[k]-q[k])*(r[k]-q[k]);dv+=(p[k]-q[k])*(s[k]-q[k]);l2+=(s[k]-q[k])*(s[k]-q[k]);}du/=Math.max(.001f,l1);dv/=Math.max(.001f,l2);u=source.u[0]+du*(source.u[1]-source.u[0])+dv*(source.u[3]-source.u[0]);v=source.v[0]+du*(source.v[1]-source.v[0])+dv*(source.v[3]-source.v[0]);}
    vs[j]=new Vertex(p[0]/16,p[1]/16,p[2]/16,u,v);
   }
   out.add(new Quad(vs,material,norms[i][0],norms[i][1],norms[i][2]));
  }
 }
}
