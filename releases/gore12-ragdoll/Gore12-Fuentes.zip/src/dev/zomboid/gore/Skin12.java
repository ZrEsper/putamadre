package dev.zomboid.gore;
import java.util.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
/** One mesh per model/region/stage; live zombies and ragdolls share exactly the same renderer. */
public final class Skin12 {
 static final Map<Object,Map<Object,Integer>> MODELS=new WeakHashMap<>();
 static final Map<Object,Map<Integer,List<Mesh12.Quad>>> MESHES=new WeakHashMap<>();
 static final ResourceLocation TEXTURE=ResourceLocation.fromNamespaceAndPath("zomboid_gore","textures/entity/trauma12.png");
 static MultiBufferSource bloodBuffer;
 static MultiBufferSource bloodBuffer(){if(bloodBuffer==null)bloodBuffer=(MultiBufferSource)R.call(R.type("net.minecraft.client.renderer.MultiBufferSource"),"immediate",R.make("com.mojang.blaze3d.vertex.ByteBufferBuilder",4096));return bloodBuffer;}
 static final ThreadLocal<Context> CURRENT=new ThreadLocal<>();
 static final int[] COLORS={0xffffffff,0xff92152a,0xffdfcf9c,0xffe8d8c0,0xff17131b,0xffc35a70};
 static final class Context {int state,details;MultiBufferSource buffer;Map<Object,Integer> parts=Map.of();Context(int s,int d,Object b){state=s;details=d;buffer=(MultiBufferSource)b;}}
 static Object optional(Object o,String field){try{return R.get(o,field);}catch(RuntimeException e){return null;}}
 public static Map<Object,Integer> modelParts(Object model){return MODELS.computeIfAbsent(model,k->{Map<Object,Integer> out=new IdentityHashMap<>();String[] names={"head","leftArm","rightArm","leftLeg","rightLeg","body","hat","leftSleeve","rightSleeve","leftPants","rightPants","jacket"};int[] zones={0,2,3,4,5,6,8,10,11,12,13,14};for(int i=0;i<names.length;i++){Object p=optional(model,names[i]);if(p!=null)bind(out,p,zones[i]);}return out;});}
 static void bind(Map<Object,Integer> out,Object part,int zone){if(out.putIfAbsent(part,zone)!=null)return;Object children=optional(part,"children");if(children instanceof Map<?,?> m)for(Object c:m.values())bind(out,c,zone);}
 public static void living(Object renderer,Object entity,Object buffer){CURRENT.remove();if(!Gore.zombie(entity))return;Context c=new Context(Gore.state(entity),Trauma12.details(entity),buffer);c.parts=modelParts(R.call(renderer,"getModel"));CURRENT.set(c);}
 public static void ragdoll(Object doll,Object buffer){CURRENT.remove();Blood12.ragdoll(doll);Context c=new Context(((Number)R.get(doll,"goreState12")).intValue(),((Number)R.get(doll,"goreDetails12")).intValue(),buffer);if(c.state!=0||c.details!=0)CURRENT.set(c);}
 public static void ragdollModel(Object model){Context c=CURRENT.get();if(c!=null)c.parts=modelParts(model);}
 public static void end(){if(CURRENT.get()!=null&&bloodBuffer!=null)R.call(bloodBuffer,"endBatch");CURRENT.remove();}
 static List<Mesh12.Cube> cubes(Object part,int zone){List<Mesh12.Cube> out=new ArrayList<>();Object list=optional(part,"cubes");if(list instanceof List<?> l)for(Object cube:l){try{float[] b=new float[6];String[] fields={"minX","minY","minZ","maxX","maxY","maxZ"};for(int i=0;i<6;i++)b[i]=((Number)R.get(cube,fields[i])).floatValue();List<Mesh12.Face> faces=new ArrayList<>();Object[] polygons=(Object[])R.get(cube,"polygons");for(Object p:polygons){Object[] vs=(Object[])R.get(p,"vertices");if(vs.length!=4)continue;float[][] xyz=new float[4][3];float[] u=new float[4],v=new float[4];for(int j=0;j<4;j++){Object pos=R.get(vs[j],"pos");xyz[j][0]=(float)R.num(R.get(pos,"x"));xyz[j][1]=(float)R.num(R.get(pos,"y"));xyz[j][2]=(float)R.num(R.get(pos,"z"));u[j]=(float)R.num(R.get(vs[j],"u"));v[j]=(float)R.num(R.get(vs[j],"v"));}Object n=R.get(p,"normal");faces.add(new Mesh12.Face(xyz,u,v,(float)R.num(R.get(n,"x")),(float)R.num(R.get(n,"y")),(float)R.num(R.get(n,"z"))));}out.add(new Mesh12.Cube(new Mesh12.Box(b[0],b[1],b[2],b[3],b[4],b[5]),faces));}catch(RuntimeException ignored){}}
  if(out.isEmpty())out.add(fallback(zone));return out;
 }
 static Mesh12.Cube fallback(int zone){Mesh12.Box b=Mesh12.canonical(zone);float x=b.x0(),y=b.y0(),z=b.z0(),X=b.x1(),Y=b.y1(),Z=b.z1();List<Mesh12.Face> fs=new ArrayList<>();float[][][] points={{{x,y,z},{x,y,Z},{x,Y,Z},{x,Y,z}},{{X,y,Z},{X,y,z},{X,Y,z},{X,Y,Z}},{{x,y,Z},{x,y,z},{X,y,z},{X,y,Z}},{{x,Y,z},{x,Y,Z},{X,Y,Z},{X,Y,z}},{{X,y,z},{x,y,z},{x,Y,z},{X,Y,z}},{{x,y,Z},{X,y,Z},{X,Y,Z},{x,Y,Z}}};float[][] normal={{-1,0,0},{1,0,0},{0,-1,0},{0,1,0},{0,0,-1},{0,0,1}};int tx=zone==0?0:zone==2||zone==3?40:zone==4||zone==5?0:16,ty=zone==0?0:16;float w=X-x,h=Y-y,d=Z-z;float[] starts={tx,tx+d+w,tx+d,tx+d+w,tx+d,tx+d+w+d};for(int i=0;i<6;i++){float width=i<2?d:w,height=i==2||i==3?d:h;float u=starts[i]/64,v=(ty+(i==2||i==3?0:d))/64;fs.add(new Mesh12.Face(points[i],new float[]{u,u+width/64,u+width/64,u},new float[]{v,v,v+height/64,v+height/64},normal[i][0],normal[i][1],normal[i][2]));}return new Mesh12.Cube(b,fs);}
 public static boolean render(Object raw,Object stack,Object consumer,int light,int overlay,int color){
  Context c=CURRENT.get();if(c==null)return false;Integer id=c.parts.get(raw);if(id==null)return false;boolean outer=id>=8;int zone=outer?id-8:id;int stage=Trauma12.stage(c.details,zone);boolean lost=(c.state&(1<<zone))!=0;
  if(outer)return stage!=0||lost||(c.state&(1<<(zone+8)))!=0;
  if(lost)return true;
  if(stage==0){if((c.state&(1<<(zone+8)))==0)return false;stage=(zone==2||zone==3)?8:1;}
  ModelPart part=(ModelPart)raw;if(!part.visible)return true;PoseStack ps=(PoseStack)stack;VertexConsumer skin=(VertexConsumer)consumer;final int z=zone,s=stage;
  List<Mesh12.Quad> mesh=MESHES.computeIfAbsent(part,k->new HashMap<>()).computeIfAbsent(zone*16+stage,k->Mesh12.build(cubes(part,z),z,s));
  VertexConsumer blood=bloodBuffer().getBuffer(RenderType.entityCutoutNoCull(TEXTURE));ps.pushPose();try{part.translateAndRotate(ps);PoseStack.Pose pose=ps.last();for(Mesh12.Quad quad:mesh){int material=quad.material(),tint=material==0?color:COLORS[material];VertexConsumer vc=material==0?skin:blood;for(Mesh12.Vertex v:quad.vertices())vc.addVertex(pose,v.x(),v.y(),v.z()).setColor(tint).setUv(v.u(),v.v()).setOverlay(overlay).setLight(light).setNormal(pose,quad.nx(),quad.ny(),quad.nz());}}finally{ps.popPose();}return true;
 }
}
