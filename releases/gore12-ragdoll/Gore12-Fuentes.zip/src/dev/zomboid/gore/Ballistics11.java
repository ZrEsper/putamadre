package dev.zomboid.gore;
import java.util.*;
/** Server-authoritative anatomical damage. Only TaCZ hits, never player damage. */
public final class Ballistics11 {
 static final ThreadLocal<Integer> ZONE=new ThreadLocal<>();
 static final ThreadLocal<Object> SOURCE=new ThreadLocal<>();
 static double num(Object x,String n){return R.num(R.call(x,n));}
 static int zone(Gore.Shot s){Object e=s.entity(),p=R.call(e,"position");double yaw=Math.toRadians(num(e,"getYRot"));double x=R.num(R.get(s.point(),"x"))-R.num(R.get(p,"x")),z=R.num(R.get(s.point(),"z"))-R.num(R.get(p,"z"));return Rules.zone((R.num(R.get(s.point(),"y"))-R.num(R.get(p,"y")))/Math.max(.1,num(e,"getBbHeight")),x*Math.cos(yaw)+z*Math.sin(yaw),s.head());}
 public static void incoming(Object event){
  ZONE.remove();SOURCE.remove(); Object e=R.call(event,"getEntity"); Gore.Shot s=Gore.shots.get();
  if(s==null||s.entity()!=e||s.bullet()==null||!Gore.zombie(e))return;
  float amount=(float)num(event,"getAmount");if(!(amount>0))return;
  int zone=zone(s);ZONE.set(zone);SOURCE.set(R.call(event,"getSource"));
  // Head lethality is finalized after an accepted damage event, not on a canceled hit.
  float health=(float)num(e,"getHealth");
  float damage=zone<2?Math.min(amount,health*.45f):Math.min(amount*.08f,health*.08f);
  R.call(event,"setAmount",Math.max(.001f,damage));
 }
 public static void injure(Object e,Gore.Shot s,float damage,int surface){
  if(s.bullet()==null){legacy(e,s,damage,surface);return;}
  int z=ZONE.get()!=null?ZONE.get():zone(s);if(z<2)z=0; Object tag=Gore.tag(e);
  String key="zg11_hits_"+z;int hits=((Number)R.call(tag,"getInt",key)).intValue()+1;R.call(tag,"putInt",key,hits);
  int state=Gore.state(e)|(1<<(8+z));
  boolean strong=s.gun()==Rules.Weapon.SNIPER || s.gun()==Rules.Weapon.SHOTGUN;
  boolean fatal=z<2&&(strong||hits>=2);
  if(z>=2&&z<6&&hits>=2) state|=1<<(26+z-2);
  Trauma12.ballistic(e,s,z,hits,strong);
  Gore.surfaceSet(e,Gore.surfaces(e)|(1<<z));Gore.set(e,state);Gore.push(e,s.bullet(),s.gun());
  if(fatal){R.call(e,"setHealth",0f);Object source=SOURCE.get();if(source!=null)R.call(e,"die",source);}
 }

 static void legacy(Object e,Gore.Shot s,float damage,int surface){int z=zone(s);Object tag=Gore.tag(e);float sum=((Number)R.call(tag,"getFloat","zg_damage_"+z)).floatValue()+damage;R.call(tag,"putFloat","zg_damage_"+z,sum);Gore.surfaceSet(e,Gore.surfaces(e)|(1<<(z+surface*8)));int old=Gore.state(e);int next=Rules.update(old,z,damage,sum,(float)num(e,"getMaxHealth"),s.gun());next=(next&~255)|(old&255);Gore.set(e,next);Trauma12.melee(e,z,damage,sum);}

 public static void clear(){ZONE.remove();SOURCE.remove();}
 /** Remove the old unconditional x3 modifier without healing injured zombies. */
 public static void durability(Object event){Object e=R.call(event,"getEntity");if(!Gore.zombie(e)||R.yes(R.get(R.call(e,"level"),"isClientSide")))return;Object a=R.call(e,"getAttribute",R.get(R.type("net.minecraft.world.entity.ai.attributes.Attributes"),"MAX_HEALTH"));if(a==null)return;Object id=R.call(R.type("net.minecraft.resources.ResourceLocation"),"fromNamespaceAndPath","zomboid_gore","durability");if(!R.yes(R.call(a,"hasModifier",id)))return;float old=(float)num(e,"getMaxHealth"),hp=(float)num(e,"getHealth");R.call(a,"removeModifier",id);float max=(float)num(e,"getMaxHealth");R.call(e,"setHealth",Math.min(max,hp/old*max));}
}
