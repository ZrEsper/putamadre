package dev.zomboid.gore;
import java.util.*;
/** One shared near-camera emission budget for living injuries and physics corpses. */
public final class Blood12 {
 static final Map<Object,long[]> LIVE=new WeakHashMap<>(),DEAD=new WeakHashMap<>();
 static Object world,particle;static long tick=Long.MIN_VALUE;static int used;static boolean missing;
 static boolean frame(Object level){if(world!=level){world=level;LIVE.clear();DEAD.clear();tick=Long.MIN_VALUE;}long t=((Number)R.call(level,"getGameTime")).longValue();if(tick!=t){tick=t;used=0;}return used<48&&!missing;}
 static void emit(Object level,double x,double y,double z,boolean force,int count){if(particle==null&&!missing)try{particle=R.call(R.get(R.type("net.mehvahdjukaar.splatter.reg.ModParticles"),"BLOOD_FLECK"),"get");}catch(RuntimeException ex){missing=true;}if(particle==null)return;for(int k=0;k<count&&used<48;k++){used++;double angle=(tick*1.7+k*2.4),spread=force?.045:.025;R.call(level,"addParticle",particle,x,y,z,Math.cos(angle)*spread,force?.14:.045,Math.sin(angle)*spread);}}
 static int regions(int state,int details){int mask=(state&255)|(state>>>8&255);for(int z=0;z<8;z++)if(Trauma12.stage(details,z)!=0)mask|=1<<z;return mask;}
 public static void nativeBlood(Object level,Object particle,double x,double y,double z,double vx,double vy,double vz){if(!frame(level))return;used++;R.call(level,"addParticle",particle,x,y,z,vx,vy,vz);}
 public static void tick(Object event){Object e=R.call(event,"getEntity");if(!Gore.zombie(e))return;Object level=R.call(e,"level");if(!R.yes(R.get(level,"isClientSide"))||!frame(level))return;Object mc=R.call(R.type("net.minecraft.client.Minecraft"),"getInstance"),player=R.get(mc,"player");if(player==null||R.num(R.call(e,"distanceToSqr",player))>1024)return;
  int state=Gore.state(e),details=Trauma12.details(e),mask=regions(state,details);if(mask==0)return;long key=(long)details<<32|(state&255);long[] a=LIVE.get(e);if(a==null){a=new long[]{key,tick};LIVE.put(e,a);}else if(a[0]!=key){a[0]=key;a[1]=tick;}long age=tick-a[1];if(age>80||tick%4!=0)return;
  double yaw=Math.toRadians(R.num(R.call(e,"getYRot"))),x=R.num(R.call(e,"getX")),y=R.num(R.call(e,"getY")),z=R.num(R.call(e,"getZ")),h=R.num(R.call(e,"getBbHeight"));
  for(int p:new int[]{0,2,3,4,5,6,7})if((mask&(1<<p))!=0){double side=p==2?.24:p==3?-.24:p==4?.12:p==5?-.12:0;double height=p==0?.85:p<4?.65:p<6?.32:.58;emit(level,x+Math.cos(yaw)*side,y+h*height,z+Math.sin(yaw)*side,p==0,age<20?3:1);}
 }
 public static void ragdoll(Object doll){int state=((Number)R.get(doll,"goreState12")).intValue(),details=((Number)R.get(doll,"goreDetails12")).intValue(),mask=regions(state,details);if(mask==0)return;
  Object snap=R.call(doll,"getSnapshot");if(snap==null||R.num(R.get(snap,"ageTicks"))>80)return;Object mc=R.call(R.type("net.minecraft.client.Minecraft"),"getInstance"),level=R.get(mc,"level"),player=R.get(mc,"player");if(level==null||player==null||!frame(level)||tick%4!=0)return;
  long[] a=DEAD.get(doll);if(a!=null&&a[0]==tick)return;DEAD.put(doll,new long[]{tick});Object torso=R.call(doll,"getSmoothedTorsoPos");double tx=R.num(R.get(torso,"x")),ty=R.num(R.get(torso,"y")),tz=R.num(R.get(torso,"z"));double dx=tx-R.num(R.call(player,"getX")),dy=ty-R.num(R.call(player,"getY")),dz=tz-R.num(R.call(player,"getZ"));if(dx*dx+dy*dy+dz*dz>1024)return;
  String[] names={"HEAD","HEAD","LEFT_ARM","RIGHT_ARM","LEFT_LEG","RIGHT_LEG","TORSO","TORSO"};
  for(int p:new int[]{0,2,3,4,5,6,7})if((mask&(1<<p))!=0){Object transform=R.call(doll,"getSmoothedTransform",R.get(R.type("com.raiiiden.ragdollified.RagdollPart"),names[p]));Object pos=transform==null?torso:R.get(transform,"position");emit(level,R.num(R.get(pos,"x")),R.num(R.get(pos,"y"))+.03,R.num(R.get(pos,"z")),p==0,2);}
 }
}
