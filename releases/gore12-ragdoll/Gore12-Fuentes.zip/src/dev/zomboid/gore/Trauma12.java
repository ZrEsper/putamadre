package dev.zomboid.gore;
import java.util.*;
/** Server authority, compact synchronized regional wounds and death snapshots. */
public final class Trauma12 {
 static Object accessor;
 static final Map<Object,Long> blasts=Collections.synchronizedMap(new WeakHashMap<>());
 public static void init(){accessor=R.call(R.type("net.minecraft.network.syncher.SynchedEntityData"),"defineId",R.type("net.minecraft.world.entity.monster.Zombie"),R.get(R.type("net.minecraft.network.syncher.EntityDataSerializers"),"INT"));}
 public static void define(Object builder){R.call(builder,"define",accessor,0);}
 public static int details(Object e){return Gore.zombie(e)?((Number)R.call(R.call(e,"getEntityData"),"get",accessor)).intValue():0;}
 static void set(Object e,int d){R.call(R.call(e,"getEntityData"),"set",accessor,d);R.call(Gore.tag(e),"putInt","zg_trauma12",d);}
 public static void save(Object e,Object tag){R.call(tag,"putInt","zg_trauma12",details(e));}
 public static void restore(Object e,Object tag){set(e,((Number)R.call(tag,"getInt","zg_trauma12")).intValue());}
 public static int stage(int details,int zone){return details >>> (zone*3)&7;}
 public static int withStage(int details,int zone,int stage){return details&~(7<<(zone*3))|(stage&7)<<(zone*3);}
 static void wound(Object e,int zone,int stage){int d=details(e);int old=stage(d,zone);if(zone==2||zone==3)stage|=old;if(old==7||old==stage)return;set(e,withStage(d,zone,stage));}
 public static void ballistic(Object e,Gore.Shot s,int z,int hits,boolean strong){
  if(z<2){wound(e,0,(hits>=2||strong)?7:6);return;}
  double h=(R.num(R.get(s.point(),"y"))-R.num(R.call(e,"getY")))/Math.max(.1,R.num(R.call(e,"getBbHeight")));
  int kind=1;
  if(z==2||z==3)kind=hits<2&&!strong?0:(h<.54?1:h<.64?2:4);
  else kind=(hits>=2||strong)?2:1;
  wound(e,z,kind);
 }
 public static void melee(Object e,int z,float damage,float sum){wound(e,z,(z==2||z==3)?(sum>=6?2:0):(sum>=6?2:1));}
 public static boolean explosion(Object source){return source!=null&&R.yes(R.call(source,"is",R.get(R.type("net.minecraft.tags.DamageTypeTags"),"IS_EXPLOSION")));}
 public static void death(Object event){
  Object e=R.call(event,"getEntity"),level=R.call(e,"level");
  if(R.yes(R.get(level,"isClientSide"))||!explosion(R.call(event,"getSource")))return;
  Object tag=Gore.tag(e);if(R.yes(R.call(tag,"getBoolean","zg_blast12")))return;
  R.call(tag,"putBoolean","zg_blast12",true);
  if(Gore.zombie(e)){
   int id=((Number)R.call(e,"getId")).intValue(),seed=id^(int)R.num(R.call(level,"getGameTime"));
   int mask=1<<(2+Math.floorMod(seed,4));mask|=1<<(2+Math.floorMod(seed/7+1,4));
   if((seed&3)==0)mask|=3;
   Gore.set(e,Gore.state(e)|mask);
   for(int z=0;z<8;z++)if((mask&(1<<z))!=0)wound(e,z,2);
  }
  R.call(level,"broadcastEntityEvent",e,(byte)121);
 }
 public static boolean entityEvent(Object e,byte event){if(event!=121)return false;blasts.put(e,System.nanoTime());return true;}
 public static boolean blastAllowed(Object e){Long time=blasts.get(e);if(time!=null&&System.nanoTime()-time<5_000_000_000L)return true;if(Gore.zombie(e)&&R.yes(R.call(Gore.tag(e),"getBoolean","zg_blast12")))return true;return false;}
 public static int ragMask(int state){int mask=0;if((state&1)!=0)mask|=2;if((state&4)!=0)mask|=16;if((state&8)!=0)mask|=32;if((state&16)!=0)mask|=4;if((state&32)!=0)mask|=8;return mask;}
 public static void packet(Object e,Object packet){if(!Gore.zombie(e))return;int state=Gore.state(e);R.set(packet,"goreState12",state);R.set(packet,"goreDetails12",details(e));R.set(packet,"goreSurface12",Gore.surfaces(e));R.call(packet,"severedMask",((Number)R.call(packet,"severedMask")).intValue()|ragMask(state));}
 public static void snapshot(Object from,Object to){for(String f:new String[]{"goreState12","goreDetails12","goreSurface12"})R.set(to,f,R.get(from,f));}
 /** Filter detached gibs to lost parts when a Ragdollified zombie retains its body. */
 public static List<?> gibParts(List<?> parts,Object e){
  if(!Gore.zombie(e)||!ragdollEnabled(e))return parts;
  Object mc=R.call(R.type("net.minecraft.client.Minecraft"),"getInstance");Object renderer=R.call(R.call(mc,"getEntityRenderDispatcher"),"getRenderer",e);Object model=R.call(renderer,"getModel");
  Map<Object,Integer> ids=Skin12.modelParts(model);int state=Gore.state(e);List<Object> kept=new ArrayList<>();
  for(Object part:parts){Integer z=ids.get(R.get(part,"part"));if(z!=null&&z<8&&(state&(1<<z))!=0)kept.add(part);}
  return kept;
 }
 static boolean ragdollEnabled(Object e){try {Object c=R.type("com.raiiiden.ragdollified.config.RagdollifiedConfig");Object id=R.call(R.type("net.minecraft.world.entity.EntityType"),"getKey",R.call(e,"getType"));Object level=R.call(e,"level"),dim=R.call(R.call(level,"dimension"),"location");return R.yes(R.call(c,"isRagdollEnabledFor",id.toString(),false,dim.toString()));}catch(RuntimeException ex){return false;}}
 public static boolean finishGibs(boolean result,Object handler,Object e){if(result&&ragdollEnabled(e)){if(Gore.zombie(e)){((Set<Object>)R.get(handler,"skippedDismember")).add(e);return false;}Rag12.exploded(e);}return result;}
}
