package dev.zomboid.gore;
public final class Rag12 {
 static Object world;static final java.util.Map<Integer,Long> GIBBED=new java.util.HashMap<>();
 static void world(){Object mc=R.call(R.type("net.minecraft.client.Minecraft"),"getInstance"),level=R.get(mc,"level");if(world!=level){world=level;GIBBED.clear();}}
 public static void exploded(Object entity){world();long now=System.nanoTime();GIBBED.entrySet().removeIf(e->e.getValue()<now);if(GIBBED.size()>512)GIBBED.clear();int id=((Number)R.call(entity,"getId")).intValue();GIBBED.put(id,now+10_000_000_000L);R.call(R.type("com.raiiiden.ragdollified.client.ClientRagdollManager"),"requestRemoveRagdoll",id);}
 public static boolean skip(Object data){world();Long expiry=GIBBED.get(((Number)R.get(data,"originalEntityId")).intValue());return expiry!=null&&expiry>System.nanoTime();}

 public static void local(Object e,Object data){if(!Gore.zombie(e))return;int state=Gore.state(e);R.set(data,"goreState12",state);R.set(data,"goreDetails12",Trauma12.details(e));R.set(data,"goreSurface12",Gore.surfaces(e));R.set(data,"severedMask",((Number)R.get(data,"severedMask")).intValue()|Trauma12.ragMask(state));}
}
