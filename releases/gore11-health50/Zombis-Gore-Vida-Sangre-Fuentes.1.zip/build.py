from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import subprocess,json,hashlib
r=Path('work/gore11');inputs=(r/'inputs.txt').read_text().splitlines();cp=':'.join(inputs)
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
subprocess.run(['java','com.sun.tools.javac.Main','-cp',cp,'-d',str(r/'classes'),*map(str,(r/'src').rglob('*.java'))],check=True)
subprocess.run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(r/'tools'),str(r/'Patch.java')],check=True)
subprocess.run(['java',*flags,'-cp',str(r/'tools'),'Patch',*inputs],check=True)
subprocess.run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/belroft3/classes','Verify',str(r/'classes')],check=True)
out=r/'release';out.mkdir(exist_ok=True)
manifest=[]
for src,name,prefixes in zip(inputs,['zomboid-zombie-gore-1.0.11-neoforge-1.21.1-localized-ballistics.jar','zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.50-zombie-health.jar','splatter-1.21.1-0.3.0-neoforge-blood-budget.2.jar'],[['dev/zomboid/gore/'],['dev/zomboid/hordes/'],['dev/zomboid/splatterbudget/','net/mehvahdjukaar/splatter/']]):
 changes={p.relative_to(r/'classes').as_posix():p.read_bytes() for prefix in prefixes for p in (r/'classes'/prefix).rglob('*.class')}
 with ZipFile(src) as z:
  data={n:z.read(n) for n in z.namelist()}; original=data.copy();data.update(changes)
  if 'gore-' in name:data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'1.0.10',b'1.0.11')
  with ZipFile(out/name,'w',ZIP_DEFLATED) as dest:
   for n,b in data.items():dest.writestr(n,b)
  with ZipFile(out/name) as result:
   assert result.testzip() is None
   assert all(result.read(n)==b for n,b in original.items() if n not in changes and n!='META-INF/neoforge.mods.toml')
 manifest.append({'input':src,'input_sha256':hashlib.sha256(Path(src).read_bytes()).hexdigest(),'file':name,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest(),'classes':list(changes)})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
