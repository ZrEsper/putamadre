package dev.zomboid.gore;
import java.util.*;
public final class Visual11 {
 static final Map<Object,int[]> wounds=new WeakHashMap<>();
 static Object world,particle;static long tick;static int used;static boolean missing;
 public static void tick(Object event){Object e=R.call(event,"getEntity");if(!Gore.zombie(e))return;Object level=R.call(e,"level");if(!R.yes(R.get(level,"isClientSide")))return;
  long now=((Number)R.call(level,"getGameTime")).longValue();if(world!=level){world=level;wounds.clear();}if(now!=tick){tick=now;used=0;}
  int loss=Gore.state(e)&63,age=((Number)R.get(e,"tickCount")).intValue();int[] w=wounds.get(e);if(w==null){w=new int[]{loss,age-101};wounds.put(e,w);}else if((loss&~w[0])!=0){w[1]=age;w[0]=loss;}
  if(loss==0||age-w[1]>100||age%4!=0||used>=48||missing)return;
  Object mc=R.call(R.type("net.minecraft.client.Minecraft"),"getInstance"),player=R.get(mc,"player");if(player==null||R.num(R.call(e,"distanceToSqr",player))>1024)return;
  if(particle==null)try{particle=R.call(R.get(R.type("net.mehvahdjukaar.splatter.reg.ModParticles"),"BLOOD_FLECK"),"get");}catch(RuntimeException ex){missing=true;return;}
  double yaw=Math.toRadians(R.num(R.call(e,"getYRot"))),x=R.num(R.call(e,"getX")),y=R.num(R.call(e,"getY")),z=R.num(R.call(e,"getZ")),height=R.num(R.call(e,"getBbHeight"));
  for(int part:new int[]{0,2,3,4,5})if((loss&(1<<part))!=0){double side=part==2?.24:part==3?-.24:part==4?.12:part==5?-.12:0;double h=part==0?.82:part<4?.67:.32;double vx=Math.cos(yaw)*side*.5,vz=Math.sin(yaw)*side*.5;int count=age-w[1]<24?4:2;for(int k=0;k<count&&used<48;k++){used++;R.call(level,"addParticle",particle,x+Math.cos(yaw)*side,y+height*h,z+Math.sin(yaw)*side,vx+(k-1.5)*.012,part==0?.16:.04,vz+(k-1.5)*.009);}}
 }
 /** Offset bookkeeping uses the existing reset hook, preventing pose drift between entities. */
 public static void pose(Object model,Object e,float age){if(!Gore.zombie(e))return;int loss=Gore.state(e);if(Integer.bitCount(Rules.disabled(loss)&48)!=1||Rules.crawling(loss))return;Object velocity=R.call(e,"getDeltaMovement");double speed=Math.hypot(R.num(R.get(velocity,"x")),R.num(R.get(velocity,"z")));if(speed<.005)return;float side=(Rules.disabled(loss)&16)!=0?1:-1;float pulse=(float)Math.sin(age*.43);List<MeleeReaction.Offset> offsets=MeleeReaction.OFFSETS.computeIfAbsent(model,k->new ArrayList<>());MeleeReaction.add(model,offsets,"body",.08f,0,side*(.09f+.055f*pulse));MeleeReaction.add(model,offsets,"head",-.04f,0,-side*.05f);MeleeReaction.add(model,offsets,(side>0?"rightLeg":"leftLeg"),.14f*pulse,0,0);}
}
