/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.gore;

import java.util.Locale;

public final class Rules {
    public static final int HEAD = 0;
    public static final int JAW = 1;
    public static final int LEFT_ARM = 2;
    public static final int RIGHT_ARM = 3;
    public static final int LEFT_LEG = 4;
    public static final int RIGHT_LEG = 5;
    public static final int LEFT_BODY = 6;
    public static final int RIGHT_BODY = 7;

    public static Weapon weapon(String string) {
        String string2 = string.toLowerCase(Locale.ROOT);
        return string2.contains("shotgun") ? Weapon.SHOTGUN : (string2.contains("sniper") ? Weapon.SNIPER : (string2.contains("pistol") ? Weapon.PISTOL : Weapon.OTHER));
    }

    public static int zone(double d, double d2, boolean bl) {
        if (bl || d >= 0.84) {
            return 0;
        }
        if (d >= 0.74) {
            return 1;
        }
        if (d < 0.43) {
            return d2 >= 0.0 ? 4 : 5;
        }
        if (Math.abs(d2) > 0.19) {
            return d2 > 0.0 ? 2 : 3;
        }
        return d2 >= 0.0 ? 6 : 7;
    }

    public static int update(int n, int n2, float f, float f2, float f3, Weapon weapon) {
        boolean bl;
        if (f <= 0.0f) {
            return n;
        }
        int n3 = 1 << n2 << 8;
        boolean bl2 = bl = weapon == Weapon.SHOTGUN || weapon == Weapon.SNIPER;
        float f4 = n2 < 2 ? 3 : (n2 < 6 ? (bl ? 5 : 9) : (bl ? 9 : 18));
        int n4 = f2 >= f4 ? 1 << n2 : 0;
        int n5 = n2 >= 2 && n2 < 6 && f2 >= 3.0f ? 1 << 26 + n2 - 2 : 0;
        int n6 = weapon == Weapon.SNIPER ? 1 << n2 << 18 : 0;
        return n | n3 | n4 | n5 | n6;
    }

    public static int disabled(int n) {
        return n & 0x3C | (n >>> 26 & 0xF) << 2;
    }

    public static double speed(int n) {
        int legs=Integer.bitCount(disabled(n)&0x30);
        double speed=legs==2?.20:legs==1?.62:1;
        if((n&0xC0)!=0)speed*=.9;
        return speed;
    }

    public static double attack(int n) {
        int n2 = Integer.bitCount(Rules.disabled(n) & 0xC);
        if (n2 == 2) {
            return (n & 2) != 0 ? 0.0 : 0.45;
        }
        return (n2 == 1 ? 0.6 : 1.0) * ((n & 2) != 0 ? 0.65 : 1.0);
    }

    public static double push(Weapon weapon) {
        return weapon == Weapon.SHOTGUN ? 0.12 : (weapon == Weapon.SNIPER ? 0.1 : 0.065);
    }

    public static boolean crawling(int n) {
        if ((n & 0x40000000) != 0) {
            return true;
        }
        return (n & 0x30) == 48;
    }

    public static int charStage(int n) {
        return n >= 120 ? 3 : (n >= 60 ? 2 : (n >= 20 ? 1 : 0));
    }

    public static enum Weapon {
        PISTOL,
        SHOTGUN,
        SNIPER,
        OTHER;

    }
}

