package dev.zomboid.splatterbudget;
public final class Projection2 {
 static final java.util.concurrent.atomic.AtomicInteger pending=new java.util.concurrent.atomic.AtomicInteger();
 static Class<?> mcType;
 static Class<?> mc(){try{return mcType==null?(mcType=Class.forName("net.minecraft.client.Minecraft")):mcType;}catch(Exception e){throw new IllegalStateException(e);}}
 public static java.util.concurrent.Future<?> submit(java.util.concurrent.ExecutorService executor,Runnable task){if(pending.incrementAndGet()>4){pending.decrementAndGet();return java.util.concurrent.CompletableFuture.completedFuture(null);}try{return executor.submit(()->{try{task.run();}finally{pending.decrementAndGet();}});}catch(RuntimeException e){pending.decrementAndGet();throw e;}}
 static Object world;static long tick;static int count,flecks;static long window;static int rate;
 public static boolean allow(Object level,Object origin){long now=((Number)Lookup.call(level,"getGameTime")).longValue();if(world!=level){world=level;tick=now;count=flecks=0;window=0;rate=0;}if(now!=tick){tick=now;count=flecks=0;}long time=System.nanoTime();if(time-window>1000000000L){window=time;rate=0;}if(count>=2||rate>=16||pending.get()>=4)return false;Object mc=Lookup.call(mc(),"getInstance"),player=Lookup.get(mc,"player");if(player==null||((Number)Lookup.call(Lookup.call(player,"position"),"distanceToSqr",origin)).doubleValue()>1600)return false;count++;rate++;return true;}
 public static int flecks(int original){int n=Math.min(Math.min(original,8),Math.max(0,32-flecks));flecks+=n;return n;}
}
