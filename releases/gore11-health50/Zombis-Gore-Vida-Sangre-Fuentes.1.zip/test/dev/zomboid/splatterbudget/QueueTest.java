package dev.zomboid.splatterbudget;
import java.util.concurrent.*;
public class QueueTest {
 public static void main(String[] a)throws Exception{ExecutorService e=Executors.newSingleThreadExecutor();CountDownLatch gate=new CountDownLatch(1);try{for(int k=0;k<30;k++)Projection2.submit(e,()->{try{gate.await();}catch(InterruptedException ex){Thread.currentThread().interrupt();}});if(Projection2.pending.get()!=4)throw new AssertionError("queue unbounded");gate.countDown();e.shutdown();if(!e.awaitTermination(3,TimeUnit.SECONDS)||Projection2.pending.get()!=0)throw new AssertionError("leaked permits");Projection2.flecks=0;int n=0;for(int k=0;k<10;k++)n+=Projection2.flecks(50);if(n!=32)throw new AssertionError("particle cap");System.out.println("PASS: pending projection cap 4, release on completion, global fleck cap 32");}finally{gate.countDown();e.shutdownNow();}}
}
