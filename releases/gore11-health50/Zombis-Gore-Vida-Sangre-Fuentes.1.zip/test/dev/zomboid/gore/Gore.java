package dev.zomboid.gore;
public class Gore {
 static ThreadLocal<Shot> shots=new ThreadLocal<>();static int state,surfaces;
 static boolean zombie(Object e){return e instanceof Test.Entity;}
 static Object tag(Object e){return ((Test.Entity)e).tag;}
 static int state(Object e){return state;}static void set(Object e,int n){state=n;}
 static int surfaces(Object e){return surfaces;}static void surfaceSet(Object e,int n){surfaces=n;}
 static void push(Object e,Object b,Rules.Weapon w){}
 record Shot(Object bullet,Object entity,Object point,boolean head,Rules.Weapon gun){}
}
