package dev.zomboid.remains;
import java.util.*;
/** Only block/level API fixture; BodyLoot16 and its Body remain production classes. */
public class ZombieRemainsLoot{public static class CorpseData{public Map<Long,Object>corpses=new HashMap<>();}public static boolean remains(Object state){return state.toString().equals("remains");}public static String blockId(Object state){return state.toString();}}
