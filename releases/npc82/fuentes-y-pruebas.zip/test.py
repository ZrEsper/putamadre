from pathlib import Path
import subprocess,tempfile,json
r=Path(__file__).parent;inputs=json.loads((r/'inputs.json').read_text());gson='/workspace/medical63/gson.jar';t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree']);jars=':'.join(str(p)for p in (r/'release').glob('*.jar'));cp='/workspace/npc79/tests:'+jars+':'+gson+':'+inputs['gore']
subprocess.run(ecj+['-cp',cp,'-d',str(r/'checks')]+[str(p)for p in (r/'checksrc').rglob('*.java')],check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'Extract82.java')],check=True)
subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'Extract82',inputs['remains'],str(r/'checks')],check=True)
with (r/'test-output.txt').open('w')as log:
 for cls in ['dev.zomboid.remains.expand.CheckMenu82','mod.cdv.tnpc.tactical.CheckNpc82']:
  with tempfile.TemporaryDirectory(dir=r)as tmp:
   result=subprocess.run(['java','-Xverify:all','-Ddecor.root='+str(r/'decor'),'-cp',str(r/'checks')+':'+cp,cls],cwd=tmp,stdout=log,stderr=subprocess.STDOUT)
   if result.returncode:raise SystemExit('FAILED '+cls)
print('PASS corpse menu and NPC regression checks; JVM fixtures only')
