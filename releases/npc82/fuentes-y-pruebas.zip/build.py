from pathlib import Path
import subprocess,json
r=Path(__file__).parent;inputs=json.loads((r/'inputs.json').read_text());t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis']);ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];(r/'release').mkdir(exist_ok=True)
cp=inputs['npc']+':'+inputs['remains']+':/workspace/medical63/gson.jar:/workspace/npc79/api-build'
subprocess.run(ecj+['-cp',cp,'-d',str(r/'build')]+[str(p)for p in (r/'src').rglob('*.java')],check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'Patch82.java')],check=True)
for mode,name in [('npc','tacznpcs-2.1.0-1.21.1-tactical.49-decor-corpse-fixes.jar'),('remains','zombie-remains-loot-1.6.1-neoforge-1.21.1-safe-corpse-menu.28.jar'),('rag','ragdollified-1.21.1-1.1.5-server-owned-corpses.33.jar')]:subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'Patch82',mode,inputs[mode],str(r/'build'),str(r/'release'/name),str(r/'npc-decor-recipes.json')],check=True)
