package dev.zomboid.remains.expand;
import dev.zomboid.remains.BodyLoot16;
public final class SafeMenu82{
 static Object c(Object o,String n,Object...a){return FastReflection.call(o,n,a);}static Object g(Object o,String n){return FastReflection.get(o,n);}
 public static boolean valid(Object corpse,Object data,Object pos,Object level,Object player){if(corpse==null||data==null||pos==null||level==null||player==null)return false;
  // The menu retains its original owner even after OWNERS forgets a removed ragdoll.
  if(data instanceof BodyLoot16.Body)return BodyLoot16.valid(corpse,player);
  if(!FastReflection.type("dev.zomboid.remains.ZombieRemainsLoot$CorpseData").isInstance(data))return false;
  if(c(player,"level")!=level||!Boolean.TRUE.equals(c(player,"isAlive"))||Boolean.TRUE.equals(c(player,"isSpectator")))return false;
  if(Boolean.TRUE.equals(g(corpse,"skeleton")))return false;Object map=g(data,"corpses");if(c(map,"get",c(pos,"asLong"))!=corpse)return false;
  if(!c(FastReflection.type("dev.zomboid.remains.ZombieRemainsLoot"),"blockId",c(level,"getBlockState",pos)).equals(g(corpse,"block")))return false;
  return ((Number)c(player,"distanceToSqr",((Number)c(pos,"getX")).doubleValue()+.5,((Number)c(pos,"getY")).doubleValue()+.5,((Number)c(pos,"getZ")).doubleValue()+.5)).doubleValue()<=64;
 }
 public static void protect(Object event){Object w=c(event,"getLevel"),p=c(event,"getPos");Class<?>main=FastReflection.type("dev.zomboid.remains.ZombieRemainsLoot");if(!Boolean.TRUE.equals(c(main,"remains",c(w,"getBlockState",p))))return;
  // Cancel ordinary mining; the dedicated gore/ragdoll interaction is untouched.
  c(event,"setCanceled",true);
 }
}
