package dev.zomboid.firstaid;
import java.util.List;
public final class Alcohol43 {
 public static final int USES=15;
 public static int remaining(int damage){return Math.max(0,USES-Math.max(0,damage));}
 public static Object remainder(Object stack){int damage=((Number)R.call(stack,"getDamageValue")).intValue();if(remaining(damage)<=1)return R.call(R.get(R.type("net.minecraft.world.item.Items"),"GLASS_BOTTLE"),"getDefaultInstance");Object next=R.call(stack,"copy");R.call(next,"setCount",1);R.call(next,"setDamageValue",Math.max(0,damage)+1);return next;}
 public static void tooltip(Object stack,List<Object> lines){lines.add(R.call(R.type("net.minecraft.network.chat.Component"),"translatable","firstaid.alcohol.uses",new Object[]{remaining(((Number)R.call(stack,"getDamageValue")).intValue()),USES}));}
}
