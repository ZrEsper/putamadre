package dev.zomboid.firstaid;
import java.util.*;import net.minecraft.world.item.*;
public class Test43{
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 public static void main(String[] args){Item item=new AlcoholItem43(new Item.Properties().durability(15));ItemStack current=new ItemStack(item);check(item.hasCraftingRemainingItem(current),"crafting remainder enabled");for(int use=1;use<=15;use++){ItemStack previous=current;current=item.getCraftingRemainingItem(previous);check(previous.damage==use-1,"input unchanged");check(current.count==1,"single bottle remainder");if(use<15){check(current.item==item&&current.damage==use,"one use deducted");check(current.component.equals("custom-preserved"),"components preserved");}else check(current.item==Items.GLASS_BOTTLE,"empty bottle after 15th craft");}
 ItemStack stacked=new ItemStack(item);stacked.count=16;ItemStack result=item.getCraftingRemainingItem(stacked);check(stacked.count==16&&result.count==1&&result.damage==1,"legacy stacked bottles");List<Object> tooltip=new ArrayList<>();item.appendHoverText(result,new Item.TooltipContext(),tooltip,null);check(tooltip.size()==1&&tooltip.get(0).toString().contains("14, 15"),"remaining uses tooltip");System.out.println("PASS: 15 crafts, input immutability, component preservation, empty bottle, legacy stacks, tooltip dispatch");}
}
