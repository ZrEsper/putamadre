package net.minecraft.world.item;
import java.util.List;
public class Item{public static class Properties{public int maxDamage;public Properties durability(int n){maxDamage=n;return this;}}public static class TooltipContext{}public final Properties properties;public Item(Properties p){properties=p;}public ItemStack getDefaultInstance(){return new ItemStack(this);}public boolean hasCraftingRemainingItem(ItemStack s){return false;}public ItemStack getCraftingRemainingItem(ItemStack s){return null;}public void appendHoverText(ItemStack s,TooltipContext c,List<Object> l,TooltipFlag f){}}
