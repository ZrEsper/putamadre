package net.minecraft.world.item;public class Items{public static final Item GLASS_BOTTLE=new Item(new Item.Properties());}
