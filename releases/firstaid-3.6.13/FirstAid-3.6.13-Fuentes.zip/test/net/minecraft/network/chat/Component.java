package net.minecraft.network.chat;public class Component{public static Object translatable(String key,Object...args){return key+java.util.Arrays.toString(args);}}
