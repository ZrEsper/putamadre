from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import subprocess,json
r=Path('work/medical43');base=Path('work/medical42/firstaid-1.21.1-ZOMBOID-v3.6.12-dressing-hygiene.jar');out=r/'firstaid-1.21.1-ZOMBOID-v3.6.13-alcohol-15-uses.jar'
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED']
subprocess.run(['java','com.sun.tools.javac.Main','-cp',str(base),'-d',str(r/'classes'),*map(str,(r/'src').rglob('*.java'))],check=True)
subprocess.run(['java','com.sun.tools.javac.Main',*flags,'-d',str(r/'tools'),str(r/'Generate.java')],check=True)
subprocess.run(['java',*flags,'-cp',str(r/'tools'),'Generate'],check=True)
subprocess.run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/belroft3/classes','Verify',str(r/'classes')],check=True)
with ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()}
original=data.copy()
changes={p.relative_to(r/'classes').as_posix():p.read_bytes() for p in (r/'classes').rglob('*.class')};data.update(changes)
for lang,text in {'es_es':'Usos restantes: %s/%s','es_mx':'Usos restantes: %s/%s','en_us':'Uses remaining: %s/%s','de_de':'Verbleibende Anwendungen: %s/%s'}.items():
 name='assets/firstaid/lang/'+lang+'.json';d=json.loads(data[name]);d['firstaid.alcohol.uses']=text;data[name]=json.dumps(d,ensure_ascii=False,indent=2).encode()
data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'zomboid-v3.6.12-dressing-hygiene',b'zomboid-v3.6.13-alcohol-15-uses')
with ZipFile(out,'w',ZIP_DEFLATED) as z:
 for n,b in data.items():z.writestr(n,b)
with ZipFile(out) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 for name,b in original.items():
  if name not in changes and name!='META-INF/neoforge.mods.toml' and '/lang/' not in name:assert z.read(name)==b
print(out)
