from pathlib import Path
import subprocess,tempfile
r=Path(__file__).parent;cp='/workspace/npc79/tests:'+str(next((r/'release').glob('*.jar')))+':/workspace/medical63/gson.jar';ecj=['java','-jar','/workspace/putamadre/hordes-melee-interiors-patch/build/tools/ecj.jar','-21','-proc:none','-nowarn']
subprocess.run(ecj+['-cp',cp,'-d',str(r/'checks'),str(r/'checksrc/mod/cdv/tnpc/tactical/Check81.java')],check=True)
with (r/'tests.txt').open('w')as log:
 for cls,extra in [('Check81',str(r/'checks')+':'),('Check80','/workspace/npc80/checks:'),('Fix4Check','/workspace/fix4-review/checks:')]:
  with tempfile.TemporaryDirectory(dir=r)as tmp:
   p=subprocess.run(['java','-Xverify:all','-cp',extra+cp,'mod.cdv.tnpc.tactical.'+cls],cwd=tmp,stdout=log,stderr=subprocess.STDOUT)
   if p.returncode:raise SystemExit('FAILED '+cls)
print('PASS targeted regression checks')
