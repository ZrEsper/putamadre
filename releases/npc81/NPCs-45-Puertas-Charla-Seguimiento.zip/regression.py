from pathlib import Path
import subprocess,tempfile
r=Path(__file__).parent;cp='/workspace/npc79/tests:'+str(next((r/'release').glob('*.jar')))+':/workspace/medical63/gson.jar'
with (r/'regression.txt').open('w')as log:
 for cls in ['Fixtures70','Fixtures74','Fixtures76','Fixtures78']:
  with tempfile.TemporaryDirectory(dir=r)as tmp:
   p=subprocess.run(['java','-Xverify:all','-cp',cp,'mod.cdv.tnpc.tactical.'+cls],cwd=tmp,stdout=log,stderr=subprocess.STDOUT)
   if p.returncode:raise SystemExit('FAILED '+cls)
print('PASS existing security/social/movement/inventory regression suites. JVM fixtures only.')
