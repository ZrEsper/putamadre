package mod.cdv.tnpc.tactical;
import java.util.*;
/** One calm movement owner; bounded tasks relinquish control on danger or dialogue. */
public final class Life79 {
 static final Set<Object> WARN=Collections.newSetFromMap(new WeakHashMap<>());
 static Object c(Object o,String m,Object...a){return Social.c(o,m,a);}
 static boolean calm(Object n){return !Social.client(n)&&Authority70.enabled(n)&&Social.alive(n)&&!Downed20.down(n)&&!Peace78.alert(n)&&!Motion76.conversing(n)&&!Ambush73.hidden(n);}
 static boolean servicing(Object n){try{return Social.num(SocialR.get(c(Social.t("mod.cdv.tnpc.tactical.Tactical27"),"state",n),"until"))>Social.time(n);}catch(Exception e){return false;}}
 public static boolean owned(Object n){return calm(n)&&Social.l(Social.tag(n),"npc79_tarea_hasta")>0&&Social.l(Social.tag(n),"npc79_tarea_hasta")>=Social.time(n);}
 static boolean mark(Object n,String task){c(Social.tag(n),"putString","npc79_tarea",task);c(Social.tag(n),"putLong","npc79_tarea_hasta",Social.time(n)+10);return true;}
 static boolean company(Object n){String id=Social.s(Social.tag(n),"npc79_amigo");long now=Social.time(n);if(id.isBlank()||now<Social.l(Social.tag(n),"npc79_compania_despues"))return false;for(Object friend:Social.nearby(n,"mod.cdv.tnpc.entity.AutoGunOperator",24d)){if(!Social.uuid(friend).toString().equals(id)||!Social.alive(friend)||Social.kind(friend)!=Social.kind(n)||!Ambient78.eligible(friend))continue;double d=Social.distance(n,friend);if(d<=25){c(Social.tag(n),"putLong","npc79_acompanado",now);c(Social.tag(n),"putLong","npc79_compania_despues",now+600);return false;}long until=Social.l(Social.tag(n),"npc79_compania_hasta");if(until==0){c(Social.tag(n),"putLong","npc79_compania_hasta",now+200);until=now+200;}if(now>until){c(Social.tag(n),"putLong","npc79_compania_hasta",0L);c(Social.tag(n),"putLong","npc79_compania_despues",now+600);return false;}if(now%20<5&&!Navigation78.go(n,Social.num(c(friend,"getX")),Social.num(c(friend,"getY")),Social.num(c(friend,"getZ")),.8)){c(Social.tag(n),"putLong","npc79_compania_despues",now+200);return false;}Social.mem(n).occupied=true;return true;}return false;}
 static void tick(Object n){if(Social.client(n)||!Social.alive(n))return;if(Social.l(Social.tag(n),"npc79_asentarse")==0)c(Social.tag(n),"putLong","npc79_asentarse",Social.time(n)+600);}
 static boolean work(Object n){if(!calm(n))return false;try{
  // Native needs service used to be skipped whenever the social work flag was set.
  Social.mem(n).occupied=false;
  c(Social.t("mod.cdv.tnpc.tactical.Tactical27"),"idle",n);
  if(servicing(n)){Social.mem(n).occupied=true;return mark(n,"comer_o_beber");}
  if(Ambient78.work(n))return mark(n,"conversar");
  if(Companion78.work(n))return mark(n,"acompanar");
  // Finish a shelter before constructing a depot or taking a hunting trip.
  Shelter77.Camp camp=Shelter77.get(n);
  if(camp!=null&&!camp.phase.equals("descansar")&&Shelter77.work(n))return mark(n,"construir_refugio");
  if(!Social.s(Social.tag(n),"npc77_refugio_lider").isBlank()&&Shelter77.work(n))return mark(n,"ayudar_refugio");
  // Real corpse/container adapter has priority over a long idle rest.
  Object state=CalmBrain.state(n);
  c(Social.t("mod.cdv.tnpc.tactical.SurvivorPatch"),"search",n,state,Social.time(n));
  if(SocialR.get(state,"corpse")!=null){c(Social.t("mod.cdv.tnpc.tactical.SurvivorPatch"),"idle",n,state,Social.time(n));return mark(n,"recolectar_cadaver");}
  if(Hunt78.work(n))return mark(n,"caza_y_deposito");
  if(Mining79.work(n))return mark(n,"minar_recursos");
  if(Activity78.roofWork(n))return mark(n,"refugiarse");
  if(Shelter77.work(n))return mark(n,"descansar_refugio");
  if(Activity78.idle(n))return mark(n,"buscar_suministros");
  if(company(n))return mark(n,"buscar_compania");
  // An idle NPC may explore, rather than being frozen by a permanent work lock.
  c(Social.tag(n),"putString","npc79_tarea","explorar");return false;
 }catch(Exception e){Social.mem(n).occupied=false;c(Social.tag(n),"putString","npc79_tarea","error_"+e.getClass().getSimpleName());if(WARN.add(n))Social.warn("simple survival goal",e);return false;}}
}
