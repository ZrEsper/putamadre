package dev.zomboid.gore;
public final class Fall27 {
 public static double[] initial(double x,double y,double z){if(!Double.isFinite(x+y+z))return new double[3];double n=Math.hypot(x,z),s=n>.025?.025/n:1;return new double[]{x*s,Math.min(y,0),z*s};}
 public static void initial(Object rag,Object data,Object velocity){String type=String.valueOf(R.get(data,"mobType"));boolean zombie=((Number)R.get(data,"goreState12")).intValue()<0||type.contains("zombie")||type.equals("minecraft:husk")||type.equals("minecraft:drowned");if(!zombie||((Number)R.get(data,"hitPartIndex")).intValue()==-3)return;double[]a=initial(R.num(R.get(velocity,"x")),R.num(R.get(velocity,"y")),R.num(R.get(velocity,"z")));R.set(velocity,"x",(float)a[0]);R.set(velocity,"y",(float)a[1]);R.set(velocity,"z",(float)a[2]);}
}
