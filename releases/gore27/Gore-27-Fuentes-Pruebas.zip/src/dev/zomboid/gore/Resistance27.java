package dev.zomboid.gore;
public final class Resistance27 {
 public static float damage(float value){return Float.isFinite(value)&&value>0?value*.55f:value;}
 public static void incoming(Object event){Object n=R.call(event,"getEntity");if(!Gore.zombie(n))return;Object bullet=R.call(R.call(event,"getSource"),"getDirectEntity");if(!Bullet13.tacz(bullet)||R.yes(R.get(bullet,"explosion")))return;float value=(float)R.num(R.call(event,"getAmount"));if(value>0)R.call(event,"setAmount",damage(value));}
}
