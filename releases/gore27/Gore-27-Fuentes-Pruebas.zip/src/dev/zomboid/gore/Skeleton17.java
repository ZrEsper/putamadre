package dev.zomboid.gore;
import java.util.List;
/** Thin connected bone beneath the soft tissue, never a solid white head box. */
public final class Skeleton17 {
 static void b(List<Anatomy14.Piece>p,String n,float x,float y,float z,float X,float Y,float Z){Anatomy27.b(p,n,2,x,y,z,X,Y,Z);}
 public static void add(List<Anatomy14.Piece>p,int r){if(r==0){
  b(p,"cranial_roof",.12f,.045f,.16f,.88f,.095f,.89f);
  b(p,"forehead",.12f,.095f,.16f,.88f,.34f,.205f);
  b(p,"occipital",.12f,.10f,.86f,.88f,.70f,.91f);
  b(p,"temporal_left",.09f,.10f,.205f,.14f,.67f,.86f);
  b(p,"temporal_right",.86f,.10f,.205f,.91f,.67f,.86f);
  for(float x:new float[]{.155f,.595f}){
   b(p,"orbit_brow",x,.34f,.10f,x+.25f,.39f,.26f);
   b(p,"orbit_floor",x,.59f,.12f,x+.25f,.63f,.27f);
  }
  b(p,"nose_bridge",.46f,.38f,.09f,.54f,.59f,.23f);
  b(p,"cheek_left",.13f,.41f,.13f,.18f,.69f,.32f);
  b(p,"cheek_right",.82f,.41f,.13f,.87f,.69f,.32f);
  b(p,"maxilla",.23f,.645f,.13f,.77f,.69f,.24f);
  b(p,"palate",.24f,.695f,.25f,.76f,.72f,.72f);
  b(p,"jaw_ramus_left",.15f,.66f,.24f,.20f,.94f,.75f);
  b(p,"jaw_ramus_right",.80f,.66f,.24f,.85f,.94f,.75f);
  b(p,"jaw_chin",.20f,.89f,.14f,.80f,.945f,.23f);
  b(p,"jaw_floor",.24f,.895f,.24f,.76f,.935f,.72f);
  b(p,"cervical",.455f,.76f,.57f,.545f,1,.66f);
  for(int i=0;i<3;i++){float y=.80f+i*.066f;b(p,"cervical_vertebra",.42f,y,.56f,.58f,y+.04f,.68f);}
  for(int i=0;i<6;i++){float x=.245f+i*.085f;Anatomy27.b(p,"tooth",5,x,.695f,.12f,x+.055f,.745f,.21f);Anatomy27.b(p,"tooth",5,x,.845f,.12f,x+.055f,.89f,.21f);}
 }else if(r==6){
  b(p,"spine",.46f,0,.67f,.54f,1,.79f);
  for(int i=0;i<10;i++){float y=.015f+i*.095f;b(p,"vertebra",.405f,y,.64f,.595f,y+.06f,.84f);b(p,"spinous_process",.47f,y+.01f,.82f,.53f,y+.045f,.91f);}
  b(p,"clavicle_left",.035f,.035f,.20f,.45f,.085f,.35f);b(p,"clavicle_right",.55f,.035f,.20f,.965f,.085f,.35f);
  b(p,"scapula_left",.10f,.12f,.79f,.34f,.34f,.84f);b(p,"scapula_right",.66f,.12f,.79f,.90f,.34f,.84f);
  b(p,"sternum",.47f,.105f,.145f,.53f,.51f,.205f);
  for(int i=0;i<5;i++){float y=.135f+i*.077f;
   b(p,"rib_anterior_left",.12f,y,.145f,.475f,y+.027f,.205f);b(p,"rib_anterior_right",.525f,y,.145f,.88f,y+.027f,.205f);
   b(p,"rib_lateral_left",.085f,y,.20f,.135f,y+.027f,.72f);b(p,"rib_lateral_right",.865f,y,.20f,.915f,y+.027f,.72f);
   b(p,"rib_posterior",.12f,y,.735f,.88f,y+.027f,.79f);
  }
  b(p,"pelvis_left",.13f,.84f,.31f,.23f,1,.77f);b(p,"pelvis_right",.77f,.84f,.31f,.87f,1,.77f);
  b(p,"pelvis_back",.23f,.91f,.69f,.77f,1,.80f);b(p,"pubic_arch",.23f,.965f,.27f,.77f,1,.36f);
 }else{
  boolean arm=r==2||r==3;
  if(arm)b(p,"shoulder_link",r==2?0:.36f,0,.40f,r==2?.64f:1,.06f,.61f);
  b(p,"upper_bone",.42f,.035f,.43f,.58f,.48f,.60f);
  b(p,"joint",.35f,.47f,.37f,.65f,.54f,.66f);
  b(p,arm?"radius":"tibia",.34f,.54f,.42f,.46f,.94f,.56f);
  b(p,arm?"ulna":"fibula",.56f,.54f,.47f,.65f,.94f,.58f);
  b(p,arm?"wrist":"ankle",.31f,.915f,.34f,.69f,.96f,.61f);
  for(int i=0;i<4;i++){float x=.27f+i*.13f;b(p,arm?"metacarpal":"metatarsal",x,.95f,.26f,x+.065f,1,.61f);}
  b(p,arm?"elbow":"patella",.39f,.475f,.31f,.61f,.545f,.37f);
 }
 }
}
