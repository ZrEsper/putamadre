from pathlib import Path
r=Path(__file__).resolve().parent
p=r/'src/dev/zomboid/gore/Anatomy14.java';s=p.read_text();start=s.index(' public static List<Piece> anatomy(');end=s.index(' static boolean bone(',start)
new=''' static final Map<Integer,List<Piece>> ANATOMY=new HashMap<>();
 public static synchronized List<Piece> anatomy(int region){int r=region==1?0:region==7?6:region;return ANATOMY.computeIfAbsent(r,Anatomy27::create);}
'''
s=s[:start]+new+s[end:];s=s.replace('return p.material()==2||p.name().equals("tooth")||p.name().equals("socket_shadow");','return p.material()==2||p.name().equals("tooth");')
p.write_text(s)
