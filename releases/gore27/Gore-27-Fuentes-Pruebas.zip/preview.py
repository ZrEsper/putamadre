from pathlib import Path
import json,math
import numpy as np
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).resolve().parent;data=json.loads((r/'anatomy-mesh.json').read_text());tex=np.asarray(Image.open(r/'anatomy27.png').convert('RGB'))
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def font(n):return ImageFont.truetype(fontpath,n)
def render(faces,size=(440,440),yaw=0,pitch=0,exclude=(),scale=30):
 w,h=size;im=np.zeros((h,w,3),np.uint8);im[:]=(24,29,30);zb=np.full((h,w),np.inf);vtx=np.array([v[:3]for q in faces for v in q['v']]);center=(vtx.min(axis=0)+vtx.max(axis=0))/2
 cy,sy=math.cos(yaw),math.sin(yaw);cp,sp=math.cos(pitch),math.sin(pitch);rot=np.array([[cy,0,-sy],[sy*sp,cp,cy*sp],[sy*cp,-sp,cy*cp]])
 for f in faces:
  if any(f['name'].startswith(n)for n in exclude):continue
  vs=np.array(f['v']);p=(vs[:,:3]-center)@rot.T;p[:,0]=p[:,0]*scale+w/2;p[:,1]=p[:,1]*scale+h/2
  normal=np.array(f['n'])@rot.T;shade=max(.52,min(1,.79+(-normal[2]*.14-normal[1]*.10-normal[0]*.07)))
  for ids in [(0,1,2),(0,2,3)]:
   ids=list(ids);t=p[ids];uv=vs[ids,3:];a,b,c=t;den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
   if abs(den)<1e-7:continue
   x0=max(0,int(np.floor(t[:,0].min())));x1=min(w,int(np.ceil(t[:,0].max()))+1);y0=max(0,int(np.floor(t[:,1].min())));y1=min(h,int(np.ceil(t[:,1].max()))+1)
   if x0>=x1 or y0>=y1:continue
   Y,X=np.mgrid[y0:y1,x0:x1];X=X+.5;Y=Y+.5;u=((b[1]-c[1])*(X-c[0])+(c[0]-b[0])*(Y-c[1]))/den;v=((c[1]-a[1])*(X-c[0])+(a[0]-c[0])*(Y-c[1]))/den;q=1-u-v;depth=u*a[2]+v*b[2]+q*c[2];mask=(u>=-1e-4)&(v>=-1e-4)&(q>=-1e-4)&(depth<zb[y0:y1,x0:x1]);U=u*uv[0,0]+v*uv[1,0]+q*uv[2,0];V=u*uv[0,1]+v*uv[1,1]+q*uv[2,1];tx=np.clip((U*64).astype(int),0,63);ty=np.clip((V*80).astype(int),0,79);colors=(tex[ty,tx]*shade).astype(np.uint8);im[y0:y1,x0:x1][mask]=colors[mask];zb[y0:y1,x0:x1][mask]=depth[mask]
 return Image.fromarray(im)
canvas=Image.new('RGB',(1320,780),(18,22,23));d=ImageDraw.Draw(canvas);d.text((28,20),'ANATOMÍA .27 · modelo del parche',font=font(28),fill=(226,218,196));d.text((28,62),'Vista técnica de las mallas y texturas; no es una captura de Minecraft.',font=font(17),fill=(157,166,164))
head=render(data['0'],yaw=.20,pitch=.40,exclude=['cranial_roof','forehead','temporal_left','temporalis'],scale=39)
body=render(data['6'],yaw=.12,pitch=.05,exclude=['pectoral','abdominal_wall'],scale=30)
side=render(data['0'],yaw=1.05,pitch=.12,exclude=['cranial_roof','temporal_left','temporal_right','temporalis','occipital','forehead'],scale=39)
for i,(im,title,texts)in enumerate([(head,'Cabeza abierta',['Cerebro rosado de dos hemisferios','Ojos con iris y pupilas · lengua']), (body,'Tórax y abdomen',['Pulmones · corazón · hígado · estómago','Intestinos, colon y columna vertebral']), (side,'Corte lateral de la cabeza',['Cerebelo · tronco cerebral · mandíbula','Músculos faciales y conexión cervical'])]):
 canvas.paste(im,(i*440,118));d.text((i*440+20,99),title,font=font(21),fill=(220,204,171))
 for j,s in enumerate(texts):d.text((i*440+20,576+j*28),s,font=font(16),fill=(199,199,188))
d.text((28,674),'En estas vistas se retiran algunas capas externas para enseñar los órganos interiores.',font=font(18),fill=(164,174,170));d.text((28,707),'En el juego los cortes locales exponen y destruyen la anatomía en el punto de impacto.',font=font(18),fill=(164,174,170))
canvas.save(r/'output/Vista-previa-anatomia-27.png')
