package com.tacz.guns.entity;public class EntityKineticBullet {public boolean explosion;}
