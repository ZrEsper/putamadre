from pathlib import Path
from PIL import Image,ImageDraw
import random,json
r=Path(__file__).resolve().parent
# Deliberately small clustered pixels, burgundy tissue and warm ivory; TZP is a 64px skin pack.
colors=[(0,0,0),(102,28,34),(181,166,132),(161,84,90),(58,35,52),(212,197,164),(137,64,74),(113,24,37),(88,30,36),(173,100,101),(150,70,76),(172,62,76),(211,199,175),(98,109,91),(20,16,18),(160,32,40),(117,39,45),(194,172,132),(169,140,89),(173,155,125)]
im=Image.new('RGBA',(64,80),(0,0,0,255));d=ImageDraw.Draw(im)
for m,base in enumerate(colors):
 ox=(m%4)*16;oy=(m//4)*16;random.seed(2700+m)
 for y in range(16):
  for x in range(16):
   # Coarse tonal clusters, no per-pixel white static.
   k=((x//3*3+y//3*5+m)%7-3)*2
   if m in [1,16]:k+=6 if (y+x//4)%5==0 else -3 if (y+x//4)%5==1 else 0
   if m==2:k+=4 if x in [4,11] else 0
   if m==3:k+=-20 if ((x//3+y//4)%3==0 and x%3==0) else 9 if (y+x//4)%5==2 else 0
   if m==6:k+=-12 if (x+y*2)%11==0 else 0
   if m in [7,8]:k+=-10 if x in [3,9] and y%5<3 else 0
   if m in [9,10,11]:k+=6 if y%5==2 else -5 if y%5==4 else 0
   rgb=tuple(max(0,min(255,c+k))for c in base);d.point((ox+x,oy+y),fill=rgb+(255,))
(r/'anatomy27.png').write_bytes(b'')
im.save(r/'anatomy27.png');im.resize((512,640),Image.Resampling.NEAREST).save(r/'video/materiales27.png')
(r/'palette.json').write_text(json.dumps(colors))
