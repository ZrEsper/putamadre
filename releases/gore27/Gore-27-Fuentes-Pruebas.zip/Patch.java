import java.nio.file.*;import java.util.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;import jdk.internal.org.objectweb.asm.tree.analysis.*;
public class Patch implements Opcodes {
 static String G="dev/zomboid/gore/";
 public static void main(String[]a)throws Exception{Map<String,byte[]>entries=new TreeMap<>();try(var z=new ZipFile(a[0])){for(var e:Collections.list(z.entries()))entries.put(e.getName(),z.getInputStream(e).readAllBytes());}
 int hooks=0;
 for(String path:List.of(G+"Mesh12.class",G+"Skin12.class",G+"Gore.class")){ClassNode c=new ClassNode();new ClassReader(entries.get(path)).accept(c,0);for(var m:c.methods){
  if(c.name.equals(G+"Mesh12")&&m.name.equals("box")){for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN){var l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new MethodInsnNode(INVOKESTATIC,G+"Palette27","lastBox","(Ljava/util/List;)V",false));m.instructions.insertBefore(n,l);}hooks++;}
  if(c.name.equals(G+"Gore")&&m.name.equals("incoming")){for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN){var l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new MethodInsnNode(INVOKESTATIC,G+"Resistance27","incoming","(Ljava/lang/Object;)V",false));m.instructions.insertBefore(n,l);}hooks++;}
  if(c.name.equals(G+"Skin12")&&m.name.equals("<clinit>")){for(var n:m.instructions.toArray()){
   if(n instanceof LdcInsnNode s&&s.cst.equals("textures/entity/trauma12.png")){s.cst="textures/entity/anatomy27.png";hooks++;}
   if(n.getOpcode()==RETURN){var l=new InsnList();l.add(new MethodInsnNode(INVOKESTATIC,G+"Palette27","colors","()[I",false));l.add(new FieldInsnNode(PUTSTATIC,G+"Skin12","COLORS","[I"));m.instructions.insertBefore(n,l);hooks++;}
  }}
 }ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);entries.put(path,w.toByteArray());}
 if(hooks!=4)throw new AssertionError("hooks="+hooks);
 try(var walk=Files.walk(Path.of(a[1]))){for(var p:walk.filter(p->p.toString().endsWith(".class")).toList())entries.put(Path.of(a[1]).relativize(p).toString(),Files.readAllBytes(p));}
 int verified=0;for(var e:entries.entrySet())if(e.getKey().endsWith(".class")&&e.getKey().startsWith(G)){ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);for(var m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);verified++;}
 try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(a[2])))){for(var e:entries.entrySet()){var n=new ZipEntry(e.getKey());n.setTime(0);z.putNextEntry(n);z.write(e.getValue());z.closeEntry();}}
 Map<String,byte[]>rag=new TreeMap<>();try(var z=new ZipFile(a[3])){for(var e:Collections.list(z.entries()))rag.put(e.getName(),z.getInputStream(e).readAllBytes());}
 String rp="com/raiiiden/ragdollified/client/ClientRagdoll.class";ClassNode rc=new ClassNode();new ClassReader(rag.get(rp)).accept(rc,0);int fall=0;
 for(var m:rc.methods)if(m.name.equals("createRagdollBodies")){for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode i&&i.owner.equals("javax/vecmath/Vector3f")&&i.name.equals("scale")&&i.desc.equals("(F)V")){
  AbstractInsnNode prev=n.getPrevious(); // Receiver local appears before the scale-factor expression; recover from the initialVel ASTORE.
  int slot=-1;for(var x=m.instructions.getFirst();x!=n;x=x.getNext())if(x instanceof MethodInsnNode ctor&&ctor.owner.equals("javax/vecmath/Vector3f")&&ctor.name.equals("<init>")&&ctor.desc.equals("(FFF)V")&&x.getNext() instanceof VarInsnNode store&&store.getOpcode()==ASTORE)slot=store.var;
  if(slot<0)throw new AssertionError("initial velocity local");var l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(ALOAD,slot));l.add(new MethodInsnNode(INVOKESTATIC,G+"Fall27","initial","(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V",false));m.instructions.insert(n,l);fall++;break;
 }}
 if(fall!=1)throw new AssertionError("fall hook "+fall);ClassWriter rw=new ClassWriter(ClassWriter.COMPUTE_MAXS);rc.accept(rw);rag.put(rp,rw.toByteArray());
 try(var walk=Files.walk(Path.of(a[4]))){for(var p:walk.filter(p->p.toString().endsWith(".class")).toList())rag.put(Path.of(a[4]).relativize(p).toString(),Files.readAllBytes(p));}
 for(var e:rag.entrySet())if(e.getKey().endsWith(".class")&&e.getKey().startsWith("com/raiiiden/")){ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);for(var m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);verified++;}
 try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(a[5])))){for(var e:rag.entrySet()){var n=new ZipEntry(e.getKey());n.setTime(0);z.putNextEntry(n);z.write(e.getValue());z.closeEntry();}}
 System.out.println("RAGDOLL27_FALL_HOOK="+fall);
 System.out.println("ANATOMY27_MATERIAL_HOOKS="+hooks+" VERIFIED_GORE_CLASSES="+verified);
 }
}
