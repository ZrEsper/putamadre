from pathlib import Path
import subprocess,zipfile,json,hashlib
r=Path(__file__).resolve().parent
GORE=next((r.parent/'procedural26/output').glob('zomboid*.jar'));RAG=next((r.parent/'procedural25/output').glob('ragdoll*.jar'))
exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{s}=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']]
for d in ['build/classes','build/rag','build/tools','output']:(r/d).mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(GORE),'-d',str(r/'build/classes'),*map(str,(r/'src').rglob('*.java'))],check=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(GORE),'-d',str(r/'build/rag'),*map(str,(r/'rag-src').rglob('*.java'))],check=True)
subprocess.run(['java',*exports,'com.sun.tools.javac.Main',*exports,'-d',str(r/'build/tools'),str(r/'Patch.java')],check=True)
g=r/'output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-tzp-organ-anatomy.27.jar';rag=r/'output/ragdollified-1.21.1-1.1.5-grounded-falls.22.jar'
subprocess.run(['java',*exports,'-cp',str(r/'build/tools'),'Patch',str(GORE),str(r/'build/classes'),str(g),str(RAG),str(r/'build/rag'),str(rag)],check=True)
with zipfile.ZipFile(g)as z:e={n:z.read(n)for n in z.namelist()}
e['assets/zomboid_gore/textures/entity/anatomy27.png']=(r/'anatomy27.png').read_bytes()
e['META-INF/neoforge.mods.toml']=e['META-INF/neoforge.mods.toml'].replace(b'Gore .26',b'Gore .27')
e['META-INF/zomboid-anatomy27.json']=json.dumps({'patch':27,'anatomy':'20 dedicated low resolution materials; large organs; connected bones','ballistic_damage_multiplier':.55,'ballistic_cut_radius_multiplier':.68,'ragdoll':'grounded-falls.22','protocol':'17-procedural25','minecraft_runtime_tested':False}).encode()
with zipfile.ZipFile(g,'w',zipfile.ZIP_DEFLATED)as z:
 for n,b in sorted(e.items()):z.writestr(n,b)
print(g,rag,sep='\n')
