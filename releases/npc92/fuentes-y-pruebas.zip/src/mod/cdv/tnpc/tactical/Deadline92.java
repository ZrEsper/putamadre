package mod.cdv.tnpc.tactical;
import java.util.*;
/** Bounded exploration -> a persistent, actionable settlement goal. No teleporting. */
public final class Deadline92{
 static final long LIMIT=1200; // 60 seconds at the normal 20 TPS.
 static Object c(Object o,String m,Object...a){return Social.c(o,m,a);}
 static boolean allowed(Object n){return Life79.calm(n)&&CalmBrain.state(n).target==null&&Social.mem(n).threats==0&&!Life79.servicing(n)&&!Survival85.sleeping(n)&&!Survival85.blocked(n,null)&&Social.s(Social.tag(n),"soc_order").isBlank();}
 public static boolean life(Object n){if(!allowed(n)){c(Social.tag(n),"putLong","npc92_explorar_limite",0L);return nativeWork(n);}long now=Social.time(n);String task=Social.s(Social.tag(n),"npc79_tarea");boolean forced=Social.l(Social.tag(n),"npc92_objetivo_forzado")!=0;boolean exploring=task.equals("explorar")||task.isBlank()&&Base48.base(n)==null;long limit=Social.l(Social.tag(n),"npc92_explorar_limite");if(!forced&&exploring){if(limit==0){limit=now+LIMIT;c(Social.tag(n),"putLong","npc92_explorar_limite",limit);}if(now>=limit){forced=true;c(Social.tag(n),"putLong","npc92_objetivo_forzado",1L);}}
 if(forced){try{return objective(n,now);}catch(Exception e){if(Bootstrap92.WARN.add(n))Social.warn("exploration deadline92",e);c(Social.tag(n),"putLong","npc92_objetivo_siguiente",now+200);return Life79.mark(n,"objetivo_refugio_bloqueado_reintentar");}}
 boolean result=nativeWork(n);String after=Social.s(Social.tag(n),"npc79_tarea");if(!after.equals("explorar")&&!after.isBlank())c(Social.tag(n),"putLong","npc92_explorar_limite",0L);return result;}
 static boolean nativeWork(Object n){return Social.yes(c(Life79.class,"workNative58",n));}
 static boolean goal(Object n,String label,boolean busy){if(busy)Job90.claim(n);return Life79.mark(n,label);}
 static boolean objective(Object n,long now){if(Bootstrap92.eligible(n)){if(Community87.work(n)){c(Social.tag(n),"putLong","npc92_objetivo_forzado",0L);c(Social.tag(n),"putLong","npc92_explorar_limite",0L);return goal(n,Social.s(Social.tag(n),"npc87_actividad"),true);}return goal(n,"resolver_necesidad_de_base_reintentar",false);}
 if(!Shelter77.safe(n))return nativeWork(n);
 Shelter77.Camp camp=Shelter77.get(n);if(camp!=null&&!camp.phase.equals("descansar")){if(Shelter77.work(n))return goal(n,"construir_refugio",true);return goal(n,"refugio_esperar_materiales_o_ruta",false);}
 if(now<Social.l(Social.tag(n),"npc92_objetivo_siguiente"))return goal(n,"buscar_sitio_para_refugio",true);c(Social.tag(n),"putLong","npc92_objetivo_siguiente",now+20);
 if(!Shelter77.cfg().get("activos").getAsBoolean())return goal(n,"refugio_desactivado_en_configuracion",false);
 Activity78.cover(n,"asentarse");Activity78.Roof roof=Activity78.ROOFS.get(n);if(roof!=null&&roof.pos!=null){Hunt78.home(n,roof.pos);if(Bootstrap92.eligible(n))return objective(n,now);}
 if(!Shelter77.grief(n))return goal(n,"refugio_bloqueado_por_mobgriefing_o_proteccion",false);
 Object feet=c(n,"blockPosition");int scan=(int)Social.l(Social.tag(n),"npc92_buscar_sitio");int[][] offsets={{4,0},{-7,0},{0,4},{0,-7},{5,5},{-8,5},{5,-8},{-8,-8}};
 for(int i=0;i<2;i++){int[]off=offsets[Math.floorMod(scan++,offsets.length)];Shelter77.Camp plan=new Shelter77.Camp(Shelter77.axis(feet,"getX")+off[0],Shelter77.axis(feet,"getY"),Shelter77.axis(feet,"getZ")+off[1],2);if(!Shelter77.site(n,plan))continue;plan.reason="asentarse";plan.until=now+Shelter77.num("max_tiempo_trabajo_ticks");Shelter77.save(n,plan);c(Social.tag(n),"putLong","npc92_buscar_sitio",(long)scan);return goal(n,"construir_refugio",true);}
 c(Social.tag(n),"putLong","npc92_buscar_sitio",(long)scan);
 if(scan%8==0){for(int[]off:new int[][]{{8,0},{-8,0},{0,8},{0,-8}}){Object p=TradeWorld87.surface(n,Base48.off(feet,off[0],0,off[1]));if(p!=null&&Base48.floor(n,p)&&Base48.reachable(n,p)&&Navigation78.go(n,Shelter77.axis(p,"getX")+.5,Shelter77.axis(p,"getY"),Shelter77.axis(p,"getZ")+.5,.95)){c(Social.tag(n),"putLong","npc92_objetivo_siguiente",now+100);return goal(n,"buscar_terreno_transitable_para_refugio",true);}}return goal(n,"refugio_sin_sitio_transitable_reintentar",false);}
 return goal(n,"buscar_sitio_para_refugio",true);}
}
