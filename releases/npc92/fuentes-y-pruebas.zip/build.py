from pathlib import Path
import subprocess,argparse,hashlib
r=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--base',default='/workspace/npc91/release/tacznpcs-2.1.0-1.21.1-tactical.58-work-sites.jar');p.add_argument('--tools',default='/workspace/putamadre/hordes-melee-interiors-patch/build/tools');p.add_argument('--gson',default='/workspace/medical63/gson.jar');a=p.parse_args();t=Path(a.tools)
assert hashlib.sha256(Path(a.base).read_bytes()).hexdigest()=='96c864ae1fafe05ad9fe93e0b5180dc2051660f1d3e978d1617cff16c5462747','Requires exact released .58 base'
ecj=['java','-jar',str(t/'ecj.jar'),'-21','-nowarn','-proc:none'];asm=':'.join(str(t/(x+'.jar'))for x in ['asm','asm-tree','asm-analysis'])
subprocess.run(ecj+['-cp',a.base+':'+a.gson,'-d',str(r/'build')]+[str(p)for p in (r/'src').rglob('*.java')],check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'Patch92.java')],check=True)
(r/'release').mkdir(exist_ok=True)
subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'Patch92',a.base,str(r/'release/tacznpcs-2.1.0-1.21.1-tactical.59-bootstrap-work.jar'),str(r/'build')],check=True)
