package mod.cdv.tnpc.tactical;
import com.google.gson.JsonObject;
import java.util.*;
import java.util.function.BiPredicate;
public final class WorkTest56 {
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static JsonObject group(){JsonObject g=new JsonObject();g.addProperty("x",0);g.addProperty("y",65);g.addProperty("z",0);g.addProperty("fase",0);g.addProperty("cursor_muro",0);g.add("construido",new JsonObject());return g;}
 static Sim47.Actor actor(Sim47.World w)throws Exception{Sim47.Actor n=new Sim47.Actor(w);Settlement87.DATA.put(w,new WorldSocial74());CalmLoot.saveBag(n,new ArrayList<>(List.of(Shelter77.item("minecraft:dirt",12),Shelter77.item("minecraft:oak_sapling",1),Shelter77.item("minecraft:stone_pickaxe",1),Shelter77.item("minecraft:oak_fence_gate",1))));n.tag.putLong("npc87_granja_kit",1);return n;}
 static void blocked(String task,BiPredicate<Object,JsonObject> work,java.util.function.Consumer<JsonObject> setup)throws Exception{
  Sim47.World w=new Sim47.World();w.forceUnreachable=true;Sim47.Actor n=actor(w);JsonObject g=group();setup.accept(g);
  for(int i=0;i<20;i++){check(work.test(n,g),task+" ended before timeout at "+i);w.now+=20;}
  check(!work.test(n,g),task+" did not release control after400ticks");
  for(int i=0;i<9;i++){w.now+=20;check(!work.test(n,g),task+" ignored retry cooldown");}
  w.now+=20;check(work.test(n,g),task+" did not retry after cooldown");
 }
 public static void main(String[] args)throws Exception{
  Sim47.setup();
  blocked("fortWork",Fort87::work,g->{});
  blocked("fortRepair",Fort87::repair,g->{g.addProperty("fase",4);g.getAsJsonObject("construido").addProperty("-16,65,-16","minecraft:dirt");});
  blocked("fortGates",Fort87::gates,g->g.addProperty("fase",1));
  blocked("farmWork",Farm87::work,g->{g.addProperty("parcela_x",9);g.addProperty("parcela_y",65);g.addProperty("parcela_z",0);});
  blocked("farmTree",Farm87::tree,g->{});
  blocked("mine",Industry87::mine,g->g.addProperty("mina_paso",1));
  Sim47.World w=new Sim47.World();w.forceUnreachable=true;Sim47.Actor n=actor(w);JsonObject g=group();
  for(int i=0;i<100;i++){if(i%10==0)n.x+=.5;check(Fort87.work(n,g),"moving NPC was prematurely released");w.now+=20;}
  Sim47.World viable=new Sim47.World();Sim47.Actor builder=actor(viable);builder.x=-15.5;builder.z=-15.5;JsonObject vg=group();Work86.WARN.add(builder);
  check(Fort87.work(builder,vg),"nearby viable placement failed");check(vg.get("cursor_muro").getAsInt()==1&&Base48.count(builder,"minecraft:dirt")==11&&Base48.id(viable,new Sim47.Pos(-16,65,-16)).equals("minecraft:dirt"),"viable task lost placement/inventory/progress");
  System.out.println("PASS: six native profession entrypoints release stalled tasks, honor cooldown and retry; movement resets timeout; viable fortification still consumes exactly one item and advances cursor");
 }
}
