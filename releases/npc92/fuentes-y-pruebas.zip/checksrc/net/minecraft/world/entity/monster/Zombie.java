package net.minecraft.world.entity.monster;
/** No zombies in the base economy scenario. */
public class Zombie {}
