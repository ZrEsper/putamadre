package net.minecraft.world.entity;
/** No corpse or item entities in the economy scenario. */
public class Entity {}
