package net.minecraft.nbt;public class CompoundTag extends mod.cdv.tnpc.tactical.Sim47.Tag{}
