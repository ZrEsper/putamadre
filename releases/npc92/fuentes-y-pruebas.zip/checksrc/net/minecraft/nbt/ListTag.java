package net.minecraft.nbt;public class ListTag extends java.util.ArrayList<Object>{public Object getCompound(int i){return get(i);}}
