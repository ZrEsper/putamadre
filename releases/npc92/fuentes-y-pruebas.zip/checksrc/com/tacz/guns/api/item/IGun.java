package com.tacz.guns.api.item; public interface IGun{}
