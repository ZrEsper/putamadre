from pathlib import Path
import subprocess,zipfile
r=Path(__file__).parent;jar=r/'release/firstaid-1.21.1-ZOMBOID-v3.6.24-unified-health-splint-game.jar';tests=r/'tests';tests.mkdir(exist_ok=True)
# Production classes are loaded from JAR; fixtures shadow only game APIs, not patch classes.
cp=str(jar)+':/workspace/medical63/gson.jar'
subprocess.run(['java','-jar','/workspace/putamadre/hordes-melee-interiors-patch/build/tools/ecj.jar','-21','-proc:none','-nowarn','-cp',cp,'-d',str(tests)]+list(map(str,(r/'testsrc').rglob('*.java'))),check=True)
subprocess.run(['java','-Xverify:all','-cp',str(tests)+':'+cp,'dev.zomboid.firstaid.Check67'],check=True)
