from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');base='/workspace/attachments/6ad54784-a38b-4c00-a34e-ad35e7edc3e6/firstaid-1.21.1-ZOMBOID-v3.6.23-leg-contact-ik.jar';asm=':'.join([str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis']]+['/workspace/medical65/asm-commons.jar']);ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn']
subprocess.run(ecj+['-cp',base,'-d',str(r/'build')]+list(map(str,(r/'src').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'Patch67.java')],check=True)
subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'Patch67',base,str(r/'build'),str(r/'release/firstaid-1.21.1-ZOMBOID-v3.6.24-unified-health-splint-game.jar')],check=True)
