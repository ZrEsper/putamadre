package ichttt.mods.firstaid;public class FirstAid{public static Channel NETWORKING=new Channel();public static class Channel{public void sendToServer(Object p){}}}
