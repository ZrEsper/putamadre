package ichttt.mods.firstaid.fracture;public class SplintItem{}
