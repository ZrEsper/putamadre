package ichttt.mods.firstaid.common.network;public class MessageClientRequest{public enum RequestType{REQUEST_REFRESH}public MessageClientRequest(RequestType r){}}
