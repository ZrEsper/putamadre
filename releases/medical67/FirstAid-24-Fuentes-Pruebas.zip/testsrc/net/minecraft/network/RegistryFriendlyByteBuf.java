package net.minecraft.network;public class RegistryFriendlyByteBuf{public final java.nio.ByteBuffer data=java.nio.ByteBuffer.allocate(100);}
