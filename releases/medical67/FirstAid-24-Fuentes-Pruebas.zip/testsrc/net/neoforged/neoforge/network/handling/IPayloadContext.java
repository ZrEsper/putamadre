package net.neoforged.neoforge.network.handling;public interface IPayloadContext{Object player();java.util.concurrent.CompletableFuture<Void>enqueueWork(Runnable r);}
