package net.neoforged.neoforge.network.handling;public interface IPayloadHandler<T extends net.minecraft.network.protocol.common.custom.CustomPacketPayload>{void handle(T p,IPayloadContext c);}
