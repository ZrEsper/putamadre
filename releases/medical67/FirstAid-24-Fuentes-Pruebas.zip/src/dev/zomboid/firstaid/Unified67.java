package dev.zomboid.firstaid;
import java.util.*;
import java.lang.reflect.Array;
public final class Unified67 {
 static final Map<Object,Game> GAMES=new WeakHashMap<>();
 static Object c(Object o,String m,Object...a){return R.call(o,m,a);}
 static Object mc(){return c(R.type("net.minecraft.client.Minecraft"),"getInstance");}
 static int n(Object o,String s){return ((Number)R.get(o,s)).intValue();}
 static void staticSet(Class<?> clazz,String key,Object val){try{var f=clazz.getDeclaredField(key);f.setAccessible(true);f.set(null,val);}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}}
 static Object open(){Object minecraft=mc(),player=R.get(minecraft,"player");if(player==null)return null;Object model=c(R.type("ichttt.mods.firstaid.common.util.CommonUtils"),"getDamageModel",player);if(model==null||((Number)c(model,"getUnconsciousTicks")).intValue()>0)return null;
  Object screen=R.make("ichttt.mods.firstaid.client.gui.GuiHealthScreen",model);Class<?> gui=R.type("ichttt.mods.firstaid.client.gui.GuiHealthScreen");staticSet(gui,"INSTANCE",screen);c(minecraft,"setScreen",screen);
  Object req=R.make("ichttt.mods.firstaid.common.network.MessageClientRequest",R.get(R.type("ichttt.mods.firstaid.common.network.MessageClientRequest$RequestType"),"REQUEST_REFRESH"));c(R.get(R.type("ichttt.mods.firstaid.FirstAid"),"NETWORKING"),"sendToServer",req);return screen;
 }
 public static boolean receive(String json){Object obj=c(c(R.type("com.google.gson.JsonParser"),"parseString",json),"getAsJsonObject");Object stage=c(obj,"get","stage");if(stage!=null&&String.valueOf(c(stage,"getAsString")).equals("offer")){open();return true;}return false;}
 static void care(){Object pkt=R.make("dev.zomboid.integration.care.CareNetwork$Action",1,0,0);c(R.type("net.neoforged.neoforge.network.PacketDistributor"),"sendToServer",pkt,Array.newInstance(R.type("net.minecraft.network.protocol.common.custom.CustomPacketPayload"),0));}
 public static java.util.List<MedicalActions40.Action> actions(java.util.List<MedicalActions40.Action> list){return list.stream().map(a->"left_leg_first".equals(a.reason())?new MedicalActions40.Action(a.key(),a.slot(),a.slot()<0?"need_splint":null):a).toList();}
 public static boolean action(Object screen,int index,String key){if(!key.equals("splint"))return false;begin(screen,index);return true;}
 static void begin(Object screen,int index){
  MedicalView40.Snapshot snapshot=MedicalView40.read(screen);MedicalActions40.Action action=MedicalActions40.list(snapshot,index).stream().filter(a->a.key().equals("splint")&&a.enabled()).findFirst().orElse(null);if(action==null)return;
  Object player=snapshot.player();if(player==null||MedicalActions40.equip(mc(),player,action.slot())==null)return;
  boolean left=MedicalView40.PARTS[index].startsWith("LEFT_");R.set(screen,"selected",snapshot.parts().get(index).id());
  Game game=new Game(left);GAMES.put(screen,game);SplintNet67.send(left?1:2);
 }
 public static void direct(){Object minecraft=mc(),screen=R.get(minecraft,"screen");if(screen==null||!screen.getClass().getName().equals("ichttt.mods.firstaid.client.gui.GuiHealthScreen"))screen=open();if(screen==null)return;Object player=R.get(minecraft,"player");boolean left=Boolean.TRUE.equals(c(R.type("ichttt.mods.firstaid.fracture.Fractures"),"isBroken",player,true));begin(screen,left?4:5);}
 static int[] box(Object screen){Object l=R.get(screen,"layout");int x=n(l,"rightX"),y=n(l,"contentTop"),w=n(l,"rightWidth"),h=n(l,"contentBottom")-y;return new int[]{x,y,w,h};}
 static void text(Object screen,Object g,String s,int x,int y,int color){HealthTab40.text(screen,g,HealthTab40.literal(s),x,y,color);}
 public static void render(Object screen,Object g,int mx,int my){if(!HealthTab40.active(screen)||R.get(screen,"layout")==null)return;int[]b=box(screen);Object layout=R.get(screen,"layout");int footer=n(layout,"top")+n(layout,"height")-24;Game game=GAMES.get(screen);
  if(game==null){HealthTab40.panel(g,b[0],footer,b[2],18,0xff555b4e,0xff272d26);text(screen,g,"Examinar compañero",b[0]+5,footer+5,0xffd3d9bf);return;}
  HealthTab40.panel(g,b[0],b[1],b[2],b[3],0xff747961,0xff20251f);if(b[3]<150){compact(screen,g,b,game,footer);return;}int x=b[0]+8,y=b[1]+9,w=b[2]-16;
  text(screen,g,"Colocar férula",x,y,0xffe0df8b);y+=16;
  String status=game.done?"Férula colocada":game.invalid?"Tratamiento no disponible":game.waiting?"Esperando confirmación…":("Paso "+(game.step+1)+" de 3 · "+new String[]{"Alinear","Colocar","Sujetar"}[Math.min(2,game.step)]);
  y=HealthTab40.wrap(screen,g,HealthTab40.literal(status),x,y,w,game.invalid?0xffff7777:0xffeeeece)+10;
  if(!game.done&&!game.invalid){
   game.stripY=y;int stripY=y,center=SplintRules67.center(game.step);HealthTab40.fill(g,x,stripY,x+w,stripY+16,0xff111711);int lo=(int)(w*(center-1)/13.0),hi=(int)(w*(center+2)/13.0);HealthTab40.fill(g,x+lo,stripY+1,x+hi,stripY+15,0xff70894d);
   int cursor=SplintRules67.cursor((System.nanoTime()-game.origin)/1e9);int px=x+(int)(w*(cursor+.5)/13.0);HealthTab40.fill(g,px-1,stripY-2,px+2,stripY+18,0xfff4e9c1);y+=28;
   y=HealthTab40.wrap(screen,g,HealthTab40.literal("Pulsa ESPACIO o haz clic en la barra cuando el indicador esté en verde."),x,y,w,0xffbdc6b1)+7;
   if(game.failed)y=HealthTab40.wrap(screen,g,HealthTab40.literal("Fallaste. Repite desde el paso 1."),x,y,w,0xffffa878)+4;
   HealthTab40.wrap(screen,g,HealthTab40.literal("No se gasta la férula hasta completar los 3 pasos."),x,y,w,0xffaab49d);
  }
  HealthTab40.panel(g,b[0],footer,b[2],18,0xff555b4e,0xff272d26);text(screen,g,game.done||game.invalid?"Volver a Salud":"Cancelar intento",b[0]+5,footer+5,0xffd3d9bf);
 }
 static void compact(Object screen,Object g,int[] b,Game game,int footer){
  int x=b[0]+8,w=b[2]-16;String title=game.done?"Férula lista":game.invalid?"No disponible":game.waiting?"Esperando…":(game.failed?"Repite 1/3":"Paso "+(game.step+1)+"/3");text(screen,g,title,x,b[1]+7,0xffe0df8b);
  if(!game.done&&!game.invalid){int y=b[1]+27,h=Math.min(12,b[3]-29),center=SplintRules67.center(game.step);game.stripY=y;HealthTab40.fill(g,x,y,x+w,y+h,0xff111711);HealthTab40.fill(g,x+(int)(w*(center-1)/13.0),y,x+(int)(w*(center+2)/13.0),y+h,0xff70894d);int bin=SplintRules67.cursor((System.nanoTime()-game.origin)/1e9),px=x+(int)(w*(bin+.5)/13.0);HealthTab40.fill(g,px-1,y,px+1,y+h,0xfff4e9c1);if(b[3]>70)HealthTab40.wrap(screen,g,HealthTab40.literal("ESPACIO: fijar en verde"),x,b[1]+48,w,0xffbdc6b1);}
  HealthTab40.panel(g,b[0],footer,b[2],18,0xff555b4e,0xff272d26);text(screen,g,game.done||game.invalid?"Volver":"Cancelar",b[0]+5,footer+5,0xffd3d9bf);
 }
 static void press(Object screen,Game game){if(game.waiting||game.done||game.invalid)return;game.waiting=true;int bin=SplintRules67.cursor((System.nanoTime()-game.origin)/1e9);SplintNet67.send(bin+3);}
 public static boolean click(Object screen,double x,double y,int button){if(!HealthTab40.active(screen)||R.get(screen,"layout")==null)return false;int[]b=box(screen);Object l=R.get(screen,"layout");int footer=n(l,"top")+n(l,"height")-24;Game game=GAMES.get(screen);
  if(button==0&&x>=b[0]&&x<b[0]+b[2]&&y>=footer&&y<footer+18){if(game!=null)close(screen);else care();return true;}
  if(game==null)return false;
  if(button==0&&x>=b[0]+8&&x<b[0]+b[2]-8&&y>=game.stripY-2&&y<game.stripY+18)press(screen,game);
  return true;
 }
 public static boolean key(Object screen,int key){Game game=GAMES.get(screen);if(game==null)return false;if(key==256)close(screen);else if(key==32)press(screen,game);return true;}
 public static void close(Object screen){if(GAMES.remove(screen)!=null)SplintNet67.send(0);}
 public static void ack(int code){Object screen=R.get(mc(),"screen");Game g=GAMES.get(screen);if(g==null)return;
  if(code==1){g.started=true;g.waiting=false;g.step=0;g.origin=System.nanoTime();return;}
  if(code==7){g.invalid=true;g.waiting=false;return;}
  if(!g.started||!g.waiting)return;
  g.waiting=false;if(code==3||code==4){g.step=code-2;g.failed=false;g.origin=System.nanoTime();}else if(code==6){g.step=0;g.failed=true;g.origin=System.nanoTime();}else if(code==5){g.done=true;}
 }
 static final class Game {final boolean left;int step,stripY;long origin=System.nanoTime();boolean started,waiting=true,done,failed,invalid;Game(boolean l){left=l;}}
}
