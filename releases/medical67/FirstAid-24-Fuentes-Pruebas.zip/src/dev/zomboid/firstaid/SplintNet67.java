package dev.zomboid.firstaid;
import java.lang.reflect.*;
public final class SplintNet67 {
 static Object c(Object o,String m,Object... a){return R.call(o,m,a);}
 static Object packet(int code){return R.make("dev.zomboid.firstaid.SplintPacket67",R.type("ichttt.mods.firstaid.api.enums.EnumPlayerPart").getEnumConstants()[code&7],R.get(R.type("net.minecraft.world.InteractionHand"),code<8?"MAIN_HAND":"OFF_HAND"));}
 public static int code(Object p){return ((Enum<?>)c(p,"clinicalPart")).ordinal()+(String.valueOf(c(p,"clinicalHand")).equals("MAIN_HAND")?0:8);}
 static Object empty(){return Array.newInstance(R.type("net.minecraft.network.protocol.common.custom.CustomPacketPayload"),0);}
 public static void send(int code){c(R.type("net.neoforged.neoforge.network.PacketDistributor"),"sendToServer",packet(code),empty());}
 public static void reply(Object player,int code){c(R.type("net.neoforged.neoforge.network.PacketDistributor"),"sendToPlayer",player,packet(code),empty());}
 public static void register(Object event){
  Object registrar=c(event,"registrar","1");Class<?> handler=R.type("net.neoforged.neoforge.network.handling.IPayloadHandler");
  Object proxy=Proxy.newProxyInstance(handler.getClassLoader(),new Class<?>[]{handler},(o,m,args)->{if(m.getName().equals("handle")){Object message=args[0],ctx=args[1];c(ctx,"enqueueWork",(Runnable)()->{Object p=c(ctx,"player");if(R.type("net.minecraft.server.level.ServerPlayer").isInstance(p))SplintServer67.message(p,code(message));else c(R.type("dev.zomboid.firstaid.Unified67"),"ack",code(message));});return null;}if(m.getName().equals("toString"))return "FirstAid splint minigame handler";if(m.getName().equals("hashCode"))return System.identityHashCode(o);if(m.getName().equals("equals"))return o==args[0];return null;});
  Class<?> packet=R.type("dev.zomboid.firstaid.SplintPacket67");c(registrar,"playBidirectional",R.get(packet,"TYPE"),R.get(packet,"STREAM_CODEC"),proxy);
 }
}
