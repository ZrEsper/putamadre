package dev.zomboid.firstaid;
/** Shared 13-position timing strip. Failure resets all three checkpoints. */
public final class SplintRules67 {
 public int step,attempts;public boolean complete;
 public static int center(int step){return new int[]{3,8,5}[Math.max(0,Math.min(2,step))];}
 public static boolean hit(int step,int bin){return bin>=0&&bin<=12&&Math.abs(bin-center(step))<=1;}
 public int accept(int bin){if(complete)return 7;if(!hit(step,bin)){step=0;attempts++;return 6;}step++;if(step==3){complete=true;return 5;}return step+2;}
 public static int cursor(double seconds){double p=((seconds%3.2)+3.2)%3.2/1.6;return Math.min(12,(int)((p<=1?p:2-p)*13));}
}
