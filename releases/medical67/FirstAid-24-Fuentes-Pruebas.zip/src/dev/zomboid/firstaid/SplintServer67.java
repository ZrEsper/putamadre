package dev.zomboid.firstaid;
import java.util.*;
public final class SplintServer67 {
 static final Map<Object,Session> SESSIONS=new WeakHashMap<>();
 static final String F="ichttt.mods.firstaid.fracture.Fractures";
 static Object c(Object o,String m,Object...a){return R.call(o,m,a);}
 static boolean yes(Object o){return Boolean.TRUE.equals(o);}
 static boolean splint(Object stack){return !yes(c(stack,"isEmpty"))&&R.type("ichttt.mods.firstaid.fracture.SplintItem").isInstance(c(stack,"getItem"));}
 static boolean available(Object player){Object model=c(R.type("ichttt.mods.firstaid.common.util.CommonUtils"),"getDamageModel",player);return yes(c(player,"isAlive"))&&!yes(c(player,"isSpectator"))&&model!=null&&((Number)c(model,"getUnconsciousTicks")).intValue()==0;}
 public static void message(Object player,int code){
  if(code==0){SESSIONS.remove(player);return;}
  if(code==1||code==2){
   SESSIONS.remove(player);boolean left=code==1;
   if(!available(player)||!yes(c(R.type(F),"isBroken",player,left))){SplintNet67.reply(player,7);return;}
   for(String name:new String[]{"MAIN_HAND","OFF_HAND"}){Object hand=R.get(R.type("net.minecraft.world.InteractionHand"),name),stack=c(player,"getItemInHand",hand);if(splint(stack)){SESSIONS.put(player,new Session(hand,stack,left,System.nanoTime()+60_000_000_000L));SplintNet67.reply(player,1);return;}}
   SplintNet67.reply(player,7);return;
  }
  Session s=SESSIONS.get(player);
  if(code<3||code>15||s==null||System.nanoTime()>s.deadline||!available(player)||c(player,"getItemInHand",s.hand)!=s.stack||!splint(s.stack)||!yes(c(R.type(F),"isBroken",player,s.left))){SESSIONS.remove(player);SplintNet67.reply(player,7);return;}
  int result=s.rules.accept(code-3);
  if(result==5){
   // Retire before mutating: duplicate completion packets cannot consume/apply twice.
   SESSIONS.remove(player);
   Object effect=R.make("net.minecraft.world.effect.MobEffectInstance",c(R.type(F),"splint",s.left),2400,0,false,false,true);
   c(player,"removeEffect",c(R.type(F),"fracture",s.left));
   c(player,"addEffect",effect);
   if(!yes(c(player,"isCreative")))c(s.stack,"shrink",1);
   c(c(player,"getInventory"),"setChanged");c(R.get(player,"containerMenu"),"broadcastChanges");
   c(R.type(F),"playSound",player,"item.armor.equip_leather",1f,1f);
   c(R.type("ichttt.mods.firstaid.common.util.CommonUtils"),"syncDamageModel",player);
  }
  SplintNet67.reply(player,result);
 }
 static final class Session {final Object hand,stack;final boolean left;final long deadline;final SplintRules67 rules=new SplintRules67();Session(Object h,Object s,boolean l,long d){hand=h;stack=s;left=l;deadline=d;}}
 public static Object direct(Object level,Object player,Object hand){
  Object stack=c(player,"getItemInHand",hand);
  if(!yes(c(R.type(F),"needsSplint",player)))return c(R.type("net.minecraft.world.InteractionResultHolder"),"fail",stack);
  if(yes(c(level,"isClientSide")))c(R.type("dev.zomboid.firstaid.Unified67"),"direct");
  return c(R.type("net.minecraft.world.InteractionResultHolder"),"consume",stack);
 }
}
