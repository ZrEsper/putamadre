from pathlib import Path
import subprocess,json
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');mts=r/'output/mts.jar';flash=r/'output/flash.jar';cp=str(flash)+':'+str(mts);out=r/'build/tests';out.mkdir(exist_ok=True);reports=[]
subprocess.run(['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn','-cp',cp,'-d',str(out)]+list(map(str,(r/'tests').rglob('*.java'))),check=True)
for args in [['java','-Xverify:all','-cp',str(out)+':'+cp,'net.flashlight.battery.VehicleTest59'],['python',str(r/'dark_gpu_test.py'),'old'],['python',str(r/'dark_gpu_test.py'),'new']]:
 p=subprocess.run(args,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();reports.append(p.stdout.strip())
(r/'test-results.json').write_text(json.dumps({'minecraft_runtime_tested':False,'results':reports,'limits':'Real Mesa OpenGL draws of production Darkness shaders; production vehicle helper with actual MTS Point3D/TransformationMatrix/JSONLight and simulated world/lamp ray sampler. No complete modpack or visual validation of all cameras.'},indent=2)+'\n')
