from pathlib import Path
import zipfile,json,hashlib,tomllib
r=Path(__file__).parent;out=r/'release';out.mkdir(exist_ok=True);entries=[]
items=[('flash','flashlight-5.1-neoforge-1.21.1-mts-headlight-cones.25.jar',Path('/workspace/light58/release/flashlight-5.1-neoforge-1.21.1-iso-capture-matrices.24.jar')),('mts','Immersive-Vehicles-1.21.1-24.0.0-zomboid-mechanics.17-headlight-cones.jar',next(Path('/workspace/attachments').rglob('Immersive-Vehicles-1.21.1-24.0.0-zomboid-mechanics.16-compact-telemetry.jar'))),('dark','hardcore_true_darkness-6.1-night-visibility.7-light-beam-preserve.jar',next(Path('/workspace/attachments').rglob('*night-visibility.6-soft-ambient.jar'))),('gore','zomboid-zombie-gore-1.0.20-neoforge-1.21.1-remains-cargo.41.jar',Path('/workspace/light58/release/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-linked-local-body.40.jar')),('loot','zombie-remains-loot-1.6.1-neoforge-1.21.1-remains-cargo.26.jar',next(Path('/workspace/attachments').rglob('zombie-remains-loot-1.6.1-neoforge-1.21.1-quietly-search.25.jar'))),('quiet','quietly-1_0_0-cooldown-v20-remains-records.jar',next(Path('/workspace/attachments').rglob('quietly-1_0_0-cooldown-v19-ragdoll-search.jar')))]
for kind,name,base in items:
 with zipfile.ZipFile(r/'output'/f'{kind}.jar')as z:data={n:z.read(n)for n in z.namelist()}
 meta=data['META-INF/neoforge.mods.toml'].decode()
 if kind=='flash':meta=meta.replace('version="5.1.24"','version="5.1.25"')
 if kind=='mts':meta=meta.replace('version = "${file.jarVersion}"','version = "24.0.0.17"')
 if kind=='dark':meta=meta.replace('version="6.1"','version="6.1.7"')
 if kind=='gore':meta=meta.replace('version="1.0.20.58"','version="1.0.20.59"').replace('Gore .40','Gore .41')
 if kind=='loot':
  import re
  meta=re.sub(r'(?m)^version="[^"]+"','version="1.6.1-physical-loot26-medical59"',meta,count=1).replace('[1.0.20.50,1.0.21)','[1.0.20.59,1.0.21)').replace('[1.0.20.51,1.0.21)','[1.0.20.59,1.0.21)')
 if kind=='quiet':
  import re
  meta=re.sub(r'(?m)^version="[^"]+"','version="1.0.0+cooldown-v20"',meta,count=1)
  meta+='\n[[dependencies.quietly]]\nmodId="zomboid_gore"\ntype="required"\nversionRange="[1.0.20.59,1.0.21)"\nordering="AFTER"\nside="BOTH"\n'
 parsed=tomllib.loads(meta);data['META-INF/neoforge.mods.toml']=meta.encode();assert not any(n.startswith(('net/minecraft/','org/joml/','tests/'))for n in data)
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in sorted(data.items()):z.writestr(n,b)
 with zipfile.ZipFile(out/name)as z:assert z.testzip()is None
 entries.append({'file':name,'mod_id':parsed['mods'][0]['modId'],'version':parsed['mods'][0]['version'],'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest(),'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'base_commit':'355244b343a50a972cd24eb498d2d8d936cf1c4e','minecraft':'1.21.1','loader':'NeoForge','minecraft_runtime_tested':False,'artifacts':entries},indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(''.join(e['sha256']+'  mods/'+e['file']+'\n'for e in entries))
for n in ['LEEME.md','test-results.json','profile-summary.json']:(out/n).write_bytes((r/n).read_bytes())
with zipfile.ZipFile(out/'Correccion-59-Luces-Faros-Remains.zip','w',zipfile.ZIP_DEFLATED)as z:
 for e in entries:z.write(out/e['file'],'mods/'+e['file'])
 for n in ['LEEME.md','test-results.json','manifest.json','SHA256SUMS.txt','profile-summary.json']:z.write(out/n,n)
with zipfile.ZipFile(out/'Correccion-59-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','mts-src','gore-src','tests','remains-tests']:
  for p in(r/folder).rglob('*.java'):z.write(p,p.relative_to(r))
 for n in ['Patch59.java','RemainsPatch59.java','ContractsRemains59.java','build.py','build_remains.py','test.py','test_remains.py','package.py','dark59.fsh','dark-old.fsh','dark_gpu_test.py','LEEME.md']:z.write(r/n,n)
 for n in ['test-results.json','manifest.json','profile-summary.json']:z.write(out/n,n)
print('PACKAGED',[(p.name,p.stat().st_size)for p in out.glob('*.zip')])
