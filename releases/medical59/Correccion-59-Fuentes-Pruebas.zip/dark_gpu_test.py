import ctypes as C,os
from pathlib import Path
os.environ['EGL_PLATFORM']='surfaceless';e=C.CDLL('libEGL.so.1');g=C.CDLL('libGL.so.1')
def fn(lib,n,ret,args):
 f=getattr(lib,n);f.restype=ret;f.argtypes=args;return f
P=C.c_void_p;I=C.c_int;U=C.c_uint
D=fn(e,'eglGetDisplay',P,[P])(None);a=I();b=I();assert fn(e,'eglInitialize',U,[P,C.POINTER(I),C.POINTER(I)])(D,C.byref(a),C.byref(b));assert fn(e,'eglBindAPI',U,[U])(0x30A2)
attrs=(I*13)(0x3033,1,0x3040,8,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3038);cfg=P();num=I();assert fn(e,'eglChooseConfig',U,[P,C.POINTER(I),C.POINTER(P),I,C.POINTER(I)])(D,attrs,C.byref(cfg),1,C.byref(num)) and num.value
ctx=fn(e,'eglCreateContext',P,[P,P,P,C.POINTER(I)])(D,cfg,None,(I*1)(0x3038));surf=fn(e,'eglCreatePbufferSurface',P,[P,P,C.POINTER(I)])(D,cfg,(I*5)(0x3057,1,0x3056,1,0x3038));assert fn(e,'eglMakeCurrent',U,[P,P,P,P])(D,surf,surf,ctx)
getstr=fn(g,'glGetString',C.c_char_p,[U]);print('OFFSCREEN_RENDERER',getstr(0x1F01).decode())
create=fn(g,'glCreateShader',U,[U]);source=fn(g,'glShaderSource',None,[U,I,C.POINTER(C.c_char_p),C.POINTER(I)]);compile=fn(g,'glCompileShader',None,[U]);get=fn(g,'glGetShaderiv',None,[U,U,C.POINTER(I)]);log=fn(g,'glGetShaderInfoLog',None,[U,I,C.POINTER(I),C.c_char_p])
r=Path(__file__).parent
shaders=[]
for kind,text in [(0x8B31,'#version 150\nout vec2 texCoord;void main(){vec2 p[3]=vec2[3](vec2(-1,-1),vec2(3,-1),vec2(-1,3));gl_Position=vec4(p[gl_VertexID],0,1);texCoord=p[gl_VertexID]*.5+.5;}'),(0x8B30,(r/('dark-old.fsh' if __import__('sys').argv[-1]=='old' else 'dark59.fsh')).read_text())]:
 shader=create(kind);v=C.c_char_p(text.encode());source(shader,1,C.byref(v),None);compile(shader);ok=I();get(shader,0x8B81,C.byref(ok));buf=C.create_string_buffer(8192);log(shader,8192,None,buf);assert ok.value,buf.value;shaders.append(shader)
program=fn(g,'glCreateProgram',U,[])();attach=fn(g,'glAttachShader',None,[U,U]);[attach(program,s) for s in shaders];fn(g,'glLinkProgram',None,[U])(program);ok=I();fn(g,'glGetProgramiv',None,[U,U,C.POINTER(I)])(program,0x8B82,C.byref(ok));assert ok.value;print('DARKNESS_GLSL150_COMPILE_AND_LINK=PASS')

W=4;H=1
texgen=fn(g,'glGenTextures',None,[I,C.POINTER(U)]);bind=fn(g,'glBindTexture',None,[U,U]);teximage=fn(g,'glTexImage2D',None,[U,I,I,I,I,I,U,U,P]);param=fn(g,'glTexParameteri',None,[U,U,I]);active=fn(g,'glActiveTexture',None,[U])
def texture(unit,internal,values):
 n=U();texgen(1,C.byref(n));active(0x84C0+unit);bind(0x0DE1,n);param(0x0DE1,0x2801,0x2600);param(0x0DE1,0x2800,0x2600);teximage(0x0DE1,0,internal,W,H,0,0x1908,0x1406,values);return n
rgba=(C.c_float*16)(.08,.075,.07,250/255,.08,.075,.07,1,.08,.075,.07,251/255,.02,.025,.03,250/255)
texture(0,0x8058,rgba);out=texture(1,0x8814,None);fbo=U();fn(g,'glGenFramebuffers',None,[I,C.POINTER(U)])(1,C.byref(fbo));fn(g,'glBindFramebuffer',None,[U,U])(0x8D40,fbo);fn(g,'glFramebufferTexture2D',None,[U,U,U,U,I])(0x8D40,0x8CE0,0x0DE1,out,0);assert fn(g,'glCheckFramebufferStatus',U,[U])(0x8D40)==0x8CD5
fn(g,'glUseProgram',None,[U])(program);loc=fn(g,'glGetUniformLocation',I,[U,C.c_char_p]);fn(g,'glUniform1i',None,[I,I])(loc(program,b'DiffuseSampler'),0)
for n,v in [('DarknessFloor',.1),('KeepStart',.1),('KeepEnd',.3),('DarknessStrength',1),('DaylightPreserve',0)]:fn(g,'glUniform1f',None,[I,C.c_float])(loc(program,n.encode()),v)
vao=U();fn(g,'glGenVertexArrays',None,[I,C.POINTER(U)])(1,C.byref(vao));fn(g,'glBindVertexArray',None,[U])(vao);fn(g,'glViewport',None,[I,I,I,I])(0,0,W,H);fn(g,'glDrawArrays',None,[U,I,I])(4,0,3)
pixels=(C.c_float*16)();fn(g,'glReadPixels',None,[I,I,I,I,U,U,P])(0,0,W,H,0x1908,0x1406,pixels);values=[round(pixels[i*4],6) for i in range(4)];print('BEAM_AMBIENT_LASER_WEAK_BEAM_RED=',values)
if __import__('sys').argv[-1]=='old':assert values[0]<.025;print('OLD_DARKNESS_CRUSHES_STAMPED_FLASHLIGHT_BEAM=REPRODUCED')
else:assert abs(values[0]-20/255)<.001 and values[1]<.025 and abs(values[2]-20/255)<.001 and values[3]>.018;print('NEW_FLASHLIGHT_PRESERVED_AMBIENT_DARK_LASER_PRESERVED=PASS')
assert fn(g,'glGetError',U,[])()==0
