package net.flashlight.battery;public class Steady52{static void scalar(int p,String n,float v){G6.scalar(p,n,v);if(n.startsWith("Range["))G6.scalar(p,"Gain["+n.charAt(6)+"]",0);}}
