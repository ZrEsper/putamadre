from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');f=Path('/workspace/light58/release/flashlight-5.1-neoforge-1.21.1-iso-capture-matrices.24.jar');mts=next(Path('/workspace/attachments').rglob('Immersive-Vehicles-1.21.1-24.0.0-zomboid-mechanics.16-compact-telemetry.jar'));dark=next(Path('/workspace/attachments').rglob('*night-visibility.6-soft-ambient.jar'));e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis'])
for p in ['build/flash','build/mts','build/tools','output']:(r/p).mkdir(parents=True,exist_ok=True)
for src,cp,out in [('src',f,'flash'),('mts-src',mts,'mts')]:subprocess.run(e+['-cp',str(cp),'-d',str(r/'build'/out)]+list(map(str,(r/src).rglob('*.java'))),check=True)
subprocess.run(e+['-cp',asm,'-d',str(r/'build/tools'),str(r/'Patch59.java')],check=True);subprocess.run(['java','-cp',str(r/'build/tools')+':'+asm,'Patch59',str(f),str(r/'build/flash'),str(r/'output/flash.jar'),str(mts),str(r/'build/mts'),str(r/'output/mts.jar'),str(dark),str(r/'dark59.fsh'),str(r/'output/dark.jar')],check=True)
