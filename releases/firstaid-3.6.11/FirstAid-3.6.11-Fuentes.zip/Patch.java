import java.nio.file.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
public class Patch implements Opcodes {
 static final String H="dev/zomboid/firstaid/HealthTab40", G="Lnet/minecraft/client/gui/GuiGraphics;";
 public static void main(String[] args)throws Exception{
  Path path=Path.of(args[0]);ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(path)).accept(c,0);int count=0;
  for(MethodNode m:c.methods){InsnList x=new InsnList();String name=m.name;if(!java.util.Set.of("render","mouseClicked","mouseScrolled","keyPressed").contains(name))continue;
   LabelNode skip=new LabelNode();x.add(new VarInsnNode(ALOAD,0));x.add(new MethodInsnNode(INVOKESTATIC,H,"active","(Ljava/lang/Object;)Z",false));x.add(new JumpInsnNode(IFEQ,skip));x.add(new VarInsnNode(ALOAD,0));
   switch(name){case "render" -> {x.add(new VarInsnNode(ALOAD,1));x.add(new VarInsnNode(ILOAD,2));x.add(new VarInsnNode(ILOAD,3));x.add(new VarInsnNode(FLOAD,4));x.add(new MethodInsnNode(INVOKESTATIC,H,"render","(Ljava/lang/Object;Ljava/lang/Object;IIF)V",false));x.add(new InsnNode(RETURN));}
    case "mouseClicked" -> {x.add(new VarInsnNode(DLOAD,1));x.add(new VarInsnNode(DLOAD,3));x.add(new VarInsnNode(ILOAD,5));x.add(new MethodInsnNode(INVOKESTATIC,H,"click","(Ljava/lang/Object;DDI)Z",false));x.add(new InsnNode(IRETURN));}
    case "mouseScrolled" -> {x.add(new VarInsnNode(DLOAD,1));x.add(new VarInsnNode(DLOAD,3));x.add(new VarInsnNode(DLOAD,7));x.add(new MethodInsnNode(INVOKESTATIC,H,"scroll","(Ljava/lang/Object;DDD)Z",false));x.add(new InsnNode(IRETURN));}
    case "keyPressed" -> {x.add(new VarInsnNode(ILOAD,1));x.add(new MethodInsnNode(INVOKESTATIC,H,"escape","(Ljava/lang/Object;I)Z",false));x.add(new JumpInsnNode(IFEQ,skip));x.add(new InsnNode(ICONST_1));x.add(new InsnNode(IRETURN));}
   }x.add(skip);x.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(x);count++;
  }if(count!=4)throw new IllegalStateException("Expected 4 hooks, got "+count);
  MethodNode widgets=new MethodNode(ACC_PUBLIC,"medical40Widgets","("+G+"IIF)V",null,null);widgets.instructions.add(new VarInsnNode(ALOAD,0));widgets.instructions.add(new VarInsnNode(ALOAD,1));widgets.instructions.add(new VarInsnNode(ILOAD,2));widgets.instructions.add(new VarInsnNode(ILOAD,3));widgets.instructions.add(new VarInsnNode(FLOAD,4));widgets.instructions.add(new MethodInsnNode(INVOKESPECIAL,c.superName,"render",widgets.desc,false));widgets.instructions.add(new InsnNode(RETURN));c.methods.add(widgets);
  MethodNode click=new MethodNode(ACC_PUBLIC,"medical40WidgetsClick","(DDI)Z",null,null);click.instructions.add(new VarInsnNode(ALOAD,0));click.instructions.add(new VarInsnNode(DLOAD,1));click.instructions.add(new VarInsnNode(DLOAD,3));click.instructions.add(new VarInsnNode(ILOAD,5));click.instructions.add(new MethodInsnNode(INVOKESPECIAL,c.superName,"mouseClicked",click.desc,false));click.instructions.add(new InsnNode(IRETURN));c.methods.add(click);
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.write(path,w.toByteArray());System.out.println("4 tab-only hooks + 2 widget bridges");
 }
}
