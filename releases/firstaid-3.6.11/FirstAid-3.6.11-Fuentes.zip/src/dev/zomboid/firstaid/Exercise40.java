package dev.zomboid.firstaid;
import java.lang.reflect.Proxy;
import java.util.*;
import java.util.function.Predicate;
/** Server-authoritative timed training. XP uses Survivor Creator; energy uses eZWeight. */
public final class Exercise40 {
 static final String SKILLS="dev.survivorcreator.skills.Skills", ENERGY="com.armilp.ezweight.stamina.StaminaCommon";
 static final Map<Object,Session> sessions=new WeakHashMap<>();
 static final Map<Object,Integer> cooldowns=new WeakHashMap<>();
 static final class Session {String kind;int start,last;double x,y,z,health;Session(String k,int t,Object p,Object model){kind=k;start=t;last=t-1;x=num(c(p,"getX"));y=num(c(p,"getY"));z=num(c(p,"getZ"));health=health(model);}}
 static Object c(Object o,String m,Object...a){return R.call(o,m,a);}static Object stat(String cls,String m,Object...a){return c(R.type(cls),m,a);}static boolean yes(Object o){return Boolean.TRUE.equals(o);}static double num(Object o){return ((Number)o).doubleValue();}
 static void say(Object p,String k,Object...a){c(p,"displayClientMessage",stat("net.minecraft.network.chat.Component","translatable","firstaid.medical.exercise."+k,a),true);}
 public static void register(Object dispatcher){Object root=stat("net.minecraft.commands.Commands","literal","firstaidexercise");Predicate<Object> players=s->R.type("net.minecraft.server.level.ServerPlayer").isInstance(c(s,"getEntity"));c(root,"requires",players);
  for(String action:new String[]{"pushups","squats","stop"}){Object node=stat("net.minecraft.commands.Commands","literal",action);Class<?> command=R.type("com.mojang.brigadier.Command");Object handler=Proxy.newProxyInstance(command.getClassLoader(),new Class<?>[]{command},(proxy,method,args)->{if(method.getName().equals("run")){Object player=c(c(args[0],"getSource"),"getPlayerOrException");return start(player,action);}if(method.getName().equals("toString"))return "FirstAidExercise:"+action;if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);if(method.getName().equals("equals"))return proxy==args[0];return null;});c(node,"executes",handler);c(root,"then",node);}c(dispatcher,"register",root);
 }
 static Object model(Object player){return stat("ichttt.mods.firstaid.common.util.CommonUtils","getDamageModel",player);}
 static double health(Object model){double total=0;for(Object part:(Object[])R.type("ichttt.mods.firstaid.api.enums.EnumPlayerPart").getEnumConstants())total+=num(R.get(c(model,"getFromEnum",part),"currentHealth"));return total;}
 static boolean eligible(Object p,Object m,String kind){if(m==null||!yes(c(p,"isAlive"))||yes(c(p,"isCreative"))||yes(c(p,"isSpectator"))||yes(c(p,"isPassenger"))||!yes(c(p,"onGround"))||yes(c(p,"isUsingItem"))||num(c(m,"getUnconsciousTicks"))>0)return false;
  Object state=stat("ichttt.mods.firstaid.survival.ClinicalData","state",m);if(num(R.get(state,"dressingPart"))>=0||num(R.get(state,"extractionPart"))>=0)return false;
  String[] names=kind.equals("pushups")?new String[]{"HEAD","BODY","LEFT_ARM","RIGHT_ARM"}:new String[]{"HEAD","BODY","LEFT_LEG","RIGHT_LEG","LEFT_FOOT","RIGHT_FOOT"};Object[] wounds=(Object[])R.get(state,"wounds");
  for(String name:names){Object id=R.get(R.type("ichttt.mods.firstaid.api.enums.EnumPlayerPart"),name),part=c(m,"getFromEnum",id);if(num(R.get(part,"currentHealth"))<num(c(part,"getMaxHealth"))*.9||yes(c(wounds[((Enum<?>)id).ordinal()],"active")))return false;}
  if(yes(stat("ichttt.mods.firstaid.fracture.Fractures","isBroken",p,true))||yes(stat("ichttt.mods.firstaid.fracture.Fractures","isBroken",p,false)))return false;
  return num(c(c(p,"getFoodData"),"getFoodLevel"))>=6;
 }
 static int start(Object p,String action){if(action.equals("stop")){sessions.remove(p);say(p,"stopped");return 1;}int t=((Number)R.get(p,"tickCount")).intValue();if(sessions.containsKey(p)){say(p,"already");return 0;}if(t<cooldowns.getOrDefault(p,0)){say(p,"rest");return 0;}
  Object m=model(p);if(!eligible(p,m,action)){say(p,"unfit");return 0;}
  try{if(stat(SKILLS,"get",action.equals("pushups")?"strength":"fitness")==null||!yes(stat(ENERGY,"canSpend",p,12d))){say(p,"no_energy");return 0;}}catch(RuntimeException|LinkageError e){say(p,"dependencies");return 0;}
  sessions.put(p,new Session(action,t,p,m));say(p,"started");return 1;
 }
 public static boolean moved(double x,double y,double z,double ox,double oy,double oz){return (x-ox)*(x-ox)+(y-oy)*(y-oy)+(z-oz)*(z-oz)>.0625;}
 public static boolean due(int elapsed){return elapsed>0&&elapsed%20==0;}
 public static void tick(Object m,Object p){if(!R.type("net.minecraft.server.level.ServerPlayer").isInstance(p))return;Session s=sessions.get(p);if(s==null)return;int t=((Number)R.get(p,"tickCount")).intValue();if(s.last==t)return;s.last=t;
  if(!eligible(p,m,s.kind)||moved(num(c(p,"getX")),num(c(p,"getY")),num(c(p,"getZ")),s.x,s.y,s.z)||health(m)<s.health-.001||num(R.get(p,"hurtTime"))>0){sessions.remove(p);say(p,"stopped");return;}
  int elapsed=t-s.start;if(!due(elapsed))return;
  if(!yes(stat(ENERGY,"consume",p,12d))){sessions.remove(p);say(p,"no_energy");return;}
  c(p,"causeFoodExhaustion",.05f);
  if(elapsed>=600){sessions.remove(p);cooldowns.put(p,t+200);Object skill=stat(SKILLS,"get",s.kind.equals("pushups")?"strength":"fitness");stat(SKILLS,"addXp",p,skill,6d);say(p,"completed",6);}
  else say(p,"progress",elapsed/20,30);
 }
}
