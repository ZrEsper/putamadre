package dev.zomboid.firstaid;
import net.minecraft.server.level.ServerPlayer;
import java.util.*;
public class ExerciseTest {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
  ServerPlayer p=new ServerPlayer();check(Exercise40.start(p,"pushups")==1,"start");check(Exercise40.start(p,"squats")==0,"prevent duplicate");
  for(int t=1;t<=600;t++){p.tickCount=t;Exercise40.tick(p.model,p);Exercise40.tick(p.model,p);}
  check(p.xp==6&&p.stamina==640,"one reward; no duplicate energy costs");check(!Exercise40.sessions.containsKey(p),"ended");check(Exercise40.start(p,"pushups")==0,"rest enforced");p.tickCount=801;check(Exercise40.start(p,"squats")==1,"rest ended");p.x=1;p.tickCount++;Exercise40.tick(p.model,p);check(p.xp==6&&!Exercise40.sessions.containsKey(p),"movement cancels without XP");
  ServerPlayer q=new ServerPlayer();q.creative=true;check(Exercise40.start(q,"pushups")==0,"creative no training");q.creative=false;q.model.parts[2].currentHealth=5;check(Exercise40.start(q,"pushups")==0,"injured arm prevents pushups");check(Exercise40.start(q,"squats")==1,"arm injury does not block squats");q.stamina=0;q.tickCount=20;Exercise40.tick(q.model,q);check(q.xp==0&&!Exercise40.sessions.containsKey(q),"out of stamina cancels");
  ServerPlayer r=new ServerPlayer();Exercise40.start(r,"pushups");r.hurtTime=2;r.tickCount=1;Exercise40.tick(r.model,r);check(!Exercise40.sessions.containsKey(r)&&r.xp==0,"damage cancellation");
  var healthy=new MedicalView40.Part(null,null,null,10,10,false,false,false,List.of());var injured=new MedicalView40.Part(null,null,null,8,10,false,false,false,List.of("health_loss"));var healedDressing=new MedicalView40.Part(null,null,null,10,10,false,false,false,List.of("bandaged"));check(!MedicalView40.affected(healthy)&&!MedicalView40.affected(healedDressing)&&MedicalView40.affected(injured),"injured-only list");check(MedicalView40.firstAffected(new MedicalView40.Snapshot(null,null,List.of(healthy,injured),18,20,0))==1,"auto-select injured part");
  MedicalHud40.geometry();for(int i=0;i<8;i++){check(!MedicalHud40.edges[i].isEmpty(),"HUD silhouette part");for(var box:MedicalHud40.fills[i])check(box.x()>=0&&box.y()>=0&&box.x()+box.w()<=37&&box.y()+box.h()<=73,"HUD bounds");}
  System.out.println("PASS: full exercise session, cost, XP, duplicate ticks, cooldown, injury/movement/damage/energy cancellation, affected-only list, HUD geometry");
 }
}
