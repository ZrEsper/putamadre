import java.nio.file.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
public class ExtraPatch implements Opcodes {
 public static void main(String[]args)throws Exception{Path p=Path.of(args[0]);ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(c,0);int changed=0;
  for(MethodNode m:c.methods){InsnList x=new InsnList();
   if(c.name.endsWith("/TreatmentV33")&&m.name.equals("clientTick")){x.add(new MethodInsnNode(INVOKESTATIC,"dev/zomboid/firstaid/MedicalActions40","tick","()V",false));m.instructions.insert(x);changed++;}
   if(c.name.endsWith("/DebugDamageCommand")&&m.name.equals("register")){x.add(new VarInsnNode(ALOAD,0));x.add(new MethodInsnNode(INVOKESTATIC,"dev/zomboid/firstaid/Exercise40","register","(Ljava/lang/Object;)V",false));m.instructions.insert(x);changed++;}
   if(c.name.endsWith("/ClinicalHooks")&&m.name.equals("tick")){x.add(new VarInsnNode(ALOAD,0));x.add(new VarInsnNode(ALOAD,1));x.add(new MethodInsnNode(INVOKESTATIC,"dev/zomboid/firstaid/Exercise40","tick","(Ljava/lang/Object;Ljava/lang/Object;)V",false));m.instructions.insert(x);changed++;}
   if(c.name.endsWith("/PlayerModelRenderer")&&m.name.equals("renderPlayerHealth")){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.visibleLocalVariableAnnotations=null;m.invisibleLocalVariableAnnotations=null;x.add(new VarInsnNode(ALOAD,2));x.add(new VarInsnNode(ALOAD,4));x.add(new VarInsnNode(FLOAD,6));x.add(new MethodInsnNode(INVOKESTATIC,"dev/zomboid/firstaid/MedicalHud40","render","(Ljava/lang/Object;Ljava/lang/Object;F)V",false));x.add(new InsnNode(RETURN));m.instructions.add(x);changed++;}
  }if(changed!=1)throw new IllegalStateException(c.name+": expected 1 change, got "+changed);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Files.write(p,w.toByteArray());System.out.println(c.name+": OK");
 }
}
