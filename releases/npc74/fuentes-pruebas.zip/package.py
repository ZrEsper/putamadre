from pathlib import Path
import zipfile,json,hashlib
r=Path(__file__).parent;o=r/'release'
(o/'LEEME.txt').write_text('''TaCZ NPCs .38 — Fase 3 y correcciones 2.6.1
Minecraft 1.21.1 / NeoForge. Reemplaza .37 por este JAR tanto en cliente como servidor.
No instales ambas versiones a la vez. Haz copia del mundo y de config/tacznpcs antes.
Conserva las dependencias actuales del modpack. No necesitas un servicio externo de IA.

Incluye memoria/relaciones persistentes, reconocimiento, siete estados calculados,
comandos de memoria, antispam, robo de objetos reales y más tiempo para responder.
Mantiene identidad aleatoria, emboscadas con dos actores reales, autoridad única,
chat celeste, tokens de un uso, opciones caducables y rupturas anteriores.

CONFIGURACIÓN
Archivo: config/tacznpcs/dialogue-phase2.json, schema 3 compatible.
El original exacto .37 se respalda como dialogue-phase2.pre38.bak.json y se actualiza.
Un JSON personalizado conserva sus textos/valores: los campos nuevos ausentes se
completan por defecto. También se admiten los importadores anteriores de schema 1/2.
En un archivo personalizado, pausa_lineas_ticks conserva tu valor anterior; puedes
cambiarlo a 50 para el nuevo ritmo. respuesta_ticks=600 da 30 segundos para elegir,
contados desde el último mensaje del turno. Ambos valores admiten /npcreload.
Se conserva la reacción al silencio y su cierre; cambia el plazo por la petición de
más tiempo para pensar. El cálculo de decisiones conserva su intervalo de 6 ticks.

MENSAJES REPETIDOS
mensajes_cooldown_ticks=200: 10 segundos desde el último intento del mismo mensaje.
Clics continuos mantienen el aviso silenciado. Si cambia el motivo, aparece el aviso
correspondiente, sujeto al mismo enfriamiento por jugador y mensaje. El límite se
comparte entre NPCs. No afecta al texto normal del NPC, las opciones, los tokens ni
las interrupciones. /npcdebug muestra los avisos actualmente bloqueados y su plazo.
Las salidas solicitadas por comandos de diagnóstico se muestran para poder revisarlas.

ROBO
Acércate a un máximo de 10 bloques con un arma TaCZ en la mano y habla con el NPC.
Sostenerla inicia intimidación; apuntar con la mira, disparar, correr o recibir daño
rompe la conversación. Sacarla durante una conversación normal sigue rompiéndola.
No permite negociar mientras hay otra amenaza real, disparos recientes o reintento
bloqueado. El NPC puede negarse: insistir acaba en combate de la IA nativa.
Si cede, transfiere UNA unidad de un objeto que ya tenga en su bolsa. No se crean
objetos, no se duplica botín, no se extrae el arma equipada y no se fuerza la rendición.
Si no tiene nada en la bolsa, lo dice. Inventario del jugador lleno: no ofrece una
transferencia imposible. El umbral de rendición está en el encuentro robo_armado.

OPERADOR
/npcdebug — mirando a un NPC hasta 12 bloques: identidad, voz, encuentro/nodo, bases,
actuales, relación contigo, efectivos, estado, últimos cinco recuerdos y enfriamientos.
/npcmemory ver — todos sus recuerdos sobre ti.
/npcmemory borrar — genera una orden de confirmación válida 10 segundos.
Pega la orden indicada sin cambiar de NPC. Borra SOLO sus recuerdos sobre tu UUID;
no reinicia sus medidores ni borra las relaciones con otros jugadores.
/npcvalidate — validación de JSON y reporte config/tacznpcs/dialogue-validation.txt.
/npcreload — recarga sin borrar identidades o memoria; cierra sesiones y anula tokens.
/npcreply — muestra opciones aún vigentes, sin ampliar su plazo.
/npcexample cansado familiar_enfermo
/npcexample seco familiar_herido_companeros
/npcexample seco robo_armado (para probar el modo armado, inicia llevando el arma).

DATOS Y MIGRACIÓN
El perfil .37 y su semilla no cambian. npc72_events se convierte una sola vez al nuevo
formato por UUID, dejando aviso en el log. Los datos sociales viven en npc74_social
(NBT de entidad): bases, actuales, relaciones, medidores, estado y recuerdos.
La muerte definitiva del NPC borra sus recuerdos. La muerte del jugador no los borra.
No se ejecuta el borrado cuando Downed20 evita una muerte y deja al NPC derribado.
Campos grupo_id/faccion_id quedan nulos. SavedData tacznpcs_social_phase3 reserva
version=1 y mapas vacíos grupos/facciones en cada dimensión del mundo; no ejecuta
comportamientos de grupos, rumores ni facciones. La memoria NO depende de esos mapas.
Los únicos aliados reconocidos para mato_aliado son los compañeros ya vinculados por
la emboscada .37; no se inventan grupos nuevos para los demás NPCs.

Ver ESQUEMA.md para fórmulas, decaimiento, pesos, estados y condiciones editables.
Ver PRUEBAS.md para resultados automáticos y la tabla PENDIENTE en Minecraft real.
''')
(o/'ESQUEMA.md').write_text('''El archivo completo editable está en dialogue-phase2.json; estas son las adiciones.

`config`: `respuesta_ticks` (240–2400, defecto 600), `mensajes_cooldown_ticks`
(20–2400, defecto 200), `robo_distancia` (2–16, defecto 10). Pausa entre mensajes:
`pausa_lineas_ticks`, nuevo defecto 50 (2,5 s). Usa tiempo de juego, no reloj externo.

`social.bases`: perfiles normal/hostil con miedo, desesperacion y hostilidad (0–100).
Se eligen al inicializar el NPC, según su disposición; no dependen de la voz. Cambiar
las bases del JSON afecta a nuevos NPCs. Las fórmulas y umbrales sí afectan a existentes.
El estado actual empieza igual a la base y los efectos lo modifican.

`social.formula`: por cada medidor, constante y coeficientes de fuentes `base`, `actual`
y `relacion`. Es una suma ponderada seguida de redondeo y límite 0–100. No acepta código,
expresiones ni comandos. Fuentes permitidas: base/actual = miedo, desesperacion,
hostilidad; relacion = confianza, hostilidad. Defectos, escritos en el propio JSON:

| Efectivo | Fórmula |
|---|---|
| confianza | relación.confianza |
| miedo | actual.miedo + 0,1 × relación.hostilidad |
| desesperacion | actual.desesperacion |
| hostilidad | 0,25 × actual.hostilidad + 0,75 × relación.hostilidad |

Los efectos confianza/hostilidad modifican la relación personal. Miedo/desesperacion
modifican el actual compartido del NPC. La confianza .37 se importa desde soc_trust_UUID,
limitada a 0–100; sus cambios nativos posteriores se siguen incorporando. Los antiguos
valores personales de hostilidad se importan al crear la relación. Las comparaciones
negativas de confianza de JSON antiguos se aceptan por compatibilidad, pero el valor
nuevo nunca baja de cero.

`social.decaimiento_por_1200_ticks`: miedo=2 y desesperacion=1 por minuto de juego,
hacia su base; hostilidad actual=0,1 y personal=0,2 hacia cero; confianza=0,01 hacia
su valor inicial de relación. Se usan fracciones, conservadas en NBT. Cálculo cada
6 ticks y al consultar/aplicar efectos. Guardado periódico cada 200 ticks; los eventos
y efectos se guardan inmediatamente en NBT. Un chunk descargado recupera el decaimiento
según el tiempo de juego transcurrido, sin forzar su carga. Mundo cerrado: no corre reloj.

`peso_grave=75`, `marca_grave_ticks=168000`, `factor_decaimiento_grave=0.1`:
los recuerdos graves ralentizan al 10 % el decaimiento de confianza/hostilidad personal
por su duración. Las ventanas superpuestas se cuentan una sola vez. Miedo/desesperacion
continúan volviendo a su base normalmente. Los recuerdos importantes se retienen por
peso aunque caduque su protección temporal. `limite_eventos=20` por NPC y UUID: se
elimina primero el menor peso y, en empate, el más antiguo.

Tipos de memoria técnicos (ASCII): `ayudo`, `ofrecio_ayuda`, `mintio_y_descubierto`,
`amenazo`, `ataco`, `mato_aliado`, `dejo_ir`, `ignoro`, `otro`.
Cada registro tiene tipo, texto (hasta 120 caracteres), at (tick) y peso (0–100).
`social.tipos_memoria` define pesos y efectos seguros de hechos externos como un ataque
o intimidación. Los efectos explícitos de una respuesta JSON se aplican una sola vez:
guardar su evento no vuelve a sumar sus medidores. No hay comprobación libre de mentiras
del jugador: el guion local define cuándo se registra mintio_y_descubierto.

`evento_memoria` conserva cadenas antiguas y añade forma explícita:
```json
{"tipo":"ayudo","texto":"Ayudó con medicina.","peso":90}
```
La migración de cadenas usa clasificación conservadora. Descubrir una mentira DEL NPC
no convierte al jugador en mentiroso; un pacto de no atacarse no cuenta como ataque.
Frases antiguas que no se reconocen se conservan con tipo `otro`, sin inventar contexto.

Condición nueva en `requiere` o `condicion`:
```json
{"memoria":{"tipo":["ayudo"],"min_eventos":1,"peso_min":75,
"antiguedad_min_ticks":0,"antiguedad_max_ticks":168000},
"estado_encuentro":["amistoso","neutral"]}
```
Todos los filtros deben cumplirse. Edad mínima/máxima y tipo son opcionales.
`estado` conserva su significado anterior de situación; `estado_encuentro` usa los
siete estados calculados. `social.estados` se evalúa en orden, primera coincidencia:
quebrado, rencoroso, emboscador, desesperado, cauteloso, amistoso, neutral. Cada regla
admite rangos de medidores, memoria y miente; neutral debe ser el respaldo incondicional.
Se recalcula al abrir, aplicar efectos, evaluar condiciones o usar /npcdebug.

`reconocimiento.<voz>`: ayudo, rencor, desconfianza y rechazo_grave. Se usa el recuerdo
significativo más reciente; ayudar requiere peso grave. Son saludos del reencuentro,
no nuevas penalizaciones repetidas cada vez que aparece el jugador. Las agresiones
aplican sus consecuencias al ocurrir. Con hostilidad efectiva >=75 y ataque/muerte de
aliado grave, no se abre conversación: solo amenaza y la IA base queda libre.
El agradecimiento baja el apuntado nativo durante el saludo, sin eliminar agresiones.
No se añade un sistema nuevo de avisos de peligro: se conservan los sensores existentes.

`social.opcion_reconocimiento`: opción y respuestas completas en JSON. Aparece solo
si hay recuerdos, al inicio de un encuentro normal y con un turno posterior disponible.
La respuesta según ayuda usa una condición de memoria. `siguiente:"actual"` se resuelve
al nodo inicial de ese encuentro. Si ya hay cuatro opciones, ocupa el lugar de ofrecer
comida. No se agrega una quinta ni se elimina la retirada. Un guion personalizado con
cuatro opciones sin ofrecer_comida conserva sus opciones; puede dejar un espacio libre
para esta opción. No se agrega durante intimidación.

La identidad, historia privada, validación de variables y revelaciones de .37 siguen
vigentes. No hay servicio externo de IA ni motor de comandos dentro del JSON.
''')
(o/'CAMBIOS.txt').write_text('''Base exacta: .37-random-identities.
Creados:
- Social74: NBT por NPC/UUID, migración, medidores, decaimiento, memoria, estados,
  reconocimiento, ataque y muerte; fallback por NPC si falla.
- WorldSocial74: SavedData reservado, sin lógica de grupos/facciones.
- Config74: defaults opcionales y validación de social/reconocimiento/condiciones.
- Notice74: antispam central por jugador/texto, pausa desde último intento.
- Gate74: rechazos separados, modo armado explícito, robo finito y reconocimiento.
- Ops74: memoria de operador, confirmación con nonce y debug ampliado.
Modificados:
- Chat71 y State: plazo y ritmo configurables, reconocimiento, modo intimidación,
  memoria semántica y opción de recuerdo. Conserva protocolo C71 y sesión existente.
- DialogueRules72: medidores persistentes, condiciones de memoria/estado, eventos
  tipados, selección exacta de un encuentro por ID sin sortear el respaldo genérico.
- DialogueData71: schema 3 extendido, validación estricta y eventos compatibles.
- Data73: defaults nuevos, copia .pre38 y reconocimiento del original .37.
- Diagnostics73, Admin73: validación y diagnóstico extendidos.
Enganches de bytecode sobre clases nativas, sin reemplazar sus ejecutores:
- Authority70: tell/reject delegados, plazo configurable y arma en modo intimidación;
  tick social antes de sus comprobaciones anteriores. Conserva bloqueo de disparo,
  melee, daño, carrera y arbitraje nativo.
- Threat27.hit: registro social de daño aplicado.
- AutoGunOperator.die: memoria definitiva solo después de superar Downed20/Probe y
  ejecutar super.die; no se borra por un simple derribo.
Datos: dialogue-phase2.json completo; copia phase26-original.json para migración.
Metadatos: 2.1.0-tactical.38-persistent-memory.
Assets de modelos/texturas/sonidos idénticos a .37. No añade segundo controlador de IA.
''')
(o/'PRUEBAS.md').write_text('''Resultados automáticos: 160 clases verificadas con ASM BasicVerifier; nueve puntos
exactos de parche en siete categorías. 277 controles de regresión, 15126 de identidad,
emboscadas, privacidad y chat, y 124 de Fase 3/2.6.1. Diez escenarios de configuración en
JVMs separadas. JVM -Xverify:all; Brigadier real; APIs de Minecraft SIMULADAS.

Cubierto: bloqueo/rupturas/tokens; 5000 identidades; dos ayudantes reales en la simulación;
transferencia finita y token repetido; rendición, negativa y bolsa vacía; spam continuo,
pausa y cambio de motivo; 30 s tras última línea; UUIDs independientes; muerte del
jugador; borrado al morir NPC; decaimiento y ventanas graves superpuestas; memoria
limitada por peso; siete estados; reconocimiento/mentira; JSON inválido, recarga y
migración .37 sin duplicación; conservación de identidad; comandos y confirmación segura.

NO se ejecutó Minecraft real, NeoForge, servidor dedicado ni GPU. No se probaron dentro
del modpack el guardado real en disco, carga/descarga de chunks, SavedData real,
sincronización multijugador, ADS de TaCZ, interacción del clic derecho, poses, navegación,
combate de emboscada, shaders o coste de render. Los logs recibidos corresponden a .37.

Tabla para probar en Minecraft real — TODAS LAS FILAS ESTÁN PENDIENTES:

| Caso | Pasos | Qué debe pasar |
|---|---|---|
| Actualizar desde .37 | Copiar mundo; reemplazar JAR en cliente/servidor; entrar | Carga .38 y original JSON respaldado como .pre38; identidades iguales |
| Ayudar y volver | Hablar con cansado; usar /npcexample cansado familiar_enfermo; dar medicina; retirarse y volver | Pierdes una medicina; acuerdo; saludo recuerda la ayuda y baja el apuntado |
| Memoria en opciones | Tras ayudar, iniciar charla normal con ese NPC | Aparece ¿Te acuerdas de mí?; respuesta distinta por ayuda; nunca más de cuatro opciones |
| Traicionar y volver | Atacar al NPC sin matarlo; retirarse hasta superar su reintento; volver | Memoria ataco, menos confianza, más miedo/hostilidad y saludo de rencor |
| Violencia grave | Repetir agresiones sin matarlo; revisar /npcdebug | A hostilidad efectiva >=75 y memoria grave, no hay opciones; solo amenazas |
| Persistencia | /npcdebug y /npcmemory ver; guardar/salir; reiniciar; repetir | Misma identidad, UUID, recuerdos y relación; decaimiento por tiempo de juego |
| Descargar chunk | Alejarse del NPC hasta descargarlo; jugar un rato; volver | Recuerdos conservados; medidores ajustados al tiempo, sin forzar chunks |
| Dos jugadores | A ayuda, B ataca al mismo NPC; ambos usan /npcdebug | Relaciones y hostilidad personal distintas; miedo actual compartido |
| Decaimiento | Amenazar/atacar, anotar valores; dejar pasar minutos; consultar | Miedo/desesperacion vuelven a base; hostilidad baja lento; confianza casi estable |
| Marca grave | Comparar relación con un recuerdo peso >=75 frente a una sin él | Confianza/hostilidad personal decaen a menor velocidad durante su marca |
| Estados | Alterar un umbral de social.estados, /npcreload, /npcdebug | Estado cambia según reglas ordenadas; condiciones estado_encuentro lo usan |
| Ver recuerdos | Mirar al NPC y ejecutar /npcmemory ver | Lista tipo, texto, tick y peso de sus recuerdos sobre tu UUID |
| Borrado seguro | /npcmemory borrar; pegar confirmación antes de 10 s | Solo se borra su memoria sobre ti; medidores y datos de B se conservan |
| Confirmación inválida | Esperar >10 s o mirar a otro NPC antes de confirmar | No borra nada |
| Permisos | Probar /npcmemory sin ser operador | No permite ver/borrar |
| Migrar memoria .37 | Abrir copia de mundo con NPC que ya recuerda eventos | Un aviso de migración por NPC; no duplica eventos tras guardar/reabrir |
| JSON personalizado .37 | Cambiar una frase en schema 3 sin campos nuevos; iniciar .38 | Conserva tu frase y agrega defaults en memoria; no pierde identidades |
| JSON inválido | Poner tipo desconocido, variable prohibida o umbral 999; /npcvalidate | Reporte con archivo/campo; /npcreload conserva último válido y memoria |
| JSON roto al arrancar | Hacerlo en copia de prueba y reiniciar | Usa respaldo incluido, log de error y archivo inválido intacto |
| Spam con arma/ADS | Intentar hablar repetidamente apuntando con la mira | Un aviso por mensaje; clics continuos no lo repiten cada dos segundos |
| Spam sin arma | Insistir tras ruptura o ejecutar /npcreply sin sesión | Un aviso por motivo dentro del plazo; motivo nuevo puede mostrarse |
| Spam con peligro | Intentar hablar con zombi cerca varias veces | Aviso único; no bloquea la defensa del NPC |
| Pausa antispam | Dejar de intentar durante >10 s y volver | Puede mostrar de nuevo el aviso |
| Ritmo | Abrir charla, leer los mensajes y esperar 15 s tras opciones | Sigue habiendo tiempo; pausa de 2,5 s entre líneas; plazo total 30 s |
| Silencio | No elegir durante 30 s desde las opciones | Una reacción al silencio, cierre único y opciones anuladas |
| Robo | Arma sostenida, sin ADS y sin otros peligros; hacer clic en NPC | Opciones de intimidación, sin aviso genérico de arma/peligro |
| Robo finito | Elegir exigir con NPC temeroso que tenga bolsa; repetir token | Una unidad transferida, nada creado y token usado rechazado |
| Resistencia | Exigir a hostil de miedo bajo y luego insistir | Se niega; la segunda amenaza termina en combate |
| Bolsa vacía/lleno | Robar a NPC sin bolsa; luego con inventario del jugador lleno | No aparecen objetos gratuitos ni transferencias imposibles |
| Rupturas | Sacar arma en charla normal; ADS en intimidación; correr/disparar/recibir daño | Termina la charla, anula opciones y libera IA nativa |
| Emboscada anterior | NPC nuevo, cobertura física; /npcexample seco familiar_herido_companeros; acercarse tras advertencia | Dos compañeros reales combaten; no se duplican; resultado traicion |
| Anti-repetición NPC | Volver a elegir una rama ya vista dentro del mismo encuentro | No repite la línea; usa cierre seguro cuando agota texto |
| Morir como jugador | NPC con recuerdos de A; A muere/reaparece | La relación por UUID se conserva |
| Muerte definitiva NPC | Matarlo, sin simple derribo; observar ayudantes vinculados | Borra memoria del muerto; ayudantes testigos guardan mato_aliado |

Limitaciones y decisiones:
- Las seis voces de respaldo siguen siendo mínimas; no se reescribieron sus encuentros.
- No hay grupos, rumores, facciones ni población nueva. Solo campos y SavedData reservados.
- Un recuerdo antiguo ambiguo se conserva como otro; no se puede reconstruir un contexto
  que .37 no guardó. Descubrir mentira del NPC no penaliza al jugador como mentiroso.
- Robo de una unidad de bolsa, no de equipo ni armas equipadas. ADS sigue siendo ruptura.
- Hay 30 s para elegir en lugar de los 12 anteriores, por la petición de más tiempo.
- El estado neutral es el respaldo; las reglas anteriores tienen prioridad en su orden.
- Identidades pueden repetir nombres de bancos finitos; no se regeneran al recargar.
- El reconocimiento no añade voces grabadas ni promesas de IA generativa.
''')
(o/'dialogue-phase2.json').write_bytes((r/'data/dialogue-phase2.json').read_bytes())
with zipfile.ZipFile(o/'fuentes-pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for name in ['Patch74.java','Extract70.java','Extract71.java','Extract73.java','build.py','test.py','config_test.py','make_data.py','package.py']:z.write(r/name,name)
 for folder in ['src','testsrc','data','api']:
  for p in sorted((r/folder).rglob('*')):
   if p.is_file() and p.suffix in ['.java','.json']:z.write(p,p.relative_to(r))
 dep=Path('/workspace/npc71/brigadier-source')
 for p in (dep/'src/main/java').rglob('*.java'):z.write(p,'brigadier-source/'+str(p.relative_to(dep)))
 z.write(dep/'LICENSE','brigadier-source/LICENSE')
 z.writestr('REPRODUCIR.txt','''Java 21, Python 3, ECJ, Gson, ASM/asm-tree/asm-analysis/asm-commons.
Base: TaCZ NPCs .37 exacta. build.py admite NPC_BASE_JAR, NPC_BUILD_TOOLS y NPC_GSON_JAR.
Ejecutar make_data.py, build.py, test.py, config_test.py. test.py conserva rutas de este
entorno: ajustar rutas de Gson, ASM commons, herramientas y fuentes Brigadier si se usa
otra máquina. Brigadier fuente MIT incluido, revisión 9ba4f13c0fe82b07c08c2dc2d8043f075ffd0d98.
api/ contiene SOLO declaraciones de tipos Minecraft para compilar WorldSocial74. NO se
empaquetan en el JAR; producción usa las clases reales de Minecraft. testsrc/ simula las
APIs para comprobaciones JVM. No es un lanzamiento de Minecraft ni una validación NeoForge.
El JAR contiene la implementación de cada función, sin dependencias de clases de prueba.
''')
base=Path('/workspace/npc73/release/tacznpcs-2.1.0-1.21.1-tactical.37-random-identities.jar');jar=next(o.glob('*.jar'));a=zipfile.ZipFile(base);b=zipfile.ZipFile(jar)
assert all(a.read(n)==b.read(n)for n in a.namelist()if n.startswith('assets/'))
assert not any(n.startswith('net/minecraft/')for n in b.namelist())
manifest={'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'minecraft_run':False,'asm_classes':160,'regression_checks':277,'phase26_checks':15126,'phase3_checks':124,'config_cases':10,'changed':[n for n in a.namelist()if n in b.namelist()and a.read(n)!=b.read(n)],'added':sorted(set(b.namelist())-set(a.namelist()))}
(o/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive='NPCs-38-Fase3-Memoria-Antispam-Robo.zip'
(o/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'for p in sorted(o.iterdir())if p.name not in [archive,'SHA256SUMS.txt']))
with zipfile.ZipFile(o/archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(o.iterdir()):
  if p.name!=archive:z.write(p,p.name)
print('JAR SHA256',manifest['jar_sha256']);print('ZIP bytes',(o/archive).stat().st_size)
