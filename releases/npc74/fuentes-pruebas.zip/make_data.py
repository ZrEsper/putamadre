from pathlib import Path
import json
r=Path(__file__).parent;d=json.loads((r/'data/phase26-original.json').read_text())
d['config'].update(pausa_lineas_ticks=50,respuesta_ticks=600,mensajes_cooldown_ticks=200,robo_distancia=10)
d['ui'].update(retry_warning='Dale un momento. Todavía no quiere volver a hablar contigo.',run_warning='Deja de correr si quieres hablar.',danger_warning='Hay otra amenaza cerca. Ahora no puede hablar.',shot_warning='Acabas de disparar. No es momento de negociar.',memory_offer='El jugador ofreció ayuda.',memory_ignored='El jugador no respondió.',memory_attack='El jugador le disparó o lo atacó.',memory_ally_death='El jugador mató a uno de sus compañeros.',memory_threat='El jugador lo amenazó con un arma.',memory_confirm='Esto borra solo los recuerdos de este NPC sobre ti; los medidores se conservan. Confirma en 10 s:',memory_confirm_expired='La confirmación caducó o ya no miras al mismo NPC.',memory_cleared='Recuerdos borrados para este jugador.',memory_empty='No hay recuerdos de este jugador.',cooldown_label='Aviso en enfriamiento:')
weights={'ayudo':(90,10,-15,-10),'ofrecio_ayuda':(30,3,0,-2),'mintio_y_descubierto':(75,-15,5,20),'amenazo':(60,-15,20,15),'ataco':(100,-30,30,30),'mato_aliado':(100,-30,30,30),'dejo_ir':(45,5,-5,-5),'ignoro':(20,-3,0,5),'otro':(10,0,0,0)}
s={'limite_eventos':20,'peso_grave':75,'marca_grave_ticks':168000,'factor_decaimiento_grave':0.1,'hostilidad_sin_dialogo':75,'bases':{'normal':{'miedo':30,'desesperacion':25,'hostilidad':5},'hostil':{'miedo':10,'desesperacion':25,'hostilidad':40}},'decaimiento_por_1200_ticks':{'miedo':2,'desesperacion':1,'hostilidad':0.1,'hostilidad_personal':0.2,'confianza':0.01},'formula':{},'tipos_memoria':{},'estados':[],'robo_sin_objetos':['No llevo nada que puedas quitarme.','Revisa si quieres. Esto ya no vale una pelea.']}
for m in ['confianza','miedo','desesperacion','hostilidad']:
 s['formula'][m]={'constante':0,'relacion' if m=='confianza' else 'actual':{m:1}}
s['formula']['hostilidad']={'constante':0,'actual':{'hostilidad':0.25},'relacion':{'hostilidad':0.75}}
s['formula']['miedo']['relacion']={'hostilidad':0.1}
for k,(weight,trust,fear,hostility) in weights.items():s['tipos_memoria'][k]={'peso':weight,'confianza':trust,'miedo':fear,'hostilidad':hostility}
for name,meters,extra in [('quebrado',{'miedo':{'min':85}},{}),('rencoroso',{'hostilidad':{'min':65}},{}),('emboscador',{'hostilidad':{'min':30}}, {'miente':True}),('desesperado',{'desesperacion':{'min':65}},{}),('cauteloso',{'miedo':{'min':45}},{}),('amistoso',{'confianza':{'min':55},'hostilidad':{'max':25}},{}),('neutral',{}, {})]:s['estados'].append(dict(id=name,medidores=meters,**extra))
d['social']=s
recognition={
'seco':{'ayudo':['Te recuerdo. Me ayudaste cuando hacía falta.','Ya. Podemos hablar.'],'rencor':['Te recuerdo. No por algo bueno.','Mantén la distancia. No estamos en paz.'],'desconfianza':['Tu historia no cuadraba la última vez.','Habla claro. Esta vez voy a escuchar mejor.'],'rechazo_grave':['No te acerques. Sé lo que hiciste.']},
'cansado':{'ayudo':['…Sí, me acuerdo de ti. Fuiste quien me ayudó.','No pensé que volvería a verte. Me alegra que sigas vivo.'],'rencor':['Otra vez tú. Justo lo que me faltaba.','No he olvidado lo que pasó. No te acerques más.'],'desconfianza':['La última vez te creí. Ya viste cómo salió eso.','Podemos hablar, pero esta vez me guardo mis dudas.'],'rechazo_grave':['No. Después de lo que hiciste, ni un paso más.']},
'sarcastico':{'ayudo':['Mira quién volvió. La persona que sí me echó una mano.'],'rencor':['Genial. Volvió la razón por la que ya no confío en nadie.'],'desconfianza':['Volvió el de las historias que nunca terminan de cuadrar.'],'rechazo_grave':['Ni un paso más. Ya tuve suficiente contigo.']},
'religioso':{'ayudo':['Recuerdo tu ayuda. Me alegra verte con vida.'],'rencor':['No he olvidado el daño que hiciste. Mantén la distancia.'],'desconfianza':['La verdad importa. La última vez no la trajiste contigo.'],'rechazo_grave':['Detente. No voy a dejar que vuelvas a hacernos daño.']},
'educado':{'ayudo':['Lo recuerdo. Le agradezco lo que hizo por mí.'],'rencor':['Recuerdo lo ocurrido. Le ruego que mantenga la distancia.'],'desconfianza':['Disculpe, después de la última vez necesito algo más que su palabra.'],'rechazo_grave':['No se acerque. No aceptaré otra agresión.']},
'aterrado':{'ayudo':['E-eres tú. Me ayudaste… gracias.'],'rencor':['¡Tú no! ¡Recuerdo lo que hiciste!'],'desconfianza':['N-no sé si creerte. La otra vez me mentiste.'],'rechazo_grave':['¡Aléjate! ¡No vuelvas a hacerme daño!']},
'veterano':{'ayudo':['Escucha. No olvidé tu ayuda. Podemos bajar la guardia un poco.'],'rencor':['Sé quién eres. Créeme, recuerdo lo que pasó.'],'desconfianza':['La última vez tu palabra no valió mucho. Esta vez necesito hechos.'],'rechazo_grave':['Hasta ahí. No tendrás otra oportunidad de atacarnos.']},
'joven':{'ayudo':['Oye, te conozco. Tú me ayudaste aquella vez.'],'rencor':['¿En serio volviste? No olvidé lo que hiciste.'],'desconfianza':['Oye, no me cuentes otra historia como la última.'],'rechazo_grave':['¡Ni te acerques! ¡No voy a caer otra vez!']}}
d['reconocimiento']=recognition
s['opcion_reconocimiento']={'id':'recordarme','texto':'¿Te acuerdas de mí?','tono':1,'requiere':{'memoria':{'min_eventos':1}},'respuestas':[{'condicion':{'memoria':{'tipo':'ayudo','min_eventos':1}},'lineas_npc':['Sí. No olvidé que me ayudaste.','Podemos seguir hablando con calma.'],'efectos':{},'siguiente':'actual'},{'lineas_npc':['Me acuerdo. No significa que confíe en ti.','Habla claro y mantén la distancia.'],'efectos':{},'siguiente':'actual'}]}
def response(lines,effects,next=None,condition=None):
 o={'lineas_npc':lines,'efectos':effects,'siguiente':next}
 if condition:o['condicion']=condition
 return o
rob={'id':'robo_armado','voz':'*','situacion':'robo_armado','peso':100,'necesidad':'aleatoria','inicio':'advertencia','turnos_max':3,'nodos':[{'id':'advertencia','lineas_npc':['Veo el arma. No hagas ningún movimiento brusco.','Dime qué quieres y terminemos con esto.'],'opciones':[{'id':'exigir','texto':'Dame algo de lo que llevas y te dejo ir.','tono':4,'respuestas':[response(['Está bien. Tómalo y aléjate.','No creas que voy a olvidar esto.'],{'confianza':-20,'hostilidad':20,'evento_memoria':'El jugador le robó bajo amenaza.','resultado':'separacion_pacifica'},condition={'medidores':{'miedo':{'min':50}}}),response(['No voy a darte nada.','Baja eso y vete. Es tu última oportunidad.'],{'hostilidad':25,'confianza':-20},'rechazo')]},{'id':'calmar','texto':'Tranquilo. No voy a robarte. Me retiro.','tono':1,'respuestas':[response(['Entonces aléjate despacio.','No te voy a seguir.'],{'resultado':'separacion_pacifica'})]},{'id':'retirarse','texto':'Me voy. No hagas ninguna tontería.','tono':3,'respuestas':[response(['Sigue caminando.','Que no tenga que repetírtelo.'],{'resultado':'separacion_pacifica'})]}],'reaccion_silencio':{'lineas':['No voy a quedarme aquí para siempre.','La próxima vez habla antes de sacar el arma.'],'efectos':{'resultado':'separacion_pacifica','evento_memoria':'El jugador lo ignoró sosteniendo un arma.'}}},{'id':'rechazo','lineas_npc':['No quiero repetirlo.','Tú eliges cómo termina esto.'],'opciones':[{'id':'insistir','texto':'Te lo advertí. Dame tus cosas.','tono':5,'respuestas':[response(['Se acabó.','No voy a dejar que me robes.'],{'resultado':'ruptura_combate','hostilidad':30})]},{'id':'retirada','texto':'Está bien. Bajo el arma y me voy.','tono':2,'respuestas':[response(['Buena decisión.','Ahora mantén la distancia.'],{'resultado':'separacion_pacifica'})]}],'reaccion_silencio':{'lineas':['Suficiente.','Vete mientras puedas.'],'efectos':{'resultado':'separacion_pacifica'}}}]}
d['encuentros'].append(rob)
def memory_type(text):
 t=text.lower()
 if 'amenaz' in t:return 'amenazo'
 if 'medicin' in t or 'compartió comida' in t or 'compartió una ración' in t:return 'ayudo'
 if 'ignor' in t:return 'ignoro'
 if 'acordaron no atacarse' in t:return 'dejo_ir'
 return 'otro'
def typed_events(obj):
 if isinstance(obj,dict):
  if isinstance(obj.get('evento_memoria'),str):
   text=obj['evento_memoria'];obj['evento_memoria']={'tipo':memory_type(text),'texto':text}
  for v in obj.values():typed_events(v)
 elif isinstance(obj,list):
  for v in obj:typed_events(v)
typed_events(d)
(r/'data/dialogue-phase2.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
