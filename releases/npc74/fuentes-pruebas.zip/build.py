from pathlib import Path
import subprocess,os
r=Path(__file__).parent;t=Path(os.environ.get('NPC_BUILD_TOOLS','/workspace/putamadre/hordes-melee-interiors-patch/build/tools'));base=os.environ.get('NPC_BASE_JAR','/workspace/npc73/release/tacznpcs-2.1.0-1.21.1-tactical.37-random-identities.jar');gson=os.environ.get('NPC_GSON_JAR','/workspace/medical63/gson.jar');asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis']);ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn']
(r/'release').mkdir(exist_ok=True)
subprocess.run(ecj+['-d',str(r/'api-build')]+list(map(str,(r/'api').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',str(r/'api-build')+':'+base+':'+gson,'-d',str(r/'build')]+list(map(str,(r/'src').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'Patch74.java')],check=True)
subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'Patch74',base,str(r/'build'),str(r/'data/dialogue-phase2.json'),str(r/'release/tacznpcs-2.1.0-1.21.1-tactical.38-persistent-memory.jar')],check=True)
