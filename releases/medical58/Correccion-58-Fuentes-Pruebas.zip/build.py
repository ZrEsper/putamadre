from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');flash=r/'flashlight-5.1-neoforge-1.21.1-iso-gpu-blit.23.jar';g=Path('/workspace/opt57/output/gore.jar');e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis'])
for p in ['build/flash','build/gore','build/tools','output']:(r/p).mkdir(parents=True,exist_ok=True)
for folder,jar,out in [('src',flash,'flash'),('gore-src',g,'gore')]:subprocess.run(e+['-cp',str(jar),'-d',str(r/'build'/out)]+list(map(str,(r/folder).rglob('*.java'))),check=True)
subprocess.run(e+['-cp',asm,'-d',str(r/'build/tools'),str(r/'Patch58.java')],check=True);subprocess.run(['java','-cp',str(r/'build/tools')+':'+asm,'Patch58',str(flash),str(r/'build/flash'),str(r/'output/flash.jar'),str(g),str(r/'build/gore'),str(r/'output/gore.jar')],check=True)
