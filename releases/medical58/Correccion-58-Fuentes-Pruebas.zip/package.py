from pathlib import Path
import zipfile,json,hashlib,tomllib
r=Path(__file__).parent;out=r/'release';out.mkdir(exist_ok=True);entries=[]
for kind,name,source in [('flash','flashlight-5.1-neoforge-1.21.1-iso-capture-matrices.24.jar',r/'output/flash.jar'),('gore','zomboid-zombie-gore-1.0.20-neoforge-1.21.1-linked-local-body.40.jar',r/'output/gore.jar'),('rag','ragdollified-1.21.1-1.1.5-view-culling.32.jar',Path('/workspace/opt57/release/ragdollified-1.21.1-1.1.5-view-culling.32.jar'))]:
 if kind=='rag':(out/name).write_bytes(source.read_bytes())
 else:
  with zipfile.ZipFile(source)as z:data={n:z.read(n)for n in z.namelist()}
  meta=data['META-INF/neoforge.mods.toml'].decode()
  if kind=='gore':meta=meta.replace('version="1.0.20.51"','version="1.0.20.58"').replace('[1.1.5-gore20-medical51]','[1.1.5-gore20-perf57]').replace('Gore .38','Gore .40').replace('Gore .35','Gore .40')
  else:meta=meta.replace('version="5.1"','version="5.1.24"')
  data['META-INF/neoforge.mods.toml']=meta.encode();assert not any(n.startswith(('net/minecraft/','org/joml/'))for n in data)
  with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED)as z:
   for n,b in sorted(data.items()):z.writestr(n,b)
 with zipfile.ZipFile(out/name)as z:assert z.testzip()is None;m=tomllib.loads(z.read('META-INF/neoforge.mods.toml').decode())
 entries.append({'file':name,'mod_id':m['mods'][0]['modId'],'version':m['mods'][0]['version'],'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'base_commit':'1933ebb4b5888f616732407d35e9235590f674fd','minecraft':'1.21.1','loader':'NeoForge','artifacts':entries,'minecraft_runtime_tested':False},indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(''.join(e['sha256']+'  mods/'+e['file']+'\n'for e in entries))
for n in ['LEEME.md','test-results.json']:(out/n).write_bytes((r/n).read_bytes())
with zipfile.ZipFile(out/'Correccion-58-Linterna-Isometrica-Cuerpos.zip','w',zipfile.ZIP_DEFLATED)as z:
 for e in entries:z.write(out/e['file'],'mods/'+e['file'])
 for n in ['LEEME.md','manifest.json','test-results.json','SHA256SUMS.txt']:z.write(out/n,n)
with zipfile.ZipFile(out/'Correccion-58-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','gore-src','tests']:
  for p in(r/folder).rglob('*.java'):z.write(p,p.relative_to(r))
 for n in ['Patch58.java','build.py','test.py','package.py','LEEME.md']:z.write(r/n,n)
 for n in ['manifest.json','test-results.json']:z.write(out/n,n)
 z.write('/workspace/opt57/release/Optimizacion-57-Fuentes-Pruebas.zip','inherited57/Optimizacion-57-Fuentes-Pruebas.zip')
print('PACKAGED',[(p.name,p.stat().st_size)for p in out.glob('*.zip')])
