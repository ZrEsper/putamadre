package net.flashlight.battery;
/** Composite depth with the exact matrices used for its scene capture. */
public final class Frame58{
 static Object world,projection,view;
 static Object copy(Object old,Object value){return old==null?R.make("org.joml.Matrix4f",value):R.call(old,"set",value);}
 public static void capture(Object event){Object current=R.get(Light6.mc(),"level");if(current!=world){world=current;projection=null;view=null;}if(current==null)return;projection=copy(projection,R.call(event,"getProjectionMatrix"));view=copy(view,R.call(event,"getModelViewMatrix"));}
 public static Object call(Object target,String method,Object...args){Object current=R.get(Light6.mc(),"level");if(current!=world){world=current;projection=null;view=null;}if(args.length==0){if(method.equals("getProjectionMatrix")&&projection!=null)return projection;if(method.equals("getModelViewMatrix")&&view!=null)return view;}return R.call(target,method,args);}
}
