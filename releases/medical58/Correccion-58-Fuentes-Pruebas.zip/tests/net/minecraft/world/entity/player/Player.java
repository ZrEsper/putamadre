package net.minecraft.world.entity.player;public class Player{public boolean alive;public boolean isAlive(){return alive;}}
