package net.flashlight.battery;public class Light6{static final Client MC=new Client();static Object mc(){return MC;}public static class Client{public Object level=new Object();}}
