package org.joml;public class Matrix4f{public double scale;public Matrix4f(double s){scale=s;}public Matrix4f(Matrix4f m){scale=m.scale;}public Matrix4f set(Matrix4f m){scale=m.scale;return this;}}
