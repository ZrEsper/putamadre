from pathlib import Path
import subprocess,json
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];out=r/'build/tests';out.mkdir(exist_ok=True);cp=str(r/'output/flash.jar')+':'+str(r/'output/gore.jar');reports=[]
subprocess.run(e+['-cp',cp,'-d',str(out)]+list(map(str,(r/'tests').rglob('*.java'))),check=True)
for main,jar,args in [('net.flashlight.battery.FrameTest58',cp,[]),('dev.zomboid.gore.LocalTest58','/workspace/opt57/output/gore.jar',['old']),('dev.zomboid.gore.LocalTest58',cp,[])]:
 p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+jar,main]+args,capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();reports.append(p.stdout.strip())
(r/'test-results.json').write_text(json.dumps({'minecraft_runtime_tested':False,'results':reports,'limits':'Production helpers with simulated matrix/event and linked-player fixtures. No OpenGL or complete modpack run. Log alone does not identify the exact duplicated corpse.'},indent=2)+'\n')
