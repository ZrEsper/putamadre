package dev.zomboid.gore;
/** PlayerCorpse43 owns the real cargo of an infected player. Do not also create a native zombie body. */
public final class CorpseChoice51 {
 public static boolean playerZombie(Object actor){for(Class<?> t=actor==null?null:actor.getClass();t!=null;t=t.getSuperclass())if(t.getName().equals("net.smileycorp.hordes.common.entities.PlayerZombie"))return true;return false;}
 public static boolean skipDeath(Object actor){return playerZombie(actor)&&Linked45.corpseAvailable()||Down50.skipDeath(actor);}
 public static boolean skipLocal(Object actor){return playerZombie(actor)&&Linked45.corpseAvailable()&&!R.yes(R.call(actor,"isAlive"))||Linked45.skipLocal(actor)||Targets49.skipLocal(actor);}
}
