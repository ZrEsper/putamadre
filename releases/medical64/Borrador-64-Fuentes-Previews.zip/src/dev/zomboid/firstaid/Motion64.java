package dev.zomboid.firstaid;
import java.util.*;
/** Authoring candidate: prepare, wrap, press, release; synced treatment duration remains 66 ticks. */
public final class Motion64{
 static final Map<Object,float[]> PHASES=Collections.synchronizedMap(new WeakHashMap<>());
 public static float[] angles(int part,int kind,float age,Object player){float[] s=PHASES.computeIfAbsent(player,p->new float[]{age,age,part,kind});if(age-s[1]>6||age<s[1]||s[2]!=part||s[3]!=kind){s[0]=age;s[2]=part;s[3]=kind;}s[1]=age;return sample(part,kind,(age-s[0])/66f);}
 static float smooth(float x){return x*x*x*(x*(x*6-15)+10);}
 public static float[] sample(int part,int kind,float progress){float t=(progress%1+1)%1;float[] times={0,.14f,.30f,.46f,.62f,.78f,.9f,1};
 float[][] keys={{-.55f,-.15f,.02f,-.55f,.15f,-.02f,0,0,0,.15f,0,0},{-1.16f,-.92f,.12f,-1.04f,.20f,-.14f,.06f,0,0,.32f,0,0},{-1.28f,-1.00f,.20f,-1.04f,.20f,-.14f,.06f,0,0,.36f,0,0},{-1.12f,-.78f,-.02f,-1.04f,.20f,-.14f,.06f,0,0,.36f,0,0},{-1.28f,-1.00f,.20f,-1.04f,.20f,-.14f,.06f,0,0,.36f,0,0},{-1.22f,-.94f,.10f,-1.04f,.20f,-.14f,.06f,0,0,.38f,0,0},{-1.16f,-.92f,.12f,-1.04f,.20f,-.14f,.06f,0,0,.32f,0,0},{-.55f,-.15f,.02f,-.55f,.15f,-.02f,0,0,0,.15f,0,0}};
 int k=0;while(k<times.length-2&&t>times[k+1])k++;float b=smooth(Math.max(0,Math.min(1,(t-times[k])/(times[k+1]-times[k]))));float[] out=new float[12];for(int i=0;i<12;i++)out[i]=keys[k][i]+(keys[k+1][i]-keys[k][i])*b;
 if(part==5){float x=out[0],y=out[1],z=out[2];out[0]=out[3];out[1]=-out[4];out[2]=-out[5];out[3]=x;out[4]=-y;out[5]=-z;}
 else if(part==0){out[0]-=.65f;out[3]-=.65f;out[9]=.1f;}
 else if(part==2||part==3||part==6||part==7){out[0]+=.85f;out[3]+=.85f;out[6]=part==3||part==7?.75f:.48f;out[9]=.55f;}
 else if(part==4){out[1]*=.45f;out[4]*=.45f;}
 if(kind==3){out[2]*=.45f;out[5]*=.45f;}if(kind==4){out[0]-=.08f;out[3]+=.08f;}
 return out;
 }
}
