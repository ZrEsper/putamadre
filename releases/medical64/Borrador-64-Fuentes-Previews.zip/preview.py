"""Offline model preview from candidate animation JSON and Java pose samples; not Minecraft footage."""
from pathlib import Path
import json,math,numpy as np
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).parent;W,H=520,380
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
geo=json.loads((r/'carfak_bandage_geo.json').read_text())['minecraft:geometry'][0]['bones'];anim=json.loads((r/'candidate-animation.json').read_text())['animations']['use']['bones'];poses=json.loads((r/'poses.json').read_text());atlas=Image.open(r/'candidate-medical49.png').convert('RGBA');pix=np.asarray(atlas);cell=atlas.width//3
faces=[(0,1,3,2),(4,6,7,5),(0,4,5,1),(2,3,7,6),(0,2,6,4),(1,5,7,3)]
def rot(axis,a):
 c,s=math.cos(a),math.sin(a);m=np.eye(4)
 if axis==0:m[1:3,1:3]=[[c,-s],[s,c]]
 elif axis==1:m[0,0]=m[2,2]=c;m[0,2]=s;m[2,0]=-s
 else:m[:2,:2]=[[c,-s],[s,c]]
 return m
def trans(v):m=np.eye(4);m[:3,3]=v;return m
def curve(v,t,default):
 if v is None:return default
 if isinstance(v,list):return v
 keys=sorted((float(k),val)for k,val in v.items());i=max(0,min(len(keys)-2,next((i-1 for i,x in enumerate(keys)if x[0]>t),len(keys)-2)))
 def value(k):x=keys[max(0,min(len(keys)-1,k))][1];return np.asarray(x.get('post',x.get('pre'))if isinstance(x,dict)else x,float)
 if len(keys)==1:return value(0)
 a,b=keys[i][0],keys[i+1][0];u=max(0,min(1,(t-a)/max(.0001,b-a)));p0,p1,p2,p3=[value(k)for k in [i-1,i,i+1,i+2]]
 return .5*((2*p1)+(-p0+p2)*u+(2*p0-5*p1+4*p2-p3)*u*u+(-p0+3*p1-3*p2+p3)*u*u*u)
def project(v,fp):
 x,y,z=v[:3]
 if fp:
  depth=25-z
  if depth<.3:return None
  return(W/2+x*340/depth,H/2-(y-2)*340/depth,depth)
 v=rot(1,.36)@v;x,y,z=v[:3];return(W/2-x*8,H/2+(y-7)*8,40+z)
def cube(lo,size,m,color,out,fp):
 q=[project(m@np.array([x,y,z,1.]),fp)for x in (lo[0],lo[0]+size[0])for y in (lo[1],lo[1]+size[1])for z in (lo[2],lo[2]+size[2])]
 for i,f in enumerate(faces):
  if any(q[j]is None for j in f):continue
  out.append((sum(q[j][2]for j in f)/4,[q[j][:2]for j in f],tuple(int(c*(.72+.045*i))for c in color)))
def decal(center,width,height,m,out,fp,tile=0):
 N=22
 for y in range(N):
  for x in range(N):
   rgba=pix[min(atlas.height-1,int((y+.5)/N*atlas.height)),min(atlas.width-1,tile*cell+int((x+.5)/N*cell))]
   if rgba[3]<128:continue
   q=[]
   for dx,dy in [(0,0),(1,0),(1,1),(0,1)]:q.append(project(m@np.array([center[0]+((x+dx)/N-.5)*width,center[1]+((y+dy)/N-.5)*height,center[2],1.]),fp))
   if any(v is None for v in q):continue
   out.append((sum(v[2]for v in q)/4,[v[:2]for v in q],tuple(int(rgba[i]*[.84,.70,.70][i])for i in range(3))))
FP_FACE=None
def frame(i,fp):
 global FP_FACE
 out=[];time=i/50*3.3
 if fp:
  matrices={}
  for b in geo:
   k=anim.get(b['name'],{});p=np.array(b.get('pivot',[0,0,0]),float);pos=np.array(curve(k.get('position'),time,[0,0,0]));angles=np.array(curve(k.get('rotation'),time,[0,0,0]))+np.array(b.get('rotation',[0,0,0]));scale=np.diag(list(curve(k.get('scale'),time,[1,1,1]))+[1]);m=trans(p+pos)@rot(2,math.radians(angles[2]))@rot(1,math.radians(angles[1]))@rot(0,math.radians(angles[0]))@scale@trans(-p);m=matrices.get(b.get('parent'),np.eye(4))@m;matrices[b['name']]=m
   for c in b.get('cubes',[]):cube(c['origin'],c['size'],m,(206,177,147)if 'hand' in b['name']else(221,217,190),out,fp)
  
  m=matrices['lefthand_pos']
  if FP_FACE is None:
   center=m@np.array([-6,4.5,8,1.]);view=np.array([0,2,25])-center[:3];options=[(float(np.dot(m[:3,:3]@np.array([sg if ax==0 else 0,0,sg if ax==2 else 0]),view)),ax,sg)for ax in [0,2]for sg in [-1,1]];_,axis,sign=max(options)
   FP_FACE=trans([-6+sign*2.03 if axis==0 else -6,4.5,8+sign*2.03 if axis==2 else 8])@(rot(1,math.pi/2)if axis==0 else np.eye(4))
  decal([0,0,0],3.3,3.5,m@FP_FACE,out,fp)
 else:
  eye=np.eye(4);cube([-4,-8,-4],[8,8,8],eye,(194,164,137),out,fp);cube([-4,0,-2],[8,12,4],eye,(83,99,73),out,fp);cube([-4,12,-2],[4,12,4],eye,(63,73,80),out,fp);cube([0,12,-2],[4,12,4],eye,(63,73,80),out,fp)
  cube([-4,-8,-4],[8,2,8],eye,(74,57,44),out,fp)
  for x in [-2.5,1]:cube([x,-4.8,-4.04],[1.5,1,.04],eye,(57,64,60),out,fp)
  cube([-1,-1.8,-4.05],[2,.5,.05],eye,(113,78,67),out,fp)
  a=poses[i]
  for side in [0,1]:
   j=side*3;m=trans([-5 if side==0 else 5,2,0])@rot(2,a[j+2])@rot(1,a[j+1])@rot(0,a[j]);cube([-2,-2,-2],[4,5,4],m,(85,102,75),out,fp);cube([-2,3,-2],[4,7,4],m,(194,164,137),out,fp)
   if side==1:decal([0,6,-2.03],3.8,4,m,out,fp)
  # Visible cloth roll carried by the working hand.
  m=trans([-5,2,0])@rot(2,a[2])@rot(1,a[1])@rot(0,a[0]);cube([-1.2,8,-1.2],[2.4,2.5,2.4],m,(225,220,194),out,fp)
 im=Image.new('RGB',(W,H),(27,33,30));d=ImageDraw.Draw(im)
 for y in range(80,H,24):d.line((0,y,W,y),fill=(32,39,35))
 for _,q,c in sorted(out,key=lambda v:v[0],reverse=True):d.polygon(q,fill=c)
 d.rectangle((0,0,W,57),fill=(17,22,20));d.text((14,12),'PRIMERA PERSONA'if fp else'TERCERA PERSONA',font=font,fill=(229,231,215));d.text((14,33),'Vendaje + lesion | render de revision, no captura del juego',font=font,fill=(158,172,153));d.rectangle((0,H-40,W,H),fill=(17,22,20));phase=['Preparar','Aplicar','Envolver','Ajustar','Presionar','Retirar'][min(5,int(i/50*6))];d.text((14,H-30),phase,font=font,fill=(214,218,199));d.rectangle((14,H-10,14+int((W-28)*i/49),H-7),fill=(131,155,112));return im
for fp,name in [(True,'preview-primera-persona.gif'),(False,'preview-tercera-persona.gif')]:
 frames=[frame(i,fp)for i in range(50)];frames[0].save(r/'release'/name,save_all=True,append_images=frames[1:],duration=66,loop=0,optimize=False);frames[23].save(r/('first.png'if fp else'third.png'))
