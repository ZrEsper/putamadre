from pathlib import Path
import json,copy
r=Path(__file__).parent;d=json.loads((r/'base-animation.json').read_text());base=copy.deepcopy(d['animations']['static_idle']['bones'])
for a in d['animations'].values():
 for key in ['righthand','lefthand']:a['bones'][key]={'scale':[1,1,1]}
 a['bones']['camera']={'rotation':[.2,0,0]}
# Keyed offsets around the original rig attachment. Preserve native 3.3s timing and bone names.
phases=[0,.14,.30,.46,.62,.78,.90,1];pull=[0,1,1,.65,1,.8,1,0];roll=[0,8,14,-6,14,0,4,0];reach=[0,1,1,.8,1,1,.8,0]
use=d['animations']['use'];bones=use['bones']
for name in ['mag_and_lefthand','gun_and_righthand']:
 rot=base[name]['rotation'];pos=base[name]['position'];bones[name]={}
 for channel,original in [('rotation',rot),('position',pos)]:
  track={}
  for phase,a,b,c in zip(phases,pull,roll,reach):
   delta=([a*1.5,a*1.0,a*1.3]if name=='mag_and_lefthand'else[a*3,b,a*-3])if channel=='rotation'else([a*.2,a*.1,a*.25]if name=='mag_and_lefthand'else[a*-.8,a*.5,a*1.1])
   track[f'{phase*3.3:.4f}']={'post':[round(x+y,5)for x,y in zip(original,delta)],'lerp_mode':'catmullrom'}
  bones[name][channel]=track
bones['camera']={'rotation':[.2,0,0]};bones['righthand']={'scale':[1,1,1]};bones['lefthand']={'scale':[1,1,1]}
# Extend cloth only during the working phase, no permanent elongated strip.
bones['bone']={'rotation':base['bone']['rotation'],'position':base['bone']['position'],'scale':{f'{p*3.3:.4f}':{'post':[1,1,1+4*a],'lerp_mode':'catmullrom'}for p,a in zip(phases,pull)}}
(r/'candidate-animation.json').write_text(json.dumps(d,indent=2)+'\n')

# Bring the working hand toward the supported forearm; apply the same anchor to all clips.
for clip in d['animations'].values():
 track=clip['bones'].get('gun_and_righthand',{}).get('position')
 if isinstance(track,list):clip['bones']['gun_and_righthand']['position']=[track[0]-5,track[1]-1,track[2]+7]
 elif isinstance(track,dict):
  for frame in track.values():
   v=frame.get('post',frame) if isinstance(frame,dict) else frame
   v[0]-=5;v[1]-=1;v[2]+=7
(r/'candidate-animation.json').write_text(json.dumps(d,indent=2)+'\n')
