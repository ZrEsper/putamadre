from pathlib import Path
import subprocess,tempfile
r=Path(__file__).parent;cp='/workspace/npc79/tests:'+str(next((r/'release').glob('*.jar')))+':/workspace/medical63/gson.jar'
subprocess.run(['java','-jar','/workspace/putamadre/hordes-melee-interiors-patch/build/tools/ecj.jar','-21','-proc:none','-nowarn','-cp',cp,'-d',str(r/'checks'),str(r/'checksrc/mod/cdv/tnpc/tactical/Check80.java')],check=True)
with (r/'regression.txt').open('w')as log:
 for cls,extra in [(f'Fixtures{i}','')for i in [70,73,74,75,76,77,78]]+[('Check80',str(r/'checks')+':'),('Fix4Check','/workspace/fix4-review/checks:')]:
  with tempfile.TemporaryDirectory(dir=r)as tmp:
   result=subprocess.run(['java','-Xverify:all','-cp',extra+cp,'mod.cdv.tnpc.tactical.'+cls],cwd=tmp,stdout=log,stderr=subprocess.STDOUT)
   if result.returncode:raise SystemExit('FAILED '+cls)
print('PASS all regression suites, context checks and fix4 checks. JVM fixtures only.')
