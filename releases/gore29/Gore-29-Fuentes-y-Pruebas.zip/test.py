from pathlib import Path
import subprocess,json,zipfile
r=Path(__file__).resolve().parent;old=r.parent/'procedural25';g=next((r/'output').glob('zomboid*.jar'));rag=next((r.parent/'procedural28/output').glob('ragdoll*.jar'));out=r/'build/test';out.mkdir(parents=True,exist_ok=True)
sources=[*map(str,(old/'fixtures').rglob('*.java')),*map(str,(r.parent/'procedural28/fixtures').rglob('*.java')),*map(str,(old/'tests').rglob('*.java')),*map(str,(r.parent/'procedural27/tests').rglob('*.java')),*map(str,(r.parent/'procedural27/fixtures').rglob('*.java')),*map(str,(r.parent/'procedural28/tests').rglob('*.java')),*map(str,(r/'fixtures').rglob('*.java')),*map(str,(r/'tests').rglob('*.java'))]
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(g)+':'+str(rag),'-d',str(out),*sources],check=True)
results=[]
for main,args in [('Checks24',[str(r.parent/'procedural28/geometry.json')]),('RenderChecks25',[]),('DamageEffectsChecks28',[]),('AnatomyChecks27',[str(r/'anatomy-mesh.json')]),('BehaviorChecks28',[]),('JetChecks28',[]),('EyeInsetChecks29',[]),('OrganBurnChecks29',[]),('NpcChecks29',[])]:
 p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(g)+':'+str(rag)+':'+str(r/'output/tacznpcs-2.1.0-1.21.1-tactical.30-visible-injuries-burns.jar'),'dev.zomboid.gore.'+main,*args],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
# .26 corpse bullet crash and foley regressions remain unchanged.
for main in ['BulletChecks26','FoleyChecks26']:
 p=subprocess.run(['java','-Xverify:all','-cp',str(r.parent/'procedural26/build/test')+':'+str(g),'dev.zomboid.gore.'+main],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{s}=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']]
subprocess.run(['java',*exports,'com.sun.tools.javac.Main',*exports,'-d',str(out),str(r.parent/'procedural28/Inspect.java')],check=True)
p=subprocess.run(['java',*exports,'-cp',str(out),'Inspect',str(g),str(rag)],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
for jar in [g,rag]:
 with zipfile.ZipFile(jar)as z:assert z.testzip()is None
with zipfile.ZipFile(g)as z:assert not any(n.startswith(('net/minecraft/','com/mojang/','javax/vecmath/'))for n in z.namelist())
subprocess.run(['java',*exports,'com.sun.tools.javac.Main',*exports,'-d',str(out),str(r/'Inspect29.java')],check=True)
npc=r/'output/tacznpcs-2.1.0-1.21.1-tactical.30-visible-injuries-burns.jar'
p=subprocess.run(['java',*exports,'-cp',str(out),'Inspect29',str(r.parent.parent/'attachments/1cf71ce5-e3bc-41ab-a68b-05ce5dc75461/tacznpcs-2.1.0-1.21.1-tactical.29-committed-decisions.jar'),str(npc)],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(npc),'OptionalBridge29'],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
(r/'output/test-results.json').write_text(json.dumps({'results':results,'minecraft_runtime_tested':False,'scope':'Strict API fixture regressions and software rendered actual anatomy mesh; no running Minecraft.'},indent=2)+'\n')
