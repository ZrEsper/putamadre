package dev.zomboid.gore;
import java.util.*;
public class EyeInsetChecks29{public static void main(String[]args){Set<String>names=Set.of("eyeball","iris","pupil","eye_glint");int n=0;for(int level=0;level<=3;level++)for(var p:Anatomy14.layer(0,level))if(names.contains(p.name())){if(p.box().z0()<.20f||p.box().z1()>.8f)throw new AssertionError("eye outside recessed socket: "+p.name()+" level "+level+" "+p.box());n++;}if(n==0)throw new AssertionError("no eyes checked");System.out.println("RECESSED_EYE_GEOMETRY_AND_LEGACY_WOUND_STATES="+n);}}
