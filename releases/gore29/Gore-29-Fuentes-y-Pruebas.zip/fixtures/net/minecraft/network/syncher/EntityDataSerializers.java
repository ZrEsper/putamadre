package net.minecraft.network.syncher; public class EntityDataSerializers{public static final Object INT=new Object(),STRING=new Object();}
