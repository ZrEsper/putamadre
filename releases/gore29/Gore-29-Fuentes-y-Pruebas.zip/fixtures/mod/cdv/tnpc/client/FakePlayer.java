package mod.cdv.tnpc.client;public class FakePlayer{public final Object link;public FakePlayer(Object n){link=n;}}
