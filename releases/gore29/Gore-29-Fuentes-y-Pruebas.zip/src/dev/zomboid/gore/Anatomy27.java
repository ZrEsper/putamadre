package dev.zomboid.gore;
import java.util.*;
/** Minecraft-sized organs in normalized model coordinates; front is z=0, crown y=0. */
public final class Anatomy27 {
 static void b(List<Anatomy14.Piece>p,String n,int m,float x,float y,float z,float X,float Y,float Z){p.add(new Anatomy14.Piece(n,new Mesh12.Box(x,y,z,X,Y,Z),m));}
 static void shape(List<Anatomy14.Piece>p,String n,int m,float x,float y,float z,float X,float Y,float Z){float[]profile={.72f,.96f,1,.91f,.61f};float cx=(x+X)/2,cz=(z+Z)/2;for(int i=0;i<5;i++){float k=profile[i];b(p,n,m,cx-(X-x)*k/2,y+(Y-y)*i/5,cz-(Z-z)*k/2,cx+(X-x)*k/2,y+(Y-y)*(i+1)/5,cz+(Z-z)*k/2);}}
 public static List<Anatomy14.Piece>create(int r){List<Anatomy14.Piece>p=new ArrayList<>();if(r==0){head(p);for(int i=0;i<p.size();i++){var piece=p.get(i);if(Set.of("eyeball","iris","pupil","eye_glint","optic_stalk").contains(piece.name())){var b=piece.box();p.set(i,new Anatomy14.Piece(piece.name(),new Mesh12.Box(b.x0(),b.y0(),b.z0()+.18f,b.x1(),b.y1(),b.z1()+.18f),piece.material()));}}}else if(r==6)torso(p);else limb(p,r);Skeleton17.add(p,r);return List.copyOf(p);}
 public static boolean organ(String n){return Set.of("brain_lobe","brain_fold","cerebellum","brainstem","eyeball","iris","pupil","optic_stalk","tongue","tongue_tip","tongue_root","left_lung","right_lung","heart","liver","stomach","kidney","pancreas","spleen","bowel_loop","bowel_join","colon_left","colon_right","colon_transverse","rectum").contains(n);}
 static void head(List<Anatomy14.Piece>p){
  // Large pink cerebral hemispheres with an actual longitudinal gap and folded top.
  for(boolean left:new boolean[]{true,false}){float x=left?.16f:.515f,X=left?.485f:.84f;
   shape(p,"brain_lobe",3,x,.12f,.25f,X,.58f,.85f);
   for(int i=0;i<4;i++){float z=.29f+i*.13f;b(p,"brain_fold",3,x+.025f,.092f+(i%2)*.015f,z,X-.025f,.16f,z+.09f);}
  }
  shape(p,"cerebellum",3,.28f,.52f,.65f,.72f,.70f,.85f);
  b(p,"brainstem",17,.46f,.57f,.57f,.54f,.91f,.68f);
  for(boolean left:new boolean[]{true,false}){float x=left?.195f:.605f;
   shape(p,"eyeball",12,x,.395f,.055f,x+.20f,.59f,.29f);
   b(p,"iris",13,x+.05f,.448f,.035f,x+.15f,.548f,.061f);
   b(p,"pupil",14,x+.082f,.468f,.026f,x+.119f,.525f,.038f);
   b(p,"eye_glint",12,x+.06f,.452f,.025f,x+.083f,.475f,.036f);
   b(p,"optic_stalk",17,x+.075f,.465f,.25f,x+.125f,.52f,.60f);
   // Red cheek and temple muscle separated from the ivory skull.
   float a=left?.065f:.82f;
   b(p,"temporalis",16,a,.21f,.16f,a+.115f,.62f,.65f);
   b(p,"masseter",16,a,.59f,.09f,a+.115f,.86f,.38f);
   b(p,"zygomatic_muscle",16,left?.14f:.66f,.56f,.035f,left?.34f:.86f,.635f,.12f);
   b(p,"jugular",4,left?.365f:.60f,.84f,.52f,left?.4f:.635f,1,.57f);
   b(p,"carotid",15,left?.405f:.56f,.83f,.48f,left?.44f:.595f,1,.53f);
  }
  b(p,"mouth_floor",16,.25f,.81f,.26f,.75f,.87f,.70f);
  shape(p,"tongue",11,.34f,.745f,.13f,.66f,.82f,.61f);
  b(p,"tongue_tip",11,.39f,.77f,.075f,.61f,.817f,.21f);
  b(p,"tongue_root",11,.41f,.76f,.54f,.59f,.92f,.66f);
  b(p,"trachea",19,.46f,.87f,.43f,.54f,1,.51f);
 }
 static void torso(List<Anatomy14.Piece>p){
  // Thin muscle at the surface; organs occupy the cavity rather than tiny central cubes.
  shape(p,"pectoral_left",16,.065f,.08f,.035f,.47f,.40f,.16f);
  shape(p,"pectoral_right",16,.53f,.08f,.035f,.935f,.40f,.16f);
  for(int i=0;i<3;i++){float y=.48f+i*.135f;for(float x:new float[]{.31f,.53f})b(p,"abdominal_wall",16,x,y,.045f,x+.16f,y+.10f,.145f);}
  for(boolean left:new boolean[]{true,false}){
   float x=left?.10f:.55f,X=left?.455f:.90f;
   shape(p,left?"left_lung":"right_lung",6,x,.135f,.19f,X,.535f,.75f);
   b(p,"bronchus",19,left?.37f:.53f,.15f,.48f,left?.47f:.63f,.30f,.55f);
   b(p,"jugular",4,left?.35f:.61f,0,.52f,left?.39f:.65f,.16f,.58f);
   b(p,"carotid",15,left?.40f:.56f,0,.47f,left?.44f:.60f,.23f,.52f);
   shape(p,"kidney",8,left?.20f:.70f,.615f,.64f,left?.32f:.82f,.79f,.81f);
  }
  shape(p,"heart",7,.385f,.285f,.145f,.64f,.515f,.47f);
  b(p,"aortic_arch",15,.47f,.20f,.32f,.58f,.285f,.40f);
  b(p,"aorta",15,.465f,.25f,.57f,.515f,.90f,.625f);
  b(p,"vena_cava",4,.54f,.24f,.59f,.585f,.88f,.64f);
  b(p,"trachea",19,.46f,0,.43f,.54f,.21f,.51f);
  b(p,"esophagus",11,.48f,0,.55f,.54f,.63f,.60f);
  b(p,"diaphragm",16,.14f,.535f,.21f,.86f,.57f,.75f);
  shape(p,"liver",8,.12f,.575f,.19f,.60f,.715f,.69f);
  shape(p,"stomach",9,.61f,.575f,.20f,.86f,.755f,.65f);
  shape(p,"gallbladder",4,.36f,.685f,.39f,.45f,.75f,.51f);
  b(p,"pancreas",18,.39f,.665f,.48f,.73f,.71f,.59f);
  shape(p,"spleen",8,.83f,.565f,.53f,.90f,.69f,.69f);
  b(p,"colon_transverse",10,.16f,.70f,.22f,.845f,.737f,.48f);
  b(p,"rectum",10,.46f,.88f,.47f,.54f,.97f,.57f);
  b(p,"mesentery",18,.27f,.705f,.56f,.75f,.925f,.69f);
  // Alternating connected loops, recognizable through an abdominal opening.
  for(int i=0;i<4;i++){float y=.728f+i*.049f;
   b(p,"bowel_loop",10,.25f,y,.21f,.76f,y+.037f,.48f);
   b(p,"bowel_join",10,i%2==0?.715f:.25f,y,.22f,i%2==0?.76f:.295f,y+.075f,.46f);
  }
  b(p,"colon_left",10,.16f,.70f,.25f,.235f,.91f,.51f);
  b(p,"colon_right",10,.77f,.70f,.25f,.845f,.91f,.51f);
  b(p,"posterior_fascia",16,.31f,0,.87f,.69f,.96f,.94f);
 }
 static void limb(List<Anatomy14.Piece>p,int r){boolean arm=r==2||r==3;
  b(p,arm?"brachial_artery":"femoral_artery",15,.22f,.03f,.47f,.28f,.95f,.53f);
  b(p,arm?"arm_vein":"leg_vein",4,.72f,.05f,.39f,.77f,.96f,.45f);
  shape(p,arm?"biceps":"quadriceps",16,.12f,.08f,.10f,.44f,.46f,.40f);
  shape(p,arm?"triceps":"hamstring",16,.52f,.08f,.59f,.86f,.46f,.88f);
  shape(p,"proximal_muscle",16,.32f,.08f,.12f,.79f,.45f,.34f);
  shape(p,"distal_muscle",16,.20f,.55f,.12f,.78f,.86f,.36f);
  b(p,"tendon",19,.38f,.42f,.23f,.62f,.98f,.35f);
 }
}
