package dev.zomboid.gore;
/** Optional TaCZ NPC adapter. NPC damage/AI balance remains owned by TaCZ NPCs and First Aid. */
public final class Npc29 {
 static final String NPC="mod.cdv.tnpc.entity.AutoGunOperator";
 static final Object[] IDS=new Object[5];static boolean ready;
 public static boolean npc(Object n){for(Class<?>c=n==null?null:n.getClass();c!=null;c=c.getSuperclass())if(c.getName().equals(NPC))return true;return false;}
 public static Object resolve(Object n){if(n!=null&&n.getClass().getName().equals("mod.cdv.tnpc.client.FakePlayer")){Object real=R.get(n,"link");if(npc(real))return real;}return n;}
 public static boolean entityNpc(Object event){return npc(R.call(event,"getEntity"));}
 public static boolean target(Object n){return npc(n)||Gore.zombie(n);}
 static synchronized void init(){if(ready)return;Class<?>type=R.type(NPC),data=R.type("net.minecraft.network.syncher.SynchedEntityData"),serial=R.type("net.minecraft.network.syncher.EntityDataSerializers");for(int i=0;i<5;i++)IDS[i]=R.call(data,"defineId",type,R.get(serial,i==4?"STRING":"INT"));ready=true;}
 public static void register(){init();}
 public static void define(Object builder){init();for(int i=0;i<5;i++)R.call(builder,"define",IDS[i],i==4?"":Integer.valueOf(0));}
 public static Object accessor(Object original,Object n,int kind){return npc(n)?IDS[kind]:original;}
 public static void save(Object n,Object tag){Gore.save(n,tag);Cuts24.save(n,tag);}
 public static void restore(Object n,Object tag){Gore.restore(n,tag);Cuts24.restore(n,tag);}
 public static void apply(Object n){Gore.modifier(n,"MOVEMENT_SPEED","injury_speed",Limb28.speed(Gore.state(n)));}
 public static void hurt(Object event){if(entityNpc(event))Ballistics11.SOURCE.set(R.call(event,"getSource"));}
 public static void injure(Object n,Gore.Shot shot,float damage,int kind){if(damage<=0||!Float.isFinite(damage))return;Cuts24.hit(n,shot,damage,kind);int serial=((Number)R.call(Gore.tag(n),"getInt","zg13_serial")).intValue()%10000000+1;R.call(Gore.tag(n),"putInt","zg13_serial",serial);R.call(R.call(n,"getEntityData"),"set",IDS[3],serial<<4|Cuts24.zone(shot));}
 public static void tick(Object event){Object n=R.call(event,"getEntity"),w=R.call(n,"level");if(R.yes(R.get(w,"isClientSide"))){Damage25.living(event);Organs16.living(event);return;}if(((Number)R.get(n,"tickCount")).intValue()%5!=0)return;if(R.yes(R.call(n,"isOnFire"))){int ticks=((Number)R.call(Gore.tag(n),"getInt","zg_burn_ticks")).intValue()+5;R.call(Gore.tag(n),"putInt","zg_burn_ticks",ticks);}Burn29.tick(event);if((Limb28.disabled(Gore.state(n))&0x30)!=0){apply(n);R.call(n,"setSprinting",false);}}
}
