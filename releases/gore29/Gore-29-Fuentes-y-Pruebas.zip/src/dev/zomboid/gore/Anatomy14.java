package dev.zomboid.gore;
import java.util.*;
/** Anatomy stays in the same local frame as the damaged model part. */
public final class Anatomy14 {
 public record Piece(String name,Mesh12.Box box,int material){}
 static void add(List<Piece>p,String name,int mat,float a,float b,float c,float d,float e,float f){if(Set.of("proximal_muscle","distal_muscle","brain_lobe","left_lung","right_lung","heart","liver","stomach").contains(name)){float midX=(a+d)/2,midZ=(c+f)/2;float[]profile=name.equals("heart")?new float[]{.72f,1,.9f,.65f,.3f}:new float[]{.55f,.86f,1,.86f,.55f};for(int i=0;i<5;i++){float k=profile[i],lo=b+(e-b)*i/5,hi=Math.min(e,b+(e-b)*(i+1)/5+.0001f);p.add(new Piece(name,new Mesh12.Box(midX-(d-a)*k/2,lo,midZ-(f-c)*k/2,midX+(d-a)*k/2,hi,midZ+(f-c)*k/2),mat));}}else p.add(new Piece(name,new Mesh12.Box(a,b,c,d,e,f),mat));}
 static final Map<Integer,List<Piece>> ANATOMY=new HashMap<>();
 public static synchronized List<Piece> anatomy(int region){int r=region==1?0:region==7?6:region;return ANATOMY.computeIfAbsent(r,Anatomy27::create);}
 static boolean bone(Piece p){return p.material()==2||p.name().equals("tooth");}
 static boolean organ(Piece p){return Set.of("brain_lobe","left_lung","right_lung","heart","liver","stomach","bowel_loop","bowel_join","mesentery","diaphragm","mediastinum","optic_stalk","eyeball","pupil").contains(p.name());}
 static List<Piece> layer(int region,int level){
 List<Piece> out=new ArrayList<>();if(level>=7)return out;
 for(Piece p:anatomy(region)){
  Mesh12.Box b=p.box();boolean hard=bone(p),inside=organ(p);
  if(level>=3&&Set.of("eyeball","pupil","optic_stalk","heart","liver","stomach").contains(p.name()))continue;
  if(!hard&&!inside&&level>=3)continue;
  if(inside&&level>=4)continue;
  // Eyes retain their recessed socket placement even in legacy wound states.
  if(level==3&&region==6&&p.name().startsWith("bowel"))b=new Mesh12.Box(b.x0(),b.y0(),.10f,b.x1(),b.y1(),b.z1());
  if(hard&&level>=5){
   // Successive cuts consume every bone, including jaw, spine and joints.
   float edge=level==5?.65f:.50f;
   if(b.x0()>=edge)continue;
   b=new Mesh12.Box(b.x0(),b.y0(),b.z0(),Math.min(b.x1(),edge),b.y1(),b.z1());
  }
  out.add(new Piece(p.name(),b,p.material()));
 }
 return out;
 }
 public static List<Piece> damaged(int region,int stage){
 if(region!=6)return layer(region,stage&7);
 List<Piece>out=new ArrayList<>();int[]levels={stage&7,(stage>>5)&7};
 for(int side=0;side<2;side++)for(Piece p:layer(region,levels[side])){if(Set.of("heart","liver","stomach").contains(p.name())&&levels[p.name().equals("stomach")?0:1]>=3)continue;Mesh12.Box b=p.box();float lo=Math.max(b.x0(),side==0?.5f:0),hi=Math.min(b.x1(),side==0?1:.5f);if(hi>lo)out.add(new Piece(p.name(),new Mesh12.Box(lo,b.y0(),b.z0(),hi,b.y1(),b.z1()),p.material()));}
 return out;
 }
 static Mesh12.Box scale(Mesh12.Box p,Mesh12.Box b){float w=b.x1()-b.x0(),h=b.y1()-b.y0(),d=b.z1()-b.z0();return new Mesh12.Box(b.x0()+p.x0()*w,b.y0()+p.y0()*h,b.z0()+p.z0()*d,b.x0()+p.x1()*w,b.y0()+p.y1()*h,b.z0()+p.z1()*d);}
 public static List<Mesh12.Quad> build(List<Mesh12.Cube> cubes,int region,int stage){return Surface19.build(cubes,region,stage);}
}
