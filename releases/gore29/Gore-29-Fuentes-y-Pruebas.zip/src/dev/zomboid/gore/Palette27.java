package dev.zomboid.gore;
import java.util.*;
/** Separate 16px material tiles, sampled at model-pixel density instead of noisy full-face stretching. */
public final class Palette27 {
 public static final int COUNT=20;
 public static void lastBox(List<Mesh12.Quad> out){remap(out,Math.max(0,out.size()-6));}
 public static int[] colors(){int[]c=new int[COUNT];Arrays.fill(c,-1);return c;}
 public static void remap(List<Mesh12.Quad>out,int start){for(int i=start;i<out.size();i++){
  Mesh12.Quad q=out.get(i);int m=q.material();if(m<=0)continue;if(m>=COUNT)throw new IllegalArgumentException("anatomy material "+m);
  float minU=Float.MAX_VALUE,minV=minU,maxU=-minU,maxV=-minU;float[]u=new float[4],v=new float[4];
  for(int j=0;j<4;j++){var p=q.vertices()[j];u[j]=(q.nx()!=0?p.z():p.x())*16;v[j]=(q.ny()!=0?p.z():p.y())*16;minU=Math.min(minU,u[j]);maxU=Math.max(maxU,u[j]);minV=Math.min(minV,v[j]);maxV=Math.max(maxV,v[j]);}
  Mesh12.Vertex[]vs=new Mesh12.Vertex[4];float w=Math.max(.001f,maxU-minU),h=Math.max(.001f,maxV-minV);float su=Math.min(14,Math.max(8,w*2)),sv=Math.min(14,Math.max(8,h*2));
  // Small pieces must sample a tonal ramp, not one flat atlas texel.
  float originU=1+(14-su)*.5f,originV=1+(14-sv)*.5f;
  for(int j=0;j<4;j++){var p=q.vertices()[j];float U=((m%4)*16+originU+(u[j]-minU)/w*su)/64,V=((m/4)*16+originV+(v[j]-minV)/h*sv)/80;vs[j]=new Mesh12.Vertex(p.x(),p.y(),p.z(),U,V);}
  out.set(i,new Mesh12.Quad(vs,m,q.nx(),q.ny(),q.nz()));
 }}
}
