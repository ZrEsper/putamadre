package dev.zomboid.gore;
/** Four persistent burn grades, carried to corpses through the existing surface snapshot. */
public final class Burn29 {
 static final double[][]RAMP={{1,1,1},{1,.79,.75},{.70,.40,.35},{.36,.24,.20},{.15,.13,.12}};
 static final ThreadLocal<Integer>GRADE=ThreadLocal.withInitial(()->0);
 public static int grade(int ticks){return ticks>=360?4:ticks>=220?3:ticks>=100?2:ticks>=20?1:0;}
 public static void tick(Object event){Object n=R.call(event,"getEntity");if(!Npc29.target(n)||R.yes(R.get(R.call(n,"level"),"isClientSide"))||((Number)R.get(n,"tickCount")).intValue()%5!=0)return;int ticks=((Number)R.call(Gore.tag(n),"getInt","zg_burn_ticks")).intValue(),g=grade(ticks),surface=Gore.surfaces(n);g=Math.max(g,(surface>>>24)&7);if(g>0){Gore.surfaceSet(n,(surface&~0x07000000)|(g<<24));Gore.set(n,(Gore.state(n)&~0x30000)|(Math.min(3,g)<<16));}}
 static final java.util.Map<Object,Integer>LAST=new java.util.WeakHashMap<>();
 public static void prepare(Object part){Object ctx=Skin12.CURRENT.get();if(ctx==null){GRADE.set(0);return;}int surface=((Number)R.get(ctx,"surfaces")).intValue(),state=((Number)R.get(ctx,"state")).intValue();int g=Math.min(4,Math.max((surface>>>24)&7,(state>>>16)&3));GRADE.set(g);Integer old=LAST.put(part,g);if(old==null||old!=g)Skin12.MESHES.remove(part);}
 public static java.util.List<Mesh12.Quad>mesh(java.util.List<Mesh12.Quad>base,java.util.List<Mesh12.Cube>cubes,int region){int g=GRADE.get();if(g<2||cubes.isEmpty()||Damage25.destroyed(Cuts24.CURRENT.get(),region))return base;var b=CSG24.bounds(cubes);java.util.List<Mesh12.Quad>out=new java.util.ArrayList<>(base);float w=b.x1()-b.x0(),h=b.y1()-b.y0(),d=b.z1()-b.z0();for(int i=0;i<3;i++){float x=.23f+i*.25f,y=.25f+(i%2)*.32f;if(Cuts24.covered(Cuts24.CURRENT.get(),region,x,y,0,0))continue;float cx=b.x0()+w*x,cy=b.y0()+h*y,r=Math.min(w,h)*.045f,z=b.z0();Mesh12.box(out,new Mesh12.Box(cx-r,cy-r,z-.03f,cx+r,cy+r,z+.02f),g==2?11:8,null);}return java.util.List.copyOf(out);}
 public static int color(int base,int material){int g=GRADE.get();if(g==0)return base;double[]c=RAMP[g];double red=c[0],green=c[1],blue=c[2];if(material==2||material==5){double k=g<3?1:g==3?.82:.53;red=k;green=k*.98;blue=k*.95;}return(base&0xff000000)|((int)(((base>>>16)&255)*red)<<16)|((int)(((base>>>8)&255)*green)<<8)|(int)((base&255)*blue);}
 public static void end(){GRADE.remove();}
}
