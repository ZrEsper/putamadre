from pathlib import Path
import math,json
import numpy as np
from PIL import Image,ImageDraw
r=Path(__file__).resolve().parent
# Tissue ramps: dark, middle, light. Muted maroon/taupe and chalky grey ivory
# were chosen beside the supplied TZP skin crops, not by bright flat primaries.
ramps=[
 [(0,0,0)]*3,
 [(49,22,24),(101,48,48),(153,103,91)], # raw flesh
 [(106,96,84),(170,161,146),(221,214,198)], # bone
 [(83,52,55),(139,91,92),(187,146,140)], # brain
 [(30,23,30),(62,46,59),(103,78,87)], # vein
 [(130,119,100),(199,188,166),(236,228,208)], # teeth
 [(69,38,43),(127,77,82),(181,127,122)], # lung
 [(46,18,23),(101,39,45),(159,88,86)], # heart
 [(40,22,26),(89,44,48),(142,89,82)], # liver
 [(94,54,54),(158,102,100),(205,156,142)], # stomach
 [(81,43,48),(141,83,88),(193,134,128)], # bowel
 [(85,31,42),(151,70,83),(201,125,126)], # tongue
 [(123,116,101),(194,183,160),(236,228,204)], # eye
 [(42,49,41),(93,105,85),(150,159,125)], # iris
 [(11,10,12),(25,21,24),(49,40,43)], # pupil
 [(63,20,29),(132,50,57),(182,100,99)], # artery
 [(54,24,27),(112,53,57),(165,108,100)], # muscle
 [(117,99,77),(182,157,119),(226,207,165)], # nerve
 [(105,85,55),(161,136,91),(210,188,141)], # fat
 [(110,99,79),(168,153,124),(218,204,174)], # cartilage
]

def smoothnoise(seed,scale):
 rng=np.random.default_rng(seed);n=rng.random((scale,scale));im=Image.fromarray((n*255).astype('uint8'));return np.asarray(im.resize((16,16),Image.Resampling.BILINEAR))/255-.5

def shade(m,x,y):
 # Broad contiguous shade patches and a lit middle, as in the reference skins.
 xx=x/15;yy=y/15
 v=.52+.18*(1-yy)-.12*xx+.12*math.cos((xx-.25)*math.pi)*math.sin(yy*math.pi)
 v+=noise[m][y,x]*.27+fine[m][y,x]*.075
 # Material structure stays within the same hue ramp.
 if m in [1,16]:
  phase=(y+int(1.4*math.sin(x*.35)))%5
  v+=.075 if phase==1 else -.09 if phase==4 else 0
 if m==3:
  # Several folded ridges, with a dark crease beside each pale fold.
  ridge=(x+int(1.6*math.sin(y*.55)))%6
  v+=-.17 if ridge==0 else .11 if ridge==2 else .035 if ridge==3 else 0
 if m==2:
  v+=-.085 if (x+int(y*.15))%9==0 else .04 if x%7==3 else 0
 if m==6:
  v+=-.09 if (x+int(y*.5))%11==2 else .045 if (x+y)%7==3 else 0
 if m in [7,8,15]:
  v+=-.11 if (x+int(math.sin(y*.4)*2))%12==4 else .07 if (x+y//5)%9==2 else 0
 if m in [9,10,11]:
  v+=.08 if (y+x//7)%6==2 else -.10 if (y+x//7)%6==5 else 0
 if m in [5,12,17,19]:v+=.025*math.sin(x*.7+y*.2)
 return max(0,min(1,v))
noise=[smoothnoise(2900+m,4)for m in range(20)];fine=[smoothnoise(5900+m,8)for m in range(20)]
im=Image.new('RGBA',(64,80));stats=[]
for m,palette in enumerate(ramps):
 patch=[]
 for y in range(16):
  for x in range(16):
   v=shade(m,x,y);a,b=(palette[0],palette[1])if v<.5 else(palette[1],palette[2]);t=v*2 if v<.5 else(v-.5)*2
   # Four gentle steps per half-ramp keep the pixel clusters deliberate.
   t=round(t*5)/5
   c=tuple(int(round(a[k]+(b[k]-a[k])*t))for k in range(3));im.putpixel(((m%4)*16+x,(m//4)*16+y),c+(255,));patch.append(c)
 stats.append({'material':m,'unique_colors':len(set(patch)),'luminance_std':float(np.std(np.array(patch)@np.array([.2126,.7152,.0722])))})
im.save(r/'anatomy29.png');(r/'texture-stats.json').write_text(json.dumps(stats,indent=2)+'\n');(r/'ramps.json').write_text(json.dumps(ramps,indent=2)+'\n')
# Side-by-side inspection of the old atlas against the new same-size atlas.
old=Image.open(r.parent/'procedural27/anatomy27.png').convert('RGBA');comparison=Image.new('RGB',(1070,750),(22,25,26));d=ImageDraw.Draw(comparison)
d.text((20,15),'ANTERIOR: poca variacion visible',fill=(220,220,210));d.text((550,15),'NUEVO: rampas tonales y detalle de tejido',fill=(220,220,210))
comparison.paste(old.resize((480,600),Image.Resampling.NEAREST),(20,50));comparison.paste(im.resize((480,600),Image.Resampling.NEAREST),(550,50));d.text((20,680),'Misma geometria, materiales y resolucion del atlas. Cambian las texturas y el muestreo UV.',fill=(200,200,190))
comparison.save(r/'output/Comparacion-texturas-29.png')
print('Generated 20 tonal ramps, atlas 64x80, with clustered tissue detail.')
