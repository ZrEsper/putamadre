from pathlib import Path
import json,zipfile,hashlib
r=Path(__file__).resolve().parent;o=r/'output';g=next(o.glob('zomboid*.jar'));npc=next(o.glob('tacznpcs*.jar'))
# Replace unpublished draft archives so no obsolete .29 build can be installed accidentally.
for p in o.glob('*.zip'):p.unlink()
(o/'LEEME.txt').write_text('''GORE .29 + TACZ NPCs .30 — anatomía, texturas TZP y quemaduras
Minecraft NeoForge 1.21.1

INSTALACIÓN
Cierra el juego y el servidor. Reemplaza el JAR de zomboid-zombie-gore por el .29 de este ZIP y el JAR de tacznpcs tactical.29 por tactical.30 de este ZIP. Instala ambos archivos nuevos en todos los clientes y en el servidor. Retira las versiones anteriores; no dejes duplicados.
Conserva ragdollified corpse-no-shot-push.23, Splatter blood-budget.2 y tus packs de texturas. Este ZIP contiene dos JARs; no es un datapack ni un resource pack.

TEXTURAS Y OJOS
Veinte materiales internos con sombras, tonos medios y luces de la misma familia de color. Fibras musculares, pliegues del cerebro y matices de hueso y órganos; atlas de 64x80. Las caras pequeñas usan una zona mayor del atlas para que el detalle no se reduzca a uno o dos texeles. Paleta comparada con las skins del TZP enviado.
Los ojos, iris, pupilas y reflejos retroceden 1,44 píxeles de modelo. Se elimina también la salida de los ojos en los estados antiguos de lesión. Un ojo sano permanece dentro de la skin.

MOVIMIENTO Y DESPRENDIMIENTO
El tejido expuesto puede moverse suavemente con la actividad y asentarse al morir. Ojos, lengua, cerebro, pulmones, corazón, hígado, estómago e intestinos pueden soltarse al destruir su soporte. La malla unida deja de dibujar el órgano desprendido; las piezas usan el límite compartido de 48 restos físicos. El balanceo y desplazamiento son secundarios y acotados, no una simulación médica de tejidos blandos.

QUEMADURAS
La exposición acumulada al fuego progresa por cuatro grados: enrojecimiento desde 1 segundo, ampollas desde 5 segundos, ennegrecimiento desde 11 segundos y carbonización profunda desde 18 segundos. Los grados se conservan al apagar el fuego y pasan al cadáver. Se aplica sobre la textura original y la anatomía; el daño de fuego sigue perteneciendo a Minecraft y a los mods de salud. No simula combustión adicional de un ragdoll ya creado.

TACZ NPCs
TaCZ NPCs .30 incorpora un puente opcional a Gore .29. Las heridas de bala, incisiones, contusiones y quemaduras tienen datos propios del NPC, sincronizados con los clientes y guardados al recargar. Su modelo de jugador se vincula al NPC real para mostrar las lesiones. El paquete de muerte conserva heridas y quemaduras cuando Ragdollified crea su cuerpo. Las piernas dañadas reducen la movilidad; los daños anatómicos extremos en cabeza o torso pueden ser letales.
Se conservan el código original de decisiones, coberturas y armas, y el balance de daño entrante de TaCZ NPCs/First Aid. Los NPCs no reciben la resistencia extra de los zombis. El puente no depende obligatoriamente de Gore y se comprueba también su carga sin ese mod. Esto amplía el gore visible de los NPCs; no reemplaza el menú médico de First Aid.

VALIDACIÓN Y LÍMITES
Pasan las regresiones de geometría, torso, impactos, sangre, cadáveres y protocolo; también las pruebas nuevas de ojos retraídos, movimiento/desprendimiento, tintado de quemaduras, sincronización y guardado de NPCs, y el puente opcional sin Gore. La comparación de bytecode confirma que la IA y las armas del NPC permanecen intactas. Los identificadores de sincronización se registran en la inicialización estática, antes de crear el array de datos de cada NPC.
No se ha ejecutado Minecraft en este entorno. Las imágenes incluidas son vistas técnicas de las mallas/UV exportadas del JAR, no capturas del juego; falta verificar visualmente iluminación, shaders y animaciones reales del modpack.
''',encoding='utf-8')
files=[{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size}for p in [g,npc]]
(o/'manifest.json').write_text(json.dumps({'patch':29,'parent_release':28,'files':files,'ragdoll_unchanged':'corpse-no-shot-push.23','splatter_unchanged':'blood-budget.2','protocol':'18-trauma28','matching_client_server_jars_required':True,'minecraft_runtime_tested':False,'changes':['TZP tonal tissue textures and wider UV sampling','recessed eyes including legacy wounds','exposed tissue movement and severable organs','four persistent burn grades','optional synchronized TaCZ NPC anatomy with save/reload and death snapshot']},indent=2)+'\n')
with zipfile.ZipFile(o/'Gore-29-Anatomia-NPCs-Quemaduras.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in [g,npc,o/'LEEME.txt',o/'manifest.json',o/'test-results.json',o/'Antes-Despues-TZP-29.png',o/'Comparacion-texturas-29.png']:z.write(p,p.name)
with zipfile.ZipFile(o/'Gore-29-Fuentes-y-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for root in ['src','npc-src','tests','fixtures']:
  for p in (r/root).rglob('*'):
   if p.is_file():z.write(p,p.relative_to(r))
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.java','.png']and p.name!='publish.py':z.write(p,p.name)
 for p in [r/'ramps.json',r/'texture-stats.json',o/'LEEME.txt',o/'test-results.json']:z.write(p,p.name)
for p in o.glob('*.zip'):
 with zipfile.ZipFile(p)as z:assert z.testzip()is None
upload=[]
for p in sorted(o.iterdir()):
 if p.is_file():b=p.read_bytes();upload.append({'local':str(p),'path':'releases/gore29/'+p.name,'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
(r/'upload.json').write_text(json.dumps(upload,indent=2))
p=r/'publish.py';s=p.read_text();start=s.index("input=b'")+len("input=b'");end=s.index("\\n'",start);s=s[:start]+'Add TZP tissue gradients, recessed and moving organs, progressive burns and optional synchronized TaCZ NPC anatomy'+s[end:];p.write_text(s)
print(json.dumps({'files':files,'bundle':'Gore-29-Anatomia-NPCs-Quemaduras.zip'},indent=2))
