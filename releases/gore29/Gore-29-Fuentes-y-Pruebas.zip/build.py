from pathlib import Path
import subprocess,zipfile,json,hashlib
r=Path(__file__).resolve().parent;old=next((r.parent/'procedural28/output').glob('zomboid*.jar'));classes=r/'build/classes';classes.mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(old)+':'+str(r.parent/'procedural28/build/test'),'-d',str(classes),*map(str,(r/'src').rglob('*.java'))],check=True)
exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{x}=ALL-UNNAMED'for x in ['', '.tree','.tree.analysis']]
subprocess.run(['java',*exports,'com.sun.tools.javac.Main',*exports,'-d',str(r/'build/tools'),str(r/'Patch.java')],check=True)
intermediate=r/'build/patched.jar'
subprocess.run(['java',*exports,'-cp',str(r/'build/tools'),'Patch',str(old),str(classes),str(intermediate)],check=True)
with zipfile.ZipFile(intermediate)as z:e={n:z.read(n)for n in z.namelist()}
for p in classes.rglob('*.class'):e[p.relative_to(classes).as_posix()]=p.read_bytes()
e['assets/zomboid_gore/textures/entity/anatomy27.png']=(r/'anatomy29.png').read_bytes()
e['META-INF/neoforge.mods.toml']=e['META-INF/neoforge.mods.toml'].replace(b'Gore .28',b'Gore .29')
e['META-INF/zomboid-textures29.json']=json.dumps({'patch':29,'texture_size':[64,80],'materials':20,'change':'TZP tonal gradients, recessed eyes, exposed-organ movement and detachment, four persistent burn grades, synchronized TaCZ NPC injuries','npc_companion':'tactical.30-visible-injuries-burns','debris_cap':48,'protocol_unchanged':'18-trauma28','minecraft_runtime_tested':False}).encode()
g=r/'output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-anatomy-npcs-burns.29.jar'
with zipfile.ZipFile(g,'w',zipfile.ZIP_DEFLATED)as z:
 for n,b in sorted(e.items()):z.writestr(n,b)
print(g)

subprocess.run(['java',*exports,'com.sun.tools.javac.Main',*exports,'-d',str(r/'build/tools'),str(r/'NpcPatch.java')],check=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-d',str(r/'build/npc'),*map(str,(r/'npc-src').rglob('*.java'))],check=True)
npc=r.parent.parent/'attachments/1cf71ce5-e3bc-41ab-a68b-05ce5dc75461/tacznpcs-2.1.0-1.21.1-tactical.29-committed-decisions.jar'
subprocess.run(['java',*exports,'-cp',str(r/'build/tools'),'NpcPatch',str(g),str(r/'build/npc-gore.jar'),str(npc),str(r/'build/npc'),str(r/'output/tacznpcs-2.1.0-1.21.1-tactical.30-visible-injuries-burns.jar')],check=True)
g.write_bytes((r/'build/npc-gore.jar').read_bytes())
