package mod.cdv.tnpc.tactical;
/** Optional bridge: no dependency on Gore when the mod is absent. */
public final class GoreCompat30 {
 static Class<?> bridge;static boolean checked;
 static Class<?> bridge(){if(!checked){checked=true;try{bridge=Class.forName("dev.zomboid.gore.Npc29");}catch(ClassNotFoundException absent){}}return bridge;}
 public static void register(){call("register",new Class<?>[0]);}
 public static void define(Object builder){call("define",new Class<?>[]{Object.class},builder);}
 public static void save(Object n,Object tag){call("save",new Class<?>[]{Object.class,Object.class},n,tag);}
 public static void restore(Object n,Object tag){call("restore",new Class<?>[]{Object.class,Object.class},n,tag);}
 static void call(String name,Class<?>[]types,Object...args){Class<?>c=bridge();if(c==null)return;try{c.getMethod(name,types).invoke(null,args);}catch(ReflectiveOperationException e){Throwable cause=e instanceof java.lang.reflect.InvocationTargetException?e.getCause():e;throw new IllegalStateException("TaCZ NPC Gore compatibility: "+name,cause);}}
}
