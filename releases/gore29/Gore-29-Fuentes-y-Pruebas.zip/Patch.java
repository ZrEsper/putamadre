import java.nio.file.*;import java.util.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;import jdk.internal.org.objectweb.asm.tree.analysis.*;
public class Patch implements Opcodes{
 static String G="dev/zomboid/gore/";
 static void tail(MethodNode m,String owner,String method,int slot){for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN){var l=new InsnList();l.add(new VarInsnNode(ALOAD,slot));l.add(new MethodInsnNode(INVOKESTATIC,G+owner,method,"(Ljava/lang/Object;)V",false));m.instructions.insertBefore(n,l);}}
 public static void main(String[]a)throws Exception{Map<String,byte[]>e=new TreeMap<>();try(var z=new ZipFile(a[0])){for(var item:Collections.list(z.entries()))e.put(item.getName(),z.getInputStream(item).readAllBytes());}int hooks=0;
 for(String path:List.of(G+"Skin12.class",G+"Gore.class")){ClassNode c=new ClassNode();new ClassReader(e.get(path)).accept(c,0);for(var m:c.methods){
 if(c.name.endsWith("Gore")&&m.name.equals("tick")){tail(m,"Burn29","tick",0);hooks++;}
 if(c.name.endsWith("Skin12")&&m.name.equals("living")){tail(m,"Organ29","living",1);hooks++;}
 if(c.name.endsWith("Skin12")&&m.name.equals("ragdoll")){tail(m,"Organ29","ragdoll",0);hooks++;}
 if(c.name.endsWith("Skin12")&&m.name.equals("end")){for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN){var l=new InsnList();l.add(new MethodInsnNode(INVOKESTATIC,G+"Organ29","end","()V",false));l.add(new MethodInsnNode(INVOKESTATIC,G+"Burn29","end","()V",false));m.instructions.insertBefore(n,l);}hooks++;}
 if(c.name.endsWith("Skin12")&&m.name.equals("renderSurface19")){
  var entry=new InsnList();entry.add(new VarInsnNode(ALOAD,0));entry.add(new MethodInsnNode(INVOKESTATIC,G+"Organ29","prepare","(Ljava/lang/Object;)V",false));entry.add(new VarInsnNode(ALOAD,0));entry.add(new MethodInsnNode(INVOKESTATIC,G+"Burn29","prepare","(Ljava/lang/Object;)V",false));m.instructions.insert(entry);
  int material=-1;for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode i&&i.owner.equals(G+"Mesh12$Quad")&&i.name.equals("material")){var next=n.getNext();while(next!=null&&next.getOpcode()<0)next=next.getNext();if(next instanceof VarInsnNode v&&v.getOpcode()==ISTORE)material=v.var;}
  if(material<0)throw new AssertionError("material local");for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode i&&i.owner.equals("com/mojang/blaze3d/vertex/VertexConsumer")){if(i.name.equals("addVertex")&&i.desc.startsWith("(Lcom/mojang/blaze3d/vertex/PoseStack$Pose;")){m.instructions.insertBefore(n,new VarInsnNode(ILOAD,material));i.setOpcode(INVOKESTATIC);i.owner=G+"Organ29";i.name="vertex";i.desc="(Lcom/mojang/blaze3d/vertex/VertexConsumer;Lcom/mojang/blaze3d/vertex/PoseStack$Pose;FFFI)Lcom/mojang/blaze3d/vertex/VertexConsumer;";i.itf=false;hooks++;}else if(i.name.equals("setColor")&&i.desc.equals("(I)Lcom/mojang/blaze3d/vertex/VertexConsumer;")){var l=new InsnList();l.add(new VarInsnNode(ILOAD,material));l.add(new MethodInsnNode(INVOKESTATIC,G+"Burn29","color","(II)I",false));m.instructions.insertBefore(n,l);hooks++;}}
 }
 }ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);e.put(path,w.toByteArray());}
 if(hooks!=6)throw new AssertionError("hooks="+hooks);
 try(var walk=Files.walk(Path.of(a[1]))){for(var p:walk.filter(p->p.toString().endsWith(".class")).toList())e.put(Path.of(a[1]).relativize(p).toString(),Files.readAllBytes(p));}
 int verified=0;for(var item:e.entrySet())if(item.getKey().endsWith(".class")&&item.getKey().startsWith(G)){ClassNode c=new ClassNode();new ClassReader(item.getValue()).accept(c,0);for(var m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);verified++;}
 try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(a[2])))){for(var item:e.entrySet()){z.putNextEntry(new ZipEntry(item.getKey()));z.write(item.getValue());z.closeEntry();}}
 System.out.println("ORGAN_BURN_RENDER_HOOKS="+hooks+" VERIFIED_GORE_CLASSES="+verified);
 }
}
