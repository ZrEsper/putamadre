from pathlib import Path
import ast,json,math
import numpy as np
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).resolve().parent
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def font(n):return ImageFont.truetype(fontpath,n)
# Use the same small software renderer and the actual exported quads/UVs for each JAR.
source=(r.parent/'procedural27/preview.py').read_text();tree=ast.parse(source)
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='render'],type_ignores=[]),filename='<mesh-preview>',mode='exec'))
old=json.loads((r.parent/'procedural27/anatomy-mesh.json').read_text());new=json.loads((r/'anatomy-mesh.json').read_text())
canvas=Image.new('RGB',(1400,900),(21,25,26));d=ImageDraw.Draw(canvas);d.text((25,20),'GORE .29 · texturas interiores junto a TZP',font=font(29),fill=(224,219,201));d.text((25,65),'Vista técnica de las mallas y UV del JAR. No es una captura de Minecraft.',font=font(17),fill=(161,171,167))
exclude=['cranial_roof','forehead','temporal_left','temporalis']
for i,(name,data,path)in enumerate([('Anterior .28',old,r.parent/'procedural27/anatomy27.png'),('Nuevo .29',new,r/'anatomy29.png')]):
 tex=np.asarray(Image.open(path).convert('RGB'));head=render(data['0'],size=(470,430),yaw=.22,pitch=.38,exclude=exclude,scale=38);body=render(data['6'],size=(260,290),yaw=.18,pitch=.05,exclude=['pectoral','abdominal_wall'],scale=22)
 x=20+i*485;d.text((x,110),name,font=font(24),fill=(224,210,183));canvas.paste(head,(x,150));canvas.paste(body,(x+110,585))
d.text((1010,110),'Referencia TZP',font=font(24),fill=(224,210,183))
ref=Image.open(r/'reference/zombie149.png').convert('RGBA');face=ref.crop((8,8,16,16));body=ref.crop((20,20,28,32));canvas.paste(face.resize((240,240),Image.Resampling.NEAREST),(1045,170),face.resize((240,240),Image.Resampling.NEAREST));canvas.paste(body.resize((240,360),Image.Resampling.NEAREST),(1045,445),body.resize((240,360),Image.Resampling.NEAREST));d.text((1010,830),'Texturas del pack recibido',font=font(17),fill=(175,183,175))
canvas.save(r/'output/Antes-Despues-TZP-29.png')
