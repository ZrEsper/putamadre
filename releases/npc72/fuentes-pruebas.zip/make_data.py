import json,pathlib,copy
r=pathlib.Path(__file__).parent
old=json.loads((r/'data/phase2-original.json').read_text())
ui=old['ui'];ui.pop('personality',None);ui['intro']='Me llamo {name}.'
ui.update(example_usage='Uso: /npcexample <voz> <encuentro|tension|necesidad>. Requiere permiso de operador y charla activa.',waiting='El superviviente todavía está hablando.',no_choice='No quedan respuestas disponibles para esta conversación.',limit='Ya hablamos suficiente por ahora.',limit_second='Sigamos cada uno por su lado.',personal_reservado='Eso prefiero guardármelo.')
voices=[
 ('seco','Seco',['Frases muy cortas','Desconfía y va directo'],['Mira.','Ya.','Corta.'],['Humor','Explicaciones emocionales'],0),
 ('cansado','Cansado',['Lento y resignado','Humor apagado'],['…Bueno.','Da igual.','Qué más da.'],['Entusiasmo','Gritos prolongados'],1),
 ('sarcastico','Sarcástico',['Ironía para tapar miedo','Burla ligera'],['Genial.','Qué sorpresa.','Claro, claro.'],['Solemnidad','Sinceridad inicial'],2),
 ('religioso','Religioso',['Fe y esperanza','Sereno hasta que se altera'],['Dios nos mira.','Todo tiene un motivo.'],['Sarcasmo','Vulgaridad habitual'],0),
 ('educado','Educado',['Formal incluso bajo amenaza','Mantiene las formas'],['Por favor.','Disculpe.','Le ruego.'],['Jerga','Groserías habituales'],0),
 ('aterrado','Aterrado',['Frases cortadas','Ruega y quiere huir'],['N-no…','Por favor.','¡No!'],['Humor','Amenazas largas'],1),
 ('veterano','Veterano',['Calma y experiencia','Autoridad tranquila'],['Escucha.','Créeme.','Así funciona esto.'],['Nerviosismo','Gritos'],1),
 ('joven','Joven',['Impulsivo','Bravuconería insegura'],['Oye.','¿En serio?','Ni de broma.'],['Formalidad','Serenidad constante'],2)]
root={'schema':2,'config':{'pausa_lineas_ticks':30,'confianza_media':30,'confianza_alta':60,'tregua_ticks':1200,'salida_segura_ticks':200},'ui':ui,'categorias':{'comida':['minecraft:bread','minecraft:apple','minecraft:cooked_beef','minecraft:cooked_porkchop','minecraft:baked_potato','minecraft:carrot'],'medicina':['firstaid:bandage','firstaid:plaster','firstaid:splint','firstaid:morphine'],'municion':['tacz:ammo','minecraft:arrow']},'voces':[],'historias':{},'encuentros':[]}
for vid,name,traits,phrases,avoid,level in voices:root['voces'].append(dict(id=vid,nombre=name,descripcion='; '.join(traits)+'.',rasgos=traits,muletillas=phrases,evita=avoid,ejemplos=[phrases[0]],groserias_nivel=level,respaldo=vid not in ['seco','cansado']))
for vid,relative,role,obj,home,job,mate,can in [
 ('seco','Mateo','mi hermano','una llave con una cinta azul','un depósito junto al canal','encargado de almacén','Inés',True),
 ('cansado','Elena','mi madre','una pulsera de hilo','una clínica cerrada cerca del puente','electricista','Andrés',False),
 ('respaldo','Rosa','alguien de mi familia','una fotografía doblada','un refugio al norte','trabajador de mantenimiento','Daniel',False)]:
 root['historias'][vid]={'puede_mentir':can,'miente':False,'datos':dict(familiar_nombre=relative,familiar_rol=role,objeto_personal=obj,lugar_hogar=home,profesion_pasada=job,companero_nombre=mate)}
def fx(**kwargs):return kwargs
def cond(minimum=None,**kw):
 if minimum is not None:kw['medidores']={'confianza':{'min':minimum}}
 return kw
def item(cat,count=1):return {'categoria':cat,'cantidad':count}
def reply(lines,effects=None,next=None,condition=None):
 d={'lineas_npc':lines,'efectos':effects or {},'siguiente':next}
 if condition is not None:d['condicion']=condition
 return d
def opt(id,text,tone,responses,requires=None):
 d={'id':id,'texto':text,'tono':tone,'respuestas':responses}
 if requires is not None:d['requiere']=requires
 return d
def silence(v,sit,node):
 if v=='seco':lines=['Terminó la espera.','No voy a insistir otra vez.']
 else:lines=['…Bueno. Parece que prefieres quedarte callado.','Yo no puedo seguir esperando.']
 return {'lineas':lines,'efectos':fx(hostilidad=15,resultado='ruptura_combate' if sit=='tension' else 'separacion_pacifica')}
def node(id,lines,options,v,sit):return {'id':id,'lineas_npc':lines,'opciones':options,'reaccion_silencio':silence(v,sit,id)}
def leave(v):
 lines=['Ya. Vete despacio.','No te seguiré.'] if v=='seco' else ['…Bueno. Ve con cuidado.','Hoy ya tuvimos bastante.']
 return opt('retirarse','Voy a retirarme despacio.',2,[reply(lines,fx(resultado='separacion_pacifica'))])
def threat(v):
 lines=['Mala decisión.','La conversación terminó.'] if v=='seco' else ['No me queda paciencia para esto.','Si quieres empeorarlo, allá tú.']
 return opt('amenazar','Dame lo que llevas o habrá problemas.',4 if v=='seco' else 5,[reply(lines,fx(confianza=-25,hostilidad=25,evento_memoria='amenazó para quitarle sus cosas',resultado='ruptura_combate'))])
# Complete branches: 3-5 conversational turns on substantive paths; peaceful/aggressive exits may finish early.
for v in ['seco','cansado']:
 for sit in ['encuentro','tension','necesidad']:
  dry=v=='seco'
  openings={
   ('seco','encuentro'):['Alto. Quédate ahí.','Mira. Podemos hablar sin acercarnos.'],
   ('seco','tension'):['Te vi salir.','Las manos quietas. No pruebes suerte.','Di qué buscas.'],
   ('seco','necesidad'):['No me toques.','La herida no te da permiso para acercarte.','Habla desde ahí.'],
   ('cansado','encuentro'):['Espera un segundo.','No tengo ganas de pelear con otro desconocido.','Hablemos desde ahí. Ya he tenido un día de mierda.'],
   ('cansado','tension'):['Te vi. No sigas avanzando.','No he descansado bien y cualquier ruido me hace levantar el arma.','No quiero cometer otra estupidez. Mierda…'],
   ('cansado','necesidad'):['Si vienes por mis cosas, llegas tarde.','Casi no me queda nada. Y me cuesta mantenerme de pie.','…Bueno. Qué día de mierda. Dime qué quieres.']}
  explanation={
   ('seco','encuentro'):['Busco suministros.','Hay alguien esperando. No daré nombres todavía.','¿Puedes ayudar o no?'],
   ('seco','tension'):['Me falta medicina.','No voy a contarte a quién se la llevo.','Primero demuestra que no vienes a quitarme lo poco que queda.'],
   ('seco','necesidad'):['Necesito vendar esto.','Y comer. En ese orden.','No te estoy pidiendo que te acerques.'],
   ('cansado','encuentro'):['Salí a buscar medicina. No encontré gran cosa.','Tengo a alguien esperando y ya no sé qué decirle cuando vuelva.','No te pido que cargues con eso. Solo que no lo empeores, joder.'],
   ('cansado','tension'):['Hay alguien contando conmigo. Por eso sigo aquí.','No voy a darte su nombre mientras no sepa qué quieres.','Joder… qué cansancio tener que explicar hasta eso.'],
   ('cansado','necesidad'):['La venda ya no sirve y no he comido desde ayer.','Me senté un minuto y después no pude levantarme.','Maldita sea. Si tienes algo útil, puedo escucharte.']}
  calm=['Ya. Entendido.','Quedarte ahí ayuda.','Ahora escucha.'] if dry else ['…Bueno. Eso está mejor.','No hace falta que ninguno se haga el valiente.','Pregúntame lo que quieras.']
  talk=opt('preguntar','Soy {player}. ¿Cómo te llamas y qué estás buscando?',1,[reply(['{name}.']+explanation[v,sit],fx(confianza=5,revela=['nombre','necesidad_actual']), 'necesidad')])
  identify=opt('presentarse','Soy {player}. ¿Y tú?',1,[reply(['{name}.','El nombre no cambia nada.','Dime a qué vienes.'] if dry else ['Me llamo {name}.','Hace días que nadie me pregunta sin querer algo después.','…Bueno. Te escucho.'],fx(confianza=3,revela=['nombre']),'entrada')])
  passopt=opt('pasar','Solo estoy pasando. No busco problemas.',1,[reply(['Puedes pasar.','Sin acercarte a mis cosas.'] if dry else ['Está bien. Sigue tu camino.','No voy a hacerte perder más tiempo.'],fx(confianza=10,resultado='separacion_pacifica'),condition=cond(30)),reply(calm,fx(miedo=5),'entrada')])
  # Node 1 has a conditional food offer, no disclosure below medium trust.
  food_offer=opt('ofrecer_comida','Tengo comida. ¿Te sirve?',2,[reply(['Sí. La necesito.','Puedes darme una ración. Nada de acercarte de golpe.'] if dry else ['…Mierda, sí. Una ración me vendría bien.','Pero no quiero prometerte algo que no pueda devolver.'],{},'comida')],{'inventario':[item('comida')]})
  n1=node('entrada',openings[v,sit],[talk,passopt,food_offer,threat(v)],v,sit)
  medlines=['Acepto.','{familiar_nombre} es {familiar_rol}. Le llevo esto.','Antes era {profesion_pasada}. Eso ya no sirve de mucho.'] if dry else ['…No me jodas. No esperaba que de verdad fueras a dármela.','{familiar_nombre} es {familiar_rol}. Está esperando en {lugar_hogar}.','Yo era {profesion_pasada}. Arreglaba cosas. Ahora no sé ni por dónde empezar.']
  medicine=opt('dar_medicina','Puedo darte una medicina.',1,[reply(medlines,fx(confianza=30,desesperacion=-25,quita_item=item('medicina'),revela=['nombre','familia','profesion_pasada','lugar_hogar'],evento_memoria='recibió medicina para su familiar'),'cierre')],{'inventario':[item('medicina')]})
  listenlines=['Quieres escuchar. Bien.','Todavía no voy a dar nombres.','Dime qué puedes ofrecer de verdad.'] if dry else ['Es raro que alguien se quede a escuchar.','No sé si me siento mejor, pero gracias por intentarlo.','No quiero hablar de mi familia todavía.']
  listen=opt('escuchar','No tengo medicina, pero puedo escucharte.',1,[reply(listenlines,fx(confianza=5,evento_memoria='lo escuchó sin exigir nada'),'cierre')])
  doubt=opt('dudar','¿Cómo sé que no estás mintiendo?',3,[reply(['Me descubriste.','No había nadie esperando. Quería que bajaras la guardia.'] if dry else ['Sí. Mentí con lo de la medicina.','Pensé que así me dejarías en paz. Fue una estupidez.'],fx(revela=['mentira'],evento_memoria='descubrió una mentira'),'duda',{'miente':True}),reply(['No lo sabes.','Tampoco voy a ganarme tu confianza contando mi vida.','Corta con eso.'] if dry else ['No tienes cómo saberlo.','Pero no pienso enseñarte lo que me queda para convencerte.','Maldita sea. Estoy cansado, no actuando.'],fx(confianza=-15,hostilidad=10),'duda')])
  n2=node('necesidad',explanation[v,sit],[medicine,listen,doubt,leave(v)],v,sit)
  foodgive=opt('dar_comida','Toma una ración. No te pido nada.',1,[reply(['Bien.','Esto alcanza por hoy.','No olvidaré quién la dio.'] if dry else ['…Gracias. De verdad.','Ya casi había olvidado lo que era no pedir algo a cambio.','Déjame guardarla antes de que se me caiga.'],fx(confianza=15,desesperacion=-10,quita_item=item('comida'),evento_memoria='compartió una ración'),'cierre')],{'inventario':[item('comida')]})
  bargain=opt('intercambio','¿Tienes algo para intercambiar?',2,[reply(['No voy a negociar a ciegas.','Hoy no habrá trato. Podemos terminar sin pelear.'] if dry else ['Tendría que revisar lo que me queda.','Hoy no puedo ofrecerte un intercambio justo. Dejémoslo por ahora.'],{},'cierre')])
  n3=node('comida',['Una ración sirve.','Decide sin acercarte.'] if dry else ['La comida me ayudaría a pensar un poco mejor.','No voy a arrebatártela. Puedes decir que no.'],[foodgive,bargain,leave(v)],v,sit)
  apology=opt('disculparse','Me pasé. No tenía que decirlo así.',1,[reply(['Ya.','Podemos terminar aquí sin más.'] if dry else ['…Bueno. No eres el primero que duda.','Tampoco tengo fuerzas para seguir discutiendo.'],fx(confianza=5),'cierre')])
  insist=opt('insistir','Sigo sin creerte.',3,[reply(['Entonces termina esto.','Sigue tu camino.'] if dry else ['No voy a convencerte repitiendo lo mismo.','Vete. Prefiero quedarme solo.'],fx(confianza=-10,hostilidad=10,resultado='separacion_pacifica'))])
  n4=node('duda',['¿Algo más?','No voy a explicarme otra vez.'] if dry else ['Ya escuchaste mi respuesta.','No quiero convertir esto en otra pelea.'],[apology,insist,leave(v)],v,sit)
  personal=opt('familia','¿Quién sigue contando contigo?',1,[reply(['{familiar_nombre}. Es {familiar_rol}.','Se quedó en {lugar_hogar}.','Eso no se lo cuentes a nadie.'] if dry else ['{familiar_nombre}, {familiar_rol}.','Todavía me guarda un lugar en {lugar_hogar}.','Pensar en volver es lo único que me hace caminar algunos días.'],fx(revela=['familia','lugar_hogar'],evento_memoria='compartió a quién quiere volver a ver',resultado='acuerdo'))],cond(30))
  itemstory=opt('recuerdo','¿Por qué guardas ese objeto?',2,[reply(['Es {objeto_personal}.','Me lo dio {companero_nombre}.','Ya sabes suficiente.'] if dry else ['Es {objeto_personal}. No vale nada para nadie más.','{companero_nombre} me lo dio antes de separarnos.','Todavía no sé si voy a volver a verlo.'],fx(revela=['objeto_personal','companero'],resultado='acuerdo'))],cond(60))
  truce=opt('tregua','No nos ataquemos. Cada uno sigue su camino.',2,[reply(['De acuerdo.','No rompas tu palabra.'] if dry else ['Sí. Me sirve que esto termine sin otro muerto.','Cuídate. Lo digo en serio.'],fx(confianza=3,evento_memoria='acordaron no atacarse',resultado='tregua'))])
  n5=node('cierre',['Podemos terminar.','O preguntar una cosa más.'] if dry else ['Creo que ya podemos bajar un poco la guardia.','Dime una cosa más y después seguimos.'],[personal,itemstory,truce,leave(v)],v,sit)
  root['encuentros'].append(dict(id=f'{v}_{sit}',voz=v,situacion=sit,peso=1,historia=v,inicio='entrada',turnos_max=5,nodos=[n1,n2,n3,n4,n5]))
# Six minimal fallbacks. Distinct voices, no full biography or long quest written prematurely.
fallbacks={
 'sarcastico':[['Genial. Alguien más con prisa.','Podemos hablar sin hacer ninguna tontería, qué concepto.'],['Claro, claro. Los dos estamos de paso.','Por una vez me gustaría que eso fuera verdad.'],['Qué sorpresa. Una charla sin disparos.','Conservemos esa costumbre tan rara.']],
 'religioso':[['Detente un momento, hermano.','Podemos entendernos sin derramar sangre.'],['Todo tiene un motivo.','Espero que el tuyo no sea hacernos daño.'],['Que encuentres un camino seguro.','Yo seguiré el mío sin buscarte problemas.']],
 'educado':[['Disculpe, no se acerque más, por favor.','Podemos hablar desde esa distancia.'],['Le agradezco que mantenga la calma.','No deseo que esto termine mal.'],['Entonces no le quitaré más tiempo.','Le ruego que mantengamos lo acordado.']],
 'aterrado':[['N-no te acerques.','Solo quiero hablar. Por favor.'],['Está bien… estás ahí.','Yo me quedo aquí. N-no hace falta pelear.'],['¿Ya puedo irme?','Por favor… no me sigas.']],
 'veterano':[['Escucha. Quédate donde pueda verte.','Hablar primero suele ahorrarnos problemas.'],['Así funciona esto: sin movimientos bruscos.','Los dos llegamos vivos hasta aquí. Cuidemos eso.'],['Créeme. Saber cuándo retirarse también cuenta.','Sigamos sin darnos motivos.']],
 'joven':[['Oye. No te acerques de golpe.','No estoy buscando pelea, ¿entendiste?'],['¿En serio solo estás pasando?','Bueno. Yo tampoco quiero armar un problema.'],['Está bien. Que quede así.','Ni de broma voy a seguirte. Tú tampoco me sigas.']]}
for v,ls in fallbacks.items():
 ns=[]
 for i in range(3):
  nextid=f'p{i+1}' if i<2 else None
  effects={} if nextid else {'resultado':'tregua'}
  answer=ls[min(i+1,2)] if i<2 else (['…Claro. Ya nos entendimos.','No alarguemos esto.'] if v=='sarcastico' else [ls[2][1],ls[0][0]])
  # Last reply uses two new lines, so anti-repetition never leaves this voice without an audible finish.
  closing={'religioso':['Vete en paz.','No alzaré mi mano contra ti.'],'educado':['Ha sido razonable de su parte.','Puede marcharse con tranquilidad.'],'aterrado':['G-gracias por no hacerme daño.','Me voy. Despacio.'],'veterano':['Buen criterio.','Mantendré mi palabra.'],'joven':['Listo. Ya quedó.','No voy a hacer ninguna tontería.'],'sarcastico':['Hasta fue agradable. Casi.','Prometo no arruinarlo siguiéndote.']}
  if i==2:answer=closing[v]
  fallback_leave=opt('retirarse','Voy a retirarme despacio.',2,[reply(closing[v],fx(resultado='separacion_pacifica'))])
  options=[opt('continuar','Podemos hablar tranquilos.' if i==0 else 'Mantengamos la distancia.' if i==1 else 'De acuerdo. Sin problemas.',1 if i==0 else 2,[reply(answer,effects,nextid)]),fallback_leave]
  sil={'lineas':closing[v],'efectos':{'resultado':'huida' if v=='aterrado' else 'separacion_pacifica'}}
  ns.append({'id':f'p{i}','lineas_npc':ls[i],'opciones':options,'reaccion_silencio':sil})
 root['encuentros'].append(dict(id=f'respaldo_{v}',voz=v,situacion='cualquiera',peso=1,historia='respaldo',inicio='p0',turnos_max=5,nodos=ns))
root['categorias']['medicina'] += ['firstaid:sterile_bandage','firstaid:medical_alcohol','firstaid:prophylactic_antibiotic','firstaid:morphine_injector','firstaid:painkillers']
root['categorias']['comida'] += ['minecraft:cooked_chicken','minecraft:cooked_mutton','minecraft:cooked_rabbit','minecraft:cooked_cod','minecraft:cooked_salmon','minecraft:melon_slice','minecraft:sweet_berries','minecraft:glow_berries','minecraft:dried_kelp','minecraft:cookie','minecraft:pumpkin_pie','minecraft:mushroom_stew','minecraft:beetroot_soup','minecraft:rabbit_stew','minecraft:beetroot','minecraft:golden_carrot','minecraft:golden_apple','minecraft:enchanted_golden_apple','minecraft:honey_bottle','minecraft:potato']
repeat_closings={
 'seco':['Corta. Estamos dando vueltas.','Cada uno por su lado.'],
 'cansado':['Ya no tengo fuerzas para repetir esto.','Mejor dejémoslo aquí.'],
 'sarcastico':['Qué bien. Conversación en círculos.','Me retiro antes de aprenderme el guion.'],
 'religioso':['Ya escuchamos lo que había que decir.','Que cada uno encuentre su camino en paz.'],
 'educado':['Disculpe, creo que estamos repitiéndonos.','Prefiero que terminemos por ahora.'],
 'aterrado':['N-no quiero seguir hablando.','Me voy. No te acerques, por favor.'],
 'veterano':['Escucha. No vamos a avanzar repitiendo lo mismo.','Dejémoslo antes de cometer un error.'],
 'joven':['Oye. Esto no está llegando a nada.','Me largo. Tú sigue por tu lado.']}
for voice in root['voces']:voice['cierre_repeticion']=repeat_closings[voice['id']]
(r/'data/dialogue-phase2.json').write_text(json.dumps(root,ensure_ascii=False,indent=2)+'\n')
