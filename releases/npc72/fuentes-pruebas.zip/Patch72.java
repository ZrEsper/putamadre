import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
public class Patch72 implements Opcodes{
 static String ROOT="mod/cdv/tnpc/tactical/",A=ROOT+"Chat71";static Map<String,Integer>hooks=new TreeMap<>();static void hook(String s){hooks.merge(s,1,Integer::sum);}static InsnList load(int...a){InsnList x=new InsnList();for(int i=0;i<a.length;i+=2)x.add(new VarInsnNode(a[i],a[i+1]));return x;}
 static void call(MethodNode m,InsnList x,String name,String desc){x.add(new MethodInsnNode(INVOKESTATIC,A,name,desc,false));m.instructions.insert(x);hook(name);}
 static void guard(MethodNode m,InsnList x,String name,String desc,int result,boolean shoot){x.add(new MethodInsnNode(INVOKESTATIC,A,name,desc,false));LabelNode no=new LabelNode();x.add(new JumpInsnNode(IFEQ,no));if(shoot){x.add(new FieldInsnNode(GETSTATIC,"com/tacz/guns/api/entity/ShootResult","COOL_DOWN","Lcom/tacz/guns/api/entity/ShootResult;"));x.add(new InsnNode(ARETURN));}else{if(result>=0)x.add(new InsnNode(result));x.add(new InsnNode(result<0?RETURN:IRETURN));}x.add(no);x.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(x);hook(name+":"+m.name);}
 public static void main(String[]a)throws Exception{Map<String,byte[]>d=new TreeMap<>();try(var z=new ZipFile(a[0])){for(var e:Collections.list(z.entries()))d.put(e.getName(),z.getInputStream(e).readAllBytes());}
 byte[] original=d.get("data/tacznpcs/dialogue/dialogue-phase2.json");
 for(String path:List.of(ROOT+"Authority70.class",ROOT+"Social.class",ROOT+"Threat27.class","mod/cdv/tnpc/entity/AutoGunOperator.class")){ClassNode n=new ClassNode();new ClassReader(d.get(path)).accept(n,0);for(var m:n.methods){
 if(n.name.endsWith("Authority70")&&m.name.equals("tick"))call(m,load(ALOAD,0),"tick","(Ljava/lang/Object;)V");
 if(n.name.endsWith("Authority70")&&m.name.equals("busy"))call(m,load(ALOAD,0),"beforeBusy","(Ljava/lang/Object;)V");
 if(n.name.endsWith("Social")&&m.name.equals("allowedPlayer")||n.name.endsWith("Threat27")&&m.name.equals("allowed"))guard(m,load(ALOAD,0,ALOAD,1),"protectedPlayer","(Ljava/lang/Object;Ljava/lang/Object;)Z",ICONST_0,false);
 if(n.name.endsWith("Threat27")&&m.name.equals("heard"))call(m,load(ALOAD,0,ALOAD,1,LLOAD,2),"heard","(Ljava/lang/Object;Ljava/lang/Object;J)V");
 if(n.name.endsWith("Threat27")&&m.name.equals("hit"))call(m,load(ALOAD,0,ALOAD,1,FLOAD,2,ILOAD,3),"hurt","(Ljava/lang/Object;Ljava/lang/Object;FZ)V");
 if(n.name.endsWith("AutoGunOperator")&&m.name.equals("shoot"))guard(m,load(ALOAD,0),"holdFire","(Ljava/lang/Object;)Z",-1,true);
 if(n.name.endsWith("AutoGunOperator")&&m.name.equals("melee"))guard(m,load(ALOAD,0),"holdFire","(Ljava/lang/Object;)Z",-1,false);
 if(n.name.endsWith("AutoGunOperator")&&m.name.equals("doHurtTarget"))guard(m,load(ALOAD,0,ALOAD,1),"protectedPlayer","(Ljava/lang/Object;Ljava/lang/Object;)Z",ICONST_0,false);
 }ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(w);d.put(path,w.toByteArray());}
 if(hooks.values().stream().mapToInt(i->i).sum()!=10)throw new Error("Hooks "+hooks);
 try(var walk=Files.walk(Path.of(a[1]))){for(var p:walk.filter(p->p.toString().endsWith(".class")).toList())d.put(Path.of(a[1]).relativize(p).toString(),Files.readAllBytes(p));}
 d.put("data/tacznpcs/dialogue/phase2-original.json",original);d.put("data/tacznpcs/dialogue/dialogue-phase2.json",Files.readAllBytes(Path.of(a[2])));String meta="META-INF/neoforge.mods.toml";d.put(meta,new String(d.get(meta),java.nio.charset.StandardCharsets.UTF_8).replaceAll("(?m)^version\\s*=\\s*\"[^\"]+\"","version=\"2.1.0-tactical.36-dialogue-branches\"").getBytes(java.nio.charset.StandardCharsets.UTF_8));int count=0;for(var e:d.entrySet())if(e.getKey().endsWith(".class")){ClassNode n=new ClassNode();new ClassReader(e.getValue()).accept(n,0);for(var m:n.methods)if((m.access&(ACC_NATIVE|ACC_ABSTRACT))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(n.name,m);count++;}try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(a[3])))){for(var e:d.entrySet()){ZipEntry ze=new ZipEntry(e.getKey());ze.setTime(0);z.putNextEntry(ze);z.write(e.getValue());z.closeEntry();}}System.out.println("VERIFIED_CLASSES="+count+" HOOKS="+hooks);
 }
}
