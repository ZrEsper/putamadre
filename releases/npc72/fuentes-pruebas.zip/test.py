from pathlib import Path
import subprocess,tempfile,json,copy,os
r=Path(__file__).parent;t=Path(os.environ.get('NPC_BUILD_TOOLS','/workspace/putamadre/hordes-melee-interiors-patch/build/tools'));asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree'])+':'+os.environ.get('NPC_ASM_COMMONS_JAR','/workspace/medical65/asm-commons.jar');ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];jar=r/'release/tacznpcs-2.1.0-1.21.1-tactical.36-dialogue-branches.jar';gson=os.environ.get('NPC_GSON_JAR','/workspace/medical63/gson.jar');tests=r/'tests'
subprocess.run(ecj+['-d',str(tests)]+list(map(str,(Path(os.environ.get('NPC_BRIGADIER_SOURCE',str(r/'brigadier-source/src/main/java' if (r/'brigadier-source').exists() else Path('/workspace/npc71/brigadier-source/src/main/java'))))).rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',str(jar)+':'+gson+':'+str(tests),'-d',str(tests)]+list(map(str,(r/'testsrc').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'Extract70.java'),str(r/'Extract71.java')],check=True)
for cls in ['Extract70','Extract71']:subprocess.run(['java','-cp',str(r/'tools')+':'+asm,cls,str(jar),str(tests)],check=True)
with tempfile.TemporaryDirectory(prefix='fixtures-',dir=r) as run:
 for cls in ['Fixtures70','Fixtures72']:subprocess.run(['java','-Xverify:all','-cp',str(tests)+':'+str(jar)+':'+gson,'mod.cdv.tnpc.tactical.'+cls],check=True,cwd=run)
# Exercise file loading in independent JVMs; static initialization cannot be faked by replacing DATA.
base=json.loads((r/'data/dialogue-phase2.json').read_text());legacy=json.loads((r/'data/phase2-original.json').read_text())
cases=['new','invalid','old_default','old_custom','new_custom','bad_command']
for case in cases:
 with tempfile.TemporaryDirectory(prefix='config-',dir=r) as run:
  cfg=Path(run)/'config/tacznpcs/dialogue-phase2.json';cfg.parent.mkdir(parents=True)
  data=None
  if case=='invalid':data=copy.deepcopy(base);data['encuentros'][0]['nodos'][0]['lineas_npc'][0]='{variable_prohibida}'
  if case=='old_default':data=legacy
  if case=='old_custom':data=copy.deepcopy(legacy);data['personalities']['cauto']['situations']['encuentro']['text']='MARCADOR PERSONAL'
  if case=='new_custom':data=copy.deepcopy(base);data['config']['pausa_lineas_ticks']=42
  if case=='bad_command':data=copy.deepcopy(base);data['encuentros'][0]['nodos'][0]['opciones'][0]['respuestas'][0]['efectos']['comando']='op @s'
  if data is not None:cfg.write_text(json.dumps(data,ensure_ascii=False));original=cfg.read_bytes()
  command=['java','-Xverify:all','-cp',str(tests)+':'+str(jar)+':'+gson,'mod.cdv.tnpc.tactical.ConfigProbe72']
  result=subprocess.run(command,cwd=run,text=True,capture_output=True,check=True)
  expected='2:12:'+('42' if case=='new_custom' else '30')+':'+('true' if case=='old_custom' else 'false')
  assert result.stdout.strip()==expected,(case,result.stdout,result.stderr)
  if case in ['invalid','bad_command']:assert 'using bundled backup' in result.stderr and cfg.read_bytes()==original
  if case=='old_default':assert json.loads(cfg.read_text())['schema']==2 and cfg.with_name('dialogue-phase2.fase2.bak.json').read_bytes()==original
  if case in ['old_custom','new_custom']:assert cfg.read_bytes()==original
  if case=='new':
   persisted=json.loads(cfg.read_text());assert persisted['encuentros'][0]['nodos'][0]['opciones'][1]['respuestas'][0]['siguiente'] is None
   second=subprocess.run(command,cwd=run,text=True,capture_output=True,check=True);assert second.stdout==result.stdout and not second.stderr
print('PASS 6 independent-JVM config cases: fresh/reload, invalid fallback, backup migration, custom legacy, custom delay and forbidden command.')
