package mod.cdv.tnpc.tactical;public class Identity20{static String name(Object npc){return ((Fixtures70.Npc)npc).name;}}
