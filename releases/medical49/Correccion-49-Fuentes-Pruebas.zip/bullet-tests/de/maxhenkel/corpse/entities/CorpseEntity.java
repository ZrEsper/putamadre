package de.maxhenkel.corpse.entities;
public class CorpseEntity{public World level(){return new World();}public Tag getPersistentData(){return new Tag();}public static class World{public boolean isClientSide;}public static class Tag{public byte[] getByteArray(String key){return new byte[]{1};}}}
