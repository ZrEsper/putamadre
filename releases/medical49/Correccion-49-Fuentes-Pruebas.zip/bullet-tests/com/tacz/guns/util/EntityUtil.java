package com.tacz.guns.util;
public class EntityUtil {public static Object result;public static Object findEntityOnPath(Object b,Object s,Object e){return result;}}
