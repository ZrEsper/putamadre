package dev.zomboid.gore;
import net.minecraft.world.phys.Vec3;import com.raiiiden.ragdollified.network.*;import com.raiiiden.ragdollified.server.ServerRagdollSyncManager;import com.tacz.guns.util.EntityUtil;
public class BulletCheck49{
 public record Hit(Object getEntity,Vec3 getHitPos){}
 public static class Vector{public float x,y,z;Vector(float a,float b,float c){x=a;y=b;z=c;}}
 public static class Quaternion{public float x,y,z,w=1;}
 public static class Pose{public Object position=new Vector(0,.95f,2),rotation=new Quaternion();}
 public static class Near extends BulletRegression46.Body{public Object pose(){return new Object[]{new Pose()};}}
 public static void main(String[]a){BulletRegression46.main(a);EntityUtil.result=new Hit(new de.maxhenkel.corpse.entities.CorpseEntity(),new Vec3(0,.95,1));var b=new BulletRegression46.Bullet();int before=RagdollImpulsePacket.sent;if(!Bullet13.tick(b)||RagdollImpulsePacket.sent!=before+1)throw new AssertionError("inventory collider blocks ragdoll shot");EntityUtil.result=new Hit(new Object(),new Vec3(0,.95,1));var opaque=new BulletRegression46.Bullet();if(Bullet13.tick(opaque)||opaque.discarded)throw new AssertionError("living entity closer to bullet must keep priority");EntityUtil.result=null;ServerRagdollSyncManager.NEAR.clear();ServerRagdollSyncManager.NEAR.add(new Near());var posed=new BulletRegression46.Bullet();if(!Bullet13.tick(posed)||!posed.discarded)throw new AssertionError("posed retained body ignored by actual tick");System.out.println("ACTUAL_BULLET_CORPSE_CONTAINER_OCCLUSION_AND_POSED_RAY=PASS");}
}
