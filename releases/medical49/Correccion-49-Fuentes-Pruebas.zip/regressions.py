from pathlib import Path
import subprocess,shutil,json
r=Path(__file__).resolve().parent;g=next((r/'output').glob('zomboid*.jar'));fa=r.parents[1]/'attachments/6797a10f-1726-4099-9665-78b18e5f2376/firstaid-1.21.1-ZOMBOID-v3.6.16-bite-class-fix.jar';npc=r.parents[1]/'attachments/5e507eca-8b5d-4001-8fa7-1237d43c9055/tacznpcs-2.1.0-1.21.1-tactical.32-corpse-guard.jar';out=r/'build/regression45';shutil.rmtree(out,ignore_errors=True);cp=':'.join(map(str,[g,fa,npc]))
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d',str(out),*map(str,(r/'src/medical45/tests').rglob('*.java'))],check=True)
p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+cp,'dev.zomboid.gore.Test45'],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode()
