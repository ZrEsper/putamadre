from pathlib import Path
import subprocess,shutil
r=Path(__file__).resolve().parent;g=next((r/'output').glob('zomboid*.jar'));fixtures=r.parents[0]/'procedural29/build/test';out=r/'build/hit-tests';shutil.rmtree(out,ignore_errors=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(g)+':'+str(fixtures),'-d',str(out),*map(str,(r/'hit-tests').rglob('*.java'))],check=True)
p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(g)+':'+str(fixtures),'dev.zomboid.gore.HitCheck49'],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode()
