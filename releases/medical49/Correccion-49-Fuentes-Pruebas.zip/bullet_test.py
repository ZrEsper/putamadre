from pathlib import Path
import subprocess,shutil
r=Path(__file__).resolve().parent;g=next((r/'output').glob('zomboid*.jar'));out=r/'build/bullet-tests';shutil.rmtree(out,ignore_errors=True)
f=[p for p in(r/'src/medical46/tests').rglob('*.java')if p.name!='EntityUtil.java']
packet=r/'src/medical46/tests/com/raiiiden/ragdollified/network/RagdollSpawnPacket.java';s=packet.read_text();s=s.replace('public boolean isBaby;','');s=s.replace('public int originalEntityId','public boolean isBaby;public int originalEntityId');packet.write_text(s)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(g),'-d',str(out),*map(str,f),*map(str,(r/'bullet-tests').rglob('*.java'))],check=True)
p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(g),'dev.zomboid.gore.BulletCheck49'],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode()
