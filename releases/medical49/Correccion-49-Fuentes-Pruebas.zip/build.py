from pathlib import Path
import zipfile,subprocess
from PIL import Image,ImageDraw
r=Path(__file__).resolve().parent
base=r.parents[1]/'attachments/965b565b-0bfa-40e1-aff3-f3aa7a60edf1/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-remains-local-cuts.32.jar'
rag=r.parents[1]/'attachments/ef982c0a-bf71-4a12-9d83-d86748d77558/ragdollified-1.21.1-1.1.5-stable-impacts-remains.25.jar'
out=r/'output';out.mkdir(exist_ok=True)
with zipfile.ZipFile(base)as z:
 import io
 old=Image.open(io.BytesIO(z.read('assets/zomboid_gore/textures/entity/medical45.png'))).convert('RGBA')
w,h=old.size;tile=w//2;im=Image.new('RGBA',(tile*3,h));im.paste(old.crop((0,0,tile,h)),(0,0));im.paste(old.crop((tile,0,w,h)),(tile*2,0));d=ImageDraw.Draw(im)
# Paired curved rows of teeth and torn skin, recognisable at the original texture resolution.
import math,random
rng=random.Random(49)
for top in (True,False):
 for j in range(7):
  x=tile+round(tile*(.18+j*.105));y=round(h*(.28 if top else .72)+(1 if top else -1)*h*.10*math.sin(j*math.pi/6));radius=max(1,tile//14)
  d.ellipse((x-radius,y-radius,x+radius,y+radius),fill=(112+rng.randrange(35),27,38,230));d.point((x,y),fill=(59,10,18,255))
 d.arc((tile+tile*.12,h*.18,tile+tile*.88,h*.82),0 if not top else 180,180 if not top else 360,fill=(156,49,58,180),width=max(1,tile//16))
im.save(r/'medical49.png')
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(base),'-d',str(r/'build/classes'),*map(str,(r/'src/dev').rglob('*.java'))],check=True)
flags=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ('','.tree','.tree.analysis')]
subprocess.run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(r/'build/tools'),str(r/'Patch49.java')],check=True)
subprocess.run(['java',*flags,'-cp',str(r/'build/tools'),'Patch49',str(base),str(r/'build/classes'),str(r/'medical49.png'),str(out/'zomboid-zombie-gore-1.0.20-neoforge-1.21.1-entry-wounds-armor.33.jar'),str(rag),str(out/'ragdollified-1.21.1-1.1.5-authoritative-corpses.26.jar')],check=True)
