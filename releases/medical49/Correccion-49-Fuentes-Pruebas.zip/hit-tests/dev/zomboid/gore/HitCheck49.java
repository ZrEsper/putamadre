package dev.zomboid.gore;
public class HitCheck49{
 static int checks;static void ok(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
 public static class Zombie extends BehaviorChecks28.Zombie{public float getScale(){return 1;}public float getXRot(){return 0;}public boolean isAlive(){return true;}}
 public record Bullet(Object getDeltaMovement){}
 public static void main(String[]args){Gore.accessor=new Object();Cuts24.accessor=new Object();var n=new Zombie();
 for(float yaw:new float[]{0,30,75,90,135,180,225,270,315}){n.yBodyRot=n.yHeadRot=yaw;n.velocity=new BehaviorChecks28.Vec(0,0,-.15);for(int region:new int[]{0,2,3,4,5,6}){double x=region==2?5:region==3?-5:region==4?2:region==5?-2:0,y=region==0?27.2:region==4||region==5?6:17.2;for(int side:new int[]{-1,1}){double[]p=Hit28.world(x,y,side*4,Math.toRadians(yaw),1),v=Hit28.world(0,0,side*8,Math.toRadians(yaw),1);var shot=new Gore.Shot(new Bullet(new BehaviorChecks28.Vec(v[0],v[1],v[2])),n,new BehaviorChecks28.Point(p[0],p[1],p[2]),false,Rules.Weapon.OTHER);var hit=Hit28.locate(shot);ok(hit.region()==region,"moving zombie region incorrect at yaw "+yaw+" r="+region);ok(side<0?hit.z()>.999:hit.z()<.001,"exit-side collision point must resolve back to entry surface at yaw "+yaw);}}}
 ok(!Targets49.skipLocal(n),"live knockdown remains available");System.out.println("MOVING_ZOMBIE_ALL_REGIONS_ENTRY_SURFACE_AND_BODY_YAW_CHECKS="+checks);}
}
