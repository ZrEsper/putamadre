/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.gore;

import dev.zomboid.gore.Anatomy14;
import dev.zomboid.gore.Anatomy27;
import dev.zomboid.gore.CSG24;
import dev.zomboid.gore.Cuts24;
import dev.zomboid.gore.Mesh12;
import dev.zomboid.gore.Model14;
import dev.zomboid.gore.Organ29;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class Connected48 {
    static boolean touch(Mesh12.Box box, Mesh12.Box box2) {
        float f = 0.045f;
        return box.x0() <= box2.x1() + f && box.x1() + f >= box2.x0() && box.y0() <= box2.y1() + f && box.y1() + f >= box2.y0() && box.z0() <= box2.z1() + f && box.z1() + f >= box2.z0();
    }

    static double volume(Mesh12.Box box) {
        return Math.max(0.0f, box.x1() - box.x0()) * Math.max(0.0f, box.y1() - box.y0()) * Math.max(0.0f, box.z1() - box.z0());
    }

    static List<Mesh12.Box> connected(List<Mesh12.Box> list) {
        if (list.size() < 2) {
            return list;
        }
        boolean[] blArray = new boolean[list.size()];
        List<Mesh12.Box> list2 = List.of();
        double d = -1.0;
        int n = 0;
        while (n < list.size()) {
            if (!blArray[n]) {
                ArrayList<Mesh12.Box> arrayList = new ArrayList<Mesh12.Box>();
                ArrayDeque<Integer> arrayDeque = new ArrayDeque<Integer>();
                arrayDeque.add(n);
                blArray[n] = true;
                double d2 = 0.0;
                while (!arrayDeque.isEmpty()) {
                    int n2 = (Integer)arrayDeque.removeFirst();
                    Mesh12.Box box = list.get(n2);
                    arrayList.add(box);
                    d2 += Connected48.volume(box);
                    int n3 = 0;
                    while (n3 < list.size()) {
                        if (!blArray[n3] && Connected48.touch(box, list.get(n3))) {
                            blArray[n3] = true;
                            arrayDeque.add(n3);
                        }
                        ++n3;
                    }
                }
                if (d2 > d) {
                    d = d2;
                    list2 = arrayList;
                }
            }
            ++n;
        }
        return list2;
    }

    static boolean contains(Mesh12.Box box, float f, float f2, float f3) {
        float f4 = 0.06f;
        return f >= box.x0() - f4 && f <= box.x1() + f4 && f2 >= box.y0() - f4 && f2 <= box.y1() + f4 && f3 >= box.z0() - f4 && f3 <= box.z1() + f4;
    }

    public static List<Mesh12.Quad> filter(List<Mesh12.Quad> list, List<Mesh12.Cube> list2, int n) {
        if (list.isEmpty() || list2.isEmpty() || !Cuts24.has(n)) {
            return list;
        }
        Mesh12.Box box = CSG24.bounds(list2);
        ArrayList<Mesh12.Box> arrayList = new ArrayList<Mesh12.Box>(CSG24.remainder(box, CSG24.holes(box, n, 0.0)));
        if (Model14.internal()) {
            for (Anatomy14.Piece list32 : Anatomy14.anatomy(n)) {
                if (Organ29.removed(list32.name(), n, list32.box())) continue;
                double quad = list32.material() == 2 || list32.name().equals("tooth") ? 0.85 : (Anatomy27.organ(list32.name()) ? 1.05 : 0.4);
                arrayList.addAll(CSG24.remainder(Anatomy14.scale(list32.box(), box), CSG24.holes(box, n, quad)));
            }
        }
        if (arrayList.isEmpty()) {
            return List.of();
        }
        List<Mesh12.Box> list3 = Connected48.connected(arrayList);
        if (list3.size() == arrayList.size()) {
            return list;
        }
        List<Mesh12.Box> loose=new ArrayList<>();var retained=java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<Mesh12.Box,Boolean>());retained.addAll(list3);for(Mesh12.Box b:arrayList)if(!retained.contains(b))loose.add(b);return clipLoose(list,loose);}
 static List<Mesh12.Quad> clipLoose(List<Mesh12.Quad> mesh,List<Mesh12.Box> loose){List<Mesh12.Quad> out=new ArrayList<>();for(Mesh12.Quad q:mesh){List<Surface19.P> poly=new ArrayList<>();for(Mesh12.Vertex v:q.vertices())poly.add(new Surface19.P(v.x()*16,v.y()*16,v.z()*16,v.u(),v.v()));List<List<Surface19.P>> polygons=List.of(poly);for(Mesh12.Box b:loose){Mesh12.Box expanded=new Mesh12.Box(b.x0()-.001f,b.y0()-.001f,b.z0()-.001f,b.x1()+.001f,b.y1()+.001f,b.z1()+.001f);List<List<Surface19.P>> next=new ArrayList<>();for(List<Surface19.P> p:polygons)next.addAll(Surface19.subtract(p,expanded));polygons=next;}for(List<Surface19.P> p:polygons)Surface19.emit(out,p,q.material(),q.nx(),q.ny(),q.nz());}return List.copyOf(out);}
}
