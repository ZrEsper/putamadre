/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.gore;

import dev.zomboid.gore.Linked45;
import dev.zomboid.gore.Mesh12;
import dev.zomboid.gore.Model25;
import dev.zomboid.gore.R;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

public final class Player45 {
    static final ThreadLocal<Context> CURRENT = new ThreadLocal();
    static final String[] PARTS = new String[]{"head", "leftArm", "leftLeg", "leftLeg", "body", "rightArm", "rightLeg", "rightLeg"};
    static final String[] ROOT = new String[]{"head", "body", "leftArm", "rightArm", "leftLeg", "rightLeg"};
    static final int[] REGIONS;
    static final Map<Object, Map<Object, Integer>> MODELS;

    static {
        int[] nArray = new int[6];
        nArray[1] = 6;
        nArray[2] = 2;
        nArray[3] = 3;
        nArray[4] = 4;
        nArray[5] = 5;
        REGIONS = nArray;
        MODELS = new WeakHashMap<Object, Map<Object, Integer>>();
    }

    static Object c(Object object, String string, Object ... objectArray) {
        return R.call(object, string, objectArray);
    }

    public static void begin(Object object, Object object2, Object object3) {
        block4: {
            CURRENT.remove();
            if (object2 == null || !Player45.instance(object2, "net.minecraft.world.entity.player.Player")) {
                return;
            }
            try {
                int[] nArray = (int[])Player45.c(R.type("dev.zomboid.firstaid.Wounds45"), "snapshot", object2);
                if (nArray.length > 0) {
                    Context context = new Context(nArray, object3);
                    context.parts = Player45.parts(Player45.c(object, "getModel", new Object[0]));
                    CURRENT.set(context);
                }
            }
            catch (IllegalStateException illegalStateException) {
                if (illegalStateException.getCause() instanceof ClassNotFoundException) break block4;
                throw illegalStateException;
            }
        }
    }

    static boolean instance(Object object, String string) {
        Class<?> clazz = object.getClass();
        while (clazz != null) {
            if (clazz.getName().equals(string)) {
                return true;
            }
            clazz = clazz.getSuperclass();
        }
        return false;
    }

    static Map<Object, Integer> parts(Object object2) {
        return MODELS.computeIfAbsent(object2, object -> {
            IdentityHashMap<Object, Integer> identityHashMap = new IdentityHashMap<Object, Integer>();
            int n = 0;
            while (n < ROOT.length) {
                identityHashMap.put(R.get(object, ROOT[n]), REGIONS[n]);
                ++n;
            }
            String[] stringArray = new String[]{"hat", "jacket", "leftSleeve", "rightSleeve", "leftPants", "rightPants"};
            int n2 = 0;
            while (n2 < stringArray.length) {
                try {
                    identityHashMap.put(R.get(object, stringArray[n2]), REGIONS[n2]);
                }
                catch (IllegalStateException illegalStateException) {}
                ++n2;
            }
            return identityHashMap;
        });
    }

    public static void rag(Object object, Object object2) {
        CURRENT.remove();
        int[] nArray = Linked45.medical(object);
        if (nArray.length > 0) {
            CURRENT.set(new Context(nArray, object2));
        }
    }

    public static void model(Object object) {
        Context context = CURRENT.get();
        if (context != null) {
            context.parts = Player45.parts(object);
        }
    }

    public static void end() {
        CURRENT.remove();
    }

    public static void draw(Object object, Object object2, int n, int n2) {
        Object object3;
        Context context = CURRENT.get();
        if (context == null || context.parts == null || !Boolean.TRUE.equals(R.get(object, "visible")) || Boolean.TRUE.equals(R.get(object, "skipDraw"))) {
            return;
        }
        Integer n3 = context.parts.get(object);
        if (n3 == null) {
            return;
        }
        List<Mesh12.Cube> list = Model25.cubes(object, n3);
        if (list.isEmpty()) {
            return;
        }
        float[] fArray = new float[]{Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -3.4028235E38f, -3.4028235E38f, -3.4028235E38f};
        for (Mesh12.Cube object42 : list) {
            object3 = object42.bounds();
            fArray[0] = Math.min(fArray[0], ((Mesh12.Box)object3).x0());
            fArray[1] = Math.min(fArray[1], ((Mesh12.Box)object3).y0());
            fArray[2] = Math.min(fArray[2], ((Mesh12.Box)object3).z0());
            fArray[3] = Math.max(fArray[3], ((Mesh12.Box)object3).x1());
            fArray[4] = Math.max(fArray[4], ((Mesh12.Box)object3).y1());
            fArray[5] = Math.max(fArray[5], ((Mesh12.Box)object3).z1());
        }
        Object object4 = Player45.c(R.type("net.minecraft.resources.ResourceLocation"), "fromNamespaceAndPath", "zomboid_gore", "textures/entity/medical49.png");
        Object object5 = Player45.c(context.buffer, "getBuffer", Player45.c(R.type("net.minecraft.client.renderer.RenderType"), "entityCutoutNoCull", object4));
        Player45.c(object2, "pushPose", new Object[0]);
        try {
            Player45.c(object, "translateAndRotate", object2);
            object3 = Player45.c(object2, "last", new Object[0]);
            int n4 = 0;
            while (n4 + 6 < context.marks.length) {
                int n5 = context.marks[n4];
                if (n5 >= 0 && n5 <= 7) {
                    int n6;
                    switch (n5) {
                        case 0: {
                            n6 = 0;
                            break;
                        }
                        case 1: {
                            n6 = 2;
                            break;
                        }
                        case 2: 
                        case 3: {
                            n6 = 4;
                            break;
                        }
                        case 4: {
                            n6 = 6;
                            break;
                        }
                        case 5: {
                            n6 = 3;
                            break;
                        }
                        default: {
                            n6 = 5;
                        }
                    }
                    if (n6 == n3) {
                        double[] dArray = new double[]{(double)context.marks[n4 + 1] / 255.0, (double)context.marks[n4 + 2] / 255.0, (double)context.marks[n4 + 3] / 255.0};
                        if (n5 == 3 || n5 == 7) {
                            dArray[1] = 0.75 + dArray[1] * 0.25;
                        } else if (n5 == 2 || n5 == 6) {
                            dArray[1] = dArray[1] * 0.75;
                        }
                        int n8 = 0;
                        double d = 1.0;
                        boolean bl = false;
                        int n9 = 0;
                        while (n9 < 3) {
                            if (dArray[n9] < d) {
                                d = dArray[n9];
                                n8 = n9;
                                bl = false;
                            }
                            if (1.0 - dArray[n9] < d) {
                                d = 1.0 - dArray[n9];
                                n8 = n9;
                                bl = true;
                            }
                            ++n9;
                        }
                        int n10 = n9 = (context.marks[n4 + 6] & 1) != 0 ? 1 : 0;
                        if (n9 != 0) {
                            if (!Model25.LAYERS.contains(object)) {
                                boolean wrapped = false;
                                int fArray2 = 0;
                                while (fArray2 < n4) {
                                    if (context.marks[fArray2] == n5 && (context.marks[fArray2 + 6] & 1) != 0) {
                                        wrapped = true;
                                    }
                                    fArray2 += 7;
                                }
                                if (!wrapped) {
                                    Player45.wrap(object5, object3, fArray, dArray, n3, (context.marks[n4 + 6] & 2) != 0, n, n2);
                                }
                            }
                        } else {
                            float f = context.marks[n4 + 4] == 2 ? 1.05f : 0.7f;
                            f = (float)((double)f * Math.max(0.12, (double)Math.min(1.0f, (float)context.marks[n4 + 5] / 12000.0f)));
                            float[] fArray2 = new float[3];
                            int n11 = 0;
                            while (n11 < 3) {
                                fArray2[n11] = (float)((double)fArray[n11] + dArray[n11] * (double)(fArray[n11 + 3] - fArray[n11]));
                                ++n11;
                            }
                            fArray2[n8] = fArray[n8 + (bl ? 3 : 0)] + (bl ? 0.025f : -0.025f);
                            n11 = (n8 + 1) % 3;
                            int n12 = (n8 + 2) % 3;
                            float[][] fArray3 = new float[4][3];
                            int[][] nArrayArray = new int[][]{{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
                            int n13 = 0;
                            while (n13 < 4) {
                                fArray3[n13] = (float[])fArray2.clone();
                                fArray3[n13][n11] = Math.max(fArray[n11], Math.min(fArray[n11 + 3], fArray2[n11] + (float)nArrayArray[n13][0] * f));
                                fArray3[n13][n12] = Math.max(fArray[n12], Math.min(fArray[n12 + 3], fArray2[n12] + (float)nArrayArray[n13][1] * f));
                                ++n13;
                            }
                            float[] n14 = new float[3];
                            n14[n8] = bl ? 1 : -1;
                            Player45.quad(object5, object3, fArray3, n14, 0xffd7b2b2, context.marks[n4+4]==2?1f/3:0, context.marks[n4+4]==2?2f/3:1f/3, n, n2);
                        }
                    }
                }
                n4 += 7;
            }
        }
        finally {
            Player45.c(object2, "popPose", new Object[0]);
        }
    }

    static void quad(Object object, Object object2, float[][] fArray, float[] fArray2, int n, float f, float f2, int n2, int n3) {
        int n4 = 0;
        while (n4 < 4) {
            Object object3 = Player45.c(object, "addVertex", object2, Float.valueOf(fArray[n4][0] / 16.0f), Float.valueOf(fArray[n4][1] / 16.0f), Float.valueOf(fArray[n4][2] / 16.0f));
            Player45.c(object3, "setColor", n);
            Player45.c(object3, "setUv", Float.valueOf(n4 == 0 || n4 == 3 ? f : f2), Float.valueOf(n4 < 2 ? 0.0f : 1.0f));
            Player45.c(object3, "setOverlay", n3);
            Player45.c(object3, "setLight", n2);
            Player45.c(object3, "setNormal", object2, Float.valueOf(fArray2[0]), Float.valueOf(fArray2[1]), Float.valueOf(fArray2[2]));
            ++n4;
        }
    }

    static void wrap(Object object, Object object2, float[] fArray, double[] dArray, int n, boolean bl, int n2, int n3) {
        float f = n == 0 ? 0.65f : (n == 6 ? 1.25f : 1.1f);
        float f2 = (float)((double)fArray[1] + dArray[1] * (double)(fArray[4] - fArray[1]));
        if (n == 0) {
            f2 = fArray[1] + 1.25f;
        }
        f2 = Math.max(fArray[1] + f, Math.min(fArray[4] - f, f2));
        float f3 = f2 - f;
        float f4 = f2 + f;
        float f5 = n == 0 ? 0.56f : 0.31f;
        float f6 = fArray[0] - f5;
        float f7 = fArray[3] + f5;
        float f8 = fArray[2] - f5;
        float f9 = fArray[5] + f5;
        int n4 = bl ? -5661817 : -1119780;
        Player45.quad(object, object2, new float[][]{{f7, f3, f8}, {f6, f3, f8}, {f6, f4, f8}, {f7, f4, f8}}, new float[]{0.0f, 0.0f, -1.0f}, n4, 2f/3, 1.0f, n2, n3);
        Player45.quad(object, object2, new float[][]{{f6, f3, f9}, {f7, f3, f9}, {f7, f4, f9}, {f6, f4, f9}}, new float[]{0.0f, 0.0f, 1.0f}, n4, 2f/3, 1.0f, n2, n3);
        Player45.quad(object, object2, new float[][]{{f6, f3, f8}, {f6, f3, f9}, {f6, f4, f9}, {f6, f4, f8}}, new float[]{-1.0f, 0.0f, 0.0f}, n4, 2f/3, 1.0f, n2, n3);
        Player45.quad(object, object2, new float[][]{{f7, f3, f9}, {f7, f3, f8}, {f7, f4, f8}, {f7, f4, f9}}, new float[]{1.0f, 0.0f, 0.0f}, n4, 2f/3, 1.0f, n2, n3);
    }

    static class Context {
        int[] marks;
        Object buffer;
        Map<Object, Integer> parts;

        Context(int[] nArray, Object object) {
            this.marks = nArray;
            this.buffer = object;
        }
    }
}

