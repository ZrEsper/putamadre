/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.gore;

import dev.zomboid.gore.CSG24;
import dev.zomboid.gore.Cuts24;
import dev.zomboid.gore.Mesh12;
import dev.zomboid.gore.Model25;
import dev.zomboid.gore.R;
import dev.zomboid.gore.Skin12;
import dev.zomboid.gore.Wound28;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

public final class Armor48 {
    static final Map<Object, Cached> CACHE = Collections.synchronizedMap(new WeakHashMap());
    static final Map<Object, Integer> PARTS = Collections.synchronizedMap(new WeakHashMap());

    public static void bind(Object object) {
        if (object == null) {
            return;
        }
        String[] stringArray = new String[]{"head", "body", "leftArm", "rightArm", "leftLeg", "rightLeg", "hat"};
        int[] nArray = new int[7];
        nArray[1] = 6;
        nArray[2] = 2;
        nArray[3] = 3;
        nArray[4] = 4;
        nArray[5] = 5;
        int[] nArray2 = nArray;
        int n = 0;
        while (n < stringArray.length) {
            try {
                Object object2 = R.get(object, stringArray[n]);
                PARTS.put(object2, nArray2[n]);
            }
            catch (IllegalStateException illegalStateException) {}
            ++n;
        }
    }

    public static boolean render(Object object, Object object2, Object object3, int n, int n2, int n3) {
        Integer n4 = PARTS.get(object);
        if (n4 == null || Skin12.CURRENT.get() == null || !Cuts24.has(n4)) {
            return false;
        }
        if (!R.yes(R.get(object, "visible")) || R.yes(R.get(object, "skipDraw"))) {
            return true;
        }
        List<Mesh12.Cube> list = Model25.cubes(object, n4);
        if (list.isEmpty()) {
            return false;
        }
        int n5 = Arrays.hashCode(Cuts24.CURRENT.get());
        Cached cached = CACHE.get(object);
        if (cached == null || cached.hash() != n5 || cached.cubes() != list) {
            cached = new Cached(n5, list, Armor48.mesh(list, n4));
            CACHE.put(object, cached);
        }
        List<Mesh12.Quad> list2 = cached.mesh();
        R.call(object2, "pushPose", new Object[0]);
        try {
            R.call(object, "translateAndRotate", object2);
            Object object4 = R.call(object2, "last", new Object[0]);
            for (Mesh12.Quad quad : list2) {
                int n6 = 0;
                while (n6 < 4) {
                    Mesh12.Vertex vertex = quad.vertices()[n6];
                    Object object5 = R.call(object3, "addVertex", object4, Float.valueOf(vertex.x()), Float.valueOf(vertex.y()), Float.valueOf(vertex.z()));
                    R.call(object5, "setColor", quad.material() == 48 ? Armor48.shade(n3) : n3);
                    R.call(object5, "setUv", Float.valueOf(vertex.u()), Float.valueOf(vertex.v()));
                    R.call(object5, "setOverlay", n2);
                    R.call(object5, "setLight", n);
                    R.call(object5, "setNormal", object4, Float.valueOf(quad.nx()), Float.valueOf(quad.ny()), Float.valueOf(quad.nz()));
                    ++n6;
                }
            }
        }
        finally {
            R.call(object2, "popPose", new Object[0]);
        }
        return true;
    }

    static int shade(int n) {
        return n & 0xFF000000 | (n >> 16 & 0xFF) / 4 << 16 | (n >> 8 & 0xFF) / 4 << 8 | (n & 0xFF) / 4;
    }

    static List<Mesh12.Quad> mesh(List<Mesh12.Cube> list, int n) {
        Mesh12.Box box = CSG24.bounds(list);
        List<Mesh12.Box> list2 = holes(box,n);
        ArrayList<Mesh12.Quad> arrayList = new ArrayList<Mesh12.Quad>();
        for (Mesh12.Cube object2 : list) {
            for (Mesh12.Face face : object2.faces()) {
                CSG24.surface(arrayList, face, list2);
            }
        }
        int[] nArray = Cuts24.CURRENT.get();
        int n2 = 0;
        while (n2 < nArray.length) {
            Cuts24.Cut cut = Cuts24.cut(nArray, n2);
            if ((cut.region() == n || n == 6 && cut.region() == 7) && cut.style() == 2) {
                int n3 = Wound28.normal(cut);
                int[] nArray2 = Wound28.tangent(n3);
                float[] fArray = new float[]{box.x0(), box.y0(), box.z0()};
                float[] fArray2 = new float[]{box.x1(), box.y1(), box.z1()};
                double[] dArray = new double[]{cut.x(), cut.y(), cut.z()};
                float[] fArray3 = new float[3];
                int n4 = 0;
                while (n4 < 3) {
                    fArray3[n4] = (float)((double)fArray[n4] + dArray[n4] * (double)(fArray2[n4] - fArray[n4]));
                    ++n4;
                }
                fArray3[n3] = dArray[n3] < 0.5 ? fArray[n3] - 0.025f : fArray2[n3] + 0.025f;
                float[] fArray4 = (float[])fArray3.clone();
                float[] fArray5 = (float[])fArray3.clone();
                float f = (float)Math.min(1.1, 0.35 + cut.radius() * 0.2);
                fArray4[nArray2[0]] = Math.max(fArray[nArray2[0]], fArray3[nArray2[0]] - f);
                fArray5[nArray2[0]] = Math.min(fArray2[nArray2[0]], fArray3[nArray2[0]] + f);
                fArray4[nArray2[1]] = Math.max(fArray[nArray2[1]], fArray3[nArray2[1]] - 0.07f);
                fArray5[nArray2[1]] = Math.min(fArray2[nArray2[1]], fArray3[nArray2[1]] + 0.07f);
                int n5 = n3;
                fArray4[n5] = fArray4[n5] - 0.006f;
                int n6 = n3;
                fArray5[n6] = fArray5[n6] + 0.006f;
                ArrayList<Mesh12.Quad> arrayList2 = new ArrayList<Mesh12.Quad>();
                Mesh12.box(arrayList2, new Mesh12.Box(fArray4[0], fArray4[1], fArray4[2], fArray5[0], fArray5[1], fArray5[2]), 8, null);
                for (Mesh12.Quad quad : arrayList2) {
                    arrayList.add(new Mesh12.Quad(quad.vertices(), 48, quad.nx(), quad.ny(), quad.nz()));
                }
            }
            n2 += 2;
        }
        return List.copyOf(arrayList);
    }

    static List<Mesh12.Box> holes(Mesh12.Box armor,int region){Mesh12.Box body=Mesh12.canonical(region);List<Mesh12.Box> out=new ArrayList<>();for(Mesh12.Box hole:CSG24.holes(body,region,0)){float[]lo={hole.x0(),hole.y0(),hole.z0()},hi={hole.x1(),hole.y1(),hole.z1()},b0={body.x0(),body.y0(),body.z0()},b1={body.x1(),body.y1(),body.z1()},a0={armor.x0(),armor.y0(),armor.z0()},a1={armor.x1(),armor.y1(),armor.z1()};for(int axis=0;axis<3;axis++){if(lo[axis]<=b0[axis]+.01f)lo[axis]=Math.min(lo[axis],a0[axis]-.02f);if(hi[axis]>=b1[axis]-.01f)hi[axis]=Math.max(hi[axis],a1[axis]+.02f);}out.add(new Mesh12.Box(lo[0],lo[1],lo[2],hi[0],hi[1],hi[2]));}return out;}
    record Cached(int hash, List<Mesh12.Cube> cubes, List<Mesh12.Quad> mesh) {
    }
}

