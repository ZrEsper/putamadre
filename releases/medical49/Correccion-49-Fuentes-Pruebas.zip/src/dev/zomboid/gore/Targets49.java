package dev.zomboid.gore;
public final class Targets49 {
 public static double depth(Cuts24.Cut c){return c.style()==1?.4+c.radius()*.18+Math.max(0,c.radius()-3)*.45:c.radius();}
 public static Object packetField(Object p,String name,Object...unused){return R.get(p,name);}
 public static boolean transparent(Object entity){return entity!=null&&entity.getClass().getName().equals("de.maxhenkel.corpse.entities.CorpseEntity")&&Linked45.linked(entity);}
 public static Object nearer(Object result){return result!=null&&transparent(R.call(result,"getEntity"))?null:result;}
 /** Dead local actors must wait for the authoritative server body. Live knockdowns are unaffected. */
 public static boolean skipLocal(Object actor){if(actor==null)return false;try{return Npc29.target(actor)&&!R.yes(R.call(actor,"isAlive"));}catch(RuntimeException e){return false;}}
}
