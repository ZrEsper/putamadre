from pathlib import Path
import subprocess,shutil,json
r=Path(__file__).resolve().parent;old=r/'src/medical48';g=next((r/'output').glob('zomboid*.jar'));rag=next((r/'output').glob('rag*.jar'));out=r/'build/tests';shutil.rmtree(out,ignore_errors=True);out.mkdir(parents=True)
flags=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ('','.tree','.tree.analysis')]
s=(old/'ExtractCleanup48.java').read_text().replace('org.objectweb.asm','jdk.internal.org.objectweb.asm');(r/'ExtractCleanup48.java').write_text(s)
subprocess.run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(r/'build/tools'),str(r/'ExtractCleanup48.java')],check=True)
subprocess.run(['java',*flags,'-cp',str(r/'build/tools'),'ExtractCleanup48',str(rag),str(out)],check=True)
f=list((old/'tests').rglob('*.java'))+[r/'src/medical45/tests/dev/zomboid/gore/Render45.java',r/'src/medical45/tests/net/minecraft/resources/ResourceLocation.java',r/'src/medical45/tests/net/minecraft/client/renderer/RenderType.java',r/'src/medical46/tests/net/minecraft/world/phys/Vec3.java']
# Real packet uses a field, rather than the method incorrectly mocked by the preceding patch.
p=old/'tests/dev/zomboid/gore/Check48.java';s=p.read_text().replace('public float yRot(){return 0;}','public float yRot;');p.write_text(s)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(g),'-d',str(out),*map(str,f),*map(str,(r/'tests').rglob('*.java'))],check=True)
shutil.copytree(old/'resources',out,dirs_exist_ok=True)
results=[]
for name in ['Check48','Check49']:
 p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(g),'dev.zomboid.gore.'+name],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
(r/'output/test-results.json').write_text(json.dumps({'minecraft_runtime_tested':False,'boundary':'Production helpers and extracted native cleanup execute against simulated Minecraft APIs.','results':results},indent=2))
