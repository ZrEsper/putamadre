package mod.chloeprime.thirdpersonshooting.client;
import java.lang.reflect.Method;
public final class ShoulderClearance {
 private static Method position;private static boolean warned;
 static double coord(Object v,String key){return ((Number)R.field(v,key)).doubleValue();}
 static Object vec(double x,double y,double z){return R.make("net.minecraft.world.phys.Vec3",x,y,z);}
 public static double[] desired(double yaw,double side,double back){double a=Math.toRadians(yaw);return new double[]{Math.cos(a)*side+Math.sin(a)*back,-.05,Math.sin(a)*side-Math.cos(a)*back};}
 public static double safeFraction(double hit,double length){return length<1e-6?0:Math.max(0,Math.min(1,(hit-.12)/length));}
 public static void apply(Object camera,float partial){try{
  if(FreeCamera.isIso())return;
  Object mc=R.mc(),p=R.field(mc,"player"),level=R.field(mc,"level");if(p==null||level==null||R.call(camera,"getEntity")!=p)return;
  Object ss=R.call(R.type("com.github.exopandora.shouldersurfing.api.client.IShoulderSurfing"),"getInstance");if(!FreeCamera.shoulder(ss))return;
  Object current=R.call(camera,"getPosition"),eye=R.call(p,"getEyePosition",partial);double yaw=((Number)R.call(camera,"getYRot")).doubleValue(),rad=Math.toRadians(yaw);
  double dx=coord(current,"x")-coord(eye,"x"),dz=coord(current,"z")-coord(eye,"z");double lateral=dx*Math.cos(rad)+dz*Math.sin(rad),back=dx*Math.sin(rad)-dz*Math.cos(rad);
  // Preserve normal camera placement, zoom, shoulder side and first-person/isometric views.
  if(Math.abs(lateral)>=.72&&back>=1.15)return;
  double side=Math.abs(lateral)>.03?Math.copySign(.85,lateral):-.85;
  double[] d=desired(yaw,side,Math.max(1.35,Math.min(2.5,back)));
  double length=Math.sqrt(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]),fraction=1;
  Object block=R.field(R.type("net.minecraft.world.level.ClipContext$Block"),"VISUAL"),fluid=R.field(R.type("net.minecraft.world.level.ClipContext$Fluid"),"NONE");
  // A small camera volume, not just one ray, protects corners and low slabs.
  for(int i=0;i<8;i++){double ox=(i%2==0?-.1:.1),oy=((i&2)==0?-.1:.1),oz=((i&4)==0?-.1:.1);
   Object from=vec(coord(eye,"x")+ox,coord(eye,"y")+oy,coord(eye,"z")+oz),to=vec(coord(from,"x")+d[0],coord(from,"y")+d[1],coord(from,"z")+d[2]);
   Object hit=R.call(level,"clip",R.make("net.minecraft.world.level.ClipContext",from,to,block,fluid,p));
   if("BLOCK".equals(String.valueOf(R.call(hit,"getType")))){Object at=R.call(hit,"getLocation");double dist=((Number)R.call(from,"distanceTo",at)).doubleValue();fraction=Math.min(fraction,safeFraction(dist,length));}
  }
  // Do not force the camera into the player's head when no shoulder space exists.
  if(Math.abs(d[0]*Math.cos(rad)+d[2]*Math.sin(rad))*fraction<Math.max(.25,Math.abs(lateral)))return;
  Object target=vec(coord(eye,"x")+d[0]*fraction,coord(eye,"y")+d[1]*fraction,coord(eye,"z")+d[2]*fraction);
  if(position==null){position=R.type("net.minecraft.client.Camera").getDeclaredMethod("setPosition",R.type("net.minecraft.world.phys.Vec3"));position.setAccessible(true);}position.invoke(camera,target);
 }catch(Throwable t){if(!warned){warned=true;System.err.println("[TPS] Shoulder clearance unavailable: "+t);}}}
}
