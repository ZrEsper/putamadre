package mod.chloeprime.thirdpersonshooting.client;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
public final class R {
 private static final Map<String,Optional<Class<?>>> TYPES=new ConcurrentHashMap<>();
 private record Signature(String name,List<Class<?>> arguments,boolean statik){}
 private static final ClassValue<Cache> CACHE=new ClassValue<>(){protected Cache computeValue(Class<?> c){return new Cache(c);}};
 private static final class Cache {
  final Method[] methods; final Constructor<?>[] constructors;
  final Map<Signature,Optional<Method>> resolved=new ConcurrentHashMap<>();
  final Map<Signature,Optional<Constructor<?>>> made=new ConcurrentHashMap<>();
  final Map<String,Field> fields=new ConcurrentHashMap<>();
  Cache(Class<?> c){methods=c.getMethods();constructors=c.getConstructors();}
 }
 public static Class<?> optionalType(String name){return TYPES.computeIfAbsent(name,n->{try{return Optional.of(Class.forName(n));}catch(ClassNotFoundException e){return Optional.empty();}}).orElse(null);}
 public static Class<?> type(String name){Class<?> c=optionalType(name);if(c==null)throw new IllegalStateException(name,new ClassNotFoundException(name));return c;}
 public static boolean is(String name,Object value){if(value==null)return false;Class<?> c=optionalType(name);return c!=null&&c.isInstance(value);}
 static boolean match(Class<?> p,Object o){if(o==null)return !p.isPrimitive();return p.isInstance(o)||p==int.class&&o instanceof Integer||p==double.class&&o instanceof Double||p==float.class&&o instanceof Float||p==boolean.class&&o instanceof Boolean||p==long.class&&o instanceof Long;}
 private static boolean matches(Class<?>[] p,Object[] args){if(p.length!=args.length)return false;for(int i=0;i<p.length;i++)if(!match(p[i],args[i]))return false;return true;}
 private static Signature key(String name,Object[] args,boolean statik){Class<?>[] a=new Class<?>[args.length];for(int i=0;i<a.length;i++)a[i]=args[i]==null?Void.class:args[i].getClass();return new Signature(name,List.of(a),statik);}
 public static Object call(Object target,String name,Object...args){Class<?> c=target instanceof Class<?> t?t:target.getClass();Cache cache=CACHE.get(c);Method m=cache.resolved.computeIfAbsent(key(name,args,target instanceof Class<?>),k->{for(Method candidate:cache.methods)if(candidate.getName().equals(name)&&matches(candidate.getParameterTypes(),args))return Optional.of(candidate);return Optional.empty();}).orElseThrow(()->new IllegalStateException(c+" "+name));try{return m.invoke(target instanceof Class<?>?null:target,args);}catch(Exception e){throw new IllegalStateException(c+" "+name,e);}}
 public static Object make(String name,Object...args){Class<?> c=type(name);Cache cache=CACHE.get(c);Constructor<?> ctor=cache.made.computeIfAbsent(key(name,args,false),k->{for(Constructor<?> candidate:cache.constructors)if(matches(candidate.getParameterTypes(),args))return Optional.of(candidate);return Optional.empty();}).orElseThrow(()->new IllegalStateException(name));try{return ctor.newInstance(args);}catch(Exception e){throw new IllegalStateException(e);}}
 public static Object field(Object target,String name){try{Class<?> c=target instanceof Class<?> t?t:target.getClass();Field f=CACHE.get(c).fields.computeIfAbsent(name,n->{try{return c.getField(n);}catch(Exception e){throw new IllegalStateException(n,e);}});return f.get(target instanceof Class<?>?null:target);}catch(Exception e){throw new IllegalStateException(name,e);}}
 public static Object mc(){return call(type("net.minecraft.client.Minecraft"),"getInstance");}
}
