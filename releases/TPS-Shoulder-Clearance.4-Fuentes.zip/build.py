from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,copy,hashlib,subprocess,re
root=Path('work/tps4');source=next(Path('attachments/43fa3f48-bce9-4fe4-9fc4-14a4951fc703').glob('*.jar'));dest=root/'tp_shooting-neoforge-1.21.1-tacz1.1.8-ssr5-6.0.1-shoulder-clearance.4.jar'
changes={p.relative_to(root/'classes').as_posix():p.read_bytes() for p in (root/'classes').rglob('*.class')}
with ZipFile(source) as z:
 cfg=json.loads(z.read('tp_shooting.mixins.json'));cfg['client'].append('client.ShoulderClearanceMixin');changes['tp_shooting.mixins.json']=json.dumps(cfg,indent=2).encode()
 meta=z.read('META-INF/neoforge.mods.toml').decode();meta=re.sub(r'^version\s*=\s*"[^"]+"','version="6.0.1+shoulder-clearance.4"',meta,count=1,flags=re.M);changes['META-INF/neoforge.mods.toml']=meta.encode()
 changed=set(changes)
 with ZipFile(dest,'w',ZIP_DEFLATED) as out:
  for info in z.infolist():out.writestr(copy.copy(info),changes.pop(info.filename,z.read(info)))
  for name,data in changes.items():out.writestr(name,data)
 with ZipFile(dest) as out:
  assert out.testzip() is None
  for name in z.namelist():
   if name not in changed:assert z.read(name)==out.read(name)
(root/'LEEME.txt').write_text('''TPS Shoulder Clearance 4
Reemplazar camera-state-reset.3.jar; no instalar ambos. Solo cliente.
Mantiene las correcciones previas. Corrige cámara centrada/demasiado próxima cuando
Shoulder Surfing está activo mediante posición lateral a la altura de los ojos.
Conserva el lado actual y evita paredes con ocho rayos y margen de 0.12 bloques.
Si no hay espacio suficiente no se fuerza la posición. Primera persona y cámara
isométrica quedan excluidas. Comprobar en juego techos, puertas, hombros y vehículos.
Pruebas: bytecode, ZIP, posición libre, pared bloqueada, primera persona y 721 ángulos.
No se ha ejecutado Minecraft aquí; validación visual pendiente.
''')
src=root/'TPS-Shoulder-Clearance.4-Fuentes.zip'
with ZipFile(src,'w',ZIP_DEFLATED) as out:
 for folder in ['src','testsrc']:
  for p in (root/folder).rglob('*.java'):out.write(p,p.relative_to(root))
 for n in ['MakeMixin.java','tests.py','build.py','LEEME.txt']:out.write(root/n,n)
files=[]
for p in [dest,src]:
 b=p.read_bytes();files.append(dict(local=str(p),path='releases/'+p.name,sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
(root/'upload.json').write_text(json.dumps(files))
parent=subprocess.check_output(['git','--git-dir=work/tzp-fix/publish.git','rev-parse','FETCH_HEAD']).decode().strip()
s=Path('work/horror39/publish.py').read_text().replace('work/horror39','work/tps4').replace('3bb2982497ab2de5ad7665f3ec86b28995051b3d',parent).replace('codex/horror39','codex/tps4').replace('Add configurable reliable breaching, Screamer, area vomit and bile, and head8 torso15 ballistic protection','Preserve shoulder clearance under low ceilings with collision checks')
(root/'publish.py').write_text(s)
print('PASS archive integrity, original classes preserved; SHA256',hashlib.sha256(dest.read_bytes()).hexdigest())
