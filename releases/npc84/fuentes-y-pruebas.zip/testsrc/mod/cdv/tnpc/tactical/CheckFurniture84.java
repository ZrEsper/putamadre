package mod.cdv.tnpc.tactical;
import net.minecraft.core.BlockPos;import net.minecraft.world.item.ItemStack;
public class CheckFurniture84{
 public static void main(String[]a){BuildWorld77.Npc n=new BuildWorld77.Npc();BuildWorld77 world=(BuildWorld77)n.world;n.bag.add(new ItemStack("minecraft:crafting_table",1));BlockPos p=new BlockPos(2,64,0);if(!Base48.place(n,p,"minecraft:crafting_table"))throw new AssertionError("placement failed");if(!Base48.id(world,p).equals("minecraft:crafting_table"))throw new AssertionError("wrong placed block");if(Shelter77.count(n.bag,"minecraft:crafting_table")!=0)throw new AssertionError("item not consumed");System.out.println("PASS production Base48.place: crafting table placed and ingredient consumed; simulated world API");}
}
