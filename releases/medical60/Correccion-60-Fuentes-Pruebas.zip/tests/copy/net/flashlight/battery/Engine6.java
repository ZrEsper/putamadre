package net.flashlight.battery;public class Engine6{static int depthBuffer=3,fbo=4,captureWidth=960,captureHeight=540,scene=5,width=1920,height=1080;static boolean ready=true;}
