package net.flashlight.battery;
/** Recover a failed scene copy at most once a second, never every frame. */
public final class Recovery60{
 static boolean waiting;static long retryAt;
 static boolean due(boolean blocked,long now){if(!blocked){waiting=false;return false;}if(!waiting){waiting=true;retryAt=now+1_000_000_000L;return false;}if(now<retryAt)return false;waiting=false;return true;}
 public static void frame(Object event){if(due(Capture53.blocked,System.nanoTime())){Capture53.blocked=false;Engine6.ready=false;Copy56.invalidate();}}
}
