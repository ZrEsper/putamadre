from pathlib import Path
import zipfile,json,hashlib,subprocess,tomllib
r=Path(__file__).parent;out=r/'release';out.mkdir(exist_ok=True);name='flashlight-5.1-neoforge-1.21.1-player-priority-depth-recovery.26.jar'
with zipfile.ZipFile(r/'output/flash.jar')as z:data={n:z.read(n)for n in z.namelist()}
meta=data['META-INF/neoforge.mods.toml'].decode().replace('version="5.1.25"','version="5.1.26"');data['META-INF/neoforge.mods.toml']=meta.encode();assert tomllib.loads(meta)['mods'][0]['version']=='5.1.26';assert not any(n.startswith(('net/minecraft/','org/joml/','tests/'))for n in data)
with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED)as z:
 for n,b in sorted(data.items()):z.writestr(n,b)
with zipfile.ZipFile(out/name)as z:assert z.testzip()is None
p=subprocess.run(['python',str(r/'depth_gpu_test.py')],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results=json.loads((r/'test-results.json').read_text());results['real_gpu_depth_test']=p.stdout.strip();results['verified_class_count']=66;results['native_hooks']='one storage invalidation after resize depth assignment; one bounded-recovery hook before scene copy';(out/'test-results.json').write_text(json.dumps(results,indent=2)+'\n')
base=Path('/workspace/light59/release/flashlight-5.1-neoforge-1.21.1-mts-headlight-cones.25.jar');sha=hashlib.sha256((out/name).read_bytes()).hexdigest();(out/'manifest.json').write_text(json.dumps({'base_commit':'ec632750923393e4c073280766a49243b5a89bf4','minecraft':'1.21.1','loader':'NeoForge','minecraft_runtime_tested':False,'file':name,'version':'5.1.26','sha256':sha,'input_sha256':hashlib.sha256(base.read_bytes()).hexdigest()},indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(sha+'  mods/'+name+'\n');(out/'LEEME.md').write_bytes((r/'LEEME.md').read_bytes())
with zipfile.ZipFile(out/'Correccion-60-Linterna-Prioridad-Recuperacion.zip','w',zipfile.ZIP_DEFLATED)as z:
 z.write(out/name,'mods/'+name)
 for n in ['LEEME.md','test-results.json','manifest.json','SHA256SUMS.txt']:z.write(out/n,n)
with zipfile.ZipFile(out/'Correccion-60-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','tests']:
  for p in(r/folder).rglob('*.java'):z.write(p,p.relative_to(r))
 for n in ['Patch60.java','build.py','test.py','depth_gpu_test.py','package.py','LEEME.md']:z.write(r/n,n)
 for n in ['test-results.json','manifest.json']:z.write(out/n,n)
print('PACKAGE_READY',name,sha)
