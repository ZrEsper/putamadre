package dev.zomboid.gore;
import java.util.*;
/** The elected physics owner reports the captured skin once, so saved bodies keep that variant. */
public final class Texture13 {
 static final Map<Object,Boolean> REPORTED=Collections.synchronizedMap(new WeakHashMap<>());
 public static void report(Object doll){if(REPORTED.containsKey(doll)||((Number)R.get(doll,"goreSurface12")).intValue()>=0)return;int id=((Number)R.call(doll,"getOriginalEntityId")).intValue();Object owned=((Map<?,?>)R.get(R.type(Corpse13.CLIENT),"streamOwnership")).get(id);if(!Boolean.TRUE.equals(owned))return;Object tex=R.call(doll,"getCachedTexture");if(tex==null)return;REPORTED.put(doll,true);Object msg=R.make("com.raiiiden.ragdollified.network.RagdollImpulsePacket",id,-17,0f,0f,0f);R.set(msg,"goreTexture13",tex.toString());R.call(R.type("com.raiiiden.ragdollified.network.ModNetwork"),"sendToServer",msg);}
 public static boolean receive(Object sender,Object msg){if(((Number)R.get(msg,"partIndex")).intValue()!=-17)return false;int id=((Number)R.get(msg,"ragdollId")).intValue();Object retained=Corpse13.retained(id);if(retained==null||!R.call(sender,"getUUID").equals(R.get(retained,"streamOwner"))||!R.call(R.call(sender,"level"),"dimension").equals(R.get(retained,"dimension")))return true;String texture=(String)R.get(msg,"goreTexture13");if(texture==null||texture.length()>256||!texture.matches("[a-z0-9_.-]+:[a-z0-9/_.-]+\\.png"))return true;Object packet=R.get(retained,"spawnPacket");R.set(packet,"goreTexture13",texture);Bridge13Texture.dirty(R.call(sender,"level"),id);return true;}
 public static String value(Object packet){Object t=R.get(packet,"goreTexture13");return t==null?"":t.toString();}
 static class Bridge13Texture{static void dirty(Object l,int id){try{R.call(R.type("dev.zomboid.remains.BodyLoot16"),"dirty",l,id);}catch(IllegalStateException e){if(!(e.getCause() instanceof ClassNotFoundException))throw e;}}}
}
