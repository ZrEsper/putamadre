package dev.zomboid.gore;
/** Pure regional progression shared by live zombies and dead physics bodies. */
public final class Damage13 {
 public record Result(int state,int details,int surfaces){}
 public static int region(int ragPart){return switch(ragPart){case 1->0;case 2->4;case 3->5;case 4->2;case 5->3;default->6;};}
 public static int kind(String item){String s=item.toLowerCase(java.util.Locale.ROOT);return s.contains("axe")&&!s.contains("pickaxe")?2:s.contains("sword")||s.contains("knife")||s.contains("machete")||s.contains("blade")||s.contains("katana")?1:0;}
 public static int kindOf(Object stack){String id=String.valueOf(R.call(stack,"getDescriptionId"));try{Object melee=R.call(R.type("me.xjqsh.lrtactical.api.item.IMeleeWeapon"),"of",stack);if(melee!=null)id+=" "+R.call(melee,"getId",stack);}catch(RuntimeException ignored){}return kind(id);}
 public static Result hit(int state,int details,int surfaces,int zone,int count,int kind,double fraction){
  int previous=Trauma12.stage(details,zone),next;
  if(zone==2||zone==3){int bit=fraction>.69?1:fraction>.34?2:4;next=previous|bit;if(count>=4)surfaces|=1<<(24+zone);}
  else if(zone==0){next=Math.min(7,Math.max(previous,count+(kind==2?2:1)));}
  else next=Math.min(7,Math.max(previous,count+(kind==2?1:0)));
  details=Trauma12.withStage(details,zone,next);state|=1<<(8+zone);
  if(zone>=2&&zone<6&&count>=2)state|=1<<(26+zone-2);
  surfaces|=1<<(zone+(kind==0?8:16));return new Result(state,details,surfaces);
 }
}
