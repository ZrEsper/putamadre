package dev.zomboid.gore;
public final class Bridge13 {
 static void optional(String method,Object event){try{R.call(R.type("dev.zomboid.remains.BodyLoot16"),method,event);}catch(IllegalStateException e){if(!(e.getCause() instanceof ClassNotFoundException))throw e;}}
 public static void leave(Object e){optional("leave",e);}
 public static void join(Object e){optional("join",e);}public static void protect(Object e){optional("protect",e);}public static void tick(Object e){optional("tick",e);}public static void stop(Object e){optional("stop",e);}
}
