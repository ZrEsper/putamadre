package dev.zomboid.gore;
import java.util.*;
/** Nested wounds remove more tissue at each stage; previous cuts never grow back. */
public final class Mesh13 {
 static Mesh12.Box b(float a,float c,float d,float e,float f,float g){return new Mesh12.Box(a,c,d,e,f,g);}
 static void cut(List<Mesh12.Box> cuts,Mesh12.Box all,int zone,int shape){
  int stage=shape&7;boolean stripped=(shape&8)!=0;float x=all.x0(),y=all.y0(),z=all.z0(),X=all.x1(),Y=all.y1(),Z=all.z1(),w=X-x,h=Y-y,d=Z-z;
  if(zone==2||zone==3){
   if((shape&16)!=0)cuts.add(b(x+w*.6f,y+h*.4f,z-1,X+1,y+h*.55f,z+d*.25f));
   if((stage&1)!=0)cuts.add(b(x-1,y+h*.72f,z-1,X+1,Y+1,Z+1));
   if((stage&2)!=0)cuts.add(b(x+w*.34f,y+h*.32f,z-1,X+1,y+h*.60f,z+d*.8f));
   if((stage&4)!=0)cuts.add(b(x+w*.4f,y+h*.10f,z-1,X+1,y+h*.36f,z+d*.8f));
   if(stripped){cuts.add(b(x-1,y+h*.23f,z-1,X+1,Y+1,Z+1));cuts.add(b(x+w*.4f,y+h*.12f,z-1,X+1,y+h*.24f,Z+1));}
  }else if(zone==0){
   if(stage>=1||(shape&16)!=0)cuts.add(b(x+w*.65f,y+h*.33f,z-1,X+1,y+h*.56f,z+d*.25f));
   if(stage>=2)cuts.add(b(x+w*.55f,y-1,z-1,X+1,y+h*.52f,z+d*.6f));
   if(stage>=3)cuts.add(b(x+w*.42f,y+h*.35f,z-1,X+1,y+h*.72f,z+d*.73f));
   if(stage>=4)cuts.add(b(x+w*.3f,y-1,z-1,X+1,y+h*.55f,Z+1));
   if(stage>=5)cuts.add(b(x-1,y+h*.72f,z-1,X+1,Y+1,z+d*.55f));
   if(stage>=6)cuts.add(b(x-1,y-1,z-1,X+1,y+h*.55f,Z+1));
   if(stage>=7)cuts.add(b(x+w*.2f,y-1,z-1,X+1,Y+1,Z+1));
  }else if(zone==4||zone==5){
   cuts.add(b(x+w*.55f,y+h*.20f,z-1,X+1,y+h*.43f,z+d*(stage>=2?.7f:.25f)));
   if(stage>=3)cuts.add(b(x+w*.3f,y+h*.48f,z-1,X+1,y+h*.73f,z+d*.8f));
   if(stage>=4)cuts.add(b(x-1,y+h*.74f,z-1,X+1,Y+1,Z+1));
   if(stage>=5)cuts.add(b(x-1,y+h*.44f,z-1,X+1,Y+1,Z+1));
   if(stage>=6)cuts.add(b(x-1,y+h*.2f,z-1,X+1,Y+1,Z+1));
   if(stage>=7)cuts.add(b(x+w*.3f,y+h*.05f,z-1,X+1,Y+1,Z+1));
  }else{
   boolean right=zone==7;float left=right?x:x+w*.52f,rightX=right?x+w*.48f:X;
   cuts.add(b(left,y+h*.24f,z-1,rightX,y+h*.48f,z+d*(stage>=2?.75f:.25f)));
   if(stage>=3)cuts.add(b(left,y+h*.48f,z-1,rightX,y+h*.74f,z+d*.75f));
   if(stage>=4)cuts.add(b(left,y+h*.12f,z-1,rightX,y+h*.79f,Z+1));
   if(stage>=5)cuts.add(b(left,y+h*.03f,z-1,rightX,y+h*.94f,Z+1));
   if(stage>=6)cuts.add(b(left,y-1,z-1,rightX,Y+1,Z+1));
   if(stage>=7)cuts.add(b(right?x:x+w*.44f,y-1,z-1,right?x+w*.56f:X,Y+1,Z+1));
  }
 }
 public static List<Mesh12.Quad> build(List<Mesh12.Cube> original,int zone,int shape){List<Mesh12.Quad> out=new ArrayList<>();if(original.isEmpty())return out;
  float x=Float.MAX_VALUE,y=x,z=x,X=-x,Y=-x,Z=-x;for(var c:original){var a=c.bounds();x=Math.min(x,a.x0());y=Math.min(y,a.y0());z=Math.min(z,a.z0());X=Math.max(X,a.x1());Y=Math.max(Y,a.y1());Z=Math.max(Z,a.z1());}var all=b(x,y,z,X,Y,Z);float w=X-x,h=Y-y,d=Z-z;List<Mesh12.Box> cuts=new ArrayList<>();
  if(zone==6){int l=shape&31,r=shape>>>5&31;if(l!=0)cut(cuts,all,6,l);if(r!=0)cut(cuts,all,7,r);}else cut(cuts,all,zone,shape);
  for(var cube:original){List<Mesh12.Box> fragments=List.of(cube.bounds());for(var wound:cuts){List<Mesh12.Box> next=new ArrayList<>();for(var f:fragments)next.addAll(Mesh12.subtract(f,wound));fragments=next;}for(var f:fragments)Mesh12.box(out,f,0,cube);}
  int stage=shape&7;boolean arm=zone==2||zone==3,severe=arm&&(shape&8)!=0;
  if(arm||zone==4||zone==5){float bx=x+w*.5f,bz=z+d*.55f;float bottom=arm?((shape&1)!=0?y+h*.82f:Y-.3f):Y-.2f;float top=y+h*.17f;
   if((shape&7)!=0){Mesh12.box(out,b(bx-.34f,top,bz-.34f,bx+.34f,bottom,bz+.34f),2,null);Mesh12.box(out,b(bx-.55f,y+h*.44f,bz-.5f,bx+.55f,y+h*.52f,bz+.5f),2,null);}
   if(severe||stage>=5){Mesh12.box(out,b(bx+.25f,top,z+d*.35f,bx+.55f,y+h*.64f,z+d*.55f),2,null);Mesh12.box(out,b(bx-.45f,y+h*.17f,z+d*.25f,bx+.45f,y+h*.27f,z+d*.6f),1,null);}
  }else if(zone==0){
   if(stage>=2)Mesh12.box(out,b(x+w*.26f,y+h*.08f,z+d*.48f,x+w*.44f,y+h*.16f,z+d*.66f),2,null);
   if(stage>=2)for(int j=0;j<3;j++){float bx=x+w*(.4f+j*.13f);Mesh12.box(out,b(bx,y+h*.55f-.6f,z+d*.55f,bx+.85f,y+h*.57f,z+d*.8f),5,null);}
   if(stage>=3){float ex=x+w*.7f,ey=y+h*.66f,ez=z-1.1f;Mesh12.box(out,b(ex-.13f,ey-1.4f,ez+.3f,ex+.13f,ey,ez+.55f),1,null);Mesh12.box(out,b(ex-.7f,ey-.6f,ez-.5f,ex+.7f,ey+.6f,ez+.6f),3,null);Mesh12.box(out,b(ex-.28f,ey-.28f,ez-.56f,ex+.28f,ey+.28f,ez-.5f),4,null);}
   if(stage>=4){Mesh12.box(out,b(x+w*.18f,y+h*.5f,z+d*.53f,x+w*.34f,Y-.2f,z+d*.70f),2,null);}
  }else{
   int l=shape&7,r=shape>>>5&7;if(l>=2||r>=2){float spine=x+w*.5f;Mesh12.box(out,b(spine-.35f,y+.7f,z+d*.65f,spine+.35f,Y-.4f,z+d*.82f),2,null);
    for(int j=0;j<4;j++){float ry=y+h*(.2f+j*.12f);if(l>=2)Mesh12.box(out,b(spine,ry,z+d*.5f,X-.2f,ry+.4f,z+d*.65f),2,null);if(r>=2)Mesh12.box(out,b(x+.2f,ry,z+d*.5f,spine,ry+.4f,z+d*.65f),2,null);}
    if(l>=3||r>=3)Mesh12.box(out,b(spine-.8f,y+h*.6f,z+d*.3f,spine+.6f,y+h*.76f,z+d*.58f),1,null);
   }
  }
  return List.copyOf(out);
 }
}
