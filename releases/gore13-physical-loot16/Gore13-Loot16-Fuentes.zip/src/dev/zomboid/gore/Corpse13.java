package dev.zomboid.gore;
import java.util.*;
/** Accepted native ragdoll hits update retained wounds and travel in the ordered impulse packet. */
public final class Corpse13 {
 static final String BASE="com.raiiiden.ragdollified.",SERVER=BASE+"server.ServerRagdollSyncManager",CLIENT=BASE+"client.ClientRagdollManager";
 static final Map<Object,Map<Integer,Pending>> PENDING=Collections.synchronizedMap(new WeakHashMap<>());
 record Pending(int state,int details,int surfaces,int revision){}
 static Object retained(int id){return ((Map<?,?>)R.get(R.type(SERVER),"RETAINED")).get(id);}
 static int i(Object o,String f){return ((Number)R.get(o,f)).intValue();}
 static Object level(){return R.get(R.call(R.type("net.minecraft.client.Minecraft"),"getInstance"),"level");}
 static boolean zombie(Object packet){return i(packet,"goreState12")<0;}
 static Object pose(Object retained,int part){Object transforms=R.get(retained,"settledTransforms");if(transforms==null)transforms=R.get(retained,"latestStreamTransforms");if(transforms!=null)R.set(retained,"gorePose13",transforms);else transforms=R.get(retained,"gorePose13");if(transforms instanceof Object[] a&&part>=0&&part<a.length)return a[part];return null;}
 public static void server(Object level,Object sender,int id,int part,Object impact,float damage){
  if(part<0||part>5||!Float.isFinite(damage)||damage<=0)return;Object body=retained(id);if(body==null||R.yes(R.get(body,"live"))||!R.get(body,"dimension").equals(R.call(level,"dimension")))return;Object packet=R.get(body,"spawnPacket");if(!zombie(packet))return;
  if(sender!=null&&!R.yes(R.call(sender,"isAlive")))return;
  Object transform=pose(body,part);Object centre=transform==null?R.call(body,"anchor"):R.get(transform,"position");double x=R.num(R.get(centre,"x")),y=R.num(R.get(centre,"y")),z=R.num(R.get(centre,"z"));
  if(impact!=null){double dx=R.num(R.get(impact,"x"))-x,dy=R.num(R.get(impact,"y"))-y,dz=R.num(R.get(impact,"z"))-z;if(dx*dx+dy*dy+dz*dz>(transform==null?9:2.25))return;}
  int kind=1;if(sender!=null){Object held=R.call(sender,"getMainHandItem");kind=Damage13.kindOf(held);boolean gun=false;try{gun=R.call(R.type("com.tacz.guns.api.item.IGun"),"of",held)!=null;}catch(RuntimeException ignored){}
   double allowed=gun?Math.max(16,R.num(R.call(R.type(BASE+"api.RagdollifiedServerApi"),"getPhysicsDistance"))):Math.max(3,R.num(R.call(sender,"getAttributeValue",R.get(R.type("net.minecraft.world.entity.ai.attributes.Attributes"),"ENTITY_INTERACTION_RANGE"))))+1;
   if(R.num(R.call(sender,"distanceToSqr",x,y,z))>allowed*allowed)return;
   Object end=R.make("net.minecraft.world.phys.Vec3",x,y,z),eye=R.call(sender,"getEyePosition"),clip=R.make("net.minecraft.world.level.ClipContext",eye,end,R.get(R.type("net.minecraft.world.level.ClipContext$Block"),"COLLIDER"),R.get(R.type("net.minecraft.world.level.ClipContext$Fluid"),"NONE"),sender),hit=R.call(level,"clip",clip);
   if(R.call(hit,"getType").toString().equals("BLOCK")&&R.num(R.call(R.call(hit,"getLocation"),"distanceToSqr",end))>.36)return;
   if(gun)kind=1;
  }
  int zone=Damage13.region(part);double fraction=.5;
  if(transform!=null&&impact!=null){Object rot=R.get(transform,"rotation");double qx=R.num(R.get(rot,"x")),qy=R.num(R.get(rot,"y")),qz=R.num(R.get(rot,"z")),qw=R.num(R.get(rot,"w"));double dx=R.num(R.get(impact,"x"))-x,dy=R.num(R.get(impact,"y"))-y,dz=R.num(R.get(impact,"z"))-z;
   double localX=(1-2*(qy*qy+qz*qz))*dx+2*(qx*qy+qz*qw)*dy+2*(qx*qz-qy*qw)*dz;
   double localY=2*(qx*qy-qz*qw)*dx+(1-2*(qx*qx+qz*qz))*dy+2*(qy*qz+qx*qw)*dz;
   fraction=Math.max(0,Math.min(1,.5-localY/.75));if(part==0&&localX<0)zone=7;
  }
  long counts=((Number)R.get(packet,"goreCounts13")).longValue();int count=(int)(counts>>>(zone*4)&15)+1;count=Math.min(15,count);counts=counts&~(15L<<(zone*4))|(long)count<<(zone*4);R.set(packet,"goreCounts13",counts);
  Damage13.Result r=Damage13.hit(i(packet,"goreState12"),i(packet,"goreDetails12"),i(packet,"goreSurface12"),zone,count,kind,fraction);R.set(packet,"goreState12",r.state());R.set(packet,"goreDetails12",r.details());R.set(packet,"goreSurface12",r.surfaces());
  try{R.call(R.type("dev.zomboid.remains.BodyLoot16"),"dirty",level,id);}catch(RuntimeException ex){if(!(ex.getCause() instanceof ClassNotFoundException))throw ex;}
 }
 public static void ordered(Object level,Object msg){Object body=retained(i(msg,"ragdollId"));if(body==null||!R.get(body,"dimension").equals(R.call(level,"dimension")))return;Trauma12.snapshot(R.get(body,"spawnPacket"),msg);}
 public static void client(Object msg){if(i(msg,"partIndex")==-16){R.call(R.type(CLIENT),"requestRemoveRagdoll",i(msg,"ragdollId"));return;}int state=i(msg,"goreState12");if(state>=0&&i(msg,"goreSurface12")>=0)return;int id=i(msg,"ragdollId"),revision=i(msg,"revision");Object doll=R.call(R.type(CLIENT),"get",id);Pending pending=new Pending(state,i(msg,"goreDetails12"),i(msg,"goreSurface12"),revision);
  if(i(msg,"partIndex")==-16){R.call(R.type(CLIENT),"requestRemoveRagdoll",id);return;}if(doll==null){Object world=level();Map<Integer,Pending> map=PENDING.computeIfAbsent(world,k->new java.util.concurrent.ConcurrentHashMap<>());if(map.size()>256)map.clear();Pending old=map.get(id);if(old==null||old.revision<revision)map.put(id,pending);return;}
  if(revision<=i(doll,"goreRevision13"))return;apply(doll,pending);if(R.num(R.get(msg,"sourceDamage"))<=0)return;
  Object world=level();if(world!=null&&Blood12.frame(world)){double x=R.num(R.get(msg,"impactX")),y=R.num(R.get(msg,"impactY")),z=R.num(R.get(msg,"impactZ"));if(Double.isFinite(x)&&Double.isFinite(y)&&Double.isFinite(z)){Shards13.burst(world,x,y,z,3,i(msg,"partIndex")==1);Blood12.emit(world,x,y,z,true,6);}}
 }
 static void apply(Object doll,Pending p){if(p.surfaces<0)R.call(R.type(CLIENT),"setPersistent",i(doll,"originalEntityId"),true);R.set(doll,"goreState12",p.state);R.set(doll,"goreDetails12",p.details);R.set(doll,"goreSurface12",p.surfaces);R.set(doll,"goreRevision13",p.revision);Texture13.report(doll);Object world=level();if(world!=null)R.set(doll,"goreBleedUntil13",((Number)R.call(world,"getGameTime")).longValue()+80);}
 public static void born(Object doll){Texture13.report(doll);if(i(doll,"goreSurface12")<0)R.call(R.type(CLIENT),"setPersistent",i(doll,"originalEntityId"),true);Map<Integer,Pending> map=PENDING.get(level());if(map!=null){Pending p=map.remove(i(doll,"originalEntityId"));if(p!=null)apply(doll,p);}}
 public static boolean loot(Object sender,Object msg){if(Texture13.receive(sender,msg))return true;if(i(msg,"partIndex")!=-13)return false;try{R.call(R.type("dev.zomboid.remains.BodyLoot16"),"open",sender,i(msg,"ragdollId"));}catch(RuntimeException ex){if(!(ex.getCause() instanceof ClassNotFoundException))throw ex;}return true;}
}
