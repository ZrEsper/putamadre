package dev.zomboid.gore;
import java.util.*;
public final class Trauma13 {
 static Object impactAccessor;
 static final Map<Object,Integer> seen=new WeakHashMap<>();
 public static void init(){impactAccessor=R.call(R.type("net.minecraft.network.syncher.SynchedEntityData"),"defineId",R.type("net.minecraft.world.entity.monster.Zombie"),R.get(R.type("net.minecraft.network.syncher.EntityDataSerializers"),"INT"));}
 public static void define(Object b){R.call(b,"define",impactAccessor,0);}
 static int integer(Object t,String key){return ((Number)R.call(t,"getInt",key)).intValue();}
 public static void injure(Object e,Gore.Shot shot,float damage,int surface){
  if(!(damage>0))return;int z=Ballistics11.zone(shot);if(z==1)z=0;
  Object tag=Gore.tag(e);int count=integer(tag,"zg13_hits_"+z)+1;R.call(tag,"putInt","zg13_hits_"+z,count);
  double height=Math.max(.1,R.num(R.call(e,"getBbHeight"))),relative=(R.num(R.get(shot.point(),"y"))-R.num(R.call(e,"getY")))/height;
  double local=relative<.43?1-relative/.43:1-(relative-.43)/.34;
  int kind=shot.bullet()!=null?1:0;
  if(shot.bullet()==null){Object src=Ballistics11.SOURCE.get(),attacker=src==null?null:R.call(src,"getEntity");if(attacker!=null&&R.type("net.minecraft.world.entity.LivingEntity").isInstance(attacker))kind=Damage13.kindOf(R.call(attacker,"getMainHandItem"));}
  Damage13.Result r=Damage13.hit(Gore.state(e),Trauma12.details(e),Gore.surfaces(e),z,count,kind,local);
  Trauma12.set(e,r.details());Gore.surfaceSet(e,r.surfaces());Gore.set(e,r.state());
  int serial=integer(tag,"zg13_serial")+1;if(serial>10000000)serial=1;R.call(tag,"putInt","zg13_serial",serial);R.call(R.call(e,"getEntityData"),"set",impactAccessor,serial<<4|z);
  long now=((Number)R.call(R.call(e,"level"),"getGameTime")).longValue();R.call(tag,"putLong","zg13_bleedUntil",now+(count>=3?180L:80L));
  boolean strong=shot.gun()==Rules.Weapon.SNIPER||shot.gun()==Rules.Weapon.SHOTGUN;
  boolean fatal=z==0&&(shot.bullet()!=null?(strong||count>=2):kind==2&&damage>=5&&count>=2);
  if(shot.bullet()!=null)Gore.push(e,shot.bullet(),shot.gun());
  if(fatal){Object source=Ballistics11.SOURCE.get();if(source==null)source=R.call(R.call(e,"damageSources"),"generic");R.call(e,"setHealth",0f);R.call(e,"die",source);}
 }
 public static void tick(Object event){Object e=R.call(event,"getEntity");if(!Gore.zombie(e))return;Object level=R.call(e,"level");if(R.yes(R.get(level,"isClientSide"))){
  Blood12.frame(level);int hit=((Number)R.call(R.call(e,"getEntityData"),"get",impactAccessor)).intValue();Integer old=seen.put(e,hit);if(hit!=0&&(old==null||old!=hit)){Blood12.LIVE.remove(e);int z=hit&15;Object p=R.call(e,"position");double y=R.num(R.get(p,"y"))+R.num(R.call(e,"getBbHeight"))*(z==0?.86:z<4?.64:z<6?.3:.6);Shards13.burst(level,R.num(R.get(p,"x")),y,R.num(R.get(p,"z")),2,z==0);Blood12.emit(level,R.num(R.get(p,"x")),y,R.num(R.get(p,"z")),z==0,5);}return;
  }
  long now=((Number)R.call(level,"getGameTime")).longValue();if(now%20!=0||!R.yes(R.call(e,"isAlive")))return;
  Object tag=Gore.tag(e);long until=((Number)R.call(tag,"getLong","zg13_bleedUntil")).longValue();if(now>until)return;
  float hp=(float)R.num(R.call(e,"getHealth")),loss=(float)Math.min(1.5,Math.max(.25,R.num(R.call(e,"getMaxHealth"))*.0125));
  if(hp>loss)R.call(e,"setHealth",hp-loss);else{Object source=R.call(R.call(e,"damageSources"),"generic");R.call(e,"setHealth",0f);R.call(e,"die",source);}
 }
}
