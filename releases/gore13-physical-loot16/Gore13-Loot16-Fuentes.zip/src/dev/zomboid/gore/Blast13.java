package dev.zomboid.gore;
public final class Blast13 {
 public static void detonate(Object event){Object level=R.call(event,"getLevel");if(R.yes(R.get(level,"isClientSide")))return;Object blast=R.call(event,"getExplosion"),centre=R.call(blast,"center");double radius=R.num(R.call(blast,"radius"))*2;if(!(radius>0))return;
  Iterable<?> bodies=(Iterable<?>)R.call(R.type(Corpse13.SERVER),"retainedBodiesNear",R.call(level,"dimension"),centre,radius);
  for(Object view:bodies){if(R.yes(R.call(view,"live")))continue;int id=((Number)R.call(view,"entityId")).intValue();Object body=Corpse13.retained(id);if(body==null)continue;Object packet=R.get(body,"spawnPacket");if(!Corpse13.zombie(packet))continue;double exposure=R.num(R.call(R.type("com.raiiiden.ragdollified.server.RagdollWorldPushes"),"exposure",level,centre,view));if(exposure<=.05)continue;
   int state=Corpse13.i(packet,"goreState12"),details=Corpse13.i(packet,"goreDetails12"),surface=Corpse13.i(packet,"goreSurface12");for(int z=0;z<8;z++){var r=Damage13.hit(state,details,surface,z,7,2,.5);state=r.state();details=r.details();surface=r.surfaces();}R.set(packet,"goreState12",state);R.set(packet,"goreDetails12",details);R.set(packet,"goreSurface12",surface);
   Object anchor=R.call(view,"anchor");for(int n=0;n<3;n++){int index=1+Math.floorMod(id+n*2,5);Object part=R.call(R.type("com.raiiiden.ragdollified.RagdollPart"),"byIndex",index);R.call(R.type("com.raiiiden.ragdollified.api.RagdollifiedServerApi"),"severRagdollPart",level,anchor,id,part,null,80);}
   R.call(R.type("com.raiiiden.ragdollified.network.RagdollImpulsePacket"),"broadcastOrdered",level,null,id,0,R.get(R.type("net.minecraft.world.phys.Vec3"),"ZERO"),anchor,1f);
  }
 }
}
