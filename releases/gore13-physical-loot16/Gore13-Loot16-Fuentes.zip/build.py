from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import subprocess,json,hashlib
r=Path('work/gore13')
inputs=[Path('work/gore12/release/zomboid-zombie-gore-1.0.12-neoforge-1.21.1-ragdoll-trauma.jar'),Path('work/gore12/release/ragdollified-1.21.1-1.1.5-gore-preservation.1.jar'),next(Path('attachments/5661b7d2-6862-4e5b-8f2a-d29de1fead16').glob('*.jar')),Path('work/gore12/release/mobdismembermentneoforge-1.21.1-1.4.0-explosions-only.2.jar'),Path('work/gore12/release/splatter-1.21.1-0.3.0-neoforge-blood-budget.2.jar')]
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
def run(args):subprocess.run(args,check=True)
run(['java','com.sun.tools.javac.Main','-cp',str(inputs[0]),'-d',str(r/'classes'),*map(str,(r/'src').rglob('*.java')),*map(str,(r/'stubs').rglob('*.java'))])
run(['java',*flags,'com.sun.tools.javac.Main',*flags,'-d',str(r/'tools'),str(r/'Patch.java')])
run(['java',*flags,'-cp',str(r/'tools'),'Patch',*map(str,inputs[:3])])
run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/belroft3/classes','Verify',str(r/'classes')])
out=r/'release';out.mkdir(exist_ok=True);manifest=[]
names=['zomboid-zombie-gore-1.0.13-neoforge-1.21.1-live-corpse-trauma.jar','ragdollified-1.21.1-1.1.5-gore-loot.2.jar','zombie-remains-loot-1.6.1-neoforge-1.21.1-physical-corpse-loot.16.jar','mobdismembermentneoforge-1.21.1-1.4.0-gore13-compat.3.jar',inputs[4].name]
prefixes=['dev/zomboid/gore/','com/raiiiden/ragdollified/','dev/zomboid/remains/',None,None]
for index,(base,name,prefix) in enumerate(zip(inputs,names,prefixes)):
 with ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()};original=data.copy()
 changes={p.relative_to(r/'classes').as_posix():p.read_bytes() for p in (r/'classes'/prefix).rglob('*.class')} if prefix else {};data.update(changes)
 if index==0:
  config=json.loads(data['zomboid_gore.mixins.json']);config['client']+=['EmfWounds13','CorpseBullet13'];data['zomboid_gore.mixins.json']=json.dumps(config,indent=2).encode()
  metadata=data['META-INF/neoforge.mods.toml'].decode().replace('version="1.0.12"','version="1.0.13"');metadata+='\n[[dependencies.zomboid_gore]]\nmodId="ragdollified"\ntype="required"\nversionRange="[1.1.5-gore13,1.1.6)"\nordering="NONE"\nside="BOTH"\n';data['META-INF/neoforge.mods.toml']=metadata.encode()
 elif index==1:
  data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'1.1.5-gore12',b'1.1.5-gore13').replace(b'[1.0.12,1.0.13)',b'[1.0.13,1.0.14)')
 elif index==2:
  metadata=data['META-INF/neoforge.mods.toml'].decode();import re
  metadata,n=re.subn(r'(?m)^version\s*=\s*"[^"]+"','version="1.6.1-physical-loot16"',metadata,count=1);assert n==1
  metadata+='\n[[dependencies.zombie_remains_loot]]\nmodId="zomboid_gore"\ntype="required"\nversionRange="[1.0.13,1.0.14)"\nordering="AFTER"\nside="BOTH"\n';data['META-INF/neoforge.mods.toml']=metadata.encode()
 elif index==3:data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'1.21.1-1.4.0-explosions2',b'1.21.1-1.4.0-gore13').replace(b'[1.0.12,1.0.13)',b'[1.0.13,1.0.14)')
 if index==4:(out/name).write_bytes(base.read_bytes())
 else:
  with ZipFile(out/name,'w',ZIP_DEFLATED) as z:
   for n,b in data.items():z.writestr(n,b)
 with ZipFile(out/name) as z:
  assert z.testzip() is None;assert not any(n.startswith(('net/minecraft/','com/mojang/','fixture/')) for n in z.namelist())
 manifest.append(dict(input=str(base),input_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),file=name,sha256=hashlib.sha256((out/name).read_bytes()).hexdigest(),modified=[n for n in original if data[n]!=original[n]],added=[n for n in data if n not in original]))
(out/'manifest.json').write_text(json.dumps(manifest,indent=2));print('PASS: 5 JAR integrity, metadata dependency versions, no test stubs packaged; Splatter byte-identical')
