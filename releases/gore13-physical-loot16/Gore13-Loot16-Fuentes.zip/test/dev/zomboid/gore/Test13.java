package dev.zomboid.gore;
import java.util.*;
public class Test13 {
 static void ck(boolean b,String s){if(!b)throw new AssertionError(s);}
 static double volume(Mesh12.Box b){return (b.x1()-b.x0())*(b.y1()-b.y0())*(b.z1()-b.z0());}
 public static void main(String[] args){
  ck(Damage13.kind("item.apocalypticarsenal.battle_axe")==2,"axe class");ck(Damage13.kind("item.minecraft.pickaxe")!=2,"pickaxe distinct");ck(Damage13.kind("item.lrtactical.katana")==1,"sharp melee");
  for(int zone=0;zone<8;zone++){int state=Integer.MIN_VALUE,details=0,surfaces=0;for(int n=1;n<=8;n++){var r=Damage13.hit(state,details,surfaces,zone,n,2,.8);ck((r.state()&255)==0,"localized chunks do not arbitrarily delete whole parts");ck((r.state()&(1<<(zone+8)))!=0,"wound visible in live state");ck((r.state()&Integer.MIN_VALUE)!=0,"corpse identity preserved");state=r.state();details=r.details();surfaces=r.surfaces();}}
  var hand=Damage13.hit(0,0,0,2,1,1,.8);var elbow=Damage13.hit(hand.state(),hand.details(),hand.surfaces(),2,2,1,.5);var upper=Damage13.hit(elbow.state(),elbow.details(),elbow.surfaces(),2,4,2,.1);ck(Trauma12.stage(upper.details(),2)==7&&(upper.surfaces()&(1<<26))!=0,"hand elbow shoulder accumulate to stripped bone");
  ck(Damage13.region(4)==2&&Damage13.region(2)==4&&Damage13.region(0)==6,"live and corpse anatomical mapping");
  for(int zone:new int[]{0,2,3,4,5,6}){for(int stage=1;stage<=7;stage++){int shape=zone==6?stage|(stage<<5):stage;var mesh=Mesh13.build(List.of(Skin12.fallback(zone)),zone,shape);ck(!mesh.isEmpty()&&mesh.size()<512,"bounded regional mesh");for(var q:mesh)for(var v:q.vertices())ck(Float.isFinite(v.x())&&Float.isFinite(v.u()),"finite vertices and UVs");}}
  for(int zone:new int[]{0,4,5,6,7}){var box=Mesh12.canonical(zone==7?6:zone);double before=volume(box);for(int stage=1;stage<=7;stage++){List<Mesh12.Box> cuts=new ArrayList<>();Mesh13.cut(cuts,box,zone,stage);List<Mesh12.Box> fragments=List.of(box);for(var c:cuts){List<Mesh12.Box> next=new ArrayList<>();for(var b:fragments)next.addAll(Mesh12.subtract(b,c));fragments=next;}double remaining=fragments.stream().mapToDouble(Test13::volume).sum();ck(remaining<=before+.001,"tissue never regrows with repeated damage zone="+zone+" stage="+stage);before=remaining;}}
  double[] a={-2,0,0},b={2,0,0};ck(Math.abs(Bullet13.box(a,b,.25,.375,.15)-.4375)<1e-8,"server bullet segment catches corpse part");ck(Double.isNaN(Bullet13.box(new double[]{-2,1,0},new double[]{2,1,0},.25,.375,.15)),"misses stay misses");ck(Bullet13.box(new double[]{0,0,0},new double[]{0,0,1},.25,.375,.15)==0,"inside starts are valid");
  System.out.println("PASS: axes/sharp/blunt classification, all anatomical zones, accumulated missing tissue, exposed bone, monotonic destruction, bounded meshes, finite UVs and server bullet segment tests");
 }
}
