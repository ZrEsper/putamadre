from pathlib import Path
import subprocess,argparse
r=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--jar',default=str(r/'release/tacznpcs-2.1.0-1.21.1-tactical.58-work-sites.jar'));p.add_argument('--tools',default='/workspace/putamadre/hordes-melee-interiors-patch/build/tools');p.add_argument('--gson',default='/workspace/medical63/gson.jar');a=p.parse_args()
subprocess.run(['java','-jar',str(Path(a.tools)/'ecj.jar'),'-21','-nowarn','-proc:none','-cp',a.jar+':'+a.gson,'-d',str(r/'checks')]+[str(f)for f in (r/'checksrc').rglob('*.java')],check=True)
with (r/'test-output.txt').open('w')as out:
 for name in ['InventoryTest56','PlacementTest56','DialogueTest56','GuardTest56','WorkTest56','CheckWork90','CheckSmart90','CheckRoutine91']:
  x=subprocess.run(['java','-Xverify:all','-Xmx256m','-cp',str(r/'checks')+':'+a.jar+':'+a.gson,'mod.cdv.tnpc.tactical.'+name],capture_output=True,text=True,cwd=r);out.write(name+'\n'+x.stdout+x.stderr);print(name, 'PASS'if x.returncode==0 else'FAIL')
  if x.returncode:print(x.stdout+x.stderr);raise SystemExit(x.returncode)
