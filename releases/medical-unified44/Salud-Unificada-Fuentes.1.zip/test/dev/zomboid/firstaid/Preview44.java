package dev.zomboid.firstaid;
import java.util.*;
public class Preview44{
 public static void main(String[]args)throws Exception{Test44.Graphics g=new Test44.Graphics();for(int view=0;view<2;view++)for(int i=0;i<8;i++){List<String> labels=new ArrayList<>();if(i==1||i==3)labels.add("bullet");if(i==2)labels.add("bruise");if(i==4||i==6)labels.add("cut");boolean splint=i==5;if(view==1&&(i==0||i==1||i==3||i==4))labels.add("bandaged");var w=new ichttt.mods.firstaid.survival.ClinicalState.Wound();w.bullets=i==1?14:i==3?6:0;var p=new MedicalView40.Part(null,null,w,4,10,i==6,splint,splint,labels);Marks42.silhouette(g,i,20+view*340,30,3,0xFF18191B);Marks42.marks(g,i,p,20+view*340,30,3);}java.nio.file.Files.writeString(java.nio.file.Path.of("work/medical44/preview-shapes.json"),g.calls.stream().map(Arrays::toString).toList().toString());}
}
