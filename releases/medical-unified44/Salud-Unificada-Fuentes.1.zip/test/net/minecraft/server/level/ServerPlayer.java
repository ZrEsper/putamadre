package net.minecraft.server.level;public class ServerPlayer{public int tickCount=100;public boolean isCreative(){return false;}public boolean isSpectator(){return false;}}
