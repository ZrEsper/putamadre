package ichttt.mods.firstaid.fracture;public class Bleeding{public static void start(Object p,Object part){}}
