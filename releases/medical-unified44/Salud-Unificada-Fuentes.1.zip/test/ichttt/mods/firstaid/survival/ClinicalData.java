package ichttt.mods.firstaid.survival;public class ClinicalData{public static Object state(dev.zomboid.firstaid.Test44.Model model){return model.state;}}
