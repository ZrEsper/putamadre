from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import subprocess,json,hashlib
r=Path('work/medical44');base=Path('attachments/3d7f01ba-d3d0-4ec7-b5ff-a9a4903f65b4/firstaid-1.21.1-ZOMBOID-v3.6.13-alcohol-15-uses.jar');compat=Path('attachments/decdddd5-9ef2-4989-acf3-a2e27482b46a/tacz-firstaid-compat-1.0.1.jar');npc=Path('attachments/e2e3cb98-50b5-414d-9c0f-30cb508bc048/tacznpcs-2.1.0-1.21.1-tactical.27-threat-cover-armor.jar');out=r/'release';out.mkdir(exist_ok=True)
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
subprocess.run(['java','com.sun.tools.javac.Main','-cp',str(base),'-d',str(r/'classes'),*map(str,(r/'src').rglob('*.java'))],check=True)
subprocess.run(['java','com.sun.tools.javac.Main','-cp',str(npc),'-d',str(r/'classes'),*map(str,(r/'npcsrc').rglob('*.java'))],check=True)
subprocess.run(['java','com.sun.tools.javac.Main',*flags,'-d',str(r/'tools'),str(r/'Patch.java')],check=True)
subprocess.run(['java',*flags,'-cp',str(r/'tools'),'Patch',str(base),str(compat),str(npc)],check=True)
subprocess.run(['java',*flags,'--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','-cp','work/belroft3/classes','Verify',str(r/'classes')],check=True)
manifest=[]
for source,name,prefixes in [(base,'firstaid-1.21.1-ZOMBOID-v3.6.14-unified-medical-care.jar',['dev/zomboid/firstaid/','ichttt/']),(compat,'tacz-firstaid-compat-1.0.2-localized-wound-sync.jar',['ru/']),(npc,'tacznpcs-2.1.0-1.21.1-tactical.28-unified-medical-care.jar',['mod/'])]:
 changes={p.relative_to(r/'classes').as_posix():p.read_bytes() for prefix in prefixes for p in (r/'classes'/prefix).rglob('*.class')}
 with ZipFile(source) as z:data={n:z.read(n) for n in z.namelist()}
 original=data.copy();data.update(changes)
 if source==base:
  meta=data['META-INF/neoforge.mods.toml'].decode().replace('zomboid-v3.6.13-alcohol-15-uses','zomboid-v3.6.14-unified-medical-care').replace('First Aid · Zomboid v3.6.11 · Lesiones y ejercicio','First Aid · Zomboid v3.6.14 · Salud unificada')
  meta+='\n[[mixins]]\nconfig="firstaid.medical44.mixins.json"\n';data['META-INF/neoforge.mods.toml']=meta.encode()
  data['firstaid.medical44.mixins.json']=json.dumps({'required':False,'minVersion':'0.8','package':'dev.zomboid.firstaid.mixin','compatibilityLevel':'JAVA_21','mixins':['CareActions44','CareRows44'],'client':['CareScreen44'],'injectors':{'defaultRequire':0}}).encode()
  for lang,words in {'es_es':['Moretón','Inflamación','Necesitas alcohol médico.','Compañero'],'es_mx':['Moretón','Inflamación','Necesitas alcohol médico.','Compañero'],'en_us':['Bruise','Inflammation','Medical alcohol required.','Companion'],'de_de':['Bluterguss','Entzündung','Medizinischer Alkohol erforderlich.','Begleiter']}.items():
   path='assets/firstaid/lang/'+lang+'.json';d=json.loads(data[path]);d.update(dict(zip(['firstaid.medical.injury.bruise','firstaid.medical.injury.irritation','firstaid.medical.requirement.need_alcohol','firstaid.medical.other_short'],words)));data[path]=json.dumps(d,ensure_ascii=False,indent=2).encode()
 elif source==compat:
  data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'version="1.0.0"',b'version="1.0.2"').replace(b'version="1.0.1"',b'version="1.0.2"')
  # The bridge now requires the anatomical recorder supplied by this First Aid version.
  text=data['META-INF/neoforge.mods.toml'].decode().replace('versionRange="[1.2.6,)"','versionRange="[1.3.3+neoforge1.21.1-zomboid-v3.6.14-unified-medical-care]"');data['META-INF/neoforge.mods.toml']=text.encode()
 if source==npc:data['META-INF/neoforge.mods.toml']=data['META-INF/neoforge.mods.toml'].replace(b'2.1.0-tactical.27-threat-cover-armor',b'2.1.0-tactical.28-unified-medical-care')
 with ZipFile(out/name,'w',ZIP_DEFLATED) as z:
  for n,b in data.items():z.writestr(n,b)
 with ZipFile(out/name) as z:assert z.testzip() is None;assert len(z.namelist())==len(set(z.namelist()))
 for n,b in original.items():
  if n not in changes and n!='META-INF/neoforge.mods.toml' and '/lang/' not in n:assert data[n]==b
 manifest.append({'input':str(source),'file':name,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest(),'changed_classes':list(changes)})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
