package dev.zomboid.firstaid;
import java.util.*;
public final class Marks42 {
 static final int[][] ANCHOR={{50,22},{50,61},{75,75},{25,75},{57,137},{43,137},{59,190},{41,190}};
 static final ClassValue<java.lang.invoke.MethodHandle> FILL=new ClassValue<>(){protected java.lang.invoke.MethodHandle computeValue(Class<?> type){try{return java.lang.invoke.MethodHandles.publicLookup().findVirtual(type,"fill",java.lang.invoke.MethodType.methodType(void.class,int.class,int.class,int.class,int.class,int.class)).asType(java.lang.invoke.MethodType.methodType(void.class,Object.class,int.class,int.class,int.class,int.class,int.class));}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}}};
 static void rect(Object g,double bx,double by,double scale,int x,int y,int w,int h,int color){int x1=(int)Math.floor(bx+x*scale),y1=(int)Math.floor(by+y*scale),x2=(int)Math.ceil(bx+(x+w)*scale),y2=(int)Math.ceil(by+(y+h)*scale);try{FILL.get(g.getClass()).invokeExact(g,x1,y1,Math.max(x1+1,x2),Math.max(y1+1,y2),color);}catch(Throwable e){throw new IllegalStateException(e);}}
 static void clipped(Object g,int index,double bx,double by,double scale,int x,int y,int w,int h,int color){int[][] poly=HealthTab40.shapes()[index];for(int yy=y;yy<y+h;yy++){int start=-1;for(int xx=x;xx<=x+w;xx++){boolean in=xx<x+w&&HealthTab40.contains(poly,xx+.5,yy+.5);if(in&&start<0)start=xx;else if(!in&&start>=0){rect(g,bx,by,scale,start,yy,xx-start,1,color);start=-1;}}}}
 public static List<String> shown(MedicalView40.Part p){return p.injuries().contains("bandaged")?List.of("bandaged"):p.injuries();}
 public static int color(String key){return switch(key){case "bandaged","healing","splinted"->0xFF75DA87;case "bruise"->0xFFC190DD;case "bullet"->0xFFD7B58A;case "fracture"->0xFFFFAA63;case "irritation","dirty_bandage"->0xFFEAC15D;case "infection"->0xFFE779C9;case "treating"->0xFF72D4DB;default->0xFFFF7772;};}
 public static int bullets(MedicalView40.Part p){if(p.wound()==null)return p.injuries().contains("bullet")?1:0;return Math.max(0,Math.min(99,((Number)R.get(p.wound(),"bullets")).intValue()));}
 static List<int[]> points(int i){List<int[]> out=new ArrayList<>();int[][] poly=HealthTab40.shapes()[i];for(int y=10;y<197;y+=5)for(int x=15;x<88;x+=4)if(HealthTab40.contains(poly,x,y)&&HealthTab40.contains(poly,x+2,y+3))out.add(new int[]{x,y});out.sort(java.util.Comparator.comparingDouble(p->Math.hypot(p[0]-ANCHOR[i][0],p[1]-ANCHOR[i][1])));return out;}
 static final Map<Integer,List<int[]>> POINTS=new HashMap<>();
 public static void marks(Object g,int i,MedicalView40.Part p,double x,double y,double scale){int cx=ANCHOR[i][0],cy=ANCHOR[i][1];var labels=p.injuries();boolean covered=labels.contains("bandaged");
  if(!covered){
   if(labels.contains("bruise")){for(int dy=-5;dy<=5;dy++){int half=(int)Math.round(5*Math.sqrt(Math.max(0,1-dy*dy/25d)));clipped(g,i,x,y,scale,cx-half,cy+dy,2*half+1,1,Math.abs(dy)<3?0xFF9770A4:0xFF684979);}}
   if(labels.contains("irritation")||labels.contains("infection"))clipped(g,i,x,y,scale,cx-6,cy-2,12,5,labels.contains("infection")?0xFFAE5770:0xFFB57256);
   if(labels.contains("cut")||labels.contains("health_loss")){clipped(g,i,x,y,scale,cx-4,cy,8,2,0xFFBB3835);clipped(g,i,x,y,scale,cx,cy-2,3,2,0xFFFF8A82);}
   if(p.broken()){clipped(g,i,x,y,scale,cx-3,cy-10,2,6,0xFFFFA57C);clipped(g,i,x,y,scale,cx-1,cy-5,3,2,0xFFD24C38);clipped(g,i,x,y,scale,cx+1,cy-4,2,6,0xFFFFA57C);}
   if(p.bleeding())clipped(g,i,x,y,scale,cx+1,cy+3,3,5,0xFFB72225);
   int count=bullets(p);List<int[]> points=POINTS.computeIfAbsent(i,Marks42::points);for(int k=0;k<Math.min(count,points.size());k++){int[]q=points.get(k);clipped(g,i,x,y,scale,q[0],q[1],3,4,0xFF592320);clipped(g,i,x,y,scale,q[0]+1,q[1],1,3,0xFFE1C58D);}
  }else{
   // Forehead band (y 10..14) leaves the eye line y 20..25 unobstructed.
   int top=i==0?10:cy-6,height=i==0?5:12;clipped(g,i,x,y,scale,cx-12,top,24,height,0xFFE7DFC9);
   clipped(g,i,x,y,scale,cx-12,top,24,1,0xFFAAA58F);clipped(g,i,x,y,scale,cx-12,top+height-1,24,1,0xFFAAA58F);
   if(i!=0)for(int yy=top+3;yy<top+height-2;yy+=4)clipped(g,i,x,y,scale,cx-12,yy,24,1,0xFFC6BEA9);
   if(labels.contains("dirty_bandage"))clipped(g,i,x,y,scale,cx-2,top+1,4,Math.max(1,height-2),0xFFAA8556);
  }
  if(p.splinted()){for(int dx:new int[]{-5,3})clipped(g,i,x,y,scale,cx+dx,cy-18,2,36,0xFFC6AA78);for(int dy:new int[]{-13,0,12})clipped(g,i,x,y,scale,cx-6,cy+dy,12,3,0xFFDBD7C2);}
 }
 static final Map<Integer,List<int[]>> SPANS=new HashMap<>(),EDGES=new HashMap<>();
 public static void silhouette(Object g,int index,double bx,double by,double scale,int color){
  if(!SPANS.containsKey(index)){List<int[]> spans=new ArrayList<>(),edges=new ArrayList<>();int[][]p=HealthTab40.shapes()[index];for(int yy=0;yy<200;yy++){int start=-1;for(int xx=0;xx<=100;xx++){boolean in=xx<100&&HealthTab40.contains(p,xx+.5,yy+.5);if(in&&start<0)start=xx;else if(!in&&start>=0){spans.add(new int[]{start,yy,xx-start,1});start=-1;}}}for(int j=0;j<p.length;j++){int[]a=p[j],b=p[(j+1)%p.length];int steps=Math.max(Math.abs(a[0]-b[0]),Math.abs(a[1]-b[1]));for(int k=0;k<=steps;k++){double t=steps==0?0:k/(double)steps;edges.add(new int[]{(int)(a[0]+(b[0]-a[0])*t),(int)(a[1]+(b[1]-a[1])*t),1,1});}}SPANS.put(index,spans);EDGES.put(index,edges);}
  for(int[]p:SPANS.get(index))rect(g,bx,by,scale,p[0],p[1],p[2],p[3],color);for(int[]p:EDGES.get(index))rect(g,bx,by,scale,p[0],p[1],p[2],p[3],0xFFFFFFFF);
 }
}
