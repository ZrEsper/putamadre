package dev.zomboid.firstaid;
import java.util.*;
/** Small fixed-scale silhouette at the top-left. Reuses the medical model, not a second injury state. */
public final class MedicalHud40 {
 record Rect(int x,int y,int w,int h){}
 static List<Rect>[] fills,edges;static Object lastPlayer,lastModel;static int lastTick=-1;static MedicalView40.Snapshot snapshot;
 static final double SCALE=.36;static final int X=1,Y=1;
 @SuppressWarnings("unchecked") static void geometry(){if(fills!=null)return;fills=new List[8];edges=new List[8];for(int i=0;i<8;i++){fills[i]=new ArrayList<>();edges[i]=new ArrayList<>();int[][] p=HealthTab40.shapes()[i];for(int y=0;y<73;y++)for(int x=0;x<37;x++)if(HealthTab40.contains(p,(x+.5)/SCALE,(y+.5)/SCALE))fills[i].add(new Rect(x,y,1,1));for(int j=0;j<p.length;j++){int[] a=p[j],b=p[(j+1)%p.length];int steps=Math.max(Math.abs(a[0]-b[0]),Math.abs(a[1]-b[1]));for(int k=0;k<=steps;k++){double t=steps==0?0:k/(double)steps;edges[i].add(new Rect((int)((a[0]+(b[0]-a[0])*t)*SCALE),(int)((a[1]+(b[1]-a[1])*t)*SCALE),1,1));}}fills[i]=merge(fills[i]);edges[i]=List.copyOf(new LinkedHashSet<>(edges[i]));}}
 static List<Rect> merge(List<Rect> pixels){List<Rect> out=new ArrayList<>();for(Rect p:pixels){if(!out.isEmpty()){Rect prev=out.get(out.size()-1);if(prev.y==p.y&&prev.x+prev.w==p.x){out.set(out.size()-1,new Rect(prev.x,prev.y,prev.w+1,1));continue;}}out.add(p);}return out;}
 static void box(Object g,int x,int y,int w,int h,int color){R.call(g,"fill",X+x,Y+y,X+x+w,Y+y+h,color);}
 public static void render(Object model,Object g,float alpha){geometry();Object mc=R.call(R.type("net.minecraft.client.Minecraft"),"getInstance"),player=R.get(mc,"player");if(player==null)return;int tick=((Number)R.get(player,"tickCount")).intValue();if(snapshot==null||player!=lastPlayer||model!=lastModel||lastTick!=tick){snapshot=MedicalView40.readModel(model);lastTick=tick;lastPlayer=player;lastModel=model;}
  int opacity=Math.max(100,Math.min(255,255-Math.round(alpha))),white=(opacity<<24)|0xFFFFFF,red=(opacity<<24)|0xFF5555,beige=(opacity<<24)|0xE5D6AD;
  for(int i=0;i<8;i++){var part=snapshot.parts().get(i);int fill=(Math.min(opacity,160)<<24)|(MedicalView40.affected(part)&&!part.injuries().contains("bandaged")?0x482525:0x151515);for(Rect r:fills[i])box(g,r.x,r.y,r.w,r.h,fill);for(Rect r:edges[i])box(g,r.x,r.y,r.w,r.h,white);
   Marks42.marks(g,i,part,X,Y,SCALE);
  }
 }
}
