package dev.zomboid.firstaid;
import java.util.*;
/** Read-only view of the existing eight-part medical model. No clinical mutations. */
public final class MedicalView40 {
 public static final String[] PARTS={"HEAD","BODY","LEFT_ARM","RIGHT_ARM","LEFT_LEG","RIGHT_LEG","LEFT_FOOT","RIGHT_FOOT"};
 public record Part(Object id,Object part,Object wound,double health,double max,boolean bleeding,boolean broken,boolean splinted,List<String> injuries){}
 public record Snapshot(Object player,Object model,List<Part> parts,double health,double max,int pain) {public double fraction(){return max<=0?0:Math.max(0,Math.min(1,health/max));}}
 static Object c(Object o,String m,Object...a){return R.call(o,m,a);}static double n(Object o){return ((Number)o).doubleValue();}static boolean b(Object o,String f){return Boolean.TRUE.equals(R.get(o,f));}
 public static boolean affected(Part p){return p.injuries().contains("bandaged")||p.health()<p.max()-.01||p.bleeding()||p.broken()||p.splinted()||p.injuries().stream().anyMatch(k->!java.util.Set.of("bandaged","dirty_bandage").contains(k));}
 public static int firstAffected(Snapshot s){for(int i=0;i<s.parts().size();i++)if(affected(s.parts().get(i)))return i;return -1;}
 public static String severity(double f){return f>=.999?"healthy":f>=.75?"slight":f>=.40?"moderate":f>=.20?"severe":"critical";}
 public static String pain(int p){return p<=0?"none":p==1?"minor":p==2?"moderate":p==3?"strong":"extreme";}
 public static List<String> labels(boolean gunshot,int bullets,boolean cut,boolean bitten,boolean infected,boolean dirty,boolean bandaged,boolean healing,boolean bleeding,boolean broken,boolean splinted,boolean healer,double hp,double max){
  List<String> out=new ArrayList<>();if(gunshot)out.add("gunshot");if(bullets>0)out.add("bullet");if(cut)out.add("cut");if(bitten)out.add("bite");if(bleeding)out.add("bleeding");if(broken)out.add("fracture");if(splinted)out.add("splinted");if(infected)out.add("infection");if(dirty){out.add("dirty_bandage");if(bandaged&&(cut||gunshot||bitten))out.add("irritation");}if(bandaged)out.add("bandaged");if(healing)out.add("healing");if(healer)out.add("treating");if(out.isEmpty()&&hp<max-.01)out.add("health_loss");return List.copyOf(out);
 }
 public static Snapshot read(Object screen){return readModel(c(screen,"live"));}
 public static Snapshot readModel(Object model){Object mc=c(R.type("net.minecraft.client.Minecraft"),"getInstance"),player=R.get(mc,"player"),state=c(R.type("ichttt.mods.firstaid.survival.ClinicalData"),"state",model);Object[] wounds=(Object[])R.get(state,"wounds");List<Part> parts=new ArrayList<>();double total=0,max=0;
  for(String name:PARTS){Object id=R.get(R.type("ichttt.mods.firstaid.api.enums.EnumPlayerPart"),name),part=c(model,"getFromEnum",id),w=wounds[((Enum<?>)id).ordinal()];double hp=n(R.get(part,"currentHealth")),m=n(c(part,"getMaxHealth"));boolean bleed=player!=null&&Boolean.TRUE.equals(c(R.type("ichttt.mods.firstaid.fracture.Bleeding"),"isBleeding",player,id)),leg=name.endsWith("_LEG"),left=name.equals("LEFT_LEG"),broken=leg&&player!=null&&Boolean.TRUE.equals(c(R.type("ichttt.mods.firstaid.fracture.Fractures"),"isBroken",player,left)),splinted=leg&&player!=null&&Boolean.TRUE.equals(c(R.type("ichttt.mods.firstaid.fracture.Fractures"),"isSplinted",player,left));
   List<String> labels=labels(b(w,"gunshot"),((Number)R.get(w,"bullets")).intValue(),b(w,"cut"),b(w,"bitten"),b(w,"infected"),b(w,"dirty"),b(w,"bandaged"),b(w,"bandaged")&&n(R.get(w,"healingLeft"))>0,bleed,broken,splinted,R.get(part,"activeHealer")!=null,hp,m);
   List<String> all=new ArrayList<>(labels);if(((Number)R.get(w,"bruiseTicks44")).intValue()>0)all.add("bruise");if(b(w,"inflamed44")&&!all.contains("irritation"))all.add("irritation");parts.add(new Part(id,part,w,hp,m,bleed,broken,splinted,List.copyOf(all)));total+=Math.max(0,hp);max+=m;
  }return new Snapshot(player,model,List.copyOf(parts),total,max,((Number)c(model,"getPainLevel")).intValue());
 }
}
