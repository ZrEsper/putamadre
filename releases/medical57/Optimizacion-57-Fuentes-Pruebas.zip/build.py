from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');import argparse
p=argparse.ArgumentParser();p.add_argument('--gore');p.add_argument('--rag');args=p.parse_args();g=Path(args.gore or (r/'gore.path').read_text());rag=args.rag or (r/'rag.path').read_text();e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis'])
for p in ['build/classes','build/tools','output']:(r/p).mkdir(parents=True,exist_ok=True)
subprocess.run(e+['-cp',str(g),'-d',str(r/'build/classes')]+list(map(str,(r/'src').rglob('*.java'))),check=True);subprocess.run(e+['-cp',asm,'-d',str(r/'build/tools'),str(r/'Patch57.java')],check=True);subprocess.run(['java','-cp',str(r/'build/tools')+':'+asm,'Patch57',str(g),str(r/'build/classes'),str(r/'output/gore.jar'),rag,str(r/'output/rag.jar')],check=True)
