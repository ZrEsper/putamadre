package dev.zomboid.gore;
import java.lang.reflect.Field;import java.util.concurrent.ConcurrentHashMap;
/** Cache class metadata, never mutable field values or model instances. */
public final class Fields57{
 static final class Access{final Field field;Access(Field f){field=f;}}
 static final Access MISSING=new Access(null);
 static final ClassValue<ConcurrentHashMap<String,Access>> CACHE=new ClassValue<>(){protected ConcurrentHashMap<String,Access> computeValue(Class<?>c){return new ConcurrentHashMap<>();}};
 static Access resolve(Class<?>c,String name){for(Class<?>p=c;p!=null;p=p.getSuperclass())try{Field f=p.getDeclaredField(name);return f.trySetAccessible()?new Access(f):MISSING;}catch(NoSuchFieldException absent){}catch(RuntimeException denied){return MISSING;}return MISSING;}
 public static Object optional(Object target,String name){if(target==null)return null;Class<?>c=target instanceof Class<?>t?t:target.getClass();Access a=CACHE.get(c).computeIfAbsent(name,n->resolve(c,n));if(a.field==null)return null;try{return a.field.get(target instanceof Class<?>?null:target);}catch(IllegalAccessException|RuntimeException denied){return null;}}
}
