package dev.zomboid.gore;
import java.util.*;import java.util.function.Function;
/** No temporary lists/boxed integers on cache hits. Keys retain only relevant cuts. */
public final class MeshCache24 extends AbstractMap<Integer,List<Mesh12.Quad>>{
 static final class Key{final int shape;final int[]cuts;final int hash;Key(int s,int[]c){shape=s;cuts=c;hash=hash(s,c);}public int hashCode(){return hash;}public boolean equals(Object o){return o instanceof Key k&&shape==k.shape&&Arrays.equals(cuts,k.cuts);}}
 static int hash(int shape,int[]cuts){int region=shape/4096,h=1;for(int i=0;i+1<cuts.length;i+=2)if(relevant(cuts[i],region)){h=31*h+cuts[i];h=31*h+cuts[i+1];}return 31*shape+h;}
 static boolean relevant(int cut,int r){int p=cut&7;return p==r||r==6&&p==7;}
 static final class Probe{int shape;int[]cuts;public int hashCode(){return hash(shape,cuts);}public boolean equals(Object o){if(!(o instanceof Key k)||shape!=k.shape)return false;int p=0,r=shape/4096;for(int i=0;i+1<cuts.length;i+=2)if(relevant(cuts[i],r)){if(p+1>=k.cuts.length||cuts[i]!=k.cuts[p++]||cuts[i+1]!=k.cuts[p++])return false;}return p==k.cuts.length;}}
 final LinkedHashMap<Key,List<Mesh12.Quad>>states=new LinkedHashMap<>(32,.75f,true){protected boolean removeEldestEntry(Map.Entry<Key,List<Mesh12.Quad>>e){return size()>24;}};final Probe probe=new Probe();
 public List<Mesh12.Quad>computeIfAbsent(Integer shape,Function<? super Integer,? extends List<Mesh12.Quad>>factory){int[]cuts=Cuts24.CURRENT.get();probe.shape=shape;probe.cuts=cuts;List<Mesh12.Quad>mesh;try{mesh=states.get(probe);}finally{probe.cuts=null;}if(mesh!=null)return mesh;mesh=factory.apply(shape);if(mesh==null)return null;int count=0,r=shape/4096;for(int i=0;i+1<cuts.length;i+=2)if(relevant(cuts[i],r))count+=2;int[]key=new int[count];int p=0;for(int i=0;i+1<cuts.length;i+=2)if(relevant(cuts[i],r)){key[p++]=cuts[i];key[p++]=cuts[i+1];}states.put(new Key(shape,key),mesh);return mesh;}
 public Set<Map.Entry<Integer,List<Mesh12.Quad>>>entrySet(){return Set.of();}public void clear(){states.clear();}
}
