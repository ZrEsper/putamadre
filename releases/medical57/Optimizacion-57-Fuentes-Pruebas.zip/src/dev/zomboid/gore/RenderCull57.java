package dev.zomboid.gore;
import java.util.List;
/** Conservative view-frustum culling; never changes physics, lifetime or inventory. */
public final class RenderCull57{
 static final ThreadLocal<Object> FRUSTUM=new ThreadLocal<>();
 public static void begin(Object event){FRUSTUM.remove();Object expected=R.get(R.type("net.neoforged.neoforge.client.event.RenderLevelStageEvent$Stage"),"AFTER_ENTITIES");if(R.call(event,"getStage") == expected)FRUSTUM.set(R.call(event,"getFrustum"));}
 public static void end(){FRUSTUM.remove();}
 public static boolean add(List<Object>list,Object drawable){Object frustum=FRUSTUM.get();if(frustum==null){return list.add(drawable);}Object snapshot=Fields57.optional(drawable,"snapshot");if(snapshot==null)return list.add(drawable);Object[]positions=(Object[])Fields57.optional(snapshot,"positions"),ext=(Object[])Fields57.optional(snapshot,"halfExtents");if(positions==null)return list.add(drawable);double[]b=bounds(positions,ext);if(b==null)return list.add(drawable);Object aabb=R.make("net.minecraft.world.phys.AABB",b[0],b[1],b[2],b[3],b[4],b[5]);return R.yes(R.call(frustum,"isVisible",aabb))&&list.add(drawable);}
 static double[]bounds(Object[]positions,Object[]ext){double[]b={Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY};boolean found=false;for(int i=0;i<positions.length;i++){Object p=positions[i];if(p==null)continue;double x=R.num(R.get(p,"x")),y=R.num(R.get(p,"y")),z=R.num(R.get(p,"z"));if(!Double.isFinite(x+y+z))return null;double radius=1;if(ext!=null&&i<ext.length&&ext[i]!=null){double hx=R.num(R.get(ext[i],"x")),hy=R.num(R.get(ext[i],"y")),hz=R.num(R.get(ext[i],"z"));radius=Math.max(1,Math.sqrt(hx*hx+hy*hy+hz*hz)+.5);}b[0]=Math.min(b[0],x-radius);b[1]=Math.min(b[1],y-radius);b[2]=Math.min(b[2],z-radius);b[3]=Math.max(b[3],x+radius);b[4]=Math.max(b[4],y+radius);b[5]=Math.max(b[5],z+radius);found=true;}return found?b:null;}
}
