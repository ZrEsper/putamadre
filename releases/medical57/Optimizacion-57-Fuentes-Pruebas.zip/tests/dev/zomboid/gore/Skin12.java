package dev.zomboid.gore;public class Skin12{static ThreadLocal<Context>CURRENT=new ThreadLocal<>();static class Context{int state;}}
