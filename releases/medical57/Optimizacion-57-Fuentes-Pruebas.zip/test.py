from pathlib import Path
import subprocess,json
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];g=r/'output/gore.jar';out=r/'build/tests';out.mkdir(exist_ok=True);results=[]
subprocess.run(e+['-cp',str(g),'-d',str(out)]+list(map(str,(r/'tests').rglob('*.java'))),check=True)
for jar,main,label in [(Path((r/'gore.path').read_text()),'CacheTest57','before'),(g,'CacheTest57','after'),(g,'GeometryTest57','geometry')]:
 p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(jar),'dev.zomboid.gore.'+main],capture_output=True,text=True);print(label,p.stdout,p.stderr);p.check_returncode();results.append({'label':label,'result':p.stdout.strip()})
(r/'test-results.json').write_text(json.dumps({'minecraft_runtime_tested':False,'results':results,'limits':'Geometry and allocation microbenchmarks with production helpers; simulated frustum and metadata objects. No FPS, GPU or full modpack run.'},indent=2)+'\n')
