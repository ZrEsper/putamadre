from pathlib import Path
import zipfile,json,hashlib,tomllib
r=Path(__file__).parent;out=r/'release';out.mkdir(exist_ok=True);entries=[]
for kind,name in [('gore','zomboid-zombie-gore-1.0.20-neoforge-1.21.1-render-cache.39.jar'),('rag','ragdollified-1.21.1-1.1.5-view-culling.32.jar')]:
 with zipfile.ZipFile(r/'output'/f'{kind}.jar')as z:data={n:z.read(n)for n in z.namelist()}
 meta=data['META-INF/neoforge.mods.toml'].decode();meta=meta.replace('1.0.20.51','1.0.20.57').replace('1.1.5-gore20-medical51','1.1.5-gore20-perf57')
 if kind=='gore':
  import re
  meta=re.sub(r'displayName="Zomboid Zombie Injuries - Gore .*?"','displayName="Zomboid Zombie Injuries - Gore .39"',meta)
 data['META-INF/neoforge.mods.toml']=meta.encode();parsed=tomllib.loads(meta)
 assert not any(n.startswith(('net/minecraft/','org/lwjgl/','tests/'))for n in data)
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in sorted(data.items()):z.writestr(n,b)
 with zipfile.ZipFile(out/name)as z:assert z.testzip()is None
 source=Path((r/(kind+'.path')).read_text());entries.append({'file':name,'mod_id':parsed['mods'][0]['modId'],'version':parsed['mods'][0]['version'],'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest(),'input_file':source.name,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'reference_repository':'baconwithd/Steph','reference_commit':'811f1efdf561bccc7385268d110bfedbb506083e','minecraft':'1.21.1','loader':'NeoForge','minecraft_runtime_tested':False,'artifacts':entries},indent=2)+'\n')
results=json.loads((r/'test-results.json').read_text());results['native_contracts']='PASS: only targeted classes changed, two culling routes, cleanup at every native return';results['gore_bytecode_verified_classes']=185;results['rag_renderer_bytecode_verified']=True;(out/'test-results.json').write_text(json.dumps(results,indent=2)+'\n');(out/'LEEME.md').write_bytes((r/'LEEME.md').read_bytes());(out/'SHA256SUMS.txt').write_text(''.join(e['sha256']+'  mods/'+e['file']+'\n'for e in entries))
with zipfile.ZipFile(out/'Optimizacion-57-Gore-Cuerpos.zip','w',zipfile.ZIP_DEFLATED)as z:
 for e in entries:z.write(out/e['file'],'mods/'+e['file'])
 for n in ['LEEME.md','manifest.json','test-results.json','SHA256SUMS.txt']:z.write(out/n,n)
with zipfile.ZipFile(out/'Optimizacion-57-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','tests']:
  for p in(r/folder).rglob('*.java'):z.write(p,p.relative_to(r))
 for n in ['Patch57.java','Contracts57.java','build.py','test.py','package.py','LEEME.md']:z.write(r/n,n)
 for n in ['manifest.json','test-results.json']:z.write(out/n,n)
print('ARTIFACTS',[(p.name,p.stat().st_size)for p in out.glob('*.zip')])
