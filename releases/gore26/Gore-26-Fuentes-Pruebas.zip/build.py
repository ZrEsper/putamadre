from pathlib import Path
import subprocess,zipfile,json,hashlib
r=Path(__file__).resolve().parent
old=r.parent/'procedural25/output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-head-blood-destruction.25.jar'
g=r/'output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-corpse-bullet-crash-fix.26.jar'
c=r/'build/classes';c.mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(old),'-d',str(c),*map(str,(r/'src').rglob('*.java'))],check=True)
with zipfile.ZipFile(old)as z:e={n:z.read(n)for n in z.namelist()}
changes=[]
for p in c.rglob('*.class'):name=p.relative_to(c).as_posix();e[name]=p.read_bytes();changes.append(name)
assert set(changes)=={'dev/zomboid/gore/Bullet13.class','dev/zomboid/gore/Foley24.class','dev/zomboid/gore/Foley24$Motion.class'},changes
e['META-INF/neoforge.mods.toml']=e['META-INF/neoforge.mods.toml'].replace(b'Gore .25',b'Gore .26')
e['META-INF/zomboid-crash26.json']=json.dumps({'patch':26,'fix':'Vec3.scale(double) reflection argument in corpse bullet impact','protocol_unchanged':'17-procedural25','minecraft_runtime_tested':False}).encode()
with zipfile.ZipFile(g,'w',zipfile.ZIP_DEFLATED)as z:
 for n,b in sorted(e.items()):z.writestr(n,b)
print(g)
