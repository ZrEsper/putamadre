from pathlib import Path
r=Path(__file__).resolve().parent/'fixtures'
files={
'net/minecraft/world/phys/Vec3.java':'''package net.minecraft.world.phys; public class Vec3 {public final double x,y,z;public Vec3(double x,double y,double z){this.x=x;this.y=y;this.z=z;}public Vec3 add(double x,double y,double z){return new Vec3(this.x+x,this.y+y,this.z+z);}}''',
'net/minecraft/client/Minecraft.java':'''package net.minecraft.client; public class Minecraft {public static final Minecraft INSTANCE=new Minecraft();public static Minecraft getInstance(){return INSTANCE;} public Object level,player;public boolean isPaused(){return false;}}''',
'com/raiiiden/ragdollified/RagdollPart.java':'''package com.raiiiden.ragdollified;public enum RagdollPart{TORSO,LEFT_LEG,RIGHT_LEG}''',
'dev/zomboid/gore/FoleyChecks26.java':'''package dev.zomboid.gore;
public class FoleyChecks26 {
 public static class FloatPosition {public float x=1,y=2,z=3;/* Physics position deliberately has no Vec3.add(double,double,double). */}
 public static class Transform {public FloatPosition position=new FloatPosition();}
 public static class Rag {public Transform t=new Transform();public FloatPosition getSmoothedTorsoPos(){return t.position;}public Transform getSmoothedTransform(com.raiiiden.ragdollified.RagdollPart p){return t;}}
 public static class World {public long tick;public int clips;public long getGameTime(){return tick;}public BulletChecks26.Hit clip(net.minecraft.world.level.ClipContext ctx){clips++;return new BulletChecks26.Hit();}}
 public static class Player {public double distanceToSqr(double x,double y,double z){return 1;}}
 public static void main(String[] args){World world=new World();var mc=net.minecraft.client.Minecraft.getInstance();mc.level=world;mc.player=new Player();Rag rag=new Rag();Foley24.ragdoll(rag);world.tick=2;Foley24.ragdoll(rag);if(Foley24.warned||world.clips!=3||rag.t.position.y!=2)throw new AssertionError("contact probe failed or mutated physics: "+world.clips);System.out.println("ACTUAL_FOLEY24_RAGDOLL_FLOAT_PHYSICS_TO_VEC3_PROBE=PASS");}
}'''
}
for n,s in files.items():p=r/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s+'\n')
