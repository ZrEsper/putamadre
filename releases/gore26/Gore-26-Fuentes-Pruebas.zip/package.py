from pathlib import Path
import json,zipfile,hashlib
r=Path(__file__).resolve().parent;o=r/'output';g=next(o.glob('*.jar'))
(o/'LEEME.txt').write_text('''GORE .26 - corrección del crash al disparar a cadáveres

Cierra Minecraft y el servidor. Quita el JAR de zomboid-zombie-gore .25 y coloca el .26 de este ZIP. No dejes ambas versiones. Instala el mismo JAR en los clientes y servidor.
Conserva ragdollified stable-anatomy.21, Splatter y los paquetes de texturas actuales. El protocolo no cambia.

Corregido: Bullet13.tick enviaba Float a Vec3.scale(double), provocando IllegalStateException: scale / NoSuchMethodException: scale y Ticking entity.
Corregido también: Foley24 intentaba usar add(double,double,double) sobre una posición física Vector3f. Ahora crea una Vec3 separada para comprobar el suelo sin modificar la posición física. Esto recupera la comprobación de contactos que usa el sonido de arrastre/impacto.

Pruebas: se reprodujeron ambos fallos con .25 y se ejecutaron las mismas rutas con .26 usando interfaces simuladas estrictas. Pasan pruebas de impactos, impulso, perforación, contacto del cadáver y regresiones existentes de geometría, cabeza, torso, sangre y fragmentos.
No se ha ejecutado Minecraft ni comprobado visualmente en el juego.

Pendiente independiente observado: latest.log registra 986 mensajes OpenGL de formatos de profundidad incompatibles. Este parche corrige el crash del servidor y el fallo de sonidos indicado; no corrige ese problema gráfico ni los avisos de recursos de otros mods.
''',encoding='utf-8')
manifest={'patch':26,'file':g.name,'sha256':hashlib.sha256(g.read_bytes()).hexdigest(),'replaces':'Gore .25','requires_existing_ragdoll':'stable-anatomy.21','protocol':'17-procedural25','minecraft_runtime_tested':False}
(o/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(o/'Gore-26-Correccion-Crash-Cadaveres.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in [g,o/'LEEME.txt',o/'manifest.json',o/'test-results.json']:z.write(p,p.name)
with zipfile.ZipFile(o/'Gore-26-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in r.rglob('*'):
  if p.is_file()and not any(x in p.relative_to(r).parts for x in ['output','build'])and p.suffix in ['.py','.java']:z.write(p,p.relative_to(r))
files=[]
for p in o.iterdir():
 if p.is_file():b=p.read_bytes();files.append({'local':str(p),'path':'releases/gore26/'+p.name,'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
(r/'upload.json').write_text(json.dumps(files,indent=2))
s=(r.parent/'procedural25/publish.py').read_text().replace('procedural25','procedural26').replace('gore25','gore26').replace('0c1c08cb4d5251b8c30deb50ee118c7894710114','56d4e99e51dbe40079f2c6967343dc6933537b51').replace('Fix EMF hidden-head ownership and late ragdoll animation; add complete tissue destruction and bounded arterial gore','Fix corpse bullet Vec3 reflection crash and ragdoll foley contact probe; reproduce and test both failures')
(r/'publish.py').write_text(s)
