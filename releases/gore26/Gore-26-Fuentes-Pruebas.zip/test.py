from pathlib import Path
import subprocess,json,zipfile,hashlib
r=Path(__file__).resolve().parent;old=r.parent/'procedural25';g=next((r/'output').glob('*.jar'));baseline=next((old/'output').glob('zomboid*.jar'));rag=next((old/'output').glob('ragdoll*.jar'));results=[]
def run(args,expected=0):
 p=subprocess.run(args,capture_output=True,text=True);assert p.returncode==expected,(p.stdout,p.stderr);return p.stdout+p.stderr
for main,needle in [('BulletChecks26','NoSuchMethodException: scale'),('FoleyChecks26','contact probe failed')]:
 p=subprocess.run(['java','-Xverify:all','-cp',str(r/'build/test')+':'+str(baseline),'dev.zomboid.gore.'+main],capture_output=True,text=True);assert p.returncode!=0 and needle in p.stderr,p.stderr
 results.append('BASELINE_25_'+main+'=REPRODUCED')
 results.append(run(['java','-Xverify:all','-cp',str(r/'build/test')+':'+str(g),'dev.zomboid.gore.'+main]).strip())
for main,args in [('Checks24',[str(r/'geometry.json')]),('RenderChecks25',[]),('DamageEffectsChecks25',[])]:results.append(run(['java','-Xverify:all','-cp',str(old/'build/test')+':'+str(g),'dev.zomboid.gore.'+main,*args]).strip())
exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{s}=ALL-UNNAMED' for s in ['', '.tree','.tree.analysis']]
results.append(run(['java',*exports,'-cp',str(old/'build/test'),'Inspect',str(g),str(rag)]).strip())
with zipfile.ZipFile(baseline)as a,zipfile.ZipFile(g)as b:
 assert b.testzip() is None
 changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
 assert set(changed)=={'dev/zomboid/gore/Bullet13.class','dev/zomboid/gore/Foley24.class','META-INF/neoforge.mods.toml'},changed
 assert not any(n.startswith(('net/minecraft/','com/mojang/'))for n in b.namelist())
results.append('UNCHANGED_GORE_ASSETS_GEOMETRY_PACKETS_AND_RAGDOLL_PROTOCOL=PASS')
(r/'output/test-results.json').write_text(json.dumps({'results':results,'minecraft_runtime_tested':False,'scope':'Actual shipped Bullet13.tick and Foley24.ragdoll with strict API fixtures; baseline reproductions; existing mesh and damage regressions.'},indent=2)+'\n')
print('\n'.join(results))
