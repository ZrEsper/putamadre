package dev.zomboid.gore;
import com.raiiiden.ragdollified.server.ServerRagdollSyncManager; import com.raiiiden.ragdollified.network.RagdollImpulsePacket;
public class BulletChecks26 {
 public static class Vec {public final double x,y,z;public Vec(double x,double y,double z){this.x=x;this.y=y;this.z=z;}public Vec add(Vec v){return new Vec(x+v.x,y+v.y,z+v.z);}public Vec subtract(Vec v){return new Vec(x-v.x,y-v.y,z-v.z);}public double length(){return Math.sqrt(x*x+y*y+z*z);}public Vec normalize(){return scale(1/length());}public Vec scale(double v){return new Vec(x*v,y*v,z*v);}public double distanceToSqr(Vec v){return subtract(v).length()*subtract(v).length();}}
 public static class World {public boolean isClientSide=false;public Hit clip(net.minecraft.world.level.ClipContext ctx){return new Hit();}public Object dimension(){return "test";}}
 public static class Hit {public String getType(){return "MISS";}}
 public static class Bullet {public boolean explosion=false,discarded=false;public int pierce=1;public double speed;public Vec start;public World world=new World();public Bullet(double speed){this.speed=speed;start=new Vec(-2,.95,0);}public World level(){return world;}public Vec getDeltaMovement(){return new Vec(speed,0,0);}public Vec position(){return start;}public float getDamage(Vec hit){return 20f;}public void discard(){discarded=true;}}
 public static class Packet {public int goreState12=Integer.MIN_VALUE;public int[] goreCuts24=new int[0];public int severedMask(){return 0;}}
 public static class Retained {public Packet spawnPacket=new Packet();public Object gorePose13;}
 public static class Entry {public int entityId(){return 7;}public boolean live(){return false;}public Object pose(){return null;}public Vec anchor(){return new Vec(0,0,0);}}
 static int checks;static void ok(boolean value){checks++;if(!value)throw new AssertionError("check "+checks);}
 public static void main(String[] args){Retained body=new Retained();ServerRagdollSyncManager.RETAINED.put(7,body);ServerRagdollSyncManager.entry=new Entry();
  for(double speed:new double[]{2,4,20}){Bullet b=new Bullet(speed);int before=RagdollImpulsePacket.calls;ok(Bullet13.tick(b));ok(b.discarded);ok(RagdollImpulsePacket.calls==before+1);ok(Math.abs(RagdollImpulsePacket.impulse.length()-Math.min(16,Math.max(3,speed*2)))<1e-6);ok(RagdollImpulsePacket.damage==20f);}
  Bullet piercing=new Bullet(4);piercing.pierce=2;ok(!Bullet13.tick(piercing));ok(piercing.pierce==1&&!piercing.discarded);int count=RagdollImpulsePacket.calls;ok(!Bullet13.tick(piercing));ok(RagdollImpulsePacket.calls==count);
  Bullet client=new Bullet(4);client.world.isClientSide=true;ok(!Bullet13.tick(client));Bullet slow=new Bullet(.01);ok(!Bullet13.tick(slow));Bullet miss=new Bullet(4);miss.start=new Vec(-2,8,0);ok(!Bullet13.tick(miss));ok(RagdollImpulsePacket.calls==count);
  System.out.println("ACTUAL_BULLET13_TICK_STRICT_VEC3_DOUBLE_REFLECTION_CHECKS="+checks);
 }
}
