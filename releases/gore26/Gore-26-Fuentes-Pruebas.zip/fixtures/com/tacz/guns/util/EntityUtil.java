package com.tacz.guns.util; public class EntityUtil {public static Object findEntityOnPath(Object b,Object a,Object c){return null;} }
