package com.raiiiden.ragdollified;public enum RagdollPart{TORSO,LEFT_LEG,RIGHT_LEG}
