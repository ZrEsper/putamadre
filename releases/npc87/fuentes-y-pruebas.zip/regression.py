from pathlib import Path
import subprocess,zipfile,json
r=Path(__file__).parent;j=next((r/'release').glob('*.jar'));gore=json.loads(Path('/workspace/npc82/inputs.json').read_text())['gore'];rest='/workspace/npc82/release/zombie-remains-loot-1.6.1-neoforge-1.21.1-safe-corpse-menu.28.jar:/workspace/npc83/release/ragdollified-1.21.1-1.1.5-server-owned-corpses.34-dependency-fix.jar:/workspace/medical63/gson.jar:'+gore
with (r/'regression-output.txt').open('w')as log:
 cp='/workspace/npc82/checks:/workspace/npc84/checks:/workspace/npc79/tests:'+str(j)+':/workspace/npc85/api-build:'+rest
 for cls in ['mod.cdv.tnpc.tactical.CheckNpc82','dev.zomboid.remains.expand.CheckMenu82','mod.cdv.tnpc.tactical.CheckFurniture84']:
  x=subprocess.run(['java','-Xverify:all','-Ddecor.root=/workspace/npc82/decor','-cp',cp,cls],capture_output=True,text=True,cwd=r);log.write(x.stdout+x.stderr)
  if x.returncode:raise SystemExit(x.stdout+x.stderr)
 with zipfile.ZipFile(j)as z:
  for n in z.namelist():
   if n.startswith('mod/cdv/tnpc/tactical/CalmBrain') and n.endswith('.class'):z.extract(n,r/'production')
 cp=str(r/'production')+':/workspace/npc85/checks:/workspace/npc79/tests:/workspace/npc85/api-build:'+str(j)+':'+rest
 x=subprocess.run(['java','-Xverify:all','-cp',cp,'mod.cdv.tnpc.tactical.CheckSurvival85'],capture_output=True,text=True,cwd=r);log.write(x.stdout+x.stderr)
 if x.returncode:raise SystemExit(x.stdout+x.stderr)
 cp='/workspace/npc86/checks:/workspace/npc79/tests:'+str(j)+':/workspace/npc85/api-build:'+rest
 x=subprocess.run(['java','-Xverify:all','-cp',cp,'mod.cdv.tnpc.tactical.CheckWork86'],capture_output=True,text=True,cwd=r);log.write(x.stdout+x.stderr)
 if x.returncode:raise SystemExit(x.stdout+x.stderr)
print((r/'regression-output.txt').read_text())
