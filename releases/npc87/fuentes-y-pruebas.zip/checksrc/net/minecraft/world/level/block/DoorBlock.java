package net.minecraft.world.level.block;public class DoorBlock extends mod.cdv.tnpc.tactical.BuildWorld77.Block{public DoorBlock(){super("minecraft:oak_door");}}
