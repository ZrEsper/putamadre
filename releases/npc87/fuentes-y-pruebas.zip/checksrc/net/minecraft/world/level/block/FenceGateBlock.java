package net.minecraft.world.level.block;public class FenceGateBlock{public static final Object OPEN=new Object();}
