package mod.cdv.tnpc.tactical;
/** Sleeping keeps native bed anchoring; residual movement/physics cannot drag the sleeper. */
public final class Sleep87{public static boolean freeze(Object n){if(!Survival85.sleeping(n))return false;Object zero=SocialR.make("net.minecraft.world.phys.Vec3",0d,0d,0d);Social.c(n,"setDeltaMovement",zero);for(String f:new String[]{"xxa","yya","zza"})try{SocialR.set(n,f,0f);}catch(RuntimeException ignored){}Social.c(Social.c(n,"getNavigation"),"stop");return true;}}
