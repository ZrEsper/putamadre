package net.minecraft.world.entity.ai.goal;public class OpenDoorGoal{public final Object mob;public final boolean close;public OpenDoorGoal(Object mob,boolean close){this.mob=mob;this.close=close;}}
