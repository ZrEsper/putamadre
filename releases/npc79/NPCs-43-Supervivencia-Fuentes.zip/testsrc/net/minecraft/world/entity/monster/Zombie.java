package net.minecraft.world.entity.monster;public class Zombie extends mod.cdv.tnpc.tactical.Fixtures70.Npc{}
