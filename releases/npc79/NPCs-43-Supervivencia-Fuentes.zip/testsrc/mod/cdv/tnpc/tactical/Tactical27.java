package mod.cdv.tnpc.tactical;
import java.util.*;
/** Service stub only for scheduler integration. Production service is inherited unchanged. */
public class Tactical27{static class State{long until;}static Map<Object,State>states=new WeakHashMap<>();static State state(Object n){return states.computeIfAbsent(n,k->new State());}public static void idle(Object n){} }
