package mod.cdv.tnpc.tactical;
import java.util.*;
/** Inventory maintenance must never materialize unwanted stacks as world loot. */
public final class Inventory79 {
 public static List<Object> clean(List<?> source){List<Object> out=new ArrayList<>();for(Object stack:source)if(stack!=null&&!DialogueRules72.empty(stack))out.add(stack);return out;}
 public static boolean ownDepot(Object n,Object p){Object own=Hunt78.point(n,"npc78_depot");return own!=null&&own.equals(p);}
 public static void trim(Object n,List<Object> bag){bag.removeIf(s->s==null||DialogueRules72.empty(s));}
 static boolean equipment(String id){return id.contains("flashlight")||id.contains("lantern")||id.contains("battery")||id.contains("gun")||id.contains("tacz")||id.contains("helmet")||id.contains("chestplate")||id.contains("leggings")||id.contains("boots")||id.contains("axe")||id.contains("sword")||id.contains("knife")||id.contains("defib");}
 public static boolean useful(Object stack){if(stack==null||DialogueRules72.empty(stack))return false;String id=DialogueRules72.itemId(stack);return equipment(id)||id.contains("bandage")||id.contains("plaster")||id.contains("ammo")||id.contains("potion")||id.contains("water")||id.contains("bottle")||id.contains("crafting_table")||id.contains("chest")||id.contains("log")||id.contains("planks")||id.contains("coal")||id.contains("ingot")||id.contains("ore")||id.contains("stick")||id.contains("torch")||id.contains("seed")||id.contains("wheat")||Activity78.hasCategory(stack,"comida")||Activity78.hasCategory(stack,"medicina");}
}
