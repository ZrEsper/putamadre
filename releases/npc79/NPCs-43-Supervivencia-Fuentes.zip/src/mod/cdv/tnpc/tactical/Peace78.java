package mod.cdv.tnpc.tactical;
import java.util.*;
public final class Peace78{
 static boolean alert(Object n){long now=Social.time(n);Object target=CalmBrain.state(n).target;if(target!=null&&Social.alive(target)||Social.mem(n).threats>0||now<Social.l(Social.tag(n),"npc78_alerta"))return true;try{Object states=SocialR.get(Social.t("mod.cdv.tnpc.tactical.Sense28"),"STATES");Object s=((Map<?,?>)states).get(n);return s!=null&&((Number)SocialR.get(s,"priority")).intValue()>=3&&now-((Number)SocialR.get(s,"heard")).longValue()<200;}catch(Exception e){return false;}}
 public static boolean skipScan(Object n){if(alert(n))return false;try{Map<?,?>states=(Map<?,?>)SocialR.get(Social.t("mod.cdv.tnpc.tactical.Sense28"),"STATES");Object s=states.get(n);if(s!=null)SocialR.set(s,"end",0L);}catch(Exception ignored){}return true;}
 static void hit(Object n){Social.c(Social.tag(n),"putLong","npc78_alerta",Social.time(n)+200);}
 public static void tick(Object n){try{if(Social.client(n)||!Social.alive(n)||Downed20.down(n)||alert(n)||Social.mem(n).medicalUntil>Social.time(n)||Social.mem(n).fearUntil>Social.time(n))return;SocialR.set(n,"xxa",0f);Social.c(n,"setSprinting",false);Social.c(n,"setShiftKeyDown",false);Social.c(n,"aim",false);Social.c(n,"setAggressive",false);}catch(Exception ignored){}}
}
