from pathlib import Path
import subprocess
r=Path(__file__).parent;j=next((r/'release').glob('*.jar'));g='/workspace/medical63/gson.jar';ecj=['java','-jar','/workspace/putamadre/hordes-melee-interiors-patch/build/tools/ecj.jar','-21','-proc:none','-nowarn'];subprocess.run(ecj+['-cp',str(j)+':'+g,'-d',str(r/'checks')]+[str(p)for p in (r/'checksrc').rglob('*.java')],check=True)
with (r/'test-output.txt').open('w')as out:
 for cls in ['InventoryTest56','PlacementTest56','DialogueTest56','GuardTest56','WorkTest56','CheckWork90','CheckSmart90']:
  x=subprocess.run(['java','-Xverify:all','-Xmx256m','-cp',str(r/'checks')+':'+str(j)+':'+g,'mod.cdv.tnpc.tactical.'+cls],capture_output=True,text=True,cwd=r);print(x.stdout+x.stderr);out.write(x.stdout+x.stderr)
  if x.returncode:raise SystemExit(x.returncode)
