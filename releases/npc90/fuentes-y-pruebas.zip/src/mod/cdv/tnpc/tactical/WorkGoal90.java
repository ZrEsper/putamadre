package mod.cdv.tnpc.tactical;
import java.util.EnumSet;import net.minecraft.world.entity.ai.goal.Goal;
/** Reserve the native MOVE/LOOK controls while external work is actually being performed. */
public final class WorkGoal90 extends Goal{
 final Object npc;public WorkGoal90(Object n){npc=n;setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
 public boolean canUse(){return CalmBrain.state(npc).target==null&&Social.mem(npc).threats==0&&!Survival85.sleeping(npc)&&!Survival85.blocked(npc,null)&&!Social.yes(Social.c(npc,"isInWater"))&&(Job90.lease(npc)||Social.mem(npc).occupied&&CalmBrain.state(npc).corpse==null);}
 public boolean canContinueToUse(){return canUse();}public boolean requiresUpdateEveryTick(){return true;}public void tick(){Placement90.tick(npc);}
}
