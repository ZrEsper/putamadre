package mod.cdv.tnpc.tactical;
import java.util.*;
public final class Placement90{
 record Pose(Object pos,long until){}static final Map<Object,Pose>POSE=new WeakHashMap<>();
 public static void placed(Object n,Object pos){Social.c(Work86.class,"placedNative56",n,pos);POSE.put(n,new Pose(pos,Social.time(n)+10));Job90.claim(n);}
 public static void civil(Object n,Object p,String kind){Social.c(CivilFeedback87.class,"placedNative56",n,p,kind);POSE.put(n,new Pose(p,Social.time(n)+10));Job90.claim(n);}
 public static void tick(Object n){Pose p=POSE.get(n);if(p==null)return;if(Social.time(n)>=p.until||CalmBrain.state(n).target!=null||Survival85.sleeping(n)){POSE.remove(n);return;}Base48.look(n,p.pos);}
 public static boolean result(boolean placed,Object n,Object pos){if(placed)placed(n,pos);return placed;}
}
