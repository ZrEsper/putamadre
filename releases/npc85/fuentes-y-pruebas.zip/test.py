from pathlib import Path
import subprocess,zipfile
r=Path(__file__).parent;j=next((r/'release').glob('*.jar'));gson='/workspace/medical63/gson.jar';ecj=['java','-jar','/workspace/putamadre/hordes-melee-interiors-patch/build/tools/ecj.jar','-21','-nowarn','-proc:none'];cp=str(j)+':/workspace/npc79/tests:'+str(r/'api-build')+':'+gson
subprocess.run(ecj+['-cp',cp,'-d',str(r/'checks')]+[str(p)for p in (r/'checksrc').rglob('*.java')],check=True)
with zipfile.ZipFile(j)as z:
 for n in z.namelist():
  if n.startswith('mod/cdv/tnpc/tactical/CalmBrain') and n.endswith('.class'):
   z.extract(n,r/'checks')
cp=str(r/'checks')+':/workspace/npc79/tests:'+str(r/'api-build')+':'+str(j)+':'+gson
result=subprocess.run(['java','-Xverify:all','-cp',cp,'mod.cdv.tnpc.tactical.CheckSurvival85'],capture_output=True,text=True,cwd=r);(r/'test-output.txt').write_text(result.stdout+result.stderr);print(result.stdout+result.stderr);raise SystemExit(result.returncode)
