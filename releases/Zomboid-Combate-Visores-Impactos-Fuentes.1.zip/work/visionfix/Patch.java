import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
public class Patch implements Opcodes {
 static ClassNode read(byte[] b){ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);return c;}
 static void write(ClassNode c,Path dir)throws Exception{ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=dir.resolve(c.name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());}
 static ClassNode from(String jar,String name)throws Exception{try(ZipFile z=new ZipFile(jar)){return read(z.getInputStream(z.getEntry(name+".class")).readAllBytes());}}
 static MethodNode method(ClassNode c,String n){return c.methods.stream().filter(m->m.name.equals(n)).findFirst().orElseThrow();}
 static void empty(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new InsnNode(RETURN));m.maxStack=0;}
 public static void main(String[] args)throws Exception{
  Path out=Path.of("work/visionfix/patched");
  ClassNode fa=from(args[0],"ichttt/mods/firstaid/client/PainVisualEffectsController");
  // Never replace another mod's native post effect. Red injury vignette and medical simulation remain active.
  MethodNode update=method(fa,"updateEffect");InsnList pre=new InsnList();LabelNode run=new LabelNode();
  pre.add(new VarInsnNode(ALOAD,1));pre.add(new MethodInsnNode(INVOKESTATIC,fa.name,"getPostEffect","(Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/PostChain;",false));
  pre.add(new JumpInsnNode(IFNULL,run));
  pre.add(new VarInsnNode(ALOAD,1));pre.add(new MethodInsnNode(INVOKESTATIC,fa.name,"getPostEffect","(Lnet/minecraft/client/Minecraft;)Lnet/minecraft/client/renderer/PostChain;",false));
  pre.add(new MethodInsnNode(INVOKESTATIC,fa.name,"isOurComposite","(Lnet/minecraft/client/renderer/PostChain;)Z",false));pre.add(new JumpInsnNode(IFNE,run));
  pre.add(new VarInsnNode(ALOAD,0));pre.add(new InsnNode(ICONST_0));pre.add(new FieldInsnNode(PUTFIELD,fa.name,"compositeActive","Z"));
  pre.add(new VarInsnNode(ALOAD,0));pre.add(new InsnNode(ICONST_M1));pre.add(new FieldInsnNode(PUTFIELD,fa.name,"activeSatTier","I"));pre.add(new InsnNode(RETURN));
  pre.add(run);pre.add(new FrameNode(F_SAME,0,null,0,null));update.instructions.insert(pre);write(fa,out);
  ClassNode fp=from(args[1],"com/raiiiden/warborn/mixin/client/ShaderProtectionMixin");
  // A postchain must be closable for world unload, reload and resize. No stack-trace inspection per shutdown.
  empty(method(fp,"protectWarbornShader"));
  MethodNode check=method(fp,"protectWarbornShaderCheckEntity");
  for(AbstractInsnNode n:check.instructions.toArray())if(n instanceof MethodInsnNode m&&m.name.equals("onExternalShutdownAttempt")){check.instructions.set(n,new InsnNode(POP));}
  write(fp,out);
  for(String[] spec:new String[][]{{args[0],"dev/zomboid/firstaid/R","dev/zomboid/firstaid/FastFields"},{args[1],"com/raiiiden/warborn/common/util/NvgReflection","com/raiiiden/warborn/common/util/FastFields"}}){
   ClassNode c=from(spec[0],spec[1]);
   for(String name:new String[]{"get","set","type"}){
    MethodNode m=method(c,name);empty(m);m.instructions.clear();
    int count=name.equals("set")?3:name.equals("get")?2:1;
    for(int i=0;i<count;i++)m.instructions.add(new VarInsnNode(ALOAD,i));
    m.instructions.add(new MethodInsnNode(INVOKESTATIC,spec[2],name,m.desc,false));m.instructions.add(new InsnNode(name.equals("set")?RETURN:ARETURN));
   }write(c,out);
  }
  // Keep the exact server damage broadcaster; replace only client reaction implementation.
  ClassNode gore=read(Files.readAllBytes(Path.of("work/action19/classes/dev/zomboid/gore/MeleeReaction.class")));
  gore.methods.removeIf(m->m.name.equals("damage"));
  gore.methods.add(method(from(args[2],gore.name),"damage"));write(gore,Path.of("work/action19/classes"));
 }
}
