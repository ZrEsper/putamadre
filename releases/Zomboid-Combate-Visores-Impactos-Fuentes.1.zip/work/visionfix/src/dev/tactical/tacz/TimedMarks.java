/*
 * Decompiled with CFR 0.152.
 */
package dev.tactical.tacz;

import dev.tactical.tacz.Reflect;
import dev.tactical.tacz.ShotAlignment;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

public final class TimedMarks {
    public static final int LIFE = 1700;
    static long clock;
    static final Map<Object, Long> born;

    static {
        born = new WeakHashMap<Object, Long>();
    }

    public static void stamp(Object object) {
        born.put(object, clock);
    }

    public static void configure(Object object) throws Exception {
        ShotAlignment.set(object, "lifetime", 1700);
        ShotAlignment.set(object, "alpha", Float.valueOf(1.0f));
    }

    public static void tick() throws Exception {
        ++clock;
        Map map = ImpactMarks.marks;
        if (map.isEmpty()) {
            born.clear();
            return;
        }
        Iterator iterator = map.values().iterator();
        while (iterator.hasNext()) {
            Object v = iterator.next();
            Long l = born.get(v);
            if (l == null) {
                born.put(v, clock);
                continue;
            }
            if (clock - l < 1700L) continue;
            Reflect.call(((ImpactMarks.Mark)v).particle, "remove", new Object[0]);
            iterator.remove();
            born.remove(v);
        }
    }
}

