/*
 * Decompiled with CFR 0.152.
 */
package dev.tactical.tacz;

import dev.tactical.tacz.ImpactMarks;
import dev.tactical.tacz.Reflect;
import dev.tactical.tacz.ShotAlignment;
import dev.tactical.tacz.TimedMarks;

public final class OnceEffects {
    public static void configure(Object object) throws Exception {
        TimedMarks.configure(object);
        if (!ImpactMarks.replay) {
            return;
        }
        long l = 5L;
        for (ImpactMarks.Mark mark : ImpactMarks.marks.values()) {
            if (Reflect.field(mark, "particle") != object) continue;
            Long l2 = TimedMarks.born.get(mark);
            if (l2 == null) break;
            l = Math.max(5L, TimedMarks.clock - l2);
            break;
        }
        ShotAlignment.set(object, "age", (int)Math.min(1700L, l));
    }
}

