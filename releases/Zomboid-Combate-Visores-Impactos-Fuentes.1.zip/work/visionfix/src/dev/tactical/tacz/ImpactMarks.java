/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dev.zomboid.tacz.Visual17
 */
package dev.tactical.tacz;

import dev.tactical.tacz.OnceEffects;
import dev.tactical.tacz.Reflect;
import dev.tactical.tacz.ShotAlignment;
import dev.tactical.tacz.ShotTrails;
import dev.tactical.tacz.TimedMarks;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public final class ImpactMarks {
    static final int LIMIT = 200;
    static Object world;
    static boolean replay;
    static int ticks;
    static final Map<Key, Mark> marks;

    public static void remember(Object object, Object object2, double d, double d2, double d3, Object object3, Object object4, String string, String string2, String string3) {
        try {
            if (replay) {
                return;
            }
            if (world != object2) {
                marks.clear();
                world = object2;
            }
            Mark mark = new Mark();
            mark.particle = object;
            mark.level = object2;
            mark.x = d;
            mark.y = d2;
            mark.z = d3;
            mark.face = object3;
            mark.pos = object4;
            mark.ammo = string;
            mark.gun = string2;
            mark.display = string3;
            mark.originalState = Boolean.TRUE.equals(Reflect.call(object2, "hasChunkAt", object4)) ? Reflect.call(object2, "getBlockState", object4) : null;
            ImpactMarks.configure(object);
            Key key = new Key(Double.doubleToLongBits(d), Double.doubleToLongBits(d2), Double.doubleToLongBits(d3), String.valueOf(object3));
            Mark mark2 = marks.remove(key);
            marks.put(key,mark);
            TimedMarks.stamp(mark);
            if (mark2 != null) {
                Reflect.call(mark2.particle, "remove", new Object[0]);
            }
            while (marks.size() > 200) {
                Iterator<Mark> iterator = marks.values().iterator();
                Reflect.call(iterator.next().particle, "remove", new Object[0]);
                iterator.remove();
            }
        }
        catch (Exception exception) {
            Reflect.warn("persistent impact capture", exception);
        }
    }

    static void configure(Object object) throws Exception {
        OnceEffects.configure(object);
    }

    public static void keepUnloaded(Object object, Object object2) {
        if (ImpactMarks.unloaded(object)) {
            try {
                Reflect.call(object2, "setReturnValue", false);
            }
            catch (Exception exception) {
                Reflect.warn("impact chunk guard", exception);
            }
        }
    }

    public static void translate(Object object, double d, double d2, double d3) {
        try {
            Reflect.call(object, "translate", d, 0.0, d3);
        }
        catch (Exception exception) {
            Reflect.warn("world tracer pose", exception);
        }
    }

    public static boolean unloaded(Object object) {
        try {
            return !Boolean.TRUE.equals(Reflect.call(Reflect.field(object, "level"), "hasChunkAt", Reflect.field(object, "pos")));
        }
        catch (Exception exception) {
            return false;
        }
    }

    public static float size(Object object) {
        return ((Number)FastFields.get(object,"quadSize")).floatValue();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void tick() {
        try {
            TimedMarks.tick();
            ShotTrails.cleanup();
            Object object = Reflect.call(Reflect.type("net.minecraft.client.Minecraft"), "getInstance", new Object[0]);
            Object object2 = Reflect.field(object, "level");
            if (object2 == null || object2 != world) {
                marks.clear();
                world = object2;
                return;
            }
            if (++ticks % 20 != 0) {
                return;
            }
            Object object3 = Reflect.field(object, "player");
            if (object3 == null) {
                return;
            }
            double d = ShotAlignment.n(Reflect.call(object3, "getX", new Object[0]));
            double d2 = ShotAlignment.n(Reflect.call(object3, "getEyeY", new Object[0]));
            double d3 = ShotAlignment.n(Reflect.call(object3, "getZ", new Object[0]));
            int n = 0;
            Iterator<Mark> iterator = marks.values().iterator();
            while (iterator.hasNext()) {
                double d4;
                Mark mark = iterator.next();
                if (!Boolean.TRUE.equals(Reflect.call(object2, "hasChunkAt", mark.pos))) continue;
                Object object4 = Reflect.call(object2, "getBlockState", mark.pos);
                if (mark.originalState == null) {
                    mark.originalState = object4;
                }
                if (!Objects.equals(object4, mark.originalState)) {
                    Reflect.call(mark.particle, "remove", new Object[0]);
                    iterator.remove();
                    continue;
                }
                if (Boolean.TRUE.equals(Reflect.call(mark.particle, "isAlive", new Object[0])) || (d4 = (mark.x - d) * (mark.x - d) + (mark.y - d2) * (mark.y - d2) + (mark.z - d3) * (mark.z - d3)) > 65536.0 || n >= 64) continue;
                replay = true;
                try {
                    mark.particle = ShotAlignment.construct("com.tacz.guns.client.particle.BulletHoleParticle", object2, mark.x, mark.y, mark.z, mark.face, mark.pos, mark.ammo, mark.gun, mark.display);
                    ImpactMarks.configure(mark.particle);
                    Reflect.call(Reflect.field(object, "particleEngine"), "add", mark.particle);
                    ++n;
                }
                finally {
                    replay = false;
                }
            }
        }
        catch (Exception exception) {
            replay = false;
            Reflect.warn("persistent impact restore", exception);
        }
    }

    public static Object tracking(Object object, int n) {
        try {
            return Reflect.call(object, "clientTrackingRange", 32);
        }
        catch (Exception exception) {
            Reflect.warn("bullet tracking range", exception);
            return object;
        }
    }

    public static void sprite(Object object) {
        try {
            Object object2 = Reflect.call(Reflect.type("net.minecraft.client.Minecraft"), "getInstance", new Object[0]);
            Object object3 = Reflect.field(Reflect.type("net.minecraft.world.inventory.InventoryMenu"), "BLOCK_ATLAS");
            Object object4 = Reflect.call(Reflect.type("net.minecraft.resources.ResourceLocation"), "fromNamespaceAndPath", "tacz_tactical", "particle/bullet_holes");
            Object object5 = Reflect.call(Reflect.call(object2, "getTextureAtlas", object3), "apply", object4);
            Reflect.call(object, "setReturnValue", object5);
        }
        catch (Exception exception) {
            Reflect.warn("bullet hole sprite", exception);
        }
    }

    public static int send(Object object, Object object2, double d, double d2, double d3, int n, double d4, double d5, double d6, double d7) {
        try {
            if (object2.getClass().getName().equals("com.tacz.guns.particles.BulletHoleOption")) {
                int n2 = 0;
                for (Object t : (Iterable)Reflect.call(object, "players", new Object[0])) {
                    double d8;
                    double d9;
                    double d10 = ShotAlignment.n(Reflect.call(t, "getX", new Object[0])) - d;
                    if (d10 * d10 + (d9 = ShotAlignment.n(Reflect.call(t, "getEyeY", new Object[0])) - d2) * d9 + (d8 = ShotAlignment.n(Reflect.call(t, "getZ", new Object[0])) - d3) * d8 > 262144.0) continue;
                    if (!Boolean.TRUE.equals(Reflect.call(object, "sendParticles", t, object2, true, d, d2, d3, n, d4, d5, d6, d7))) continue;
                    ++n2;
                }
                return n2;
            }
        }
        catch (Exception exception) {
            Reflect.warn("long-range impact notification", exception);
        }
        try {
            return ((Number)Reflect.call(object, "sendParticles", object2, d, d2, d3, n, d4, d5, d6, d7)).intValue();
        }
        catch (Exception exception) {
            Reflect.warn("native impact notification", exception);
            return 0;
        }
    }

    static {
        marks = new LinkedHashMap<Key, Mark>();
    }

    static final class Mark {
        Object particle;
        Object level;
        Object face;
        Object pos;
        double x;
        double y;
        double z;
        String ammo;
        String gun;
        String display;
        Object originalState;

        Mark() {
            TimedMarks.stamp(this);
        }
    }

    record Key(long x, long y, long z, String face) {
    }
}

