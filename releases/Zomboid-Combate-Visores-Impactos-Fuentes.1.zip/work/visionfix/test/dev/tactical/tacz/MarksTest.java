package dev.tactical.tacz;
public class MarksTest{
 public static class World{public boolean hasChunkAt(Object p){return true;}public Object getBlockState(Object p){return "stone";}}
 public static class Particle{public int lifetime,age;public float alpha,quadSize=.09f;public boolean removed;public void remove(){removed=true;}public boolean isAlive(){return !removed;}}
 public static void main(String[] args)throws Exception{
  World w=new World();Particle first=null;
  for(int i=0;i<201;i++){Particle p=new Particle();if(i==0)first=p;ImpactMarks.remember(p,w,i,0,0,"N",i,"ammo","gun","display");if(p.lifetime!=1700)throw new AssertionError("lifetime "+p.lifetime);}
  if(ImpactMarks.marks.size()!=200||!first.removed)throw new AssertionError("limit/FIFO");
  Particle replacement=new Particle();ImpactMarks.remember(replacement,w,1,0,0,"N",1,"ammo","gun","display");
  Particle next=new Particle();ImpactMarks.remember(next,w,300,0,0,"N",300,"ammo","gun","display");
  if(replacement.removed||ImpactMarks.marks.size()!=200)throw new AssertionError("refresh order");
  for(int i=0;i<1699;i++)TimedMarks.tick();if(ImpactMarks.marks.size()!=200)throw new AssertionError("early expiry");
  TimedMarks.tick();if(!ImpactMarks.marks.isEmpty()||!replacement.removed||!next.removed)throw new AssertionError("85 second expiry");
  ImpactMarks.remember(new Particle(),w,0,0,0,"N",0,"a","g","d");ImpactMarks.remember(new Particle(),new World(),0,0,0,"N",0,"a","g","d");if(ImpactMarks.marks.size()!=1)throw new AssertionError("world cleanup");
  System.out.println("PASS: 200 cap, FIFO removal, refreshed position ordering, lifetime 1700 ticks, expiry at 85s, world reset");
 }
}
