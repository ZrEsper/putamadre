package dev.zomboidmelee.boxing;
public class MotionTest {
 public static void main(String[] args){
  for(int combo=0;combo<2;combo++)for(int hand=0;hand<2;hand++){
   double last=0,max=0;
   for(int i=0;i<=10000;i++){double p=i/10000d,v=Motion16.value(combo,hand,p);if(!Double.isFinite(v)||Math.abs(v-last)>.004)throw new AssertionError("discontinuity");last=v;max=Math.max(max,v);}
   if(hand==Motion16.DOMINANT[combo]&&max<.99)throw new AssertionError("missing contact");
   if(Motion16.value(combo,hand,0)!=0||Motion16.value(combo,hand,1)!=0)throw new AssertionError("bad endpoints");
  }
  double last=0;for(int i=0;i<=10000;i++){double v=Motion16.kick(i/10000d);if(!Double.isFinite(v)||Math.abs(v-last)>.005)throw new AssertionError("kick discontinuity");last=v;}
  if(Motion16.kick(.24)>=0||Motion16.kick(.4)<.99)throw new AssertionError("kick anticipation/contact");
  long start=1;double max=0;for(int i=0;i<=460;i++){double w=BoxingClient16.cameraWave(start+i*1000000L,start,true);if(!Double.isFinite(w))throw new AssertionError();max=Math.max(max,Math.abs(w));}if(max>1.001)throw new AssertionError("camera overshoot");
  if(BoxingClient16.cameraWave(start+460000000,start,true)!=0)throw new AssertionError("camera not settled");
  BoxingClient16.nextPunch=0;BoxingClient16.started=0;BoxingClient16.combo=-1;BoxingClient16.begin(100000000);BoxingClient16.begin(101000000);if(BoxingClient16.combo!=0)throw new AssertionError("double start");
  Inherited obj=new Inherited();for(int i=0;i<10000;i++){FastFields.set(obj,"value",i);if(!FastFields.get(obj,"value").equals(i))throw new AssertionError("field cache");}
  System.out.println("PASS: 40,004 punch samples, 10,001 kick samples, bounded camera/settling, duplicate input, inherited field cache");
 }
 static class Base{private int value;}static class Inherited extends Base{}
}
