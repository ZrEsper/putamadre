from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import copy,hashlib,json,re
root=Path('work/action19');out=root/'release';out.mkdir(exist_ok=True)
files=[]
specs=[
('attachments/40c0e6e0-08c8-4cdf-9663-84153de9c1a6/zomboid-global-melee-animations-2.3.1-range-plus-one-ezweight-v18-heavy-fists-camera-stagger.jar','zomboid-global-melee-animations-2.3.1-v19-action-motion.jar',[('work/action19/classes','dev/zomboidmelee/')]),
('attachments/c63cbfc9-b554-4893-b0db-acc0be9d5c71/zomboid-zombie-gore-1.0.8-neoforge-1.21.1-boxing-knockdown-stomp.jar','zomboid-zombie-gore-1.0.9-neoforge-1.21.1-impact-reactions.jar',[('work/action19/classes','dev/zomboid/gore/')]),
('attachments/ff809ccb-c71a-4759-88a6-75b6d2a6a650/tacz-tactical-1.2.4-neoforge-1.21.1-distant-shots-768.4.jar','tacz-tactical-1.2.4-neoforge-1.21.1-marks200-85s.5.jar',[('work/visionfix/classes','dev/tactical/')]),
('attachments/443c5f30-2d76-441c-a1b7-8c4aa7e78cdb/firstaid-1.21.1-ZOMBOID-v3.6.3-treatment-animations.jar','firstaid-1.21.1-ZOMBOID-v3.6.4-native-visor-compat.jar',[('work/visionfix/patched','ichttt/'),('work/visionfix/patched','dev/zomboid/firstaid/'),('work/visionfix/classes','dev/zomboid/firstaid/')]),
('attachments/345ab06e-5bc6-4f98-b9e7-91c1f5841353/fracturepoint-1.21.1-3.0.0-PT2-nvg-manual-visor.3.jar','fracturepoint-1.21.1-3.0.0-PT2-native-visor-cache.4.jar',[('work/visionfix/patched','com/raiiiden/'),('work/visionfix/classes','com/raiiiden/')])]
for src,name,dirs in specs:
 changes={}
 for directory,prefix in dirs:
  for p in (Path(directory)/prefix).rglob('*.class'):changes[p.relative_to(directory).as_posix()]=p.read_bytes()
 with ZipFile(src) as base:
  meta=base.read('META-INF/neoforge.mods.toml').decode()
  if 'zombie-gore' in name:meta=meta.replace('version="1.0.8"','version="1.0.9"')
  if 'firstaid-' in name:meta=meta.replace('zomboid-v3.6.3-revival-recovery','zomboid-v3.6.4-revival-recovery')
  if meta.encode()!=base.read('META-INF/neoforge.mods.toml'):changes['META-INF/neoforge.mods.toml']=meta.encode()
  with ZipFile(out/name,'w',ZIP_DEFLATED) as z:
   for info in base.infolist():z.writestr(copy.copy(info),changes.get(info.filename,base.read(info)))
   for path,data in changes.items():
    if path not in base.namelist():z.writestr(path,data)
  with ZipFile(out/name) as z:
   assert z.testzip() is None
   assert len(z.namelist())==len(set(z.namelist()))
   for entry in base.namelist():
    if entry not in changes:assert z.read(entry)==base.read(entry),entry
   assert not any(n.startswith(('net/minecraft/','test/')) for n in changes)
 files.append(dict(input=src,input_sha256=hashlib.sha256(Path(src).read_bytes()).hexdigest(),file=name,sha256=hashlib.sha256((out/name).read_bytes()).hexdigest(),changed=sorted(changes)))
(out/'manifest.json').write_text(json.dumps(files,indent=2))
(out/'LEEME.txt').write_text('''COMBATE, VISORES NATIVOS E IMPACTOS — NEOFORGE 1.21.1

INSTALACION
Cierra el juego. Extrae los cinco JAR de este ZIP en mods y retira sus versiones anteriores: global-melee v18, zombie-gore 1.0.8, tactical distant-shots .4, firstaid 3.6.3 y fracturepoint visor .3. Instala las mismas versiones en servidor y clientes. Conserva el TaCZ principal .18-spas-reload-guard y el resource pack TZP que ya usas. No copies este ZIP en resourcepacks.

COMBATE
Curvas originales de puño con preparación corta, contacto y recuperación; brazos en guardia fuera del centro. Se evita iniciar varias veces el mismo golpe desde distintos eventos de ratón.
Patada/pisotón con levantamiento, descenso y regreso; conserva el remate gore existente (clic derecho a la cabeza de un zombi caído, manos vacías). Es una animación procedural original, no una importación de Doom o Call of Duty ni un sistema de glory kills cinematográficas.
Sacudida breve: máximo 0.18 grados de pitch en golpe normal y 0.45 en fuerte, roll muy reducido. Solo en primera persona; no cambia el yaw/pitch lógico ni secuestra el cursor o hace zoom automático.
Caída temporal progresiva de 0.36 s, recuperación de 0.65 s y asentamiento pequeño con pose asimétrica de brazos/piernas. No es una simulación ragdoll física.
Aturdimiento normal 3 ticks y fuerte 7; ventana de 30 ticks entre aturdimientos. Caída aleatoria 3.5% normal/18% fuerte y descanso mínimo de 160 ticks entre derribos.
Reacción al impacto del zombi más breve y con retraso de cabeza respecto al cuerpo. Se conservan heridas y desmembramiento de la base.
La pose específica de pisotón en tercera persona se aplica al jugador local; los jugadores remotos mantienen el swing que sincroniza la base.

VISION NOCTURNA
First Aid deja de reemplazar los efectos nativos de otros mods. Mientras el visor esté activo, se pausa el desenfoque/desaturación de First Aid; las lesiones, tratamientos y viñeta de daño siguen funcionando.
Fracture Point conserva N, los visores instalados, baterías y sus shaders nocturno/digital/térmico. Ya no bloquea cierres de shaders mediante inspección de la pila, lo que permite cerrar recursos al recargar o salir. Caché de campos/clases para reducir búsquedas repetidas.
No cambia automáticamente un visor nocturno a térmico: el efecto corresponde a las gafas instaladas y requiere batería.

MARCAS DE DISPARO
Máximo 200 impactos por cliente. Al entrar uno nuevo se elimina el más antiguo. Duración 1700 ticks de cliente (85 segundos de juego activo); pausar el juego pausa el contador.
La restauración al volver a una zona conserva la edad original, no reinicia la duración. Se elimina el acceso de reflexión sin caché en el cálculo del tamaño por fotograma. Mantiene tamaños por calibre, disparos lejanos y sonido de la base. No se modifica el JAR principal TaCZ .18.

VERIFICACION Y LIMITES
Compilado con Java 21; verificación ASM, pruebas de continuidad de curvas, cámara acotada, entrada duplicada, campos heredados, límite FIFO, caducidad a 85 s y cambio de mundo. Recursos y clases no modificados comparados byte a byte.
No se ejecutó Minecraft aquí: hace falta validar el aspecto con tu TZP/EMF y medir de nuevo con Spark; no se promete una cifra de FPS.
El log también tiene un error GeckoLib: melee_3 contiene la expresión inválida '0-'. Estos dos JAR de melee/gore no incluyen ese recurso; este paquete no corrige ese archivo externo.
''',encoding='utf-8')
with ZipFile(out/'Zomboid-Combate-Visores-Impactos.1.zip','w',ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.suffix=='.jar' or p.name in ['LEEME.txt','manifest.json']:z.write(p,p.name)
with ZipFile(out/'Zomboid-Combate-Visores-Impactos-Fuentes.1.zip','w',ZIP_DEFLATED) as z:
 for folder in ['work/action19/src','work/action19/test','work/visionfix/src','work/visionfix/test']:
  for p in Path(folder).rglob('*.java'):z.write(p,p.as_posix())
 for p in [root/'build.py',root/'FastFields.template',Path('work/visionfix/Patch.java'),out/'LEEME.txt',out/'manifest.json']:z.write(p,p.as_posix())
print('Built:',[(p.name,p.stat().st_size) for p in out.glob('*.zip')])
