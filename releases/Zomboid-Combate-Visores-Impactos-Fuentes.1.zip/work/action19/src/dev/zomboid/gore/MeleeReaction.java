/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 */
package dev.zomboid.gore;

import dev.zomboid.gore.Gore;
import dev.zomboid.gore.R;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;


public final class MeleeReaction {
    private static final WeakHashMap<Object, Reaction> REACTIONS = new WeakHashMap();
    private static final WeakHashMap<Object, List<Offset>> OFFSETS = new WeakHashMap();

    public static boolean event(Object object, byte by) {
        if (by > -101 || by < -103 || !Gore.zombie(object)) {
            return false;
        }
        REACTIONS.put(object, new Reaction((int)R.num(R.get(object, "tickCount")), -101 - by));
        return true;
    }

    public static float envelope(float t) {
        if(t<=0 || t>=12)return 0;
        if(t<1.5f){float x=t/1.5f;return x*x*(3-2*x);}
        float x=(t-1.5f)/10.5f;return (1-x)*(1-x)*(1+0.10f*(float)Math.sin(x*10));
    }

    public static void reset(Object object) {
        List<Offset> list = OFFSETS.remove(object);
        if (list == null) {
            return;
        }
        for (Offset offset : list) {
            MeleeReaction.adjust(offset.part, "xRot", -offset.x);
            MeleeReaction.adjust(offset.part, "yRot", -offset.y);
            MeleeReaction.adjust(offset.part, "zRot", -offset.z);
        }
    }

    private static void adjust(Object object, String string, float f) {
        if (f != 0.0f) {
            R.set(object, string, Float.valueOf((float)R.num(R.get(object, string)) + f));
        }
    }

    private static void add(Object object, List<Offset> list, String string, float f, float f2, float f3) {
        Object object2 = R.get(object, string);
        if (object2 == null) {
            return;
        }
        MeleeReaction.adjust(object2, "xRot", f);
        MeleeReaction.adjust(object2, "yRot", f2);
        MeleeReaction.adjust(object2, "zRot", f3);
        list.add(new Offset(object2, f, f2, f3));
    }

    public static void pose(Object object, Object object2, float f) {
        if (!Gore.zombie(object2)) {
            return;
        }
        Reaction reaction = REACTIONS.get(object2);
        if (reaction == null) {
            return;
        }
        float f2 = f - (float)reaction.tick;
        float f3 = MeleeReaction.envelope(f2);
        if (f2 >= 12.0f) {
            REACTIONS.remove(object2);
            return;
        }
        if (f3 == 0.0f) {
            return;
        }
        float f4 = reaction.variant == 1 ? -1.0f : 1.0f;
        ArrayList<Offset> arrayList = new ArrayList<Offset>(6);
        MeleeReaction.add(object, arrayList, "head", -0.24f * MeleeReaction.envelope(f2-0.6f), 0.17f * f3 * f4, 0.18f * f3 * f4);
        MeleeReaction.add(object, arrayList, "body", -0.19f * f3, 0.08f * f3 * f4, 0.13f * f3 * f4);
        MeleeReaction.add(object, arrayList, "rightArm", -0.28f * f3, -0.12f * f3, 0.23f * f3);
        MeleeReaction.add(object, arrayList, "leftArm", -0.28f * f3, 0.12f * f3, -0.23f * f3);
        if (reaction.variant == 2) {
            MeleeReaction.add(object, arrayList, "rightLeg", 0.21f * f3, 0.0f, 0.08f * f3);
            MeleeReaction.add(object, arrayList, "leftLeg", -0.16f * f3, 0.0f, -0.08f * f3);
        }
        OFFSETS.put(object, arrayList);
    }

    private record Reaction(int tick, int variant) {
    }

    private record Offset(Object part, float x, float y, float z) {
    }
}

