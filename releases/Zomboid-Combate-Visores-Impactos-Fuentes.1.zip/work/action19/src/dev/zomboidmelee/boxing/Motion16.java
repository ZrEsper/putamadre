package dev.zomboidmelee.boxing;
/** Original procedural strike curves: anticipation, contact, follow-through, recovery. */
public final class Motion16 {
 public static final int[] DOMINANT={1,0};
 public static double smooth(double x){x=Math.max(0,Math.min(1,x));return x*x*x*(x*(x*6-15)+10);}
 public static double curve(double p,double[] t,double[] v){if(!Double.isFinite(p)||p<=0||p>=1)return 0;for(int i=1;i<t.length;i++)if(p<=t[i])return v[i-1]+(v[i]-v[i-1])*smooth((p-t[i-1])/(t[i]-t[i-1]));return 0;}
 private static final double[] T={0,.12,.28,.38,.62,1}, V={0,-.12,1,.85,.18,0};
 public static double value(int combo,int hand,double p){double hit=curve(p,T,V);return hand==DOMINANT[Math.floorMod(combo,2)]?hit:hit*.065;}
 private static final double[] KT={0,.24,.40,.48,.72,1}, KV={0,-.35,1,1,.18,0};
 public static double kick(double p){return curve(p,KT,KV);}
}
