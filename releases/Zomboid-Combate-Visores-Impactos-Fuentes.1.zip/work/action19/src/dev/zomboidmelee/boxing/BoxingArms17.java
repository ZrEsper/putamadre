package dev.zomboidmelee.boxing;
public final class BoxingArms17 {
 public static void pose(Object model,int hand,float x,float y,float z){Object arm=R.get(model,hand==0?"rightArm":"leftArm");if(arm==null)return;R.set(arm,"xRot",x);R.set(arm,"yRot",y);R.set(arm,"zRot",z);try{Object sleeve=R.get(model,hand==0?"rightSleeve":"leftSleeve");if(sleeve!=null)R.call(sleeve,"copyFrom",arm);}catch(IllegalStateException ignored){}}
 public static void draw(Object renderer,Object poses,Object buffers,int light,Object player,int hand,double hit){
  int side=hand==0?1:-1;R.call(poses,"pushPose");
  try{
   // Keep the guard below the sightline, with forward travel and wrist rotation on contact.
   R.call(poses,"translate",side*(.43-.16*hit),-.68+.19*hit,-.14-.48*hit);
   BoxingClient16.rotate(poses,"YP",side*(19-22*hit));
   BoxingClient16.rotate(poses,"XP",-53-17*hit);
   BoxingClient16.rotate(poses,"ZP",side*(4+8*hit));
   R.call(poses,"translate",side*.3125,-.125,0d);
   R.call(renderer,hand==0?"renderRightHand":"renderLeftHand",poses,buffers,light,player);
  }finally{R.call(poses,"popPose");}
 }
 public static void flinch(Object model,float w){for(String name:new String[]{"body","head","rightArm","leftArm"}){Object p=R.get(model,name);if(p!=null)R.set(p,"xRot",(float)R.num(R.get(p,"xRot"))+(name.equals("head")?-.22f:.12f)*w);}}
 public static void leg(Object renderer,Object poses,Object buffers,int light,Object player,double phase){
  Object model=R.call(renderer,"getModel"),leg=R.get(model,"rightLeg");if(leg==null)return;
  float x=(float)R.num(R.get(leg,"xRot")),y=(float)R.num(R.get(leg,"yRot")),z=(float)R.num(R.get(leg,"zRot"));
  double k=Motion16.kick(phase),fade=Motion16.smooth(Math.min(phase/.13,(1-phase)/.2));
  R.call(poses,"pushPose");
  try{
   R.call(poses,"translate",.25,-1.25+.55*fade-.28*Math.max(0,k),-.30-.42*k);
   BoxingClient16.rotate(poses,"XP",-64-18*k);
   BoxingClient16.rotate(poses,"ZP",-5*fade);
   R.call(poses,"translate",-.12,-.75,0d);
   R.set(leg,"xRot",0f);R.set(leg,"yRot",0f);R.set(leg,"zRot",0f);
   Object tex=R.call(R.call(player,"getSkin"),"texture");
   Object buffer=R.call(buffers,"getBuffer",R.call(R.type("net.minecraft.client.renderer.RenderType"),"entitySolid",tex));
   R.call(leg,"render",poses,buffer,light,655360);
  }finally{R.set(leg,"xRot",x);R.set(leg,"yRot",y);R.set(leg,"zRot",z);R.call(poses,"popPose");}
 }
 public static void flush(Object buffers){if(R.type("net.minecraft.client.renderer.MultiBufferSource$BufferSource").isInstance(buffers))R.call(buffers,"endBatch");}
}
