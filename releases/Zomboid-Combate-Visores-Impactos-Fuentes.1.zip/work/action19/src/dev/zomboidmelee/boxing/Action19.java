package dev.zomboidmelee.boxing;
import java.util.*;
/** Client-only, visual transitions; never edits gameplay yaw, pitch or target. */
public final class Action19 {
 static final WeakHashMap<Object,Fall> FALLS=new WeakHashMap<>();
 static final class Fall{boolean down;double from,to;long changed;}
 static double blend(Fall f,long now){double duration=f.down?360_000_000d:650_000_000d;return f.from+(f.to-f.from)*Motion16.smooth((now-f.changed)/duration);}
 public static void prone(Object entity,Object poses){
  boolean down=Stomp18.temporary(entity);long now=BoxingClient16.CLOCK.getAsLong();Fall f=FALLS.get(entity);
  if(f==null){if(!down)return;f=new Fall();f.changed=now;f.down=true;f.to=1;FALLS.put(entity,f);}
  if(f.down!=down){f.from=blend(f,now);f.to=down?1:0;f.down=down;f.changed=now;}
  double w=blend(f,now);if(!down&&w<.001){FALLS.remove(entity);return;}
  // Width returns to standing during recovery; use a fixed adult reference while blending.
  double scale=down?Stomp18.fallenScale(entity):Math.max(.1,R.num(R.call(entity,"getBbWidth"))/.6);
  R.call(poses,"translate",0d,.22*scale*w,-.8*scale*w);
  BoxingClient16.rotate(poses,"XP",90*w);
  double age=(now-f.changed)/1e9;
  double settle=down&&age>.28&&age<.8?Math.sin((age-.28)*18)*Math.exp(-(age-.28)*10)*1.4:0;
  BoxingClient16.rotate(poses,"ZP",settle);
 }
 public static void zombiePose(Object model,Object entity){
  if(!Stomp18.temporary(entity))return;
  Fall f=FALLS.get(entity);double w=f==null?0:blend(f,BoxingClient16.CLOCK.getAsLong());
  part(model,"rightArm",(float)(-.8*w),(float)(-.25*w),(float)(.45*w));
  part(model,"leftArm",(float)(-.55*w),(float)(.2*w),(float)(-.34*w));
  part(model,"rightLeg",(float)(.25*w),0,(float)(.10*w));
  part(model,"leftLeg",(float)(-.12*w),0,(float)(-.08*w));
 }
 public static void body(Object model,Object player,double phase,int combo,boolean kick){
  double w=Math.max(0,Motion16.value(combo,Motion16.DOMINANT[Math.floorMod(combo,2)],phase));
  if(kick){double k=Motion16.kick(phase);part(model,"rightLeg",(float)(-1.1*k),0,.06f);part(model,"body",(float)(-.10*Math.max(0,k)),0,0);}
  else {Object torso=R.get(model,"body");float y=(float)R.num(R.get(torso,"yRot"));R.set(torso,"yRot",y+(float)((combo%2==0?1:-1)*.12*w));}
  // Match the skin overlays to the pose.
  for(String[] pair:new String[][]{{"rightPants","rightLeg"},{"leftPants","leftLeg"},{"jacket","body"}}){try{R.call(R.get(model,pair[0]),"copyFrom",R.get(model,pair[1]));}catch(IllegalStateException ignored){}}
 }
 static void part(Object m,String n,float x,float y,float z){Object p=R.get(m,n);R.set(p,"xRot",x);R.set(p,"yRot",y);R.set(p,"zRot",z);}
 public static boolean firstPerson(Object mc){return R.yes(R.call(R.call(R.get(mc,"options"),"getCameraType"),"isFirstPerson"));}
}
