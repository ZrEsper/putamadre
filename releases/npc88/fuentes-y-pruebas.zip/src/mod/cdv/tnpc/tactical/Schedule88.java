package mod.cdv.tnpc.tactical;
/** One dispatch point after recovery, before optional noise wandering and legacy patrol. */
public final class Schedule88{
 public static boolean work(Object n){if(!Community87.eligible(n))return false;
 // Older releases assigned every military survivor to guard duty, leaving no workers.
 if(Social.l(Social.tag(n),"npc88_oficio_migrado")==0){String role=Social.s(Social.tag(n),"npc87_oficio");if(Roles22.military(n)&&(role.isBlank()||role.equals("guardia")))Social.c(Social.tag(n),"putString","npc87_oficio",choose(n));Social.c(Social.tag(n),"putLong","npc88_oficio_migrado",1L);}
 return Community87.work(n);}
 static String choose(Object n){java.util.Set<String> used=new java.util.HashSet<>();Object home=Base48.base(n);for(Object peer:Social.nearby(n,"mod.cdv.tnpc.entity.AutoGunOperator",32)){Object p=Base48.base(peer);if(p==null||!Settlement87.allegiance(n).equals(Settlement87.allegiance(peer)))continue;int dx=Shelter77.axis(home,"getX")-Shelter77.axis(p,"getX"),dz=Shelter77.axis(home,"getZ")-Shelter77.axis(p,"getZ");if(dx*dx+dz*dz<=144&&Math.abs(Shelter77.axis(home,"getY")-Shelter77.axis(p,"getY"))<=3&&Social.l(Social.tag(peer),"npc88_oficio_migrado")!=0)used.add(Social.s(Social.tag(peer),"npc87_oficio"));}for(String job:java.util.List.of("granjero","constructor","minero","guardia"))if(!used.contains(job))return job;return java.util.List.of("granjero","constructor","minero","guardia").get(Math.floorMod(Social.uuid(n).hashCode(),4));}
 public static boolean freshHeard(Object n){if(Social.client(n)||!Social.alive(n)||Downed20.down(n))return false;Sense28.State sound=Sense28.state(n);return sound.priority>=3&&Social.time(n)-sound.heard<=2&&heard(n);}
 public static boolean heard(Object n){long now=Social.time(n);if(now<Social.l(Social.tag(n),"npc88_reaccion_ruido"))return false;Social.c(Social.tag(n),"putLong","npc88_reaccion_ruido",now+1200);return true;}
}
