package mod.cdv.tnpc.tactical;
import java.util.*;
public final class Supply88{
 /** Use the original transactional depot transfer, then reclaim real supplies needed for the current job. */
 static void deposit(Object n,Object chest){Map<String,Integer>keep=new LinkedHashMap<>();String role=Settlement87.profession(n);for(Object stack:DialogueRules72.bag(n)){String id=DialogueRules72.itemId(stack);int cap=id.endsWith("_hoe")||id.endsWith("_pickaxe")||id.endsWith("_axe")?1:role.equals("granjero")&&id.equals("minecraft:water_bucket")?1:role.equals("granjero")&&(id.equals("minecraft:wheat_seeds")||id.equals("minecraft:dirt"))?8:0;if(cap>0)keep.put(id,Math.min(cap,keep.getOrDefault(id,0)+DialogueRules72.size(stack)));}Hunt78.deposit(n,chest);keep.forEach((id,qty)->{int missing=qty-Base48.count(n,id);if(missing>0)Settlement87.from(n,chest,id,missing);});}
}
