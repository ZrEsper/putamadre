package mod.cdv.tnpc.tactical;
public class Flow88{static boolean recovering,working;static String order;public static boolean recover(Object n){order+="recovery ";return recovering;}public static boolean job(Object n){order+="job ";return working;}public static boolean sound(Object n){order+="noise";return true;}}
