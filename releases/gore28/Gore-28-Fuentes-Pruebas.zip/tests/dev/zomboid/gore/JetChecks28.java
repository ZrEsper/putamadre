package dev.zomboid.gore;
import net.minecraft.sounds.*;
public class JetChecks28 {
 public static class Hit{public String getType(){return "MISS";}}
 public static class World{public int clips,sounds;public SoundEvent last;public long getGameTime(){return 100;}public Hit clip(net.minecraft.world.level.ClipContext c){clips++;return new Hit();}public void playLocalSound(double x,double y,double z,SoundEvent s,SoundSource source,float volume,float pitch,boolean far){sounds++;last=s;}}
 public static void main(String[]args){World w=new World();var mc=net.minecraft.client.Minecraft.getInstance();mc.level=w;mc.player=new Object();Jets28.clear();var p=new Damage25.Point(0,1,0,0,0,-1);for(int i=0;i<50;i++)Jets28.offer(w,i,p,.9,100,mc);if(Jets28.ACTIVE.size()>16||w.clips>12)throw new AssertionError("budget");var buffer=new net.minecraft.client.renderer.MultiBufferSource.BufferSource();Skin12.bloodBuffer=buffer;Jets28.render(new net.neoforged.neoforge.client.event.RenderLevelStageEvent());if(buffer.consumer.positions.isEmpty()||Jets28.reported)throw new AssertionError("actual jet renderer");
 Bleed28.reset();Effects25.Seen seen=new Effects25.Seen();Bleed28.flowSound(w,p,seen,100,12,false);if(w.sounds!=1||!w.last.id().path().equals("arterial_flow28"))throw new AssertionError("pressure audio");Bleed28.flowSound(w,p,seen,101,13,false);if(w.sounds!=1)throw new AssertionError("sound throttle");Jets28.clear();if(!Jets28.ACTIVE.isEmpty())throw new AssertionError("world cleanup");System.out.println("SHIPPED_JET_RENDER_SOUND_AND_GLOBAL_COLLISION_BUDGET=PASS");}
}
