from pathlib import Path
import wave,math,random,struct,subprocess,json
from PIL import Image
r=Path(__file__).resolve().parent;(r/'audio').mkdir(exist_ok=True);stats={}
for kind,duration in [('arterial_flow28',.72),('blood_trickle28',.68),('blood_splash28',.30)]:
 for variant in range(3):
  rng=random.Random(2800+variant+len(kind));rate=24000;low=0;mid=0;values=[];bubbles=[(rng.uniform(.015,duration-.05),rng.uniform(360,1300),rng.uniform(.02,.05))for _ in range(9 if 'flow'in kind else 13)]
  for i in range(int(rate*duration)):
   t=i/rate;noise=rng.uniform(-1,1);low+=.13*(noise-low);mid+=.48*(noise-mid);band=mid-low
   if 'flow'in kind:env=(1-math.exp(-t*70))*math.exp(-t*2.5)*( .3+.7*max(0,math.sin(t*math.pi*4.5))**2);value=(band*.36+low*.48)*env
   elif 'trickle'in kind:env=math.sin(math.pi*t/duration)**1.1;value=low*.10*env
   else:env=(1-math.exp(-t*250))*math.exp(-t*17);value=(low*.65+band*.34)*env
   for start,f,decay in bubbles:
    age=t-start
    if 0<age<decay*4:value+=math.sin(2*math.pi*f*(1-age*.5)*age)*math.exp(-age/decay)*.045
   values.append(value)
  peak=max(map(abs,values));gain=min(1.9,.74/max(.001,peak));samples=[int(max(-.95,min(.95,v*gain))*32767)for v in values];p=r/'audio'/f'{kind}_{variant}.wav'
  with wave.open(str(p),'wb')as w:w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes(struct.pack('<'+'h'*len(samples),*samples))
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(p),'-c:a','libvorbis','-q:a','4',str(p.with_suffix('.ogg'))],check=True)
  stats[p.name]={'peak':max(map(abs,samples))/32768,'duration':duration}
(r/'audio-stats.json').write_text(json.dumps(stats,indent=2));Image.new('RGBA',(4,4),(135,13,28,255)).save(r/'bloodjet28.png')
