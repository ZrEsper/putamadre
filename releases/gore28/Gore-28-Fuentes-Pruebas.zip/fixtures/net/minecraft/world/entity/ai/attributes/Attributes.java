package net.minecraft.world.entity.ai.attributes;public final class Attributes{public static final Object MOVEMENT_SPEED=new Object();}
