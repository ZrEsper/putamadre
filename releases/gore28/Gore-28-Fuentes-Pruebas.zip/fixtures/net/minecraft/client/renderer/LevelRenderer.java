package net.minecraft.client.renderer;public class LevelRenderer{public static int getLightColor(Object level,Object pos){return 0xF000F0;}}
