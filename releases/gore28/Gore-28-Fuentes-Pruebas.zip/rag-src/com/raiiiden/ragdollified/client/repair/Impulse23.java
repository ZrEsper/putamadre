package com.raiiiden.ragdollified.client.repair;
import java.util.*;import dev.zomboid.gore.R;
/** No upward kick. Only strong shots get a tiny, globally budgeted nudge. */
public final class Impulse23 {
 static final Map<Object,Budget>BUDGETS=new WeakHashMap<>();static final class Budget{long time;double used;}
 public static double[] reduce(double x,double y,double z,double remaining){if(!Double.isFinite(x+y+z))return new double[3];double n=Math.sqrt(x*x+y*y+z*z);if(n<8)return new double[3];double strength=Math.min(.20,Math.max(0,(n-6)*.004)),horizontal=Math.hypot(x,z);if(horizontal<1e-8)return new double[3];double s=Math.min(strength,Math.max(0,remaining))/horizontal;return new double[]{x*s,0,z*s};}
 static double[] death(double x,double y,double z,double remaining){double n=Math.hypot(x,z);if(!Double.isFinite(n)||n<1e-8)return new double[3];double impulse=Math.min(Math.max(0,remaining),Math.min(.08,.012+n*.001));return new double[]{x/n*impulse,0,z/n*impulse};}
 static double[] old(double x,double y,double z,double remaining){x*=.12;y=Math.max(-2.5,Math.min(2.5,y*.12));z*=.12;double n=Math.sqrt(x*x+y*y+z*z),s=n>remaining?Math.max(0,remaining)/Math.max(.000001,n):1;return new double[]{x*s,y*s,z*s};}
 public static Object apply(Object rag,Object vector){return apply(rag,vector,true);}
 public static Object apply(Object rag,Object vector,boolean death){String type=String.valueOf(R.get(rag,"mobType"));boolean zombie=((Number)R.get(rag,"goreState12")).intValue()<0||type.contains("zombie")||type.equals("minecraft:husk")||type.equals("minecraft:drowned");double[]v;long now=System.nanoTime();synchronized(BUDGETS){Budget b=BUDGETS.computeIfAbsent(rag,k->new Budget());if(now-b.time>=200_000_000L){b.time=now;b.used=0;}double x=R.num(R.get(vector,"x")),y=R.num(R.get(vector,"y")),z=R.num(R.get(vector,"z"));v=zombie?(death?death(x,y,z,.20-b.used):new double[3]):old(x,y,z,12-b.used);b.used+=Math.sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);}return R.make("javax.vecmath.Vector3f",(float)v[0],(float)v[1],(float)v[2]);}
}
