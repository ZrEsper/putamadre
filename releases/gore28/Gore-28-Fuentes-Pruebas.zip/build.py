from pathlib import Path
import subprocess,zipfile,json,hashlib
r=Path(__file__).resolve().parent;previous=r.parent/'procedural27/output';GORE=next(previous.glob('zomboid*.jar'));RAG=next(previous.glob('ragdoll*.jar'));fixtures=r.parent/'procedural25/build/test'
exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{s}=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']]
for d in ['build/classes','build/rag','build/tools','output']:(r/d).mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(GORE)+':'+str(fixtures),'-d',str(r/'build/classes'),*map(str,(r/'src').rglob('*.java'))],check=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(GORE),'-d',str(r/'build/rag'),*map(str,(r/'rag-src').rglob('*.java'))],check=True)
subprocess.run(['java',*exports,'com.sun.tools.javac.Main',*exports,'-d',str(r/'build/tools'),str(r/'Patch.java')],check=True)
g=r/'output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-bleeding-limbs-slashes.28.jar';rag=r/'output/ragdollified-1.21.1-1.1.5-corpse-no-shot-push.23.jar'
subprocess.run(['java',*exports,'-cp',str(r/'build/tools'),'Patch',str(GORE),str(r/'build/classes'),str(g),str(RAG),str(r/'build/rag'),str(rag)],check=True)
with zipfile.ZipFile(g)as z:e={n:z.read(n)for n in z.namelist()}
e['assets/zomboid_gore/textures/entity/bloodjet28.png']=(r/'bloodjet28.png').read_bytes();sounds=json.loads(e['assets/zomboid_gore/sounds.json'])
for name in ['arterial_flow28','blood_trickle28','blood_splash28']:
 sounds[name]={'sounds':[{'name':f'zomboid_gore:{name}_{i}','attenuation_distance':14}for i in range(3)]}
 for i in range(3):e[f'assets/zomboid_gore/sounds/{name}_{i}.ogg']=(r/'audio'/f'{name}_{i}.ogg').read_bytes()
e['assets/zomboid_gore/sounds.json']=json.dumps(sounds,indent=2).encode();e['META-INF/neoforge.mods.toml']=e['META-INF/neoforge.mods.toml'].replace(b'Gore .27',b'Gore .28')
e['META-INF/zomboid-behavior28.json']=json.dumps({'patch':28,'changes':['narrow pressure jets and audio','disabled limb server/client behavior','mirrored hit frame corrected','blade incisions encoded in spare cut bits','dead corpse ignores shot impulses'],'protocol':'18-trauma28','minecraft_runtime_tested':False}).encode()
with zipfile.ZipFile(g,'w',zipfile.ZIP_DEFLATED)as z:
 for n,b in sorted(e.items()):z.writestr(n,b)
print(g,rag,sep='\n')
