import java.nio.file.*;import java.util.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;import jdk.internal.org.objectweb.asm.tree.analysis.*;
public class Patch implements Opcodes {
 static void tail(MethodNode m,String cls,String name,int slot){for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN){var l=new InsnList();l.add(new VarInsnNode(ALOAD,slot));l.add(new MethodInsnNode(INVOKESTATIC,"dev/zomboid/gore/"+cls,name,"(Ljava/lang/Object;)V",false));m.instructions.insertBefore(n,l);}}
 static String G="dev/zomboid/gore/";
 public static void main(String[]a)throws Exception{Map<String,byte[]>entries=new TreeMap<>();try(var z=new ZipFile(a[0])){for(var e:Collections.list(z.entries()))entries.put(e.getName(),z.getInputStream(e).readAllBytes());}
 int hooks=0;
 for(String path:List.of(G+"Skin12.class",G+"Gore.class",G+"Rules.class",G+"Visual11.class",G+"MeleeReaction.class",G+"Shards13.class")){ClassNode c=new ClassNode();new ClassReader(entries.get(path)).accept(c,0);for(var m:c.methods){
  if(c.name.equals(G+"Gore")&&m.name.equals("incoming")){tail(m,"Limb28","incoming",0);tail(m,"Melee28","incoming",0);hooks++;}
  if(c.name.equals(G+"Gore")&&m.name.equals("tick")){tail(m,"Limb28","tick",0);hooks++;}
  if(c.name.equals(G+"Skin12")&&m.name.equals("living")){tail(m,"Gait28","living",1);hooks++;}
  if(c.name.equals(G+"Skin12")&&m.name.equals("end")){for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN)m.instructions.insertBefore(n,new MethodInsnNode(INVOKESTATIC,G+"Gait28","end","()V",false));hooks++;}
  if(c.name.equals(G+"Shards13")&&m.name.equals("render")){tail(m,"Jets28","render",0);hooks++;}
  if(c.name.equals(G+"Rules")&&Set.of("speed","attack").contains(m.name)){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.instructions.add(new VarInsnNode(ILOAD,0));m.instructions.add(new MethodInsnNode(INVOKESTATIC,G+"Limb28",m.name,"(I)D",false));m.instructions.add(new InsnNode(DRETURN));hooks++;}
  if(c.name.equals(G+"Visual11")&&m.name.equals("pose")){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.instructions.add(new InsnNode(RETURN));hooks++;}
  if(c.name.equals(G+"MeleeReaction")&&m.name.equals("event")){var l=new InsnList();var next=new LabelNode();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(ILOAD,1));l.add(new MethodInsnNode(INVOKESTATIC,G+"Gait28","event","(Ljava/lang/Object;B)Z",false));l.add(new JumpInsnNode(IFEQ,next));l.add(new InsnNode(ICONST_1));l.add(new InsnNode(IRETURN));l.add(next);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(l);hooks++;}
 }ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);entries.put(path,w.toByteArray());}
 if(hooks!=9)throw new AssertionError("hooks="+hooks);
 try(var walk=Files.walk(Path.of(a[1]))){for(var p:walk.filter(p->p.toString().endsWith(".class")).toList())entries.put(Path.of(a[1]).relativize(p).toString(),Files.readAllBytes(p));}
 int verified=0;for(var e:entries.entrySet())if(e.getKey().endsWith(".class")&&e.getKey().startsWith(G)){ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);for(var m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);verified++;}
 try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(a[2])))){for(var e:entries.entrySet()){var n=new ZipEntry(e.getKey());n.setTime(0);z.putNextEntry(n);z.write(e.getValue());z.closeEntry();}}
 Map<String,byte[]>rag=new TreeMap<>();try(var z=new ZipFile(a[3])){for(var e:Collections.list(z.entries()))rag.put(e.getName(),z.getInputStream(e).readAllBytes());}
 String rp="com/raiiiden/ragdollified/client/ClientRagdoll.class";ClassNode rc=new ClassNode();new ClassReader(rag.get(rp)).accept(rc,0);int fall=0;
 for(var m:rc.methods)if(m.name.equals("applyHit")&&m.desc.equals("(ILjavax/vecmath/Vector3f;Ljavax/vecmath/Vector3f;Z)V")){for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode i&&i.owner.equals("com/raiiiden/ragdollified/client/repair/Impulse23")&&i.name.equals("apply")){m.instructions.insertBefore(i,new VarInsnNode(ILOAD,4));i.desc="(Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;";fall++;}}
 if(fall!=1)throw new AssertionError("corpse impulse hook "+fall);ClassWriter rw=new ClassWriter(ClassWriter.COMPUTE_MAXS);rc.accept(rw);rag.put(rp,rw.toByteArray());
 try(var walk=Files.walk(Path.of(a[4]))){for(var p:walk.filter(p->p.toString().endsWith(".class")).toList())rag.put(Path.of(a[4]).relativize(p).toString(),Files.readAllBytes(p));}
 String np="com/raiiiden/ragdollified/network/ModNetwork.class";ClassNode nc=new ClassNode();new ClassReader(rag.get(np)).accept(nc,0);int protocol=0;for(var m:nc.methods)for(var n:m.instructions)if(n instanceof LdcInsnNode literal&&literal.cst.equals("17-procedural25")){literal.cst="18-trauma28";protocol++;}if(protocol!=1)throw new AssertionError("protocol hook "+protocol);ClassWriter nw=new ClassWriter(0);nc.accept(nw);rag.put(np,nw.toByteArray());
 for(var e:rag.entrySet())if(e.getKey().endsWith(".class")&&e.getKey().startsWith("com/raiiiden/")){ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);for(var m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);verified++;}
 try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(a[5])))){for(var e:rag.entrySet()){var n=new ZipEntry(e.getKey());n.setTime(0);z.putNextEntry(n);z.write(e.getValue());z.closeEntry();}}
 System.out.println("RAGDOLL28_DEATH_VS_CORPSE_HOOK="+fall);
 System.out.println("GORE28_BEHAVIOR_HOOKS="+hooks+" VERIFIED_GORE_CLASSES="+verified);
 }
}
