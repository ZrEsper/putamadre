package dev.zomboid.gore;
public final class Melee28 {
 public static void incoming(Object event){Object victim=R.call(event,"getEntity");if(!Gore.zombie(victim))return;Object source=R.call(event,"getSource"),attacker=R.call(source,"getEntity");if(attacker==null||attacker!=R.call(source,"getDirectEntity"))return;Object stack=R.call(attacker,"getMainHandItem");if(R.yes(R.call(stack,"isEmpty"))){float value=(float)R.num(R.call(event,"getAmount"));if(value>0)R.call(event,"setAmount",value*.35f);}}
}
