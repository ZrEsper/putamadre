package dev.zomboid.gore;
/** Same handedness as LivingEntityRenderer: rotate(180-bodyYaw), scale(-1,-1,1). */
public final class Hit28 {
 public record Hit(int region,double x,double y,double z){}
 static final int[]REGIONS={0,2,3,4,5,6};
 public static double[] local(double dx,double dy,double dz,double yaw,double scale){double c=Math.cos(yaw),s=Math.sin(yaw);return new double[]{(dx*c+dz*s)*16/scale,dy*16/scale,(dx*s-dz*c)*16/scale};}
 public static double[] world(double x,double y,double z,double yaw,double scale){double c=Math.cos(yaw),s=Math.sin(yaw);return new double[]{(c*x+s*z)*scale/16,y*scale/16,(s*x-c*z)*scale/16};}
 static double[] box(int r){return switch(r){case 0->new double[]{-4,23.2,-4,4,31.2,4};case 2->new double[]{3,11.2,-2,7,23.2,2};case 3->new double[]{-7,11.2,-2,-3,23.2,2};case 4->new double[]{0,0,-2,4,12,2};case 5->new double[]{-4,0,-2,0,12,2};default->new double[]{-4,11.2,-2,4,23.2,2};};}
 static double clamp(double x){return Math.max(0,Math.min(1,x));}
 public static Hit classify(double x,double y,double z,boolean headHint){int r=6;double best=Double.POSITIVE_INFINITY;for(int region:REGIONS){double[]b=box(region);double dx=Math.max(b[0]-x,Math.max(0,x-b[3])),dy=Math.max(b[1]-y,Math.max(0,y-b[4])),dz=Math.max(b[2]-z,Math.max(0,z-b[5]));double dist=dx*dx+dy*dy+dz*dz;if(dist<best-1e-7||(Math.abs(dist-best)<1e-7&&(region>=2&&region<=5&&Math.abs(x)>=3.2||region==6&&Math.abs(x)<3.2))){best=dist;r=region;}}
 // Height of the actual point wins over a stale TaCZ headshot flag.
 if(headHint&&y>=22.5&&best<4)r=0;double[]b=box(r);return new Hit(r,clamp((x-b[0])/(b[3]-b[0])),clamp((b[4]-y)/(b[4]-b[1])),clamp((z-b[2])/(b[5]-b[2])));}
 public static Hit locate(Gore.Shot shot){Object n=shot.entity(),p=shot.point();double h=Math.max(.1,R.num(R.call(n,"getBbHeight"))),scale=h/1.95,yaw=Math.toRadians(R.num(R.get(n,"yBodyRot")));double[]v=local(R.num(R.get(p,"x"))-R.num(R.call(n,"getX")),R.num(R.get(p,"y"))-R.num(R.call(n,"getY")),R.num(R.get(p,"z"))-R.num(R.call(n,"getZ")),yaw,scale);Hit result=classify(v[0],v[1],v[2],shot.head());if(result.region()==0){try{double headYaw=Math.toRadians(R.num(R.get(n,"yHeadRot")));double[]q=local(R.num(R.get(p,"x"))-R.num(R.call(n,"getX")),R.num(R.get(p,"y"))-R.num(R.call(n,"getY")),R.num(R.get(p,"z"))-R.num(R.call(n,"getZ")),headYaw,scale);return new Hit(0,clamp(q[0]/8+.5),clamp((31.2-q[1])/8),clamp(q[2]/8+.5));}catch(RuntimeException absent){}}return result;}
 public static int zone(Gore.Shot shot){return locate(shot).region();}
}
