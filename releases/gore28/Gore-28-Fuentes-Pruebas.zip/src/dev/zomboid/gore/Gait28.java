package dev.zomboid.gore;
import java.util.*;
/** Late render correction survives EMF child animation and is restored after every part. */
public final class Gait28 {
 static final ThreadLocal<Object> ENTITY=new ThreadLocal<>();static final Map<Object,Float>ATTACK=new WeakHashMap<>();
 public static void living(Object n){ENTITY.set(n);}public static void end(){ENTITY.remove();}
 public static boolean event(Object n,byte event){if(event!=-113||!Gore.zombie(n))return false;ATTACK.put(n,((Number)R.get(n,"tickCount")).floatValue());return true;}
 public record Pose(float x,float y,float z,float drop){}
 public static float strike(float age){if(age<0||age>15)return 0;if(age<4)return -.18f*(float)Math.sin(age/4*Math.PI);return (float)(Math.sin((age-4)/11*Math.PI)*Math.exp(-(age-4)*.09));}
 public static Pose pose(int region,int state,double speed,float time,float attack){int d=Limb28.disabled(state),legs=d&48;boolean moving=speed>.002;float wave=(float)Math.sin(time*.38),step=(float)Math.sin(time*.38+Math.PI/2),side=(d&16)!=0?1:-1;float x=0,z=0,drop=0;
 if(legs!=0&&moving){if(legs==48){if(region==6)x=1.05f;if(region==0)x=-.35f;if(region==2||region==3)x=-.80f+wave*.12f;drop=region==6||region==0||region==2||region==3?.80f:0;}else{if(region==6){x=.12f;z=side*(.15f+.07f*wave);drop=.035f*Math.max(0,step);}if(region==0){x=-.05f;z=-side*.10f;}if(region==4||region==5){boolean damaged=(d&(1<<region))!=0;x=damaged?.10f+wave*.035f:wave*.45f;z=damaged?side*.09f:0;}}}
 if((region==2||region==3)&&(d&(1<<region))!=0){x=.18f;z=(region==2?-1:1)*.09f;}
 if(Limb28.headAttack(state)){float sway=(float)Math.sin(time*.19)*.075f;if(region==6){x+=.20f+attack*.48f;z+=sway;}if(region==0){x+=-.10f+attack*.72f;z-=sway*.7f;}}
 return new Pose(x,0,z,drop);}
 public static boolean needed(int state){return Limb28.disabled(state)!=0;}
 static float partial(Object n){try{return R.num(R.get(n,"tickCount"))==0?0:0;}catch(RuntimeException e){return 0;}}
 public static float[] apply(Object part,int region,int state){Object n=ENTITY.get();if(n==null||!needed(state))return null;float time=((Number)R.get(n,"tickCount")).floatValue();try{Object mc=R.call(R.type("net.minecraft.client.Minecraft"),"getInstance");Object dt=R.call(mc,"getTimer");time+=(float)R.num(R.call(dt,"getGameTimeDeltaPartialTick",false));}catch(RuntimeException optional){}
 Object vel=R.call(n,"getDeltaMovement");double speed=Math.hypot(R.num(R.get(vel,"x")),R.num(R.get(vel,"z")));float strike=strike(time-ATTACK.getOrDefault(n,-1000f));if(strike==0&&Limb28.headAttack(state)){try{strike=(float)Math.sin(Math.PI*R.num(R.call(n,"getAttackAnim",0f)));}catch(RuntimeException optional){}}
 Pose pose=pose(region,state,speed,time,strike);float[]saved={((Number)R.get(part,"xRot")).floatValue(),((Number)R.get(part,"yRot")).floatValue(),((Number)R.get(part,"zRot")).floatValue(),((Number)R.get(part,"y")).floatValue()};boolean limb=region>=2&&region<=5;
 R.set(part,"xRot",limb&&((Limb28.disabled(state)&(1<<region))!=0)?pose.x():saved[0]+pose.x());R.set(part,"yRot",saved[1]+pose.y());R.set(part,"zRot",saved[2]+pose.z());R.set(part,"y",saved[3]+pose.drop()*16);return saved;}
 public static void restore(Object part,float[]v){if(v==null)return;R.set(part,"xRot",v[0]);R.set(part,"yRot",v[1]);R.set(part,"zRot",v[2]);R.set(part,"y",v[3]);}
}
