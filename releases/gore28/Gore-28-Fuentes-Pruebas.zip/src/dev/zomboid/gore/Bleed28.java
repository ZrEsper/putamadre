package dev.zomboid.gore;
public final class Bleed28 {
 static long window=-1000;static int sounds;
 public static void reset(){window=-1000;sounds=0;}
 public static double pressure(long age,boolean dead){if(age<0)return 0;double decay=Math.max(0,1-age/(dead?65d:135d)),pulse=.58+.42*Math.pow(Math.max(0,Math.sin(age*.48)),2);return decay*decay*pulse;}
 public static void flowSound(Object world,Damage25.Point p,Effects25.Seen state,long now,long age,boolean dead){if(now-window>=20){window=now;sounds=0;}if(sounds>=4||now-state.sound<16||pressure(age,dead)<.12)return;state.sound=now;sounds++;String name=age<45?"arterial_flow28":"blood_trickle28";float volume=(float)(.17+.23*pressure(age,dead));R.call(world,"playLocalSound",p.x(),p.y(),p.z(),Artery14.makeSound(name),R.get(R.type("net.minecraft.sounds.SoundSource"),"HOSTILE"),volume,.94f+(now%5)*.025f,false);}
}
