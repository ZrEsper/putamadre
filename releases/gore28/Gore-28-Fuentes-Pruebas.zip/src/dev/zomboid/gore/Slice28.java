package dev.zomboid.gore;
public final class Slice28 {
 public static int quantize(double yaw,double pitch){double angle=Math.PI/180*(20+Math.max(-40,Math.min(40,pitch))*.55+25*Math.sin(Math.toRadians(yaw)));angle=(angle%Math.PI+Math.PI)%Math.PI;return ((int)Math.round(angle/Math.PI*8))&7;}
 public static int angle(Object victim,int kind){Object source=Ballistics11.SOURCE.get();Object sender=source==null?null:R.call(source,"getEntity");return angleSender(sender,victim,kind);}
 public static int angleSender(Object sender,Object victim,int kind){if(sender==null)return 1;double yaw=R.num(R.call(sender,"getYRot")),pitch=R.num(R.call(sender,"getXRot"));try{yaw-=R.num(R.get(victim,"yBodyRot"));}catch(RuntimeException absent){}int direction=quantize(yaw,pitch);return kind==2?(direction+2)&7:direction;}
}
