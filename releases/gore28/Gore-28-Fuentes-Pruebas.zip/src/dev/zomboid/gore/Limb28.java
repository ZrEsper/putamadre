package dev.zomboid.gore;
import java.util.*;
/** One authoritative damaged-limb state for AI speed, attack style and client posture. */
public final class Limb28 {
 static final Map<Object,Integer>APPLIED=new WeakHashMap<>();static final Map<Object,Long>ATTACKED=new WeakHashMap<>();
 public static boolean structural(int[]cuts,int r){if(Damage25.destroyed(cuts,r))return true;int hit=0;for(double y:new double[]{.18,.34,.50,.67,.83})if(Cuts24.covered(cuts,r,.5,y,.5,.55))hit++;return hit>=2||Damage25.coverage(cuts,r,.55)>=.30;}
 public static int state(int old,int[]cuts){int s=old;for(int r=2;r<=5;r++)if(structural(cuts,r)||(s&(1<<r))!=0)s|=1<<(24+r);return s;}
 public static int disabled(int state){return (state&0x3c)|((state>>>26)&15)<<2;}
 public static double speed(int state){int n=Integer.bitCount(disabled(state)&0x30);return n==2?.12:n==1?.40:1;}
 public static boolean headAttack(int s){return (disabled(s)&12)==12&&(s&1)==0;}
 public static double attack(int state){int arms=Integer.bitCount(disabled(state)&12);if(arms==2)return (state&1)!=0?0:.55;return arms==1?.70:1;}
 public static void tick(Object event){Object n=R.call(event,"getEntity");if(!Gore.zombie(n)||R.yes(R.get(R.call(n,"level"),"isClientSide")))return;int tick=((Number)R.get(n,"tickCount")).intValue();if(tick%5!=0)return;int old=Gore.state(n),s=state(old,Cuts24.get(n));if(s!=old)Gore.set(n,s);Integer applied=APPLIED.get(n);if(applied==null||applied!=s||tick%40==0){APPLIED.put(n,s);Gore.modifier(n,"MOVEMENT_SPEED","injury_speed",speed(s));}
 // Grounded gait has a pronounced support phase; do not damp jumping, swimming or falls.
 if((disabled(s)&0x30)!=0&&R.yes(R.call(n,"onGround"))){Object v=R.call(n,"getDeltaMovement");double x=R.num(R.get(v,"x")),z=R.num(R.get(v,"z"));double horizontal=Math.hypot(x,z),limit=(disabled(s)&0x30)==0x30?.017:.045;if(horizontal>limit){double k=limit/horizontal;R.call(n,"setDeltaMovement",R.call(v,"multiply",k,1d,k));}R.call(n,"setSprinting",false);}
 }
 public static void incoming(Object event){Object source=R.call(event,"getSource"),n=R.call(source,"getDirectEntity");if(!Gore.zombie(n)||n!=R.call(source,"getEntity")||!headAttack(Gore.state(n)))return;Object world=R.call(n,"level");if(R.yes(R.get(world,"isClientSide")))return;long now=((Number)R.call(world,"getGameTime")).longValue();if(now-ATTACKED.getOrDefault(n,-1000L)<12)return;ATTACKED.put(n,now);R.call(world,"broadcastEntityEvent",n,(byte)-113);}
}
