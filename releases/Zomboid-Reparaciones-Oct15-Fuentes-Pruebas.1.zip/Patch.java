import java.nio.file.*;import java.util.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public class Patch implements Opcodes{
 static InsnList zeroGuard(String helper,String method){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new MethodInsnNode(INVOKESTATIC,helper,method,"(Ljava/lang/Object;)Z",false));LabelNode go=new LabelNode();l.add(new JumpInsnNode(IFEQ,go));l.add(new InsnNode(ICONST_0));l.add(new InsnNode(IRETURN));l.add(go);l.add(new FrameNode(F_SAME,0,null,0,null));return l;}
 public static void main(String[]a)throws Exception{try(ZipFile z=new ZipFile(a[0])){String path=a[1];ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(path))).accept(c,0);int edits=0;
 for(MethodNode m:List.copyOf(c.methods)){
  if(path.endsWith("ZoneReserve.class")&&m.name.equals("corpse")){m.instructions.insert(zeroGuard("dev/zomboid/hordes/PlayerCorpseGuard","corpse"));edits++;}
  if(path.endsWith("CursorTarget.class")&&m.name.equals("aimPoint")){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new MethodInsnNode(INVOKESTATIC,"dev/zomboid/isotacz/CursorAim","point","(Ljava/lang/Object;)Ljava/lang/Object;",false));m.instructions.add(new InsnNode(ARETURN));edits++;}
  if(path.endsWith("CorpseEntity.class")){
   if(m.name.equals("hurt")){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new InsnNode(ICONST_0));m.instructions.add(new InsnNode(IRETURN));edits++;}
   if(m.name.equals("tick")){for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.name.equals("discard")){
     // Both timed removal paths must require an empty corpse.
     InsnList l=new InsnList();LabelNode skip=new LabelNode();l.add(new InsnNode(DUP));l.add(new MethodInsnNode(INVOKEVIRTUAL,c.name,"isEmpty","()Z",false));l.add(new JumpInsnNode(IFNE,skip));l.add(new InsnNode(POP));LabelNode done=new LabelNode();l.add(new JumpInsnNode(GOTO,done));l.add(skip);m.instructions.insertBefore(i,l);m.instructions.insert(i,done);edits++;
   }}
   if(m.name.equals("remove")){
    m.name="v113Remove";MethodNode n=new MethodNode(ACC_PUBLIC,"remove",m.desc,null,null);LabelNode live=new LabelNode(),unload=new LabelNode();n.instructions.add(new VarInsnNode(ALOAD,0));n.instructions.add(new MethodInsnNode(INVOKEVIRTUAL,c.name,"isRemoved","()Z",false));n.instructions.add(new JumpInsnNode(IFEQ,live));n.instructions.add(new InsnNode(RETURN));n.instructions.add(live);n.instructions.add(new VarInsnNode(ALOAD,1));n.instructions.add(new MethodInsnNode(INVOKEVIRTUAL,"net/minecraft/world/entity/Entity$RemovalReason","shouldDestroy","()Z",false));n.instructions.add(new JumpInsnNode(IFEQ,unload));n.instructions.add(new VarInsnNode(ALOAD,0));n.instructions.add(new VarInsnNode(ALOAD,1));n.instructions.add(new MethodInsnNode(INVOKEVIRTUAL,c.name,"v113Remove",m.desc,false));n.instructions.add(new InsnNode(RETURN));n.instructions.add(unload);n.instructions.add(new VarInsnNode(ALOAD,0));n.instructions.add(new VarInsnNode(ALOAD,1));n.instructions.add(new MethodInsnNode(INVOKESPECIAL,c.superName,"remove",m.desc,false));n.instructions.add(new InsnNode(RETURN));c.methods.add(n);edits++;
   }
  }
 }
 if(edits==0)throw new AssertionError(path);boolean full=path.endsWith("CorpseEntity.class");ClassWriter w=new ClassWriter(full?ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS:ClassWriter.COMPUTE_MAXS){protected String getCommonSuperClass(String a,String b){return "java/lang/Object";}};c.accept(w);Path out=Path.of(a[2],path);Files.createDirectories(out.getParent());Files.write(out,w.toByteArray());System.out.println(path+": "+edits+" changes");
 }}}
