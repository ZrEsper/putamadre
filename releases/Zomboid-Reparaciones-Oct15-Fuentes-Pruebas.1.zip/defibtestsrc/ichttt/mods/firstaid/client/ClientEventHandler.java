package ichttt.mods.firstaid.client;public class ClientEventHandler{public static int resets;private static void resetInteractionPromptHoldState(){resets++;}}
