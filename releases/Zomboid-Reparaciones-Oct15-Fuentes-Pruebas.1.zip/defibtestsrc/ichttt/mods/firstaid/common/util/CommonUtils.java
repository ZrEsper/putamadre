package ichttt.mods.firstaid.common.util;public class CommonUtils{public static void syncDamageModel(Object p){}}
