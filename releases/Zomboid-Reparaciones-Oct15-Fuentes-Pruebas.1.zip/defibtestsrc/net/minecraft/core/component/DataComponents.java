package net.minecraft.core.component;public class DataComponents{public static final Object MAX_DAMAGE=new Object();}
