package dev.zomboid.hordes;public final class PlayerCorpseGuard{public static boolean corpse(Object e){return e!=null&&e.getClass().getName().equals("de.maxhenkel.corpse.entities.CorpseEntity");}}
