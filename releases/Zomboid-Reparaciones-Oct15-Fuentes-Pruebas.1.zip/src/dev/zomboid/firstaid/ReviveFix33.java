/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.firstaid;

import dev.zomboid.firstaid.Assist;
import dev.zomboid.firstaid.R;
import dev.zomboid.firstaid.Revival;
import dev.zomboid.firstaid.ZeroParts;

public final class ReviveFix33 {
    static boolean clientRequested;

    static Object c(Object object, String string, Object ... objectArray) {
        return R.call(object, string, objectArray);
    }

    static boolean yes(Object object) {
        return Boolean.TRUE.equals(object);
    }

    static void say(Object object, String string, Object ... objectArray) {
        ReviveFix33.c(object, "displayClientMessage", ReviveFix33.c(R.type("net.minecraft.network.chat.Component"), "translatable", string, objectArray), true);
    }

    public static long duration(Object object, Object object2) {
        return Assist.defib(object) != null ? 60L : 160L;
    }

    public static Object selection(Object object) {
        String[] stringArray = new String[]{"MAIN_HAND", "OFF_HAND"};
        int n = stringArray.length;
        int n2 = 0;
        while (n2 < n) {
            String string = stringArray[n2];
            Object object2 = R.get(R.type("net.minecraft.world.InteractionHand"), string);
            Object object3 = ReviveFix33.c(object, "getItemInHand", object2);
            if (ReviveFix33.yes(ReviveFix33.c(R.type("ichttt.mods.firstaid.common.EventHandler"), "isDefibrillator", object3))) {
                return R.make("ichttt.mods.firstaid.common.EventHandler$InteractionSelection", R.get(R.type("ichttt.mods.firstaid.common.EventHandler$InteractionType"), "RESCUE"), object2);
            }
            ++n2;
        }
        return null;
    }

    public static Object prompt(Object object) {
        Object object2 = R.get(object, "player");
        if (object2 == null || !ReviveFix33.yes(ReviveFix33.c(object2, "isAlive", new Object[0])) || Assist.model(object2) == null || !Revival.active(Assist.model(object2)) || Assist.defib(object2) == null) {
            return null;
        }
        Object object3 = ReviveFix33.c(object2, "getMainHandItem", new Object[0]) == Assist.defib(object2) ? R.get(R.type("net.minecraft.world.InteractionHand"), "MAIN_HAND") : R.get(R.type("net.minecraft.world.InteractionHand"), "OFF_HAND");
        boolean bl = R.get(object, "screen") == null && ReviveFix33.yes(ReviveFix33.c(R.get(R.get(object, "options"), "keyUse"), "isDown", new Object[0]));
        return R.make("ichttt.mods.firstaid.client.ClientEventHandler$InteractionPrompt", ((Number)ReviveFix33.c(object2, "getId", new Object[0])).intValue(), ReviveFix33.c(object2, "getDisplayName", new Object[0]), R.get(R.type("ichttt.mods.firstaid.client.ClientEventHandler$InteractionType"), "SELF_DEFIB"), bl, object3, 60);
    }

    public static void clientTick(Object object) {
        DefibRearm.tick(object);
        boolean bl;
        Object object2 = ReviveFix33.prompt(object);
        boolean bl2 = bl = object2 != null && ReviveFix33.yes(ReviveFix33.c(object2, "isSneaking", new Object[0]));
        if (!bl) {
            clientRequested = false;
            return;
        }
        if (clientRequested) {
            return;
        }
        clientRequested = true;
        Object object3 = R.make("ichttt.mods.firstaid.common.network.MessageClientRequest", R.get(R.type("ichttt.mods.firstaid.common.network.MessageClientRequest$RequestType"), "ATTEMPT_SELF_DEFIB"));
        ReviveFix33.c(R.get(R.type("ichttt.mods.firstaid.FirstAid"), "NETWORKING"), "sendToServer", object3);
    }

    public static void finish(Object object, Object object2) {finishBy(object,object2,object2);}
    public static boolean finishBy(Object object, Object object2,Object actor) {
        Assist.completing = object;
        try {
            Object object32;
            Object defib=Assist.defib(actor);
            boolean rescued=defib!=null?yes(c(object,"defibrillatorRescueFromCriticalState",object2,false)):yes(c(object,"rescueFromCriticalState",object2,null,false));
            if(!rescued)return false;
            for (Object part : ZeroParts.parts(object)) {
                float f = ((Number)ReviveFix33.c(part, "getMaxHealth", new Object[0])).floatValue();
                R.set(part, "currentHealth", Float.valueOf(Math.max(((Number)R.get(part, "currentHealth")).floatValue(), Math.min(f, f * 0.3f))));
            }
            R.set(object, "criticalConditionActive", false);
            ReviveFix33.c(object, "clearUnconsciousState", new Object[0]);
            ReviveFix33.c(object, "clearUnconsciousPenalties", object2);
            ReviveFix33.c(object2, "setForcedPose", new Object[1]);
            ReviveFix33.c(object2, "setShiftKeyDown", false);
            ReviveFix33.c(object2, "refreshDimensions", new Object[0]);
            object32 = ReviveFix33.c(object2, "getPersistentData", new Object[0]);
            ReviveFix33.c(object32, "putLong", "FADownDeadline", 0L);
            ReviveFix33.c(object32, "putInt", "FAFinishHits", 0);
            ReviveFix33.c(object32, "putLong", "FABleedGraceUntil", Assist.time(object2) + 400L);
            ReviveFix33.c(object, "syncVanillaHealth", object2);
            ReviveFix33.c(object, "scheduleResync", new Object[0]);
            ReviveFix33.c(R.type("ichttt.mods.firstaid.common.util.CommonUtils"), "syncDamageModel", object2);
            ClickRevival.wake(object,object2);
            if(defib!=null)DefibUses.consume(defib,actor);
            clientRequested=false;
            ReviveFix33.say(object2, "firstaid.revive33.complete", new Object[0]);
            return true;
        }
        finally {
            Assist.completing = null;
        }
    }

    public static void message(Object object, String string) {
        Assist.Attempt attempt = Assist.attempts.get(object);
        if (attempt != null && (string.startsWith("Reanimando") || string.startsWith("Desfibrilador"))) {
            long l = ReviveFix33.duration(object, attempt.target());
            long l2 = Math.max(0L, Assist.time(object) - attempt.start());
            int n = (int)Math.min(100L, l2 * 100L / l);
            int n2 = n / 5;
            String string2 = "[" + "|".repeat(n2) + "\u00b7".repeat(20 - n2) + "]";
            ReviveFix33.say(object, "firstaid.revive33.progress", string2, n, l / 20L);
            return;
        }
        Assist.message(object, string);
    }
}

