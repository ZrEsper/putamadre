package dev.zomboid.firstaid.client;
import net.minecraft.client.Minecraft;import net.minecraft.client.multiplayer.ClientPacketListener;import net.minecraft.world.entity.player.Player;import net.minecraft.world.InteractionHand;import net.minecraft.network.protocol.game.ServerboundInteractPacket;
public final class ReviveTransport {
 public static boolean send(Object actor,Object target){
  Minecraft mc=Minecraft.getInstance();ClientPacketListener connection=mc.getConnection();
  if(connection==null||mc.player==null||actor!=mc.player||!(target instanceof Player other)||other==mc.player||!other.isAlive()||other.level()!=mc.player.level())return false;
  try{connection.send(ServerboundInteractPacket.createInteractionPacket(other,mc.player.isShiftKeyDown(),InteractionHand.MAIN_HAND));return true;}
  catch(RuntimeException e){System.getLogger("FirstAidRevival").log(System.Logger.Level.WARNING,"No se pudo enviar la solicitud de revivir",e);return false;}
 }
}
