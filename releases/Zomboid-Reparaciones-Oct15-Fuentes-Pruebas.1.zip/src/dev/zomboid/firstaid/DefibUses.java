package dev.zomboid.firstaid;
public final class DefibUses {
 public static int remaining(int damage){return Math.max(0,5-Math.max(0,damage));}
 public static void consume(Object stack,Object actor){
  if(stack==null||R.yes(R.call(stack,"isEmpty"))||R.yes(R.call(actor,"isCreative")))return;
  Object component=R.get(R.type("net.minecraft.core.component.DataComponents"),"MAX_DAMAGE");R.call(stack,"set",component,5);
  int damage=((Number)R.call(stack,"getDamageValue")).intValue()+1;
  if(damage>=5){R.call(stack,"shrink",1);R.call(stack,"setDamageValue",0);}else R.call(stack,"setDamageValue",damage);
  R.call(actor,"displayClientMessage",R.call(R.type("net.minecraft.network.chat.Component"),"literal","Desfibrilador: "+remaining(damage)+"/5 usos"),true);
 }
 public static void reserve(Object stack,int amount,Object actor,Object slot){
  if(!R.yes(R.call(R.type("ichttt.mods.firstaid.common.EventHandler"),"isDefibrillator",stack)))R.call(stack,"hurtAndBreak",amount,actor,slot);
 }
 public static boolean nativeRescue(Object model,Object target,boolean delayed,Object stack,Object actor){
  Object previous=Assist.completing;Assist.completing=model;
  try{boolean success=R.yes(R.call(model,"defibrillatorRescueFromCriticalState",target,false));if(success){ClickRevival.wake(model,target);consume(stack,actor);}return success;}finally{Assist.completing=previous;}
 }
 @SuppressWarnings("unchecked")public static void tooltip(Object event){
  Object stack=R.call(event,"getItemStack");if(!R.yes(R.call(R.type("ichttt.mods.firstaid.common.EventHandler"),"isDefibrillator",stack)))return;
  int damage=((Number)R.call(stack,"getDamageValue")).intValue();Object text=R.call(R.type("net.minecraft.network.chat.Component"),"translatable","firstaid.defib.charges",new Object[]{remaining(damage),5});
  ((java.util.List<Object>)R.call(event,"getToolTip")).add(text);
 }

}
