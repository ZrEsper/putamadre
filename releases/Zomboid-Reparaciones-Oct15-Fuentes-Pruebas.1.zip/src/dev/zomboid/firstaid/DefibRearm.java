package dev.zomboid.firstaid;
public final class DefibRearm {
 static Object player;static boolean down;static int ticks;
 public static void tick(Object mc){
  Object p=R.get(mc,"player");Object model=p==null?null:Assist.model(p);boolean now=model!=null&&Revival.active(model);int left=model==null?0:((Number)R.call(model,"getUnconsciousTicks")).intValue();
  if(p!=player||now&&!down||now&&left>ticks+20){ReviveFix33.clientRequested=false;R.call(R.type("ichttt.mods.firstaid.client.ClientEventHandler"),"resetInteractionPromptHoldState");}
  player=p;down=now;ticks=left;
 }
}
