/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.firstaid;

import dev.zomboid.firstaid.Assist;
import dev.zomboid.firstaid.R;
import dev.zomboid.firstaid.Revival;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public final class ClickRevival {
    public static boolean interact(Object object) {
        Object object2 = R.call(object, "getEntity", new Object[0]);
        Object object3 = R.call(object, "getTarget", new Object[0]);
        if (object3 == null || !R.type("net.minecraft.world.entity.player.Player").isInstance(object3)) {
            return false;
        }
        Object object4 = Assist.model(object3);
        if (object4 == null || !Revival.active(object4)) {
            return false;
        }
        if (R.yes(R.call(R.call(object2, "level", new Object[0]), "isClientSide", new Object[0]))) {
            R.call(R.type("dev.zomboid.firstaid.client.ReviveTransport"),"send",object2,object3);
            R.call(object, "setCanceled", true);
            R.call(object, "setCancellationResult", R.get(R.type("net.minecraft.world.InteractionResult"), "SUCCESS"));
            return true;
        }
        boolean bl = R.yes(R.call(Assist.class, "v352OriginalInteract", object));
        if (bl) {
            R.call(object, "setCancellationResult", R.get(R.type("net.minecraft.world.InteractionResult"), "SUCCESS"));
        }
        return bl;
    }

    public static Object prompt(Object object) {
        try {
            Object object2;
            block8: {
                block7: {
                    Object object3 = R.get(object, "player");
                    Object object4 = R.get(object, "hitResult");
                    object2 = R.call(object4, "getEntity", new Object[0]);
                    if (object3 == null || object2 == null || object2 == object3 || !R.type("net.minecraft.world.entity.player.Player").isInstance(object2)) {
                        return null;
                    }
                    Object object5 = Assist.model(object2);
                    if (object5 == null || !Revival.active(object5) || !R.yes(R.call(object3, "isAlive", new Object[0])) || R.yes(R.call(Assist.model(object3), "isUnconscious", new Object[0]))) break block7;
                    Object[] objectArray = new Object[]{object2};
                    if (!(R.num(R.call(object3, "distanceToSqr", objectArray)) > 9.0)) break block8;
                }
                return null;
            }
            Object object6 = ClickRevival.field(R.type("ichttt.mods.firstaid.client.ClientEventHandler$InteractionType"), "RESCUE");
            Object object7 = ClickRevival.field(R.type("net.minecraft.world.InteractionHand"), "MAIN_HAND");
            Class<?> clazz = R.type("ichttt.mods.firstaid.client.ClientEventHandler$InteractionPrompt");
            for (Constructor<?> constructor : clazz.getDeclaredConstructors()) {
                if (constructor.getParameterCount() != 6) continue;
                constructor.setAccessible(true);
                return constructor.newInstance(((Number)R.call(object2, "getId", new Object[0])).intValue(), R.call(object2, "getDisplayName", new Object[0]), object6, false, object7, 160);
            }
            return null;
        }
        catch (ReflectiveOperationException | RuntimeException exception) {
            return null;
        }
    }

    private static Object field(Class<?> clazz, String string) throws ReflectiveOperationException {
        Field field = clazz.getDeclaredField(string);
        field.setAccessible(true);
        return field.get(null);
    }

    public static void wake(Object object, Object object2) {
        if (Revival.active(object)) {
            return;
        }
        R.call(object, "clearUnconsciousState", new Object[0]);
        R.call(object, "clearUnconsciousPenalties", object2);
        R.call(object2, "setForcedPose", new Object[]{null});
        R.call(object2, "setShiftKeyDown", false);
        R.call(object2, "refreshDimensions", new Object[0]);
        Object object3 = R.call(object2, "getPersistentData", new Object[0]);
        R.call(object3, "putLong", "FADownDeadline", 0L);
        Object object4 = R.make("net.minecraft.world.effect.MobEffectInstance", R.get(R.type("net.minecraft.world.effect.MobEffects"), "REGENERATION"), 100, 1);
        if (object4 != null) {
            R.call(object2, "addEffect", object4);
        }
        R.call(object, "scheduleResync", new Object[0]);
        R.call(R.type("ichttt.mods.firstaid.common.util.CommonUtils"), "syncDamageModel", object2);
    }
}

