package dev.zomboid.isotacz;
import java.util.*;import java.util.function.Predicate;
public final class CursorAim {
 public static double planeParameter(double originY,double endY,double height){double dy=endY-originY;if(!Double.isFinite(dy)||Math.abs(dy)<1e-7)return -1;double t=(height-originY)/dy;return Double.isFinite(t)&&t>=0&&t<=1?t:-1;}
 public static boolean ceiling(boolean hit,String face,double hitY,double eyeY){return hit&&"DOWN".equals(face)&&hitY>eyeY+.5;}
 public static Object point(Object mc){
  Object player=R.get(mc,"player"),level=R.get(mc,"level"),eye=R.call(player,"getEyePosition");Object[] ray=CursorTarget.ray(mc);
  Object start=ray[0],end=ray[1],delta=R.call(end,"subtract",start);
  Object context=R.make("com.cleannrooster.dungeons_iso.api.RaycastContextCull",start,end,R.get(R.type("com.cleannrooster.dungeons_iso.api.CustomShapeTypes"),"CULLED"),R.get(R.type("net.minecraft.world.level.ClipContext$Block"),"OUTLINE"),R.get(R.type("net.minecraft.world.level.ClipContext$Fluid"),"NONE"),player);
  Object block=R.call(level,"clip",context),location=R.call(block,"getLocation");boolean blockHit=!R.call(block,"getType").toString().equals("MISS");
  boolean roof=blockHit&&ceiling(true,String.valueOf(R.call(block,"getDirection")),Bridge.v(location,"y"),Bridge.v(eye,"y"));
  Object bounds=R.call(R.type("net.minecraft.world.phys.AABB"),"ofSize",start,1d,1d,1d);bounds=R.call(R.call(bounds,"expandTowards",delta),"inflate",.1d);
  Object chosen=null;double nearest=Double.POSITIVE_INFINITY;
  Predicate<Object> targets=e->R.yes(R.call(e,"isPickable"))&&!R.yes(R.call(e,"isSpectator"))&&R.yes(R.call(e,"isAlive"));
  for(Object e:(List<?>)R.call(level,"getEntities",player,bounds,targets)){
   Optional<?> hit=(Optional<?>)R.call(R.call(e,"getBoundingBox"),"clip",start,end);if(hit.isEmpty())continue;
   Object at=hit.get();double distance=Bridge.distance(start,at);if(distance>=nearest)continue;
   // Camera-side ceilings must not override an entity visible from the shooter's eyes.
   Object los=Bridge.clip(level,player,eye,at);
   if(R.call(los,"getType").toString().equals("BLOCK")&&Bridge.distance(eye,R.call(los,"getLocation"))<Bridge.distance(eye,at)-.06)continue;
   chosen=at;nearest=distance;
  }
  if(chosen!=null)return chosen;
  if(blockHit&&!roof)return location;
  double t=planeParameter(Bridge.v(start,"y"),Bridge.v(end,"y"),Bridge.v(eye,"y")-.8);
  if(t>=0)return Bridge.plus(start,Bridge.v(delta,"x")*t,Bridge.v(delta,"y")*t,Bridge.v(delta,"z")*t);
  return location;
 }
}
