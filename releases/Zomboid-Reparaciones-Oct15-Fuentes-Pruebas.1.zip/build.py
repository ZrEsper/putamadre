from pathlib import Path
import zipfile,copy,json,hashlib,re
p=Path('work/repairs-oct15');out=p/'release';out.mkdir(exist_ok=True)
items=[('fa',Path('attachments/8829a937-cd97-40e4-ba1e-7a9a738da216/firstaid-1.21.1-ZOMBOID-v3.5.8-defib-priority-medical-progress.jar'),'firstaid-1.21.1-ZOMBOID-v3.5.9-revival-safe-defib5-cure-recipe.jar','dev/zomboid/firstaid', ['ichttt/mods/firstaid/common/RegistryObjects.class','ichttt/mods/firstaid/common/EventHandler.class','ichttt/mods/firstaid/client/ClientEventHandler.class']),('corpse',Path('attachments/da5d2869-15d5-46b5-922f-9b1fa6a47429/corpse-neoforge-1.21.1-1.1.13.jar'),'corpse-neoforge-1.21.1-1.1.13-player-storage-protection.1.jar',None,['de/maxhenkel/corpse/entities/CorpseEntity.class']),('iso',Path('attachments/2a6203cb-517d-4dfb-b5ec-796d7bf99107/dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.26-mounted-aim-side-zoom.jar'),'dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.27-pvp-cursor-roof-fix.jar','dev/zomboid/isotacz',['dev/zomboid/isotacz/CursorTarget.class']),('hordes',Path('work/playerzombie37/zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.37-player-zombie-inventory-guard.jar'),'zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.38-player-corpses-protected.jar','dev/zomboid/hordes',['dev/zomboid/hordes/ZoneReserve.class'])]
for kind,src,name,prefix,paths in items:
 changes={n:(p/'patched'/n).read_bytes() for n in paths}
 if prefix:
  for f in (p/'classes'/prefix).rglob('*.class'):changes[str(f.relative_to(p/'classes'))]=f.read_bytes()
 for f in (p/'resources'/kind).rglob('*'):
  if f.is_file():changes[str(f.relative_to(p/'resources'/kind))]=f.read_bytes()
 with zipfile.ZipFile(src) as z:
  n='META-INF/neoforge.mods.toml';txt=z.read(n).decode()
  if kind=='fa':txt=txt.replace('v3.5.7','v3.5.9').replace('v3.5.8','v3.5.9')
  if kind=='iso':txt=txt.replace('zomboid.22','zomboid.27').replace('zomboid.26','zomboid.27')
  if kind=='hordes':txt=txt.replace('admin-panel.37','admin-panel.38')
  changes[n]=txt.encode()
  if kind=='fa':
   for lang,translation in [('es_es','Cargas restantes: %s/%s'),('en_us','Charges remaining: %s/%s'),('de_de','Verbleibende Ladungen: %s/%s')]:
    n='assets/firstaid/lang/'+lang+'.json';data=json.loads(z.read(n));data['firstaid.defib.charges']=translation;changes[n]=json.dumps(data,ensure_ascii=False,indent=2).encode()
  dest=out/name
  with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as fixed:
   for info in z.infolist():
    if info.filename not in changes:fixed.writestr(copy.copy(info),z.read(info.filename))
   for n,b in changes.items():fixed.writestr(n,b)
  with zipfile.ZipFile(dest) as fixed:
   assert fixed.testzip() is None
   for n in z.namelist():
    if n not in changes:assert z.read(n)==fixed.read(n),(kind,n)
   assert not any(n.startswith('net/minecraft/') for n in fixed.namelist()),'MC stubs accidentally packaged'
 print(kind,len(changes),'entries changed')
# Includes the player inventory fallback already delivered; the log still uses admin.2.
old=Path('work/playerzombie37/The-Hordes-1.21.1-1.6.3f-zombies-mutants-admin.3-player-inventory-fallback.jar');copyto=out/old.name;copyto.write_bytes(old.read_bytes())
readme='''REPARACIONES DE REVIVIR, CADAVERES Y CAMARA — Minecraft 1.21.1 NeoForge

INSTALACION
Cierra Minecraft y el servidor. Sustituye las cinco familias de mods por los JAR de este paquete, sin versiones duplicadas:
1. FirstAid v3.5.8 (o anterior) -> v3.5.9.
2. Corpse 1.1.13 -> player-storage-protection.1.
3. dungeons_iso .26 -> .27.
4. Zomboid Hordes panel .35/.36/.37 -> .38.
5. The Hordes zombies-mutants-admin.2 -> admin.3-player-inventory-fallback.
Actualiza tambien la instancia del anfitrion/servidor. dungeons_iso es de cliente: no añadas mods de cliente a un dedicado donde antes no estaban. No cambies TaCZ, Tactical ni CarryOn con este paquete.

REVIVIR Y DESFIBRILADOR
El crash aportado señala ClickRevival -> R.call(send) -> NullPointerException. La solicitud de revivir usa ahora envio tipado, valida conexion, jugador local, objetivo vivo y mismo mundo. Un envio fallido no cierra el juego ni consume un uso.
El desfibrilador tiene cinco cargas. Se descuenta una por reanimacion completada, tanto propia como a un compañero; los intentos fallidos/interrumpidos no gastan. Creativo no gasta. La descripcion muestra las cargas restantes. Se reinicia el bloqueo de solicitud/progreso al entrar en una nueva caida y se conserva el flujo de uso normal y los cambios medicos de v3.5.8.
Reanimar vuelve a levantar al jugador y mantiene regeneracion II durante cinco segundos.

RECETA DE CURA ZOMBI
Resultado: 1 firstaid:zombie_cure_injector. Mesa de crafteo:
A A A
A B A
C H A
A = manzana de oro normal (seis unidades, no encantadas).
B = firstaid:prophylactic_antibiotic (una unidad).
C = polvo de blaze (una unidad).
H = botella de miel (una unidad).
La receta se descubre al obtener una manzana de oro. No cambia el antibiotico preventivo de heridas por la cura zombi: son objetos diferentes.

CADAVERES E INVENTARIO
Corpse ya no suelta su contenido por descargar el chunk o cambiar de dimension. El daño normal, fuego, explosiones y ataques no lo rompen. El temporizador de Corpse no elimina cuerpos con objetos; los vacios siguen su ciclo normal. La eliminacion destructiva explicita del administrador puede seguir retirando cuerpos y soltando sus objetos una vez.
Zomboid Hordes .38 excluye los cuerpos de jugadores de su limpieza y sus epocas de borrado, y conserva las protecciones del zombi del jugador de .37 y la prioridad del loot del panel de .36.
The Hordes admin.3 devuelve los objetos a los drops de muerte si otro mod rechaza la aparicion del zombi del jugador. Corpse puede recogerlos. No se obliga a otros mods a aceptar entidades.
Estos cambios previenen nuevas perdidas; no recuperan objetos que ya desaparecieron. Eso requiere un respaldo del mundo.

CAMARA ISOMETRICA
El cursor da prioridad a una entidad que el tirador puede ver desde sus ojos, aunque un techo cercano obstruya la camara. Un techo por encima del jugador no sustituye ese objetivo; sin objetivo se usa el plano corporal. Se conserva el bloqueo por paredes, los blancos elevados reales y las perspectivas/zoom/vehiculos de .26. La correccion se limita al selector de apuntado isometrico.

VALIDACION Y PRUEBA EN JUEGO
Verificacion de CRC y conservacion byte a byte de entradas no modificadas. ASM de seis clases parcheadas y nueve clases auxiliares. Pruebas con fixtures: conexion ausente/desconectada, solicitudes validas; cinco reanimaciones y cargas; rearme en cinco caidas; metodo de eliminacion del cadaver sin soltar objetos al descargar; cursor con techo, pared y blancos elevados. Receta verificada con seis manzanas exactas. No ejecutado dentro de Minecraft.
Prueba en una copia del mundo: reanimar cinco veces, alejarse de un cuerpo con objetos y volver, guardar/reabrir, golpear el cuerpo y apuntar a otro jugador en interiores. Si queda un fallo visual o de otro mod, aporta el log de esa prueba.
'''
(out/'LEEME.txt').write_text(readme)
bundle=p/'Zomboid-Revivir-Cadaveres-Isometrico-Defib5.1.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
 for f in out.iterdir():z.write(f,f.name)
with zipfile.ZipFile(bundle) as z:assert z.testzip() is None;assert len([n for n in z.namelist() if n.endswith('.jar')])==5
sources=p/'Zomboid-Reparaciones-Oct15-Fuentes-Pruebas.1.zip'
with zipfile.ZipFile(sources,'w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['src','resources','testsrc','cursortestsrc','defibtestsrc','corpsetestsrc','stubs']:
  for f in (p/folder).rglob('*'):
   if f.is_file():z.write(f,str(f.relative_to(p)))
 for name in ['build.py','Patch.java','DefibPatch.java','CorpseHarness.java']:z.write(p/name,name)
u=[]
for f,name in [(bundle,bundle.name),(sources,sources.name),(out/'LEEME.txt','Zomboid-Reparaciones-Oct15-LEEME.txt')]:
 b=f.read_bytes();u.append(dict(local=str(f),path='releases/'+name,sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
(p/'upload.json').write_text(json.dumps(u));print('PASS final ZIP:',bundle.stat().st_size,'bytes; 5 jars + instructions')
