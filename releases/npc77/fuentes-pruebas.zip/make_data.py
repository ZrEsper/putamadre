from pathlib import Path
import json
r=Path(__file__).parent;d=json.loads((r/'data/trust-original.json').read_text())
d['config']['pausa_lineas_ticks']=30
d['presentacion']={'separador':'────────────────────────────','pausa_respuesta_ticks':30,'relacion_cooldown_ticks':40,'emocion_cooldown_ticks':200,'colores':{'normal':'#CCCCCC','dar':'#77DD88','pedir':'#66CCEE','robo':'#DD6666','amenaza':'#CC7777','trueque':'#DDCC99','engaño':'#8899AA'},'etiquetas':{'normal':'Conversar','dar':'Entregar','pedir':'Pedir','robo':'Robar','amenaza':'Amenazar','trueque':'Intercambiar','engaño':'Engaño'}}
d['ui']['trust_improved']='MEJORÓ TU RELACIÓN CON'
d['refugios']={'activos':True,'intervalo_ticks':200,'accion_ticks':20,'radio_madera':10,'radio_grupo':12,'descanso_ticks':6000,'reintento_ticks':1200,'frio_bioma':0.25,'calor_bioma':1.5,'max_tiempo_trabajo_ticks':24000,'logs_por_arbol':5}
texts={
 'seco':{'traicion':['Confié en ti. Error mío.','Se acabó. Ya sé quién eres.'],'carino':['Me alegra verte. Ya.','Contigo puedo bajar la guardia un poco.'],'confusion':['Corta. ¿Qué estás haciendo?','Primero ayudas y luego amenazas. Decide.'],'ataque':['Mala idea. Muy mala idea.','Atrás. No vuelvas a hacerlo.']},
 'cansado':{'traicion':['…Mierda. Pensé que podía confiar en ti.','Después de todo, ¿vas a dispararme tú también?'],'carino':['…Bueno. Una cara que sí quería ver.','Contigo al menos puedo respirar un momento.'],'confusion':['Espera… ¿qué quieres de mí, entonces?','Me ayudas y luego me amenazas. No entiendo nada.'],'ataque':['¡Mierda! ¡No vuelvas a hacerlo!','Déjame en paz. Ya tengo suficiente.']},
 'sarcastico':{'traicion':['Genial. También tenía que cuidarme de ti.','Y yo pensando que éramos amigos. Qué sorpresa.'],'carino':['Vaya. Por una vez una visita que sí me alegra.','Te extrañé. No hagas que me arrepienta de decirlo.'],'confusion':['¿Ahora qué? ¿Amigos o blancos de tiro?','Qué detalle: regalos y amenazas en la misma visita.'],'ataque':['Qué buena manera de terminar una conversación.','¡Oye! ¡Guarda esa mierda!']},
 'religioso':{'traicion':['Te abrí mi puerta y elegiste hacerme daño.','Creí que podía confiar en ti, hermano.'],'carino':['Me alegra que hayas vuelto con bien.','Todavía queda bondad. La he visto en ti.'],'confusion':['No comprendo tus intenciones, hermano.','Tus actos y tus palabras no dicen lo mismo.'],'ataque':['Detente. No me obligues a responder.','Esa violencia no nos traerá nada bueno.']},
 'educado':{'traicion':['Le di mi confianza. Ahora veo que fue un error.','Después de mi ayuda, ¿así me responde?'],'carino':['Es un alivio volver a verlo.','Su compañía me hace bien. Gracias por volver.'],'confusion':['Disculpe, no entiendo qué pretende.','Me ofrece ayuda y luego me amenaza. Explíquese, por favor.'],'ataque':['¡Deténgase! No aceptaré otro ataque.','Aléjese. Se lo advierto.']},
 'aterrado':{'traicion':['P-pero… yo confiaba en ti.','¡No! ¡Tú no, por favor!'],'carino':['V-volviste. Qué alivio.','Contigo… siento un poco menos de miedo.'],'confusion':['N-no entiendo. ¿Vas a ayudarme o no?','Primero ayudas… luego amenazas. ¿P-por qué?'],'ataque':['¡No! ¡No me hagas daño!','¡Mierda, aléjate!']},
 'veterano':{'traicion':['Confié en ti. No voy a cometer ese error dos veces.','Escucha. Después de esto, nada será igual.'],'carino':['Me alegra tenerte cerca. Créeme.','Nos cuidamos la espalda. Eso vale mucho.'],'confusion':['Escucha. Tus señales no son claras.','Si quieres mi ayuda, deja de amenazarme.'],'ataque':['Detente. No habrá otra advertencia.','Así empiezan las cosas que luego nadie puede arreglar.']},
 'joven':{'traicion':['¡Carajo! ¡Yo confiaba en ti!','¿En serio? ¿Después de todo lo que hicimos?'],'carino':['Oye. Qué bueno que volviste.','Contigo sí me animo a salir de aquí.'],'confusion':['Oye, ¿qué te pasa? No te entiendo.','¿Me ayudas o me amenazas? ¡Decídete!'],'ataque':['¡Carajo, basta!','¡Oye! ¡Otro golpe y respondo!']}}
d['emociones']=texts
# Utility is explicit and editable; dynamic gift/search entries classify server-side too.
def utility(o):
 i=o['id'];tone=str(o['tono']);effects=[v['efectos']for v in o['respuestas']]
 if tone=='engaño':return 'engaño'
 if i=='aceptar_oferta':return 'trueque'
 if i in ['exigir','insistir','robar','quitar','exigir_cosas'] or i.startswith('registro_'):return 'robo'
 if any('da_item'in e and 'quita_item'in e for e in effects):return 'trueque'
 if any('quita_item'in e for e in effects) or i.startswith(('donar_','regalo_')):return 'dar'
 if any('da_item'in e for e in effects):return 'pedir'
 if tone in ['4','5']:return 'amenaza'
 if i in ['necesidad','equipo','nombre','origen','familia','destino','suministros','pedir_ayuda','preguntar']:return 'pedir'
 return 'normal'
for encounter in d['encuentros']:
 for node in encounter['nodos']:
  for o in node['opciones']:o['utilidad']=utility(o)
(r/'data/dialogue-phase2.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
