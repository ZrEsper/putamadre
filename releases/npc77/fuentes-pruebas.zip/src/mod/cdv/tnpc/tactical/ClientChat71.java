package mod.cdv.tnpc.tactical;
import com.google.gson.*;import java.util.*;import java.util.function.Consumer;
public final class ClientChat71 {
 static final List<Object> OPTIONS=new ArrayList<>(),DECORATIONS=new ArrayList<>();static String activeId;static long until;static Object owner;static boolean installed;static String hovered;
 static Object c(Object o,String m,Object...a){return Social.c(o,m,a);}
 static Object mc(){return c(Social.t("net.minecraft.client.Minecraft"),"getInstance");}
 static Object player(){return SocialR.get(mc(),"player");}
 static Object chat(){return c(SocialR.get(mc(),"gui"),"getChat");}
 static long now(){return ((Number)c(SocialR.get(mc(),"gui"),"getGuiTicks")).longValue();}
 static Object parse(JsonElement j){return c(Social.t("net.minecraft.network.chat.Component$Serializer"),"fromJson",j.toString(),c(player(),"registryAccess"));}
 static void refresh(){try{c(chat(),"refreshTrimmedMessage");}catch(Exception e){c(chat(),"rescaleChat");}}
 static void clear(){boolean changed=!OPTIONS.isEmpty()||!DECORATIONS.isEmpty();for(Object o:OPTIONS){Object style=c(o,"getStyle");style=c(style,"withClickEvent",(Object)null);style=c(style,"withHoverEvent",(Object)null);style=c(style,"withUnderlined",Boolean.FALSE);style=c(style,"withColor",0x666666);c(o,"setStyle",style);}if(changed)try{Set<Object> expired=Collections.newSetFromMap(new IdentityHashMap<>());expired.addAll(OPTIONS);expired.addAll(DECORATIONS);@SuppressWarnings("unchecked") List<Object> messages=(List<Object>)SocialR.get(chat(),"allMessages");messages.removeIf(m->expired.contains(c(m,"content")));}catch(Exception e){Social.warn("phase2.6 remove stale options",e);}OPTIONS.clear();DECORATIONS.clear();activeId=null;hovered=null;if(changed)refresh();}
 public static boolean receive(String text){if(!text.startsWith("C71\n"))return false;
  try{if(player()==null)return true;install();if(owner!=player()){clear();owner=player();}JsonObject j=JsonParser.parseString(text.substring(4)).getAsJsonObject();
   if(j.has("invalidate")&&Objects.equals(activeId,j.get("invalidate").getAsString()))clear();
   if(j.has("options")){clear();activeId=j.get("id").getAsString();until=now()+Math.max(0,Math.min(2400,j.get("remainingTicks").getAsLong()));}
   if(j.has("lines"))for(JsonElement line:j.getAsJsonArray("lines"))c(chat(),"addMessage",parse(line));
   if(j.has("xp")&&j.get("xp").getAsBoolean())Feedback77.xp();
   if(j.has("replyHeader")){Object header=parse(j.get("replyHeader"));DECORATIONS.add(header);c(chat(),"addMessage",header);}
   if(j.has("options"))for(JsonElement option:j.getAsJsonArray("options")){Object component=parse(option);OPTIONS.add(component);c(chat(),"addMessage",component);}return true;
  }catch(Exception e){Social.warn("phase2 client chat",e);return true;}}
 static void tick(Object event){try{if(owner!=player()||!OPTIONS.isEmpty()&&now()>=until){clear();owner=player();}}catch(Exception e){Social.warn("phase2 chat expiry",e);}}
 static String command(Object style){if(style==null)return null;Object click=c(style,"getClickEvent");return click==null?null:(String)c(click,"getValue");}
 static void hover(Object event){if(OPTIONS.isEmpty())return;try{Object screen=c(event,"getScreen");if(!Social.t("net.minecraft.client.gui.screens.ChatScreen").isInstance(screen)){setHover(null);return;}double x=((Number)c(event,"getMouseX")).doubleValue(),y=((Number)c(event,"getMouseY")).doubleValue();String selected=command(c(chat(),"getClickedComponentStyleAt",x,y));setHover(selected);}catch(Exception e){Social.warn("phase2 chat hover",e);}}
 static void setHover(String selected){if(Objects.equals(selected,hovered))return;hovered=selected;for(Object o:OPTIONS){Object style=c(o,"getStyle");boolean on=selected!=null&&selected.equals(command(style));c(o,"setStyle",c(style,"withUnderlined",Boolean.valueOf(on)));}refresh();}
 static void listen(Object bus,String cls,Consumer<Object> listener){Class<?> type=Social.t(cls);try{c(bus,"addListener",type,listener);}catch(Exception e){c(bus,"addListener",SocialR.get(Social.t("net.neoforged.bus.api.EventPriority"),"NORMAL"),false,type,listener);}}
 static void install(){if(installed)return;Object bus=SocialR.get(Social.t("net.neoforged.neoforge.common.NeoForge"),"EVENT_BUS");listen(bus,"net.neoforged.neoforge.client.event.ClientTickEvent$Post",ClientChat71::tick);listen(bus,"net.neoforged.neoforge.client.event.ScreenEvent$Render$Post",ClientChat71::hover);installed=true;}
}
