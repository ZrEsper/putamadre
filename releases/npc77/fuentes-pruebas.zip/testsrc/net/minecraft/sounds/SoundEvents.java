package net.minecraft.sounds;public class SoundEvents{public static final Object EXPERIENCE_ORB_PICKUP=new Object();}
