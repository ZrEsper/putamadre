package net.minecraft.world.item.crafting;public class RecipeType{public static final Object CRAFTING=new Object();}
