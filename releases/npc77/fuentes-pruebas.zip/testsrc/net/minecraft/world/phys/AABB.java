package net.minecraft.world.phys;public record AABB(double x,double y,double z,double maxX,double maxY,double maxZ){}
