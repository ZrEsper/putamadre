from pathlib import Path
import zipfile,json,hashlib
r=Path(__file__).parent;o=r/'release';base=Path('/workspace/npc76/release/tacznpcs-2.1.0-1.21.1-tactical.40-trust-gifts-motion.jar');jar=next(o.glob('*.jar'))
(o/'LEEME.txt').write_text('''TaCZ NPCs .41 — Chat por turnos, reacciones y refugios provisionales
Minecraft 1.21.1 / NeoForge. Reemplaza .40 en cliente y servidor. No mantengas ambos.

CHAT
Cada turno abre una línea horizontal, envía el mensaje del NPC y sus opciones,
muestra tu respuesta elegida y cierra la línea. Las opciones viejas siguen retirándose.
El siguiente bloque empieza tras la pausa. También se cierran los bloques al terminar,
interrumpir o suspender la conversación. Conversaciones y mensajes normales se conservan.
Hay una pausa mínima de 30 ticks (1,5 s a 20 TPS) entre líneas, después de la última
línea antes de habilitar opciones y después de tu respuesta antes de contestar el NPC.
El tiempo disponible para elegir empieza después de esa espera, no se pierde leyendo.
Default pausa_lineas_ticks=30. Un JSON personalizado puede conservar una pausa mayor.

Todas las opciones están en negrita. Colores por utilidad, independientes de tono:
robar rojo, entregar verde, pedir celeste, conversar gris, trueque dorado, engaño azul gris.
Campo opcional utilidad en cada opción: normal/dar/pedir/robo/amenaza/trueque/engaño.
El tono y sus efectos se mantienen: el color informa de la acción, no garantiza éxito.
Cuando aumenta la confianza: MEJORÓ TU RELACIÓN CON [nombre conocido o ???], negrita,
verde y sonido local de recoger XP. No da experiencia real ni revela nombres ocultos.
Límite de aviso para no superponer sonidos de varios efectos en el mismo instante.

REACCIONES
Bancos JSON para las ocho voces: traición, cariño, confusión y ataque.
Confianza alta habilita saludos/respuestas de afecto. Señales contradictorias generan
confusión. Un ataque de alguien en quien confiaba provoca una reacción de traición y
penalización adicional; un golpe leve con confianza intermedia puede causar confusión.
Esto no elimina la defensa ni el registro normal de ataques; no convierte los golpes
en un método gratuito de conversación. Memoria emocional temporal, persistida por
jugador. /npcdebug muestra emoción y estado de construcción. Las respuestas adicionales
respetan la cola, pausas, límite de líneas y no repetición del encuentro.

REFUGIOS: PRIMERA RUTINA FUNCIONAL
NPCs libres, sin propietario/orden de acompañamiento, sin combate, amenazas, cuidados
ni conversación, detectan exposición a frío, calor, lluvia o noche. Buscan suelo plano,
cargado y permitido. Un NPC dispone de interior 2x2; un grupo cercano compatible
(hasta cuatro, mismo tipo, sin enemistad registrada) comparte interior 4x4.
La huella exterior es mayor: paredes perimetrales, entrada abierta de dos bloques y
techo con alero. Roof 6x6/8x8 para cubrir el área 5x5 comprobada por Homeostatic en
cada casilla interior. Hay una sola mesa de crafteo; se coloca antes de levantar paredes.

Recoge troncos naturales vanilla accesibles, identificados por base de tierra y hojas;
no arrasa edificios. Balancea la mano al trabajar. Cada bloque retirado se convierte en
una unidad real en la bolsa, sin crear además un drop duplicado. Usa recetas reales
para troncos -> tablones y cuatro tablones -> mesa. Construye una pieza por acción,
consumiendo un tablón real por bloque. Los compañeros aportan madera que ya llevan.
No inventa materiales ni teletransporta al constructor. El progreso se guarda en NBT.
La navegación, alcance y línea de visión determinan si puede llegar a cada tarea.

Respeta mobGriefing, permisos de facciones existentes y eventos NeoForge de rotura y
colocación. Colocaciones canceladas restauran el bloque y conservan el objeto. No
reemplaza estructuras ni coloca bloques ocupados por entidades. Escaneos escalonados,
radio limitado, sitios reservados para evitar obras superpuestas y reintento con espera
si faltan madera, permisos o ruta. No carga chunks ni añade otro selector de objetivos.
Combate, conversación y órdenes del jugador tienen prioridad. Tras descansar vuelve
a sus rutinas; puede volver a usar el mismo refugio si se expone de nuevo al clima.
Las construcciones son bloques persistentes: no se borran automáticamente.

CLIMA Y LÍMITES
SereneSeasons: consulta su temperatura de bioma estacional si está instalado; sin él,
usa la temperatura del bioma vanilla. Umbrales editables en unidades de bioma, no °C.
Homeostatic adjunto fue revisado: su evaluación térmica principal requiere ServerPlayer.
No se llama con un NPC ni se le asigna una temperatura corporal ficticia. El techo real
busca cumplir su comprobación de cobertura; NO hay inmunidad al calor/frío, calefacción
ni aire acondicionado automáticos. No se han ejecutado ambos mods en Minecraft aquí.

Rutina inicial: casa fija sencilla de madera con entrada abierta, sin puerta automática,
cama, fuego, decoración, reparación, planos libres ni sociedad completa. Solo maderas
vanilla con logs/planks, terreno plano y árboles accesibles. No todos los NPCs construirán
inmediatamente. En terreno irregular o protegido pueden no encontrar sitio. NPCs
reclutados conservan sus órdenes. Los compañeros ayudan con recursos, el líder construye.

CONFIGURACIÓN
config/tacznpcs/dialogue-phase2.json. Original .40 migra con respaldo pre41.bak.json;
personalizados conservan textos y reciben secciones opcionales. /npcreload /npcvalidate.
Nuevas secciones: presentacion, emociones y refugios. refugios.activos=false desactiva
la rutina sin eliminar bloques ya construidos. /npcdebug muestra plan, avance y motivo
(por ejemplo sin_madera_cercana, ruta_no_disponible o mobGriefing/proteccion).

VERIFICACIÓN
176 clases verificadas ASM. JVM con APIs simuladas: 277 regresión, 15126 identidad y
emboscada, 124 memoria, 2249 charla abierta, 20368 .40 y 797 pruebas nuevas; 14 casos
independientes de configuración. Incluye prueba de NPC sin materiales que recoge,
craftea y completa el refugio, con navegación simulada. No es una prueba de Minecraft.
NO se ejecutó Minecraft real, GPU, NeoForge ni el modpack completo. PRUEBAS.md contiene
la lista pendiente. Fuentes y resultados reproducibles en fuentes-pruebas.zip.
''')
(o/'PRUEBAS.md').write_text('''Resultados automáticos: build-output.txt, test-output.txt, config-output.txt en fuentes-pruebas.zip.
APIs simuladas, no ejecución de Minecraft. La navegación del constructor se simula;
los trayectos reales y la integración visual/térmica siguen pendientes.

| Caso en Minecraft pendiente | Procedimiento | Resultado esperado |
|---|---|---|
| Ritmo | Hablar y elegir respuesta de inmediato | 1,5 s mínimo entre líneas y antes de la contestación; opciones esperan tras la última línea |
| Lectura | Completar tres turnos | Cada bloque abre línea, NPC, opciones, jugador y cierre; no se acumulan opciones viejas |
| Colores | Regalar, pedir, intimidar y hacer trueque | Verde/celeste/rojo/dorado; respuestas en negrita, hover conserva formato |
| Relación | Escuchar tema nuevo o dar regalo aceptado | Aviso verde en mayúsculas/negrita y sonido XP, sin dar XP real |
| Traición | Ganar confianza alta y atacar | Reacción propia de la voz, penalización y defensa normal; no se congela |
| Confusión/cariño | Relación alta o señales contradictorias | Respuestas contextuales, sin repetirlas en el mismo encuentro |
| Solo | NPC libre al aire libre, bosque cercano, frío o noche, terreno plano | Recoge madera, fabrica y coloca una mesa, construye interior 2x2 y se refugia |
| Grupo | Dos NPCs compatibles próximos sin dueño | Un plan compartido 4x4; aportes reales de madera, una mesa |
| Recursos | Dar pocos materiales, observar bolsa y árboles | Solo construye al disponer de materiales; cada colocación consume una unidad |
| Interrupción | Hablar, acercar amenaza o atacar durante obra | Conversación/defensa prevalecen; obra retoma después si es posible |
| Protección | mobGriefing false o claim ajeno | No destruye ni construye; diagnóstico explica bloqueo |
| Obstáculos | Ocupar la siguiente pieza o cancelar evento de colocación | No sobrescribe la estructura, no coloca sobre entidades ni pierde el material |
| Persistencia | Guardar y reiniciar durante obra | Recupera plan/avance y evita una segunda mesa/refugio |
| SereneSeasons | Cambiar estación en bioma templado | El sensor usa temperatura estacional, no una estación fija inventada |
| Homeostatic | Entrar bajo techo terminado en frío/calor | Comprobar cobertura real y efecto térmico del mod; no se promete inmunidad |
| Rendimiento | Muchos NPCs, terreno sin madera | Comprobaciones escalonadas; pausa de reintento, sin escaneo sin límite ni chunkload |

Limitaciones de esta entrega: planos fijos, acceso abierto, sin calentador/AC ni fisiología
completa del NPC. La simulación acredita lógica e inventarios, no pathfinding de Minecraft.
''')
(o/'dialogue-phase2.json').write_bytes((r/'data/dialogue-phase2.json').read_bytes())
a=zipfile.ZipFile(base);b=zipfile.ZipFile(jar)
assert all(a.read(n)==b.read(n)for n in a.namelist()if n.startswith('assets/'))
assert not any(n.startswith('net/minecraft/')for n in b.namelist())
manifest={'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'minecraft_run':False,'asm_classes':176,'regression_checks':277,'phase26_checks':15126,'phase3_checks':124,'open_checks':2249,'npc40_checks':20368,'new_checks':797,'config_cases':14,'changed':[n for n in a.namelist()if n in b.namelist()and a.read(n)!=b.read(n)],'added':sorted(set(b.namelist())-set(a.namelist()))}
(o/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(o/'CAMBIOS.txt').write_text('Base .40.\nAñadidos: Feedback77, Emotion77, Shelter77 y sus clases internas.\nModificados: Chat71 (colas, separadores, lectura y utilidad); ClientChat71 (sonido XP); Social74 (aviso al subir confianza, reacción ante daño); Reputation76 (evita avisos duplicados); Events76 (integración de trabajo en orders existente); Motion76 (evita expresiones competidoras durante trabajo); Free75 (limpia cachés al recargar); Ops74 (diagnóstico); DialogueData71/Config74/Data73 (validación/defaults/migración); JSON y metadatos.\nNo se sustituyen los JAR de Homeostatic ni SereneSeasons. Assets intactos.\nArchivos del JAR cambiados:\n'+'\n'.join(manifest['changed'])+'\nAñadidos:\n'+'\n'.join(manifest['added'])+'\n')
with zipfile.ZipFile(o/'fuentes-pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for name in ['Patch77.java','Extract70.java','Extract71.java','Extract73.java','build.py','test.py','config_test.py','make_data.py','package.py','build-output.txt','test-output.txt','config-output.txt']:z.write(r/name,name)
 for folder in ['src','testsrc','data','api']:
  for p in sorted((r/folder).rglob('*')):
   if p.is_file() and p.suffix in ['.java','.json']:z.write(p,p.relative_to(r))
 dep=Path('/workspace/npc71/brigadier-source')
 for p in (dep/'src/main/java').rglob('*.java'):z.write(p,'brigadier-source/'+str(p.relative_to(dep)))
 z.write(dep/'LICENSE','brigadier-source/LICENSE')
 z.writestr('REPRODUCIR.txt','Java21/Python3/ECJ/Gson/ASM/asm-tree/asm-analysis/asm-commons, base .40 exacta. build.py acepta NPC_BASE_JAR, NPC_BUILD_TOOLS, NPC_GSON_JAR; ajustar rutas de dependencias en test.py/config_test.py. Brigadier MIT incluido. Ejecutar make_data.py, build.py, test.py, config_test.py. api/ son declaraciones de compilación y no se incluyen en el JAR; testsrc/ son APIs simuladas, no Minecraft.')
archive='NPCs-41-Chat-Reacciones-Refugios.zip'
(o/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'for p in sorted(o.iterdir())if p.name not in [archive,'SHA256SUMS.txt']))
with zipfile.ZipFile(o/archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(o.iterdir()):
  if p.name!=archive:z.write(p,p.name)
print('SHA256',manifest['jar_sha256']);print('ZIP_BYTES',(o/archive).stat().st_size)
