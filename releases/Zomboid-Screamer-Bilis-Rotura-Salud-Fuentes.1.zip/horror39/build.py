from pathlib import Path
import zipfile,json,copy
p=Path('work/horror39');out=p/'release'
def build(src,dest,changes):
 with zipfile.ZipFile(src) as z:
  with zipfile.ZipFile(out/dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as w:
   for i in z.infolist():
    if i.filename not in changes:w.writestr(copy.copy(i),z.read(i.filename))
   for n,b in changes.items():w.writestr(n,b)
  with zipfile.ZipFile(out/dest) as w:
   assert w.testzip() is None
   assert not any(n.startswith(('net/minecraft/','net/neoforged/')) for n in w.namelist())
   for n in z.namelist():
    if n not in changes:assert z.read(n)==w.read(n),n
 print(dest,len(changes),'changed entries')
base=Path('attachments/bd33c192-b7cf-4caf-beab-0a72afe52895/zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.38-player-corpses-protected.jar')
changes={str(f.relative_to(Path('work/hordes39')/d)):f.read_bytes() for d in ['classes','patched'] for f in (Path('work/hordes39')/d).rglob('*.class')}
with zipfile.ZipFile(base) as z:changes['META-INF/neoforge.mods.toml']=z.read('META-INF/neoforge.mods.toml').replace(b'admin-panel.38',b'admin-panel.39')
build(base,'zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.39-breach-speed-screamer.jar',changes)
base=Path('attachments/5183914f-81d0-4c2a-a724-3331f4bca3e2/mutants-l4d2-addon-1.3.0-neoforge-1.21.1.jar')
changed={'MutantAddon','Screamers','HordeScent','Vomit','BoomerGoal','TerrainControl','Events','Combat','SpecialGoal','MutantStats','DeathBile','TankTerrain','SpitterVomit','SpitterEntityTerrain','ZombieBruteEntityTerrain','ScreamerClient'}
changes={str(f.relative_to('work/mutants14/classes')):f.read_bytes() for f in Path('work/mutants14/classes').rglob('*.class') if f.stem.split('$')[0] in changed}
with zipfile.ZipFile(base) as z:
 n='META-INF/neoforge.mods.toml';changes[n]=z.read(n).replace(b'version="1.3.0"',b'version="1.4.0"')
 n='mutants_l4d2.mixins.json';data=json.loads(z.read(n));data['mixins']+=['SpitterVomit','SpitterEntityTerrain','ZombieBruteEntityTerrain'];changes[n]=json.dumps(data,indent=2).encode()
 for lang in ['es_es','es_mx','en_us','de_de']:
  n=f'assets/mutants_l4d2/lang/{lang}.json';data=json.loads(z.read(n)) if n in z.namelist() else {};data.update(json.loads((Path('work/mutants14/resources')/n).read_text()));changes[n]=json.dumps(data,ensure_ascii=False,indent=2).encode()
for f in Path('work/mutants14/resources').rglob('*'):
 if f.is_file() and '/lang/' not in str(f):changes[str(f.relative_to('work/mutants14/resources'))]=f.read_bytes()
build(base,'mutants-l4d2-addon-1.4.0-neoforge-1.21.1-screamer-vomit-bile.jar',changes)
base=Path('work/ballistic360/firstaid-1.21.1-ZOMBOID-v3.6.0-ballistic-vital-downing.jar')
changes={str(f.relative_to('work/ballistic361/classes')):f.read_bytes() for f in Path('work/ballistic361/classes').rglob('*.class')}
with zipfile.ZipFile(base) as z:changes['META-INF/neoforge.mods.toml']=z.read('META-INF/neoforge.mods.toml').replace(b'v3.6.0',b'v3.6.1')
build(base,'firstaid-1.21.1-ZOMBOID-v3.6.1-head8-torso15.jar',changes)
