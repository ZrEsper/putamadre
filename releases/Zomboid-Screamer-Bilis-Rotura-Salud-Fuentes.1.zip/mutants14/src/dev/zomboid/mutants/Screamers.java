package dev.zomboid.mutants;
import net.minecraft.world.entity.*;import net.minecraft.world.entity.ai.attributes.*;import net.minecraft.world.entity.monster.Zombie;import net.minecraft.world.entity.player.Player;import net.minecraft.world.level.Level;import net.minecraft.server.level.ServerLevel;import net.neoforged.neoforge.registries.*;import net.neoforged.bus.api.*;import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
@net.neoforged.fml.common.EventBusSubscriber(modid=MutantAddon.ID)
public final class Screamers {
 public static final DeferredRegister<EntityType<?>> TYPES=DeferredRegister.create(net.minecraft.core.registries.Registries.ENTITY_TYPE,MutantAddon.ID);
 public static final DeferredHolder<EntityType<?>,EntityType<Screamer>> TYPE=TYPES.register("screamer",()->EntityType.Builder.of(Screamer::new,MobCategory.MONSTER).sized(.55f,2.65f).clientTrackingRange(10).build("mutants_l4d2:screamer"));
 public static void register(IEventBus bus){TYPES.register(bus);bus.addListener(Screamers::attributes);}
 public static void attributes(EntityAttributeCreationEvent e){e.put(TYPE.get(),Zombie.createAttributes().add(Attributes.MAX_HEALTH,48).add(Attributes.MOVEMENT_SPEED,.36).add(Attributes.FOLLOW_RANGE,64).add(Attributes.ATTACK_DAMAGE,0).build());}
 public static double chance(){try{var getter=Class.forName("dev.zomboid.hordes.WorldTuning").getMethod("get",String.class);if(((Number)getter.invoke(null,"mutantes")).doubleValue()<=0)return 0;return ((Number)getter.invoke(null,"screamer_probabilidad")).doubleValue()/100;}catch(ReflectiveOperationException|LinkageError e){return .01;}}
 @SubscribeEvent public static void fresh(net.neoforged.neoforge.event.entity.living.FinalizeSpawnEvent e){if(e.getEntity().getClass()==Zombie.class&&(e.getSpawnType()==MobSpawnType.NATURAL||e.getSpawnType()==MobSpawnType.CHUNK_GENERATION))e.getEntity().getPersistentData().putBoolean("l4d_screamer_fresh",true);}
 @SubscribeEvent public static void naturalTick(net.neoforged.neoforge.event.tick.EntityTickEvent.Post e){if(!(e.getEntity().level() instanceof ServerLevel l)||e.getEntity().getClass()!=Zombie.class)return;Zombie z=(Zombie)e.getEntity();if(z.tickCount!=1)return;boolean fresh=z.getPersistentData().getBoolean("l4d_screamer_fresh");z.getPersistentData().remove("l4d_screamer_fresh");if(!fresh)return;for(var item:z.getHandSlots())if(!item.isEmpty())return;for(var item:z.getArmorSlots())if(!item.isEmpty())return;if(z.getHealth()<z.getMaxHealth())return;if(z.isBaby()||z.hasCustomName()||z.isPersistenceRequired()||l.getRandom().nextDouble()>=chance())return;int cap=2;try{cap=((Number)Class.forName("dev.zomboid.hordes.WorldTuning").getMethod("mutantCap").invoke(null)).intValue();}catch(ReflectiveOperationException|LinkageError ignored){}int count=0;for(Mob m:l.getEntitiesOfClass(Mob.class,z.getBoundingBox().inflate(128))){if(m.isAlive()&&(m instanceof Screamer||m.getType().getDescriptionId().startsWith("entity.mutantszombies.")))count++;}if(count>=cap)return;Screamer s=TYPE.get().create(l);if(s==null)return;s.moveTo(z.getX(),z.getY(),z.getZ(),z.getYRot(),0);if(!l.noCollision(s)||l.containsAnyLiquid(s.getBoundingBox()))return;if(l.addFreshEntity(s))z.discard();}
 public static final class Screamer extends Zombie {
  private long nextCry,nextSearch,nextPath;private int unseen;
  public Screamer(EntityType<? extends Zombie> type,Level level){super(type,level);}
  @Override protected void registerGoals(){goalSelector.addGoal(0,new net.minecraft.world.entity.ai.goal.FloatGoal(this));}
  @Override protected boolean isSunSensitive(){return false;}
  @Override public boolean doHurtTarget(Entity e){return false;}
  @Override public void tick(){super.tick();if(!(level() instanceof ServerLevel l)||!isAlive())return;long now=l.getGameTime();LivingEntity t=getTarget();if(!Combat.valid(t)||t.level()!=l||distanceToSqr(t)>96*96||unseen>200){setTarget(null);t=null;unseen=0;}
   if(t==null&&now>=nextSearch){nextSearch=now+20;double best=48*48;for(Player p:l.players()){double d=distanceToSqr(p);if(Combat.valid(p)&&d<best&&hasLineOfSight(p)){t=p;best=d;}}setTarget(t);}
   setAggressive(t!=null);if(t==null){getNavigation().stop();return;}unseen=hasLineOfSight(t)?0:unseen+1;getLookControl().setLookAt(t,60,60);if(now>=nextPath){nextPath=now+10;if(distanceToSqr(t)>9)getNavigation().moveTo(t,1.2);else getNavigation().stop();}
   if(now>=nextCry){nextCry=now+80;playSound(net.minecraft.sounds.SoundEvents.GHAST_SCREAM,2.5f,.65f);HordeScent.alert(l,t,96);}
  }
 }
}
