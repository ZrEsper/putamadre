package dev.zomboid.mutants;
import java.util.*;
public final class Signals {
 public record Pose(int phase,long start,int duration){}
 private static final Map<UUID,Pose> POSES=new LinkedHashMap<>();
 public static void accept(String body){try{String[] a=body.split(",",4);UUID id=UUID.fromString(a[0]);int phase=Integer.parseInt(a[1]),duration=Integer.parseInt(a[3]);long start=Long.parseLong(a[2]);if(phase<0||phase>11||duration<0||duration>600)return;if(POSES.size()>=2048&&!POSES.containsKey(id))POSES.remove(POSES.keySet().iterator().next());POSES.put(id,new Pose(phase,start,duration));}catch(RuntimeException ignored){}}
 public static Pose get(UUID id){return POSES.get(id);}public static void clear(){POSES.clear();}
}
