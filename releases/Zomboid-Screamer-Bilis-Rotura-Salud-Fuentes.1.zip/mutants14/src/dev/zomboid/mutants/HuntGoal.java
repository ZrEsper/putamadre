package dev.zomboid.mutants;
import net.minecraft.world.entity.*;import net.minecraft.world.entity.player.Player;import net.minecraft.world.entity.ai.goal.Goal;import java.util.EnumSet;
/** Deterministic acquisition and persistent pursuit, without seeing through walls. */
public final class HuntGoal extends Goal {
 private final Mob mob;private LivingEntity target;private long scan;private int unseen;
 public HuntGoal(Mob m){mob=m;setFlags(EnumSet.of(Flag.TARGET));}
 public boolean canUse(){long now=mob.level().getGameTime();if(now<scan)return false;scan=now+5;target=null;double best=48*48;for(Player p:mob.level().getEntitiesOfClass(Player.class,mob.getBoundingBox().inflate(48))){double d=mob.distanceToSqr(p);if(Combat.valid(p)&&d<best&&mob.hasLineOfSight(p)){best=d;target=p;}}return target!=null;}
 public boolean canContinueToUse(){return Combat.valid(target)&&mob.distanceToSqr(target)<=64*64&&unseen<240;}
 public boolean requiresUpdateEveryTick(){return true;}
 public void start(){unseen=0;mob.setTarget(target);}
 public void tick(){unseen=mob.hasLineOfSight(target)?0:unseen+1;mob.setTarget(target);}
 public void stop(){if(mob.getTarget()==target)mob.setTarget(null);target=null;}
}
