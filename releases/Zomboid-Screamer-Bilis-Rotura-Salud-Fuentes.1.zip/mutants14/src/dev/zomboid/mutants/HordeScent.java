package dev.zomboid.mutants;
import net.minecraft.world.entity.*;import net.minecraft.server.level.ServerLevel;
public final class HordeScent {
 public static void alert(ServerLevel l,LivingEntity target,double radius){if(!Combat.valid(target))return;try{Class.forName("dev.zomboid.hordes.EventAttraction").getMethod("alert",Object.class,Object.class,double.class,long.class,boolean.class).invoke(null,l,target,radius,l.getGameTime(),false);}catch(ReflectiveOperationException|LinkageError ignored){}
 int n=0;for(Mob m:l.getEntitiesOfClass(Mob.class,target.getBoundingBox().inflate(radius))){if(n>=32)break;if(!m.isAlive()||m==target||m instanceof Screamers.Screamer||!Combat.infected(m)||m.distanceToSqr(target)>radius*radius)continue;m.setTarget(target);m.getPersistentData().putLong("zh_siege_seen",l.getGameTime());n++;}
 }
}
