package dev.zomboid.mutants;
import net.minecraft.world.entity.Entity;import net.minecraft.sounds.*;
public final class AbilitySounds {
 public static void play(Entity e,String id,float volume,float pitch){SoundEvent sound=net.minecraft.core.registries.BuiltInRegistries.SOUND_EVENT.get(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("minecraft",id));if(sound==null)return;e.level().playSound(null,e.getX(),e.getY(),e.getZ(),sound,SoundSource.HOSTILE,volume,pitch);}
 public static void charge(Entity e){play(e,"entity.ravager.roar",1.4f,.7f);}
 public static void slam(Entity e){play(e,"entity.generic.explode",1,.6f);}
 public static void tongue(Entity e){play(e,"entity.slime.attack",.9f,.65f);}
 public static void cut(Entity e){play(e,"entity.sheep.shear",.8f,.7f);}
 public static void stone(Entity e){play(e,"block.stone.hit",1.1f,.65f);}
}
