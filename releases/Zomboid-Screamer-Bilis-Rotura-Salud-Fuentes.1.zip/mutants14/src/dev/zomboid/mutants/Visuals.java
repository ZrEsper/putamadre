package dev.zomboid.mutants;
import java.util.*;import net.minecraft.world.entity.*;import net.minecraft.server.level.ServerLevel;import net.minecraft.world.phys.Vec3;
/** Native display/interaction entities: synchronized and rendered by Minecraft itself. */
public final class Visuals {
 private static final Map<UUID,java.lang.ref.WeakReference<Entity>> ACTIVE=new HashMap<>();
 public static Entity create(ServerLevel l,boolean hitbox){Entity e=(hitbox?EntityType.INTERACTION:EntityType.BLOCK_DISPLAY).create(l);if(e!=null){ACTIVE.put(e.getUUID(),new java.lang.ref.WeakReference<>(e));e.getPersistentData().putBoolean("l4d_visual",true);}return e;}
 public static void configure(Entity e,String tag){try{e.load(net.minecraft.nbt.TagParser.parseTag(tag));e.getPersistentData().putBoolean("l4d_visual",true);}catch(Exception ex){throw new IllegalStateException("Invalid native ability display data",ex);}}
 public static void discard(Entity e){if(e!=null){ACTIVE.remove(e.getUUID());e.discard();}}
 public static boolean stale(Entity e){return e.getPersistentData().getBoolean("l4d_visual")&&(ACTIVE.get(e.getUUID())==null||ACTIVE.get(e.getUUID()).get()!=e);}
 public static boolean active(UUID id){var r=ACTIVE.get(id);return r!=null&&r.get()!=null&&!r.get().isRemoved();}
 public static void clean(){ACTIVE.entrySet().removeIf(e->e.getValue().get()==null||e.getValue().get().isRemoved());}
 public static String display(String block,Vec3 pos,double sx,double sy,double sz,double qx,double qy,double qz,double qw){return String.format(Locale.ROOT,"{Pos:[%.6fd,%.6fd,%.6fd],NoGravity:1b,Silent:1b,Invulnerable:1b,block_state:{Name:\"%s\"},transformation:{translation:[%.6ff,%.6ff,%.6ff],scale:[%.6ff,%.6ff,%.6ff],left_rotation:[%.6ff,%.6ff,%.6ff,%.6ff],right_rotation:[0f,0f,0f,1f]},teleport_duration:1,interpolation_duration:1,start_interpolation:0,view_range:2f,shadow_radius:0f,shadow_strength:0f}",pos.x,pos.y,pos.z,block,-sx/2,-sy/2,block.equals("minecraft:red_terracotta")?0:-sz/2,sx,sy,sz,qx,qy,qz,qw);}
 public static void move(Entity e,Vec3 p){e.moveTo(p.x,p.y,p.z,0,0);}
}
