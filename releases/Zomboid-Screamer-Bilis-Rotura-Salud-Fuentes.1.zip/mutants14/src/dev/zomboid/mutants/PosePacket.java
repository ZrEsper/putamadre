package dev.zomboid.mutants;
import net.minecraft.network.*;import net.minecraft.network.codec.StreamCodec;import net.minecraft.network.protocol.common.custom.CustomPacketPayload;import net.minecraft.resources.ResourceLocation;
public record PosePacket(String body) implements CustomPacketPayload {
 public static final Type<PosePacket> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath(MutantAddon.ID,"pose"));
 public static final StreamCodec<RegistryFriendlyByteBuf,PosePacket> CODEC=StreamCodec.of((b,p)->b.writeUtf(p.body()),b->new PosePacket(b.readUtf()));
 public Type<PosePacket> type(){return TYPE;}
 public static void register(net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent event){event.registrar("1").playToClient(TYPE,CODEC,(p,c)->c.enqueueWork(()->Signals.accept(p.body())));}
}
