package dev.zomboid.mutants;
import net.minecraft.world.entity.*;import net.minecraft.world.entity.player.Player;import net.minecraft.world.entity.ai.goal.Goal;import java.util.EnumSet;
public final class BileTargetGoal extends Goal {
 private final Mob mob;private LivingEntity scent;private long nextScan;
 public BileTargetGoal(Mob m){mob=m;setFlags(EnumSet.of(Flag.TARGET));}
 public boolean canUse(){long now=mob.level().getGameTime();if(now<nextScan)return false;nextScan=now+20;scent=null;double best=Rules.SCENT_RADIUS*Rules.SCENT_RADIUS;for(LivingEntity p:mob.level().getEntitiesOfClass(LivingEntity.class,mob.getBoundingBox().inflate(Rules.SCENT_RADIUS))){double d=mob.distanceToSqr(p);if((p instanceof Player||Bandits.is(p))&&Combat.valid(p)&&p.hasEffect(MutantAddon.BILE)&&d<best){best=d;scent=p;}}return scent!=null;}
 public boolean canContinueToUse(){return Combat.valid(scent)&&scent.hasEffect(MutantAddon.BILE)&&mob.distanceToSqr(scent)<Rules.SCENT_RADIUS*Rules.SCENT_RADIUS;}
 public boolean requiresUpdateEveryTick(){return true;}
 public void start(){mob.setTarget(scent);}
 public void tick(){if(mob.tickCount%10==0){mob.setTarget(scent);if(mob.distanceToSqr(scent)>4)mob.getNavigation().moveTo(scent,1);}}
 public void stop(){if(mob.getTarget()==scent)mob.setTarget(null);scent=null;}
}
