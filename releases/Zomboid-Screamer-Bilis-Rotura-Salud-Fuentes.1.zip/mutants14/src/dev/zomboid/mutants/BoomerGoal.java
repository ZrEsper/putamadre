package dev.zomboid.mutants;
import java.util.EnumSet;import net.minecraft.world.entity.*;import net.minecraft.world.entity.ai.goal.Goal;
public final class BoomerGoal extends Goal {
 private final Mob mob;private long next,started;private int burst;
 public BoomerGoal(Mob m){mob=m;setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
 public boolean canUse(){return Combat.valid(mob.getTarget());}public boolean canContinueToUse(){return canUse();}public boolean requiresUpdateEveryTick(){return true;}
 public void tick(){var t=mob.getTarget();if(!Combat.valid(t))return;long now=mob.level().getGameTime();mob.getLookControl().setLookAt(t,45,45);if(mob.distanceToSqr(t)>16||!mob.hasLineOfSight(t)){if(now%10==0)mob.getNavigation().moveTo(t,1.1);return;}mob.getNavigation().stop();if(now>=next&&burst==0){burst=1;started=now;next=now+120;mob.playSound(net.minecraft.sounds.SoundEvents.GENERIC_DRINK,1,.6f);net.neoforged.neoforge.network.PacketDistributor.sendToPlayersTrackingEntity(mob,new PosePacket(mob.getUUID()+","+Rules.SPIT+","+now+",24"));}if(burst>0){long age=now-started;if(age==6||age==12||age==18)Vomit.cast(mob,t,true);if(age>=24)burst=0;}}
 public void stop(){burst=0;}
}
