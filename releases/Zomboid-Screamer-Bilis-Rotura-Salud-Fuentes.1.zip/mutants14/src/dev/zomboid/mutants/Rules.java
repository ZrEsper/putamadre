package dev.zomboid.mutants;
public final class Rules {
 public static final int IDLE=0,WINDUP=1,CHARGE=2,STUN=3,THROW=4,RECOVER=5,POUNCE=6,FURY=7,SMASH=8,SPIT=9,TETHER=10,LUNGE=11;
 public static final int BILE_TICKS=400;public static final double SCENT_RADIUS=48;
 public static boolean startles(boolean crouching,double distanceSquared,boolean visible){return visible&&distanceSquared<(crouching?1.25*1.25:4*4);}
 public static boolean escaped(double distanceSquared,int unseenTicks,boolean alive){return !alive||distanceSquared>48*48||unseenTicks>=200;}
 public static float progress(long now,long start,int duration){return duration<=0?0:Math.max(0,Math.min(1,(now-start)/(float)duration));}
 public static double rockLift(double horizontalDistance,double speed){double ticks=horizontalDistance/speed;return .5*.03*ticks*ticks;}
 public static double heightAt(double distance,double speed,double pitch,double gravity){double vx=speed*Math.cos(pitch),vy=speed*Math.sin(pitch),x=0,y=0;for(int i=0;i<120;i++){double oldX=x,oldY=y;x+=vx;y+=vy;if(x>=distance)return oldY+(y-oldY)*(distance-oldX)/(x-oldX);vx*=.99;vy=vy*.99-gravity;}return Double.NEGATIVE_INFINITY;}
 public static double trajectoryRise(double distance,double height,double speed,double gravity){if(distance<.01)return height;double low=-1.1,previous=heightAt(distance,speed,low,gravity)-height;for(double high=-1.0;high<=.91;high+=.1){double value=heightAt(distance,speed,high,gravity)-height;if(previous<=0&&value>=0){double upper=high;for(int j=0;j<24;j++){double mid=(low+upper)/2;if(heightAt(distance,speed,mid,gravity)<height)low=mid;else upper=mid;}return distance*Math.tan((low+upper)/2);}low=high;previous=value;}return height+rockLift(distance,speed);}
 public static boolean waveDue(int ticksLeft,int waveCount,long now,long next){return ticksLeft>0&&waveCount<3&&now>=next;}
}
