package dev.zomboid.mutants;
import net.minecraft.world.entity.*;import net.minecraft.world.entity.ai.goal.Goal;import java.util.EnumSet;
public final class BanditTargetGoal extends Goal {
 private final Mob mob;private LivingEntity target;private long nextScan;private int unseen;
 public BanditTargetGoal(Mob m){mob=m;setFlags(EnumSet.of(Flag.TARGET));}
 public boolean canUse(){long now=mob.level().getGameTime();if(now<nextScan)return false;nextScan=now+20;target=null;double best=32*32;for(LivingEntity e:mob.level().getEntitiesOfClass(LivingEntity.class,mob.getBoundingBox().inflate(32))){double d=mob.distanceToSqr(e);if(Combat.valid(e)&&Bandits.is(e)&&d<best&&mob.hasLineOfSight(e)){best=d;target=e;}}return target!=null;}
 public boolean canContinueToUse(){return Combat.valid(target)&&Bandits.is(target)&&mob.distanceToSqr(target)<=40*40&&unseen<100;}
 public boolean requiresUpdateEveryTick(){return true;}
 public void start(){unseen=0;mob.setTarget(target);}
 public void tick(){unseen=mob.hasLineOfSight(target)?0:unseen+1;mob.setTarget(target);}
 public void stop(){if(mob.getTarget()==target)mob.setTarget(null);target=null;unseen=0;}
}
