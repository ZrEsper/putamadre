package dev.zomboid.mutants.mixin;
@org.spongepowered.asm.mixin.Mixin(targets="net.petemc.mutantszombies.entity.MutantBruteEntity",remap=false)
public abstract class TankTerrain {
 @org.spongepowered.asm.mixin.injection.Redirect(method="tick()V",at=@org.spongepowered.asm.mixin.injection.At(value="INVOKE",target="Lnet/petemc/mutantszombies/config/Config;getMutantBrutesBreakLogsAndLeavesAroundThem()Z"),require=1,remap=false)
 private boolean mutants$collision(){var goal=dev.zomboid.mutants.Events.goal((net.minecraft.world.entity.Mob)(Object)this);return (goal==null||goal.phase==dev.zomboid.mutants.Rules.IDLE)&&dev.zomboid.mutants.TerrainControl.nativeBreak(net.petemc.mutantszombies.config.Config.getMutantBrutesBreakLogsAndLeavesAroundThem());}
}
