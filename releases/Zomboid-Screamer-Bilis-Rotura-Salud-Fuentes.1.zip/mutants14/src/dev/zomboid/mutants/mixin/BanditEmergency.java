package dev.zomboid.mutants.mixin;
@org.spongepowered.asm.mixin.Pseudo
@org.spongepowered.asm.mixin.Mixin(targets="mod.cdv.tnpc.tactical.NightCombat",remap=false)
public abstract class BanditEmergency {
 @org.spongepowered.asm.mixin.injection.Inject(method="emergency(Ljava/lang/Object;)V",at=@org.spongepowered.asm.mixin.injection.At("TAIL"),require=1,remap=false)
 private static void mutants$priority(Object entity,org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci){if(entity instanceof net.minecraft.world.entity.Mob mob)dev.zomboid.mutants.BanditCombat.tick(mob);}
}
