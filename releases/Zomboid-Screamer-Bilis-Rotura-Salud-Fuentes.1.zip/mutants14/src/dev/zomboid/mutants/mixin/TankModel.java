package dev.zomboid.mutants.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;import net.minecraft.client.model.geom.ModelPart;import net.petemc.mutantszombies.entity.MutantBruteEntity;
@Mixin(targets="net.petemc.mutantszombies.client.model.MutantBruteModel",remap=false)
public abstract class TankModel {
 @Shadow @Final private ModelPart head;@Shadow @Final private ModelPart torso;@Shadow @Final private ModelPart right_arm;@Shadow @Final private ModelPart left_arm;
 @Inject(method="setupAnim(Lnet/petemc/mutantszombies/entity/MutantBruteEntity;FFFFF)V",at=@At("HEAD"),require=1,remap=false)
 private void mutants$reset(MutantBruteEntity e,float a,float b,float c,float d,float f,CallbackInfo ci){torso.resetPose();}
 @Inject(method="setupAnim(Lnet/petemc/mutantszombies/entity/MutantBruteEntity;FFFFF)V",at=@At("TAIL"),require=1,remap=false)
 private void mutants$attack(MutantBruteEntity e,float a,float b,float age,float d,float f,CallbackInfo ci){dev.zomboid.mutants.client.Animation.heavyWalk(e,a,b,age,torso);dev.zomboid.mutants.client.Animation.tank(e,age,head,torso,right_arm,left_arm);}
}
