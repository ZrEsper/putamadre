package dev.zomboid.mutants.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;import net.minecraft.client.model.geom.ModelPart;import net.petemc.mutantszombies.entity.CrawlerEntity;
@Mixin(targets="net.petemc.mutantszombies.client.model.CrawlerModel",remap=false)
public abstract class CrawlerModel {
 @Shadow @Final public ModelPart head;
 @Shadow @Final public ModelPart torso;
 @Shadow @Final public ModelPart right_arm;
 @Shadow @Final public ModelPart left_arm;
 @Inject(method="setupAnim(Lnet/petemc/mutantszombies/entity/CrawlerEntity;FFFFF)V",at=@At("HEAD"),require=1,remap=false)
 private void mutants$reset(CrawlerEntity e,float a,float b,float age,float d,float f,CallbackInfo ci){head.resetPose();torso.resetPose();right_arm.resetPose();left_arm.resetPose();}
 @Inject(method="setupAnim(Lnet/petemc/mutantszombies/entity/CrawlerEntity;FFFFF)V",at=@At("TAIL"),require=1,remap=false)
 private void mutants$pose(CrawlerEntity e,float a,float b,float age,float d,float f,CallbackInfo ci){dev.zomboid.mutants.client.Animation.infected(e,a,b,age,head,torso,right_arm,left_arm,2);}
}
