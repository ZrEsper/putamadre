package dev.zomboid.mutants.mixin;
@org.spongepowered.asm.mixin.Mixin(targets="net.minecraft.world.entity.Mob",remap=false)
public interface MobGoals {
 @org.spongepowered.asm.mixin.gen.Accessor("goalSelector") net.minecraft.world.entity.ai.goal.GoalSelector mutants$goals();
 @org.spongepowered.asm.mixin.gen.Accessor("targetSelector") net.minecraft.world.entity.ai.goal.GoalSelector mutants$targets();
}
