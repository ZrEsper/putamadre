package dev.zomboid.mutants.mixin;
@org.spongepowered.asm.mixin.Pseudo
@org.spongepowered.asm.mixin.Mixin(targets="mod.cdv.tnpc.entity.AutoGunOperator",remap=false)
public abstract class BanditNPC {
 @org.spongepowered.asm.mixin.injection.Inject(method="tick()V",at={@org.spongepowered.asm.mixin.injection.At("HEAD"),@org.spongepowered.asm.mixin.injection.At("TAIL")},require=1,remap=false)
 private void mutants$threats(org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci){dev.zomboid.mutants.BanditCombat.tick((net.minecraft.world.entity.Mob)(Object)this);}
 @org.spongepowered.asm.mixin.injection.Inject(method="isOpposedTo(Lnet/minecraft/world/entity/LivingEntity;)Z",at=@org.spongepowered.asm.mixin.injection.At("HEAD"),cancellable=true,require=1,remap=false)
 private void mutants$hostility(net.minecraft.world.entity.LivingEntity target,org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Boolean> ci){if(dev.zomboid.mutants.Bandits.is((net.minecraft.world.entity.Mob)(Object)this)&&dev.zomboid.mutants.BanditCombat.mutant(target))ci.setReturnValue(!dev.zomboid.mutants.BanditCombat.calmWitch((net.minecraft.world.entity.Mob)target));}
}
