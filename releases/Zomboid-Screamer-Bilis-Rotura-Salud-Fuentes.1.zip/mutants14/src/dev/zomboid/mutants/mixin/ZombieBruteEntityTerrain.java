package dev.zomboid.mutants.mixin;
@org.spongepowered.asm.mixin.Mixin(targets="net.petemc.mutantszombies.entity.ZombieBruteEntity",remap=false)
public abstract class ZombieBruteEntityTerrain {
 @org.spongepowered.asm.mixin.injection.Redirect(method="tick()V",at=@org.spongepowered.asm.mixin.injection.At(value="INVOKE",target="Lnet/petemc/mutantszombies/config/Config;getZombieBrutesBreakLogsAndLeavesAroundThem()Z"),require=1,remap=false)
 private boolean mutants$terrain(){return dev.zomboid.mutants.TerrainControl.nativeBreak(net.petemc.mutantszombies.config.Config.getZombieBrutesBreakLogsAndLeavesAroundThem());}}
