package dev.zomboid.mutants.mixin;
@org.spongepowered.asm.mixin.Mixin(targets="net.petemc.mutantszombies.entity.SpitterEntity",remap=false)
public abstract class SpitterVomit {
 @org.spongepowered.asm.mixin.injection.Inject(method="performRangedAttack(Lnet/minecraft/world/entity/LivingEntity;F)V",at=@org.spongepowered.asm.mixin.injection.At("HEAD"),cancellable=true,require=1,remap=false)
 private void mutants$vomit(net.minecraft.world.entity.LivingEntity t,float f,org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci){var m=(net.minecraft.world.entity.Mob)(Object)this;long now=m.level().getGameTime();if(!m.level().isClientSide&&now>=m.getPersistentData().getLong("l4d_external_vomit")){m.getPersistentData().putLong("l4d_external_vomit",now+80);dev.zomboid.mutants.Vomit.cast(m,t,false);}ci.cancel();}
}
