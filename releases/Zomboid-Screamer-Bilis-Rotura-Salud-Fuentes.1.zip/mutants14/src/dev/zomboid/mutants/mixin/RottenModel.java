package dev.zomboid.mutants.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;import net.minecraft.client.model.geom.ModelPart;import net.minecraft.world.entity.Entity;
@Mixin(targets="net.petemc.mutantszombies.client.model.RottenMutantModel",remap=false)
public abstract class RottenModel {
 @Shadow @Final private ModelPart head;
 @Shadow @Final private ModelPart torso;
 @Shadow @Final private ModelPart right_arm;
 @Shadow @Final private ModelPart left_arm;
 @Inject(method="setupAnim(Lnet/minecraft/world/entity/Entity;FFFFF)V",at=@At("HEAD"),require=1,remap=false)
 private void mutants$reset(Entity e,float a,float b,float age,float d,float f,CallbackInfo ci){head.resetPose();torso.resetPose();right_arm.resetPose();left_arm.resetPose();}
 @Inject(method="setupAnim(Lnet/minecraft/world/entity/Entity;FFFFF)V",at=@At("TAIL"),require=1,remap=false)
 private void mutants$pose(Entity e,float a,float b,float age,float d,float f,CallbackInfo ci){dev.zomboid.mutants.client.Animation.infected(e,a,b,age,head,torso,right_arm,left_arm,4);}
}
