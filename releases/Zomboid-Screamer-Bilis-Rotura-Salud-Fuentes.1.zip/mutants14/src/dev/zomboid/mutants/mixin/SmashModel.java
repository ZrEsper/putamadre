package dev.zomboid.mutants.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;import net.minecraft.client.model.geom.ModelPart;import net.petemc.mutantszombies.entity.ZombieBruteEntity;
@Mixin(targets="net.petemc.mutantszombies.client.model.ZombieBruteModel",remap=false)
public abstract class SmashModel {
 @Shadow @Final public ModelPart torso;@Shadow @Final public ModelPart right_arm;@Shadow @Final public ModelPart left_arm;
 @Inject(method="setupAnim(Lnet/petemc/mutantszombies/entity/ZombieBruteEntity;FFFFF)V",at=@At("HEAD"),require=1,remap=false)
 private void mutants$reset(ZombieBruteEntity e,float a,float b,float c,float d,float f,CallbackInfo ci){torso.resetPose();}
 @Inject(method="setupAnim(Lnet/petemc/mutantszombies/entity/ZombieBruteEntity;FFFFF)V",at=@At("TAIL"),require=1,remap=false)
 private void mutants$warning(ZombieBruteEntity e,float a,float b,float c,float d,float f,CallbackInfo ci){dev.zomboid.mutants.client.Animation.heavyWalk(e,a,b,c,torso);dev.zomboid.mutants.client.Animation.brute(e,torso,right_arm,left_arm);}
}
