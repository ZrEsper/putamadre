package dev.zomboid.mutants.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;import net.minecraft.client.model.geom.ModelPart;import net.petemc.mutantszombies.entity.SplitHeadZombieEntity;
@Mixin(targets="net.petemc.mutantszombies.client.model.SplitHeadZombieModel",remap=false)
public abstract class WitchModel {
 @Shadow @Final private ModelPart head1;@Shadow @Final private ModelPart head2;@Shadow @Final private ModelPart torso;@Shadow @Final private ModelPart left_leg;@Shadow @Final private ModelPart right_leg;
 @Inject(method="setupAnim(Lnet/petemc/mutantszombies/entity/SplitHeadZombieEntity;FFFFF)V",at=@At("HEAD"),require=1,remap=false)
 private void mutants$reset(SplitHeadZombieEntity e,float a,float b,float c,float d,float f,CallbackInfo ci){head1.resetPose();head2.resetPose();torso.resetPose();left_leg.resetPose();right_leg.resetPose();}
 @Inject(method="setupAnim(Lnet/petemc/mutantszombies/entity/SplitHeadZombieEntity;FFFFF)V",at=@At("TAIL"),require=1,remap=false)
 private void mutants$pose(SplitHeadZombieEntity e,float a,float b,float age,float d,float f,CallbackInfo ci){dev.zomboid.mutants.client.Animation.witch(e,age,head1,head2,torso,left_leg,right_leg);}
}
