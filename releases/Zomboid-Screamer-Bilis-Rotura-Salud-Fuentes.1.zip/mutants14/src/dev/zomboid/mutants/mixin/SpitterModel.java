package dev.zomboid.mutants.mixin;
import org.spongepowered.asm.mixin.*;import org.spongepowered.asm.mixin.injection.*;import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;import net.minecraft.client.model.geom.ModelPart;import net.petemc.mutantszombies.entity.SpitterEntity;
@Mixin(targets="net.petemc.mutantszombies.client.model.SpitterModel",remap=false)
public abstract class SpitterModel {
 @Shadow @Final public ModelPart head2;
 @Shadow @Final public ModelPart head3;
 @Shadow @Final public ModelPart head4;
 @Shadow @Final public ModelPart head5;
 @Shadow @Final public ModelPart head6;
 @Shadow @Final public ModelPart head7;
 @Shadow @Final public ModelPart head8;
 @Shadow @Final public ModelPart torso;
 @Shadow @Final public ModelPart right_arm;
 @Shadow @Final public ModelPart left_arm;
 @Inject(method="setupAnim(Lnet/petemc/mutantszombies/entity/SpitterEntity;FFFFF)V",at=@At("HEAD"),require=1,remap=false)
 private void mutants$reset(SpitterEntity e,float a,float b,float age,float d,float f,CallbackInfo ci){head2.resetPose();head3.resetPose();head4.resetPose();head5.resetPose();head6.resetPose();head7.resetPose();head8.resetPose();torso.resetPose();right_arm.resetPose();left_arm.resetPose();}
 @Inject(method="setupAnim(Lnet/petemc/mutantszombies/entity/SpitterEntity;FFFFF)V",at=@At("TAIL"),require=1,remap=false)
 private void mutants$pose(SpitterEntity e,float a,float b,float age,float d,float f,CallbackInfo ci){dev.zomboid.mutants.client.Animation.infected(e,a,b,age,head2,torso,right_arm,left_arm,1);head3.xRot+=(float)Math.sin(age*.13+0)*.025f;head4.xRot+=(float)Math.sin(age*.13+1)*.025f;head5.xRot+=(float)Math.sin(age*.13+2)*.025f;head6.xRot+=(float)Math.sin(age*.13+3)*.025f;head7.xRot+=(float)Math.sin(age*.13+4)*.025f;head8.xRot+=(float)Math.sin(age*.13+5)*.025f;}
}
