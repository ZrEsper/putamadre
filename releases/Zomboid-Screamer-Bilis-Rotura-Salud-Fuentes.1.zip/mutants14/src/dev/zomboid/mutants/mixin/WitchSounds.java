package dev.zomboid.mutants.mixin;
@org.spongepowered.asm.mixin.Mixin(targets="net.petemc.mutantszombies.entity.SplitHeadZombieEntity",remap=false)
public abstract class WitchSounds {
 @org.spongepowered.asm.mixin.injection.Inject(method="getAmbientSound()Lnet/minecraft/sounds/SoundEvent;",at=@org.spongepowered.asm.mixin.injection.At("HEAD"),cancellable=true,require=1,remap=false)
 private void mutants$cryOnly(org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<net.minecraft.sounds.SoundEvent> ci){ci.setReturnValue(null);}
}
