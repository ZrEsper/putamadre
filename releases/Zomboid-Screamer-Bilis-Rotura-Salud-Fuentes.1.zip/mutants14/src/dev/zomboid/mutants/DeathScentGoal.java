package dev.zomboid.mutants;
import java.util.EnumSet;import net.minecraft.world.entity.Mob;import net.minecraft.world.entity.ai.goal.Goal;
public final class DeathScentGoal extends Goal {
 private final Mob mob;private DeathBile.Patch patch;private long scan;
 public DeathScentGoal(Mob m){mob=m;setFlags(EnumSet.of(Flag.TARGET));}
 public boolean canUse(){long now=mob.level().getGameTime();if(now<scan)return false;scan=now+20;if(Combat.valid(mob.getTarget())&&mob.distanceToSqr(mob.getTarget())<16*16)return false;patch=DeathBile.nearest(mob);return patch!=null;}
 public boolean canContinueToUse(){return patch!=null&&patch.end()>mob.level().getGameTime()&&mob.position().subtract(patch.pos()).lengthSqr()>4&&mob.position().subtract(patch.pos()).lengthSqr()<48*48;}
 public void start(){mob.setTarget(null);}
 public boolean requiresUpdateEveryTick(){return true;}
 public void tick(){if(mob.tickCount%10==0){var p=patch.pos();mob.getNavigation().moveTo(p.x,p.y,p.z,1.25);}}
 public void stop(){patch=null;}
}
