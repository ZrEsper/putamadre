package dev.zomboid.mutants;
import net.minecraft.world.effect.*;import net.neoforged.neoforge.registries.*;
@net.neoforged.fml.common.Mod(MutantAddon.ID)
public final class MutantAddon {
 public static final String ID="mutants_l4d2";
 public static final DeferredRegister<MobEffect> EFFECTS=DeferredRegister.create(net.minecraft.core.registries.Registries.MOB_EFFECT,ID);
 public static final DeferredHolder<MobEffect,BileEffect> BILE=EFFECTS.register("bilis",BileEffect::new);
 public MutantAddon(net.neoforged.bus.api.IEventBus bus){EFFECTS.register(bus);Screamers.register(bus);bus.addListener(PosePacket::register);}
 public static final class BileEffect extends MobEffect {public BileEffect(){super(MobEffectCategory.HARMFUL,0x9dac23);}}
}
