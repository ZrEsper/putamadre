package dev.zomboid.mutants;
import net.minecraft.world.entity.*;import net.minecraft.server.level.ServerLevel;import net.minecraft.world.phys.*;import net.minecraft.world.level.ClipContext;import net.minecraft.core.particles.ParticleTypes;
public final class Vomit {
 public static boolean inCone(double dx,double dz,double dirx,double dirz,double range){double d=dx*dx+dz*dz;return d<=range*range&&(d<.16||(dx*dirx+dz*dirz)/Math.sqrt(d)>.65);}
 public static void cast(Mob m,LivingEntity target,boolean bile){if(!(m.level() instanceof ServerLevel l)||!Combat.valid(target))return;double range=bile?5:9;Vec3 dir=target.position().subtract(m.position()).multiply(1,0,1).normalize();if(dir.lengthSqr()<.01)dir=new Vec3(1,0,0);Vec3 mouth=new Vec3(m.getX(),m.getEyeY()-.2,m.getZ());m.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
  for(int ray=-2;ray<=2;ray++){double angle=ray*.18,c=Math.cos(angle),s=Math.sin(angle);Vec3 d=new Vec3(dir.x*c-dir.z*s,0,dir.x*s+dir.z*c);Vec3 from=mouth,last=mouth;for(double step=.5;step<=range;step+=.5){Vec3 p=mouth.add(d.x*step,-.035*step*step,d.z*step);var hit=l.clip(new ClipContext(from,p,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,m));if(hit.getType()!=HitResult.Type.MISS){last=hit.getLocation();break;}last=p;l.sendParticles(ParticleTypes.SNEEZE,p.x,p.y,p.z,1,.06,.06,.06,.015);from=p;}if(!bile){Vec3 ground=Events.ground(l,last.add(0,.3,0));if(ground!=null)Zones.add(l,ground,1.8f,120,true,m);}}
  for(LivingEntity e:l.getEntitiesOfClass(LivingEntity.class,m.getBoundingBox().inflate(range,2,range))){if(e==m||!Combat.valid(e)||Combat.infected(e)||!inCone(e.getX()-m.getX(),e.getZ()-m.getZ(),dir.x,dir.z,range)||!m.hasLineOfSight(e))continue;if(bile)Combat.bile(e);else e.hurt(l.damageSources().mobAttack(m),3);}
 }
}
