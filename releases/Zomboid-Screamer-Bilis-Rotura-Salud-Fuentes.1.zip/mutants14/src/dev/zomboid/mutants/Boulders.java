package dev.zomboid.mutants;
import java.util.*;import java.lang.ref.WeakReference;import net.minecraft.server.level.ServerLevel;import net.minecraft.world.entity.*;import net.minecraft.world.phys.*;import net.minecraft.world.level.ClipContext;
public final class Boulders {
 public static final int LIFE=100;public static final double SIZE=1.4;
 private static final Map<ServerLevel,List<Rock>> ROCKS=new WeakHashMap<>();
 private static final class Rock {final WeakReference<Entity> display;final UUID owner;final long end;final Map<UUID,Long> hit=new HashMap<>();Vec3 pos,velocity;long soundAt;Rock(Entity e,Mob m,Vec3 p,Vec3 v,long end){display=new WeakReference<>(e);owner=m.getUUID();pos=p;velocity=v;this.end=end;}}
 public static void launch(Mob mob,LivingEntity victim){mob.swing(net.minecraft.world.InteractionHand.MAIN_HAND);ServerLevel l=(ServerLevel)mob.level();if(ROCKS.getOrDefault(l,List.of()).size()>=32)return;Entity e=Visuals.create(l,false);if(e==null)return;Vec3 p=mob.position().add(0,2.2,0);double dx=victim.getX()-p.x,dz=victim.getZ()-p.z,d=Math.sqrt(dx*dx+dz*dz);Vec3 v=new Vec3(dx,Rules.trajectoryRise(d,victim.getEyeY()-p.y-.3,1.15,.04),dz).normalize().scale(1.15);Visuals.configure(e,Visuals.display("minecraft:cobblestone",p,SIZE,SIZE,SIZE,0,0,0,1));Visuals.move(e,p);ROCKS.computeIfAbsent(l,k->new ArrayList<>()).add(new Rock(e,mob,p,v,l.getGameTime()+LIFE));if(!l.addFreshEntity(e)){Visuals.discard(e);return;}AbilitySounds.stone(mob);}
 public static Vec3 bounce(Vec3 velocity,int x,int y,int z){double dot=velocity.x*x+velocity.y*y+velocity.z*z;Vec3 v=velocity.add(-2*dot*x,-2*dot*y,-2*dot*z).scale(.65);if(y!=0&&Math.abs(v.y)<.12)v=new Vec3(v.x,.12,v.z);return v;}
 public static void tick(ServerLevel l){var list=ROCKS.get(l);if(list==null)return;long now=l.getGameTime();var it=list.iterator();while(it.hasNext()){Rock r=it.next();Entity e=r.display.get();if(e==null||e.isRemoved()||now>=r.end||!l.hasChunkAt(net.minecraft.core.BlockPos.containing(r.pos.x,r.pos.y,r.pos.z))){Visuals.discard(e);it.remove();continue;}
  Vec3 next=r.pos.add(r.velocity);var hit=l.clip(new ClipContext(r.pos,next,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,e));AABB box=new AABB(next,next).inflate(SIZE/2);
  if(hit.getType()!=HitResult.Type.MISS||!l.noCollision(e,box)){int nx=0,ny=0,nz=0;if(hit.getType()!=HitResult.Type.MISS){var face=hit.getDirection();nx=face.getStepX();ny=face.getStepY();nz=face.getStepZ();}else{AABB bx=new AABB(r.pos,r.pos).inflate(SIZE/2).move(new Vec3(r.velocity.x,0,0)),by=new AABB(r.pos,r.pos).inflate(SIZE/2).move(new Vec3(0,r.velocity.y,0));if(!l.noCollision(e,bx))nx=r.velocity.x>0?-1:1;else if(!l.noCollision(e,by))ny=r.velocity.y>0?-1:1;else nz=r.velocity.z>0?-1:1;}
   r.velocity=bounce(r.velocity,nx,ny,nz);if(now>=r.soundAt){AbilitySounds.stone(e);r.soundAt=now+5;}
  }else r.pos=next;
  Visuals.move(e,r.pos);Mob owner=l.getEntity(r.owner) instanceof Mob m?m:null;
  for(LivingEntity target:l.getEntitiesOfClass(LivingEntity.class,new AABB(r.pos,r.pos).inflate(SIZE/2+.2))){if(!Combat.valid(target)||target.getUUID().equals(r.owner)||now<r.hit.getOrDefault(target.getUUID(),0L))continue;if(l.clip(new ClipContext(r.pos,target.position().add(0,.5,0),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,target)).getType()!=HitResult.Type.MISS)continue;r.hit.put(target.getUUID(),now+10);target.hurt(owner==null?l.damageSources().magic():l.damageSources().mobAttack(owner),10);Combat.knock(r.pos,target,1.1);AbilitySounds.stone(e);}
  r.velocity=r.velocity.scale(.98).add(0,-.04,0);
 }if(list.isEmpty())ROCKS.remove(l);}
}
