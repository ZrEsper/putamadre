package dev.zomboid.mutants.client;
import dev.zomboid.mutants.*;import net.minecraft.world.entity.Entity;import net.minecraft.client.model.geom.ModelPart;
@net.neoforged.fml.common.EventBusSubscriber(modid=MutantAddon.ID,value=net.neoforged.api.distmarker.Dist.CLIENT)
public final class Animation {
 public static void infected(Entity e,float walk,float speed,float age,ModelPart head,ModelPart torso,ModelPart right,ModelPart left,int kind){
  float gait=Math.min(1,Math.abs(speed)),breath=(float)Math.sin(age*.11)*.014f,sway=(float)Math.sin(walk*.6)*gait*.035f;
  float run=Math.max(0,Math.min(1,(gait-.3f)*2));torso.xRot+=(kind==2?.05f:kind==3?.13f:.1f)+gait*.08f+run*.12f+breath;torso.zRot+=sway;
  head.zRot+=(kind==4?-.09f:.055f)+(float)Math.sin(age*.17)*.012f;head.xRot-=gait*.045f;
  if(kind!=2){right.xRot-=gait*.25f+run*.2f;left.xRot-=gait*.2f+run*.2f;right.zRot+=.04f;left.zRot-=.035f;}
  float attack=e instanceof net.minecraft.world.entity.LivingEntity living?living.getAttackAnim(0):0;float burst=(float)Math.sin(Math.sqrt(Math.max(0,attack))*Math.PI);torso.xRot+=burst*.24f;torso.yRot+=burst*.14f;right.xRot-=burst*.6f;left.xRot-=burst*.45f;head.xRot+=burst*.14f;
  var s=signal(e);if(s==null)return;float p=Rules.progress(e.level().getGameTime(),s.start(),s.duration());
  if(s.phase()==Rules.TETHER){torso.xRot+=.15f;head.xRot+=.12f;}
  else if(s.phase()==Rules.SPIT){float jerk=(float)Math.sin(p*Math.PI);torso.xRot+=jerk*.2f;head.xRot+=jerk*.3f;right.xRot-=jerk*.3f;left.xRot-=jerk*.3f;}
  else if(s.phase()==Rules.POUNCE){torso.xRot+=.3f;right.xRot=-1.1f;left.xRot=-1.1f;head.xRot-=.15f;}
 }
 public static void heavyWalk(Entity e,float walk,float speed,float age,ModelPart torso){float run=Math.max(0,Math.min(1,(Math.abs(speed)-.3f)*2));torso.xRot+=run*.16f;torso.zRot+=(float)Math.sin(walk*.55)*Math.min(1,Math.abs(speed))*.04f;float hit=e instanceof net.minecraft.world.entity.LivingEntity l?l.getAttackAnim(0):0;torso.xRot+=(float)Math.sin(Math.sqrt(Math.max(0,hit))*Math.PI)*.3f;}
 public static Signals.Pose signal(Entity entity){return Signals.get(entity.getUUID());}
 public static void tank(Entity e,float age,ModelPart head,ModelPart torso,ModelPart right,ModelPart left){torso.xRot+=.1f+(float)Math.sin(age*.1)*.012f;var s=signal(e);if(s==null)return;float p=Rules.progress(e.level().getGameTime(),s.start(),s.duration());switch(s.phase()){
 case Rules.WINDUP->{torso.xRot=.2f;right.xRot=-.4f;left.xRot=-.4f;}
 case Rules.CHARGE->{torso.xRot=.55f;head.xRot=.25f;right.xRot=-1;left.xRot=-1;}
 case Rules.STUN->{torso.xRot=.7f;head.xRot=.55f;right.xRot=.35f;left.xRot=.35f;}
 case Rules.THROW->{torso.xRot=-.15f*p;right.xRot=-2.6f*Math.min(1,p*1.7f);left.xRot=right.xRot;}
 case Rules.RECOVER->{right.xRot=-2.6f*(1-p);left.xRot=right.xRot;torso.xRot=.3f*(1-p);}
 }}
 public static void brute(Entity e,ModelPart torso,ModelPart right,ModelPart left){torso.xRot+=.12f+(float)Math.sin(e.tickCount*.1)*.012f;var s=signal(e);if(s!=null&&s.phase()==Rules.LUNGE){torso.xRot+=.4f;right.xRot=-.9f;left.xRot=-.9f;}else if(s!=null&&s.phase()==Rules.SMASH){float p=Rules.progress(e.level().getGameTime(),s.start(),s.duration());right.xRot=-.5f-2*p;left.xRot=right.xRot;torso.xRot=-.1f*p;}}
 public static void witch(Entity e,float age,ModelPart head1,ModelPart head2,ModelPart torso,ModelPart left,ModelPart right){var s=signal(e);boolean furious=s!=null&&s.phase()==Rules.FURY;if(furious){float attack=e instanceof net.minecraft.world.entity.LivingEntity l?l.getAttackAnim(0):0;torso.xRot=.28f+(float)Math.sin(Math.sqrt(Math.max(0,attack))*Math.PI)*.28f;head1.xRot-=.2f;head2.xRot-=.2f;left.xRot*=1.25f;right.xRot*=1.25f;}else{float breath=(float)Math.sin(age*.09)*.035f;torso.xRot=.7f+breath;torso.y+=6;head1.y+=6;head2.y+=6;head1.xRot=.8f+breath;head2.xRot=.85f+breath;left.xRot=-1.45f;right.xRot=-1.45f;left.y+=3;right.y+=3;left.z+=2;right.z+=2;}}
 @net.neoforged.bus.api.SubscribeEvent public static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event){if(net.minecraft.client.Minecraft.getInstance().level==null)Signals.clear();}
}
