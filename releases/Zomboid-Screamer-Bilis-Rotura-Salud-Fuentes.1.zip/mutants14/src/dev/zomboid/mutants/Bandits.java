package dev.zomboid.mutants;
import java.lang.reflect.*;import net.minecraft.world.entity.*;
/** Optional tactical.13 integration; never links NPC classes on installations without them. */
public final class Bandits {
 private static final java.util.Map<String,Field> FIELDS=new java.util.HashMap<>();
 private static Method bandit,state,mem,release,cancel,busy;private static boolean ready,failed;
 private static boolean npc(Entity e){if(e==null)return false;for(Class<?> c=e.getClass();c!=null;c=c.getSuperclass())if(c.getName().equals("mod.cdv.tnpc.entity.AutoGunOperator"))return true;return false;}
 private static Method method(Class<?> c,String n,Class<?>...args)throws Exception{Method m=c.getDeclaredMethod(n,args);m.setAccessible(true);return m;}
 private static boolean initialize(){if(ready)return true;if(failed)return false;try{Class<?> c=Class.forName("mod.cdv.tnpc.tactical.CalmBrain"),t=Class.forName("mod.cdv.tnpc.tactical.TeamBrain"),s=Class.forName("mod.cdv.tnpc.tactical.CalmBrain$State"),m=Class.forName("mod.cdv.tnpc.tactical.TeamBrain$Memory"),l=Class.forName("mod.cdv.tnpc.tactical.CalmLoot");bandit=method(c,"bandit",Object.class);state=method(c,"state",Object.class);mem=method(t,"mem",Object.class);busy=method(t,"busy",Object.class);cancel=method(t,"cancelAid",Object.class,m,long.class);release=method(l,"release",Object.class,s);ready=true;return true;}catch(Exception e){failed=true;System.err.println("[mutants_l4d2] Tactical NPC integration unavailable: "+e);return false;}}
 public static boolean is(Entity e){if(!npc(e)||!initialize())return false;try{return Boolean.TRUE.equals(bandit.invoke(null,e));}catch(Exception ex){warn(ex);return false;}}
 private static void warn(Exception e){if(!failed)System.err.println("[mutants_l4d2] Tactical NPC integration error: "+e);failed=true;}
 private static Field field(Object o,String name)throws Exception{String key=o.getClass().getName()+"#"+name;Field f=FIELDS.get(key);if(f==null){f=o.getClass().getDeclaredField(name);f.setAccessible(true);FIELDS.put(key,f);}return f;}
 private static void set(Object o,String name,Object value)throws Exception{field(o,name).set(o,value);}
 public static void avoidProvoking(Mob mob){if(!initialize()||failed)return;try{Object s=state.invoke(null,mob);Object target=field(s,"target").get(s);if(target instanceof Mob m&&BanditCombat.calmWitch(m))set(s,"target",null);if(mob.getTarget() instanceof Mob m&&BanditCombat.calmWitch(m))mob.setTarget(null);}catch(Exception e){warn(e);}}
 public static void engage(Mob mob,LivingEntity enemy){if(!initialize()||failed)return;try{Object s=state.invoke(null,mob),m=mem.invoke(null,mob);if(Boolean.TRUE.equals(field(m,"fleeing").get(m)))return;long now=mob.level().getGameTime();if(field(s,"target").get(s)!=enemy)release.invoke(null,mob,s);if(Boolean.TRUE.equals(busy.invoke(null,mob)))cancel.invoke(null,mob,m,now);set(m,"sheltering",false);set(m,"tidying",false);set(m,"investigateUntil",0L);set(s,"target",enemy);set(s,"seen",now);set(s,"reactAt",now);set(s,"x",enemy.getX());set(s,"y",enemy.getY());set(s,"z",enemy.getZ());mob.setTarget(enemy);}catch(Exception e){warn(e);}}
 public static boolean retreating(Mob mob){if(!initialize()||failed)return true;try{return Boolean.TRUE.equals(field(mem.invoke(null,mob),"fleeing").get(mem.invoke(null,mob)));}catch(Exception e){warn(e);return true;}}
}
