package dev.zomboid.mutants;
import java.util.EnumSet;import net.minecraft.world.entity.*;import net.minecraft.world.entity.ai.goal.Goal;import net.minecraft.world.phys.Vec3;import net.petemc.mutantszombies.entity.*;
/** Fills ability cooldowns with pursuit and native melee; never teleports or breaks blocks. */
public final class PursuitGoal extends Goal {
 private final Mob mob;private long pathAt,checkAt,hitAt;private Vec3 previous;
 public PursuitGoal(Mob m){mob=m;setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
 public boolean canUse(){return !mob.isInWater()&&Combat.valid(mob.getTarget())&&mob.distanceToSqr(mob.getTarget())<=64*64;}
 public boolean canContinueToUse(){return canUse();}
 public boolean requiresUpdateEveryTick(){return true;}
 public void start(){pathAt=0;checkAt=mob.level().getGameTime()+20;previous=mob.position();}
 public void tick(){LivingEntity t=mob.getTarget();if(!Combat.valid(t))return;long now=mob.level().getGameTime();mob.getLookControl().setLookAt(t,30,30);if(now>=pathAt){pathAt=now+5;mob.getNavigation().moveTo(t,1.25);}if(now>=checkAt){checkAt=now+20;if(previous!=null&&mob.position().subtract(previous).lengthSqr()<.16&&mob.distanceToSqr(t)>9){Vec3 forward=t.position().subtract(mob.position()).multiply(1,0,1).normalize();double sign=((now/20+mob.getUUID().getLeastSignificantBits())&1)==0?1:-1;Vec3 side=mob.position().add(-forward.z*sign*4,0,forward.x*sign*4).add(forward.scale(2));mob.getNavigation().moveTo(side.x,side.y,side.z,1.25);pathAt=now+15;}previous=mob.position();}
  double reach=2+mob.getBbWidth()/2;if(now>=hitAt&&mob.distanceToSqr(t)<reach*reach&&mob.hasLineOfSight(t)){hitAt=now+16;mob.doHurtTarget(t);mob.swing(net.minecraft.world.InteractionHand.MAIN_HAND);}
 }
 public void stop(){mob.getNavigation().stop();}
}
