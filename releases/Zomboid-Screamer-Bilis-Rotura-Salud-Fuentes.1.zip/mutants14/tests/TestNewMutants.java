import dev.zomboid.mutants.*;import net.minecraft.server.level.*;import net.minecraft.world.entity.*;import net.minecraft.world.phys.*;import net.petemc.mutantszombies.entity.*;
public class TestNewMutants {
 static int checks;static void ok(boolean v,String why){checks++;if(!v)throw new AssertionError(why);}static ServerPlayer player(ServerLevel l,double x,double z){var p=new ServerPlayer();p.world=l;p.x=x;p.z=z;l.players.add(p);return p;}
 public static void main(String[] args){
  ok(Vomit.inCone(4,0,1,0,5),"front hit");ok(!Vomit.inCone(-2,0,1,0,5),"behind excluded");ok(!Vomit.inCone(1,4,1,0,5),"side excluded");ok(!Vomit.inCone(6,0,1,0,5),"outside radius excluded");
  var l=new ServerLevel();var front=player(l,4,0);var back=player(l,-3,0);var side=player(l,0,4);var m=new RottenMutantEntity(l);l.entities.add(m);
  Vomit.cast(m,front,true);ok(front.hasEffect(MutantAddon.BILE),"short vomit marks front player");ok(!back.hasEffect(MutantAddon.BILE)&&!side.hasEffect(MutantAddon.BILE),"vomit not omnidirectional");ok(l.entities.size()==1,"bile vomit creates no slime or projectile");
  var near=new net.minecraft.world.entity.monster.Zombie(l);near.x=12;l.entities.add(near);front.effects.clear();Combat.bile(front);ok(near.getTarget()==front,"first contact immediately attracts zombie");
  l=new ServerLevel();front=player(l,6,0);var sp=new SpitterEntity(l);l.entities.add(sp);Vomit.cast(sp,front,false);ok(front.damage>0,"acid cone damages target");ok(l.entities.stream().noneMatch(e->e instanceof SpitterEntityProjectile),"spitter never creates slime projectile");
  l=new ServerLevel();front=player(l,3,0);front.visible=false;m=new RottenMutantEntity(l);Vomit.cast(m,front,true);ok(!front.hasEffect(MutantAddon.BILE),"bile cannot hit through wall");
  l=new ServerLevel();front=player(l,12,0);var screamer=new Screamers.Screamer(null,l);l.entities.add(screamer);var z=new net.minecraft.world.entity.monster.Zombie(l);z.x=25;l.entities.add(z);screamer.tick();ok(screamer.getTarget()==front&&screamer.isAggressive(),"screamer acquires and signals player");ok(screamer.getNavigation().target==front,"screamer pursues player");ok(z.getTarget()==front,"scream recruits nearby zombie");ok(!screamer.doHurtTarget(front)&&front.damage==0,"screamer cannot directly attack");front.creative=true;l.time=100;screamer.tick();ok(screamer.getTarget()==null,"creative immunity and chase release");
  l=new ServerLevel();front=player(l,2,0);m=new RottenMutantEntity(l);MutantStats.apply(m);ok(m.getMaxHealth()==16,"boomer fragile health");m.setTarget(front);var g=new BoomerGoal(m);g.tick();l.time=6;g.tick();ok(front.hasEffect(MutantAddon.BILE),"boomer burst marks victim");ok(front.damage==0,"boomer spits without melee");
  l=new ServerLevel();front=player(l,1,0);m=new RottenMutantEntity(l);DeathBile.add(m);l.time=10;DeathBile.tick(l);ok(front.hasEffect(MutantAddon.BILE),"death puddle contaminates on contact within half second");l.time=400;DeathBile.tick(l);ok(l.entities.stream().noneMatch(Entity::isAlive),"death visuals expire");
  System.out.println("PASS "+checks+" new mutant behavior cases");
 }
}
