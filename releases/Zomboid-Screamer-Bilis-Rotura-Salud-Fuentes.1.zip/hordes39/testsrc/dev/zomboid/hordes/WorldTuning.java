package dev.zomboid.hordes;public class WorldTuning{public static double speed=25;public static double get(String k){return speed;}}
