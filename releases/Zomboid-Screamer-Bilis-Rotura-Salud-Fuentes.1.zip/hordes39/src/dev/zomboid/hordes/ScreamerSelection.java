package dev.zomboid.hordes;
public final class ScreamerSelection {
 public static boolean supported(String id){return id.equals("mutants_l4d2:screamer");}
 public static Object pick(Object original,String method,Object[] args){if(!method.equals("pick")||original==null||args.length<2||WorldTuning.get("mutantes")<=0||WorldTuning.get("screamer_probabilidad")<=0)return original;
 String description=String.valueOf(ZoneReflection.call(original,"getDescriptionId"));if(!description.equals("entity.minecraft.zombie")&&!description.equals("entity.minecraft.husk")&&!description.equals("entity.minecraft.drowned"))return original;
 Object world=args[0],random=ZoneReflection.call(world,"getRandom");if(((Number)ZoneReflection.call(random,"nextDouble")).doubleValue()>=WorldTuning.get("screamer_probabilidad")/100)return original;
 Object registry=ZoneReflection.get(ZoneReflection.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE"),id=ZoneReflection.call(ZoneReflection.type("net.minecraft.resources.ResourceLocation"),"parse","mutants_l4d2:screamer");if(!Boolean.TRUE.equals(ZoneReflection.call(registry,"containsKey",id)))return original;
 double x=((Number)ZoneReflection.call(args[1],"getX")).doubleValue(),z=((Number)ZoneReflection.call(args[1],"getZ")).doubleValue();int count=0;
 for(Object entity:(Iterable<?>)ZoneReflection.call(world,"getAllEntities")){if(!Boolean.TRUE.equals(ZoneReflection.call(entity,"isAlive")))continue;String key=dev.zomboid.rarehorde.Mutants.id(entity);if(!dev.zomboid.rarehorde.Mutants.supported(key))continue;double dx=((Number)ZoneReflection.call(entity,"getX")).doubleValue()-x,dz=((Number)ZoneReflection.call(entity,"getZ")).doubleValue()-z;if(dx*dx+dz*dz<=16384&&++count>=WorldTuning.mutantCap())return original;}
 return ZoneReflection.call(registry,"get",id);}
}
