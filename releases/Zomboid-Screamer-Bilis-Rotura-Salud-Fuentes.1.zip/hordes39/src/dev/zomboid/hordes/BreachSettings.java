package dev.zomboid.hordes;
import java.util.*;
public final class BreachSettings {
 public static void install(Map<String,Double>a,Map<String,Double>b,Map<String,Double>c,Map<String,Double>d){for(String k:new String[]{"rotura_velocidad","screamer_probabilidad"}){double v=k.startsWith("rotura")?25:1;a.put(k,v);b.put(k,k.startsWith("rotura")?1d:0d);c.put(k,100d);d.putIfAbsent(k,v);}}
 public static double scroll(double value,String key){return key.equals("rotura_velocidad")?Math.max(1,Math.min(100,value)):value;}
 public static int breakTicks(float hardness,double speed){if(!Double.isFinite(speed))speed=25;return (int)Math.ceil(Math.max(40,80+Math.max(0,hardness)*40)*25/Math.max(1,Math.min(100,speed)));}
 public static String[][] rows(String[][] rows,String kind){rows=rows.clone();boolean keys=kind.equals("KEYS"),labels=kind.equals("LABELS");for(int page:new int[]{0,11}){String[] old=rows[page];String[] n=Arrays.copyOf(old,old.length+1);n[old.length]=page==0?(keys?"rotura_velocidad":labels?"Velocidad de rotura (%)":"1-100; 25 lento por defecto. Piedra: ~7 s a 25, ~1,75 s a 100. Requiere permitir romper y mobGriefing."):(keys?"screamer_probabilidad":labels?"Screamer entre zombis nuevos (%)":"0-100; 1 por defecto. Sustituye zombis comunes nuevos; respeta admision y limite local de mutantes. Requiere addon 1.4.");rows[page]=n;}
 if(kind.equals("HINTS"))ApocalypsePanel.baseHints=Arrays.stream(rows).map(String[]::clone).toArray(String[][]::new);return rows;}
}
