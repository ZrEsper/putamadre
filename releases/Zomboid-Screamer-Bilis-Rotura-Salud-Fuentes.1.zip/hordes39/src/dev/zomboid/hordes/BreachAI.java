package dev.zomboid.hordes;
import net.minecraft.core.BlockPos;import net.minecraft.nbt.CompoundTag;import net.minecraft.world.entity.Mob;import net.minecraft.server.level.ServerLevel;import net.minecraft.world.level.ClipContext;import net.minecraft.world.phys.*;
public final class BreachAI {
 public static boolean failedStep(Mob z,CompoundTag d,long now){if(!d.contains("zh_step_at")||Math.hypot(z.getX()-d.getDouble("zh_step_x"),z.getZ()-d.getDouble("zh_step_z"))>.75){d.putLong("zh_step_at",now);d.putDouble("zh_step_x",z.getX());d.putDouble("zh_step_z",z.getZ());return false;}return now-d.getLong("zh_step_at")>=40;}
 public static BlockPos find(Mob z,ServerLevel l,CompoundTag d,double dx,double dz){
 if(d.contains("zh_siege_bx")){BlockPos old=new BlockPos(d.getInt("zh_siege_bx"),d.getInt("zh_siege_by"),d.getInt("zh_siege_bz"));double x=old.getX()+.5-z.getX(),y=old.getY()+.5-z.getY(),zz=old.getZ()+.5-z.getZ();if(x*x+zz*zz<6.25&&y>-.5&&y<z.getBbHeight()+.2&&x*dx+zz*dz>-.2&&solid(l,old))return old;}
 for(double y:new double[]{1.1,.25,Math.max(1.75,z.getBbHeight()-.15)}){Vec3 from=z.position().add(0,y,0),to=from.add(dx*1.65,0,dz*1.65);var hit=l.clip(new ClipContext(from,to,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,z));if(hit.getType()==HitResult.Type.BLOCK&&solid(l,hit.getBlockPos()))return hit.getBlockPos();}return null;}
 private static boolean solid(ServerLevel l,BlockPos p){return l.hasChunkAt(p)&&!l.getBlockState(p).getCollisionShape(l,p).isEmpty();}
}
