package dev.zomboid.firstaid;
public final class BallisticHealth {
 public static boolean fatalValues(float head,float torso,float total){return head<=0 || torso<=0 || total<=0;}
 public static boolean fatal(Object model){return fatalValues(((Number)R.get(R.get(model,"HEAD"),"currentHealth")).floatValue(),((Number)R.get(R.get(model,"BODY"),"currentHealth")).floatValue(),ZeroParts.rawHealth(model,null));}
 public static float scale(float amount,boolean vital,boolean bullet){return amount*(vital?0.5f:1f)*(bullet?0.4f:1f);}
 public static float shot(float amount,boolean vital,boolean bullet,float max,String part){float result=scale(amount,vital,bullet);if(bullet&&(part.equals("HEAD")||part.equals("BODY"))){float cap=max/(part.equals("HEAD")?8f:15f)+max*.000001f;result=Math.min(result,cap);}return result;}
 public static float damage(Object part,float amount){Object context=R.get(R.type("ichttt.mods.firstaid.survival.ClinicalHooks"),"BULLET");boolean bullet=Boolean.TRUE.equals(((ThreadLocal<?>)context).get());String name=String.valueOf(R.get(part,"part"));return shot(amount,name.equals("HEAD")||name.equals("BODY"),bullet,((Number)R.call(part,"getMaxHealth")).floatValue(),name);}
}
