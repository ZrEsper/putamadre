package mod.cdv.tnpc.tactical;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.WeakHashMap;

public final class Hunt78 {
   static final Map<Object, Hunt78.Run> RUNS = new WeakHashMap<>();
   static final Set<Object> WARN = Collections.newSetFromMap(new WeakHashMap<>());

   static Object c(Object var0, String var1, Object... var2) {
      return Social.c(var0, var1, var2);
   }

   static JsonObject cfg() {
      return Companion78.cfg().getAsJsonObject("caza");
   }

   static int num(String var0) {
      return cfg().get(var0).getAsInt();
   }

   static boolean nativeLoot(Object var0) {
      Hunt78.Run var1 = RUNS.get(var0);

      try {
         return var1 != null && var1.phase.equals("botin") && SocialR.get(CalmBrain.state(var0), "corpse") != null;
      } catch (Exception var2) {
         return false;
      }
   }

   static boolean busy(Object var0) {
      Hunt78.Run var1 = RUNS.get(var0);
      return var1 != null && !Set.of("descansar", "cazar").contains(var1.phase);
   }

   static String goal(Object var0) {
      Hunt78.Run var1 = RUNS.get(var0);
      Object var10000;
      if (var1 == null) {
         var10000 = null;
      } else {
         String var2 = var1.phase;
         switch (var1.phase.hashCode()) {
            case -682319683:
               if (var2.equals("regresar")) {
                  return "regresar";
               }
               break;
            case 93926700:
               if (var2.equals("botin")) {
                  return "botin";
               }
               break;
            case 94438669:
               if (var2.equals("cazar")) {
                  return "cazar";
               }
               break;
            case 943439249:
               if (var2.equals("deposito")) {
                  return "deposito";
               }
         }

         var10000 = null;
      }

      return (String)var10000;
   }

   static void point(Object var0, String var1, Object var2) {
      JsonObject var3 = new JsonObject();
      var3.addProperty("x", Shelter77.axis(var2, "getX"));
      var3.addProperty("y", Shelter77.axis(var2, "getY"));
      var3.addProperty("z", Shelter77.axis(var2, "getZ"));
      c(Social.tag(var0), "putString", var1, var3.toString());
   }

   static Object point(Object var0, String var1) {
      try {
         String var2 = Social.s(Social.tag(var0), var1);
         if (var2.isBlank()) {
            return null;
         } else {
            JsonObject var3 = JsonParser.parseString(var2).getAsJsonObject();
            return Shelter77.pos(var3.get("x").getAsInt(), var3.get("y").getAsInt(), var3.get("z").getAsInt());
         }
      } catch (Exception var4) {
         return null;
      }
   }

   static void home(Object var0, Object var1) {
      if (point(var0, "npc78_home") == null) {
         point(var0, "npc78_home", var1);
      }
   }

   static boolean eligible(Object var0) {
      return cfg().get("activa").getAsBoolean()
         && Activity78.free(var0)
         && Chat71.armed(var0)
         && Social.num(c(var0, "getHealth")) >= Social.num(c(var0, "getMaxHealth")) * 0.7;
   }

   static double distance(Object var0, Object var1) {
      double var2 = Social.num(c(var0, "getX")) - (double)Shelter77.axis(var1, "getX") - 0.5;
      double var4 = Social.num(c(var0, "getY")) - (double)Shelter77.axis(var1, "getY");
      double var6 = Social.num(c(var0, "getZ")) - (double)Shelter77.axis(var1, "getZ") - 0.5;
      return var2 * var2 + var4 * var4 + var6 * var6;
   }

   static Object approach(Object var0, Object var1) {
      Object var2 = c(var0, "getNavigation");
      Object var3 = Social.world(var0);

      int[][] var7;
      for (int[] var4 : var7 = new int[][]{{0, -1}, {1, 0}, {-1, 0}, {0, 1}}) {
         Object var8 = Shelter77.offset(var1, var4[0], 0, var4[1]);
         if (Shelter77.loaded(var3, var8)
            && Shelter77.air(var3, var8)
            && Navigation78.complete(
               Navigation78.path(
                  var2, (double)Shelter77.axis(var8, "getX") + 0.5, (double)Shelter77.axis(var8, "getY"), (double)Shelter77.axis(var8, "getZ") + 0.5
               )
            )) {
            return var8;
         }
      }

      return null;
   }

   static boolean move(Object var0, Object var1) {
      if (container(Social.world(var0), var1)) {
         var1 = approach(var0, var1);
         if (var1 == null) {
            return false;
         }
      }

      return Navigation78.go(
         var0, (double)Shelter77.axis(var1, "getX") + 0.5, (double)Shelter77.axis(var1, "getY"), (double)Shelter77.axis(var1, "getZ") + 0.5, 0.9
      );
   }

   static void tick(Object var0) {
      try {
         if (Social.client(var0) || !Social.alive(var0) || Downed20.down(var0)) {
            return;
         }

         Hunt78.Run var1 = RUNS.get(var0);
         long var2 = Social.time(var0);
         if (var1 != null && var1.phase.equals("cazar") && var1.target != null) {
            Object var14 = var1.target.get();
            if (var14 != null && Social.alive(var14)) {
               if (var2 <= var1.until && !(distance(var0, var1.home) > (double)(num("radio_base") * num("radio_base")))) {
                  var1.x = Social.num(c(var14, "getX"));
                  var1.y = Social.num(c(var14, "getY"));
                  var1.z = Social.num(c(var14, "getZ"));
               } else {
                  if (CalmBrain.state(var0).target == var14) {
                     Social.c(Social.class, "target", var0, null);
                  }

                  var1.phase = "regresar";
                  var1.next = var2;
               }
            } else {
               var1.phase = "botin";
               var1.until = var2 + (long)num("botin_ticks");
               var1.next = var2;
            }

            return;
         }

         if (!eligible(var0) || Life79.servicing(var0)) {
            return;
         }

         if (var1 == null) {
            Shelter77.Camp var4 = Shelter77.get(var0);
            if (var4 != null) {
               if (!var4.phase.equals("descansar")) {
                  return;
               }

               home(var0, Shelter77.pos(var4.x, var4.y, var4.z));
            } else if (!Shelter77.exposed(var0)) {
               home(var0, c(var0, "blockPosition"));
            }

            Object var5 = point(var0, "npc78_home");
            if (var5 == null) {
               return;
            }

            var1 = new Hunt78.Run();
            var1.home = var5;
            var1.depot = point(var0, "npc78_depot");
            var1.next = var2;
            RUNS.put(var0, var1);
         }

         if (var2 < var1.next) {
            return;
         }

         if (var1.phase.equals("descansar")) {
            var1.phase = var1.depot == null ? "deposito" : "cazar";
            var1.target = null;
         }

         if (!var1.phase.equals("cazar") || var1.target != null) {
            return;
         }

         int var13 = 0;
         Object var15 = null;
         double var6 = (double)(num("radio_caza") * num("radio_caza"));

         for (Object var8 : Social.nearby(var0, "net.minecraft.world.entity.monster.Zombie", (double)num("radio_caza"))) {
            if (Social.alive(var8) && Social.visible(var0, var8)) {
               var13++;
               double var10 = Social.distance(var0, var8);
               if (var10 < var6 && distance(var8, var1.home) <= (double)(num("radio_base") * num("radio_base"))) {
                  var15 = var8;
                  var6 = var10;
               }
            }
         }

         if (var13 > num("max_zombies") || var15 == null) {
            var1.phase = "descansar";
            var1.next = var2 + (long)num("descanso_ticks");
            return;
         }

         var1.target = new WeakReference<>(var15);
         var1.x = Social.num(c(var15, "getX"));
         var1.y = Social.num(c(var15, "getY"));
         var1.z = Social.num(c(var15, "getZ"));
         var1.until = var2 + (long)num("persecucion_ticks");
         Social.c(Social.class, "target", var0, var15);
         c(Social.tag(var0), "putString", "npc78_actividad", "cazar_zombi");
      } catch (Exception var12) {
         failure(var0, var12);
      }
   }

   static boolean work(Object var0) {
      Hunt78.Run var1 = RUNS.get(var0);
      if (var1 != null && eligible(var0) && !var1.phase.equals("cazar") && !var1.phase.equals("descansar")) {
         if (Social.time(var0) >= var1.next) {
            try {
               long var2 = Social.time(var0);
               var1.next = var2 + 20L;
               Social.mem(var0).occupied = true;
               if (var1.phase.equals("deposito")) {
                  if (var1.depot == null) {
                     var1.depot = findDepot(var0, var1.home);
                     if (var1.depot == null && !prepareChest(var0, var1)) {
                        return !var1.phase.equals("descansar");
                     }

                     if (var1.depot != null) {
                        point(var0, "npc78_depot", var1.depot);
                     }
                  }

                  if (var1.depot != null) {
                     var1.phase = "regresar";
                  }

                  return true;
               } else if (var1.phase.equals("botin")) {
                  Object var4 = Shelter77.pos((int)Math.floor(var1.x), (int)Math.floor(var1.y), (int)Math.floor(var1.z));
                  if (!(distance(var0, var4) > 9.0)) {
                     collect(var0);
                     Social.mem(var0).occupied = false;

                     try {
                        CalmBrain.State var5 = CalmBrain.state(var0);
                        c(Social.t("mod.cdv.tnpc.tactical.SurvivorPatch"), "search", var0, var5, var2);
                        if (SocialR.get(var5, "corpse") != null) {
                           c(Social.t("mod.cdv.tnpc.tactical.SurvivorPatch"), "idle", var0, var5, var2);
                           if (var2 >= var1.until) {
                              c(CalmLoot.class, "release", var0, var5);
                              var1.phase = "regresar";
                              return true;
                           }

                           Social.mem(var0).occupied = false;
                           return false;
                        }
                     } catch (Exception var6) {
                     }

                     Social.mem(var0).occupied = true;
                     if (var2 >= var1.until) {
                        var1.phase = "regresar";
                     }

                     return true;
                  } else {
                     if (!move(var0, var4) || var2 > var1.until) {
                        var1.phase = "regresar";
                     }

                     return true;
                  }
               } else if (var1.phase.equals("regresar")) {
                  if (var1.depot == null || !container(Social.world(var0), var1.depot)) {
                     var1.depot = null;
                     var1.phase = "deposito";
                     return true;
                  } else if (distance(var0, var1.depot) > 9.0) {
                     if (!move(var0, var1.depot)) {
                        var1.next = var2 + 100L;
                     }

                     return true;
                  } else {
                     deposit(var0, var1.depot);
                     var1.phase = "descansar";
                     var1.target = null;
                     var1.next = var2 + (long)num("descanso_ticks");
                     Social.mem(var0).occupied = false;
                     c(Social.tag(var0), "putString", "npc78_actividad", "botin_guardado");
                     return false;
                  }
               } else {
                  return false;
               }
            } catch (Exception var7) {
               Social.mem(var0).occupied = false;
               failure(var0, var7);
               return false;
            }
         } else if (nativeLoot(var0)) {
            return false;
         } else {
            Social.mem(var0).occupied = true;
            return true;
         }
      } else {
         return false;
      }
   }

   static void collect(Object var0) {
      for (Object var1 : Social.nearby(var0, "net.minecraft.world.entity.item.ItemEntity", 3.0)) {
         if (Social.alive(var1)) {
            Object var3 = c(var1, "getItem");
            if (!DialogueRules72.empty(var3)) {
               List var4 = DialogueRules72.copies(DialogueRules72.bag(var0));
               List var5 = DialogueRules72.copies(var4);
               if (DialogueRules72.insert(var5, new ArrayList<>(List.of(DialogueRules72.copy(var3))), false)) {
                  c(CalmLoot.class, "saveBag", var0, var5);

                  try {
                     c(var1, "setItem", c(var3, "copyWithCount", 0));
                  } catch (Exception var7) {
                     c(CalmLoot.class, "saveBag", var0, var4);
                     throw var7;
                  }

                  c(var1, "discard");
               }
            }
         }
      }
   }

   static boolean container(Object var0, Object var1) {
      if (!Shelter77.loaded(var0, var1)) {
         return false;
      } else {
         Object var2 = c(var0, "getBlockEntity", var1);
         return var2 != null && Social.t("net.minecraft.world.Container").isInstance(var2);
      }
   }

   static Object findDepot(Object var0, Object var1) {
      Object var2 = Social.world(var0);
      int var3 = 0;

      for (int var4 = -4; var4 <= 4; var4++) {
         for (int var5 = -4; var5 <= 4; var5++) {
            Object var6 = Shelter77.offset(var1, var4, 0, var5);
            if (container(var2, var6) && Shelter77.permitted(var0, var6)) {
               Object var7 = c(var2, "getBlockEntity", var6);
               if (!Social.yes(c(c(var7, "getPersistentData"), "getBoolean", "QuietlyPlayerPlaced"))) {
                  if (++var3 > 2) {
                     return null;
                  }

                  if (approach(var0, var6) != null) {
                     return var6;
                  }
               }
            }
         }
      }

      return null;
   }

   static boolean prepareChest(Object var0, Hunt78.Run var1) {
      if (!Shelter77.grief(var0)) {
         restBlocked(var0, var1);
         return false;
      } else {
         List var2 = DialogueRules72.bag(var0);
         if (Shelter77.count(var2, "minecraft:chest") == 0) {
            if (Shelter77.planks(var2) < 8) {
               if (Shelter77.craft(var0, false)) {
                  return false;
               }

               if (var1.gathering == null) {
                  var1.gathering = new Shelter77.Camp(
                     Shelter77.axis(var1.home, "getX"), Shelter77.axis(var1.home, "getY"), Shelter77.axis(var1.home, "getZ"), 2
                  );
               }

               Shelter77.Camp var30 = var1.gathering;
               long var31 = Social.time(var0);
               if (var31 < var30.next) {
                  // FIX: respetar la pausa/desplazamiento que fijo gather() en vez de reescanear cada 20 ticks.
                  if (var30.wait) {
                     restBlocked(var0, var1, Math.max(20L, var30.next - var31));
                  }

                  return false;
               }

               var1.gathering.wait = false;
               Shelter77.gather(var0, var1.gathering);
               if (var1.gathering.giveUp) {
                  // FIX bucle: sin salida terminal el deposito reintentaba la recoleccion cada 200 ticks para siempre.
                  var1.gathering = null;
                  var1.depotFails++;
                  restBlocked(var0, var1, (long)(6000 << Math.min(var1.depotFails - 1, 3)));
                  c(Social.tag(var0), "putString", "npc78_actividad", "deposito_sin_madera");
               } else if (var1.gathering.wait) {
                  restBlocked(var0, var1);
               }

               return false;
            }

            if (!craftChest(var0)) {
               return false;
            }
         }

         Object var3 = null;

         int[][] var7;
         for (int[] var4 : var7 = new int[][]{{0, 1}, {1, 0}, {-1, 0}, {0, -1}}) {
            Object var8 = Shelter77.offset(var1.home, var4[0], 0, var4[1]);
            if (Shelter77.loaded(Social.world(var0), var8)
               && Shelter77.permitted(var0, var8)
               && Shelter77.air(Social.world(var0), var8)
               && !Shelter77.occupied(Social.world(var0), var8)) {
               var3 = var8;
               break;
            }
         }

         if (var3 == null) {
            restBlocked(var0, var1);
            return false;
         } else if (distance(var0, var3) > 9.0) {
            move(var0, var1.home);
            return false;
         } else if (Shelter77.placeItem(var0, var3, "minecraft:chest")) {
            var1.depot = var3;
            return true;
         } else {
            return false;
         }
      }
   }

   static void restBlocked(Object var0, Hunt78.Run var1) {
      restBlocked(var0, var1, 200L);
   }

   static void restBlocked(Object var0, Hunt78.Run var1, long var2) {
      var1.phase = "descansar";
      var1.next = Social.time(var0) + var2;
      Social.mem(var0).occupied = false;
      c(Social.tag(var0), "putString", "npc78_actividad", "deposito_bloqueado");
   }

   static boolean craftChest(Object var0) {
      List var1 = DialogueRules72.copies(DialogueRules72.bag(var0));
      ArrayList var2 = new ArrayList();

      for (int var3 = 0; var3 < 9; var3++) {
         if (var3 == 4) {
            var2.add(Shelter77.item("minecraft:air", 0));
         } else {
            Object var4 = null;

            for (Object var5 : var1) {
               if (!DialogueRules72.empty(var5) && DialogueRules72.itemId(var5).endsWith("_planks")) {
                  var4 = var5;
                  break;
               }
            }

            if (var4 == null) {
               return false;
            }

            var2.add(c(var4, "copyWithCount", 1));
            c(var4, "shrink", 1);
         }
      }

      Object var7 = c(Social.t("net.minecraft.world.item.crafting.CraftingInput"), "of", 3, 3, var2);
      Optional var8 = (Optional)c(
         c(Social.world(var0), "getRecipeManager"),
         "getRecipeFor",
         SocialR.get(Social.t("net.minecraft.world.item.crafting.RecipeType"), "CRAFTING"),
         var7,
         Social.world(var0)
      );
      if (var8.isEmpty()) {
         return false;
      } else {
         Object var9 = c(c(var8.get(), "value"), "assemble", var7, c(Social.world(var0), "registryAccess"));
         if (!DialogueRules72.itemId(var9).equals("minecraft:chest")) {
            return false;
         } else {
            var1.removeIf(DialogueRules72::empty);
            if (!DialogueRules72.insert(var1, new ArrayList<>(List.of(var9)), false)) {
               return false;
            } else {
               c(CalmLoot.class, "saveBag", var0, var1);
               Shelter77.swing(var0);
               return true;
            }
         }
      }
   }

   static boolean insert(List<Object> var0, Object var1) {
      for (Object var2 : var0) {
         if (!DialogueRules72.empty(var2) && Social.yes(c(Social.t("net.minecraft.world.item.ItemStack"), "isSameItemSameComponents", var2, var1))) {
            int var4 = Math.min(((Number)c(var2, "getMaxStackSize")).intValue() - DialogueRules72.size(var2), DialogueRules72.size(var1));
            if (var4 > 0) {
               c(var2, "grow", var4);
               c(var1, "shrink", var4);
            }
         }
      }

      for (int var5 = 0; var5 < var0.size() && !DialogueRules72.empty(var1); var5++) {
         if (DialogueRules72.empty(var0.get(var5))) {
            int var6 = Math.min(((Number)c(var1, "getMaxStackSize")).intValue(), DialogueRules72.size(var1));
            var0.set(var5, c(var1, "copyWithCount", var6));
            c(var1, "shrink", var6);
         }
      }

      return DialogueRules72.empty(var1);
   }

   static void deposit(Object var0, Object var1) {
      Object var2 = c(Social.world(var0), "getBlockEntity", var1);
      if (var2 != null && Shelter77.permitted(var0, var1)) {
         int var3 = ((Number)c(var2, "getContainerSize")).intValue();
         if (var3 >= 1 && var3 <= 128) {
            ArrayList var4 = new ArrayList();

            for (int var5 = 0; var5 < var3; var5++) {
               var4.add(DialogueRules72.copy(c(var2, "getItem", var5)));
            }

            List var18 = DialogueRules72.copies(var4);
            List var6 = DialogueRules72.copies(DialogueRules72.bag(var0));
            HashMap<String, Integer> var7 = new HashMap<>();
            boolean var8 = false;

            for (Object var9 : var6) {
               if (!DialogueRules72.empty(var9)) {
                  String var11 = DialogueRules72.itemId(var9);
                  int var12 = Inventory79.equipment(var11)
                     ? DialogueRules72.size(var9)
                     : (
                        var11.contains("bandage")
                           ? 2
                           : (var11.contains("ammo") ? 64 : (Activity78.hasCategory(var9, "comida") ? 4 : (var11.endsWith("_planks") ? 4 : 0)))
                     );
                  int var13 = Math.max(0, var12 - var7.getOrDefault(var11, 0));
                  int var14 = Math.min(var13, DialogueRules72.size(var9));
                  var7.merge(var11, var14, Integer::sum);
                  int var15 = DialogueRules72.size(var9) - var14;
                  if (var15 > 0) {
                     List var16 = DialogueRules72.copies(var18);
                     if (insert(var16, c(var9, "copyWithCount", var15))) {
                        var18 = var16;
                        c(var9, "shrink", var15);
                        var8 = true;
                     }
                  }
               }
            }

            if (var8) {
               try {
                  for (int var19 = 0; var19 < var3; var19++) {
                     c(var2, "setItem", var19, var18.get(var19));
                  }

                  c(CalmLoot.class, "saveBag", var0, var6);
                  c(var2, "setChanged");
               } catch (Exception var17) {
                  for (int var20 = 0; var20 < var3; var20++) {
                     c(var2, "setItem", var20, var4.get(var20));
                  }

                  throw var17;
               }
            }
         }
      }
   }

   static void failure(Object var0, Exception var1) {
      Hunt78.Run var2 = RUNS.get(var0);
      if (var2 != null) {
         var2.next = Social.time(var0) + 200L;
      }

      c(Social.tag(var0), "putString", "npc78_actividad", "caza_bloqueada");
      if (WARN.add(var0)) {
         Social.warn("local hunt and depot", var1);
      }
   }

   static void validate(JsonObject var0) {
      DialogueData71.only(var0, "activa", "radio_caza", "radio_base", "max_zombies", "persecucion_ticks", "botin_ticks", "descanso_ticks");
      if (!var0.get("activa").getAsJsonPrimitive().isBoolean()) {
         throw new IllegalArgumentException("caza.activa");
      } else {
         DialogueData71.integer(var0.get("radio_caza"), 8, 24);
         DialogueData71.integer(var0.get("radio_base"), 16, 48);
         DialogueData71.integer(var0.get("max_zombies"), 1, 5);

         for (String var1 : List.of("persecucion_ticks", "botin_ticks", "descanso_ticks")) {
            DialogueData71.integer(var0.get(var1), 100, 2400);
         }
      }
   }

   static class Run {
      String phase = "deposito";
      Object home;
      Object depot;
      WeakReference<Object> target;
      double x;
      double y;
      double z;
      long next;
      long until;
      Shelter77.Camp gathering;
      int depotFails;
   }
}
