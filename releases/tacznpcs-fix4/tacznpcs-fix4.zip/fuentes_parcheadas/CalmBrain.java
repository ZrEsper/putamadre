package mod.cdv.tnpc.tactical;

import dev.zomboid.npcprobe.Probe;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.function.Predicate;
import java.util.function.Supplier;

public final class CalmBrain {
   static final Map<Object, CalmBrain.State> STATES = Collections.synchronizedMap(new WeakHashMap<>());
   private static final Set<String> ERRORS = new HashSet<>();

   static CalmBrain.State state(Object var0) {
      return STATES.computeIfAbsent(var0, var0x -> new CalmBrain.State());
   }

   static void error(String var0, Exception var1) {
      synchronized (ERRORS) {
         if (ERRORS.add(var0)) {
            System.err.println("[TacZ NPCs Calm] " + var0 + ": " + var1);
         }
      }
   }

   static boolean bandit(Object var0) throws Exception {
      String var1 = String.valueOf(Reflect.field(var0, "templateId")).toLowerCase(Locale.ROOT);
      if (!var1.contains("bandit") && !var1.contains("illager")) {
         Object var2 = Reflect.call(var0, "getTemplate");
         return var2 != null && ((Set)Reflect.call(var2, "opposed")).contains("players");
      } else {
         return true;
      }
   }

   public static boolean managed(Object var0) {
      CalmBrain.State var1 = STATES.get(var0);
      return var1 != null && var1.installed;
   }

   static long now(Object var0) throws Exception {
      return ((Number)Reflect.call(Reflect.call(var0, "level"), "getGameTime")).longValue();
   }

   static boolean alive(Object var0) throws Exception {
      if (var0 != null && Reflect.yes(Reflect.call(var0, "isAlive"))) {
         return !Reflect.type("net.minecraft.world.entity.player.Player").isInstance(var0)
            ? true
            : !Reflect.yes(Reflect.call(var0, "isCreative")) && !Reflect.yes(Reflect.call(var0, "isSpectator"));
      } else {
         return false;
      }
   }

   static boolean visible(Object var0, Object var1) throws Exception {
      return TeamBrain.vision(Reflect.yes(Reflect.call(Reflect.call(var0, "getSensing"), "hasLineOfSight", var1)), var0, var1);
   }

   static double distance(Object var0, Object var1) throws Exception {
      double var2 = Reflect.coord(var0, "X") - Reflect.coord(var1, "X");
      double var4 = Reflect.coord(var0, "Y") - Reflect.coord(var1, "Y");
      double var6 = Reflect.coord(var0, "Z") - Reflect.coord(var1, "Z");
      return var2 * var2 + var4 * var4 + var6 * var6;
   }

   static List<?> nearby(Object var0, String var1, double var2) throws Exception {
      Object var4 = Reflect.call(Reflect.call(var0, "getBoundingBox"), "inflate", var2);
      return (List<?>)Reflect.call(Reflect.call(var0, "level"), "getEntitiesOfClass", Reflect.type(var1), var4);
   }

   static boolean gun(Object var0) throws Exception {
      Object var1 = Reflect.call(Reflect.call(var0, "getMainHandItem"), "getItem");
      return Reflect.type("com.tacz.guns.api.item.IGun").isInstance(var1);
   }

   static boolean allied(Object var0, Object var1) throws Exception {
      return Reflect.type("mod.cdv.tnpc.entity.AutoGunOperator").isInstance(var1)
         && (bandit(var0) && bandit(var1) || Reflect.yes(Reflect.call(var0, "isAlliedTo", var1)));
   }

   public static void tick(Object var0) {
      Authority70.tick(var0);

      label26: {
         try {
            if (Reflect.yes(Reflect.call(Reflect.call(var0, "level"), "isClientSide")) || !Social.controlAll(var0)) {
               break label26;
            }

            CalmBrain.State var1 = state(var0);
            if (!var1.installed) {
               Object var2 = Reflect.field(var0, "goalSelector");
               Object var3 = Reflect.field(var0, "targetSelector");
               Reflect.call(var2, "removeAllGoals", (Predicate<Object>)var0x -> !var0x.getClass().getSimpleName().equals("FloatGoal"));
               Reflect.call(var3, "removeAllGoals", (Predicate<Object>)var0x -> true);
               Reflect.call(var2, "addGoal", 1, new CalmGoal(var0));
               Reflect.call(Reflect.call(var0, "getNavigation"), "setCanFloat", true);
               Reflect.call(var2, "addGoal", 2, new VanillaGunGoal(var0));
               Reflect.call(var2, "addGoal", 3, new WaterRecoveryGoal(var0));
               Reflect.call(var2, "addGoal", 4, Reflect.construct("net.minecraft.world.entity.ai.goal.MeleeAttackGoal", var0, 1.1, true));
               Reflect.call(var2, "addGoal", 5, new ScavengeGoal(var0));
               Reflect.call(var2, "addGoal", 6, Reflect.construct("net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal", var0, 0.85));
               Reflect.call(
                  var2,
                  "addGoal",
                  7,
                  Reflect.construct("net.minecraft.world.entity.ai.goal.LookAtPlayerGoal", var0, Reflect.type("net.minecraft.world.entity.player.Player"), 8.0F)
               );
               Reflect.call(var2, "addGoal", 8, Reflect.construct("net.minecraft.world.entity.ai.goal.RandomLookAroundGoal", var0));
               Social.install(var0);
               // FIX puertas: removeAllGoals borra el OpenDoorGoal que Navigation78.init ya habia añadido
               // (Authority70.tick -> Events76.tick -> Navigation78.tick corre ANTES de este bloque).
               Navigation78.INIT.remove(var0);
               Navigation78.init(var0);
               var1.installed = true;
            }

            CalmLoot.outfit(var0, var1.random);
            Object var5 = Reflect.call(
               var0, "getAttribute", Reflect.field(Reflect.type("net.minecraft.world.entity.ai.attributes.Attributes"), "MOVEMENT_SPEED")
            );
            Reflect.call(var5, "setBaseValue", 0.3);
            clearGunSlowdown(var5);
            Reflect.call(var0, "setSprinting", var1.sprint);
         } catch (Exception var4) {
            error("install/speed", var4);
         }

         TeamBrain.tick(var0);
         StarterGear.tick(var0);
         Social.tick(var0);
         return;
      }

      TeamBrain.tick(var0);
      StarterGear.tick(var0);
      Social.tick(var0);
   }

   static void crouch(Object var0, boolean var1) throws Exception {
      if (var1 && Reflect.yes(Reflect.call(var0, "isInWater"))) {
         var1 = false;
      }

      Reflect.call(var0, "setShiftKeyDown", var1);
      String var2 = String.valueOf(Reflect.call(var0, "getPose"));
      if (var2.equals("STANDING") || var2.equals("CROUCHING")) {
         Reflect.call(var0, "setPose", Reflect.field(Reflect.type("net.minecraft.world.entity.Pose"), var1 ? "CROUCHING" : "STANDING"));
      }
   }

   public static void stop(Object var0) {
      try {
         Reflect.call(Reflect.call(var0, "getNavigation"), "stop");
         crouch(var0, false);
         Reflect.call(var0, "setTarget", null);
      } catch (Exception var2) {
         error("stop", var2);
      }
   }

   static void path(Object var0, CalmBrain.State var1, long var2, double var4, double var6, double var8, double var10) throws Exception {
      if (!Navigation78.regular(var0, var4, var6, var8, var10)) {
         if (var2 >= var1.nextPath) {
            var1.nextPath = var2 + 10L;
            Object var12 = Reflect.call(var0, "getNavigation");
            boolean var13 = Reflect.yes(Reflect.call(var12, "moveTo", var4, var6, var8, Math.min(1.15, Math.max(0.95, var10))));
            if (!var13 && Reflect.yes(Reflect.call(var0, "isInWater"))) {
               Reflect.call(Reflect.call(var0, "getMoveControl"), "setWantedPosition", var4, var6, var8, 1.0);
            }
         }
      }
   }

   static void acquire(Object var0, CalmBrain.State var1, long var2, boolean var4) throws Exception {
      Social.acquire(var0, var1, var2, var4);
   }

   public static void control(Object var0) {
      if (!Social.pause(var0)) {
         if (!Social.pause(var0)) {
            try {
               if (!Reflect.yes(Reflect.call(var0, "isAlive"))) {
                  return;
               }

               CalmBrain.State var1 = state(var0);
               long var2 = now(var0);
               boolean var4 = gun(var0);
               var1.tier = CalmLoot.tier(var0, var4);
               if (var2 >= var1.nextDecision) {
                  var1.nextDecision = var2 + Authority70.interval(var0);
                  acquire(var0, var1, var2, var4);
               }

               Object var5 = var1.target;
               if (!alive(var5) || allied(var0, var5)) {
                  var1.target = null;
                  var5 = null;
               }

               var1.sprint = false;
               if (var5 == null) {
                  Reflect.call(var0, "setTarget", null);
                  Reflect.call(var0, "setAggressive", false);
                  Reflect.call(var0, "aim", false);
                  CalmLoot.search(var0, var1, var2);
                  return;
               }

               CalmLoot.release(var0, var1);
               crouch(var0, false);
               boolean var6 = visible(var0, var5);
               if (var6) {
                  var1.x = Reflect.coord(var5, "X");
                  var1.y = Reflect.coord(var5, "Y");
                  var1.z = Reflect.coord(var5, "Z");
                  var1.seen = var2;
                  Reflect.call(var0, "setTarget", var5);
                  Reflect.call(var0, "setAggressive", true);
                  var1.sprint = distance(var0, var5) > (double)(var4 ? 324 : 16);
               } else {
                  Reflect.call(var0, "setTarget", null);
                  Reflect.call(var0, "aim", false);
                  if (var1.seen < 0L || var2 - var1.seen > 80L) {
                     var1.target = null;
                     return;
                  }
               }
            } catch (Exception var7) {
               error("decisions", var7);
            }
         }
      }
   }

   public static void rangedAttack(Object var0, Object var1, float var2) {
      if (!Social.blockPlayerAttack(var0, var1)) {
         label73: {
            label72: {
               label71: {
                  try {
                     CalmBrain.State var3 = state(var0);
                     long var4 = now(var0);
                     if (var1 != var3.target || !gun(var0) || !alive(var1) || !visible(var0, var1) || var4 < var3.reactAt || var4 < var3.nextShot) {
                        break label73;
                     }

                     double var6 = Math.sqrt(distance(var0, var1));
                     double var8 = face(var0, var1);
                     if (var6 > 24.0 || var8 > 15.0 || allyInLine(var0, var1)) {
                        break label72;
                     }

                     String var10 = String.valueOf(Reflect.field(Reflect.call(var0, "getDataHolder"), "reloadStateType"));
                     if (!var10.equals("NOT_RELOADING") && !var10.endsWith("FINISHING")) {
                        break label71;
                     }

                     double[] var11 = aim(var0);
                     Reflect.call(var0, "aim", true);
                     Object var10000 = Reflect.call(var0, "shoot", (Supplier<Float>)() -> (float)var11[0], (Supplier<Float>)() -> (float)var11[1]);
                     TeamBrain.shot(var0, var10000);
                     Object var12 = var10000;
                     String var13 = String.valueOf(var12);
                     if (var13.equals("NOT_DRAW")) {
                        Reflect.call(var0, "draw", (Supplier<Object>)() -> {
                           try {
                              return Reflect.call(var0, "getMainHandItem");
                           } catch (Exception var2x) {
                              throw new IllegalStateException(var2x);
                           }
                        });
                     } else if (var13.equals("NO_AMMO")) {
                        Reflect.call(var0, "reload");
                     } else if (var13.equals("NEED_BOLT")) {
                        Reflect.call(var0, "bolt");
                     }

                     var3.nextShot = var4 + (long)(var13.equals("SUCCESS") ? CalmRules.shotPause(var3.tier) + var3.random.nextInt(5) : 5);
                  } catch (Exception var14) {
                     error("ranged attack", var14);
                  }

                  TeamBrain.cadence(var0);
                  return;
               }

               TeamBrain.cadence(var0);
               return;
            }

            TeamBrain.cadence(var0);
            return;
         }

         TeamBrain.cadence(var0);
      }
   }

   static void clearGunSlowdown(Object var0) throws Exception {
      Class var1;
      try {
         var1 = Reflect.type("com.tacz.guns.entity.shooter.LivingEntitySpeedModifier");
      } catch (ClassNotFoundException var6) {
         return;
      }

      Field[] var5;
      for (Field var2 : var5 = var1.getDeclaredFields()) {
         if (Modifier.isStatic(var2.getModifiers())
            && (var2.getName().startsWith("EXTRA_SPEED_MODIFIER") || var2.getName().startsWith("WEIGHT_SPEED_MODIFIER"))) {
            var2.setAccessible(true);
            Reflect.call(var0, "removeModifier", var2.get(null));
         }
      }
   }

   public static boolean nativePickupAllowed(Object var0) {
      return !managed(var0);
   }

   static double face(Object var0, Object var1) throws Exception {
      return Combat26.face(var0, var1);
   }

   public static boolean allyInLine(Object var0, Object var1) throws Exception {
      double var2 = Reflect.coord(var0, "X");
      double var4 = Reflect.number(Reflect.call(var0, "getEyeY"));
      double var6 = Reflect.coord(var0, "Z");
      double var8 = Reflect.coord(var1, "X");
      double var10 = Reflect.coord(var1, "Y") + Reflect.number(Reflect.call(var1, "getBbHeight")) * 0.52;
      double var12 = Reflect.coord(var1, "Z");

      for (Object var14 : nearby(var0, "mod.cdv.tnpc.entity.AutoGunOperator", 32.0)) {
         if (var14 != var0
            && alive(var14)
            && allied(var0, var14)
            && CalmRules.hitAlly(
               var2,
               var4,
               var6,
               var8,
               var10,
               var12,
               Reflect.coord(var14, "X"),
               Reflect.coord(var14, "Y") + Reflect.number(Reflect.call(var14, "getBbHeight")) * 0.55,
               Reflect.coord(var14, "Z"),
               1.0
            )) {
            return true;
         }
      }

      return false;
   }

   public static boolean ignoreDamage(Object var0, Object var1) {
      if (Probe.marked(var0)) {
         return false;
      } else {
         try {
            Object var2 = Reflect.call(var1, "getEntity");
            return var2 != null && var2 != var0 && bandit(var0) && allied(var0, var2);
         } catch (Exception var3) {
            error("friendly fire", var3);
            return false;
         }
      }
   }

   public static double[] aim(Object var0) throws Exception {
      Object var1 = state(var0).target;
      if (var1 == null) {
         var1 = Reflect.call(var0, "getTarget");
      }

      if (var1 == null) {
         return TeamBrain.playerAim(
            new double[]{Reflect.number(Reflect.call(var0, "getViewXRot", 1.0F)), Reflect.number(Reflect.call(var0, "getViewYRot", 1.0F))}, var0
         );
      } else {
         double var2 = Reflect.coord(var1, "X") - Reflect.coord(var0, "X");
         double var4 = Reflect.coord(var1, "Z") - Reflect.coord(var0, "Z");
         double var6 = Math.hypot(var2, var4);
         double var8 = Reflect.coord(var1, "Y") + Reflect.number(Reflect.call(var1, "getBbHeight")) * 0.52;
         Random var10 = new Random(((Number)Reflect.call(var0, "getId")).longValue() * 341873128712L + now(var0) * 132897987541L);
         double var11 = CalmRules.dispersion(state(var0).tier, var6);
         return TeamBrain.playerAim(
            new double[]{
               -Math.toDegrees(Math.atan2(var8 - Reflect.number(Reflect.call(var0, "getEyeY")), Math.max(0.1, var6))) + var10.nextGaussian() * var11,
               Math.toDegrees(Math.atan2(var4, var2)) - 90.0 + var10.nextGaussian() * var11
            },
            var0
         );
      }
   }

   public static Object legacyCall(Object var0, String var1, Object[] var2) throws Exception {
      return var1.equals("isSpectator") && var2.length == 0 && Reflect.type("net.minecraft.world.entity.player.Player").isInstance(var0)
         ? !alive(var0)
         : Reflect.call(var0, var1, var2);
   }

   public static boolean spawnAllowed(Object var0) {
      try {
         Object var1 = Reflect.call(var0, "getLevel");
         return !Reflect.yes(Reflect.call(var1, "isClientSide"))
            && !String.valueOf(Reflect.call(var1, "getDifficulty")).equalsIgnoreCase("PEACEFUL")
            && Reflect.yes(
               Reflect.call(
                  Reflect.call(var1, "getGameRules"), "getBoolean", Reflect.field(Reflect.type("net.minecraft.world.level.GameRules"), "RULE_DOMOBSPAWNING")
               )
            );
      } catch (Exception var2) {
         error("spawn conditions", var2);
         return false;
      }
   }

   public static void clientPose(Object var0, Object var1) {
      try {
         for (String var2 : List.of("attackAnim", "oAttackAnim")) {
            Field var4 = Reflect.type("net.minecraft.world.entity.LivingEntity").getDeclaredField(var2);
            var4.setAccessible(true);
            var4.setFloat(var1, var4.getFloat(var0));
         }
      } catch (Exception var5) {
         error("swing animation", var5);
      }

      Social.pose(var0, var1);
   }

   static final class State {
      boolean installed;
      boolean sprint;
      Object target;
      long seen = -1L;
      long reactAt;
      long nextDecision;
      long nextPath;
      long nextShot;
      long nextIdle;
      long nextLoot;
      double x;
      double y;
      double z;
      int tier;
      int zombies;
      Object corpse;
      long lootStart = Long.MIN_VALUE;
      long lootApproach = Long.MIN_VALUE;
      double corpseX;
      double corpseY;
      double corpseZ;
      final Random random = new Random();
   }
}
