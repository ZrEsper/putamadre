package mod.cdv.tnpc.tactical;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.Map.Entry;

public final class Shelter77 {
   static final String KEY = "npc77_refugio";
   static final Map<Object, Shelter77.Camp> CACHE = new WeakHashMap<>();
   static final Set<Object> WARN = Collections.newSetFromMap(new WeakHashMap<>());
   static Boolean seasons;
   static final Map<Object, Shelter77.Camp> HELP = new WeakHashMap<>();

   static Object c(Object var0, String var1, Object... var2) {
      return Social.c(var0, var1, var2);
   }

   static JsonObject cfg() {
      return DialogueData71.DATA.getAsJsonObject("refugios");
   }

   static int num(String var0) {
      return cfg().get(var0).getAsInt();
   }

   static Object pos(int var0, int var1, int var2) {
      return SocialR.make("net.minecraft.core.BlockPos", var0, var1, var2);
   }

   static int axis(Object var0, String var1) {
      return ((Number)c(var0, var1)).intValue();
   }

   static Object offset(Object var0, int var1, int var2, int var3) {
      return pos(axis(var0, "getX") + var1, axis(var0, "getY") + var2, axis(var0, "getZ") + var3);
   }

   static boolean loaded(Object var0, Object var1) {
      return Social.yes(c(var0, "hasChunkAt", var1));
   }

   static Object state(Object var0, Object var1) {
      if (!loaded(var0, var1)) {
         throw new IllegalStateException("chunk no cargado");
      } else {
         return c(var0, "getBlockState", var1);
      }
   }

   static String id(Object var0) {
      return c(SocialR.get(Social.t("net.minecraft.core.registries.BuiltInRegistries"), "BLOCK"), "getKey", c(var0, "getBlock")).toString();
   }

   static Object registry(String var0, String var1) {
      return c(
         SocialR.get(Social.t("net.minecraft.core.registries.BuiltInRegistries"), var0),
         "get",
         c(Social.t("net.minecraft.resources.ResourceLocation"), "parse", var1)
      );
   }

   static Object item(String var0, int var1) {
      return SocialR.make("net.minecraft.world.item.ItemStack", registry("ITEM", var0), var1);
   }

   static boolean air(Object var0, Object var1) {
      return Social.yes(c(state(var0, var1), "isAir")) && Social.yes(c(c(var0, "getFluidState", var1), "isEmpty"));
   }

   static boolean safe(Object var0) {
      long var1 = Social.time(var0);
      return !Social.client(var0)
         && Authority70.enabled(var0)
         && Social.alive(var0)
         && !Downed20.down(var0)
         && !Ambush73.hidden(var0)
         && !Motion76.conversing(var0)
         && !Ambient78.active(var0)
         && !Events76.approaching(var0)
         && CalmBrain.state(var0).target == null
         && Social.mem(var0).threats == 0
         && Social.mem(var0).medicalUntil <= var1
         && Social.mem(var0).fearUntil <= var1
         && Social.s(Social.tag(var0), "soc_owner").isBlank();
   }

   static boolean permitted(Object var0, Object var1) {
      return loaded(Social.world(var0), var1) && Social.yes(c(Social.t("mod.cdv.tnpc.tactical.Tasks"), "permitted", var0, var1));
   }

   static boolean grief(Object var0) {
      return Social.yes(c(Social.t("net.neoforged.neoforge.event.EventHooks"), "canEntityGrief", Social.world(var0), var0));
   }

   static boolean exposed(Object var0) {
      Object var1 = Social.world(var0);
      Object var2 = c(var0, "blockPosition");
      return Social.yes(c(var1, "canSeeSky", offset(var2, 0, 1, 0)));
   }

   static double temperature(Object var0) {
      Object var1 = Social.world(var0);
      Object var2 = c(var0, "blockPosition");
      Object var3 = c(var1, "getBiome", var2);
      if (seasons == null) {
         try {
            Class.forName("sereneseasons.season.SeasonHooks");
            seasons = true;
         } catch (ClassNotFoundException var4) {
            seasons = false;
         }
      }

      return seasons
         ? Social.num(c(Social.t("sereneseasons.season.SeasonHooks"), "getBiomeTemperature", var1, var3, var2))
         : Social.num(c(c(var3, "value"), "getTemperature", var2));
   }

   static String need(Object var0) {
      if (!exposed(var0)) {
         return null;
      } else {
         Object var1 = Social.world(var0);
         if (Social.yes(c(var1, "isRainingAt", c(var0, "blockPosition")))) {
            return "lluvia";
         } else {
            double var2 = temperature(var0);
            if (var2 <= cfg().get("frio_bioma").getAsDouble()) {
               return "frio";
            } else if (var2 >= cfg().get("calor_bioma").getAsDouble()) {
               return "calor";
            } else {
               long var4 = ((Number)c(var1, "getDayTime")).longValue() % 24000L;
               return var4 >= 12500L && var4 <= 23000L ? "noche" : null;
            }
         }
      }
   }

   static Shelter77.Camp get(Object var0) {
      if (CACHE.containsKey(var0)) {
         return CACHE.get(var0);
      } else {
         String var1 = Social.s(Social.tag(var0), "npc77_refugio");
         if (var1.isBlank()) {
            return null;
         } else {
            JsonObject var2 = JsonParser.parseString(var1).getAsJsonObject();
            Shelter77.Camp var3 = new Shelter77.Camp(var2.get("x").getAsInt(), var2.get("y").getAsInt(), var2.get("z").getAsInt(), var2.get("size").getAsInt());
            if (var3.size != 2 && var3.size != 4) {
               throw new IllegalArgumentException("camp size");
            } else {
               var3.index = var2.get("index").getAsInt();
               var3.phase = var2.get("phase").getAsString();
               var3.until = var2.get("until").getAsLong();
               var3.reason = var2.get("reason").getAsString();
               var3.fails = var2.has("fails") ? var2.get("fails").getAsInt() : 0;
               if (var3.index >= 0 && var3.index <= var3.cells.size()) {
                  CACHE.put(var0, var3);
                  return var3;
               } else {
                  throw new IllegalArgumentException("camp index");
               }
            }
         }
      }
   }

   static void save(Object var0, Shelter77.Camp var1) {
      CACHE.put(var0, var1);
      JsonObject var2 = new JsonObject();
      var2.addProperty("x", var1.x);
      var2.addProperty("y", var1.y);
      var2.addProperty("z", var1.z);
      var2.addProperty("size", var1.size);
      var2.addProperty("index", var1.index);
      var2.addProperty("phase", var1.phase);
      var2.addProperty("until", var1.until);
      var2.addProperty("reason", var1.reason);
      var2.addProperty("fails", var1.fails);
      c(Social.tag(var0), "putString", "npc77_refugio", var2.toString());
   }

   public static void tick(Object var0) {
      try {
         if (!cfg().get("activos").getAsBoolean() || !safe(var0) || get(var0) != null || !Social.s(Social.tag(var0), "npc77_refugio_lider").isBlank()) {
            return;
         }

         long var1 = Social.time(var0);
         if (var1 < Social.l(Social.tag(var0), "npc77_refugio_despues")
            || Math.floorMod(var1 + (long)Social.uuid(var0).hashCode(), num("intervalo_ticks")) != 0) {
            return;
         }

         String var3 = need(var0);
         if (var3 == null) {
            if (Social.time(var0) < Social.l(Social.tag(var0), "npc79_asentarse") || Hunt78.point(var0, "npc78_home") != null) {
               return;
            }

            var3 = "asentarse";
         }

         if (Activity78.cover(var0, var3)) {
            return;
         }

         if (!grief(var0)) {
            status(var0, "mobGriefing/proteccion");
            return;
         }

         List var4 = group(var0);
         int var5 = var4.size() > 1 ? 4 : 2;
         Object var6 = c(var0, "blockPosition");
         int var7 = (int)Social.l(Social.tag(var0), "npc77_sitio");
         int[][] var8 = new int[][]{{4, 0}, {-7, 0}, {0, 4}, {0, -7}, {5, 5}, {-8, 5}, {5, -8}, {-8, -8}};

         for (int var9 = 0; var9 < 2; var9++) {
            int[] var10 = var8[Math.floorMod(var7++, var8.length)];
            Shelter77.Camp var11 = new Shelter77.Camp(axis(var6, "getX") + var10[0], axis(var6, "getY"), axis(var6, "getZ") + var10[1], var5);
            if (site(var0, var11)) {
               var11.reason = var3;
               var11.until = var1 + (long)num("max_tiempo_trabajo_ticks");
               save(var0, var11);

               for (Object var12 : var4) {
                  if (var12 != var0) {
                     c(Social.tag(var12), "putString", "npc77_refugio_lider", Social.uuid(var0).toString());
                  }
               }

               status(var0, "reunir_materiales");
               break;
            }
         }

         c(Social.tag(var0), "putLong", "npc77_sitio", (long)var7);
         c(Social.tag(var0), "putLong", "npc77_refugio_despues", var1 + (long)num("reintento_ticks"));
      } catch (Exception var14) {
         failure(var0, var14);
      }
   }

   static void status(Object var0, String var1) {
      c(Social.tag(var0), "putString", "npc77_refugio_estado", var1);
   }

   static List<Object> group(Object var0) {
      ArrayList var1 = new ArrayList();
      var1.add(var0);

      for (Object var2 : Social.nearby(var0, "mod.cdv.tnpc.entity.AutoGunOperator", (double)num("radio_grupo"))) {
         if (var1.size() >= 4) {
            break;
         }

         if (var2 != var0
            && safe(var2)
            && get(var2) == null
            && Social.s(Social.tag(var2), "npc77_refugio_lider").isBlank()
            && Social.kind(var2) == Social.kind(var0)
            && Social.s(Social.tag(var0), "soc_enemy").isBlank()
            && Social.s(Social.tag(var2), "soc_enemy").isBlank()) {
            var1.add(var2);
         }
      }

      return var1;
   }

   static boolean site(Object var0, Shelter77.Camp var1) {
      Object var2 = Social.world(var0);

      for (Object var3 : Social.nearby(var0, "mod.cdv.tnpc.entity.AutoGunOperator", 32.0)) {
         get(var3);
      }

      for (Entry var7 : CACHE.entrySet()) {
         Shelter77.Camp var5 = (Shelter77.Camp)var7.getValue();
         if (var7.getKey() != var0
            && Social.world(var7.getKey()) == var2
            && Math.abs(var1.y - var5.y) < 4
            && var1.x - 2 <= var5.x + var5.size + 1
            && var1.x + var1.size + 1 >= var5.x - 2
            && var1.z - 2 <= var5.z + var5.size + 1
            && var1.z + var1.size + 1 >= var5.z - 2) {
            return false;
         }
      }

      for (int var8 = -1; var8 <= var1.size; var8++) {
         for (int var11 = -1; var11 <= var1.size; var11++) {
            Object var13 = pos(var1.x + var8, var1.y - 1, var1.z + var11);
            if (!loaded(var2, var13)
               || !permitted(var0, var13)
               || c(var2, "getBlockEntity", var13) != null
               || !Social.yes(c(state(var2, var13), "isFaceSturdy", var2, var13, SocialR.get(Social.t("net.minecraft.core.Direction"), "UP")))) {
               return false;
            }

            for (int var6 = 0; var6 < 3; var6++) {
               if (!air(var2, offset(var13, 0, var6 + 1, 0))) {
                  return false;
               }
            }
         }
      }

      for (Shelter77.Cell var9 : var1.cells) {
         Object var14 = pos(var1.x + var9.x, var1.y + var9.y, var1.z + var9.z);
         if (!loaded(var2, var14) || !permitted(var0, var14) || !air(var2, var14)) {
            return false;
         }
      }

      return true;
   }

   public static boolean work(Object var0) {
      try {
         if (cfg().get("activos").getAsBoolean() && safe(var0)) {
            String var1 = Social.s(Social.tag(var0), "npc77_refugio_lider");
            if (!var1.isBlank()) {
               return helper(var0, var1);
            } else {
               Shelter77.Camp var2 = get(var0);
               if (var2 == null) {
                  return false;
               } else {
                  long var3 = Social.time(var0);
                  if (var3 < var2.next) {
                     if (!var2.wait && (!var2.phase.equals("descansar") || var3 <= var2.until)) {
                        Social.mem(var0).occupied = true;
                        return true;
                     } else {
                        Social.mem(var0).occupied = false;
                        return false;
                     }
                  } else {
                     var2.wait = false;
                     var2.next = var3 + (long)num("accion_ticks");
                     if (!grief(var0)) {
                        status(var0, "mobGriefing/proteccion");
                        return false;
                     } else if (var3 > var2.until && !var2.phase.equals("descansar")) {
                        status(var0, "espera_materiales_o_ruta");
                        var2.fails++;
                        if (var2.fails >= 3) {
                           abandon(var0, "refugio_abandonado_sin_progreso");
                           return false;
                        }

                        var2.until = var3 + (long)num("max_tiempo_trabajo_ticks");
                        var2.next = var3 + (long)num("reintento_ticks");
                        var2.wait = true;
                        save(var0, var2);
                        Social.mem(var0).occupied = false;
                        return false;
                     } else {
                        Social.mem(var0).occupied = true;
                        if (var2.phase.equals("descansar")) {
                           if (var3 > var2.until) {
                              if (var3 <= var2.until + (long)num("reintento_ticks") || need(var0) == null) {
                                 Social.mem(var0).occupied = false;
                                 return false;
                              }

                              var2.until = var3 + (long)num("descanso_ticks");
                              save(var0, var2);
                           }

                           if (!Social.yes(c(Social.world(var0), "canSeeSky", pos(var2.x, var2.y + 1, var2.z)))) {
                              move(var0, (double)var2.x + 0.5, var2.y, (double)var2.z + 0.5);
                              status(var0, "resguardado_" + var2.reason);
                              return true;
                           } else {
                              status(var0, "techo_danado");
                              Social.mem(var0).occupied = false;
                              return false;
                           }
                        } else {
                           int var5 = planks(DialogueRules72.bag(var0));
                           int var6 = var2.index > 0 ? 1 : count(DialogueRules72.bag(var0), "minecraft:crafting_table");
                           if (var2.index < var2.cells.size() && (var2.index == 0 ? var6 == 0 : var5 < 1)) {
                              if (craft(var0, var6 == 0 && var5 >= 4)) {
                                 status(var0, "crafteando");
                                 return true;
                              } else {
                                 status(var0, "recogiendo_madera");
                                 gather(var0, var2);
                                 if (var2.giveUp) {
                                    abandon(var0, "refugio_abandonado_sin_recursos");
                                    return false;
                                 }

                                 save(var0, var2);
                                 return true;
                              }
                           } else if (var2.index >= var2.cells.size()) {
                              var2.phase = "descansar";
                              var2.until = var3 + (long)num("descanso_ticks");
                              save(var0, var2);
                              return true;
                           } else {
                              Shelter77.Cell var7 = var2.cells.get(var2.index);
                              Object var8 = pos(var2.x + var7.x, var2.y + var7.y, var2.z + var7.z);
                              Object var9 = Social.world(var0);
                              if (!loaded(var9, var8) || !permitted(var0, var8)) {
                                 status(var0, "sitio_protegido");
                                 Social.mem(var0).occupied = false;
                                 return false;
                              } else if (!air(var9, var8)) {
                                 status(var0, "obra_obstruida");
                                 var2.next = var3 + (long)num("reintento_ticks");
                                 var2.wait = true;
                                 Social.mem(var0).occupied = false;
                                 return false;
                              } else {
                                 double var10 = Social.num(c(var0, "getX")) - ((double)(var2.x + var7.x) + 0.5);
                                 double var12 = Social.num(c(var0, "getEyeY")) - ((double)(var2.y + var7.y) + 0.5);
                                 double var14 = Social.num(c(var0, "getZ")) - ((double)(var2.z + var7.z) + 0.5);
                                 boolean var16 = Social.yes(
                                    c(
                                       Social.t("mod.cdv.tnpc.tactical.Tasks"),
                                       "visibleBlock",
                                       var0,
                                       var8,
                                       (double)(var2.x + var7.x) + 0.5,
                                       (double)(var2.y + var7.y),
                                       (double)(var2.z + var7.z) + 0.5
                                    )
                                 );
                                 if (!(var10 * var10 + var12 * var12 + var14 * var14 > 12.25) && var16) {
                                    if (occupied(var9, var8)) {
                                       status(var0, "esperando_espacio");
                                       return true;
                                    } else {
                                       if (place(var0, var8, var7.table)) {
                                          var2.index++;
                                          var2.fails = 0;
                                          var2.phase = "construir";
                                          status(var0, var7.table ? "mesa_colocada" : "construyendo");
                                          save(var0, var2);
                                       }

                                       return true;
                                    }
                                 } else {
                                    int var17 = var7.y == 2 ? Math.max(0, Math.min(var2.size - 1, var7.x)) : var7.x;
                                    int var18 = var7.y == 2 ? Math.max(0, Math.min(var2.size - 1, var7.z)) : var7.z;
                                    if (var7.table) {
                                       var17 = var7.x - 1;
                                    }

                                    if (var7.y < 2 && !var7.table) {
                                       if (var7.x == -1) {
                                          var17 = -2;
                                       } else if (var7.x == var2.size) {
                                          var17 = var2.size + 1;
                                       } else if (var7.z == -1) {
                                          var18 = -2;
                                       } else if (var7.z == var2.size) {
                                          var18 = var2.size + 1;
                                       }
                                    }

                                    move(var0, (double)(var2.x + var17) + 0.5, var2.y, (double)(var2.z + var18) + 0.5);
                                    return true;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         } else {
            return false;
         }
      } catch (Exception var19) {
         failure(var0, var19);
         return false;
      }
   }

   static boolean helper(Object var0, String var1) {
      Object var2 = c(Social.world(var0), "getEntity", UUID.fromString(var1));
      if (var2 == null) {
         // El lider puede estar solo descargado: se le da un plazo de gracia antes de soltarlo.
         long var20 = Social.time(var0);
         long var21 = Social.l(Social.tag(var0), "npc77_lider_perdido_desde");
         if (var21 == 0L) {
            c(Social.tag(var0), "putLong", "npc77_lider_perdido_desde", var20);
         } else if (var20 - var21 > 6000L) {
            releaseHelper(var0, "lider_perdido");
         }

         return false;
      } else if (!Social.alive(var2)) {
         releaseHelper(var0, "lider_muerto");
         return false;
      } else {
         if (Social.l(Social.tag(var0), "npc77_lider_perdido_desde") != 0L) {
            c(Social.tag(var0), "putLong", "npc77_lider_perdido_desde", 0L);
         }

         Shelter77.Camp var3 = get(var2);
         if (var3 == null) {
            releaseHelper(var0, "lider_sin_refugio");
            return false;
         } else if (var3.phase.equals("descansar")) {
            if (Social.time(var0) > var3.until) {
               return false;
            } else {
               Social.mem(var0).occupied = true;
               move(var0, (double)(var3.x + var3.size) - 0.5, var3.y, (double)var3.z + 0.5);
               status(var0, "refugio_compartido");
               return true;
            }
         } else {
            long var4 = Social.time(var0);
            if (var4 < Social.l(Social.tag(var0), "npc77_ayuda_despues")) {
               Social.mem(var0).occupied = true;
               return true;
            } else {
               c(Social.tag(var0), "putLong", "npc77_ayuda_despues", var4 + (long)num("accion_ticks"));
               Social.mem(var0).occupied = true;
               if (!(Social.distance(var0, var2) > 16.0)
                  || HELP.containsKey(var0)
                     && !DialogueRules72.bag(var0).stream().anyMatch(var0x -> !DialogueRules72.empty(var0x) && wood(DialogueRules72.itemId(var0x)))) {
                  List var6 = DialogueRules72.copies(DialogueRules72.bag(var0));
                  List var7 = DialogueRules72.copies(DialogueRules72.bag(var2));

                  for (Object var8 : var6) {
                     String var10 = DialogueRules72.itemId(var8);
                     if (!DialogueRules72.empty(var8) && wood(var10)) {
                        Object var11 = c(var8, "copyWithCount", 1);
                        if (!DialogueRules72.insert(var7, new ArrayList<>(List.of(var11)), false)) {
                           return true;
                        }

                        c(var8, "shrink", 1);
                        List var12 = DialogueRules72.copies(DialogueRules72.bag(var2));
                        c(CalmLoot.class, "saveBag", var2, var7);

                        try {
                           c(CalmLoot.class, "saveBag", var0, var6);
                        } catch (Exception var14) {
                           c(CalmLoot.class, "saveBag", var2, var12);
                           throw var14;
                        }

                        status(var0, "aportando_madera");
                        return true;
                     }
                  }

                  Shelter77.Camp var15 = HELP.computeIfAbsent(var0, var1x -> new Shelter77.Camp(var3.x, var3.y, var3.z, var3.size));
                  if (var4 >= var15.next) {
                     var15.wait = false;
                     gather(var0, var15);
                     if (var15.giveUp) {
                        releaseHelper(var0, "ayuda_abandonada");
                        return false;
                     }

                     status(var0, var15.wait ? "ayuda_sin_madera" : "ayuda_talando");
                  }

                  return true;
               } else {
                  c(c(var0, "getNavigation"), "moveTo", var2, 0.9);
                  return true;
               }
            }
         }
      }
   }

   static void move(Object var0, double var1, int var3, double var4) {
      if (!Navigation78.go(var0, var1, (double)var3, var4, 0.85)) {
         Shelter77.Camp var6 = CACHE.get(var0);
         if (var6 != null) {
            var6.wait = true;
            var6.next = Social.time(var0) + (long)num("reintento_ticks");
         }

         Social.mem(var0).occupied = false;
         status(var0, "ruta_no_disponible");
      }
   }

   static boolean occupied(Object var0, Object var1) {
      Object var2 = SocialR.make(
         "net.minecraft.world.phys.AABB",
         (double)axis(var1, "getX"),
         (double)axis(var1, "getY"),
         (double)axis(var1, "getZ"),
         (double)axis(var1, "getX") + 1.0,
         (double)axis(var1, "getY") + 1.0,
         (double)axis(var1, "getZ") + 1.0
      );
      return !((List)c(var0, "getEntities", null, var2)).isEmpty();
   }

   static boolean wood(String var0) {
      return var0.startsWith("minecraft:") && (var0.endsWith("_log") || var0.endsWith("_planks"));
   }

   static int planks(List<Object> var0) {
      int var1 = 0;

      for (Object var2 : var0) {
         if (!DialogueRules72.empty(var2) && DialogueRules72.itemId(var2).startsWith("minecraft:") && DialogueRules72.itemId(var2).endsWith("_planks")) {
            var1 += DialogueRules72.size(var2);
         }
      }

      return var1;
   }

   static int count(List<Object> var0, String var1) {
      int var2 = 0;

      for (Object var3 : var0) {
         if (!DialogueRules72.empty(var3) && DialogueRules72.itemId(var3).equals(var1)) {
            var2 += DialogueRules72.size(var3);
         }
      }

      return var2;
   }

   static boolean craft(Object var0, boolean var1) {
      List var2 = DialogueRules72.copies(DialogueRules72.bag(var0));
      ArrayList var3 = new ArrayList();

      for (int var4 = 0; var4 < (var1 ? 4 : 1); var4++) {
         Object var5 = null;

         for (Object var6 : var2) {
            String var8 = DialogueRules72.itemId(var6);
            if (!DialogueRules72.empty(var6) && var8.startsWith("minecraft:") && var8.endsWith(var1 ? "_planks" : "_log")) {
               var5 = var6;
               break;
            }
         }

         if (var5 == null) {
            return false;
         }

         var3.add(c(var5, "copyWithCount", 1));
         c(var5, "shrink", 1);
      }

      var2.removeIf(DialogueRules72::empty);
      Object var13 = c(Social.t("net.minecraft.world.item.crafting.CraftingInput"), "of", var1 ? 2 : 1, var1 ? 2 : 1, var3);
      Object var14 = c(Social.world(var0), "getRecipeManager");
      Optional var15 = (Optional)c(
         var14, "getRecipeFor", SocialR.get(Social.t("net.minecraft.world.item.crafting.RecipeType"), "CRAFTING"), var13, Social.world(var0)
      );
      if (var15.isEmpty()) {
         return false;
      } else {
         Object var16 = c(var15.get(), "value");
         Object var17 = c(var16, "assemble", var13, c(Social.world(var0), "registryAccess"));
         String var9 = DialogueRules72.itemId(var17);
         if (!DialogueRules72.empty(var17) && (var1 ? var9.equals("minecraft:crafting_table") : var9.endsWith("_planks"))) {
            ArrayList var10 = new ArrayList();
            var10.add(var17);

            for (Object var11 : (Iterable)c(var16, "getRemainingItems", var13)) {
               if (!DialogueRules72.empty(var11)) {
                  var10.add(DialogueRules72.copy(var11));
               }
            }

            if (!DialogueRules72.insert(var2, var10, false)) {
               return false;
            } else {
               c(CalmLoot.class, "saveBag", var0, var2);
               swing(var0);
               return true;
            }
         } else {
            return false;
         }
      }
   }

   static boolean place(Object var0, Object var1, boolean var2) {
      return placeItem(var0, var1, var2 ? "minecraft:crafting_table" : "planks");
   }

   static boolean placeItem(Object var0, Object var1, String var2) {
      List var3 = DialogueRules72.copies(DialogueRules72.bag(var0));

      for (Object var4 : var3) {
         String var6 = DialogueRules72.itemId(var4);
         if (!DialogueRules72.empty(var4) && (var2.equals("planks") ? var6.startsWith("minecraft:") && var6.endsWith("_planks") : var6.equals(var2))) {
            Object var7 = Social.world(var0);
            Object var8 = state(var7, var1);
            Object var9 = c(Social.t("net.neoforged.neoforge.common.util.BlockSnapshot"), "create", c(var7, "dimension"), var7, var1);
            Object var10 = c(registry("BLOCK", var6), "defaultBlockState");
            if (!Social.yes(c(var7, "setBlock", var1, var10, 2))) {
               return false;
            } else {
               try {
                  if (Social.yes(
                     c(
                        Social.t("net.neoforged.neoforge.event.EventHooks"),
                        "onBlockPlace",
                        var0,
                        var9,
                        SocialR.get(Social.t("net.minecraft.core.Direction"), "UP")
                     )
                  )) {
                     c(var9, "restore", 3);
                     return false;
                  }

                  c(var4, "shrink", 1);
                  c(CalmLoot.class, "saveBag", var0, var3);
               } catch (Exception var12) {
                  c(var7, "setBlock", var1, var8, 3);
                  throw var12;
               }

               c(var7, "blockUpdated", var1, c(var10, "getBlock"));
               swing(var0);
               return true;
            }
         }
      }

      return false;
   }

   // FIX: un ayudante que pierde a su lider (o se rinde) debe poder volver a iniciar su propio refugio.
   static void releaseHelper(Object var0, String var1) {
      HELP.remove(var0);
      c(Social.tag(var0), "putString", "npc77_refugio_lider", "");
      c(Social.tag(var0), "putLong", "npc77_lider_perdido_desde", 0L);
      c(Social.tag(var0), "putLong", "npc77_refugio_despues", Social.time(var0) + 6000L);
      status(var0, var1);
      Social.mem(var0).occupied = false;
   }

   // FIX bucle: sin limite de intentos el campamento nunca se abandonaba.
   static void abandon(Object var0, String var1) {
      CACHE.remove(var0);
      c(Social.tag(var0), "putString", "npc77_refugio", "");
      c(Social.tag(var0), "putLong", "npc77_refugio_despues", Social.time(var0) + 6000L);
      status(var0, var1);
      Social.mem(var0).occupied = false;
   }

   // FIX bucle: al no haber arboles en el radio, antes se reescaneaba el MISMO sitio cada minuto.
   static boolean wander(Object var0, Shelter77.Camp var1) {
      double var2 = (double)(var1.fails * 2) + (double)Math.floorMod(Social.uuid(var0).hashCode(), 6);
      int var4 = num("radio_madera") + 8;
      double var5 = Social.num(c(var0, "getX")) + Math.cos(var2) * (double)var4;
      double var7 = Social.num(c(var0, "getZ")) + Math.sin(var2) * (double)var4;
      int var9 = (int)Math.floor(Social.num(c(var0, "getY")));
      return Navigation78.go(var0, var5, (double)var9, var7, 0.85);
   }

   static void swing(Object var0) {
      c(var0, "swing", SocialR.get(Social.t("net.minecraft.world.InteractionHand"), "MAIN_HAND"));
   }

   static void gather(Object var0, Shelter77.Camp var1) {
      if (var1.giveUp) {
         // Ya se rindio: el llamador debe descartar este trabajo; no se vuelve a escanear ni a deambular.
         var1.wait = true;
         var1.next = Social.time(var0) + (long)num("reintento_ticks");
         return;
      }

      Object var2 = Social.world(var0);
      if (var1.tree == null) {
         int var3 = num("radio_madera");
         int var4 = var3 * 2 + 1;
         int var5 = var4 * var4 * 5;
         int var6 = (int)Math.floor(Social.num(c(var0, "getX")));
         int var7 = (int)Math.floor(Social.num(c(var0, "getY")));
         int var8 = (int)Math.floor(Social.num(c(var0, "getZ")));

         for (int var9 = 0; var9 < 32; var9++) {
            int var10 = Math.floorMod(var1.scan++, var5);
            Object var11 = pos(var6 + var10 % var4 - var3, var7 + var10 / (var4 * var4) - 2, var8 + var10 / var4 % var4 - var3);
            if (loaded(var2, var11)) {
               String var12 = id(state(var2, var11));
               if (var12.startsWith("minecraft:") && var12.endsWith("_log") && permitted(var0, var11)) {
                  Object var13 = offset(var11, 0, -1, 0);
                  String var14 = id(state(var2, var13));
                  if (Set.of("minecraft:dirt", "minecraft:grass_block", "minecraft:podzol", "minecraft:coarse_dirt", "minecraft:rooted_dirt").contains(var14)) {
                     boolean var15 = false;

                     for (int var16 = 3; var16 <= 8; var16++) {
                        for (int var17 = -1; var17 <= 1; var17++) {
                           if (loaded(var2, offset(var11, var17, var16, 0)) && id(state(var2, offset(var11, var17, var16, 0))).endsWith("_leaves")) {
                              var15 = true;
                           }
                        }
                     }

                     if (var15) {
                        var1.tree = var11;
                        var1.treeCount = 0;
                        break;
                     }
                  }
               }
            }
         }

         if (var1.tree == null) {
            if (var1.scan >= var5) {
               var1.scan = 0;
               var1.fails++;
               if (var1.fails >= 3) {
                  var1.giveUp = true;
                  var1.next = Social.time(var0) + (long)num("reintento_ticks");
                  var1.wait = true;
                  status(var0, "sin_madera_cercana");
                  Social.mem(var0).occupied = false;
               } else if (wander(var0, var1)) {
                  var1.next = Social.time(var0) + 100L;
                  var1.wait = false;
                  status(var0, "buscando_madera_en_otra_zona");
                  Social.mem(var0).occupied = true;
               } else {
                  var1.next = Social.time(var0) + (long)num("reintento_ticks");
                  var1.wait = true;
                  status(var0, "sin_madera_cercana");
                  Social.mem(var0).occupied = false;
               }
            }

            return;
         }
      }

      Object var19 = var1.tree;
      if (Math.abs(Social.num(c(var0, "getEyeY")) - (double)axis(var19, "getY") - 0.5) > 3.4) {
         var1.tree = null;
         var1.chop = 0;
      } else {
         Object var20 = state(var2, var19);
         if (id(var20).endsWith("_log") && permitted(var0, var19) && var1.treeCount < num("logs_por_arbol")) {
            double var21 = Social.num(c(var0, "getX")) - (double)axis(var19, "getX") - 0.5;
            double var22 = Social.num(c(var0, "getZ")) - (double)axis(var19, "getZ") - 0.5;
            double var23 = Social.num(c(var0, "getEyeY")) - (double)axis(var19, "getY") - 0.5;
            if (!(var21 * var21 + var23 * var23 + var22 * var22 > 12.25)
               && Social.yes(
                  c(
                     Social.t("mod.cdv.tnpc.tactical.Tasks"),
                     "visibleBlock",
                     var0,
                     var19,
                     (double)axis(var19, "getX") + 0.5,
                     (double)axis(var19, "getY"),
                     (double)axis(var19, "getZ") + 0.5
                  )
               )) {
               swing(var0);
               if (++var1.chop >= 3) {
                  var1.chop = 0;
                  if (Social.yes(c(var20, "canEntityDestroy", var2, var19, var0))
                     && Social.yes(c(Social.t("net.neoforged.neoforge.event.EventHooks"), "onEntityDestroyBlock", var0, var19, var20))) {
                     List var24 = DialogueRules72.copies(DialogueRules72.bag(var0));
                     if (DialogueRules72.insert(var24, new ArrayList<>(List.of(item(id(var20), 1))), false)) {
                        if (Social.yes(c(var2, "destroyBlock", var19, false, var0))) {
                           try {
                              c(CalmLoot.class, "saveBag", var0, var24);
                           } catch (Exception var18) {
                              c(var2, "setBlock", var19, var20, 3);
                              throw var18;
                           }

                           var1.treeCount++;
                           var1.fails = 0;
                           var1.tree = offset(var19, 0, 1, 0);
                        }
                     } else {
                        // FIX bucle: con la mochila llena el NPC golpeaba el arbol para siempre sin romperlo.
                        var1.tree = null;
                        var1.chop = 0;
                        var1.fails++;
                        if (var1.fails >= 3) {
                           var1.giveUp = true;
                        }

                        var1.next = Social.time(var0) + (long)num("reintento_ticks");
                        var1.wait = true;
                        status(var0, "mochila_llena");
                        Social.mem(var0).occupied = false;
                     }
                  } else {
                     var1.tree = null;
                  }
               }
            } else {
               move(var0, (double)axis(var19, "getX") + 1.5, var1.y, (double)axis(var19, "getZ") + 0.5);
            }
         } else {
            var1.tree = null;
            var1.chop = 0;
         }
      }
   }

   static void failure(Object var0, Exception var1) {
      status(var0, "error_compatible_" + var1.getClass().getSimpleName());
      c(Social.tag(var0), "putLong", "npc77_refugio_despues", Social.time(var0) + 1200L);
      Shelter77.Camp var2 = CACHE.get(var0);
      if (var2 != null) {
         var2.next = Social.time(var0) + 1200L;
      }

      if (WARN.add(var0)) {
         Social.warn("survival shelter (NPC still active)", var1);
      }
   }

   static void debug(Object var0, Object var1) {
      Ops74.out(
         var1,
         "refugio="
            + Social.s(Social.tag(var0), "npc77_refugio_estado")
            + " lider="
            + Social.s(Social.tag(var0), "npc77_refugio_lider")
            + " plan="
            + Social.s(Social.tag(var0), "npc77_refugio")
      );
   }

   static void validate(JsonObject var0) {
      JsonObject var1 = var0.getAsJsonObject("refugios");
      DialogueData71.only(
         var1,
         "activos",
         "intervalo_ticks",
         "accion_ticks",
         "radio_madera",
         "radio_grupo",
         "descanso_ticks",
         "reintento_ticks",
         "frio_bioma",
         "calor_bioma",
         "max_tiempo_trabajo_ticks",
         "logs_por_arbol"
      );
      if (!var1.get("activos").getAsJsonPrimitive().isBoolean()) {
         throw new IllegalArgumentException("refugios.activos");
      } else {
         DialogueData71.integer(var1.get("intervalo_ticks"), 100, 2400);
         DialogueData71.integer(var1.get("accion_ticks"), 10, 100);
         DialogueData71.integer(var1.get("radio_madera"), 4, 16);
         DialogueData71.integer(var1.get("radio_grupo"), 4, 24);

         for (String var2 : List.of("descanso_ticks", "reintento_ticks", "max_tiempo_trabajo_ticks")) {
            DialogueData71.integer(var1.get(var2), 200, 48000);
         }

         DialogueData71.integer(var1.get("logs_por_arbol"), 1, 8);
         Config74.number(var1.get("frio_bioma"), -1.0, 1.0);
         Config74.number(var1.get("calor_bioma"), 0.5, 3.0);
         if (var1.get("frio_bioma").getAsDouble() >= var1.get("calor_bioma").getAsDouble()) {
            throw new IllegalArgumentException("temperaturas invertidas");
         }
      }
   }

   static List<Shelter77.Cell> blueprint(int var0) {
      if (var0 != 2 && var0 != 4) {
         throw new IllegalArgumentException("size");
      } else {
         ArrayList var1 = new ArrayList();
         var1.add(new Shelter77.Cell(var0 - 1, 0, var0 - 1, true));

         for (int var2 = 0; var2 < 2; var2++) {
            for (int var3 = -1; var3 <= var0; var3++) {
               for (int var4 = -1; var4 <= var0; var4++) {
                  if ((var3 == -1 || var3 == var0 || var4 == -1 || var4 == var0) && (var3 != 0 || var4 != -1)) {
                     var1.add(new Shelter77.Cell(var3, var2, var4, false));
                  }
               }
            }
         }

         for (int var5 = -2; var5 <= var0 + 1; var5++) {
            for (int var6 = -2; var6 <= var0 + 1; var6++) {
               var1.add(new Shelter77.Cell(var5, 2, var6, false));
            }
         }

         return var1;
      }
   }

   static class Camp {
      final int x;
      final int y;
      final int z;
      final int size;
      final List<Shelter77.Cell> cells;
      int index;
      int scan;
      int chop;
      int treeCount;
      int fails;
      boolean giveUp;
      long next;
      long until;
      boolean wait;
      String phase = "reunir";
      String reason = "";
      Object tree;

      Camp(int var1, int var2, int var3, int var4) {
         this.x = var1;
         this.y = var2;
         this.z = var3;
         this.size = var4;
         this.cells = Shelter77.blueprint(var4);
      }

      int remainingPlanks() {
         int var1 = 0;

         for (int var2 = this.index; var2 < this.cells.size(); var2++) {
            if (!this.cells.get(var2).table) {
               var1++;
            }
         }

         return var1;
      }
   }

   static record Cell(int x, int y, int z, boolean table) {
   }
}
