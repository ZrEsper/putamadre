from pathlib import Path
import subprocess,sys,zipfile,json
r=Path(__file__).parent.resolve();base=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();b=r/'build';b.mkdir(exist_ok=True)
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
def run(*a):subprocess.run(a,check=True)
run('java','com.sun.tools.javac.Main','-proc:none','-cp',str(base),'-d',str(b),*[str(f) for f in (r/'src').rglob('*.java')]);run('java','com.sun.tools.javac.Main',*flags,'-d',str(b),str(r/'Patch.java'))
patched=['dev/survivorcreator/spawn/'+n+'.class' for n in ['Spawns','SpawnScreen']]
with zipfile.ZipFile(base) as z:
 for name in patched:
  f=b/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(z.read(name));run('java',*flags,'-cp',str(b),'Patch',str(f))
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as dest:
  compiled={p.relative_to(b).as_posix():p.read_bytes() for p in (b/'dev').rglob('*.class')}
  for item in z.infolist():
   data=compiled.pop(item.filename,z.read(item.filename))
   if item.filename.endswith('mods.toml'):data=data.replace(b'version = "1.0.9"',b'version = "1.0.9+zomboid-v35"').replace(b'displayName = "Survivor Creator"',b'displayName = "Survivor Creator - Adaptive Spawn v35"').replace(b'v34',b'v35').replace(b'flashlight-battery',b'adaptive-world-spawn')
   if item.filename.startswith('assets/survivorcreator/lang/') and item.filename.endswith('.json'):
    d=json.loads(data);english=Path(item.filename).stem.startswith('en');d['survivorcreator.localized.1']='SPAWN AREA / AUTOMATIC' if english else 'ZONA DE APARICIÓN / AUTOMÁTICO';d['survivorcreator.spawn35.auto']='Automatic spawn\n\nThe server checks safe ground in the current world.\n\nWorks without Mosslorn. Original regions are used only if their homes are verified.' if english else 'Aparición automática\n\nSe comprueba el terreno seguro del mundo actual.\n\nFunciona sin Mosslorn. Las zonas originales solo se usan si sus casas se verifican.';data=json.dumps(d,ensure_ascii=False,indent=2).encode()
   dest.writestr(item,data)
  for name,data in compiled.items():dest.writestr(name,data)
print(out)
