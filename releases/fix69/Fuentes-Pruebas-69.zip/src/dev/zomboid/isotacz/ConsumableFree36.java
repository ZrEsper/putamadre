package dev.zomboid.isotacz;
/** Keep native consumption input, but retain isometric locomotion and cursor-facing. */
public final class ConsumableFree36 {
 private static Object cachedPlayer,cachedLevel;private static long nextUpdate,lastFrame;private static double desiredYaw;private static boolean hasDesired;
 public static double plane(double y0,double y1,double y){double d=y1-y0;if(!Double.isFinite(d)||Math.abs(d)<1e-7)return -1;double t=(y-y0)/d;return Double.isFinite(t)&&t>=0&&t<=1?t:-1;}
 public static boolean held(){
  Object mc=Bridge.mc(),p=R.get(mc,"player");
  if(!Bridge.active()||p==null)return false;
  if(MedicalInput30.held())return true;
  if(!Bridge.gun(p)&&NativeActions.food(mc))return true;
  if(R.yes(R.call(p,"isUsingItem"))){Object stack=R.call(p,"getUseItem");String a=String.valueOf(R.call(stack,"getUseAnimation"));return a.equals("EAT")||a.equals("DRINK");}
  return false;
 }
 public static double wrap(double a){return ((a+180)%360+360)%360-180;}
 public static double yaw(double dx,double dz){return Math.toDegrees(Math.atan2(-dx,dz));}
 public static double approach(double current,double target,double dt,double speed){return current+Math.max(-speed*dt,Math.min(speed*dt,wrap(target-current)));}
 public static double limitHead(double head,double body){return body+Math.max(-40,Math.min(40,wrap(head-body)));}
 public static void aim(){
  try{
   Object mc=Bridge.mc(),p=R.get(mc,"player"),level=R.get(mc,"level");
   if(!Bridge.active()||p==null||level==null||R.get(mc,"screen")!=null||NativeActions.riding()||!held()||Bridge.gun(p)){lastFrame=0;hasDesired=false;nextUpdate=0;return;}
   long now=System.nanoTime();if(p!=cachedPlayer||level!=cachedLevel){hasDesired=false;nextUpdate=0;lastFrame=0;cachedPlayer=p;cachedLevel=level;}
   double current=R.num(R.call(p,"getYRot"));if(!hasDesired){desiredYaw=current;hasDesired=true;}
   if(now>=nextUpdate){
    nextUpdate=now+45_000_000L;Object eye=R.call(p,"getEyePosition");Object[] ray=CursorTarget.ray(mc);Object start=ray[0],end=ray[1];double t=plane(R.num(R.get(start,"y")),R.num(R.get(end,"y")),R.num(R.get(eye,"y"))-.8);
    if(t>=0){double dx=R.num(R.get(start,"x"))+(R.num(R.get(end,"x"))-R.num(R.get(start,"x")))*t-R.num(R.get(eye,"x"));double dz=R.num(R.get(start,"z"))+(R.num(R.get(end,"z"))-R.num(R.get(start,"z")))*t-R.num(R.get(eye,"z"));
     // Near the avatar, a few pixels can reverse atan2: retain the previous direction.
     if(Double.isFinite(dx)&&Double.isFinite(dz)&&dx*dx+dz*dz>=.64)desiredYaw=yaw(dx,dz);
    }
   }
   double dt=lastFrame==0?0:Math.max(0,Math.min(.05,(now-lastFrame)/1e9));lastFrame=now;
   float body=(float)approach(current,desiredYaw,dt,300);
   float head=(float)approach(R.num(R.call(p,"getYHeadRot")),limitHead(desiredYaw,body),dt,420);
   float pitch=(float)approach(R.num(R.call(p,"getXRot")),0,dt,90);
   for(String field:new String[]{"yRotO","yBodyRotO"}){double previous=R.num(R.get(p,field));R.set(p,field,(float)(body+wrap(previous-body)));}
   double previous=R.num(R.get(p,"yHeadRotO"));R.set(p,"yHeadRotO",(float)(head+wrap(previous-head)));
   R.call(p,"setYRot",body);R.call(p,"setYHeadRot",head);R.set(p,"yBodyRot",body);R.call(p,"setXRot",pitch);
   R.set(Bridge.mod(),"livingYaw",body);R.set(Bridge.mod(),"livingHeadYaw",head);R.set(Bridge.mod(),"livingBodyYaw",body);R.set(Bridge.mod(),"livingPitch",pitch);
  }catch(Throwable t){Bridge.warn("consumable free movement",t);}
 }
}
