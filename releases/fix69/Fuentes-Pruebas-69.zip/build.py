from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');base='/workspace/fix68/release/dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.37-lightweight-food-turn.jar';asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis']);ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];jar=r/'release/dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.38-smooth-consumable-head.jar'
subprocess.run(ecj+['-cp',base,'-d',str(r/'build')]+list(map(str,(r/'src').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'Patch69.java')],check=True)
subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'Patch69','iso',base,str(r/'build'),str(jar)],check=True)
subprocess.run(ecj+['-cp',str(jar),'-d',str(r/'tests')]+list(map(str,(r/'testsrc').rglob('*.java'))),check=True)
subprocess.run(['java','-Xverify:all','-cp',str(r/'tests')+':'+str(jar),'dev.zomboid.isotacz.Fixture'],check=True)
