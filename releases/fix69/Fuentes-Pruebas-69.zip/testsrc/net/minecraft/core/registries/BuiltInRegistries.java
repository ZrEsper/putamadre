package net.minecraft.core.registries;
public class BuiltInRegistries {public static Registry ITEM=new Registry();public static class Registry {public Object getKey(dev.zomboid.isotacz.Fixture.Item i){return i.id;}}}
