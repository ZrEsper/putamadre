package dev.zomboid.isotacz;
public class Fixture {
 public static class Vec{public double x,y,z;public Vec(double x,double y,double z){this.x=x;this.y=y;this.z=z;}}
 public static class Item{public String id;public Item(String s){id=s;}}
 public static class Stack{public Item item;public String animation="NONE";public Stack(String s){item=new Item(s);}public boolean isEmpty(){return item.id.isEmpty();}public Item getItem(){return item;}public String getUseAnimation(){return animation;}}
 public static class Player{public Stack main=new Stack("firstaid:bandage"),off=new Stack(""),use=main;public boolean using;public float yaw,head,yBodyRot,yRotO,yHeadRotO,yBodyRotO,pitch=17;public boolean isUsingItem(){return using;}public Stack getUseItem(){return use;}public Stack getMainHandItem(){return main;}public Stack getOffhandItem(){return off;}public float getYRot(){return yaw;}public float getYHeadRot(){return head;}public float getXRot(){return pitch;}public void setXRot(float x){pitch=x;}public Vec getEyePosition(){return new Vec(0,1.6,0);}public void setYRot(float v){yaw=v;}public void setYHeadRot(float v){head=v;}}
 public static class Mod{public static boolean using;public static float livingYaw,livingHeadYaw,livingBodyYaw,livingPitch;}
 public static class MC{public Player player=new Player();public Object level=new Object(),screen;public boolean useKey;public void setLocation(Object x){}public void setOriginalLocation(Object x){}}
 public static void main(String[] args) throws Exception {
 int checks=0;
 for(double current:new double[]{-179,-90,0,90,179})for(double target:new double[]{-179,-90,0,90,179}){
 double a=current;for(int i=0;i<180;i++){double b=ConsumableFree36.approach(a,target,1.0/60,300);if(Math.abs(b-a)>5.001)throw new Error("snap");a=b;checks++;}if(Math.abs(ConsumableFree36.wrap(a-target))>.001)throw new Error("wrong direction");
 }
 Player p=Bridge.MC.player;NativeActions.food=true;p.main=new Stack("minecraft:apple");
 java.lang.reflect.Field next=ConsumableFree36.class.getDeclaredField("nextUpdate"),last=ConsumableFree36.class.getDeclaredField("lastFrame");next.setAccessible(true);last.setAccessible(true);
 CursorTarget.point=new Vec(5,0,0);ConsumableFree36.aim();
 for(int i=0;i<30;i++){next.setLong(null,0);last.setLong(null,System.nanoTime()-20_000_000L);float old=p.yaw;ConsumableFree36.aim();if(Math.abs(p.yaw-old)>6.1)throw new Error("body snaps");if(Math.abs(ConsumableFree36.wrap(p.head-p.yaw))>40.1)throw new Error("twist");if(Mod.livingPitch!=p.pitch||Mod.livingHeadYaw!=p.head)throw new Error("stale restoration cache");checks++;}
 if(Math.abs(p.yaw+90)>.1||Math.abs(p.pitch)>.1)throw new Error("failed neutral head");
 double dir=p.yaw;CursorTarget.point=new Vec(.1,0,-.1);next.setLong(null,0);last.setLong(null,System.nanoTime()-20_000_000L);ConsumableFree36.aim();if(Math.abs(p.yaw-dir)>.1)throw new Error("near-avatar flip");checks++;
 Bridge.active=false;float before=p.yaw;ConsumableFree36.aim();if(p.yaw!=before)throw new Error("first person changed");checks++;
 Bridge.active=true;Bridge.MC.screen=new Object();ConsumableFree36.aim();if(p.yaw!=before)throw new Error("GUI changed");checks++;
 System.out.println("PASS "+checks+" checks: bounded shortest-path yaw, head/body relation, pitch restoration, near-avatar stability and mode guards; API fixtures, not Minecraft.");
 }
}
