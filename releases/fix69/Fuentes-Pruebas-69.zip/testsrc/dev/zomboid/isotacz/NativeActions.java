package dev.zomboid.isotacz;
public class NativeActions {public static boolean riding,food;public static boolean riding(){return riding;}public static boolean food(Object mc){return food;}}
