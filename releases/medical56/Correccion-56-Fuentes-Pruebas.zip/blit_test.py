from pathlib import Path
exec(Path('work/medical52/shader_test.py').read_text().split('shaders=[]')[0])
bind=fn(g,'glBindTexture',None,[U,U]);gen=fn(g,'glGenTextures',None,[I,C.POINTER(U)]);image=fn(g,'glTexImage2D',None,[U,I,I,I,I,I,U,U,P]);error=fn(g,'glGetError',U,[]);bindf=fn(g,'glBindFramebuffer',None,[U,U]);attach=fn(g,'glFramebufferTexture2D',None,[U,U,U,U,I]);status=fn(g,'glCheckFramebufferStatus',U,[U]);blit=fn(g,'glBlitFramebuffer',None,[I]*8+[U,U])
def framebuffer():
 n=U();fn(g,'glGenFramebuffers',None,[I,C.POINTER(U)])(1,C.byref(n));return n
def texture(fmt,external,ty,size):
 n=U();gen(1,C.byref(n));bind(0xDE1,n);image(0xDE1,0,fmt,size,size,0,external,ty,None);return n
for fmt,external,ty in [(0x81A6,0x1902,0x1406),(0x8CAC,0x1902,0x1406),(0x88F0,0x84F9,0x84FA),(0x8CAD,0x84F9,0x8DAD)]:
 source=framebuffer();bindf(0x8D40,source);sc=texture(0x8058,0x1908,0x1401,8);sd=texture(fmt,external,ty,8);attach(0x8D40,0x8CE0,0xDE1,sc,0);attach(0x8D40,0x8D00,0xDE1,sd,0);assert status(0x8D40)==0x8CD5
 fn(g,'glClearColor',None,[C.c_float]*4)(.25,.5,.75,1);fn(g,'glClearDepth',None,[C.c_double])(.4);fn(g,'glClear',None,[U])(0x4100)
 dest=framebuffer();bindf(0x8D40,dest);dc=texture(0x8058,0x1908,0x1401,4);dd=texture(fmt,external,ty,4);attach(0x8D40,0x8CE0,0xDE1,dc,0);attach(0x8D40,0x8D00,0xDE1,dd,0);assert status(0x8D40)==0x8CD5
 bindf(0x8CA8,source);bindf(0x8CA9,dest);blit(0,0,8,8,0,0,4,4,0x4100,0x2600);assert error()==0,hex(fmt)
 bind(0xDE1,dd);pixels=(C.c_float*16)();fn(g,'glGetTexImage',None,[U,I,U,U,P])(0xDE1,0,0x1902,0x1406,pixels);assert all(abs(x-.4)<1e-4 for x in pixels)
 bind(0xDE1,dc);pixels=(C.c_ubyte*64)();fn(g,'glGetTexImage',None,[U,I,U,U,P])(0xDE1,0,0x1908,0x1401,pixels);assert abs(pixels[0]-64)<=1 and abs(pixels[1]-128)<=1
 print('MATCHING_COLOR_DEPTH_HALF_RES_BLIT',hex(fmt),'PASS')
