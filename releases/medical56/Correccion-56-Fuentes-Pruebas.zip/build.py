from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent;o=r/'output';o.mkdir(exist_ok=True);tacz=next((r/'input').glob('*.jar'));flash=next((r.parent/'medical55/output').glob('flashlight*.jar'))
for src,jar,name in [('src',tacz,'core'),('flash-src',flash,'flash')]:
 p=r/'build'/name;p.mkdir(parents=True,exist_ok=True);subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(jar),'-d',str(p),*map(str,(r/src).rglob('*.java'))],check=True)
f=['--add-exports=java.base/jdk.internal.org.objectweb.asm'+s+'=ALL-UNNAMED'for s in ['','.tree','.tree.analysis']];t=r/'build/tools';t.mkdir(exist_ok=True)
subprocess.run(['java',*f,'com.sun.tools.javac.Main',*f,'-d',str(t),str(r.parent/'medical52/Patch52.java'),str(r/'Patch56.java')],check=True)
subprocess.run(['java',*f,'-cp',str(t),'Patch56',str(tacz),str(r/'build/core'),str(o/'tacz-neoforge-1.21.1-1.1.8-hotfix-r7-third-person-pz.20-wall-low-ready.jar'),str(flash),str(r/'build/flash'),str(r/'portable6.frag'),str(o/'flashlight-5.1-neoforge-1.21.1-iso-gpu-blit.23.jar')],check=True)
