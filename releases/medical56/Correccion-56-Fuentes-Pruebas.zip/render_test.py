from pathlib import Path
import ctypes as C
r=Path(__file__).resolve().parent
s=(r/'shader_test.py').read_text();exec(s[:s.index("fn(e,'eglMakeCurrent'",s.index('program=') )])
# Draw the production fragment on a controlled plane with a real OpenGL framebuffer.
W=128;H=128
texgen=fn(g,'glGenTextures',None,[I,C.POINTER(U)]);bind=fn(g,'glBindTexture',None,[U,U]);teximage=fn(g,'glTexImage2D',None,[U,I,I,I,I,I,U,U,P]);param=fn(g,'glTexParameteri',None,[U,U,I]);active=fn(g,'glActiveTexture',None,[U])
def texture(unit,internal,fmt,ty,values,w=W,h=H):
 n=U();texgen(1,C.byref(n));active(0x84C0+unit);bind(0x0DE1,n);param(0x0DE1,0x2801,0x2600);param(0x0DE1,0x2800,0x2600);param(0x0DE1,0x2802,0x812F);param(0x0DE1,0x2803,0x812F);teximage(0x0DE1,0,internal,w,h,0,fmt,ty,values);return n
rgba=(C.c_float*(W*H*4))(*([.06,.065,.07,1.]*(W*H)));dep=(C.c_float*(W*H))(*([.5]*(W*H)));alb=(C.c_float*(W*H*4))(*([.24,.25,.26,1.]*(W*H)));sh=(C.c_float*(12*24))(*([8.]*(12*24)))
texture(0,0x8814,0x1908,0x1406,rgba);texture(1,0x822E,0x1903,0x1406,dep);texture(2,0x8814,0x1908,0x1406,alb);texture(3,0x822E,0x1903,0x1406,sh,12,24);texture(4,0x822E,0x1903,0x1406,dep)
out=texture(5,0x8814,0x1908,0x1406,None);fbo=U();fn(g,'glGenFramebuffers',None,[I,C.POINTER(U)])(1,C.byref(fbo));fn(g,'glBindFramebuffer',None,[U,U])(0x8D40,fbo);fn(g,'glFramebufferTexture2D',None,[U,U,U,U,I])(0x8D40,0x8CE0,0x0DE1,out,0);assert fn(g,'glCheckFramebufferStatus',U,[U])(0x8D40)==0x8CD5
fn(g,'glUseProgram',None,[U])(program);loc=fn(g,'glGetUniformLocation',I,[U,C.c_char_p]);ui=fn(g,'glUniform1i',None,[I,I]);uf=fn(g,'glUniform1f',None,[I,C.c_float]);u3=fn(g,'glUniform3f',None,[I,C.c_float,C.c_float,C.c_float])
for i,n in enumerate(['Scene','Depth','Albedo','Shadow','AlbedoDepth']):ui(loc(program,n.encode()),i)
ui(loc(program,b'Count'),1)
for n,v in [('CapturedLit',0),('IsoView',1),('Range[0]',4),('HalfTan[0]',1.0),('NearFill[0]',0),('Gain[0]',1)]:uf(loc(program,n.encode()),v)
for n,v in [('Origin[0]',(0,0,.5)),('Forward[0]',(0,0,-1)),('ShadowOrigin[0]',(0,0,.5)),('ShadowForward[0]',(0,0,-1)),('ShadowRight[0]',(1,0,0)),('ShadowUp[0]',(0,1,0))]:u3(loc(program,n.encode()),*v)
identity=(C.c_float*16)(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)
for n in ['InverseViewProjection','ViewProjection']:fn(g,'glUniformMatrix4fv',None,[I,I,U,P])(loc(program,n.encode()),1,0,identity)
fn(g,'glUniform2f',None,[I,C.c_float,C.c_float])(loc(program,b'FogDistance'),0,100)
vao=U();fn(g,'glGenVertexArrays',None,[I,C.POINTER(U)])(1,C.byref(vao));fn(g,'glBindVertexArray',None,[U])(vao);fn(g,'glViewport',None,[I,I,I,I])(0,0,W,H);fn(g,'glDrawArrays',None,[U,I,I])(4,0,3)
pixels=(C.c_float*(W*H*4))();fn(g,'glReadPixels',None,[I,I,I,I,U,U,P])(0,0,W,H,0x1908,0x1406,pixels)
row=[pixels[(H//2*W+x)*4]for x in range(W)];assert all(0<=x<=1 for x in row);assert row[W//2]>row[0]+.02,(row[W//2],row[0]);assert max(abs(row[x+1]-row[x])for x in range(W-1))<.02
assert fn(g,'glGetError',U,[])()==0
from PIL import Image
img=Image.new('RGB',(W,H));img.putdata([tuple(round(max(0,min(1,pixels[i+j]))*255)for j in range(3))for i in range(0,len(pixels),4)]);img.resize((512,512)).save(r/'controlled-light-plane.png')
print('PRODUCTION_FRAGMENT_REAL_GL_DRAW_FINITE_SOFT_FALLOFF=PASS')
