package net.flashlight.battery;
public final class Lamp56{
 public static double[] direction(double[] forward){double h=Math.hypot(forward[0],forward[2]);if(!Double.isFinite(h)||h<1e-6)return new double[]{0,-.22,Math.sqrt(1-.22*.22)};double s=Math.sqrt(1-.22*.22)/h;return new double[]{forward[0]*s,-.22,forward[2]*s};}
 public static void pose(Object object){if(!Capture53.iso())return;Light6.Lamp lamp=(Light6.Lamp)object;if(lamp.owner!=R.get(Light6.mc(),"player"))return;lamp.forward=direction(lamp.forward);lamp.right=Light6.normal(Light6.cross(lamp.forward,new double[]{0,1,0}));lamp.up=Light6.normal(Light6.cross(lamp.right,lamp.forward));}
}
