from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent;o=r/'output';d=r/'dist';d.mkdir(exist_ok=True)
files=[dict(name=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in sorted(o.glob('*.jar'))];assert len(files)==2
(o/'manifest.json').write_text(json.dumps({'release':56,'files':files},indent=2));(o/'SHA256SUMS.txt').write_text(''.join(p['sha256']+'  '+p['name']+'\n'for p in files))
(o/'test-results.json').write_text(json.dumps({'java_asm':(r/'build.log').read_text(),'wall_pose_alt_priority_and_config':'PASS fixture','lamp_finite_ground_direction':'PASS fixture','production_copy_helper_format_cache_half_resolution':'PASS fixture','actual_gl_half_resolution_blit':['D24 PASS','D32F PASS','D24S8 PASS','D32FS8 PASS'],'glsl_compile_link_and_controlled_plane_draw':'PASS Mesa llvmpipe','profile_seconds':326.121,'render_copy_exclusive_fraction':57284/325900,'full_modpack_run':False,'post_patch_fps_measured':False},indent=2))
with zipfile.ZipFile(d/'Correccion-56-Luz-Arma-Optimizacion.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(o.glob('*.jar')):z.write(p,'mods/'+p.name)
 for n in ['LEEME.md','manifest.json','SHA256SUMS.txt','test-results.json']:z.write(o/n,n)
with zipfile.ZipFile(d/'Correccion-56-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','flash-src','tests','copy-tests']:
  for p in (r/folder).rglob('*.java'):z.write(p,str(p.relative_to(r)))
 for n in ['build.py','Patch56.java','test_helpers.py','test_copy.py','blit_test.py','shader_test.py','render_test.py','portable6.frag','controlled-light-plane.png','build.log','package.py','read_profile.py','profile.txt']:z.write(r/n,n)
 z.write(r.parent/'medical52/Patch52.java','base-tools/Patch52.java')
 for n in ['LEEME.md','manifest.json','test-results.json']:z.write(o/n,n)
for p in d.glob('*.zip'):
 with zipfile.ZipFile(p)as z:assert z.testzip()is None
print('TWO_JAR_MANIFEST_AND_DELIVERY_CRC=PASS')
