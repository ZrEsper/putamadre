from pathlib import Path
import struct,collections,json
b=Path('attachments/1b05d827-28e4-4dd9-8e7a-270483cb14f5/XdWEsZS4Gt.sparkprofile').read_bytes()
def var(b,i):
 n=s=0
 while True:
  x=b[i];i+=1;n|=(x&127)<<s
  if x<128:return n,i
  s+=7
  if s>70:raise ValueError()
def fields(b):
 i=0;d=collections.defaultdict(list)
 while i<len(b):
  k,i=var(b,i);f,w=k>>3,k&7
  if w==0:x,i=var(b,i)
  elif w==2:n,i=var(b,i);x=b[i:i+n];i+=n
  elif w in (1,5):n=8 if w==1 else 4;x=b[i:i+n];i+=n
  else:raise ValueError(w)
  d[f].append((w,x))
 return d
def raw(d,k,default=b''):return d[k][0][1] if d[k] else default
def msg(d,k):return fields(raw(d,k))
def string(d,k):return raw(d,k).decode(errors='replace')
def nums(d,k):
 out=[]
 for w,v in d[k]:
  if w==0:out.append(v)
  elif w==2:
   i=0
   while i<len(v):x,i=var(v,i);out.append(x)
 return out
def times(d,k):
 return sum(sum(struct.unpack('<'+'d'*(len(v)//8),v)) if w==2 else struct.unpack('<d',v)[0] for w,v in d[k])
def doubles(d):return {k:struct.unpack('<d',v[0][1])[0] for k,v in d.items() if v and v[0][0]==1}
top=fields(b);meta=msg(top,1);stats=msg(meta,8);print('duration seconds',(raw(meta,11,0)-raw(meta,2,0))/1000,'ticks',raw(meta,12,0));print('TPS',doubles(msg(stats,4)));print('MSPT',doubles(msg(msg(stats,5),1)));world=msg(stats,8);print('entities',raw(world,1,0));print('entity_counts',sorted([(string(fields(v),1),raw(fields(v),2,0)) for w,v in world[2]],key=lambda x:x[1],reverse=True)[:12])
for w,v in top[2]:
 t=fields(v);nodes=[]
 for w2,v2 in t[3]:
  n=fields(v2);nodes.append({'class':string(n,3),'method':string(n,4),'time':times(n,8),'children':nums(n,9)})
 total=times(t,4);print('thread',string(t,1),'total',total,'nodes',len(nodes),'roots',nums(t,5)[:8]);inc=collections.Counter();exc=collections.Counter()
 for n in nodes:
  name=n['class']+'.'+n['method'];inc[name]+=n['time'];exc[name]+=max(0,n['time']-sum(nodes[i]['time'] for i in n['children']))
 print('TOP INCLUSIVE',inc.most_common(20));print('TOP EXCLUSIVE',exc.most_common(16))
 Path('work/medical56/profile-summary.json').write_text(json.dumps({'total_ms':total,'inclusive':inc.most_common(150),'exclusive':exc.most_common(150)},indent=2))
 parents={}
 for i,n in enumerate(nodes):
  for child in n['children']:parents[child]=i
 def category(test):
  result=[]
  for i,n in enumerate(nodes):
   if not test(n):continue
   p=parents.get(i);found=False
   while p is not None:
    if test(nodes[p]):found=True;break
    p=parents.get(p)
   if not found:result.append((i,n))
  return sum(n['time'] for i,n in result),result
 for label,test in [('path creation',lambda n:n['class'].endswith(('PathNavigation','GroundPathNavigation')) and n['method']=='createPath'),('commands/functions',lambda n:n['class']=='net.minecraft.server.ServerFunctionManager' and n['method'] in ('tick','execute')),('zomboid',lambda n:n['class'].startswith('dev.zomboid.hordes.')),('mutant addon',lambda n:n['class'].startswith('dev.zomboid.mutants.'))]:
  value,entries=category(test);print('DEDUP',label,round(value/total*100,2),'percent wall sampled');
  if label=='path creation':
   attribution=collections.Counter()
   for i,n in entries:
    chain=[];p=parents.get(i)
    while p is not None:
     chain.append(nodes[p]['class']+'.'+nodes[p]['method']);p=parents.get(p)
    name=next((s for s in chain if s.startswith(('dev.zomboid.','net.corosus.','com.corosus.','net.mcreator.','com.example.','net.petemc.'))),'vanilla/other')
    attribution[name]+=n['time']
   print('PATH attribution',attribution.most_common(10))
