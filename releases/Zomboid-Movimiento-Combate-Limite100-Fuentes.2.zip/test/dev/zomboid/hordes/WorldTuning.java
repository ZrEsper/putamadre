package dev.zomboid.hordes;public class WorldTuning{static double cap=100;public static double get(String k){return cap;}}
