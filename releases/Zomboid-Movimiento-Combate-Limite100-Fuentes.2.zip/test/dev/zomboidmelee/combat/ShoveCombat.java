package dev.zomboidmelee.combat;public class ShoveCombat{public static boolean zombie(Object p){return p instanceof dev.zomboidmelee.boxing.HitTest.Zombie;}}
