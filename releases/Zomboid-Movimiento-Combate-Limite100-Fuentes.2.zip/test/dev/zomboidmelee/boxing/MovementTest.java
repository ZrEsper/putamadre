package dev.zomboidmelee.boxing;
import java.util.*;import net.minecraft.world.entity.Pose;import net.minecraft.core.BlockPos;import net.minecraft.world.phys.AABB;
public class MovementTest{
 public static class V{public double x,y,z;V(double a,double b,double c){x=a;y=b;z=c;}}
 public static class Ability{public boolean flying;}
 public static class P{double x=.5,y=0,z=.5;V v=new V(0,0,0);W world=new W();Ability ability=new Ability();boolean ground=true,alive=true,sprint=true,water,passenger;public boolean horizontalCollision,hurtMarked;Pose pose;
 public W level(){return world;}public double getX(){return x;}public double getY(){return y;}public double getZ(){return z;}public boolean onGround(){return ground;}public boolean isAlive(){return alive;}public boolean isSprinting(){return sprint;}public boolean isSpectator(){return false;}public boolean isPassenger(){return passenger;}public boolean isInWater(){return water;}public boolean isSleeping(){return false;}public boolean isUsingItem(){return false;}public Ability getAbilities(){return ability;}public Pose getForcedPose(){return pose;}public void setForcedPose(Pose p){pose=p;}public V getLookAngle(){return new V(1,0,0);}public V getDeltaMovement(){return v;}public void setDeltaMovement(double a,double b,double c){v=new V(a,b,c);}public BlockPos blockPosition(){return new BlockPos((int)Math.floor(x),(int)Math.floor(y),(int)Math.floor(z));}}
 public static class Shape{boolean empty;Shape(boolean e){empty=e;}public boolean isEmpty(){return empty;}public AABB bounds(){return new AABB(0,0,0,1,1,1);}}
 public static class Block{boolean empty;Block(boolean e){empty=e;}public boolean isAir(){return empty;}public Shape getCollisionShape(W w,BlockPos p){return new Shape(empty);}}
 public static class W{long time=100;int height=2;boolean ceiling;public long getGameTime(){return time;}public boolean hasChunkAt(BlockPos p){return true;}public Block getBlockState(BlockPos p){return new Block(!(p.x()==1&&p.z()==0&&p.y()>=0&&p.y()<height));}public boolean noCollision(P p,AABB b){for(int i=0;i<height;i++)if(b.intersects(new AABB(1,i,0,2,i+1,1)))return false;return !ceiling||b.maxY<2.9;}}
 static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
 public static void main(String[] args){
  P p=new P();Slide20.tick(p);p.x+=.3;p.world.time++;Slide20.tick(p);check(p.v.x==0,"position is distinct from server velocity");Slide20.request(p);check(Slide20.STATES.containsKey(p),"sprint slide accepted from measured motion");check(p.pose==Pose.CROUCHING,"crouch applied");check(Net20.last>=108&&Net20.last<=122,"duration cue");p.horizontalCollision=true;Slide20.tick(p);check(!Slide20.STATES.containsKey(p)&&p.pose==null,"wall abort restores pose");Slide20.request(p);check(!Slide20.STATES.containsKey(p),"cooldown enforced");
  check(Slide20.duration(.5)>Slide20.duration(.15),"speed increases duration");check(Slide20.speed(.5,10)<Slide20.speed(.5,1),"friction");
  p=new P();Parkour20.tick(p,true);p.ground=false;p.y=.8;Parkour20.request(p);check(Parkour20.active(p),"two-block ledge found");check(Net20.last==200,"mantle sync");double maxY=p.y;
  for(int n=0;n<29&&Parkour20.active(p);n++){p.world.time++;Parkour20.tick(p,true);p.x+=p.v.x;p.y+=p.v.y;p.z+=p.v.z;maxY=Math.max(maxY,p.y);}
  check(!Parkour20.active(p)&&Math.abs(p.x-1.5)<.13&&p.y>=2,"mantle reaches top and exits");check(maxY<2.5,"bounded mantle");
  p=new P();p.world.ceiling=true;Parkour20.tick(p,true);p.ground=false;p.y=.8;Parkour20.request(p);check(!Parkour20.active(p),"ceiling rejected");
  p=new P();p.world.height=3;Parkour20.tick(p,true);p.ground=false;p.y=.8;Parkour20.request(p);check(!Parkour20.active(p),"three blocks rejected");
  p=new P();p.world.height=0;Parkour20.tick(p,true);p.ground=false;p.y=.8;Parkour20.request(p);check(!Parkour20.active(p),"no midair double jump");
  p=new P();Parkour20.tick(p,true);p.ground=false;p.y=.8;Parkour20.request(p);p.world.ceiling=true;Parkour20.tick(p,true);check(!Parkour20.active(p),"changed landing geometry aborts");
  for(boolean heavy:new boolean[]{false,true}){double last=0;for(int n=0;n<=10000;n++){double v=Motion20.strike(n/10000d,heavy);check(Double.isFinite(v)&&Math.abs(v-last)<.005,"smooth strike");last=v;}check(Math.abs(last)<1e-9,"settled pose");}
  check(Math.abs(Motion20.strike(.24,false)-Motion20.strike(.24,true))>1,"different heavy anticipation");check(Motion20.lift(.32)>.99&&Motion20.drop(.32)<.01&&Motion20.drop(.55)>.99,"stomp up then down");
  System.out.println("PASS: measured slide speed, friction, collision/pose cleanup, cooldown; two-block mantle, ceiling and 3-block rejection, no air jump, live obstruction; 20,002 animation samples.");
 }
}
