package dev.zomboidmelee.boxing;public class Net20{static int last;public static void cue(Object p,int a){last=a;}}
