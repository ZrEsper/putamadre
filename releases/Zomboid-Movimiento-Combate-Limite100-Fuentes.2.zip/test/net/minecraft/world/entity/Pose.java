package net.minecraft.world.entity;public enum Pose{CROUCHING,SWIMMING,STANDING}
