from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import copy,hashlib,json
root=Path('work/action20');out=root/'release';out.mkdir(exist_ok=True)
specs=[
('work/action19/release/zomboid-global-melee-animations-2.3.1-v19-action-motion.jar','zomboid-global-melee-animations-2.3.1-v20-parkour-bodycam-combat.jar','work/action20/classes','dev/zomboidmelee/'),
('attachments/48bb10c2-6267-4fcc-88ac-d875c0753e8f/zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.48-clear-panel.jar','zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.49-global100.jar','work/action20/classes','dev/zomboid/hordes/'),
('work/visionfix/tacz-neoforge-1.21.1-1.1.8-hotfix-r7-third-person-pz.18-spas-reload-guard.jar','tacz-neoforge-1.21.1-1.1.8-hotfix-r7-third-person-pz.19-wall-alt-slide.jar','work/action20/coreclasses','')]
manifest=[]
for source,name,folder,prefix in specs:
 changes={p.relative_to(folder).as_posix():p.read_bytes() for p in (Path(folder)/prefix).rglob('*.class')}
 assert not any(p.startswith(('net/minecraft/','test/')) for p in changes)
 with ZipFile(source) as base,ZipFile(out/name,'w',ZIP_DEFLATED) as dest:
  for info in base.infolist():dest.writestr(copy.copy(info),changes.get(info.filename,base.read(info)))
  for p,b in changes.items():
   if p not in base.namelist():dest.writestr(p,b)
 with ZipFile(source) as base,ZipFile(out/name) as dest:
  assert dest.testzip() is None
  assert len(dest.namelist())==len(set(dest.namelist()))
  for p in base.namelist():
   if p not in changes:assert base.read(p)==dest.read(p),p
 manifest.append(dict(input=source,input_sha256=hashlib.sha256(Path(source).read_bytes()).hexdigest(),file=name,sha256=hashlib.sha256((out/name).read_bytes()).hexdigest(),changed=sorted(changes)))
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
(out/'LEEME.txt').write_text('''MOVIMIENTO, COMBATE Y LIMITE GLOBAL — NEOFORGE 1.21.1

INSTALACION
Cierra Minecraft y el servidor. Sustituye, no dupliques, estos tres mods:
- Global Melee anterior -> v20-parkour-bodycam-combat.
- Zomboid Hordes .48 -> .49-global100.
- TaCZ principal .18 -> .19-wall-alt-slide.
Pon las mismas versiones en clientes y servidor. El JAR TaCZ completo ya esta en este ZIP; no necesitas unir partes 7z.
Conserva Tactical marks200-85s.5, taczaddon, Gore 1.0.9, First Aid y tu resource pack actuales. Este ZIP no va en resourcepacks.

CONTROLES Y MOVIMIENTO
Primera persona: oscilacion suave tipo bodycam incluso parado, mayor al caminar/correr y reducida al apuntar. Solo modifica la camara visual, no la direccion logica de disparo. No cambia la camara isometrica.
Corriendo en el suelo, pulsa C o la tecla configurada para agacharte: deslizada. La velocidad real de desplazamiento determina impulso y duracion; tiene friccion, limite y descanso de 35 ticks. Se interrumpe ante pared, borde, agua o al montar. Emite tres particulas del suelo cada tres ticks, como maximo unas 24 por deslizada. No atraviesa bloques.
C ya estaba asignada a cuerpo a tierra en este TaCZ: al correr tiene prioridad la deslizada; parado conserva cuerpo a tierra. Una tecla reasignada al cuerpo a tierra tambien usa esa prioridad. Agacharse no cambia su asignacion global.
Junto a un borde, salta y vuelve a pulsar salto en menos de 0.65 segundos: trepada de hasta DOS BLOQUES desde el suelo de salida. Necesita un borde cercano, superficie amplia y espacio para el cuerpo. Levanta el cuerpo antes de avanzar. No permite doble salto libre, subir tres bloques ni atravesar techos. Cancelacion automatica si se tapa el destino.
Servidor valida maniobras; cliente reproduce el movimiento y la pose. La trepada y la deslizada necesitan comprobacion en una partida real, especialmente con ping alto y superficies parciales.

ARMA JUNTO A PARED / ALT
Postura compacta de 20 grados en lugar de la inclinacion larga de 54 grados. Pared y ALT usan la mayor intensidad, sin sumar desplazamientos. Se sustituye el bloqueo de render por tiempo por deteccion de la transformacion activa para evitar aplicarla de nuevo dentro del mismo render.
ALT conserva la funcion de arma levantada. Se conserva el bloqueo del disparo cuando el canon esta obstruido y al mantener esa postura. No se modifica la balistica ni la recarga SPAS.

COMBATE Y BUSQUEDA
Golpe ligero recto y pesado cruzado tienen preparacion, trayectoria y duracion distintas. La pisada levanta la rodilla y baja el pie: ya no empuja la pierna hacia delante como una patada.
Impactos de punos validados pueden registrarse con la cadencia de ocho ticks sin ser descartados por la ventana residual de invulnerabilidad del zombi. Se mantienen validacion, alcance, energia y cooldown; no se quita invulnerabilidad a jugadores.
Sacudida amortiguada al impacto confirmado, mayor en pesado y pisada. Las animaciones se notifican a jugadores cercanos.
Chavetazo: empuje corto de brazos y arma, sin el giro anterior de unos 144 grados. Se evita ejecutar simultaneamente la antigua animacion nativa del arma.
Buscar en menus de cofre, barril y cadaver: pose de inclinarse y rebuscar con ambos brazos, con entrada/salida gradual. Depende del menu reconocido; las interfaces externas con otro tipo de menu pueden necesitar un adaptador.
Son animaciones originales procedurales; no contienen animaciones copiadas de Call of Duty o Doom.

100 ZOMBIS ACTIVOS
Panel sencillo, ambiente/poblacion: "Zombis activos globales (normal: 100)". Editable como numero y con la rueda, entre 10 y 1000. Se guarda por mundo. Cuenta los zombis gestionados por la reserva en todas las dimensiones; no es 100 por chunk.
Al bajar el limite, los inactivos excedentes pasan a la reserva existente. Se impiden nuevas apariciones que excedan el presupuesto. Para mantener la prioridad de combate que pediste, los que YA combaten/se acercan y las oleadas protegidas pueden producir un exceso temporal; no se borran delante del jugador. El sistema vuelve al presupuesto cuando dejan de estar protegidos.
No se usa la limpieza para borrar inventarios: se conserva la exclusion previa de zombis/cadaveres de jugador. Los limites locales anteriores siguen existiendo y pueden restringir adicionalmente las apariciones.

PERFILES SPARK ADJUNTADOS
8We32b1F51: aproximadamente 15.46 TPS, media 62.15 ms por tick y pico 276.36 ms; 511 zombis, 264 objetos tirados y 107 segmentos de ciempies. Reducir zombis activos aborda una parte importante de la carga de entidades; no elimina la carga de otros mobs ni objetos.
OGEZLWrkZH: perfil de render con 517 zombis; hay coste de evaluacion de modelos EMF y reflexion. Es una captura distinta: no equivale a medir FPS despues de estos cambios.

VERIFICACION
Java 21, verificacion ASM de las clases modificadas y comparacion byte a byte de recursos/clases conservados. Pruebas de logica: velocidad medida y friccion, restauracion de postura y cooldown, trepada a 2 bloques, rechazo de 3 bloques/techo/destino obstruido, presupuesto compartido y valores invalidos, ventana de impactos y continuidad de curvas.
No se ha ejecutado Minecraft en este entorno. Las pruebas con objetos simulados no verifican apariencia, sincronizacion real ni ausencia de conflictos con todo el modpack. Prueba primero en una copia del mundo y con un segundo jugador antes de reemplazar el servidor habitual.
''',encoding='utf-8')
with ZipFile(out/'Zomboid-Movimiento-Combate-Limite100.2.zip','w',ZIP_DEFLATED) as z:
 for p in out.iterdir():
  if p.suffix=='.jar' or p.name in ['LEEME.txt','manifest.json']:z.write(p,p.name)
with ZipFile(out/'Zomboid-Movimiento-Combate-Limite100-Fuentes.2.zip','w',ZIP_DEFLATED) as z:
 for folder in ['src','coresrc','test']:
  for p in (root/folder).rglob('*.java'):z.write(p,p.relative_to(root).as_posix())
 for p in [root/'Patch.java',root/'build.py',out/'LEEME.txt',out/'manifest.json']:z.write(p,p.name)
print('Built:',[(p.name,p.stat().st_size) for p in out.glob('*.zip')])
