package dev.zomboid.hordes;
import java.util.*;
public final class Global49 {
 public static final String KEY="limite_global_activos";
 public static void install(Map<String,Double> defaults,Map<String,Double> min,Map<String,Double> max,Map<String,Double> values){defaults.put(KEY,100d);min.put(KEY,10d);max.put(KEY,1000d);values.putIfAbsent(KEY,100d);}
 public static void validate(String key,double value){if(KEY.equals(key)&&(!Double.isFinite(value)||value!=Math.rint(value)||value<10||value>1000))throw new IllegalArgumentException("El limite global debe ser un entero entre 10 y 1000.");}
 public static double step(double value,String key){return KEY.equals(key)?1d:value;}
 public static int limit(){return (int)WorldTuning.get(KEY);}
 public static int count(){Map<?,?> states=(Map<?,?>)FastFields.get(ZoneReserve.class,"DATA");int total=0;for(Object state:states.values())total+=((Map<?,?>)FastFields.get(state,"active")).size();return total;}
 public static boolean room(boolean local){return local&&count()<limit();}
 public static int preLimit(){return count()>limit()?0:ZoneReserve.limit;}
 public static boolean joinProtected(boolean value){return value&&count()<limit();}
}
