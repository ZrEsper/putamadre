package dev.zomboid.hordes;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
public final class FastFields {
 private static final ClassValue<Map<String,Field>> FIELDS=new ClassValue<>(){protected Map<String,Field> computeValue(Class<?> c){Map<String,Field> m=new HashMap<>();for(Class<?> k=c;k!=null;k=k.getSuperclass())for(Field f:k.getDeclaredFields()){if(!m.containsKey(f.getName())&&f.trySetAccessible())m.put(f.getName(),f);}return Collections.unmodifiableMap(m);}};
 private static final Map<String,Optional<Class<?>>> TYPES=new ConcurrentHashMap<>();
 public static Class<?> type(String n){return TYPES.computeIfAbsent(n,k->{try{return Optional.of(Class.forName(k));}catch(ClassNotFoundException e){return Optional.empty();}}).orElseThrow(()->new IllegalStateException(n));}
 static Field field(Object o,String n){Class<?> c=o instanceof Class<?> t?t:o.getClass();Field f=FIELDS.get(c).get(n);if(f==null)throw new IllegalStateException(c.getName()+"."+n);return f;}
 public static Object get(Object o,String n){try{return field(o,n).get(o instanceof Class<?>?null:o);}catch(IllegalAccessException e){throw new IllegalStateException(n,e);}}
 public static void set(Object o,String n,Object v){try{field(o,n).set(o instanceof Class<?>?null:o,v);}catch(IllegalAccessException e){throw new IllegalStateException(n,e);}}
}
