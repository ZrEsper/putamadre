package dev.zomboidmelee.combat;
import dev.zomboidmelee.boxing.Motion20;
public final class StockMotion{
 public static final double LENGTH=.55;
 public static Frame at(double time){double p=time/LENGTH;if(!Double.isFinite(p)||p<=0||p>=1)return new Frame(0,0,0,0,0,0);double w=Motion20.shove(p);return new Frame(-.035*w,.035*w,-.23*w,(float)(-9*w),(float)(-5*w),(float)(4*w));}
 public record Frame(double x,double y,double z,float rx,float ry,float rz){}
}
