/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboidmelee.boxing;

import dev.zomboidmelee.boxing.Boxing16;
import dev.zomboidmelee.boxing.BoxingArms17;
import dev.zomboidmelee.boxing.Combat18;
import dev.zomboidmelee.boxing.Motion16;
import dev.zomboidmelee.boxing.R;
import dev.zomboidmelee.boxing.Stomp18;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.LongSupplier;

public final class BoxingClient16 {
    static LongSupplier CLOCK = System::nanoTime;
    static double lastSwing;
    static boolean heavy;
    static boolean stomping;
    static long nextPunch;
    static Object owner;
    static boolean held;
    static boolean renderingHands;
    static boolean warned;
    static boolean blockSwingSent;
    static long pressed;
    static long started;
    static int combo;
    static final Map<Object, Remote> REMOTE;

    static {
        combo = -1;
        REMOTE = new WeakHashMap<Object, Remote>();
    }

    static Object mc() {
        return R.call(R.type("net.minecraft.client.Minecraft"), "getInstance", new Object[0]);
    }

    static Object optional(Object object, String string) {
        try {
            return R.get(object, string);
        }
        catch (IllegalStateException illegalStateException) {
            return null;
        }
    }

    public static boolean usable(Object object) {
        return Boxing16.empty(object) && R.yes(R.call(object, "isAlive", new Object[0])) && !R.yes(R.call(object, "isSpectator", new Object[0])) && !R.yes(R.call(object, "isSleeping", new Object[0])) && !R.yes(R.call(object, "isUsingItem", new Object[0])) && !BoxingClient16.visorBusy(object);
    }

    static boolean visorBusy(Object object) {
        try {
            return R.num(R.call(R.call(object, "getPersistentData", new Object[0]), "getInt", "NVG_ANIM_TICK")) > 0.0;
        }
        catch (IllegalStateException illegalStateException) {
            return false;
        }
    }

    public static double phase(long l, long l2) {
        return l2 == 0L ? 1.0 : (double)(l - l2) / 4.0E8;
    }

    public static boolean holdingReady(long l, long l2) {
        return l2 != 0L && l - l2 >= 350000000L;
    }

    static void reset() {
        heavy = false;
        stomping = false;
        nextPunch = 0L;
        held = false;
        blockSwingSent = false;
        started = 0L;
        pressed = 0L;
        combo = -1;
    }

    static void update(Object object, Object object2, long l) {
        if (object2 != owner) {
            owner = object2;
            BoxingClient16.reset();
            REMOTE.clear();
        }
        if (object2 == null || !BoxingClient16.usable(object2) || R.get(object, "screen") != null || !R.yes(R.call(object, "isWindowActive", new Object[0]))) {
            BoxingClient16.reset();
            return;
        }
        boolean bl = R.yes(R.call(R.get(R.get(object, "options"), "keyAttack"), "isDown", new Object[0]));
        if (bl && !held) {
            pressed = l;
            blockSwingSent = false;
            BoxingClient16.begin(l);
        } else if (!bl) {
            pressed = 0L;
        }
        held = bl;
    }

    static void begin(long l) {
        if (l < nextPunch || (started != 0L && l-started < 60000000L)) {
            return;
        }
        heavy = false;
        stomping = false;
        ++combo;
        started = l;
    }

    public static void tick(Object object) {
        Client20.poll();
        Object object2 = BoxingClient16.mc();
        BoxingClient16.update(object2, R.get(object2, "player"), CLOCK.getAsLong());
    }

    static Object target(Object object) {
        Object object2 = R.get(object, "hitResult");
        try {
            Class<?> clazz = R.type("com.cleannrooster.dungeons_iso.mod.Mod");
            if (R.yes(R.get(clazz, "enabled"))) {
                object2 = R.get(clazz, "crosshairTarget");
            }
        }
        catch (IllegalStateException illegalStateException) {}
        return object2;
    }

    public static void input(Object object) {
        boolean bl;
        Object object2 = BoxingClient16.mc();
        Object object3 = R.get(object2, "player");
        if (object3 == null || !BoxingClient16.usable(object3) || R.get(object2, "screen") != null) {
            return;
        }
        if (!R.yes(R.call(object, "isAttack", new Object[0]))) {
            BoxingClient16.use(object, object2, object3);
            return;
        }
        long l = CLOCK.getAsLong();
        BoxingClient16.update(object2, object3, l);
        Object object4 = BoxingClient16.target(object2);
        if (object4 != null) {
            R.set(object2, "hitResult", object4);
        }
        boolean bl2 = bl = object4 != null && R.call(object4, "getType", new Object[0]).toString().equals("BLOCK");
        if (bl && !BoxingClient16.holdingReady(l, pressed)) {
            R.call(object, "setCanceled", true);
            R.call(object, "setSwingHand", false);
            if (!blockSwingSent) {
                blockSwingSent = true;
                R.call(object3, "swing", R.get(R.type("net.minecraft.world.InteractionHand"), "MAIN_HAND"));
            }
            return;
        }
        if (!bl) {
            if (l < nextPunch) {
                R.call(object, "setCanceled", true);
                R.call(object, "setSwingHand", false);
                return;
            }
            BoxingClient16.begin(l);
            nextPunch = l + 400000000L;
        }
    }

    public static void mouse(Object object) {
        Object object2 = BoxingClient16.mc();
        Object object3 = R.get(object2, "player");
        if (object3 == null || !BoxingClient16.usable(object3) || R.get(object2, "screen") != null || !R.yes(R.call(object2, "isWindowActive", new Object[0]))) {
            return;
        }
        int n = ((Number)R.call(object, "getButton", new Object[0])).intValue();
        if (!R.yes(R.call(R.get(R.get(object2, "options"), "keyAttack"), "matchesMouse", n))) {
            return;
        }
        long l = CLOCK.getAsLong();
        BoxingClient16.update(object2, object3, l);
        int n2 = ((Number)R.call(object, "getAction", new Object[0])).intValue();
        if (n2 == 1) {
            pressed = l;
            held = true;
            blockSwingSent = false;
            BoxingClient16.begin(l);
        } else if (n2 == 0) {
            pressed = 0L;
            held = false;
        }
    }

    public static boolean bareClient() {
        Object object = BoxingClient16.mc();
        return Boxing16.empty(R.get(object, "player"));
    }

    public static void hand(Object object) {
        if(Client20.searchHand(object))return;
        Object object2 = BoxingClient16.mc();
        Object object3 = R.get(object2, "player");
        if (object3 == null || !BoxingClient16.usable(object3) || R.get(object2, "screen") != null) {
            return;
        }
        if (!R.call(object, "getHand", new Object[0]).toString().equals("MAIN_HAND")) {
            R.call(object, "setCanceled", true);
            return;
        }
        if (BoxingClient16.renderFirstPerson(((Number)R.call(object, "getPartialTick", new Object[0])).floatValue(), R.call(object, "getPoseStack", new Object[0]), R.call(object, "getMultiBufferSource", new Object[0]), object3, ((Number)R.call(object, "getPackedLight", new Object[0])).intValue())) {
            R.call(object, "setCanceled", true);
        }
    }

    public static boolean renderFirstPerson(float f, Object object, Object object2, Object object3, int n) {
        boolean bl;
        Object object4 = BoxingClient16.mc();
        if (object3 == null || !BoxingClient16.usable(object3) || R.get(object4, "screen") != null) {
            return false;
        }
        long l = CLOCK.getAsLong();
        Object object5 = BoxingClient16.target(object4);
        boolean bl2 = bl = held && BoxingClient16.holdingReady(l, pressed) && object5 != null && R.call(object5, "getType", new Object[0]).toString().equals("BLOCK");
        double d = bl ? (double)((l - pressed - 350000000L) % 420000000L) / 4.2E8 : (heavy ? (started == 0L ? 1.0 : (double)(l - started) / 6.2E8) : BoxingClient16.phase(l, started));
        if(stomping&&started!=0)d=(l-started)/7.5E8;
        double d2 = R.num(R.call(object3, "getAttackAnim", Float.valueOf(f)));
        if (!bl && started == 0L && d >= 1.0 && d2 > 0.0) {
            if (lastSwing <= 0.0 || d2 < lastSwing - 0.2) {
                ++combo;
            }
            d = d2;
        }
        lastSwing = d2;
        try {
            renderingHands = true;
            Object object6 = R.call(R.call(object4, "getEntityRenderDispatcher", new Object[0]), "getRenderer", object3);
            int n2 = 0;
            while (n2 < 2) {
                double d3 = n2 == Math.floorMod(combo,2) ? Motion20.strike(d,heavy) : .035*Motion20.strike(d,heavy);
                BoxingArms17.draw(object6, object, object2, n, object3, n2, stomping ? 0.0 : d3);
                ++n2;
            }
            if (stomping && d < 1.0) {
                BoxingArms17.leg(object6, object, object2, n, object3, d);
            }
            BoxingArms17.flush(object2);
            return true;
        }
        catch (RuntimeException runtimeException) {
            if (!warned) {
                warned = true;
                System.err.println("[Boxing18] Native skin-arm render failed: " + String.valueOf(runtimeException));
            }
            return false;
        }
        finally {
            renderingHands = false;
        }
    }

    static void rotate(Object object, String string, double d) {
        R.call(object, "mulPose", R.call(R.get(R.type("com.mojang.math.Axis"), string), "rotationDegrees", Float.valueOf((float)d)));
    }

    public static void body(Object m,Object p){Client20.body(m,p);}

    static void use(Object object, Object object2, Object object3) {
        if (!R.yes(R.call(object, "isUseItem", new Object[0])) || !R.call(object, "getHand", new Object[0]).toString().equals("MAIN_HAND")) {
            return;
        }
        Object object4 = BoxingClient16.target(object2);
        int n = -1;
        if (object4 != null) {
            String string = R.call(object4, "getType", new Object[0]).toString();
            if (string.equals("BLOCK")) {
                return;
            }
            if (string.equals("ENTITY")) {
                Object object5 = R.call(object4, "getEntity", new Object[0]);
                if (!Combat18.zombie(object5)) {
                    return;
                }
                n = ((Number)R.call(object5, "getId", new Object[0])).intValue();
            }
        }
        R.call(object, "setCanceled", true);
        R.call(object, "setSwingHand", false);
        long l = CLOCK.getAsLong();
        if (l < nextPunch) {
            return;
        }
        heavy = true;
        stomping = object4 != null && R.call(object4, "getType", new Object[0]).toString().equals("ENTITY") && Stomp18.headAim(object3, R.call(object4, "getEntity", new Object[0]));
        ++combo;
        started = l;
        nextPunch = l + (stomping ? 1000000000L : 900000000L);
        Combat18.send(n, stomping ? 1 : 0);
        R.call(object3, "swing", R.get(R.type("net.minecraft.world.InteractionHand"), "MAIN_HAND"));
    }

    public static double cameraWave(long l, long l2, boolean bl) {
        if (l2 == 0L) {
            return 0.0;
        }
        double d = (double)(l - l2) / (bl ? 4.6E8 : 3.2E8);
        return d <= 0.0 || d >= 1.0 ? 0.0 : Motion16.curve(d, new double[]{0,.28,.35,.52,.7,1}, new double[]{0,0,1,-.18,0,0});
    }

    public static void camera(Object event){Client20.camera(event);}

    static void flinch(Object object, Object object2) {
        if (Stomp18.GORE != null) {
            return;
        }
        if (!Combat18.zombie(object2)) {
            return;
        }
        int n = ((Number)R.get(object2, "hurtTime")).intValue();
        if (n > 0) {
            BoxingArms17.flinch(object, (float)Math.sin(Math.min(1.0, (double)n / 10.0) * Math.PI / 2.0));
        }
    }

    public static void prone(Object entity,Object poses){ Action19.prone(entity,poses); }

    static final class Remote {
        double last;
        int combo = -1;

        Remote() {
        }
    }
}

