package dev.zomboidmelee.boxing;
import java.util.*;
public final class Server20 {
 private static final Map<Object,Boolean> SEARCH=new WeakHashMap<>();
 public static boolean searchMenu(Object player){Object menu=R.get(player,"containerMenu");if(menu==null||menu==R.get(player,"inventoryMenu"))return false;String n=menu.getClass().getName().toLowerCase(Locale.ROOT);return n.contains("chest")||n.contains("barrel")||n.contains("corpse")||n.contains("remains")||n.contains("loot")||n.contains("scaveng");}
 public static void tick(Object event){Object p=R.call(event,"getEntity");if(!R.type("net.minecraft.server.level.ServerPlayer").isInstance(p))return;Slide20.tick(p);Parkour20.tick(p,true);boolean now=searchMenu(p);Boolean old=SEARCH.put(p,now);if(now!=(old!=null&&old))Net20.cue(p,now?14:15);}
 public static void prepare(Object target){if(target!=null&&Combat18.zombie(target)){int old=((Number)R.get(target,"invulnerableTime")).intValue();if(old>10)R.set(target,"invulnerableTime",10);}}
 public static boolean vanilla(Object player,Object target){
  if(R.yes(R.call(R.call(player,"level"),"isClientSide")))return true;
  if(!Boxing16.empty(player)){
   Object melee=R.call(R.type("me.xjqsh.lrtactical.api.item.IMeleeWeapon"),"of",R.call(player,"getMainHandItem"));
   return melee!=null||R.yes(R.call(R.type("com.armilp.ezweight.stamina.StaminaCommon"),"consume",player,60d));
  }
  if(Combat18.time(player)<Combat18.NEXT.getOrDefault(player,Long.MIN_VALUE))return false;
  if(!R.yes(R.call(R.type("com.armilp.ezweight.stamina.StaminaCommon"),"consume",player,60d))){Net20.cue(player,19);return false;}
  if(!Combat18.gate(player,target))return false;
  prepare(target);Net20.cue(player,10);return true;
 }
 public static void hit(Object event){Object victim=R.call(event,"getEntity");if(R.yes(R.call(R.call(victim,"level"),"isClientSide"))||R.num(R.call(event,"getNewDamage"))<=0)return;
  Object source=R.call(event,"getSource"),p=R.call(source,"getEntity");
  if(p!=null&&R.type("net.minecraft.server.level.ServerPlayer").isInstance(p)&&p==R.call(source,"getDirectEntity")&&Boxing16.empty(p))Net20.cue(p,Combat18.HEAVY.get()?17:16);
 }
}
