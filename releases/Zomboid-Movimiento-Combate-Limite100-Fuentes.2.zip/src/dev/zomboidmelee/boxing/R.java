/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboidmelee.boxing;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class R {
    private static final Map<String, Method> METHODS = new ConcurrentHashMap<String, Method>();

    public static Class<?> type(String n){return FastFields.type(n);}
    /*
     * WARNING - void declaration
     */
    public static Object call(Object object2, String string, Object ... objectArray) {
        try {
            Class<?> clazz = object2 instanceof Class ? (Class<?>)object2 : object2.getClass();
            String string2 = clazz.getName() + "#" + string + Arrays.toString(Arrays.stream(objectArray).map(object -> object == null ? null : object.getClass()).toArray());
            Method genericDeclaration = METHODS.get(string2);
            if (genericDeclaration == null) {
                ArrayList<Method> arrayList = new ArrayList<Method>(Arrays.asList(clazz.getMethods()));
                Class<?> var7_10 = clazz;
                while (var7_10 != null) {
                    arrayList.addAll(Arrays.asList(var7_10.getDeclaredMethods()));
                    var7_10 = var7_10.getSuperclass();
                }
                block4: for (Method method : arrayList) {
                    if (!method.getName().equals(string) || method.getParameterCount() != objectArray.length) continue;
                    Class<?>[] classArray = method.getParameterTypes();
                    int n = 0;
                    while (n < objectArray.length) {
                        Class<?> clazz3 = classArray[n];
                        if (clazz3.isPrimitive()) {
                            clazz3 = R.box(clazz3);
                        }
                        if (objectArray[n] == null ? classArray[n].isPrimitive() : !clazz3.isInstance(objectArray[n])) continue block4;
                        ++n;
                    }
                    genericDeclaration = method;
                    genericDeclaration.setAccessible(true);
                    METHODS.put(string2, genericDeclaration);
                    break;
                }
                if (genericDeclaration == null) {
                    throw new NoSuchMethodException(string2);
                }
            }
            return genericDeclaration.invoke(object2 instanceof Class ? null : object2, objectArray);
        }
        catch (InvocationTargetException invocationTargetException) {
            throw new IllegalStateException(string, invocationTargetException.getCause());
        }
        catch (Exception exception) {
            throw new IllegalStateException(string, exception);
        }
    }

    private static Class<?> box(Class<?> clazz) {
        if (clazz == Integer.TYPE) {
            return Integer.class;
        }
        if (clazz == Long.TYPE) {
            return Long.class;
        }
        if (clazz == Float.TYPE) {
            return Float.class;
        }
        if (clazz == Double.TYPE) {
            return Double.class;
        }
        if (clazz == Boolean.TYPE) {
            return Boolean.class;
        }
        return clazz;
    }

    public static Object get(Object o,String n){return FastFields.get(o,n);}
    public static Object make(String string, Object ... objectArray) {
        try {
            Constructor<?>[] constructorArray = R.type(string).getDeclaredConstructors();
            int n = constructorArray.length;
            int n2 = 0;
            while (n2 < n) {
                Constructor<?> constructor = constructorArray[n2];
                if (constructor.getParameterCount() == objectArray.length) {
                    Class<?>[] classArray = constructor.getParameterTypes();
                    boolean bl = true;
                    int n3 = 0;
                    while (n3 < objectArray.length) {
                        if (objectArray[n3] == null ? classArray[n3].isPrimitive() : !R.box(classArray[n3]).isInstance(objectArray[n3])) {
                            bl = false;
                        }
                        ++n3;
                    }
                    if (bl) {
                        constructor.setAccessible(true);
                        return constructor.newInstance(objectArray);
                    }
                }
                ++n2;
            }
            throw new NoSuchMethodException(string);
        }
        catch (Exception exception) {
            throw new IllegalStateException(string, exception);
        }
    }

    public static void set(Object o,String n,Object v){FastFields.set(o,n,v);}
    public static double num(Object object) {
        return ((Number)object).doubleValue();
    }

    public static long lng(Object object) {
        return ((Number)object).longValue();
    }

    public static boolean yes(Object object) {
        return Boolean.TRUE.equals(object);
    }

    public static double coord(Object object, String string) {
        return R.num(R.call(object, "get" + string, new Object[0]));
    }

    public static void warn(String string, Throwable throwable) {
        System.err.println("[iso-tacz] " + string + ": " + String.valueOf(throwable));
        throwable.printStackTrace(System.err);
    }
}

