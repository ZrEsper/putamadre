/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboidmelee.boxing;

import dev.zomboidmelee.boxing.Boxing16;

import dev.zomboidmelee.boxing.R;
import dev.zomboidmelee.boxing.Stomp18;
import java.lang.reflect.Array;
import java.lang.reflect.Proxy;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.WeakHashMap;

public final class Combat18 {
    static final Map<Object, Long> NEXT = Collections.synchronizedMap(new WeakHashMap());
    static final ThreadLocal<Boolean> HEAVY = ThreadLocal.withInitial(() -> false);

    static long time(Object object) {
        return R.lng(R.call(R.call(object, "level", new Object[0]), "getGameTime", new Object[0]));
    }

    static boolean zombie(Object object) {
        return R.yes(R.call(R.type("dev.zomboidmelee.combat.ShoveCombat"), "zombie", object));
    }

    public static boolean gate(Object object, Object object2) {
        if (!Boxing16.empty(object) || R.yes(R.call(R.call(object, "level", new Object[0]), "isClientSide", new Object[0]))) {
            return true;
        }
        long l = Combat18.time(object);
        if (l < NEXT.getOrDefault(object, Long.MIN_VALUE)) {
            return false;
        }
        NEXT.put(object, l + 8L);
        Combat18.mark(object2, l);
        return true;
    }

    static void mark(Object object, long l) {
        if (object != null && Combat18.zombie(object)) {
            R.call(R.call(object, "getPersistentData", new Object[0]), "putLong", "boxing18_no_launch", l + 2L);
        }
    }

    public static void knockback(Object object) {
        Object object2 = R.call(object, "getEntity", new Object[0]);
        if (!Combat18.zombie(object2)) {
            return;
        }
        long l = R.lng(R.call(R.call(object2, "getPersistentData", new Object[0]), "getLong", "boxing18_no_launch"));
        if (l > Combat18.time(object2)) {
            R.call(object, "setCanceled", true);
        }
    }

    public static int stunTicks() {
        return HEAVY.get() != false ? 14 : 8;
    }

    public static void register(Object e){Net20.register(e);}

    public static void send(int n) {
        Combat18.send(n, 0);
    }

    public static void send(int n, int n2) {
        Class<?> clazz = R.type("net.minecraft.network.protocol.common.custom.CustomPacketPayload");
        R.call(R.type("net.neoforged.neoforge.network.PacketDistributor"), "sendToServer", R.make("dev.zomboidmelee.boxing.Heavy18", n, n2), Array.newInstance(clazz, 0));
    }

    static void sound(Object object, String string, float f, float f2) {
        R.call(R.call(object, "level", new Object[0]), "playSound", null, R.call(object, "blockPosition", new Object[0]), R.get(R.type("net.minecraft.sounds.SoundEvents"), string), R.get(R.type("net.minecraft.sounds.SoundSource"), "PLAYERS"), Float.valueOf(f), Float.valueOf(f2));
    }

    static boolean clearRay(Object object, Object object2) {
        Object object3 = R.make("net.minecraft.world.level.ClipContext", R.call(object, "getEyePosition", new Object[0]), object2, R.get(R.type("net.minecraft.world.level.ClipContext$Block"), "COLLIDER"), R.get(R.type("net.minecraft.world.level.ClipContext$Fluid"), "NONE"), object);
        return R.call(R.call(R.call(object, "level", new Object[0]), "clip", object3), "getType", new Object[0]).toString().equals("MISS");
    }

    public static void request(Object object, int n, int n2) {
        if(n2==2){Slide20.request(object);return;}
        if(n2==3){Parkour20.request(object);return;}
        if (n2 == 1) {
            Stomp18.stomp(object, n);
            return;
        }
        if (n2 == 0) {
            Combat18.heavy(object, n);
        }
    }

    public static void heavy(Object object, int n) {
        Object object2;
        Object object3;
        if (!R.type("net.minecraft.server.level.ServerPlayer").isInstance(object) || !Boxing16.empty(object) || !R.yes(R.call(object, "isAlive", new Object[0])) || R.yes(R.call(object, "isSpectator", new Object[0])) || R.yes(R.call(object, "isSleeping", new Object[0])) || R.yes(R.call(object, "isUsingItem", new Object[0]))) {
            return;
        }
        long l = Combat18.time(object);
        if (l < NEXT.getOrDefault(object, Long.MIN_VALUE)) {
            return;
        }
        Object object4 = object3 = n < 0 ? null : R.call(R.call(object, "level", new Object[0]), "getEntity", n);
        if (object3 != null) {
            if (object3 == object || !R.type("net.minecraft.world.entity.LivingEntity").isInstance(object3) || !R.yes(R.call(object3, "isAlive", new Object[0])) || R.num(R.call(object, "distanceToSqr", object3)) > 16.0 || !R.yes(R.call(object, "hasLineOfSight", object3))) {
                return;
            }
            object2 = R.call(object, "getEyePosition", new Object[0]);
            Object object5 = R.call(object2, "add", R.call(R.call(object, "getLookAngle", new Object[0]), "scale", 3.0));
            Object object6 = R.call(R.call(object3, "getBoundingBox", new Object[0]), "inflate", 0.1);
            Optional optional = (Optional)R.call(object6, "clip", object2, object5);
            if (!R.yes(R.call(object6, "contains", object2)) && !optional.isPresent()) {
                return;
            }
            if (!Combat18.clearRay(object, optional.orElse(null) == null ? object2 : optional.get())) {
                return;
            }
        }
        if (!R.yes(R.call(R.type("com.armilp.ezweight.stamina.StaminaCommon"), "consume", object, 100.0))) {
            return;
        }
        NEXT.put(object, l + 18L);
        Net20.cue(object,11);
        R.call(object, "resetAttackStrengthTicker", new Object[0]);
        Combat18.sound(object, "PLAYER_ATTACK_SWEEP", 0.55f, 0.65f);
        if (object3 != null) {
            Combat18.mark(object3, l);
            Server20.prepare(object3);
            HEAVY.set(true);
            try {
                object2 = R.call(R.call(object, "damageSources", new Object[0]), "playerAttack", object);
                if (R.yes(R.call(object3, "hurt", object2, Float.valueOf(3.0f)))) {
                    Combat18.sound(object3, "PLAYER_ATTACK_STRONG", 0.8f, 0.7f);
                }
            }
            finally {
                HEAVY.remove();
            }
        }
    }
}

