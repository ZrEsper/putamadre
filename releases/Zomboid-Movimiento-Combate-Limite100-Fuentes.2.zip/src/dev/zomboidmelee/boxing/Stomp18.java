/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboidmelee.boxing;

import dev.zomboidmelee.boxing.Boxing16;
import dev.zomboidmelee.boxing.Combat18;
import dev.zomboidmelee.boxing.R;
import java.util.Optional;

public final class Stomp18 {
    static final int DOWN = 0x40000000;
    static final Class<?> GORE;

    static {
        Class<?> clazz = null;
        try {
            clazz = Class.forName("dev.zomboid.gore.Gore");
        }
        catch (ClassNotFoundException classNotFoundException) {}
        GORE = clazz;
    }

    static boolean supported(Object object) {
        return GORE != null && R.yes(R.call(GORE, "zombie", object));
    }

    static int state(Object object) {
        return ((Number)R.call(GORE, "state", object)).intValue();
    }

    public static boolean down(Object object) {
        return Stomp18.supported(object) && ((Stomp18.state(object) & 0x40000000) != 0 || R.yes(R.call(R.type("dev.zomboid.gore.Rules"), "crawling", Stomp18.state(object))));
    }

    public static boolean roll(boolean bl, float f) {
        return f < (bl ? 0.18f : 0.035f);
    }

    public static void recoil(Object object, Object object2) {
        double d;
        double d2 = R.num(R.call(object, "getX", new Object[0])) - R.num(R.call(object2, "getX", new Object[0]));
        double d3 = Math.hypot(d2, d = R.num(R.call(object, "getZ", new Object[0])) - R.num(R.call(object2, "getZ", new Object[0])));
        if (d3 < 0.001) {
            Object object3 = R.call(object2, "getLookAngle", new Object[0]);
            d2 = R.num(R.get(object3, "x"));
            d = R.num(R.get(object3, "z"));
            d3 = Math.hypot(d2, d);
        }
        if (d3 > 0.001) {
            double d4 = Combat18.HEAVY.get() != false ? 0.38 : 0.2;
            R.call(object, "push", d2 / d3 * d4, 0.0, d / d3 * d4);
            R.set(object, "hurtMarked", true);
        }
        if (R.lng(R.call(R.call(object,"getPersistentData"),"getLong","boxing19_fall_ready")) > Combat18.time(object)) return;
        if (!Stomp18.supported(object) || Stomp18.down(object) || !R.yes(R.call(object, "isAlive", new Object[0])) || !Stomp18.roll(Combat18.HEAVY.get(), ((Number)R.call(R.call(object, "getRandom", new Object[0]), "nextFloat", new Object[0])).floatValue())) {
            return;
        }
        R.call(R.call(object, "getPersistentData", new Object[0]), "putLong", "boxing18_down_until", Combat18.time(object) + 80L);
        R.call(R.call(object,"getPersistentData"),"putLong","boxing19_fall_ready",Combat18.time(object)+160L);
        R.call(GORE, "set", object, Stomp18.state(object) | 0x40000000);
        R.call(R.call(object, "getPersistentData", new Object[0]), "putLong", "zpush_until", Combat18.time(object) + 80L);
    }

    static double fallenScale(Object object) {
        return Math.max(0.1, R.num(R.call(object, "getBbWidth", new Object[0])) / 1.8);
    }

    static Object head(Object object) {
        double d = Stomp18.fallenScale(object);
        double d2 = Math.toRadians(R.num(R.get(object, "yBodyRot")));
        return R.call(R.call(object, "position", new Object[0]), "add", Math.sin(d2) * 0.95 * d, 0.35 * d, -Math.cos(d2) * 0.95 * d);
    }

    public static boolean headAim(Object object, Object object2) {
        if (!Stomp18.down(object2)) {
            return false;
        }
        Object object3 = Stomp18.head(object2);
        Object object4 = R.call(object, "getEyePosition", new Object[0]);
        Object object5 = R.call(object4, "add", R.call(R.call(object, "getLookAngle", new Object[0]), "scale", 3.0));
        Object object6 = R.make("net.minecraft.world.phys.AABB", R.num(R.get(object3, "x")) - 0.4, R.num(R.get(object3, "y")) - 0.3, R.num(R.get(object3, "z")) - 0.4, R.num(R.get(object3, "x")) + 0.4, R.num(R.get(object3, "y")) + 0.3, R.num(R.get(object3, "z")) + 0.4);
        Optional optional = (Optional)R.call(object6, "clip", object4, object5);
        return R.num(R.call(object, "distanceToSqr", object3)) <= 6.25 && optional.isPresent() && Combat18.clearRay(object, optional.get());
    }

    public static void stomp(Object object, int n) {
        if (!R.type("net.minecraft.server.level.ServerPlayer").isInstance(object) || !Boxing16.empty(object) || !R.yes(R.call(object, "isAlive", new Object[0])) || R.yes(R.call(object, "isSpectator", new Object[0])) || R.yes(R.call(object, "isSleeping", new Object[0])) || R.yes(R.call(object, "isUsingItem", new Object[0]))) {
            return;
        }
        long l = Combat18.time(object);
        if (l < Combat18.NEXT.getOrDefault(object, Long.MIN_VALUE)) {
            return;
        }
        Object object2 = R.call(R.call(object, "level", new Object[0]), "getEntity", n);
        if (!(object2 != null && R.yes(R.call(object2, "isAlive", new Object[0])) && Stomp18.headAim(object, object2) && R.yes(R.call(object, "hasLineOfSight", object2)))) {
            return;
        }
        if (!R.yes(R.call(R.type("com.armilp.ezweight.stamina.StaminaCommon"), "consume", object, 100.0))) {
            return;
        }
        Combat18.NEXT.put(object, l + 20L);
        Net20.cue(object,12);
        int n2 = Stomp18.state(object2);
        R.call(GORE, "set", object2, n2 | 1 | 0x100);
        Object object3 = R.call(R.call(object, "damageSources", new Object[0]), "playerAttack", object);
        if (!R.yes(R.call(object2, "hurt", object3, Float.valueOf(Float.MAX_VALUE)))) {
            R.call(GORE, "set", object2, n2);
            return;
        }
        Net20.cue(object,18);
        Combat18.sound(object2, "SLIME_SQUISH", 0.8f, 0.65f);
        Object object4 = Stomp18.head(object2);
        Object object5 = R.call(R.get(R.type("net.minecraft.world.level.block.Blocks"), "REDSTONE_BLOCK"), "defaultBlockState", new Object[0]);
        Object object6 = R.make("net.minecraft.core.particles.BlockParticleOption", R.get(R.type("net.minecraft.core.particles.ParticleTypes"), "BLOCK"), object5);
        R.call(R.call(object2, "level", new Object[0]), "sendParticles", object6, R.num(R.get(object4, "x")), R.num(R.get(object4, "y")), R.num(R.get(object4, "z")), 24, 0.22, 0.12, 0.22, 0.08);
    }

    public static boolean temporary(Object object) {
        return Stomp18.supported(object) && (Stomp18.state(object) & 0x40000000) != 0;
    }
}

