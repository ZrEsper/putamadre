package dev.zomboidmelee.boxing;
import java.util.*;
/** Two-block mantle. Server validates the ledge; both sides apply collision-respecting velocity. */
public final class Parkour20 {
 static final Map<Object,Long> VISUAL=Collections.synchronizedMap(new WeakHashMap<>());
 static final Map<Object,State> ACTIVE=Collections.synchronizedMap(new WeakHashMap<>());
 static final Map<Object,Long> NEXT=Collections.synchronizedMap(new WeakHashMap<>());
 static final Map<Object,double[]> GROUND=Collections.synchronizedMap(new WeakHashMap<>());
 static final class State{double x,y,z;int age;}
 public static boolean active(Object p){return ACTIVE.containsKey(p);}
 static double pos(Object p,String axis){return R.num(R.call(p,"get"+axis));}
 static boolean forbidden(Object p){return !R.yes(R.call(p,"isAlive"))||R.yes(R.call(p,"isSpectator"))||R.yes(R.call(p,"isPassenger"))||R.yes(R.call(p,"isInWater"))||R.yes(R.call(p,"isSleeping"))||R.yes(R.call(p,"isUsingItem"))||R.yes(R.get(R.call(p,"getAbilities"),"flying"))||R.call(p,"getForcedPose")!=null;}
 static Object box(double x,double y,double z,double width){return R.make("net.minecraft.world.phys.AABB",x-width,y,z-width,x+width,y+1.81,z+width);}
 static boolean clear(Object level,Object p,Object box){return R.yes(R.call(level,"noCollision",p,box));}
 public static boolean heightAllowed(double rise){return rise>.65&&rise<=2.001;}
 static State find(Object p){
  if(forbidden(p)||Slide20.STATES.containsKey(p))return null;
  Object level=R.call(p,"level"),look=R.call(p,"getLookAngle");double dx=R.num(R.get(look,"x")),dz=R.num(R.get(look,"z")),len=Math.hypot(dx,dz);if(len<.1)return null;dx/=len;dz/=len;
  double x=pos(p,"X"),y=pos(p,"Y"),z=pos(p,"Z");double[] ground=GROUND.get(p);if(ground==null||Combat18.time(p)-(long)ground[1]>20)return null;
  // Search only directly reachable front ledges, never through a wall or ceiling.
  for(double reach=.45;reach<=1.05;reach+=.20){int bx=(int)Math.floor(x+dx*reach),bz=(int)Math.floor(z+dz*reach);
   for(int by=(int)Math.floor(ground[0])+1;by>=(int)Math.floor(ground[0]);by--){
    Object bp=R.make("net.minecraft.core.BlockPos",bx,by,bz);if(!R.yes(R.call(level,"hasChunkAt",bp)))continue;
    Object block=R.call(level,"getBlockState",bp),shape=R.call(block,"getCollisionShape",level,bp);if(R.yes(R.call(shape,"isEmpty")))continue;
    Object bounds=R.call(shape,"bounds");double top=by+R.num(R.get(bounds,"maxY"));if(!heightAllowed(top-ground[0])||top<y-.15)continue;
    // Require a broad top surface; fences, walls and thin rods are not landing platforms.
    if(R.num(R.get(bounds,"maxX"))-R.num(R.get(bounds,"minX"))<.60||R.num(R.get(bounds,"maxZ"))-R.num(R.get(bounds,"minZ"))<.60)continue;
    double tx=bx+.5,tz=bz+.5,ty=top+.04;
    if(Math.hypot(tx-x,tz-z)>1.35||!clear(level,p,box(tx,ty,tz,.30)))continue;
    Object rise=R.make("net.minecraft.world.phys.AABB",x-.30,y,z-.30,x+.30,ty+1.81,z+.30);
    Object over=R.make("net.minecraft.world.phys.AABB",Math.min(x,tx)-.30,ty,Math.min(z,tz)-.30,Math.max(x,tx)+.30,ty+1.81,Math.max(z,tz)+.30);
    if(!clear(level,p,rise)||!clear(level,p,over))continue;
    State s=new State();s.x=tx;s.y=ty;s.z=tz;return s;
   }
  }return null;
 }
 public static void request(Object p){long t=Combat18.time(p);if(active(p)||t<NEXT.getOrDefault(p,Long.MIN_VALUE)||R.yes(R.call(p,"onGround")))return;State s=find(p);if(s==null)return;
  ACTIVE.put(p,s);NEXT.put(p,t+30);Net20.cue(p,200);
 }
 public static void accept(Object p,boolean start){if(!start){ACTIVE.remove(p);VISUAL.remove(p);return;}VISUAL.put(p,System.nanoTime());if(p!=R.get(BoxingClient16.mc(),"player"))return;State s=find(p);if(s!=null)ACTIVE.put(p,s);}
 public static void tick(Object p,boolean server){long t=Combat18.time(p);if(R.yes(R.call(p,"onGround"))&&!active(p))GROUND.put(p,new double[]{pos(p,"Y"),t});State s=ACTIVE.get(p);if(s==null)return;
  double x=pos(p,"X"),y=pos(p,"Y"),z=pos(p,"Z");
  if(++s.age>28||forbidden(p)||!clear(R.call(p,"level"),p,box(s.x,s.y,s.z,.30))||Math.hypot(s.x-x,s.z-z)>1.6||y>s.y+.5){stop(p,server);return;}
  double dy=s.y-y,dx=s.x-x,dz=s.z-z,dist=Math.hypot(dx,dz);
  if(dy<.08&&dist<.12){stop(p,server);return;}
  // Lift beside the wall first, then pull over the lip. Normal collision physics stays enabled.
  double vy=dy>.06?Math.min(.24,dy+.025):.025,vx=0,vz=0;
  if(dy<.08&&dist>.01){double step=Math.min(.16,dist);vx=dx/dist*step;vz=dz/dist*step;}
  R.call(p,"setDeltaMovement",vx,vy,vz);
  if(server&&s.age%4==1)R.set(p,"hurtMarked",true);
 }
 static void stop(Object p,boolean server){ACTIVE.remove(p);if(server)Net20.cue(p,201);}
 public static boolean body(Object model,Object p){State s=ACTIVE.get(p);Long visual=VISUAL.get(p);double age=s==null?(visual==null?100:(System.nanoTime()-visual)/50000000d):s.age;if(age>28)return false;double w=Motion16.smooth(Math.min(age/3d,(28-age)/4d));Bodycam20.part(model,"body","xRot",.18,w);Bodycam20.part(model,"rightArm","xRot",-2.3,w);Bodycam20.part(model,"leftArm","xRot",-2.3,w);Bodycam20.part(model,"rightLeg","xRot",-.6,w);Bodycam20.part(model,"leftLeg","xRot",-.3,w);return true;}
}
