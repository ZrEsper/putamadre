package dev.zomboidmelee.boxing;
public final class Motion20{
 static final double[] L={0,.10,.24,.34,.65,1},LV={0,-.06,1,.8,.1,0};
 static final double[] H={0,.28,.43,.55,.75,1},HV={0,-.35,1,.90,.18,0};
 static final double[] K={0,.32,.44,.58,.76,1},KV={0,1,1,.1,0,0};
 static final double[] D={0,.40,.55,.64,.80,1},DV={0,0,1,.9,.15,0};
 static final double[] S={0,.18,.35,.48,.70,1},SV={0,-.15,1,.85,.15,0};
 public static double strike(double p,boolean heavy){return Motion16.curve(p,heavy?H:L,heavy?HV:LV);}
 public static double lift(double p){return Motion16.curve(p,K,KV);}
 public static double drop(double p){return Motion16.curve(p,D,DV);}
 public static double shove(double p){return Motion16.curve(p,S,SV);}
}
