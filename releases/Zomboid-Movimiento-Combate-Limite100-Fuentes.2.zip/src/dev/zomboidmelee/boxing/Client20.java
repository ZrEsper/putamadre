package dev.zomboidmelee.boxing;
import java.util.*;
public final class Client20 {
 static final Map<Object,Cue> CUES=new WeakHashMap<>();static Object level;static long impact;static int strength;
 static class Cue{long start;int action,combo;boolean searching;long searchChange;double from;}
 static long now(){return BoxingClient16.CLOCK.getAsLong();}
 static Object mc(){return BoxingClient16.mc();}
 static Cue cue(Object p){return CUES.computeIfAbsent(p,k->new Cue());}
 static double searchWeight(Cue c,long t){double k=Motion16.smooth((t-c.searchChange)/250000000d);return c.from+((c.searching?1:0)-c.from)*k;}
 static void searching(Cue c,boolean yes,long t){if(c.searching!=yes){c.from=searchWeight(c,t);c.searchChange=t;c.searching=yes;}}
 public static void poll(){Bodycam20.tick();Object m=mc(),world=R.get(m,"level");if(level!=world){CUES.clear();impact=0;level=world;}Object p=R.get(m,"player");if(p!=null)searching(cue(p),Server20.searchMenu(p),now());}
 public static void receive(int id,int action){Object m=mc(),world=R.get(m,"level");if(world==null)return;Object p=R.call(world,"getEntity",id);if(p==null)return;if(action==200||action==201){Parkour20.accept(p,action==200);return;}if(action==99||action>=108&&action<=122){Bodycam20.accept(p,action==99?0:action-100);return;}boolean local=p==R.get(m,"player");Cue c=cue(p);long t=now();
  if(action==14||action==15){searching(c,action==14,t);return;}
  if(action==19){if(local){BoxingClient16.started=0;R.call(p,"displayClientMessage",R.call(R.type("net.minecraft.network.chat.Component"),"literal","Sin energía para golpear"),true);}return;}
  if(action>=16&&action<=18){if(local){strength=action-16;impact=t+(strength==0?70000000L:strength==1?140000000L:180000000L);}return;}
  if(action<10||action>13)return;
  c.action=action;c.start=t;c.combo++;
  // Local input is predicted; don't restart an animation when its server cue arrives.
  if(local&&action==13) c.start=t;
 }
 public static void shove(Object player){Cue c=cue(player);c.start=now();c.action=13;c.combo++;}
 static double length(int action){return action==11?.62:action==12?.75:action==13?.55:.40;}
 static double phase(Cue c,long t){return c.start==0?1:(t-c.start)/(length(c.action)*1e9);}
 static void blend(Object model,String name,String axis,double target,double weight){Object p=R.get(model,name);double base=R.num(R.get(p,axis));R.set(p,axis,(float)(base+(target-base)*weight));}
 static void overlays(Object model){for(String[] p:new String[][]{{"rightSleeve","rightArm"},{"leftSleeve","leftArm"},{"rightPants","rightLeg"},{"leftPants","leftLeg"},{"jacket","body"},{"hat","head"}})try{R.call(R.get(model,p[0]),"copyFrom",R.get(model,p[1]));}catch(IllegalStateException ignored){}}
 public static void body(Object model,Object p){
  if(BoxingClient16.renderingHands)return;
  if(!R.type("net.minecraft.world.entity.player.Player").isInstance(p)){Action19.zombiePose(model,p);BoxingClient16.flinch(model,p);return;}
  if(Parkour20.body(model,p)||Bodycam20.body(model,p)){overlays(model);return;}
  Object local=R.get(mc(),"player");Cue c=cue(p);long t=now();double sw=searchWeight(c,t);
  if(sw>0){double wave=Math.sin((t-c.searchChange)/1e9*5.5);blend(model,"body","xRot",.16,sw);blend(model,"head","xRot",.36,sw);
   blend(model,"rightArm","xRot",-1.04-.18*wave,sw);blend(model,"leftArm","xRot",-1.04+.18*wave,sw);
   blend(model,"rightArm","yRot",-.20,sw);blend(model,"leftArm","yRot",.20,sw);blend(model,"rightArm","zRot",.09,sw);blend(model,"leftArm","zRot",-.09,sw);overlays(model);return;}
  int action=c.action,combo=c.combo;double phase=phase(c,t);
  if(p==local&&BoxingClient16.started!=0&&Boxing16.empty(p)){
   action=BoxingClient16.stomping?12:BoxingClient16.heavy?11:10;combo=BoxingClient16.combo;phase=(t-BoxingClient16.started)/(length(action)*1e9);
  }
  if(phase<0||phase>=1)return;
  double w=Motion16.smooth(Math.min(phase/.1,(1-phase)/.24)),hit=Motion20.strike(phase,action==11);
  int side=combo%2==0?1:-1;String active=side==1?"rightArm":"leftArm",guard=side==1?"leftArm":"rightArm";
  if(action==12){double lift=Motion20.lift(phase),drop=Motion20.drop(phase);blend(model,"rightLeg","xRot",-.95*lift+.25*drop,w);blend(model,"leftLeg","xRot",.10*lift,w);blend(model,"body","xRot",.15*drop-.08*lift,w);blend(model,"rightArm","xRot",-.5,w);blend(model,"leftArm","xRot",-.55,w);}
  else if(action==13){double push=Motion20.shove(phase);blend(model,"rightArm","xRot",-1.0-.5*push,w);blend(model,"rightArm","yRot",-.12,w);blend(model,"leftArm","xRot",-.85-.35*push,w);blend(model,"leftArm","yRot",.12,w);blend(model,"body","xRot",.08*push,w);}
  else if(Boxing16.empty(p)){
   blend(model,active,"xRot",-1.10-.48*hit,w);blend(model,active,"yRot",side*(action==11?(.60-1.05*hit):(-.12+.12*hit)),w);blend(model,active,"zRot",side*(action==11?.22:.08),w);
   blend(model,guard,"xRot",-1.02,w);blend(model,guard,"yRot",side*.22,w);blend(model,guard,"zRot",-side*.13,w);blend(model,"body","yRot",side*(action==11?.28:.09)*hit,w);
  }overlays(model);
 }
 public static void camera(Object event){Bodycam20.camera(event);Object m=mc();if(R.get(m,"player")==null||R.get(m,"screen")!=null||!Action19.firstPerson(m))return;
  double t=(now()-impact)/1e9;if(impact==0||t<0||t>.44)return;
  double v=Math.sin(t*30)*Math.exp(-t*10)*Motion16.smooth(t/.025)*Motion16.smooth((.44-t)/.12);
  double amplitude=strength==0?1.25:strength==1?3.0:3.4;
  R.call(event,"setPitch",(float)(R.num(R.call(event,"getPitch"))+v*amplitude));
  R.call(event,"setRoll",(float)(R.num(R.call(event,"getRoll"))+v*amplitude*.24*(BoxingClient16.combo%2==0?1:-1)));
 }
 public static boolean searchHand(Object event){Object m=mc(),p=R.get(m,"player");if(p==null)return false;Cue c=cue(p);double weight=searchWeight(c,now());if(weight<=.001)return false;
  if(!R.call(event,"getHand").toString().equals("MAIN_HAND")){R.call(event,"setCanceled",true);return true;}
  Object renderer=R.call(R.call(m,"getEntityRenderDispatcher"),"getRenderer",p);Object poses=R.call(event,"getPoseStack"),buffers=R.call(event,"getMultiBufferSource");int light=((Number)R.call(event,"getPackedLight")).intValue();
  boolean previous=BoxingClient16.renderingHands;BoxingClient16.renderingHands=true;
  try{for(int hand=0;hand<2;hand++)BoxingArms17.draw(renderer,poses,buffers,light,p,hand,weight*(.12+.09*Math.sin((now()-c.searchChange)/1e9*5.5+hand*Math.PI)));BoxingArms17.flush(buffers);}finally{BoxingClient16.renderingHands=previous;}
  R.call(event,"setCanceled",true);return true;
 }
}
