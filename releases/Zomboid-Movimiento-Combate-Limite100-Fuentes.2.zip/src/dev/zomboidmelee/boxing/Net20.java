package dev.zomboidmelee.boxing;
import java.lang.reflect.*;
/** Common-side registration; the client receiver is resolved only on the client. */
public final class Net20 {
 public static void register(Object event){
  Object registrar=R.call(event,"registrar","boxing20");Class<?> handler=R.type("net.neoforged.neoforge.network.handling.IPayloadHandler");
  Object proxy=Proxy.newProxyInstance(handler.getClassLoader(),new Class[]{handler},(p,m,a)->{
   if(m.getName().equals("handle")){Object packet=a[0],ctx=a[1];R.call(ctx,"enqueueWork",(Runnable)()->{
    Object player=R.call(ctx,"player");int id=((Number)R.call(packet,"entityId")).intValue(),action=((Number)R.call(packet,"action")).intValue();
    if(R.type("net.minecraft.server.level.ServerPlayer").isInstance(player))Combat18.request(player,id,action);
    else R.call(R.type("dev.zomboidmelee.boxing.Client20"),"receive",id,action);
   });return null;}
   if(m.getName().equals("toString"))return "Boxing20Handler";if(m.getName().equals("hashCode"))return System.identityHashCode(p);if(m.getName().equals("equals"))return p==a[0];return null;
  });Class<?> packet=R.type("dev.zomboidmelee.boxing.Heavy18");
  R.call(registrar,"playBidirectional",R.get(packet,"TYPE"),R.get(packet,"CODEC"),proxy);
 }
 public static void cue(Object player,int action){
  Object packet=R.make("dev.zomboidmelee.boxing.Heavy18",((Number)R.call(player,"getId")).intValue(),action);
  R.call(R.type("net.neoforged.neoforge.network.PacketDistributor"),"sendToPlayersTrackingEntityAndSelf",player,packet,Array.newInstance(R.type("net.minecraft.network.protocol.common.custom.CustomPacketPayload"),0));
 }
}
