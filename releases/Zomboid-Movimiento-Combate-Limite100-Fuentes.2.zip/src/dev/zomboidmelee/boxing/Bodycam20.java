package dev.zomboidmelee.boxing;
import java.util.*;
public final class Bodycam20 {
 static final Map<Object,long[]> SLIDES=new WeakHashMap<>();static Object owner;static boolean crouch,jump;static long sprint,clock,jumpAt,slideRequested;static double distance,lastX,lastZ,motion;
 public static void tick(){Object m=BoxingClient16.mc(),p=R.get(m,"player");if(p!=owner){owner=p;SLIDES.clear();crouch=false;jump=false;jumpAt=0;sprint=0;clock=0;motion=0;distance=0;if(p!=null){lastX=R.num(R.call(p,"getX"));lastZ=R.num(R.call(p,"getZ"));}}if(p==null)return;
  double x=R.num(R.call(p,"getX")),z=R.num(R.call(p,"getZ"));motion=Math.min(.8,Math.hypot(x-lastX,z-lastZ));lastX=x;lastZ=z;distance+=motion;long t=System.nanoTime();
  if(R.yes(R.call(p,"isSprinting")))sprint=t;
  Object opt=R.get(m,"options");boolean down=R.yes(R.call(R.get(opt,"keyShift"),"isDown"));
  // C is supported explicitly as requested, as well as the configured crouch key.
  long window=((Number)R.call(R.call(m,"getWindow"),"getWindow")).longValue();down|=R.yes(R.call(R.type("com.mojang.blaze3d.platform.InputConstants"),"isKeyDown",window,67));
  if(R.get(m,"screen")==null&&down&&!crouch&&t-sprint<300000000L&&motion>.12&&t-slideRequested>300000000L){Combat18.send(-1,2);slideRequested=t;}
  boolean jumping=R.yes(R.call(R.get(opt,"keyJump"),"isDown"));
  if(R.get(m,"screen")==null&&jumping&&!jump){if(jumpAt!=0&&t-jumpAt<650000000L&&!R.yes(R.call(p,"onGround"))){Combat18.send(-1,3);jumpAt=0;}else jumpAt=t;}
  jump=jumping;crouch=down;Parkour20.tick(p,false);Slide20.clientTick(p);

 }
 public static boolean proneKey(int key,int scan,int action){if(action!=1)return false;Object m=BoxingClient16.mc(),p=R.get(m,"player");if(p==null||R.get(m,"screen")!=null||!R.yes(R.call(p,"onGround"))||R.call(p,"getForcedPose")!=null)return false;
  if(!R.yes(R.call(R.get(R.type("com.locknar.taczammocheck.prone.ProneClient"),"KEY"),"matches",key,scan)))return false;
  long t=System.nanoTime();if(!R.yes(R.call(p,"isSprinting"))&&t-sprint>300000000L)return false;
  Combat18.send(-1,2);slideRequested=t;return true;
 }
 public static void accept(Object p,int ticks){if(p==R.get(BoxingClient16.mc(),"player"))Slide20.clientStart(p,ticks);if(ticks<=0)SLIDES.remove(p);else SLIDES.put(p,new long[]{System.nanoTime(),ticks});}
 static double slide(Object p){long[] s=SLIDES.get(p);if(s==null)return 0;double phase=(System.nanoTime()-s[0])/(s[1]*50000000d);if(phase>=1){SLIDES.remove(p);return 0;}return Motion16.smooth(Math.min(phase/.12,(1-phase)/.20));}
 public static boolean body(Object model,Object p){double w=slide(p);if(w==0)return false;
  part(model,"body","xRot",-.22,w);part(model,"rightLeg","xRot",-1.10,w);part(model,"leftLeg","xRot",-.65,w);part(model,"rightArm","xRot",-.8,w);part(model,"leftArm","xRot",-.8,w);return true;}
 static void part(Object m,String n,String a,double v,double w){Object p=R.get(m,n);double from=R.num(R.get(p,a));R.set(p,a,(float)(from+(v-from)*w));}
 public static void camera(Object event){Object m=BoxingClient16.mc(),p=R.get(m,"player");if(p==null||R.get(m,"screen")!=null||!Action19.firstPerson(m))return;
  double t=System.nanoTime()/1e9,amplitude=R.yes(R.call(p,"isSprinting"))?.42:.22;
  boolean aiming=R.yes(R.call(R.get(R.get(m,"options"),"keyUse"),"isDown"));if(aiming)amplitude*=.22;
  double walk=distance*8,weight=Math.min(1,motion/.15),s=slide(p);
  double pitch=Math.sin(t*1.8)*.025+(Math.sin(walk*2)*.65+Math.sin(walk*1.1)*.15)*amplitude*weight+s*.45;
  double roll=Math.sin(t*1.1)*.025+Math.sin(walk)*amplitude*.70*weight+s*1.2;
  R.call(event,"setPitch",(float)(R.num(R.call(event,"getPitch"))+pitch));R.call(event,"setRoll",(float)(R.num(R.call(event,"getRoll"))+roll));
 }
}
