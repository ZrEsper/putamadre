package dev.zomboidmelee.boxing;
import java.util.*;
public final class Slide20 {
 static final Map<Object,State> STATES=Collections.synchronizedMap(new WeakHashMap<>());static final Map<Object,Long> SPRINT=Collections.synchronizedMap(new WeakHashMap<>()),NEXT=Collections.synchronizedMap(new WeakHashMap<>());
 static final Map<Object,double[]> MOTION=Collections.synchronizedMap(new WeakHashMap<>());
 static final Map<Object,State> CLIENT=Collections.synchronizedMap(new WeakHashMap<>());
 static final class State{double x,z,speed;int left;Object oldPose;}
 public static double speed(double initial,int ticks){return initial*Math.pow(.92,ticks);}
 public static int duration(double v){return Math.max(8,Math.min(22,(int)Math.round(10+v*20)));}
 static double horizontal(Object p){Object v=R.call(p,"getDeltaMovement");return Math.hypot(R.num(R.get(v,"x")),R.num(R.get(v,"z")));}
 static void measure(Object p){double x=R.num(R.call(p,"getX")),z=R.num(R.call(p,"getZ"));double[] old=MOTION.get(p);MOTION.put(p,new double[]{x,z,old==null?0:x-old[0],old==null?0:z-old[1]});}
 static void advance(Object p,State s){s.speed*=.92;Object v=R.call(p,"getDeltaMovement");R.call(p,"setDeltaMovement",s.x*s.speed,R.num(R.get(v,"y")),s.z*s.speed);}
 public static void clientTick(Object p){measure(p);State s=CLIENT.get(p);if(s==null)return;if(s.left--<=0||R.yes(R.get(p,"horizontalCollision"))||!R.yes(R.call(p,"onGround"))){clientStop(p);return;}advance(p,s);}
 static void clientStop(Object p){State s=CLIENT.remove(p);if(s!=null&&R.call(p,"getForcedPose")==R.get(R.type("net.minecraft.world.entity.Pose"),"CROUCHING"))R.call(p,"setForcedPose",s.oldPose);}
 public static void clientStart(Object p,int ticks){if(ticks==0){clientStop(p);return;}double[] d=MOTION.get(p);if(d==null)return;double v=Math.hypot(d[2],d[3]);if(v<.01)return;State s=new State();s.x=d[2]/v;s.z=d[3]/v;s.speed=Math.min(.75,v*1.18);s.left=ticks;s.oldPose=R.call(p,"getForcedPose");if(s.oldPose!=null)return;CLIENT.put(p,s);R.call(p,"setForcedPose",R.get(R.type("net.minecraft.world.entity.Pose"),"CROUCHING"));}
 public static void tick(Object p){measure(p);long time=Combat18.time(p);if(R.yes(R.call(p,"isSprinting")))SPRINT.put(p,time);State s=STATES.get(p);if(s==null)return;
  if(s.left--<=0||!R.yes(R.call(p,"isAlive"))||R.yes(R.call(p,"isPassenger"))||R.yes(R.call(p,"isInWater"))||!R.yes(R.call(p,"onGround"))||R.yes(R.get(p,"horizontalCollision"))){stop(p);return;}
  advance(p,s);if(s.left%4==0)R.set(p,"hurtMarked",true);
  if(s.left%3==0&&R.yes(R.call(p,"onGround")))dust(p);
 }
 public static void request(Object p){long time=Combat18.time(p);if(Parkour20.active(p)||STATES.containsKey(p)||time<NEXT.getOrDefault(p,Long.MIN_VALUE)||!R.yes(R.call(p,"isAlive"))||R.yes(R.call(p,"isSpectator"))||R.yes(R.call(p,"isPassenger"))||!R.yes(R.call(p,"onGround"))||R.yes(R.call(p,"isInWater"))||R.yes(R.call(p,"isUsingItem")))return;
  if(!R.yes(R.call(p,"isSprinting"))&&time-SPRINT.getOrDefault(p,time-100)>6)return;
  if(R.yes(R.get(R.call(p,"getAbilities"),"flying")))return;
  double[] movement=MOTION.get(p);if(movement==null)return;double v=Math.hypot(movement[2],movement[3]);if(v<.12||v>.85)return;Object old=R.call(p,"getForcedPose");if(old!=null)return;
  State s=new State();s.x=movement[2]/v;s.z=movement[3]/v;s.speed=Math.min(.75,v*1.18);s.left=duration(s.speed);s.oldPose=old;
  R.call(p,"setForcedPose",R.get(R.type("net.minecraft.world.entity.Pose"),"CROUCHING"));STATES.put(p,s);NEXT.put(p,time+35);Net20.cue(p,100+s.left);
 }
 static void stop(Object p){State s=STATES.remove(p);if(s==null)return;Object crouch=R.get(R.type("net.minecraft.world.entity.Pose"),"CROUCHING");if(R.call(p,"getForcedPose")==crouch)R.call(p,"setForcedPose",s.oldPose);Net20.cue(p,99);}
 static void dust(Object p){Object level=R.call(p,"level"),pos=R.call(R.call(p,"blockPosition"),"below"),block=R.call(level,"getBlockState",pos);if(R.yes(R.call(block,"isAir")))return;Object particle=R.make("net.minecraft.core.particles.BlockParticleOption",R.get(R.type("net.minecraft.core.particles.ParticleTypes"),"BLOCK"),block);R.call(level,"sendParticles",particle,R.num(R.call(p,"getX")),R.num(R.call(p,"getY"))+.08,R.num(R.call(p,"getZ")),3,.20,.03,.20,.025);}
}
