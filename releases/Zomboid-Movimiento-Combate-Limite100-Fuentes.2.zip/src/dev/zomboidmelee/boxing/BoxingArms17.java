package dev.zomboidmelee.boxing;
public final class BoxingArms17 {
 public static void pose(Object model,int hand,float x,float y,float z){Object arm=R.get(model,hand==0?"rightArm":"leftArm");if(arm==null)return;R.set(arm,"xRot",x);R.set(arm,"yRot",y);R.set(arm,"zRot",z);try{Object sleeve=R.get(model,hand==0?"rightSleeve":"leftSleeve");if(sleeve!=null)R.call(sleeve,"copyFrom",arm);}catch(IllegalStateException ignored){}}
 public static void draw(Object renderer,Object poses,Object buffers,int light,Object player,int hand,double hit){
  int side=hand==0?1:-1;R.call(poses,"pushPose");
  try{
   // Keep the guard below the sightline, with forward travel and wrist rotation on contact.
   R.call(poses,"translate",side*(.34-.10*hit),-.80+.17*hit,-.42-.36*hit);
   BoxingClient16.rotate(poses,"YP",side*(BoxingClient16.heavy?(35-60*hit):(16-16*hit)));
   BoxingClient16.rotate(poses,"XP",-62-14*hit);
   BoxingClient16.rotate(poses,"ZP",side*(BoxingClient16.heavy?(12+24*hit):(4+6*hit)));
   R.call(poses,"translate",side*.3125,-.125,0d);
   R.call(renderer,hand==0?"renderRightHand":"renderLeftHand",poses,buffers,light,player);
  }finally{R.call(poses,"popPose");}
 }
 public static void flinch(Object model,float w){for(String name:new String[]{"body","head","rightArm","leftArm"}){Object p=R.get(model,name);if(p!=null)R.set(p,"xRot",(float)R.num(R.get(p,"xRot"))+(name.equals("head")?-.22f:.12f)*w);}}
 public static void leg(Object renderer,Object poses,Object buffers,int light,Object player,double phase){
  Object model=R.call(renderer,"getModel"),leg=R.get(model,"rightLeg");if(leg==null)return;
  float x=(float)R.num(R.get(leg,"xRot")),y=(float)R.num(R.get(leg,"yRot")),z=(float)R.num(R.get(leg,"zRot"));
  double lift=Motion20.lift(phase),drop=Motion20.drop(phase),fade=Motion16.smooth(Math.min(phase/.16,(1-phase)/.20));
  R.call(poses,"pushPose");
  try{
   R.call(poses,"translate",.23,-1.45+.78*lift-.22*drop,-.64);
   BoxingClient16.rotate(poses,"XP",-18+12*drop);
   BoxingClient16.rotate(poses,"ZP",-3*fade);
   R.call(poses,"translate",-.12,-.75,0d);
   R.set(leg,"xRot",0f);R.set(leg,"yRot",0f);R.set(leg,"zRot",0f);
   Object tex=R.call(R.call(player,"getSkin"),"texture");
   Object buffer=R.call(buffers,"getBuffer",R.call(R.type("net.minecraft.client.renderer.RenderType"),"entitySolid",tex));
   R.call(leg,"render",poses,buffer,light,655360);
  }finally{R.set(leg,"xRot",x);R.set(leg,"yRot",y);R.set(leg,"zRot",z);R.call(poses,"popPose");}
 }
 public static void flush(Object buffers){if(R.type("net.minecraft.client.renderer.MultiBufferSource$BufferSource").isInstance(buffers))R.call(buffers,"endBatch");}
}
