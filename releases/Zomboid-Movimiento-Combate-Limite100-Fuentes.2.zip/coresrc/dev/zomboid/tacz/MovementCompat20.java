package dev.zomboid.tacz;
/** Optional bridge: core TaCZ still runs when the movement module is absent. */
public final class MovementCompat20 {
 private static java.lang.reflect.Method handler;private static boolean resolved;
 public static boolean proneKey(int key,int scan,int action){
  if(!resolved){resolved=true;try{handler=Class.forName("dev.zomboidmelee.boxing.Bodycam20").getMethod("proneKey",int.class,int.class,int.class);}catch(ReflectiveOperationException ignored){}}
  if(handler==null)return false;
  try{return Boolean.TRUE.equals(handler.invoke(null,key,scan,action));}catch(ReflectiveOperationException failure){System.getLogger("ZomboidMovement").log(System.Logger.Level.WARNING,"Unable to activate slide",failure);return false;}
 }
}
