from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree'])+':/workspace/medical65/asm-commons.jar';ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];jar=r/'release/tacznpcs-2.1.0-1.21.1-tactical.35-clickable-chat.jar';gson='/workspace/medical63/gson.jar';tests=r/'tests'
subprocess.run(ecj+['-d',str(tests)]+list(map(str,(r/'brigadier-source/src/main/java').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',str(jar)+':'+gson+':'+str(tests),'-d',str(tests)]+list(map(str,(r/'testsrc').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),'/workspace/npc70/Extract70.java',str(r/'Extract71.java')],check=True)
for cls in ['Extract70','Extract71']:subprocess.run(['java','-cp',str(r/'tools')+':'+asm,cls,str(jar),str(tests)],check=True)
run=r/'test-run';run.mkdir(exist_ok=True)
for cls in ['Fixtures70','Fixtures71']:subprocess.run(['java','-Xverify:all','-cp',str(tests)+':'+str(jar)+':'+gson,'mod.cdv.tnpc.tactical.'+cls],check=True,cwd=run)
