import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
public class Patch71 implements Opcodes{
 static String ROOT="mod/cdv/tnpc/tactical/",A=ROOT+"Chat71";static Map<String,Integer>hooks=new TreeMap<>();
 static void hook(String s){hooks.merge(s,1,Integer::sum);}static InsnList load(int...a){InsnList x=new InsnList();for(int i=0;i<a.length;i+=2)x.add(new VarInsnNode(a[i],a[i+1]));return x;}
 static void handle(MethodNode m,InsnList x,String owner,String name,String desc){x.add(new MethodInsnNode(INVOKESTATIC,owner,name,desc,false));LabelNode no=new LabelNode();x.add(new JumpInsnNode(IFEQ,no));x.add(new InsnNode(RETURN));x.add(no);x.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(x);hook(name);}
 public static void main(String[]a)throws Exception{Map<String,byte[]>d=new TreeMap<>();try(var z=new ZipFile(a[0])){for(var e:Collections.list(z.entries()))d.put(e.getName(),z.getInputStream(e).readAllBytes());}
 for(String name:List.of("Conversation","Conversation$Session","Authority70","TalkNetwork")){
  String path=ROOT+name+".class";ClassNode node=new ClassNode();new ClassReader(d.get(path)).accept(node,0);
  if(name.equals("Conversation$Session")){node.fields.add(new FieldNode(0,"chat71","Ljava/lang/Object;",null,null));hook("session-field");}
  for(var m:node.methods){
   if(name.equals("Conversation")&&m.name.equals("send"))handle(m,load(ALOAD,0,ALOAD,1,ALOAD,2),A,"open","(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)Z");
   if(name.equals("Conversation")&&m.name.equals("register"))for(var i:m.instructions.toArray())if(i.getOpcode()==RETURN){InsnList x=load(ALOAD,0);x.add(new MethodInsnNode(INVOKESTATIC,A,"register","(Ljava/lang/Object;)V",false));m.instructions.insertBefore(i,x);hook("commands");}
   if(name.equals("Conversation")&&m.name.equals("action")){InsnList x=load(ALOAD,0,ALOAD,1);x.add(new MethodInsnNode(INVOKESTATIC,A,"legacy","(Ljava/lang/Object;Ljava/lang/String;)I",false));x.add(new InsnNode(DUP));x.add(new InsnNode(ICONST_M1));LabelNode no=new LabelNode();x.add(new JumpInsnNode(IF_ICMPEQ,no));x.add(new InsnNode(IRETURN));x.add(no);x.add(new FrameNode(F_SAME1,0,null,1,new Object[]{INTEGER}));x.add(new InsnNode(POP));m.instructions.insert(x);hook("legacy");}
   if((name.equals("Authority70")||name.equals("Conversation"))&&m.name.equals("end")){InsnList x=load(ALOAD,0);x.add(new MethodInsnNode(INVOKESTATIC,A,"ended","(Ljava/lang/Object;)V",false));m.instructions.insert(x);hook("end-invalidate");}
   if(name.equals("Authority70")){Map<String,String>texts=Map.of("[???] Guarda el arma y aléjate del peligro antes de intentar negociar.","unarmed","[???] La conversación ha terminado.","ended","[???] ¡Se acabó! Nos están atacando.","attacked","[???] ¡Has disparado! Se acabó la negociación.","shot");for(var i:m.instructions.toArray())if(i instanceof LdcInsnNode l&&l.cst instanceof String s&&texts.containsKey(s)){l.cst=texts.get(s);m.instructions.insert(i,new MethodInsnNode(INVOKESTATIC,A,"ui","(Ljava/lang/String;)Ljava/lang/String;",false));hook("json-text");}}
   // Intercept C71 on client before the existing M20/legacy GUI dispatcher; medical unchanged.
   if(name.equals("TalkNetwork")&&m.name.startsWith("lambda$")&&m.desc.equals("(Lmod/cdv/tnpc/tactical/TalkPayload;)V")){InsnList x=load(ALOAD,0);x.add(new MethodInsnNode(INVOKEVIRTUAL,ROOT+"TalkPayload","text","()Ljava/lang/String;",false));handle(m,x,ROOT+"ClientChat71","receive","(Ljava/lang/String;)Z");}
  }
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);node.accept(w);d.put(path,w.toByteArray());
 }
 if(!hooks.equals(new TreeMap<>(Map.of("session-field",1,"open",1,"commands",1,"legacy",1,"end-invalidate",2,"json-text",4,"receive",1))))throw new Error("Unexpected hooks "+hooks);
 try(var walk=Files.walk(Path.of(a[1]))){for(var p:walk.filter(p->p.toString().endsWith(".class")).toList())d.put(Path.of(a[1]).relativize(p).toString(),Files.readAllBytes(p));}
 d.put("data/tacznpcs/dialogue/dialogue-phase2.json",Files.readAllBytes(Path.of(a[2])));
 String meta="META-INF/neoforge.mods.toml";d.put(meta,new String(d.get(meta),java.nio.charset.StandardCharsets.UTF_8).replaceAll("(?m)^version\\s*=\\s*\"[^\"]+\"","version=\"2.1.0-tactical.35-clickable-chat\"").getBytes(java.nio.charset.StandardCharsets.UTF_8));int count=0;
 for(var e:d.entrySet())if(e.getKey().endsWith(".class")){ClassNode n=new ClassNode();new ClassReader(e.getValue()).accept(n,0);for(var m:n.methods)if((m.access&(ACC_NATIVE|ACC_ABSTRACT))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(n.name,m);count++;}
 try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(a[3])))){for(var e:d.entrySet()){ZipEntry entry=new ZipEntry(e.getKey());entry.setTime(0);z.putNextEntry(entry);z.write(e.getValue());z.closeEntry();}}
 System.out.println("VERIFIED_CLASSES="+count+" HOOKS="+hooks);
 }
}
