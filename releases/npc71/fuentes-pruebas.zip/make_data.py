import json,pathlib
r=pathlib.Path(__file__).parent
ui={'tones':{'1':'Amistosa','2':'Neutral','3':'Firme','4':'Amenaza','5':'Agresiva','engaño':'Engaño'},'unknown':'???','expired':'Estas opciones ya no están disponibles.','none':'No tienes una conversación activa.','ended':'La conversación ha terminado.','unarmed':'Guarda el arma y aléjate del peligro antes de intentar negociar.','attacked':'¡Se acabó! Nos están atacando.','shot':'¡Has disparado! Se acabó la negociación.','example_usage':'Uso: /npcexample <cauto|agotado> <encuentro|tension|necesidad>. Requiere permisos de operador y una conversación activa.','example_denied':'Este comando de prueba requiere permisos de operador.','personality':'Personalidad de prueba: {personality}; situación: {situation}.','player_prefix':'Tú','intro':'Me llamo {name}.','error':'No se pudo continuar la conversación.','leave':'Me retiro. No busco problemas.','leave_response':'De acuerdo. Sigue tu camino.'}
def o(i,t,tone,reply,next=None,trust=0,effect='none'):
 d={'id':i,'text':t,'tono':tone,'response':reply,'effect':effect,'trust':trust}
 if next:d['next']=next
 return d
def leave():return o('retirarse',ui['leave'],2,ui['leave_response'],effect='close')
p={
'cauto':{'situations':{
'encuentro':{'text':'No des otro paso. Podemos hablar desde ahí.','options':[
 o('presentarse','Soy {player}. ¿Cómo te llamas?',1,'{intro} No confundas eso con confianza.','encuentro',1,'identify'),
 o('situacion','¿Está despejada la zona?',2,'No he revisado cada esquina. No te prometeré seguridad.','tension'),
 o('ayuda','¿Necesitas algo?',1,'Necesito saber que no vas a dispararme por la espalda.','necesidad'),leave()]},
'tension':{'text':'Mantén las manos a la vista. He perdido gente por confiar demasiado.','options':[
 o('calmar','No quiero pelear. Mantendré la distancia.',1,'Bien. Te escucharé mientras cumplas eso.','encuentro',2),
 o('limite','Hablaré, pero no me amenaces.',3,'Entonces no nos demos motivos. Tú ahí, yo aquí.','encuentro'),
 o('amenazar','Apártate o lo resolveremos por las malas.',4,'Amenazarme fue un error. Se acabó la charla.',trust=-6,effect='hostile'),leave()]},
'necesidad':{'text':'Nos faltan suministros. Pero primero necesito saber con quién hablo.','options':[
 o('escuchar','Cuéntame qué está pasando.',1,'Antes podía dormir sin hacer guardia. Ahora nunca bajo la cabeza del todo.','encuentro',1),
 o('limites','No prometo darte nada. Puedo escucharte.',3,'Prefiero una respuesta honesta a una promesa vacía.','encuentro'),
 o('enganar','Tengo un refugio seguro para todos. Ven conmigo.','engaño','No voy a seguir una promesa sin pruebas. Sigue hablando desde ahí.','tension'),leave()]}}},
'agotado':{'situations':{
'encuentro':{'text':'Te he visto. Por favor, dime que hoy no vamos a dispararnos.','options':[
 o('presentarse','Soy {player}. Puedes decirme tu nombre.',1,'{intro} Hace tiempo que nadie me lo preguntaba.','encuentro',1,'identify'),
 o('situacion','¿Has visto movimiento por aquí?',2,'Escuché cosas, pero estoy demasiado cansado para asegurar qué eran.','tension'),
 o('ayuda','Pareces agotado. ¿Qué necesitas?',1,'Descansar sin tener que vigilar cada ruido. Y suministros.','necesidad'),leave()]},
'tension':{'text':'No te acerques de golpe. Me sobresalto con cualquier cosa.','options':[
 o('calmar','Tranquilo. No voy a acercarme.',1,'Gracias. Dame un segundo... podemos hablar.','encuentro',2),
 o('limite','Necesito pasar. Mantengamos la calma.',3,'Vale. Sin movimientos bruscos por ninguno de los dos.','encuentro'),
 o('amenazar','Me estás estorbando. Quítate de una vez.',5,'No pienso dejar que me trates como una presa.',trust=-6,effect='hostile'),leave()]},
'necesidad':{'text':'No estoy bien. Cada día cuesta más seguir caminando.','options':[
 o('escuchar','Puedes hablar. Te escucho.',1,'A veces sigo por costumbre. Luego recuerdo que aún podría encontrar a alguien.','encuentro',1),
 o('limites','No puedo quedarme, pero no voy a hacerte daño.',2,'Es más de lo que otros me han ofrecido.','encuentro'),
 o('enganar','Todo va a estar bien. No hay peligro en esta zona.','engaño','No me prometas eso. Nadie puede saberlo.','tension'),leave()]}}}}
d={'schema':1,'ui':ui,'personalities':p}
(r/'data/dialogue-phase2.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
