from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');base='/workspace/npc70/release/tacznpcs-2.1.0-1.21.1-tactical.34-decision-authority.jar';gson='/workspace/medical63/gson.jar';asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis']);ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn']
subprocess.run(ecj+['-cp',base+':'+gson,'-d',str(r/'build')]+list(map(str,(r/'src').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'Patch71.java')],check=True)
subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'Patch71',base,str(r/'build'),str(r/'data/dialogue-phase2.json'),str(r/'release/tacznpcs-2.1.0-1.21.1-tactical.35-clickable-chat.jar')],check=True)
