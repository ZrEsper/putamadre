package mod.cdv.tnpc.tactical;
import com.google.gson.*;import java.nio.file.*;import java.io.*;import java.nio.charset.StandardCharsets;import java.util.*;
public final class DialogueData71 {
 static final String RESOURCE="/data/tacznpcs/dialogue/dialogue-phase2.json";
 static final Path CONFIG=Path.of("config/tacznpcs/dialogue-phase2.json");
 static final Set<String> EFFECTS=Set.of("none","identify","close","hostile");
 static final JsonObject DATA=load();
 static JsonObject load(){try(var in=DialogueData71.class.getResourceAsStream(RESOURCE)){
  if(in==null)throw new IllegalStateException("Missing dialogue JSON");byte[] defaults=in.readAllBytes();
  JsonObject base=JsonParser.parseString(new String(defaults,StandardCharsets.UTF_8)).getAsJsonObject();validate(base);
  try{if(Files.exists(CONFIG)){JsonObject custom=JsonParser.parseString(Files.readString(CONFIG)).getAsJsonObject();validate(custom);return custom;}Files.createDirectories(CONFIG.getParent());Files.write(CONFIG,defaults);}catch(Exception e){System.err.println("[NPC chat phase2] Invalid/unavailable dialogue config; using bundled JSON: "+e.getClass().getSimpleName());}
  return base;
 }catch(IOException e){throw new IllegalStateException(e);}}
 static void validate(JsonObject root){if(root.get("schema").getAsInt()!=1)throw new IllegalArgumentException("schema");JsonObject ui=root.getAsJsonObject("ui");for(String k:List.of("tones","unknown","expired","none","ended","unarmed","attacked","shot","example_usage","example_denied","personality","player_prefix","intro","error"))if(!ui.has(k))throw new IllegalArgumentException(k);
  JsonObject people=root.getAsJsonObject("personalities");if(people.size()!=2)throw new IllegalArgumentException("two personalities required");
  for(var person:people.entrySet()){if(!person.getKey().matches("[a-z_]{1,24}"))throw new IllegalArgumentException("personality id");JsonObject nodes=person.getValue().getAsJsonObject().getAsJsonObject("situations");for(String required:List.of("encuentro","tension","necesidad"))if(!nodes.has(required))throw new IllegalArgumentException(required);
   for(var node:nodes.entrySet()){if(!node.getKey().matches("[a-z_]{1,24}"))throw new IllegalArgumentException("node id");JsonObject n=node.getValue().getAsJsonObject();text(n,"text",350);JsonArray options=n.getAsJsonArray("options");if(options.size()<2||options.size()>4)throw new IllegalArgumentException("2-4 options");Set<String> ids=new HashSet<>();for(JsonElement e:options){JsonObject o=e.getAsJsonObject();String id=o.get("id").getAsString();if(!id.matches("[a-z_]{1,24}")||!ids.add(id))throw new IllegalArgumentException("option id");text(o,"text",160);text(o,"response",350);String tone=o.get("tono").getAsString();if(!Set.of("1","2","3","4","5","engaño").contains(tone)||!ui.getAsJsonObject("tones").has(tone))throw new IllegalArgumentException("tone");if(!EFFECTS.contains(o.get("effect").getAsString()))throw new IllegalArgumentException("effect");int trust=o.get("trust").getAsInt();if(trust< -10||trust>3)throw new IllegalArgumentException("trust");if(o.has("next")&&!nodes.has(o.get("next").getAsString()))throw new IllegalArgumentException("next");}}}
 }
 static void text(JsonObject o,String key,int max){String s=o.get(key).getAsString();if(s.isBlank()||s.length()>max||s.indexOf('\n')>=0||s.indexOf('\r')>=0)throw new IllegalArgumentException(key);}
 static String ui(String key){return DATA.getAsJsonObject("ui").get(key).getAsString();}
 static JsonObject nodes(String person){return DATA.getAsJsonObject("personalities").getAsJsonObject(person).getAsJsonObject("situations");}
 static String color(String tone){return switch(tone){case "1"->"#FFFFFF";case "2"->"#CCCCCC";case "3"->"#999999";case "4"->"#B07070";case "5"->"#A04040";case "engaño"->"#8899AA";default->throw new IllegalArgumentException("tone");};}
}
