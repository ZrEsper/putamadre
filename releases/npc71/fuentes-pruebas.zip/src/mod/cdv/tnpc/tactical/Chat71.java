package mod.cdv.tnpc.tactical;
import com.google.gson.*;import java.util.*;import java.lang.reflect.Proxy;import java.security.*;import java.nio.charset.StandardCharsets;
public final class Chat71 {
 static final SecureRandom RANDOM=new SecureRandom();
 static Object c(Object o,String m,Object...a){return Social.c(o,m,a);}
 static State state(Conversation.Session session){return (State)SocialR.get(session,"chat71");}
 static void state(Conversation.Session session,State state){SocialR.set(session,"chat71",state);}
 static String random(){byte[] b=new byte[16];RANDOM.nextBytes(b);return HexFormat.of().formatHex(b);}
 public static String ui(String key){return DialogueData71.ui(key);}
 public static void notice(Object player,String key){JsonObject packet=new JsonObject();packet.add("lines",new JsonArray());packet.getAsJsonArray("lines").add(component(ui(key),"#CCCCCC"));send(player,packet);}
 static void send(Object player,JsonObject packet){TalkNetwork.send(player,"C71\n"+packet);}
 static String knownKey(Object player){return "npc71_known_"+Social.identity(player);}
 static String speaker(Object npc,Object player){return Social.yes(c(Social.tag(npc),"getBoolean",knownKey(player)))?Identity20.name(npc):ui("unknown");}
 static String format(String s,Object npc,Object player){String name=Identity20.name(npc);String pname=(String)c(c(player,"getName"),"getString");return s.replace("{intro}",ui("intro").replace("{name}",name)).replace("{name}",name).replace("{player}",pname);}
 static JsonObject component(String text,String color){JsonObject j=new JsonObject();j.addProperty("text",text);j.addProperty("color",color);return j;}
 static JsonObject speech(String name,String text){JsonObject j=component("["+name+"] ","#CCCCCC");JsonArray a=new JsonArray();a.add(component(text,"#FFFFFF"));j.add("extra",a);return j;}
 static String initial(Object npc,Object player){if(Social.enemy(npc,player)||Social.kind(npc)==0)return "tension";double max=Social.num(c(npc,"getMaxHealth"));return Social.num(c(npc,"getHealth"))<max*.8?"necesidad":"encuentro";}
 static String personality(Object npc){String key=Social.s(Social.tag(npc),"npc71_personality");JsonObject people=DialogueData71.DATA.getAsJsonObject("personalities");if(!people.has(key)){List<String> ids=new ArrayList<>(people.keySet());Collections.sort(ids);key=ids.get(Math.floorMod(Social.uuid(npc).hashCode(),ids.size()));c(Social.tag(npc),"putString","npc71_personality",key);}return key;}
 public static boolean open(Object npc,Object player,String topic){if(!Authority70.enabled(npc)||Downed20.down(npc))return false;
  try{Conversation.Session session=Conversation.SESSIONS.get(player);if(session==null||session.npc!=npc)return true;
   Authority70.sent(npc,player);if(!Authority70.busy(npc))return true;
   State old=state(session);if(old!=null)invalidate(player,old);
   State s=new State(random(),personality(npc),initial(npc,player));state(session,s);render(npc,player,s,true);return true;
  }catch(Exception e){Authority70.end(npc,false,null);Social.warn("phase2 open",e);notice(player,"error");return true;}}
 static void invalidate(Object player,State s){if(s.token==null)return;s.token=null;JsonObject j=new JsonObject();j.addProperty("invalidate",s.id);try{send(player,j);}catch(Exception e){Social.warn("phase2 invalidate disconnected client",e);}}
 public static void ended(Object npc){for(var e:new ArrayList<>(Conversation.SESSIONS.entrySet()))if(e.getValue().npc==npc){State s=state(e.getValue());if(s!=null){invalidate(e.getKey(),s);state(e.getValue(),null);}}}
 static void render(Object npc,Object player,State s,boolean text){s.token=random();s.until=Authority70.state(npc).until;
  JsonObject node=DialogueData71.nodes(s.personality).getAsJsonObject(s.node);s.offered=node.getAsJsonArray("options").deepCopy();
  JsonObject packet=new JsonObject();packet.addProperty("id",s.id);packet.addProperty("token",s.token);packet.addProperty("remainingTicks",Math.max(0,s.until-Social.time(npc)));
  JsonArray lines=new JsonArray();if(text)lines.add(speech(speaker(npc,player),format(node.get("text").getAsString(),npc,player)));packet.add("lines",lines);
  JsonArray options=new JsonArray();for(JsonElement e:s.offered){JsonObject o=e.getAsJsonObject();String tone=o.get("tono").getAsString();JsonObject j=component("▸ "+format(o.get("text").getAsString(),npc,player),DialogueData71.color(tone));JsonObject click=new JsonObject();click.addProperty("action","run_command");click.addProperty("value","/npcreply "+s.id+" "+o.get("id").getAsString()+" "+s.token);j.add("clickEvent",click);JsonObject hover=new JsonObject();hover.addProperty("action","show_text");hover.add("contents",component(DialogueData71.DATA.getAsJsonObject("ui").getAsJsonObject("tones").get(tone).getAsString(),"#CCCCCC"));j.add("hoverEvent",hover);options.add(j);}packet.add("options",options);send(player,packet);
 }
 static boolean valid(Object player,Conversation.Session session,State s){return s!=null&&s.token!=null&&Conversation.SESSIONS.get(player)==session&&Social.time(session.npc)<s.until&&Authority70.busy(session.npc);}
 public static int reshow(Object player){Conversation.Session session=Conversation.SESSIONS.get(player);State s=session==null?null:state(session);if(session==null||!valid(player,session,s)){if(s!=null)invalidate(player,s);notice(player,"none");return 0;}invalidate(player,s);render(session.npc,player,s,false);return 1;}
 static boolean same(String a,String b){return a!=null&&b!=null&&MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8),b.getBytes(StandardCharsets.UTF_8));}
 public static int choose(Object player,String id,String option,String token){Conversation.Session session=Conversation.SESSIONS.get(player);State s=session==null?null:state(session);
  if(session==null||!valid(player,session,s)||!same(s.id,id)||!same(s.token,token)){if(s!=null&&session!=null&&!valid(player,session,s))invalidate(player,s);notice(player,"expired");return 0;}
  JsonObject choice=null;for(JsonElement e:s.offered)if(e.getAsJsonObject().get("id").getAsString().equals(option)){choice=e.getAsJsonObject();break;}if(choice==null){notice(player,"expired");return 0;}
  Object npc=session.npc;invalidate(player,s); // retire capability before any side effects
  try{
   JsonObject response=new JsonObject();JsonArray lines=new JsonArray();lines.add(speech((String)c(c(player,"getName"),"getString"),format(choice.get("text").getAsString(),npc,player)));
   String effect=choice.get("effect").getAsString();if(effect.equals("identify"))c(Social.tag(npc),"putBoolean",knownKey(player),true);
   int delta=choice.get("trust").getAsInt();String reward="npc71_reward_"+Social.identity(player)+"_"+s.node+"_"+choice.get("id").getAsString();long now=Social.time(npc);if(delta<0||delta>0&&now>=Social.l(Social.tag(npc),reward)){Social.trust(npc,player,delta);if(delta>0)c(Social.tag(npc),"putLong",reward,now+24000L);}
   lines.add(speech(speaker(npc,player),format(choice.get("response").getAsString(),npc,player)));response.add("lines",lines);send(player,response);
   if(effect.equals("close")||effect.equals("hostile")){
    Authority70.end(npc,false,null);
    if(effect.equals("hostile")){c(Social.tag(npc),"putString","soc_enemy",Social.identity(player).toString());c(Social.tag(npc),"putLong","soc_enemy_until",now+6000L);c(Social.tag(npc),"putLong","npc70_retry_"+Social.identity(player),now+Authority70.RETRY);Social.mem(npc).nextAcquire=0L;Social.target(npc,player);}
    return 1;
   }
   if(choice.has("next"))s.node=choice.get("next").getAsString();session.until=now+1200L;Authority70.sent(npc,player);if(Authority70.busy(npc))render(npc,player,s,true);return 1;
  }catch(Exception e){Authority70.end(npc,false,null);Social.warn("phase2 reply",e);notice(player,"error");return 0;}
 }
 // Legacy GUI commands cannot manufacture unoffered choices. Medical sessions remain native.
 public static int legacy(Object player,String op){Conversation.Session session=Conversation.SESSIONS.get(player);if(session==null||state(session)==null)return -1;if(op.equals("close")){Authority70.end(session.npc,false,null);return 1;}notice(player,"expired");return 0;}
 public static int example(Object player,String person,String node,boolean permitted){if(!permitted){notice(player,"example_denied");return 0;}Conversation.Session session=Conversation.SESSIONS.get(player);State s=session==null?null:state(session);if(session==null||!valid(player,session,s)||!DialogueData71.DATA.getAsJsonObject("personalities").has(person)||!DialogueData71.nodes(person).has(node)){notice(player,"example_usage");return 0;}invalidate(player,s);s.personality=person;s.node=node;render(session.npc,player,s,true);return 1;}
 interface Handler{int run(Object context);}
 static Object command(Handler h){Class<?> type=Social.t("com.mojang.brigadier.Command");return Proxy.newProxyInstance(type.getClassLoader(),new Class[]{type},(p,m,args)->m.getName().equals("run")?h.run(args[0]):0);}
 static Object literal(String s){return c(Social.t("com.mojang.brigadier.builder.LiteralArgumentBuilder"),"literal",s);}
 static Object arg(String s){return c(Social.t("com.mojang.brigadier.builder.RequiredArgumentBuilder"),"argument",s,c(Social.t("com.mojang.brigadier.arguments.StringArgumentType"),"word"));}
 static String argValue(Object ctx,String key){return (String)c(Social.t("com.mojang.brigadier.arguments.StringArgumentType"),"getString",ctx,key);}
 static Object player(Object ctx){return c(c(ctx,"getSource"),"getPlayer");}
 public static void register(Object event){Object dispatcher=c(event,"getDispatcher");Object root=literal("npcreply");c(root,"executes",command(ctx->{Object p=player(ctx);return p==null?0:reshow(p);}));Object id=arg("conversation"),option=arg("option"),token=arg("token");c(token,"executes",command(ctx->{Object p=player(ctx);return p==null?0:choose(p,argValue(ctx,"conversation"),argValue(ctx,"option"),argValue(ctx,"token"));}));c(option,"then",token);c(id,"then",option);c(root,"then",id);c(dispatcher,"register",root);
  Object alias=literal("superviviente");c(alias,"executes",command(ctx->{Object p=player(ctx);return p==null?0:reshow(p);}));c(dispatcher,"register",alias);
  Object ex=literal("npcexample"),person=arg("personality"),node=arg("situation");c(ex,"requires",(java.util.function.Predicate<Object>)(source->Social.yes(c(source,"hasPermission",2))));c(node,"executes",command(ctx->{Object p=player(ctx);return p==null?0:example(p,argValue(ctx,"personality"),argValue(ctx,"situation"),Social.yes(c(c(ctx,"getSource"),"hasPermission",2)));}));c(person,"then",node);c(ex,"then",person);c(dispatcher,"register",ex);
 }
 public static final class State {final String id;String personality,node,token;long until;JsonArray offered;State(String id,String personality,String node){this.id=id;this.personality=personality;this.node=node;}}
}
