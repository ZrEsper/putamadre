from pathlib import Path
import zipfile,json,hashlib
r=Path(__file__).parent;o=r/'release'
(o/'LEEME.txt').write_text('''TaCZ NPCs .39 — Primera etapa: conversación abierta
Minecraft 1.21.1 / NeoForge. Sustituye .38 por este JAR en cliente y servidor.
No dejes ambos. Respalda el mundo y config/tacznpcs antes de actualizar.

QUÉ CAMBIA
Charlas normales de las ocho voces: menú de cinco opciones; salud, suministros,
objetivos, pasado/origen/familia y entorno. Puedes navegar sin máximo de turnos.
Agotar frases nuevas no termina la conversación. Se indica (ya tratado), se conserva
el menú y no se vuelven a aplicar sus efectos al pulsar una respuesta agotada.
Hay 8 encuentros abiertos nuevos, 6 menús por voz, y 374 líneas distintas en el conjunto
nuevo (no son horas garantizadas de texto por NPC). Todos los textos están en el JSON.

Las preguntas de heridas consultan la salud real; suministros consulta la bolsa;
clima consulta precipitación en su posición; día/noche consulta la hora del mundo;
techo consulta exposición al cielo. Dar comida/medicina transfiere una unidad real
con los controles de inventario existentes; no cura automáticamente ni inventa hambre.
Identidad aleatoria y privacidad por confianza se mantienen.

La negociación de conflictos, robo y emboscada siguen usando sus encuentros estructurados.
No se convierten en una charla infinita que anule sus consecuencias. Los comandos de
operador anteriores, memoria, medidores, antispam y bloqueo de ataque se conservan.

PAUSA Y CONTINUIDAD
Tras 30 segundos sin elegir, solo la charla abierta queda en pausa. Las opciones se
anulan y el NPC recupera su IA nativa: no queda congelado esperando indefinidamente.
Con manos sin arma, cerca y a su vista: /npcreply para retomar durante 10 minutos.
También sirve volver a interactuar. Se conserva el tema y las frases ya dichas.
Reanudar rota el token; un clic antiguo no puede ejecutar la opción anterior.
No se reanuda con peligro, corriendo, apuntando, NPC derribado ni muerto.
Si empiezas una interacción manual con arma, es un robo nuevo, no la charla pausada.

Solo se retiene una charla pausada por jugador. El estado de pausa/frases es temporal;
recargar configuración lo elimina. El último menú se guarda en NBT por UUID, de modo
que al volver tras reiniciar o recargar el NPC pueda conservar el tema. Eso es un
encuentro nuevo: no conserva todo el historial textual tras un reinicio del servidor.

CIERRES EXPLICADOS
Un cierre por arma, carrera, peligro, distancia o estado ahora tiene un aviso específico.
El log incluye [TacZ NPC dialogue] reason=..., NPC, jugador, nodo, tick y plazos.
/npcdebug añade ultimo_cierre. Los cierres nativos externos también se registran.
Esto permite diagnosticar el cierre de unos 10 segundos del log recibido; no se pudo
reproducir su causa exacta dentro del modpack desde este entorno.

CONFIGURACIÓN
config/tacznpcs/dialogue-phase2.json, schema 3 compatible.
Original .38: copia dialogue-phase2.pre39.bak.json y migración al nuevo contenido.
JSON personalizado: conserva sus textos; añade los campos opcionales y encuentros libres.
config.conversacion_abierta=false recupera la selección anterior de charlas normales.
config.registrar_cierres=true activa diagnósticos de cierre de la autoridad.
config.reanudar_ticks=12000 controla los 10 minutos de reanudación temporal.
respuesta_ticks=600 y pausa_lineas_ticks=50 conservan 30 s / 2,5 s. El cliente admite
el plazo configurable completo hasta 2400 ticks, sin recortarlo a 600.
/npcreload sigue recargando sin borrar identidad ni memoria; invalida sesiones y pausas.
/npcvalidate valida modo libre, cinco opciones, entorno y variantes de respuestas.
/npcexample cansado libre_cansado permite probar un encuentro libre desarmado.

ALCANCE DE ESTA ENTREGA
Es la primera etapa de la expansión conversada. NO construye sociedades, edificios,
perímetros, rutas de viaje ni economía nueva. No genera profesiones activas ni hambre
simulada. Esas funciones corresponden a las siguientes etapas de necesidades, rutinas
y asentamientos. Preguntar por compartir camino no recluta ni crea un grupo nuevo.
No se puede prometer que una biblioteca finita de diálogos dure horas sin repetirse;
esta versión elimina cierres artificiales y da la base para ampliar contenido y contexto.

PRUEBAS
Pruebas JVM con APIs simuladas: 277 regresión, 15126 identidad/chat/emboscada, 124 memoria,
2249 modo abierto. 12 casos de configuración en JVMs separadas; 163 clases ASM verificadas.
NO se ejecutó Minecraft real, NeoForge, GPU ni servidor dedicado. Ver PRUEBAS.md.
''')
(o/'CAMBIOS.txt').write_text('''Base exacta: .38-persistent-memory.
Añadidos: Free75 (contexto, selección libre, pausa/reanudación y causas de cierre),
Free75$Pause, FreeData75 (defaults/validación) y phase3-original.json.
Modificados:
- Chat71: selección de charlas abiertas, navegación sin tope, agotamiento sin cierre,
  reanudación segura y pausa neutral. Mantiene el protocolo C71.
- DialogueRules72: filtro entorno para condiciones de respuesta.
- DialogueData71: modo_libre, cinco opciones solo en ese modo y variantes opcionales.
- Config74/Data73: importación de los nuevos defaults, respaldo .pre39 y limpieza de pausas.
- Gate74: no inyecta una sexta opción de memoria sobre el menú libre.
- Flow73: evita reiniciar automáticamente una charla con ese NPC que el jugador dejó en pausa.
- Ops74: último motivo de cierre en /npcdebug.
- ClientChat71: respeta el plazo configurable hasta 2400 ticks.
- Authority70.end: un enganche de diagnóstico antes de borrar la sesión.
- Conversation.end: un enganche que identifica cierres nativos externos.
- JSON completo: ocho voces ampliadas y contenido contextual.
- Metadatos: 2.1.0-tactical.39-open-conversations.
Assets de modelos/texturas/sonidos idénticos a .38. No instala otro controlador de IA.
Las implementaciones nativas de construcción, seguimiento y facciones no se sustituyen.
''')
(o/'ESQUEMA.md').write_text('''Adiciones opcionales sobre schema 3:

- config.conversacion_abierta: bool, defecto true.
- config.registrar_cierres: bool, defecto true.
- config.reanudar_ticks: 600–24000, defecto 12000.
- encuentro.modo_libre: bool, defecto false. Hasta cinco opciones por nodo;
  turnos_max se conserva en el archivo por compatibilidad pero no cierra ese modo.
  Un encuentro estructurado conserva el límite de cuatro opciones y sus resultados.
- requiere/condicion.entorno: objeto de booleanos. Campos permitidos: herido,
  comida_en_bolsa, llueve, noche, bajo_techo, armado. Solo sensores, no efectos.
- respuesta.variantes: hasta ocho bloques {condicion?, lineas_npc:[2–4 líneas]}.
  En modo libre se escoge un bloque válido con al menos dos líneas nuevas; después se
  prueba la línea base. No aplica efectos extra. El contenido incluido usa principalmente
  ramas de contexto para que un cambio del entorno desbloquee otra respuesta.

No se repite una línea del NPC dentro del mismo encuentro. Si no quedan frases nuevas
para un tema, el menú continúa. Una navegación puede funcionar sin otro discurso del NPC.
No vuelve a gastar objetos ni a premiar confianza al pulsar un tema agotado.
Las líneas privadas siguen pasando por las revelaciones y umbrales existentes.

Temas incluidos por voz: heridas, comida en bolsa, ánimo, apoyo, necesidad de suministros,
destino, equipo, compartir camino, nombre, origen, familia, profesión, clima, hora,
cobertura y amenazas. Los temas narrativos no son objetivos de navegación ni tareas
futuras automáticas. No implementan las etapas de necesidades y construcción.

Persistencia nueva: npc75_tema_UUID (último menú), npc75_ultimo_cierre (diagnóstico).
Las sesiones de pausa son temporales con referencia débil al NPC. No fuerzan chunks.
El NBT y SavedData sociales de .38 no cambian.
''')
(o/'PRUEBAS.md').write_text('''Comprobaciones automáticas realizadas, NO ejecutadas dentro de Minecraft:
- 163 clases ASM BasicVerifier; dos enganches exactos de diagnóstico de cierre.
- 277 controles de arbitraje, disparo real trasplantado y rupturas.
- 15126 controles de identidad, privacidad, dos actores de emboscada y chat.
- 124 controles de memoria, medidores, robo finito, persistencia simulada y comandos.
- 2249 controles de charla abierta: ocho voces, más de cien elecciones consecutivas
  por voz sin reinicio/cierre, ausencia de frases repetidas, sensores de contexto,
  revelaciones privadas, donación real en inventario simulado, pausas, cambio de token,
  bloqueo de reanudación insegura y motivos específicos de cierre.
- 12 casos de configuración en JVMs independientes: creación, relectura, originales
  anteriores, .38, personalizaciones, schema 1/2/3 y respaldo de archivo inválido.
- JVM -Xverify:all; Brigadier real. Las APIs del mundo, entidades y cliente son simuladas.

No se comprobó Minecraft real, NeoForge, GPU, red cliente/servidor, distancia real de
interacción, sensores de bioma/clima/cielo del motor, terceros que cierren la charla,
guardado real/chunks ni rendimiento del modpack. El log recibido era de .38.
No se ha identificado en vivo la causa exacta de su cierre anticipado: .39 añade el
motivo al log y al aviso para distinguir peligro, arma, distancia, plazo y cierre externo.

Tabla de prueba en Minecraft — PENDIENTE EN TODOS LOS CASOS:

| Caso | Pasos | Qué debe pasar |
|---|---|---|
| Actualización | Reemplazar .38 en ambos lados; copia del mundo/config | .39 carga; original se respalda como .pre39; identidad/memoria intactas |
| Charla normal | Acercarse desarmado a neutral/pasivo | Menú con cinco áreas; no encuentro mínimo genérico de dos respuestas |
| Continuidad | Elegir más de diez preguntas y volver entre menús | No termina por número de turnos |
| Tema agotado | Repetir una pregunta sin cambios | Marca ya tratado; no repite discurso ni termina la charla |
| Volver al menú | Entrar y salir de un tema ya visto repetidamente | Siempre permite navegar, incluso sin frases nuevas |
| Ocho voces | /npcexample seco libre_seco y equivalentes de las ocho voces | Estilo propio y biblioteca completa para cada voz |
| Heridas | Preguntar salud, herir al NPC fuera de la charla y volver | Respuesta cambia con su salud real; daño durante charla la interrumpe |
| Suministros | Preguntar por comida antes/después de una donación | Bolsa vacía y bolsa con comida dan respuestas distintas |
| Clima | Preguntar con y sin precipitación en la posición del NPC | Selecciona la rama correspondiente |
| Hora | Preguntar de día y de noche | Respuesta según hora del mundo |
| Techo | Preguntar bajo techo y con cielo expuesto | Cambia la respuesta sin prometer que el lugar sea seguro |
| Privacidad | Preguntar origen/familia/profesión con confianza baja y luego media | Reserva detalles primero; después revela datos persistentes |
| Nombre | Presentarse | Revela el nombre aleatorio y lo muestra en el chat |
| Ayuda | Ofrecer una unidad de comida o medicina | Transfiere unidad real; guarda recuerdo, sin curación inventada |
| Inventario vacío | Intentar ofrecer sin tener ese recurso | Opción no disponible; no crea objetos |
| Pausa | Dejar pasar 30 s desde las opciones | Aviso de pausa, opciones anuladas y NPC vuelve a IA nativa |
| Retomar | /npcreply cerca, visible, desarmado y sin peligro | Vuelve al mismo tema con token nuevo |
| Token antiguo | Pulsar una opción de antes de la pausa | No ejecuta efectos |
| Retomar con peligro | Reanudar con amenaza cerca | No pausa defensa ni fuerza conversación |
| Retomar armado | /npcreply sosteniendo arma | No reanuda charla normal; interacción manual puede iniciar robo |
| Carrera | Correr en una charla | Cierre por carrera visible y reason=sprint en log |
| Arma/ADS | Sacar arma en charla normal o ADS durante intimidación | Cierre por arma, manteniendo seguridad anterior |
| Distancia | Alejarse fuera del radio | Aviso de distancia y reason=distance |
| Amenaza | Acercar una amenaza real | Cierre con aviso de peligro y reason=danger |
| Diagnóstico | /npcdebug después de un cierre | Muestra ultimo_cierre; log incluye nodo, ticks y plazos |
| Despedida | Elegir Seguimos en otro momento | Cierra realmente, sin dejar una pausa reanudable |
| Configuración | /npcreload y /npcvalidate | Valida nuevas secciones; reload anula pausas/tokens sin borrar memoria |
| Compatibilidad | conversacion_abierta=false y recargar | Regresa a selección de encuentros anterior |
| Emboscada/robo | Probar ejemplos estructurados anteriores | Conservan actores, efectos, consecuencias y límites propios |
| Reinicio | Guardar/salir y volver al NPC | Conserva identidad, memoria y último menú; comienza nueva sesión textual |

Siguiente etapa acordada: necesidades y rutinas individuales. Construcción, perímetros
y sociedades aún no están implementados en esta entrega. El contenido es finito y no
se presenta como garantía de horas de diálogo único por NPC.
''')
(o/'dialogue-phase2.json').write_bytes((r/'data/dialogue-phase2.json').read_bytes())
with zipfile.ZipFile(o/'fuentes-pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for name in ['Patch75.java','Extract70.java','Extract71.java','Extract73.java','build.py','test.py','config_test.py','make_data.py','package.py']:z.write(r/name,name)
 for folder in ['src','testsrc','data','api']:
  for p in sorted((r/folder).rglob('*')):
   if p.is_file() and p.suffix in ['.java','.json']:z.write(p,p.relative_to(r))
 dep=Path('/workspace/npc71/brigadier-source')
 for p in (dep/'src/main/java').rglob('*.java'):z.write(p,'brigadier-source/'+str(p.relative_to(dep)))
 z.write(dep/'LICENSE','brigadier-source/LICENSE')
 z.writestr('REPRODUCIR.txt','Java 21, Python 3, ECJ, Gson y ASM/asm-tree/asm-analysis/asm-commons. Base JAR .38 exacta. build.py admite NPC_BASE_JAR, NPC_BUILD_TOOLS, NPC_GSON_JAR. Ajustar rutas de test.py/config_test.py al entorno local para Gson, ASM commons y Brigadier fuente MIT incluido. Ejecutar make_data.py, build.py, test.py y config_test.py. api/ solo declara tipos Minecraft para compilar SavedData; NO se incluye en el mod. testsrc/ simula APIs: las pruebas no equivalen a ejecutar Minecraft.')
base=Path('/workspace/npc74/release/tacznpcs-2.1.0-1.21.1-tactical.38-persistent-memory.jar');jar=next(o.glob('*.jar'));a=zipfile.ZipFile(base);b=zipfile.ZipFile(jar)
assert all(a.read(n)==b.read(n)for n in a.namelist()if n.startswith('assets/'))
assert not any(n.startswith('net/minecraft/')for n in b.namelist())
manifest={'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'minecraft_run':False,'asm_classes':163,'regression_checks':277,'phase26_checks':15126,'phase3_checks':124,'open_checks':2249,'config_cases':12,'changed':[n for n in a.namelist()if n in b.namelist()and a.read(n)!=b.read(n)],'added':sorted(set(b.namelist())-set(a.namelist()))}
(o/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive='NPCs-39-Conversacion-Abierta.zip'
(o/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'for p in sorted(o.iterdir())if p.name not in [archive,'SHA256SUMS.txt']))
with zipfile.ZipFile(o/archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(o.iterdir()):
  if p.name!=archive:z.write(p,p.name)
print('JAR SHA256',manifest['jar_sha256']);print('ZIP bytes',(o/archive).stat().st_size)
