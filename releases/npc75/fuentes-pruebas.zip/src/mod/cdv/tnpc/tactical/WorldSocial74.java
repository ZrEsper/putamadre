package mod.cdv.tnpc.tactical;
import com.google.gson.*;import java.util.*;import net.minecraft.world.level.saveddata.SavedData;import net.minecraft.nbt.CompoundTag;import net.minecraft.core.HolderLookup;
/** Phase 7 namespace only: no actors, groups, rumors or faction behavior. */
public final class WorldSocial74 extends SavedData {
 static final Set<Object>INITIALIZED=Collections.newSetFromMap(new WeakHashMap<>());final JsonObject schema;
 public WorldSocial74(){schema=new JsonObject();schema.addProperty("version",1);schema.add("grupos",new JsonObject());schema.add("facciones",new JsonObject());setDirty();}
 WorldSocial74(CompoundTag tag){String raw=tag.getString("social");schema=raw.isBlank()?new JsonObject():JsonParser.parseString(raw).getAsJsonObject();if(!schema.has("version")||schema.get("version").getAsInt()!=1||!schema.has("grupos")||!schema.has("facciones"))throw new IllegalArgumentException("World social namespace");}
 public CompoundTag save(CompoundTag tag,HolderLookup.Provider registries){tag.putString("social",schema.toString());return tag;}
 static void ensure(Object npc){Object world=Social.world(npc);if(INITIALIZED.contains(world))return;Object storage=Social.c(Social.c(world,"getChunkSource"),"getDataStorage");Social.c(storage,"computeIfAbsent",new SavedData.Factory<WorldSocial74>(WorldSocial74::new,(tag,provider)->new WorldSocial74(tag)),"tacznpcs_social_phase3");INITIALIZED.add(world);}
}
