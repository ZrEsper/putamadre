package mod.cdv.tnpc.tactical;
import com.google.gson.*;import java.util.*;
public final class FreeData75 {
 static final Set<String>CONTEXT=Set.of("herido","llueve","noche","bajo_techo","comida_en_bolsa","armado");
 static void context(JsonObject c){for(var e:c.entrySet())if(!CONTEXT.contains(e.getKey())||!e.getValue().isJsonPrimitive()||!e.getValue().getAsJsonPrimitive().isBoolean())throw new IllegalArgumentException("entorno: booleano o campo inválido "+e.getKey());}
 static void variants(JsonObject r,JsonObject root){if(!r.has("variantes"))return;JsonArray variants=r.getAsJsonArray("variantes");if(variants.size()>8)throw new IllegalArgumentException("máximo ocho variantes");for(JsonElement e:variants){JsonObject v=e.getAsJsonObject();DialogueData71.only(v,"condicion","lineas_npc");if(v.has("condicion"))DialogueData71.condition(v.getAsJsonObject("condicion"),root);DialogueData71.lines(v.get("lineas_npc"),false);}}
 static JsonObject defaults(JsonObject raw,JsonObject base){JsonObject out=raw.deepCopy();Set<String>ids=new HashSet<>();for(JsonElement e:out.getAsJsonArray("encuentros"))ids.add(e.getAsJsonObject().get("id").getAsString());for(JsonElement e:base.getAsJsonArray("encuentros"))if(e.getAsJsonObject().has("modo_libre")&&!ids.contains(e.getAsJsonObject().get("id").getAsString()))out.getAsJsonArray("encuentros").add(e.deepCopy());return out;}
 static void config(JsonObject config){for(String k:List.of("conversacion_abierta","registrar_cierres"))if(!config.get(k).isJsonPrimitive()||!config.get(k).getAsJsonPrimitive().isBoolean())throw new IllegalArgumentException(k+" booleano");DialogueData71.integer(config.get("reanudar_ticks"),600,24000);}
}
