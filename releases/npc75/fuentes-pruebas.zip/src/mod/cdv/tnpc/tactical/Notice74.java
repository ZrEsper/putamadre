package mod.cdv.tnpc.tactical;
import java.util.*;
public final class Notice74 {
 static class Entry{long sent,last;Entry(long at){sent=last=at;}}static final Map<Object,Map<String,Entry>>PLAYERS=new WeakHashMap<>();
 static long now(Object p){return Social.time(p);}static String key(String s){return s.replaceFirst("^\\[\\?\\?\\?]\\s*","").strip().replaceAll("\\s+"," ");}
 static boolean allow(Object p,String line){String k=key(line);long now=now(p),cooldown=DialogueData71.config("mensajes_cooldown_ticks");Map<String,Entry>map=PLAYERS.computeIfAbsent(p,x->new LinkedHashMap<>());Entry old=map.get(k);if(old!=null&&now>=old.last&&now-old.last<cooldown){old.last=now;return false;}map.put(k,new Entry(now));while(map.size()>128)map.remove(map.keySet().iterator().next());return true;}
 public static void tell(Object p,String line){if(allow(p,line))Social.c(p,"displayClientMessage",Social.c(Social.t("net.minecraft.network.chat.Component"),"literal",line),false);}
 static List<String>debug(Object p){long now=now(p);List<String>out=new ArrayList<>();for(var e:PLAYERS.getOrDefault(p,Map.of()).entrySet()){long ticks=DialogueData71.config("mensajes_cooldown_ticks")-(now-e.getValue().last);if(ticks>0)out.add(e.getKey()+" : "+((ticks+19)/20)+" s");}return out;}
}
