from pathlib import Path
import tempfile,subprocess,json
r=Path(__file__).parent
cp=str(r/'tests')+':'+str(next((r/'release').glob('*.jar')))+':/workspace/medical63/gson.jar'
def run(data=None,count=21):
 with tempfile.TemporaryDirectory(dir=r,prefix='config-') as folder:
  path=Path(folder)/'config/tacznpcs/dialogue-phase2.json'
  if data is not None:
   path.parent.mkdir(parents=True);path.write_text(data)
  result=subprocess.run(['java','-Xverify:all','-cp',cp,'mod.cdv.tnpc.tactical.ConfigProbe72'],cwd=folder,check=True,capture_output=True,text=True)
  assert result.stdout.strip().startswith(f'3:{count}:'),result
  return path.read_text(),path.with_name('dialogue-phase2.pre39.bak.json').exists(),result
base=(r/'data/dialogue-phase2.json').read_text()
written,backup,result=run();assert json.loads(written)==json.loads(base) and not backup
run(written)
original=(r/'data/phase25-original.json').read_text();written,backup,result=run(original);assert backup and json.loads(written)==json.loads(base)
custom=json.loads(original);custom['config']['pausa_lineas_ticks']=40
written,backup,result=run(json.dumps(custom));assert result.stdout.strip().startswith('3:21:40:') and not backup
bad='{INVALID';written,backup,result=run(bad);assert written==bad and 'respaldo incluido' in result.stderr
invalid=json.loads(base);invalid['encuentros'][0]['nodos'][0]['lineas_npc'][0]='{variable_prohibida}'
raw=json.dumps(invalid);written,backup,result=run(raw);assert written==raw and 'respaldo incluido' in result.stderr
legacy=json.loads(Path('/workspace/npc71/data/dialogue-phase2.json').read_text());legacy['ui']['ended']='MARCADOR PERSONAL'
written,backup,result=run(json.dumps(legacy),21);assert 'true' in result.stdout and not backup
original37=(r/'data/phase26-original.json').read_text();written,backup,result=run(original37);assert backup and json.loads(written)==json.loads(base)
custom37=json.loads(original37);custom37['config']['pausa_lineas_ticks']=45
written,backup,result=run(json.dumps(custom37));assert result.stdout.strip().startswith('3:21:45:') and not backup
invalid=json.loads(base);invalid['social']['formula']['miedo']['actual']['miedo']=999
raw=json.dumps(invalid);written,backup,result=run(raw);assert written==raw and 'respaldo incluido' in result.stderr
original38=(r/'data/phase3-original.json').read_text();written,backup,result=run(original38);assert backup and json.loads(written)==json.loads(base)
custom38=json.loads(original38);custom38['config']['pausa_lineas_ticks']=55
written,backup,result=run(json.dumps(custom38));assert result.stdout.strip().startswith('3:21:55:') and not backup
print('PASS 12 independent JVM config cases: fresh/reload, .36 backup migration, custom schema2, malformed/prohibited fallback, schema1 preservation. Not Minecraft.')
