package com.tacz.guns.api.entity;public enum ShootResult{SUCCESS,COOL_DOWN}
