package dev.zomboid.firstaid;public class BodyTreatmentScreen20{public static String received;public static void receiveNpc(String s){received=s;}}
