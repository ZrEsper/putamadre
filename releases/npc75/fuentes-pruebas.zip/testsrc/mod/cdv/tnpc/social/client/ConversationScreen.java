package mod.cdv.tnpc.social.client;public class ConversationScreen{public static int opened;public static void open(String s){opened++;}}
