package mod.cdv.tnpc.tactical;public class Downed20{static boolean down(Object n){return ((Fixtures70.Npc)n).down;}}
