package mod.cdv.tnpc.tactical;public class Roles22{public static void finish(Object n){((Fixtures70.Npc)n).kind=0;}}
