package mod.cdv.tnpc.tactical;public class TeamBrain{static Memory mem(Object n){return ((Fixtures70.Npc)n).teamMemory;}public static class Memory{boolean fleeing;long lastThreat,hurtAt;}}
