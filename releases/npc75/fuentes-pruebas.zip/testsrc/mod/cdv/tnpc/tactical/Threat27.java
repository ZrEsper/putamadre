package mod.cdv.tnpc.tactical;public class Threat27{static boolean recent(Object n,Object p,long t){return ((Fixtures70.Npc)p).recent;}}
