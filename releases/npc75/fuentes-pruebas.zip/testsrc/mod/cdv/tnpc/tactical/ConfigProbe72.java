package mod.cdv.tnpc.tactical;
public class ConfigProbe72{public static void main(String[]a){System.out.println(DialogueData71.DATA.get("schema").getAsInt()+":"+DialogueData71.DATA.getAsJsonArray("encuentros").size()+":"+DialogueData71.config("pausa_lineas_ticks")+":"+DialogueData71.DATA.toString().contains("MARCADOR PERSONAL"));}}
