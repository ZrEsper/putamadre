package mod.cdv.tnpc.tactical;public record TalkPayload(String text){}
