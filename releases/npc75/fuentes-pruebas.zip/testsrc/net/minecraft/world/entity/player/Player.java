package net.minecraft.world.entity.player;public class Player extends mod.cdv.tnpc.tactical.Fixtures70.Npc{}
