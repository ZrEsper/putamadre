package net.minecraft.core;public enum Direction{UP;public enum Axis{Y}}
