package dev.zomboid.hordes;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.storage.loot.LootTable;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
/** Metadata writes must not notify comparators or load neighbouring chunks. */
public final class RestockSafety52{
 private record Job(MinecraftServer server,Runnable task){}
 private static final ConcurrentLinkedQueue<Job>PENDING=new ConcurrentLinkedQueue<>();
 public static void enqueue(Object server,Runnable task){PENDING.add(new Job((MinecraftServer)server,task));}
 public static void drain(LevelTickEvent.Post event){if(!(event.getLevel() instanceof ServerLevel level))return;MinecraftServer server=level.getServer();if(!server.isSameThread())return;int limit=Math.min(128,PENDING.size());for(int i=0;i<limit;i++){Job job=PENDING.poll();if(job==null)break;if(job.server()!=server){PENDING.add(job);continue;}try{job.task().run();}catch(RuntimeException e){System.err.println("[Zomboid Hordes restock.52] Deferred registration failed: "+e);e.printStackTrace();}}}
 public static void clear(){PENDING.clear();}
 public static boolean current(ServerLevel level,BlockEntity block){LevelChunk chunk=level.getChunkSource().getChunkNow(block.getBlockPos().getX()>>4,block.getBlockPos().getZ()>>4);return chunk!=null&&!block.isRemoved()&&chunk.getBlockEntities().get(block.getBlockPos())==block;}
 public static boolean loaded(ServerLevel level,LevelChunk chunk){return level.getChunkSource().getChunkNow(chunk.getPos().x,chunk.getPos().z)==chunk;}
 public static void remember(RandomizableContainerBlockEntity block,ResourceKey<LootTable> table){if(table==null||!(block.getLevel() instanceof ServerLevel level))return;MinecraftServer server=level.getServer();if(!server.isSameThread()){enqueue(server,()->remember(block,table));return;}if(current(level,block))LootRestock.rememberNative51(block,table);}
 public static void mark(BlockEntity block){if(!(block.getLevel() instanceof ServerLevel level))return;MinecraftServer server=level.getServer();if(!server.isSameThread()){enqueue(server,()->mark(block));return;}LevelChunk chunk=level.getChunkSource().getChunkNow(block.getBlockPos().getX()>>4,block.getBlockPos().getZ()>>4);if(chunk!=null&&!block.isRemoved()&&chunk.getBlockEntities().get(block.getBlockPos())==block)chunk.setUnsaved(true);}
}
