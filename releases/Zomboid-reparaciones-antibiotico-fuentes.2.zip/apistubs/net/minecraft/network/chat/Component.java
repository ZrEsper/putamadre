package net.minecraft.network.chat;public interface Component{static MutableComponent translatable(String key,Object...args){return null;}}
