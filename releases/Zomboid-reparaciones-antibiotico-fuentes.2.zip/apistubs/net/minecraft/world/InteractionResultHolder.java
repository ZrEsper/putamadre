package net.minecraft.world;public class InteractionResultHolder<T>{public static <T> InteractionResultHolder<T> consume(T value){return null;}}
