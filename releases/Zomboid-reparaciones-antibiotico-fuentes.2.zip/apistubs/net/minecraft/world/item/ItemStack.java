package net.minecraft.world.item;public class ItemStack{public void shrink(int n){}}
