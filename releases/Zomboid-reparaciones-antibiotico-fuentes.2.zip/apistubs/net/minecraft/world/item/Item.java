package net.minecraft.world.item;public class Item{public static class Properties{}public interface TooltipContext{}public Item(Properties p){}}
