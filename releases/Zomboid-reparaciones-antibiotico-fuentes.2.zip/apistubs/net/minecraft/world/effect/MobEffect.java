package net.minecraft.world.effect;public class MobEffect{protected MobEffect(MobEffectCategory category,int color){}}
