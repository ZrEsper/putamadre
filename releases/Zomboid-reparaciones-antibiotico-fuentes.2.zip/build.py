from pathlib import Path
import zipfile,json,copy,shutil
p=Path('work/repair-oct14b');out=p/'release';out.mkdir(exist_ok=True);inputs=json.loads((p/'inputs.json').read_text())
names={k:Path(v).name for k,v in inputs.items()};names.update({'fa':'firstaid-1.21.1-ZOMBOID-v3.5.5-medical-infection-care.jar','clans':'factionfriction-1.8.0R-1.21.1-NEOFORGE-zomboid-clans.13-indoor-tunnel-waves.jar','tacz':'tacz-neoforge-1.21.1-1.1.8-hotfix-r7-third-person-pz.15-stance-render-fix.jar','hordes':'zomboid-hordes-1.8.3-neoforge-1.21.1-admin-panel.30-pve-antibiotic-loot.jar'})
for k,src in inputs.items():
 changes={str(f.relative_to(p/'patched'/k)):f.read_bytes() for f in (p/'patched'/k).rglob('*.class')} if (p/'patched'/k).exists() else {}
 prefix={'fa':'dev/zomboid/firstaid','clans':'dev/zomboid/clans','tacz':'dev/zomboid/tacz','hordes':'dev/zomboid/hordes'}.get(k)
 if prefix:
  for f in (p/'classes'/prefix).rglob('*.class'):changes[str(f.relative_to(p/'classes'))]=f.read_bytes()
 for f in (p/'resources'/k).rglob('*'):
  if f.is_file():changes[str(f.relative_to(p/'resources'/k))]=f.read_bytes()
 dest=out/names[k]
 if not changes:shutil.copyfile(src,dest);continue
 with zipfile.ZipFile(src) as z:
  if k=='fa':
   values={'es_es':('Antibiótico profiláctico','Trata infecciones de heridas y protege durante 5 minutos. No cura la infección zombi.','Protección contra infección de heridas'),'en_us':('Prophylactic antibiotic','Treats wound infections and protects wounds for 5 minutes. Does not cure zombie infection.','Wound infection protection'),'de_de':('Prophylaktisches Antibiotikum','Behandelt Wundinfektionen und schützt Wunden 5 Minuten lang. Heilt keine Zombieinfektion.','Schutz vor Wundinfektionen')}
   for lang,(name,desc,effect) in values.items():
    n='assets/firstaid/lang/'+lang+'.json';data=json.loads(z.read(n)) if n in z.namelist() else {};data.update({'item.firstaid.prophylactic_antibiotic':name,'item.firstaid.prophylactic_antibiotic.desc':desc,'effect.firstaid.wound_immunity':effect});changes[n]=json.dumps(data,ensure_ascii=False,indent=2).encode()
  if k=='hordes':
   n='data/zomboid_hordes/loot_table/profiles/medicinas.json';data=json.loads(z.read(n));data['pools'][0]['entries'].append({'type':'minecraft:item','name':'firstaid:prophylactic_antibiotic','weight':1});changes[n]=json.dumps(data,ensure_ascii=False,indent=2).encode()
  n='META-INF/neoforge.mods.toml'
  if n in z.namelist() and k in ['fa','clans']:
   t=z.read(n).decode().replace('v3.5.4','v3.5.5').replace('zomboid-clans.12','zomboid-clans.13');changes[n]=t.encode()
  with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as target:
   for info in z.infolist():
    if info.filename not in changes:target.writestr(copy.copy(info),z.read(info.filename))
   for n,b in changes.items():target.writestr(n,b)
  with zipfile.ZipFile(dest) as fixed:
   assert fixed.testzip() is None
   for n in z.namelist():
    if n not in changes:assert fixed.read(n)==z.read(n),n
 print(k,len(changes),'changed entries')
(p/'outputs.json').write_text(json.dumps(names,indent=2))
