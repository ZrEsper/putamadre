package dev.zomboid.hordes;
public final class WaveSpawn{public static boolean entity(Object mob){Object tag=ZoneReflection.call(mob,"getPersistentData");return !String.valueOf(ZoneReflection.call(tag,"getString","FactionPveWave")).isEmpty();}public static boolean event(Object event){return entity(ZoneReflection.call(event,"getEntity"));}}
