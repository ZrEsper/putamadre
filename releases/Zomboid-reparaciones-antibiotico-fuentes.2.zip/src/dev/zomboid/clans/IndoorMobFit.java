package dev.zomboid.clans;
public final class IndoorMobFit{public static Object adapt(Object type,Object raw){Pve.Wave w=(Pve.Wave)raw;if(w.spawnCollisions<32)return type;return R.get(R.type("net.minecraft.world.entity.EntityType"),"ZOMBIE");}}
