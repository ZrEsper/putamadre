package dev.zomboid.firstaid;import net.minecraft.world.effect.*;public final class WoundImmunity extends MobEffect{public WoundImmunity(){super(MobEffectCategory.BENEFICIAL,0x65b594);}}
