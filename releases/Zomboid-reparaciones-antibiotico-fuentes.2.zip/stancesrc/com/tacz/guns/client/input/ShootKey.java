package com.tacz.guns.client.input;import dev.zomboid.tacz.StanceTest;public class ShootKey{public static StanceTest.Key SHOOT_KEY=new StanceTest.Key("MOUSE",0);}
