package com.tacz.guns.client.input;import dev.zomboid.tacz.StanceTest;public class AimKey{public static StanceTest.Key AIM_KEY=new StanceTest.Key("MOUSE",1);}
