package dev.zomboid.tacz;public class Bridge{static final StanceTest.Client client=new StanceTest.Client();public static Object mc(){return client;}}
