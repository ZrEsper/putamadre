package dev.zomboid.hordes;public class WorldTuning{public static boolean profile;public static boolean flag(String key){return profile;}}
