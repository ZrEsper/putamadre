import java.nio.file.*;import java.util.*;import java.util.zip.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
public class Patch70 implements Opcodes{
 static String A="mod/cdv/tnpc/tactical/Authority70";static Map<String,Integer>hooks=new TreeMap<>();static void hit(String s){hooks.merge(s,1,Integer::sum);}
 static InsnList load(int...args){InsnList list=new InsnList();for(int i=0;i<args.length;i+=2)list.add(new VarInsnNode(args[i],args[i+1]));return list;}
 static void predicate(MethodNode m,InsnList ins,String name,String desc,InsnList result){ins.add(new MethodInsnNode(INVOKESTATIC,A,name,desc,false));LabelNode cont=new LabelNode();ins.add(new JumpInsnNode(IFEQ,cont));ins.add(result);ins.add(cont);ins.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(ins);hit(name+":"+m.name);}
 static InsnList ret(int value,int opcode){InsnList x=new InsnList();if(value>=0)x.add(new InsnNode(value));x.add(new InsnNode(opcode));return x;}
 public static void main(String[]a)throws Exception{Map<String,byte[]>d=new TreeMap<>();try(var z=new ZipFile(a[0])){for(var e:Collections.list(z.entries()))d.put(e.getName(),z.getInputStream(e).readAllBytes());}
 for(String path:List.of("mod/cdv/tnpc/tactical/Conversation.class","mod/cdv/tnpc/tactical/CalmBrain.class","mod/cdv/tnpc/tactical/Social.class","mod/cdv/tnpc/tactical/Threat27.class","mod/cdv/tnpc/entity/AutoGunOperator.class")){
 ClassNode c=new ClassNode();new ClassReader(d.get(path)).accept(c,0);List<MethodNode>added=new ArrayList<>();
 for(var m:c.methods){
 if(c.name.endsWith("Conversation")){
  if(m.name.equals("interact")){InsnList result=new InsnList();result.add(new FieldInsnNode(GETSTATIC,"net/minecraft/world/InteractionResult","SUCCESS","Lnet/minecraft/world/InteractionResult;"));result.add(new InsnNode(ARETURN));predicate(m,load(ALOAD,0,ALOAD,1),"reject","(Ljava/lang/Object;Ljava/lang/Object;)Z",result);}
  if(m.name.equals("send")){InsnList x=load(ALOAD,0,ALOAD,1);x.add(new MethodInsnNode(INVOKESTATIC,A,"sent","(Ljava/lang/Object;Ljava/lang/Object;)V",false));m.instructions.insert(x);hit("sent");}
  if(m.name.equals("action"))predicate(m,load(ALOAD,0,ALOAD,1),"denyReply","(Ljava/lang/Object;Ljava/lang/String;)Z",ret(ICONST_0,IRETURN));
  if(m.name.equals("busy")||m.name.equals("focus")){String name=m.name;m.name=name.equals("busy")?"nativeBusy70":"nativeFocus70";MethodNode proxy=new MethodNode(m.access,name,m.desc,null,m.exceptions.toArray(String[]::new));proxy.instructions.add(name.equals("busy")?load(ALOAD,0):load(ALOAD,0,ALOAD,1,LLOAD,2));proxy.instructions.add(new MethodInsnNode(INVOKESTATIC,A,name,m.desc,false));proxy.instructions.add(new InsnNode(IRETURN));added.add(proxy);hit(name);}
 }
 if(c.name.endsWith("CalmBrain")&&m.name.equals("control")){for(var i:m.instructions.toArray())if(i instanceof LdcInsnNode v&&Long.valueOf(2).equals(v.cst)&&i.getNext()!=null&&i.getNext().getOpcode()==LADD&&i.getNext().getNext() instanceof FieldInsnNode f&&f.name.equals("nextDecision")){InsnList x=load(ALOAD,0);x.add(new MethodInsnNode(INVOKESTATIC,A,"interval","(Ljava/lang/Object;)J",false));m.instructions.insertBefore(i,x);m.instructions.remove(i);hit("acquireInterval");}}
 if(c.name.endsWith("CalmBrain")&&m.name.equals("tick")){InsnList x=load(ALOAD,0);x.add(new MethodInsnNode(INVOKESTATIC,A,"tick","(Ljava/lang/Object;)V",false));m.instructions.insert(x);hit("tick");}
 if(c.name.endsWith("Social")&&m.name.equals("pause"))predicate(m,load(ALOAD,0),"pause","(Ljava/lang/Object;)Z",ret(ICONST_1,IRETURN));
 if(c.name.endsWith("Social")&&m.name.equals("allowedPlayer")||c.name.endsWith("Threat27")&&m.name.equals("allowed"))predicate(m,load(ALOAD,0),"pause","(Ljava/lang/Object;)Z",ret(ICONST_0,IRETURN));
 if(c.name.endsWith("Threat27")&&m.name.equals("hit")){InsnList x=load(ALOAD,0,ALOAD,1,FLOAD,2,ILOAD,3);x.add(new MethodInsnNode(INVOKESTATIC,A,"hit","(Ljava/lang/Object;Ljava/lang/Object;FZ)V",false));m.instructions.insert(x);hit("hit");}
 if(c.name.endsWith("Threat27")&&m.name.equals("heard")){InsnList x=load(ALOAD,0,ALOAD,1,LLOAD,2);x.add(new MethodInsnNode(INVOKESTATIC,A,"heard","(Ljava/lang/Object;Ljava/lang/Object;J)V",false));m.instructions.insert(x);hit("heard");}
 if(c.name.endsWith("AutoGunOperator")&&m.name.equals("shoot")){InsnList result=new InsnList();result.add(new FieldInsnNode(GETSTATIC,"com/tacz/guns/api/entity/ShootResult","COOL_DOWN","Lcom/tacz/guns/api/entity/ShootResult;"));result.add(new InsnNode(ARETURN));predicate(m,load(ALOAD,0),"pause","(Ljava/lang/Object;)Z",result);}
 if(c.name.endsWith("AutoGunOperator")&&m.name.equals("doHurtTarget"))predicate(m,load(ALOAD,0),"pause","(Ljava/lang/Object;)Z",ret(ICONST_0,IRETURN));
 if(c.name.endsWith("AutoGunOperator")&&m.name.equals("melee"))predicate(m,load(ALOAD,0),"pause","(Ljava/lang/Object;)Z",ret(-1,RETURN));
 }
 if(c.name.endsWith("AutoGunOperator")&&!c.methods.stream().anyMatch(m->m.name.equals("doHurtTarget"))){MethodNode m=new MethodNode(ACC_PUBLIC,"doHurtTarget","(Lnet/minecraft/world/entity/Entity;)Z",null,null);m.instructions.add(load(ALOAD,0,ALOAD,1));m.instructions.add(new MethodInsnNode(INVOKESPECIAL,c.superName,"doHurtTarget",m.desc,false));m.instructions.add(new InsnNode(IRETURN));predicate(m,load(ALOAD,0),"pause","(Ljava/lang/Object;)Z",ret(ICONST_0,IRETURN));added.add(m);}
 c.methods.addAll(added);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);d.put(path,w.toByteArray());}
 if(hooks.values().stream().mapToInt(i->i).sum()!=16)throw new Error("hooks "+hooks);
 try(var files=Files.walk(Path.of(a[1]))){for(var p:files.filter(p->p.toString().endsWith(".class")).toList())d.put(Path.of(a[1]).relativize(p).toString(),Files.readAllBytes(p));}
 String key="META-INF/neoforge.mods.toml";String toml=new String(d.get(key),java.nio.charset.StandardCharsets.UTF_8);System.out.println(toml.substring(0,Math.min(350,toml.length())));toml=toml.replaceAll("(?m)^version\\s*=\\s*\"[^\"]+\"","version=\"2.1.0-tactical.34-decision-authority\"");d.put(key,toml.getBytes(java.nio.charset.StandardCharsets.UTF_8));
 int n=0;for(var e:d.entrySet())if(e.getKey().endsWith(".class")){ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);for(var m:c.methods)if((m.access&(ACC_NATIVE|ACC_ABSTRACT))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);n++;}try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(a[2])))){for(var e:d.entrySet()){z.putNextEntry(new ZipEntry(e.getKey()));z.write(e.getValue());z.closeEntry();}}System.out.println("VERIFIED_CLASSES="+n+" HOOKS="+hooks);
 }
}
