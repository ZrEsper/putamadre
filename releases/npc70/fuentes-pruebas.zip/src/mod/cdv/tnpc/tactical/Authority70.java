package mod.cdv.tnpc.tactical;
import java.util.*;import java.lang.ref.WeakReference;import java.nio.file.*;import java.io.*;
public final class Authority70 {
 static final Map<Object,State> STATES=new WeakHashMap<>();static final Set<Object> FAILED=Collections.newSetFromMap(new WeakHashMap<>());
 static final Properties CONFIG=load();static final boolean ENABLED=Boolean.parseBoolean(CONFIG.getProperty("enabled","true"));
 static int setting(String k,int fallback,int min,int max){try{return Math.max(min,Math.min(max,Integer.parseInt(CONFIG.getProperty(k,""+fallback))));}catch(Exception e){return fallback;}}
 static final int RANGE=setting("dialogueRange",25,4,48),SILENCE=setting("silenceTicks",240,100,600),INTERVAL=setting("decisionIntervalTicks",6,5,10),RETRY=setting("brokenRetryTicks",600,40,2400);
 static Properties load(){Properties p=new Properties();p.setProperty("enabled","true");p.setProperty("dialogueRange","25");p.setProperty("silenceTicks","240");p.setProperty("decisionIntervalTicks","6");p.setProperty("brokenRetryTicks","600");p.setProperty("hysteresisMargin","20");p.setProperty("minimumModeTicks","20");try{Path path=Path.of("config/tacznpcs-decision-phase1.properties");if(Files.exists(path)){try(var in=Files.newInputStream(path)){p.load(in);}}else{Files.createDirectories(path.getParent());try(var out=Files.newOutputStream(path)){p.store(out,"NPC phase 1: existing TaCZ executors and conversation arbitration. Restart to reload.");}}}catch(IOException e){System.err.println("[TacZ NPC phase1] Config unavailable; using defaults.");}return p;}
 static Object c(Object o,String name,Object...a){return Social.c(o,name,a);}
 static State state(Object npc){return STATES.computeIfAbsent(npc,n->new State());}
 static boolean enabled(Object npc){return ENABLED&&!FAILED.contains(npc)&&!Social.yes(c(Social.tag(npc),"getBoolean","npc70_disabled"));}
 static void fail(Object npc,Exception e){FAILED.add(npc);try{c(Social.tag(npc),"putBoolean","npc70_disabled",true);end(npc,false,null);}catch(Exception ignored){}Social.warn("phase1 arbitration disabled for NPC",e);}
 static void tell(Object player,String line){c(player,"displayClientMessage",c(Social.t("net.minecraft.network.chat.Component"),"literal",line),false);}
 static boolean danger(Object npc,Object player){Object target=CalmBrain.state(npc).target;return target!=null&&target!=player&&Social.alive(target)||Social.mem(npc).threats>0;}
 public static boolean reject(Object npc,Object player){try{if(Social.client(npc)||!Social.actor(npc)||!enabled(npc)||Downed20.down(npc))return false;
  long now=Social.time(npc);State s=state(npc);boolean samePartner=s.player.get()==player;
  if((s.player.get()!=null&&!samePartner)||now<Social.l(Social.tag(npc),"npc70_retry_"+Social.identity(player))||Social.armed(player)||Social.yes(c(player,"isSprinting"))||danger(npc,player)||Threat27.recent(npc,player,now)){
   if(now>=s.nextWarning){tell(player,"[???] Guarda el arma y aléjate del peligro antes de intentar negociar.");s.nextWarning=now+40;}return true;
  }return false;
 }catch(Exception e){fail(npc,e);return false;}}
 public static void sent(Object npc,Object player){try{if(Social.client(npc)||!enabled(npc)||Downed20.down(npc))return;State s=state(npc);long now=Social.time(npc);if(s.player.get()!=player){s.player=new WeakReference<>(player);s.started=now;}s.until=now+SILENCE;s.holdAt=Long.MIN_VALUE;busy(npc);}catch(Exception e){fail(npc,e);}}
 static void end(Object npc,boolean broken,String message){State s=state(npc);Object p=s.player.get();
  Conversation.SESSIONS.entrySet().removeIf(e->e.getValue().npc==npc);s.player=new WeakReference<>(null);s.until=0;s.mode=DecisionRules70.Mode.ROUTINE;Social.mem(npc).occupied=false;
  if(p!=null){if(broken){c(Social.tag(npc),"putLong","npc70_retry_"+Social.identity(p),Social.time(npc)+RETRY);Social.trust(npc,p,-5);}if(message!=null)tell(p,message);}
 }
 public static boolean busy(Object npc){try{
  if(Social.client(npc)||Downed20.down(npc))return false;if(!enabled(npc))return Social.yes(c(Conversation.class,"nativeBusy70",npc));
  State s=state(npc);Object player=s.player.get();if(player==null)return false;Conversation.Session session=Conversation.SESSIONS.get(player);if(session==null||session.npc!=npc){s.player=new WeakReference<>(null);Social.mem(npc).occupied=false;return false;}
  long now=Social.time(npc);boolean valid=DecisionRules70.valid(Social.alive(npc),Social.alive(player),Social.world(npc)==Social.world(player),Social.armed(player),Social.yes(c(player,"isSprinting")),danger(npc,player),Social.distance(npc,player),RANGE,now,Math.min(s.until,session.until));
  if(!valid){end(npc,Social.alive(player)&&(Social.armed(player)||Social.yes(c(player,"isSprinting"))),"[???] La conversación ha terminado.");return false;}
  s.mode=DecisionRules70.Mode.NEGOTIATE;
  if(now>=s.holdAt+INTERVAL||s.holdAt==Long.MIN_VALUE){s.holdAt=now;Social.target(npc,null);Social.mem(npc).occupied=true;c(c(npc,"getNavigation"),"stop");c(c(npc,"getLookControl"),"setLookAt",player,30f,30f);}
  return true;
 }catch(Exception e){fail(npc,e);return false;}}
 public static boolean focus(Object npc,Social.Memory memory,long now){try{if(!enabled(npc))return Social.yes(c(Conversation.class,"nativeFocus70",npc,memory,now));return busy(npc);}catch(Exception e){fail(npc,e);return false;}}
 public static boolean denyReply(Object player,String op){Conversation.Session session=Conversation.SESSIONS.get(player);if(session==null)return false;Object npc=session.npc;
  try{if(!enabled(npc)||Downed20.down(npc))return false;if(op.equals("close")){end(npc,false,null);return true;}if(!busy(npc))return true;state(npc).until=Social.time(npc)+SILENCE;return false;}catch(Exception e){fail(npc,e);return false;}}
 public static void tick(Object npc){try{if(Social.client(npc)||!enabled(npc)||!Social.actor(npc))return;State s=state(npc);long now=Social.time(npc);boolean talk=busy(npc);if(now<s.nextDecision)return;s.nextDecision=now+INTERVAL;
  Social.Memory memory=Social.mem(npc);double max=Social.num(c(npc,"getMaxHealth"));double hp=max>0?Math.max(0,Math.min(1,Social.num(c(npc,"getHealth"))/max)):0;
  var input=new DecisionRules70.Input(Downed20.down(npc),talk,CalmBrain.state(npc).target!=null,memory.fear!=null&&memory.fearUntil>now,memory.medicalUntil>now,hp);
  var selected=DecisionRules70.choose(input,s.mode,now-s.switchedAt,setting("hysteresisMargin",20,0,200),setting("minimumModeTicks",20,0,100));if(selected!=s.mode){s.mode=selected;s.switchedAt=now;}
 }catch(Exception e){fail(npc,e);}}
 public static long interval(Object npc){try{return enabled(npc)?INTERVAL:2L;}catch(Exception e){return 2L;}}
 public static boolean pause(Object npc){try{return enabled(npc)&&busy(npc);}catch(Exception e){fail(npc,e);return false;}}
 public static void hit(Object npc,Object source,float damage,boolean applied){if(!applied||damage<=0)return;try{if(enabled(npc)&&state(npc).player.get()!=null)end(npc,true,"[???] ¡Se acabó! Nos están atacando.");}catch(Exception e){fail(npc,e);}}
 public static void heard(Object npc,Object shooter,long now){try{if(enabled(npc)&&state(npc).player.get()==shooter)end(npc,true,"[???] ¡Has disparado! Se acabó la negociación.");}catch(Exception e){fail(npc,e);}}
 static final class State {WeakReference<Object> player=new WeakReference<>(null);long until,started,nextDecision,switchedAt,nextWarning,holdAt=Long.MIN_VALUE;DecisionRules70.Mode mode=DecisionRules70.Mode.ROUTINE;}
}
