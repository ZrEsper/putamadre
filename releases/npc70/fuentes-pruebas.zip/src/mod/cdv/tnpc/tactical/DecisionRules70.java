package mod.cdv.tnpc.tactical;
/** Narrow arbitration over existing executors, not another goal selector. */
public final class DecisionRules70 {
 public enum Mode {ROUTINE,COMBAT,RECOVER,FLEE,NEGOTIATE,DOWNED}
 public record Input(boolean down,boolean conversation,boolean target,boolean fear,boolean medical,double health){}
 public static int score(Mode m,Input i){return switch(m){case DOWNED->i.down?10000:-1;case NEGOTIATE->i.conversation?9000:-1;case FLEE->i.fear?650+(int)((1-i.health)*100):-1;case RECOVER->i.medical?700:-1;case COMBAT->i.target?500:-1;case ROUTINE->100;};}
 public static Mode choose(Input i,Mode old,long heldTicks,int margin,int hold){Mode best=Mode.ROUTINE;for(Mode m:Mode.values())if(score(m,i)>score(best,i))best=m;if(best==Mode.DOWNED||best==Mode.NEGOTIATE||old==Mode.DOWNED||old==Mode.NEGOTIATE)return best;if(score(old,i)<0)return best;if(best!=old&&(heldTicks<hold||score(best,i)<score(old,i)+margin))return old;return best;}
 public static boolean valid(boolean npcAlive,boolean playerAlive,boolean sameWorld,boolean armed,boolean sprinting,boolean danger,double distance2,double range,long now,long until){return npcAlive&&playerAlive&&sameWorld&&!armed&&!sprinting&&!danger&&Double.isFinite(distance2)&&distance2<=range*range&&now<until;}
}
