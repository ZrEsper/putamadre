package mod.cdv.tnpc.tactical;public class CalmBrain{static State state(Object n){return ((Fixtures70.Npc)n).state;}static class State{Object target;}}
