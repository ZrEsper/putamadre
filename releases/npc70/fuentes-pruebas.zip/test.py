from pathlib import Path
import subprocess
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree'])+':/workspace/medical65/asm-commons.jar';ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];jar=r/'release/tacznpcs-2.1.0-1.21.1-tactical.34-decision-authority.jar'
subprocess.run(ecj+['-cp',str(jar),'-d',str(r/'tests')]+list(map(str,(r/'testsrc').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools'),str(r/'Extract70.java')],check=True)
subprocess.run(['java','-cp',str(r/'tools')+':'+asm,'Extract70',str(jar),str(r/'tests')],check=True)
(r/'test-run').mkdir(exist_ok=True)
subprocess.run(['java','-Xverify:all','-cp',str(r/'tests')+':'+str(jar),'mod.cdv.tnpc.tactical.Fixtures70'],check=True,cwd=r/'test-run')
