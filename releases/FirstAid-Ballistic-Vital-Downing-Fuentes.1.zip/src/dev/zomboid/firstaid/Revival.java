/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.firstaid;

import dev.zomboid.firstaid.Assist;
import dev.zomboid.firstaid.R;
import dev.zomboid.firstaid.ZeroParts;
import java.util.Locale;

public final class Revival {
    static float raw(Object object) {
        return ZeroParts.rawHealth(object, null);
    }

    public static boolean active(Object object) {
        return R.yes(R.get(object, "criticalConditionActive"));
    }

    public static boolean bypass(Object object) {
        if (object == null) {
            return false;
        }
        try {
            Class<?> clazz = R.type("net.minecraft.world.damagesource.DamageTypes");
            return R.yes(R.call(object, "is", R.get(clazz, "GENERIC_KILL"))) || R.yes(R.call(object, "is", R.get(clazz, "FELL_OUT_OF_WORLD")));
        }
        catch (Exception exception) {
            return false;
        }
    }

    public static boolean preventDeath(Object object, Object object2, Object object3) {
        if (Revival.bypass(object3)) {
            return false;
        }
        if (!BallisticHealth.fatal(object)) {
            return true;
        }
        Revival.post(object, object2, object3);
        return Revival.active(object);
    }

    public static void bodyFatal(Object object, Object object2) {
        Object object3 = Assist.model(object);
        if (object3 != null && !Revival.preventDeath(object3, object, object2)) {
            R.call(R.type("ichttt.mods.firstaid.common.util.CommonUtils"), "killPlayerDirectly", object, object2);
        }
    }

    public static void post(Object object, Object object2, Object object3) {
        if (R.yes(R.call(R.call(object2, "level", new Object[0]), "isClientSide", new Object[0])) || Revival.active(object) || !BallisticHealth.fatal(object) || !R.yes(R.call(object2, "isAlive", new Object[0])) || Revival.bypass(object3)) {
            return;
        }
        R.set(object, "criticalConditionActive", true);
        Object object4 = R.call(object2, "getPersistentData", new Object[0]);
        R.call(object4, "putInt", "FAFinishHits", 0);
        R.call(object4, "putLong", "FADownDeadline", Assist.time(object2) + 2000L);
        R.call(object, "setUnconsciousState", 2000, false, true, "firstaid.gui.downed_assist");
        R.call(object, "scheduleResync", new Object[0]);
    }

    public static int nativeCountdown(int n, Object object) {
        return Revival.active(object) ? ((Number)R.call(object, "getUnconsciousTicks", new Object[0])).intValue() : n;
    }

    public static void clock(Object object, Object object2) {
        Object object3 = R.call(object2, "getPersistentData", new Object[0]);
        if (!Revival.active(object)) {
            R.call(object3, "putLong", "FADownDeadline", 0L);
            return;
        }
        long l = Assist.time(object2);
        long l2 = ((Number)R.call(object3, "getLong", "FADownDeadline")).longValue();
        if (l2 == 0L) {
            l2 = l + (long)Math.max(0, Math.min(2000, ((Number)R.call(object, "getUnconsciousTicks", new Object[0])).intValue()));
            R.call(object3, "putLong", "FADownDeadline", l2);
        }
        int n = (int)Math.max(0L, Math.min(2000L, l2 - l));
        R.set(object, "unconsciousTicks", n);
        if (n == 0) {
            R.set(object, "criticalConditionActive", false);
            R.call(object, "clearUnconsciousState", new Object[0]);
            R.call(object, "clearUnconsciousPenalties", object2);
            R.call(object3, "putLong", "FADownDeadline", 0L);
            R.call(R.type("ichttt.mods.firstaid.common.util.CommonUtils"), "killPlayerDirectly", object2, null);
            return;
        }
        if (l % 20L == 0L) {
            R.call(R.type("ichttt.mods.firstaid.common.util.CommonUtils"), "syncDamageModel", object2);
        }
    }

    public static Object countdown(Object object, float f) {
        int n = ((Number)R.call(object, "getUnconsciousTicks", new Object[0])).intValue();
        String string = Revival.active(object) ? "firstaid.gui.assist_time_left" : "firstaid.gui.unconscious_left";
        String string2 = String.format(Locale.ROOT, "%02d:%02d", Math.max(0, (n + 19) / 20) / 60, Math.max(0, (n + 19) / 20) % 60);
        return R.call(R.type("net.minecraft.network.chat.Component"), "translatable", string, new Object[]{string2});
    }

    public static void tick(Object object, Object object2) {
        Assist.hearts(object2);
        if (!Revival.active(object) && BallisticHealth.fatal(object)) {
            Revival.post(object, object2, null);
        }
    }
}

