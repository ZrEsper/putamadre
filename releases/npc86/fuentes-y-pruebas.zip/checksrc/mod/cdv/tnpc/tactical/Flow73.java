package mod.cdv.tnpc.tactical;public class Flow73{static int messages;static Object lastSpeaker;static void emit(Object n,Object p,String line,String tone){messages++;lastSpeaker=n;}}
