package dev.zomboid.firstaid;
public final class UnconsciousClient{
 static Object lastPlayer;static boolean wasDown;
 public static void tick(){Object mc=Cinematic63.mc(),p=R.get(mc,"player"),level=R.get(mc,"level"),screen=R.get(mc,"screen");if(p==null||level==null){wasDown=false;lastPlayer=null;Cinematic63.disconnected();if(screen instanceof UnconsciousScreen||screen instanceof FinalScreen63)R.call(mc,"setScreen",new Object[]{null});return;}
 Cinematic63.observe();boolean down=DownedSupport.down(p),alive=Boolean.TRUE.equals(R.call(p,"isAlive"));boolean newly=down&&(!wasDown||lastPlayer!=p);wasDown=down;lastPlayer=p;
 if(down){Cinematic63.enter();if(newly||screen==null)R.call(mc,"setScreen",new UnconsciousScreen());}
 else if(!alive){Cinematic63.enter();if(!Cinematic63.requestedRespawn&&(screen==null||screen.getClass().getName().equals("net.minecraft.client.gui.screens.DeathScreen")||screen instanceof UnconsciousScreen))R.call(mc,"setScreen",new FinalScreen63());}
 else if(Cinematic63.ending(screen)){Cinematic63.enter();}
 else {Cinematic63.release();Cinematic63.requestedRespawn=false;if(screen instanceof UnconsciousScreen||screen instanceof FinalScreen63)R.call(mc,"setScreen",new Object[]{null});}
 }
}
