package dev.zomboid.firstaid;
import net.minecraft.client.gui.screens.Screen;import net.minecraft.client.gui.GuiGraphics;import net.minecraft.network.chat.Component;
public final class UnconsciousScreen extends Screen{
 boolean requested,surrendered;int requestTicks,focus=-1,shown=-1;Cinematic63.Layout area;
 public UnconsciousScreen(){super(Component.literal("Derribado"));}
 Object player(){return R.get(Cinematic63.mc(),"player");}String[] buttons(){return Cinematic63.usable(player())?new String[]{requested?"Reanimando…":"Usar desfibrilador","Rendirse"}:new String[]{"Rendirse"};}
 protected void init(){Cinematic63.enter();}
 public void tick(){UnconsciousClient.tick();if(requested&&++requestTicks>=200){requested=false;requestTicks=0;}}
 void choose(int i){if(surrendered)return;String[] choices=buttons();if(i<0||i>=choices.length)return;if(choices.length==2&&i==0){if(requested||!Cinematic63.usable(player()))return;requested=true;requestTicks=0;Cinematic63.send("ATTEMPT_SELF_DEFIB");}else{if(requested)return;surrendered=true;Cinematic63.send("GIVE_UP");}}
 public void render(GuiGraphics g,int x,int y,float f){Cinematic63.enter();String[]b=buttons();if(shown!=b.length||focus>=b.length)focus=-1;shown=b.length;area=Cinematic63.draw(g,font,width,height,x,y,false,requested,b,focus,Cinematic63.lifeTicks,Cinematic63.kills,DownedSupport.seconds(player()));}
 public boolean mouseClicked(double x,double y,int button){if(button==0&&area!=null&&shown==buttons().length)for(int i=0;i<buttons().length;i++)if(area.hit(x,y,i)){choose(i);return true;}return false;}
 public boolean keyPressed(int key,int scan,int mods){if(key==258||key==264||key==265){focus=(focus+1)%buttons().length;return true;}if((key==257||key==32)&&focus>=0){choose(focus);return true;}if(key==256){R.call(Cinematic63.mc(),"setScreen",R.make("net.minecraft.client.gui.screens.PauseScreen",true));return true;}return false;}
 public void renderBackground(GuiGraphics g,int x,int y,float f){}protected void renderBlurredBackground(float f){}public boolean isPauseScreen(){return false;}public boolean shouldCloseOnEsc(){return false;}
}
