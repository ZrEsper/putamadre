package dev.zomboid.firstaid;
import java.util.*;
/** Client-only controller, referenced reflectively by the two optional integrations. */
public final class Cinematic63{
 public static boolean forced,recovered,requestedRespawn,skipPostDeath;static Object world,config;static boolean oldOrtho,oldXIV,oldHud;static float oldZoom;public static long lifeTicks=-1;public static int kills=-1;static String playerId="";
 static void field(Object target,String name,Object value){if(!(target instanceof Class<?> type)){R.set(target,name,value);return;}try{var f=type.getDeclaredField(name);f.setAccessible(true);f.set(null,value);}catch(ReflectiveOperationException e){throw new IllegalStateException(name,e);}}
 public static boolean consumePostDeath(){boolean result=skipPostDeath;skipPostDeath=false;return result;}
 public static Object mc(){return R.call(R.type("net.minecraft.client.Minecraft"),"getInstance");}
 static boolean yes(Object v){return Boolean.TRUE.equals(v);}static int num(Object v){return ((Number)v).intValue();}
 public static boolean ending(Object screen){return screen!=null&&screen.getClass().getName().equals("dev.survivorcreator.client.EndingScreen")&&yes(R.call(screen,"survivorcreator$isDeath"));}
 public static void observe(){Object w=R.get(mc(),"level");if(world!=w){release();world=w;lifeTicks=-1;kills=-1;playerId="";requestedRespawn=false;skipPostDeath=false;recovered=false;}}
 public static void live(String id,long ticks,int zombies){observe();Object p=R.get(mc(),"player");if(p!=null&&String.valueOf(R.call(p,"getUUID")).equals(id)){playerId=id;lifeTicks=Math.max(0,ticks);kills=Math.max(0,zombies);}}
 public static void enter(){Object m=mc(),w=R.get(m,"level");if(w==null)return;if(world!=w){if(forced)release();world=w;lifeTicks=-1;kills=-1;playerId="";}Object options=R.get(m,"options");if(!forced){oldHud=yes(R.get(options,"hideGui"));try{Class<?> mod=R.type("com.cleannrooster.dungeons_iso.mod.Mod");oldZoom=((Number)R.get(mod,"zoom")).floatValue();config=R.call(R.get(R.type("com.cleannrooster.dungeons_iso.config.Config"),"GSON"),"instance");oldOrtho=yes(R.get(config,"ortho"));oldXIV=yes(R.get(config,"XIV"));field(config,"ortho",true);field(config,"XIV",false);field(mod,"zoom",3f);field(mod,"yaw",135f);field(mod,"pitch",45f);}catch(IllegalStateException e){config=null;}forced=true;recovered=false;R.call(R.get(m,"levelRenderer"),"allChanged");}
 field(options,"hideGui",true);R.call(options,"setCameraType",R.get(R.type("net.minecraft.client.CameraType"),"THIRD_PERSON_BACK"));try{field(R.type("com.cleannrooster.dungeons_iso.mod.Mod"),"enabled",true);}catch(IllegalStateException e){} }
 public static void release(){if(!forced)return;forced=false;recovered=true;Object m=mc(),options=R.get(m,"options");field(options,"hideGui",oldHud);try{Class<?> mod=R.type("com.cleannrooster.dungeons_iso.mod.Mod");field(mod,"enabled",false);field(mod,"zoom",oldZoom);field(mod,"lastPerspective",R.get(R.type("net.minecraft.client.CameraType"),"FIRST_PERSON"));if(config!=null){field(config,"ortho",oldOrtho);field(config,"XIV",oldXIV);}}catch(IllegalStateException e){}R.call(options,"setCameraType",R.get(R.type("net.minecraft.client.CameraType"),"FIRST_PERSON"));if(R.get(m,"level")!=null)R.call(R.get(m,"levelRenderer"),"allChanged");}
 public static void disconnected(){release();world=null;requestedRespawn=false;skipPostDeath=false;recovered=false;lifeTicks=-1;kills=-1;}
 public static boolean usable(Object p){if(!DownedSupport.canSelf(p))return false;Object s=DownedSupport.defib(p);return s!=null&&!yes(R.call(s,"isEmpty"))&&DefibUses.remaining(num(R.call(s,"getDamageValue")))>0;}
 public static void send(String action){Object request=R.make("ichttt.mods.firstaid.common.network.MessageClientRequest",R.get(R.type("ichttt.mods.firstaid.common.network.MessageClientRequest$RequestType"),action));R.call(R.get(R.type("ichttt.mods.firstaid.FirstAid"),"NETWORKING"),"sendToServer",request);}
 public static String duration(long ticks){if(ticks<0)return "Sincronizando…";long s=ticks/20;return(s>=86400?s/86400+" d · ":"")+String.format(Locale.ROOT,"%02d:%02d:%02d",s/3600%24,s/60%60,s%60);}
 public record Layout(int left,int top,int width,int buttonY,int buttonHeight,int gap){public boolean hit(double x,double y,int i){return x>=left+16&&x<left+width-16&&y>=buttonY+i*(buttonHeight+gap)&&y<buttonY+i*(buttonHeight+gap)+buttonHeight;}}
 public static Layout layout(int w,int h,int buttons){int width=Math.min(292,Math.max(160,w-32));int bh=h<230?21:25;int base=h<230?65:85;int top=Math.max(48,h-(base+buttons*(bh+6)+12)-12);return new Layout((w-width)/2,top,width,top+base,bh,6);}
 static void fill(Object g,int x,int y,int w,int h,int color){R.call(g,"fill",x,y,x+w,y+h,color);}
 static void text(Object g,Object font,String s,int x,int y,int color){R.call(g,"drawString",font,s,x,y,color,false);}
 static void center(Object g,Object font,String s,int x,int y,int color){text(g,font,s,x-num(R.call(font,"width",s))/2,y,color);}
 public static Layout draw(Object g,Object font,int w,int h,int mx,int my,boolean dead,boolean busy,String[]buttons,int focus,long ticks,int zombies,int seconds){
 Layout a=layout(w,h,buttons.length);int cx=w/2;int panelHeight=(a.buttonY-a.top)+buttons.length*(a.buttonHeight+a.gap)+12;
 // Keep the scene visible; darken only the margins and the compact lower card.
 R.call(g,"fillGradient",0,0,w,62,0x80000000,0x00000000);R.call(g,"fillGradient",0,Math.max(0,h-105),w,h,0x00000000,0x90000000);
 center(g,font,dead?"HAS MUERTO":busy?"REANIMANDO":"DERRIBADO",cx,Math.max(22,h/8),dead?0xFFD18B80:0xFFE5E0D4);
 center(g,font,dead?"TU HISTORIA TERMINA AQUÍ":busy?"El desfibrilador está en marcha":("Puedes recibir ayuda · "+seconds+" s"),cx,Math.max(22,h/8)+16,0xFFA9A99D);
 fill(g,a.left,a.top,a.width,panelHeight,0xD9161916);fill(g,a.left,a.top,2,panelHeight,dead?0xFF9E554D:0xFF8E9D7B);fill(g,a.left+2,a.top,a.width-2,1,0xFF42463C);
 text(g,font,"TIEMPO SOBREVIVIDO",a.left+16,a.top+14,0xFF999E8D);text(g,font,duration(ticks),a.left+16,a.top+29,0xFFF1EEE1);text(g,font,"ZOMBIS ABATIDOS",a.left+16,a.top+49,0xFF999E8D);text(g,font,zombies<0?"—":Integer.toString(zombies),a.left+a.width-34,a.top+49,0xFFE3E9D6);
 for(int i=0;i<buttons.length;i++){boolean hover=a.hit(mx,my,i)||focus==i;int y=a.buttonY+i*(a.buttonHeight+a.gap);fill(g,a.left+16,y,a.width-32,a.buttonHeight,hover?0xFF424B3A:0xE5242922);fill(g,a.left+16,y,a.width-32,1,hover?0xFFADB89A:0xFF555D4C);center(g,font,buttons[i],cx,y+(a.buttonHeight-8)/2,busy?0xFF8C9281:0xFFE8E8DA);}
 return a;
 }
}
