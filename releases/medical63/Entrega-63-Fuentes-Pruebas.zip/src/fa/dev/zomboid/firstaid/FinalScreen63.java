package dev.zomboid.firstaid;
import net.minecraft.client.gui.screens.Screen;import net.minecraft.client.gui.GuiGraphics;import net.minecraft.network.chat.Component;
public final class FinalScreen63 extends Screen{
 Cinematic63.Layout area;boolean sent;int focus=-1;
 public FinalScreen63(){super(Component.literal("Has muerto"));}protected void init(){Cinematic63.enter();}public void tick(){UnconsciousClient.tick();}
 void next(){if(sent)return;sent=true;Cinematic63.requestedRespawn=true;Cinematic63.skipPostDeath=true;Object m=Cinematic63.mc();R.call(m,"setScreen",new Object[]{null});R.call(R.get(m,"player"),"respawn");}
 public void render(GuiGraphics g,int x,int y,float f){Cinematic63.enter();area=Cinematic63.draw(g,font,width,height,x,y,true,false,new String[]{"Nuevo superviviente"},focus,Cinematic63.lifeTicks,Cinematic63.kills,0);}
 public boolean mouseClicked(double x,double y,int b){if(b==0&&area!=null&&area.hit(x,y,0)){next();return true;}return false;}public boolean keyPressed(int k,int s,int m){if(k==258){focus=0;return true;}if(focus==0&&(k==257||k==32)){next();return true;}return false;}public void renderBackground(GuiGraphics g,int x,int y,float f){}protected void renderBlurredBackground(float f){}public boolean isPauseScreen(){return false;}public boolean shouldCloseOnEsc(){return false;}
}
