package dev.zomboid.isotacz;
/** Prevent gameplay toggles from overriding the incapacitated camera. */
public final class DownedView63{
 public static boolean recovering(){try{return Boolean.TRUE.equals(R.get(R.type("dev.zomboid.firstaid.Cinematic63"),"recovered"));}catch(IllegalStateException absent){return false;}}
 public static boolean active(){try{Class<?> view=R.type("dev.zomboid.firstaid.Cinematic63");if(Boolean.TRUE.equals(R.get(view,"forced")))return true;if(!Boolean.TRUE.equals(R.get(view,"recovered")))return false;if(Boolean.TRUE.equals(R.call(R.get(R.type("com.cleannrooster.dungeons_iso.ClientInit"),"toggleBinding"),"isDown"))){try{view.getField("recovered").setBoolean(null,false);}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}return false;}return true;}catch(IllegalStateException absent){return false;}}
}
