package dev.zomboid.survival;
import dev.zomboid.autopsy.R;
/** Adds small per-life counters to the existing server-to-client snapshot. No new channel. */
public final class LiveStats63{
 public static void enrich(Object json,Object source){Object p=source;try{p=R.call(source,"getEntity");}catch(IllegalStateException notEvent){}Object tag=R.call(p,"getPersistentData");R.call(json,"addProperty","life63",R.call(tag,"getLong","survivorcreator_life16"));R.call(json,"addProperty","zombies63",R.call(tag,"getInt","survivorcreator_life_zombies24"));}
 public static void accept(String data){try{Object json=R.call(R.type("com.google.gson.JsonParser"),"parseString",data);json=R.call(json,"getAsJsonObject");if(!R.yes(R.call(json,"has","life63")))return;String player=R.call(R.call(json,"get","player"),"getAsString").toString();long ticks=((Number)R.call(R.call(json,"get","life63"),"getAsLong")).longValue();int kills=((Number)R.call(R.call(json,"get","zombies63"),"getAsInt")).intValue();R.call(R.type("dev.zomboid.firstaid.Cinematic63"),"live",player,ticks,kills);}catch(IllegalStateException optionalFirstAidAbsent){} }
}
