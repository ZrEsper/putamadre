from pathlib import Path
import subprocess,json,os
r=Path(__file__).parent;t=Path(os.environ.get('PATCH_TOOLS','/workspace/putamadre/hordes-melee-interiors-patch/build/tools'));e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];out=r/'build/tests';out.mkdir(exist_ok=True)
cp=':'.join(str(r/p)for p in ['build/api','output/fa.jar','output/sc.jar','output/iso.jar','gson.jar']);subprocess.run(e+['-cp',cp,'-d',str(out)]+list(map(str,(r/'tests/lifecycle').rglob('*.java'))),check=True)
p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+cp,'dev.zomboid.firstaid.LifecycleTest63'],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();report={'minecraft_runtime_tested':False,'lifecycle':p.stdout.strip(),'scope':'Production FirstAid screens and cinematic controller with simulated Minecraft, inventory/model and isometric config. Java verification enabled. No full modpack runtime.'}
asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree']);subprocess.run(e+['-cp',asm,'-d',str(r/'build/tools'),str(r/'Contracts63.java')],check=True)
p=subprocess.run(['java','-Xverify:all','-cp',str(r/'build/tools')+':'+asm,'Contracts63',str(r/'output/fa.jar')],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();report['runtime_contracts']=p.stdout.strip();(r/'test-results.json').write_text(json.dumps(report,indent=2)+'\n')
