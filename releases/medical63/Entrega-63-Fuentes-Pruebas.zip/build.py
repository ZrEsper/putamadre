from pathlib import Path
import subprocess,json,os
r=Path(__file__).parent;t=Path(os.environ.get('PATCH_TOOLS','/workspace/putamadre/hordes-melee-interiors-patch/build/tools'));inputs={'fa':'/workspace/attachments/7ad58502-c887-4cd6-aebd-47e5badb571c/firstaid-1.21.1-ZOMBOID-v3.6.18-visible-bandage-marks.jar','sc':'/workspace/attachments/ce63929d-8413-4766-b903-abcfc2ac5b11/survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v35-adaptive-world-spawn.jar','iso':'/workspace/attachments/133b43c6-0e76-4e75-bc1d-21b27bf7a73b/dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.34-finite-aim.jar'};inputs=json.loads((r/'inputs.json').read_text()) if (r/'inputs.json').exists() else inputs;e=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree','asm-analysis'])
for p in ['build/api','build/tools','output']:(r/p).mkdir(parents=True,exist_ok=True)
subprocess.run(e+['-d',str(r/'build/api')]+list(map(str,(r/'api').rglob('*.java'))),check=True)
for tag,base in inputs.items():
 out=r/'build'/tag;out.mkdir(exist_ok=True);subprocess.run(e+['-cp',str(r/'build/api')+':'+base,'-d',str(out)]+list(map(str,(r/'src'/tag).rglob('*.java'))),check=True)
subprocess.run(e+['-cp',asm,'-d',str(r/'build/tools'),str(r/'Patch63.java')],check=True)
for tag,base in inputs.items():subprocess.run(['java','-cp',str(r/'build/tools')+':'+asm,'Patch63',tag,base,str(r/'build'/tag),str(r/'output'/f'{tag}.jar')],check=True)
(r/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
