from pathlib import Path
import zipfile,json,hashlib,tomllib
r=Path(__file__).parent;out=r/'release';out.mkdir(exist_ok=True);items=[('fa','firstaid-1.21.1-ZOMBOID-v3.6.19-isometric-survival-decisions.jar','1.3.3+neoforge1.21.1-zomboid-v3.6.19-isometric-decisions'),('sc','survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v36-world-death-summary.jar','1.0.9+zomboid-v36'),('iso','dungeons_iso-neoforge-3.6.2+1.21.1-zomboid-tacz.35-revival-camera.jar','3.6.2+zomboid.35')];inputs=json.loads((r/'inputs.json').read_text());files=[]
for tag,name,version in items:
 with zipfile.ZipFile(r/'output'/f'{tag}.jar') as z:data={n:z.read(n)for n in z.namelist()}
 key='META-INF/neoforge.mods.toml';meta=data[key].decode();old=tomllib.loads(meta)['mods'][0]['version'];meta=meta.replace('"'+old+'"','"'+version+'"',1);assert tomllib.loads(meta)['mods'][0]['version']==version;data[key]=meta.encode();assert not any(n.startswith(('net/minecraft/','org/joml/','tests/'))for n in data)
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED)as z:
  for n,b in sorted(data.items()):z.writestr(n,b)
 with zipfile.ZipFile(out/name)as z:assert z.testzip()is None
 files.append({'name':name,'version':version,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest(),'base_sha256':hashlib.sha256(Path(inputs[tag]).read_bytes()).hexdigest(),'base_name':Path(inputs[tag]).name})
report=json.loads((r/'test-results.json').read_text());report['class_verification']={'firstaid':290,'survivorcreator':120,'dungeons_iso':151};report['hooks']={'firstaid':2,'survivorcreator':7,'dungeons_iso':3};assert report['lifecycle'].endswith('=48');assert 'runtime_contracts' in report
(out/'test-results.json').write_text(json.dumps(report,indent=2)+'\n');(out/'manifest.json').write_text(json.dumps({'base_commit':'04c9f65b3f4f26c9d0ee87c69723bd291c860155','minecraft':'1.21.1','loader':'NeoForge','minecraft_runtime_tested':False,'files':files},indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(''.join(f['sha256']+'  mods/'+f['name']+'\n'for f in files));(out/'LEEME.md').write_bytes((r/'LEEME.md').read_bytes())
with zipfile.ZipFile(out/'Entrega-63-Supervivencia-Isometrica.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in files:z.write(out/f['name'],'mods/'+f['name'])
 for n in ['LEEME.md','test-results.json','manifest.json','SHA256SUMS.txt']:z.write(out/n,n)
with zipfile.ZipFile(out/'Entrega-63-Fuentes-Pruebas.zip','w',zipfile.ZIP_DEFLATED)as z:
 for folder in ['src','api','tests']:
  for p in(r/folder).rglob('*.java'):z.write(p,p.relative_to(r))
 for n in ['Patch63.java','Contracts63.java','build.py','test.py','package.py','inputs.json','gson.jar','LEEME.md']:z.write(r/n,n)
 for n in ['test-results.json','manifest.json']:z.write(out/n,n)
print('PACKAGE_READY',json.dumps(files))
