package net.minecraft.network.chat;public class MutableComponent implements Component{private final String text;public MutableComponent(String s){text=s;}public String getString(){return text;}}
