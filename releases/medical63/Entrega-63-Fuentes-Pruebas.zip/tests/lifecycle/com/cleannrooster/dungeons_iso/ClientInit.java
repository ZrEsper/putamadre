package com.cleannrooster.dungeons_iso;public class ClientInit{public static Key toggleBinding=new Key();public static class Key{public boolean down;public boolean isDown(){return down;}}}
