from pathlib import Path
import subprocess,tempfile,json,copy,os
r=Path(__file__).parent;t=Path('/workspace/putamadre/hordes-melee-interiors-patch/build/tools');gson='/workspace/medical63/gson.jar';asm=':'.join(str(t/(n+'.jar'))for n in ['asm','asm-tree'])+':/workspace/medical65/asm-commons.jar';ecj=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-nowarn'];jar=r/'release/tacznpcs-2.1.0-1.21.1-tactical.37-random-identities.jar';tests=r/'tests'
subprocess.run(ecj+['-d',str(tests)]+list(map(str,Path('/workspace/npc71/brigadier-source/src/main/java').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',str(jar)+':'+gson+':'+str(tests),'-d',str(tests)]+list(map(str,(r/'testsrc').rglob('*.java'))),check=True)
subprocess.run(ecj+['-cp',asm,'-d',str(r/'tools')]+[str(r/(n+'.java'))for n in ['Extract70','Extract71','Extract73']],check=True)
for name in ['Extract70','Extract71','Extract73']:subprocess.run(['java','-cp',str(r/'tools')+':'+asm,name,str(jar),str(tests)],check=True)
with tempfile.TemporaryDirectory(prefix='fixtures-',dir=r)as run:
 for cls in ['Fixtures70','Fixtures73']:subprocess.run(['java','-Xverify:all','-cp',str(tests)+':'+str(jar)+':'+gson,'mod.cdv.tnpc.tactical.'+cls],check=True,cwd=run)
