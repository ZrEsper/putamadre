from pathlib import Path
import json,copy
r=Path(__file__).parent
base=json.loads((r/'data/phase25-original.json').read_text());d=copy.deepcopy(base);d['schema']=3;d.pop('historias')
female='Adriana Alicia Amelia Andrea Ángela Beatriz Camila Carolina Catalina Cecilia Clara Daniela Diana Emilia Estela Fernanda Gabriela Helena Isabel Jimena Julia Laura Lorena Marina Natalia Patricia Paula Renata Silvia Valeria'.split()
male='Adrián Alberto Alejandro Alonso Andrés Antonio Arturo Benjamín Carlos César Damián Daniel David Diego Eduardo Emilio Ernesto Esteban Felipe Gabriel Gustavo Héctor Javier Joaquín Jorge José Julián Manuel Marcos Rafael'.split()
names=[{'nombre':n,'genero':g}for g,ns in [('femenino',female),('masculino',male)]for n in ns]
families=[('mi madre','femenino'),('mi padre','masculino'),('mi hermana','femenino'),('mi hermano','masculino'),('mi hija','femenino'),('mi hijo','masculino'),('mi tía','femenino'),('mi tío','masculino'),('mi abuela','femenino'),('mi abuelo','masculino'),('mi prima','femenino'),('mi primo','masculino')]
d['bancos']={'nombres':{'npc':names,'companero':copy.deepcopy(names)},'apellidos':'Acosta Aguirre Alvarado Arias Benítez Cabrera Campos Castro Cordero Cortés Delgado Díaz Domínguez Duarte Espinoza Estrada Figueroa Flores Fuentes Galván García Herrera Ibarra León Lozano Maldonado Medina Mendoza Molina Montoya Morales Navarro Ortega Paredes Ponce Ramírez Reyes Ríos Rojas Salazar'.split(),'familiares':[{'rol':role,'genero':gender,'nombres':female if gender=='femenino' else male}for role,gender in families],'objetos_personales':['una fotografía doblada','una pulsera de hilo','un reloj que no funciona','una llave oxidada','una medalla de escuela','un anillo de cobre','un pañuelo bordado','una cinta de casete','una libreta de recetas','una moneda perforada','un llavero de madera','una carta sin sobre','un boleto de autobús','una brújula pequeña','una credencial gastada','una ficha de dominó','una insignia de taller','un dibujo en papel','un broche de cabello','una piedra pintada'],'lugares_hogar':['una estación vieja junto al río','un taller al final de la carretera','una escuela con las ventanas tapiadas','un almacén cerca de las vías','una casa detrás de la cantera','un refugio bajo el puente','una clínica cerrada en las afueras','una finca junto al canal','una fábrica al norte de la ciudad','un edificio frente al mercado','una vivienda cerca de la presa','un campamento detrás del aserradero'],'profesiones_pasadas':['electricista','carpintero','conductor de autobús','personal de enfermería','personal de almacén','personal de mantenimiento','guardia de seguridad','repartidor de correo','mecánico de maquinaria','personal de cocina','docente','personal de limpieza','personal de construcción','personal de imprenta','personal de farmacia','personal de jardinería','personal de ferretería','personal de telefonía','personal de biblioteca','personal de panadería']}
d['plantillas_necesidad']={'familiar_enfermo':{'puede_mentir':False,'miente':False},'familiar_herido_companeros':{'puede_mentir':True,'miente':True}}
d['config'].update(dialogo_automatico=True,distancia_inicio=18,susurro_radio=6,normal_radio=16,grito_radio=32,cooldown_auto_ticks=1200,cooldown_jugador_ticks=400)
d['ui'].update(npc_heading='TE HABLAN',reply_heading='(RESPONDER- CLICKEA TU RESPUESTA)',tone_whisper='susurro',tone_normal='normal',tone_shout='grito',already_talking='Ya estás respondiendo a otro superviviente.',reload_closed='Los diálogos se recargaron. Puedes volver a hablar.',reload_ok='Diálogos recargados. Se conservan las identidades guardadas.',reload_failed='El JSON no es válido. Sigue activa la configuración anterior.',validate_ok='JSON válido. Informe: config/tacznpcs/dialogue-validation.txt',debug_no_npc='Mira directamente a un NPC a menos de 12 bloques.',ambush_no_cover='No hay dos posiciones ocultas válidas. Este encuentro no se inició.',example_usage='Uso: /npcexample <voz> <situación o ID de encuentro>. Requiere operador y charla activa.')
kept=[]
for e in d['encuentros']:
 if e['id'] in ['seco_tension','cansado_tension']:continue
 e.pop('historia');e['necesidad']='aleatoria';kept.append(e)
d['encuentros']=kept

def response(lines,effects=None,next=None,condition=None):
 x={'lineas_npc':lines,'efectos':effects or {},'siguiente':next}
 if condition is not None:x['condicion']=condition
 return x

def option(id,text,tone,responses,requires=None):
 x={'id':id,'texto':text,'tono':tone,'respuestas':responses}
 if requires is not None:x['requiere']=requires
 return x

def mintrust(n):return {'medidores':{'confianza':{'min':n}}}
def item(c):return {'categoria':c,'cantidad':1}
def leave():return option('retirarse','Voy a retirarme despacio.',2,[response(['Está bien. Sigue tu camino.','No voy a impedirte salir.'],{'resultado':'separacion_pacifica'})])
def threat():return option('amenazar','Baja el arma o vas a tener problemas.',4,[response(['Entonces ya elegiste.','No voy a entregarte nada por una amenaza.'],{'confianza':-25,'hostilidad':25,'resultado':'ruptura_combate'})])
def silence(lying):return {'lineas':['Se acabó la espera.','No voy a seguir hablando solo.'],'efectos':{'hostilidad':15,'resultado':'ruptura_combate'}}
def node(id,lines,opts,lying,approach=False):
 x={'id':id,'lineas_npc':lines,'opciones':opts,'reaccion_silencio':silence(lying)}
 if approach:x['al_acercarse']={'distancia_max':2.5,'avance_min':1.0,'respuesta':response(['Te advertí que no te acercaras.','Hay dos personas cubriéndome. Ya no vamos a negociar.'],{'confianza':-20,'hostilidad':30,'revela':['mentira'],'evento_memoria':'ignoró la advertencia y activó la emboscada','resultado':'traicion'})}
 return x
for lying in [False,True]:
 need='familiar_herido_companeros'if lying else'familiar_enfermo'
 opening=['Quédate ahí.','Estoy con un familiar que tiene una herida. Nadie más.','Busco vendas y alcohol. No te acerques.']if lying else['Espera. Quédate donde estás.','No estoy aquí para pelear. Apenas he podido descansar.','Si necesitas hablar, hazlo desde ahí.']
 question_low=['Busco vendas y alcohol.','Tengo un familiar con una herida. No hay nadie más conmigo.','Si puedes ayudar, habla desde donde estás.']if lying else['Tengo un familiar con fiebre.','Necesito antibióticos. Lleva dos días sin mejorar.','Todavía no voy a dar nombres ni decir dónde está.']
 question_high=['{familiar_nombre}, {familiar_rol}, tiene una herida.','Se quedó en {lugar_hogar}.','Solo estamos los dos. Necesito vendas y alcohol.']if lying else['{familiar_nombre}, {familiar_rol}, tiene fiebre.','Se quedó en {lugar_hogar}.','Salí a buscar antibióticos. No encontré lo que necesitaba.']
 ask=option('preguntar','¿Qué te pasa? ¿Por qué estás aquí?',1,[response(question_high,{'confianza':5,'revela':['nombre','necesidad_actual','familia','lugar_hogar']},'necesidad',mintrust(30)),response(question_low,{'confianza':5,'revela':['nombre','necesidad_actual']},'necesidad')])
 passing=option('pasar','Solo paso. No busco problemas.',1,[response(['Puedes seguir.','Mantén la distancia y no habrá problemas.'],{'confianza':10,'resultado':'separacion_pacifica'},condition=mintrust(30)),response(['Eso es fácil de decir.','Retrocede un poco. Todavía te estoy escuchando.'],{'miedo':5},'entrada')])
 food=option('ofrecer_comida','Tengo comida. ¿La necesitas?',2,[response(['Una ración me ayudaría.','No voy a acercarme para quitártela. Tú decides.'],{},'comida')],{'inventario':[item('comida')]})
 entry=node('entrada',opening,[passing,ask,food,threat()],lying,lying)
 med_effect={'confianza':30,'desesperacion':-25,'quita_item':item('medicina'),'evento_memoria':'recibió medicina para su familiar','resultado':'acuerdo'}
 med_high=copy.deepcopy(med_effect);med_high['revela']=['familia','profesion_pasada','lugar_hogar','nombre']
 med=option('dar_medicina','Tengo medicina. Puedo darte una.',1,[response(['…Gracias. No esperaba que de verdad fueras a ayudar.','{familiar_nombre} es {familiar_rol}. Está en {lugar_hogar}.','Antes trabajaba como {profesion_pasada}. Pensé que podría resolver esto sin pedir ayuda.','Voy a llevar esto. Te debo una.'],med_high,condition=mintrust(0)),response(['Gracias por darme esto.','Todavía no voy a contarte mi vida, pero voy a recordarlo.'],med_effect)],{'inventario':[item('medicina')]})
 if lying:
  doubt=option('dudar','No te creo. Hay alguien más contigo.',3,[response(['Sí. Mentí.','{companero_nombre} y otra persona me cubren.','Podemos terminar esto sin que nadie dispare.'],{'revela':['mentira','companero'],'evento_memoria':'descubrió a los compañeros ocultos'},'descubierto',{'miente':True,'medidores':{'confianza':{'min':60}}}),response(['No estoy solo. Hay dos personas cubriéndome.','Ya descubriste esa parte. No voy a darte sus nombres.','Todavía podemos hablar.'],{'revela':['mentira'],'evento_memoria':'descubrió la mentira sobre estar solo'},'descubierto',{'miente':True}),response(['No te estoy mintiendo.','No tengo que demostrarte todo lo que digo.'],{'confianza':-15,'hostilidad':10},'duda')])
 else:
  doubt=option('dudar','¿Cómo sé que no me estás mintiendo?',3,[response(['No tienes cómo saberlo.','Pero no pienso usar lo poco que me queda para convencerte.','Estoy cansado de tener que justificar hasta esto, maldita sea.'],{'confianza':-15,'hostilidad':10},'duda')])
 extort=option('exigir','Dame tus cosas y me largo.',4,[response(['No voy a entregarte lo que necesita mi familia.','Si insistes, esto termina aquí.'],{'confianza':-20,'hostilidad':20,'resultado':'ruptura_combate'})])
 diagnosis=node('necesidad',question_low,[med,doubt,extort,leave()],lying,lying)
 doubt_node=node('duda',['Ya te di una respuesta.','Decide si quieres seguir hablando.'],[option('continuar','Me excedí. Podemos seguir hablando.',1,[response(['…Bueno. Todavía puedo escucharte.','Dime qué puedes hacer de verdad.'],{'confianza':5},'necesidad')]),option('insistir','Sigo sin creerte.',3,[response(['Entonces no tiene sentido alargarlo.','Retírate. No voy a seguir explicándome.'],{'confianza':-10,'resultado':'separacion_pacifica'})]),leave()],lying,lying)
 food_node=node('comida',['Con una ración alcanza por ahora.','Puedes guardarla y retirarte si prefieres.'],[option('dar_comida','Toma. Espero que ayude.',1,[response(['Sí. Esto ayuda.','Voy a llevarla antes de que se haga tarde.'],{'confianza':15,'desesperacion':-10,'quita_item':item('comida'),'evento_memoria':'compartió comida para su familiar','resultado':'acuerdo'})],{'inventario':[item('comida')]}),leave()],lying,lying)
 nodes=[entry,diagnosis,doubt_node,food_node]
 if lying:nodes.append(node('descubierto',['La mentira ya quedó clara.','No te acerques. Elige cómo terminamos.'],[option('seguir','Podemos seguir negociando desde aquí.',3,[response(['Bien. Sin movimientos raros.','Te escucho.'],{},'necesidad')]),extort,leave()],True,True))
 encounter={'id':need,'voz':'*','situacion':'tension','peso':1,'necesidad':need,'inicio':'entrada','turnos_max':5,'nodos':nodes}
 if lying:encounter['companeros_ocultos']=True
 d['encuentros'].append(encounter)
(r/'data/dialogue-phase2.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
