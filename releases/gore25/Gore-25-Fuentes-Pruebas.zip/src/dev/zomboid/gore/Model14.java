package dev.zomboid.gore;
import java.util.*;
/** Distinguish anatomical roots from decorative descendants in EMF hierarchies. */
public final class Model14 {
 static final Map<Object,Boolean> ROOTS=new WeakHashMap<>(),BOUND=new WeakHashMap<>();static final ThreadLocal<Object> PART=new ThreadLocal<>();
 public static void bind(Object model){Model25.bind(model);}

 public static void part(Object part){PART.set(part);}public static void end(){PART.remove();}
 static boolean skin(){Object p=PART.get();return p==null||!Model25.cubes(p,0).isEmpty();}
 static boolean internal(){Object p=PART.get();Model25.Root root=Model25.ROOTS.get(p);return p==null||root!=null&&root.internal();}

 public static void children(Object part,Object pose,Object vertex,int light,int overlay,int color){if(Model25.ROOTS.containsKey(part))return;Object children;try{children=R.get(part,"children");}catch(RuntimeException absent){return;}if(!(children instanceof Map<?,?>map)||map.isEmpty())return;R.call(pose,"pushPose");try{R.call(part,"translateAndRotate",pose);for(Object child:map.values())R.call(child,"render",pose,vertex,light,overlay,color);}finally{R.call(pose,"popPose");}}
}
