package dev.zomboid.gore;
public final class Render25 {public static int light(int original){return (original&~0xF0)|(Math.max(5,(original>>>4)&15)<<4);}}
