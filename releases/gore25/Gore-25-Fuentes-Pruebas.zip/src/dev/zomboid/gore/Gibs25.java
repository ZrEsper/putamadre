package dev.zomboid.gore;
import java.util.*;
/** Visible flesh-and-bone chunks on the shared collision-aware, bounded client debris system. */
public final class Gibs25 {
 static final int CAP=48;static final Random RANDOM=new Random(250);
 static void burst(Object world,Damage25.Point p,Cuts24.Cut cut,boolean complete){if(!Organs16.bind(world))return;int count=complete?9:cut.radius()>=2?4:2;
 for(int i=0;i<count;i++){while(Shards13.ACTIVE.size()>=CAP){var old=Shards13.ACTIVE.removeFirst();Organs16.BODIES.remove(old);}Shards13.Shard s=new Shards13.Shard();s.x=p.x()+(RANDOM.nextDouble()-.5)*.09;s.y=p.y()+.04;s.z=p.z()+(RANDOM.nextDouble()-.5)*.09;s.radius=complete?.065f+RANDOM.nextFloat()*.045f:.035f+RANDOM.nextFloat()*.03f;float size=s.radius*16;List<Mesh12.Quad>mesh=new ArrayList<>();Mesh12.box(mesh,new Mesh12.Box(-size,-size*.65f,-size*.7f,size,size*.65f,size*.7f),i%3==0?2:1,null);if(i%3!=0){Mesh12.box(mesh,new Mesh12.Box(-size*.18f,-size*.85f,-size*.18f,size*.18f,size*.9f,size*.18f),2,null);if(cut.region()==0)Mesh12.box(mesh,new Mesh12.Box(-size*.8f,-size*.1f,-size*.8f,size*.5f,size*.7f,size*.4f),3,null);}s.mesh=List.copyOf(mesh);
 var body=new OrganMotion16.Body(s.x,s.y,s.z,s.radius);double force=complete?.16:.1;body.vx=p.nx()*force+(RANDOM.nextDouble()-.5)*.18;body.vy=.10+RANDOM.nextDouble()*.13;body.vz=p.nz()*force+(RANDOM.nextDouble()-.5)*.18;body.spin=(RANDOM.nextDouble()-.5)*.5;Shards13.ACTIVE.add(s);Organs16.BODIES.put(s,body);}
 }
}
