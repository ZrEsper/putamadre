/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.gore;

import dev.zomboid.gore.Blood12;
import dev.zomboid.gore.Damage13;
import dev.zomboid.gore.R;
import dev.zomboid.gore.Shards13;
import dev.zomboid.gore.Texture13;
import dev.zomboid.gore.Trauma12;
import dev.zomboid.gore.Wounds18;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;

public final class Corpse13 {
    static final String BASE = "com.raiiiden.ragdollified.";
    static final String SERVER = "com.raiiiden.ragdollified.server.ServerRagdollSyncManager";
    static final String CLIENT = "com.raiiiden.ragdollified.client.ClientRagdollManager";
    static final Map<Object, Map<Integer, Pending>> PENDING = Collections.synchronizedMap(new WeakHashMap());

    static Object retained(int n) {
        return ((Map)R.get(R.type(SERVER), "RETAINED")).get(n);
    }

    static int i(Object object, String string) {
        return ((Number)R.get(object, string)).intValue();
    }

    static Object level() {
        return R.get(R.call(R.type("net.minecraft.client.Minecraft"), "getInstance", new Object[0]), "level");
    }

    static boolean zombie(Object object) {
        return Corpse13.i(object, "goreState12") < 0;
    }

    static Object pose(Object object, int n) {
        Object object2 = R.get(object, "settledTransforms");
        if (object2 == null) {
            object2 = R.get(object, "latestStreamTransforms");
        }
        if (object2 != null) {
            R.set(object, "gorePose13", object2);
        } else {
            object2 = R.get(object, "gorePose13");
        }
        if (object2 instanceof Object[]) {
            Object[] objectArray = (Object[])object2;
            if (n >= 0 && n < objectArray.length) {
                return objectArray[n];
            }
        }
        return null;
    }

    public static void server(Object object, Object object2, int n, int n2, Object object3, float f) {
        block17: {
            Object object4;
            double d;
            if (n2 < 0 || n2 > 5 || !Float.isFinite(f) || f <= 0.0f) {
                return;
            }
            Object object5 = Corpse13.retained(n);
            if (object5 == null || R.yes(R.get(object5, "live")) || !R.get(object5, "dimension").equals(R.call(object, "dimension", new Object[0]))) {
                return;
            }
            Object object6 = R.get(object5, "spawnPacket");
            if (!Corpse13.zombie(object6)) {
                return;
            }
            if (object2 != null && !R.yes(R.call(object2, "isAlive", new Object[0]))) {
                return;
            }
            Object object7 = Corpse13.pose(object5, n2);
            Object object8 = object7 == null ? R.call(object5, "anchor", new Object[0]) : R.get(object7, "position");
            double d2 = R.num(R.get(object8, "x"));
            double d3 = R.num(R.get(object8, "y"));
            double d4 = R.num(R.get(object8, "z"));
            if (object3 != null) {
                double d5 = R.num(R.get(object3, "x")) - d2;
                d = R.num(R.get(object3, "y")) - d3;
                double d6 = R.num(R.get(object3, "z")) - d4;
                double d7 = object7 == null ? 9.0 : 2.25;
                if (d5 * d5 + d * d + d6 * d6 > d7) {
                    return;
                }
            }
            int n3 = 1;
            if (object2 != null) {
                Object object9 = R.call(object2, "getMainHandItem", new Object[0]);
                n3 = Damage13.kindOf(object9);
                boolean bl = false;
                try {
                    bl = R.call(R.type("com.tacz.guns.api.item.IGun"), "of", object9) != null;
                }
                catch (RuntimeException runtimeException) {
                    // empty catch block
                }
                double d8 = bl ? Math.max(16.0, R.num(R.call(R.type("com.raiiiden.ragdollified.api.RagdollifiedServerApi"), "getPhysicsDistance", new Object[0]))) : Math.max(3.0, R.num(R.call(object2, "getAttributeValue", R.get(R.type("net.minecraft.world.entity.ai.attributes.Attributes"), "ENTITY_INTERACTION_RANGE")))) + 1.0;
                Object[] objectArray = new Object[]{d2, d3, d4};
                if (R.num(R.call(object2, "distanceToSqr", objectArray)) > d8 * d8) {
                    return;
                }
                Object object10 = R.make("net.minecraft.world.phys.Vec3", d2, d3, d4);
                Object object11 = R.call(object2, "getEyePosition", new Object[0]);
                object4 = R.make("net.minecraft.world.level.ClipContext", object11, object10, R.get(R.type("net.minecraft.world.level.ClipContext$Block"), "COLLIDER"), R.get(R.type("net.minecraft.world.level.ClipContext$Fluid"), "NONE"), object2);
                Object object12 = R.call(object, "clip", object4);
                if (R.call(object12, "getType", new Object[0]).toString().equals("BLOCK")) {
                    Object[] objectArray2 = new Object[]{object10};
                    if (R.num(R.call(R.call(object12, "getLocation", new Object[0]), "distanceToSqr", objectArray2)) > 0.36) {
                        return;
                    }
                }
                if (bl) {
                    n3 = 1;
                }
            }
            int n4 = Damage13.region(n2);
            d = 0.5;
            if (object7 != null && object3 != null) {
                Object object13 = R.get(object7, "rotation");
                double d9 = R.num(R.get(object13, "x"));
                double d10 = R.num(R.get(object13, "y"));
                double d11 = R.num(R.get(object13, "z"));
                double d12 = R.num(R.get(object13, "w"));
                double d13 = R.num(R.get(object3, "x")) - d2;
                double d14 = R.num(R.get(object3, "y")) - d3;
                double d15 = R.num(R.get(object3, "z")) - d4;
                double d16 = (1.0 - 2.0 * (d10 * d10 + d11 * d11)) * d13 + 2.0 * (d9 * d10 + d11 * d12) * d14 + 2.0 * (d9 * d11 - d10 * d12) * d15;
                double d17 = 2.0 * (d9 * d10 - d11 * d12) * d13 + (1.0 - 2.0 * (d9 * d9 + d11 * d11)) * d14 + 2.0 * (d10 * d11 + d9 * d12) * d15;
                d = Math.max(0.0, Math.min(1.0, 0.5 - d17 / 0.75));
                if (n2 == 0 && d16 < 0.0) {
                    n4 = 7;
                }
            }
            long l = ((Number)R.get(object6, "goreCounts13")).longValue();
            int n5 = (int)(l >>> n4 * 4 & 0xFL) + 1;
            n5 = Math.min(15, n5);
            l = l & (15L << n4 * 4 ^ 0xFFFFFFFFFFFFFFFFL) | (long)n5 << n4 * 4;
            R.set(object6, "goreCounts13", l);
            object4 = Wounds18.corpse(Corpse13.i(object6, "goreState12"), Corpse13.i(object6, "goreDetails12"), Corpse13.i(object6, "goreSurface12"), n4, n5, n3, d, object6, object2, f);
            Cuts24.dead(object, object2, n, n2, object3, f);
            R.set(object6, "goreState12", Damage25.state(((Damage13.Result)object4).state(),Cuts24.field(object6),n4));
            R.set(object6, "goreDetails12", ((Damage13.Result)object4).details());
            R.set(object6, "goreSurface12", ((Damage13.Result)object4).surfaces());
            try {
                R.call(R.type("dev.zomboid.remains.BodyLoot16"), "dirty", object, n);
            }
            catch (RuntimeException runtimeException) {
                if (runtimeException.getCause() instanceof ClassNotFoundException) break block17;
                throw runtimeException;
            }
        }
    }

    public static void ordered(Object object, Object object2) {
        Object object3 = Corpse13.retained(Corpse13.i(object2, "ragdollId"));
        if (object3 == null || !R.get(object3, "dimension").equals(R.call(object, "dimension", new Object[0]))) {
            return;
        }
        Trauma12.snapshot(R.get(object3, "spawnPacket"), object2);
    }

    public static void client(Object object2) {
        if (Corpse13.i(object2, "partIndex") == -16) {
            R.call(R.type(CLIENT), "requestRemoveRagdoll", Corpse13.i(object2, "ragdollId"));
            return;
        }
        int n = Corpse13.i(object2, "goreState12");
        if (n >= 0 && Corpse13.i(object2, "goreSurface12") >= 0) {
            return;
        }
        int n2 = Corpse13.i(object2, "ragdollId");
        int n3 = Corpse13.i(object2, "revision");
        Object object3 = R.call(R.type(CLIENT), "get", n2);
        Pending pending = new Pending(n, Corpse13.i(object2, "goreDetails12"), Corpse13.i(object2, "goreSurface12"), n3, Cuts24.field(object2));
        if (Corpse13.i(object2, "partIndex") == -16) {
            R.call(R.type(CLIENT), "requestRemoveRagdoll", n2);
            return;
        }
        if (object3 == null) {
            Pending pending2;
            Object object4 = Corpse13.level();
            Map map = PENDING.computeIfAbsent(object4, object -> new ConcurrentHashMap());
            if (map.size() > 256) {
                map.clear();
            }
            if ((pending2 = (Pending)map.get(n2)) == null || pending2.revision < n3) {
                map.put(n2, pending);
            }
            return;
        }
        if (n3 <= Corpse13.i(object3, "goreRevision13")) {
            return;
        }
        Corpse13.apply(object3, pending);
        if (R.num(R.get(object2, "sourceDamage")) <= 0.0) {
            return;
        }
        Object object5 = Corpse13.level();
        if (object5 != null && Blood12.frame(object5)) {
            double d = R.num(R.get(object2, "impactX"));
            double d2 = R.num(R.get(object2, "impactY"));
            double d3 = R.num(R.get(object2, "impactZ"));
            if (Double.isFinite(d) && Double.isFinite(d2) && Double.isFinite(d3)) {
                Shards13.burst(object5, d, d2, d3, 3, Corpse13.i(object2, "partIndex") == 1);
                Blood12.emit(object5, d, d2, d3, true, 6);
            }
        }
    }

    static void apply(Object object, Pending pending) {
        if (pending.surfaces < 0) {
            R.call(R.type(CLIENT), "setPersistent", Corpse13.i(object, "originalEntityId"), true);
        }
        R.set(object, "goreState12", pending.state);
        R.set(object, "goreDetails12", pending.details);
        R.set(object, "goreSurface12", pending.surfaces);
        R.set(object, "goreRevision13", pending.revision);
        R.set(object, "goreCuts24", pending.cuts.clone());
        Texture13.report(object);
        Object object2 = Corpse13.level();
        if (object2 != null) {
            R.set(object, "goreBleedUntil13", ((Number)R.call(object2, "getGameTime", new Object[0])).longValue() + 80L);
        }
    }

    public static void born(Object object) {
        Pending pending;
        Map<Integer, Pending> map;
        Texture13.report(object);
        if (Corpse13.i(object, "goreSurface12") < 0) {
            R.call(R.type(CLIENT), "setPersistent", Corpse13.i(object, "originalEntityId"), true);
        }
        if ((map = PENDING.get(Corpse13.level())) != null && (pending = map.remove(Corpse13.i(object, "originalEntityId"))) != null) {
            Corpse13.apply(object, pending);
        }
    }

    public static boolean loot(Object object, Object object2) {
        block4: {
            if (Texture13.receive(object, object2)) {
                return true;
            }
            if (Corpse13.i(object2, "partIndex") != -13) {
                return false;
            }
            try {
                R.call(R.type("dev.zomboid.remains.BodyLoot16"), "open", object, Corpse13.i(object2, "ragdollId"));
            }
            catch (RuntimeException runtimeException) {
                if (runtimeException.getCause() instanceof ClassNotFoundException) break block4;
                throw runtimeException;
            }
        }
        return true;
    }

    record Pending(int state, int details, int surfaces, int revision, int[] cuts) {
    }
}

