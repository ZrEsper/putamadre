package dev.zomboid.gore;
import java.util.*;
/** UV-preserving surface subtraction, with layered damage to tissue, organs and bones. */
public final class CSG24 {
 static List<Mesh12.Box> holes(Mesh12.Box bounds,int region,double inset){List<Mesh12.Box>out=new ArrayList<>();int[]a=Cuts24.CURRENT.get();for(int i=0;i<a.length;i+=2){var c=Cuts24.cut(a,i);if(c.region()!=region&&!(region==6&&c.region()==7))continue;double r=Math.max(0,c.radius()-inset);if(r<=0)continue;double cx=bounds.x0()+c.x()*(bounds.x1()-bounds.x0()),cy=bounds.y0()+c.y()*(bounds.y1()-bounds.y0()),cz=bounds.z0()+c.z()*(bounds.z1()-bounds.z0());double scale=(bounds.y1()-bounds.y0())/(region==0?8:12);r*=scale;for(int s=-2;s<=2;s++){double low=(s-.5)/2.5,high=(s+.5)/2.5,lo=Math.max(-1,low),hi=Math.min(1,high);if(hi<=lo)continue;double nearest=lo>0?lo:hi<0?hi:0,extent=Math.sqrt(Math.max(0,1-nearest*nearest))*.92;out.add(new Mesh12.Box((float)(cx-r*extent),(float)(cy+r*lo),(float)(cz-r*extent),(float)(cx+r*extent),(float)(cy+r*hi),(float)(cz+r*extent)));}}
 return out;}
 static Mesh12.Box bounds(List<Mesh12.Cube> cubes){float x=Float.MAX_VALUE,y=x,z=x,X=-x,Y=-x,Z=-x;for(var c:cubes)for(var f:c.faces())for(float[]v:f.xyz()){x=Math.min(x,v[0]);y=Math.min(y,v[1]);z=Math.min(z,v[2]);X=Math.max(X,v[0]);Y=Math.max(Y,v[1]);Z=Math.max(Z,v[2]);}if(x==Float.MAX_VALUE)return cubes.getFirst().bounds();return new Mesh12.Box(x,y,z,X,Y,Z);}
 static void surface(List<Mesh12.Quad>out,Mesh12.Face f,List<Mesh12.Box>holes){List<Surface19.P>p=new ArrayList<>();for(int i=0;i<4;i++)p.add(new Surface19.P(f.xyz()[i][0],f.xyz()[i][1],f.xyz()[i][2],f.u()[i],f.v()[i]));List<List<Surface19.P>> remain=List.of(p);for(var hole:holes){List<List<Surface19.P>>next=new ArrayList<>();for(var polygon:remain)next.addAll(Surface19.subtract(polygon,hole));remain=next;}for(var poly:remain)Surface19.emit(out,poly,0,f.nx(),f.ny(),f.nz());}
 static List<Mesh12.Box> remainder(Mesh12.Box b,List<Mesh12.Box> holes){List<Mesh12.Box>parts=List.of(b);for(var h:holes){List<Mesh12.Box>next=new ArrayList<>();for(var p:parts)next.addAll(Mesh12.subtract(p,h));parts=next;}return parts;}
 public static List<Mesh12.Quad> mesh(List<Mesh12.Cube>cubes,int region,int stage){if(cubes.isEmpty()||Damage25.destroyed(Cuts24.CURRENT.get(),region))return List.of();if(!Cuts24.has(region)){if((stage&7)==0&&(region!=6||((stage>>5)&7)==0))return Model25.intact(cubes);return Surface19.build(cubes,region,stage);}Mesh12.Box bounds=bounds(cubes);List<Mesh12.Box>skinHoles=holes(bounds,region,0);List<Mesh12.Quad>out=new ArrayList<>();
 if(Model14.skin())for(var cube:cubes)for(var f:cube.faces())surface(out,f,skinHoles);
 if(Model14.internal()){
  List<Mesh12.Box>soft=holes(bounds,region,.65),hard=holes(bounds,region,1.35);
  for(var piece:Anatomy14.anatomy(region)){
   var box=Anatomy14.scale(piece.box(),bounds);boolean bone=piece.material()==2||piece.name().equals("tooth");var cuts=bone?hard:soft;
   for(var b:remainder(box,cuts))Mesh12.box(out,b,piece.material(),null);
  }
  // Under the skin, a continuous muscle shell closes the edge of each aperture.
  float w=bounds.x1()-bounds.x0(),h=bounds.y1()-bounds.y0(),d=bounds.z1()-bounds.z0();
  for(var hole:skinHoles){Mesh12.Box shell=Mesh12.intersect(bounds,new Mesh12.Box(hole.x0()-.12f,hole.y0()-.12f,hole.z0()-.12f,hole.x1()+.12f,hole.y1()+.12f,hole.z1()+.12f));if(!shell.valid())continue;
   // Only draw the small lining lying inside each hole, then remove all newer wounds.
   for(var b:remainder(shell,skinHoles))Mesh12.box(out,b,1,null);
  }
 }
 return List.copyOf(out);
 }
}
