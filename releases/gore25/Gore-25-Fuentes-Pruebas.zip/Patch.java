import java.nio.file.*;import java.util.*;import java.util.zip.*;import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;import jdk.internal.org.objectweb.asm.tree.analysis.*;
public class Patch implements Opcodes {
 static final String G="dev/zomboid/gore/";static int changes;
 static Map<String,byte[]>read(String p)throws Exception{var out=new TreeMap<String,byte[]>();try(var z=new ZipFile(p)){for(var e:Collections.list(z.entries()))out.put(e.getName(),z.getInputStream(e).readAllBytes());}return out;}
 static void write(String p,Map<String,byte[]>e)throws Exception{try(var z=new ZipOutputStream(Files.newOutputStream(Path.of(p)))){for(var a:e.entrySet()){var n=new ZipEntry(a.getKey());n.setTime(0);z.putNextEntry(n);z.write(a.getValue());z.closeEntry();}}}
 static MethodInsnNode call(String c,String m,String d){return new MethodInsnNode(INVOKESTATIC,G+c,m,d,false);}
 static void tail(MethodNode m,String cls,String method,int slot){for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN){var l=new InsnList();l.add(new VarInsnNode(ALOAD,slot));l.add(call(cls,method,"(Ljava/lang/Object;)V"));m.instructions.insertBefore(n,l);}changes++;}
 static void noOp(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.instructions.add(new InsnNode(RETURN));changes++;}
 public static void main(String[]a)throws Exception{var gore=read(a[0]);var rag=read(a[1]);
 for(var e:new ArrayList<>(gore.entrySet())){if(!e.getKey().startsWith(G)||!e.getKey().endsWith(".class"))continue;ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);String name=c.name.substring(G.length());for(var m:c.methods){
  if(name.equals("Skin12")&&m.name.equals("cubes")){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new VarInsnNode(ILOAD,1));m.instructions.add(call("Model25","cubes",m.desc));m.instructions.add(new InsnNode(ARETURN));changes++;}
  if(name.equals("Skin12")&&m.name.equals("ragdoll")){tail(m,"Damage25","ragdoll",0);tail(m,"Model25","ragdoll",0);}
 if(name.equals("Skin12")&&m.name.equals("living"))tail(m,"Model25","living",0);
 if(name.equals("Skin12")&&m.name.equals("end")){for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN)m.instructions.insertBefore(n,call("Model25","end","()V"));changes++;}
  if(name.equals("Trauma13")&&m.name.equals("tick"))tail(m,"Damage25","living",0);
  if(name.equals("Artery14")&&Set.of("tick","ragdoll","deadEmit").contains(m.name))noOp(m);
  if(name.equals("Blood12")&&Set.of("tick","ragdoll").contains(m.name))noOp(m);
  if(name.equals("Debris23")&&Set.of("burst","ragdoll").contains(m.name))noOp(m);
  if(name.equals("Shards13")&&m.name.equals("render")){boolean light=false;for(var n:m.instructions.toArray()){if(n instanceof LdcInsnNode l&&l.cst.equals("getLightColor"))light=true;if(light&&n instanceof MethodInsnNode i&&i.owner.equals("java/lang/Number")&&i.name.equals("intValue")){m.instructions.insert(n,call("Render25","light","(I)I"));changes++;light=false;}}}
 }ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);gore.put(e.getKey(),w.toByteArray());}
 for(var e:new ArrayList<>(rag.entrySet()))if(e.getKey().equals("com/raiiiden/ragdollified/network/ModNetwork.class")){ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);boolean protocol=false;for(var m:c.methods)for(var n:m.instructions)if(n instanceof LdcInsnNode l&&l.cst.equals("16-procedural24")){l.cst="17-procedural25";protocol=true;}if(!protocol)throw new AssertionError("base protocol mismatch");ClassWriter w=new ClassWriter(0);c.accept(w);rag.put(e.getKey(),w.toByteArray());}
 try(var walk=Files.walk(Path.of(a[2]))){for(var p:walk.filter(p->p.toString().endsWith(".class")).toList())gore.put(Path.of(a[2]).relativize(p).toString(),Files.readAllBytes(p));}
 int verified=0;for(var jar:List.of(gore,rag))for(var e:jar.entrySet())if(e.getKey().endsWith(".class")&&(e.getKey().startsWith(G)||e.getKey().startsWith("com/raiiiden/"))){ClassNode c=new ClassNode();new ClassReader(e.getValue()).accept(c,0);for(var m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);verified++;}
 if(changes!=14)throw new AssertionError("hooks "+changes);write(a[3],gore);write(a[4],rag);System.out.println("GORE25_HOOKS="+changes+" VERIFIED_CLASSES="+verified);}
}
