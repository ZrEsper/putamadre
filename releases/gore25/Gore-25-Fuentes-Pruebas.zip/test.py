from pathlib import Path
import subprocess,json,zipfile
r=Path(__file__).resolve().parent;g=r/'output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-head-blood-destruction.25.jar';rag=r/'output/ragdollified-1.21.1-1.1.5-stable-anatomy.21.jar';out=r/'build/test';out.mkdir(parents=True,exist_ok=True)
exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{s}=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']]
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(g),'-d',str(out),*map(str,(r/'fixtures').rglob('*.java')),*map(str,(r/'tests').rglob('*.java'))],check=True)
subprocess.run(['java',*exports,'com.sun.tools.javac.Main',*exports,'-d',str(out),str(r/'Inspect.java')],check=True)
results=[]
for main,argv in [('Checks24',[str(r/'geometry.json')]),('RenderChecks25',[]),('DamageEffectsChecks25',[])]:
 p=subprocess.run(['java','-Xverify:all','-cp',str(out)+':'+str(g),'dev.zomboid.gore.'+main,*argv],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
p=subprocess.run(['java',*exports,'-cp',str(out),'Inspect',str(g),str(rag)],capture_output=True,text=True);print(p.stdout,p.stderr);p.check_returncode();results.append(p.stdout.strip())
with zipfile.ZipFile(g)as z:
 assert z.testzip()is None
 assert not any(n.startswith('net/minecraft/')or n.startswith('com/mojang/')for n in z.namelist())
 sounds=json.loads(z.read('assets/zomboid_gore/sounds.json'))
 for row in sounds['body_destroy25']['sounds']:assert 'assets/zomboid_gore/sounds/'+row['name'].split(':')[1]+'.ogg'in z.namelist()
(r/'test-results.json').write_text(json.dumps({'results':results,'fixture_scope':'Runs shipped Skin12 bytecode against minimal Minecraft API fixtures; not a running game.','minecraft_runtime_tested':False},indent=2)+'\n')
