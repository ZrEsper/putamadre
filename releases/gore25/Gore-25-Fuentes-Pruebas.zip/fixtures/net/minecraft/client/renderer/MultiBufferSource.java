package net.minecraft.client.renderer;
import com.mojang.blaze3d.vertex.*;
public interface MultiBufferSource {VertexConsumer getBuffer(RenderType r);public static class BufferSource implements MultiBufferSource{public VertexConsumer.Recording consumer=new VertexConsumer.Recording();public VertexConsumer getBuffer(RenderType r){return consumer;}public void endBatch(){}}}
