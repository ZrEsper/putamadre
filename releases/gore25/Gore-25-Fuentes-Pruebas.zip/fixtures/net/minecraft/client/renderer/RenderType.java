package net.minecraft.client.renderer;
import net.minecraft.resources.ResourceLocation;
public class RenderType{public static RenderType entityCutoutNoCull(ResourceLocation r){return new RenderType();}}
