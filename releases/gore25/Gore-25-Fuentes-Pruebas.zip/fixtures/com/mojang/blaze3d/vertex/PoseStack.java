package com.mojang.blaze3d.vertex;
import java.util.*;
public class PoseStack{public static class Pose{public float x,y,z;Pose copy(){Pose p=new Pose();p.x=x;p.y=y;p.z=z;return p;}}public Pose pose=new Pose();final Deque<Pose>stack=new ArrayDeque<>();public void pushPose(){stack.push(pose.copy());}public void popPose(){pose=stack.pop();}public Pose last(){return pose;}public void translate(float x,float y,float z){pose.x+=x;pose.y+=y;pose.z+=z;}}
