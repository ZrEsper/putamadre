from pathlib import Path
import subprocess,zipfile,json,hashlib,argparse
r=Path(__file__).resolve().parent;root=r.parent
GORE=root/'procedural24/output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-procedural-anatomy.24.jar'
RAG=root/'procedural24/output/ragdollified-1.21.1-1.1.5-procedural-anatomy.20.jar'
parser=argparse.ArgumentParser();parser.add_argument('--gore',type=Path,default=GORE);parser.add_argument('--ragdoll',type=Path,default=RAG);args=parser.parse_args();GORE=args.gore;RAG=args.ragdoll
exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{s}=ALL-UNNAMED'for s in ['', '.tree','.tree.analysis']]
for d in ['build/classes','build/tools','output']:(r/d).mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','-proc:none','-cp',str(GORE),'-d',str(r/'build/classes'),*map(str,(r/'src').rglob('*.java'))],check=True)
subprocess.run(['java',*exports,'com.sun.tools.javac.Main',*exports,'-d',str(r/'build/tools'),str(r/'Patch.java')],check=True)
g=r/'output/zomboid-zombie-gore-1.0.20-neoforge-1.21.1-head-blood-destruction.25.jar';rag=r/'output/ragdollified-1.21.1-1.1.5-stable-anatomy.21.jar'
subprocess.run(['java',*exports,'-cp',str(r/'build/tools'),'Patch',str(GORE),str(RAG),str(r/'build/classes'),str(g),str(rag)],check=True)
with zipfile.ZipFile(g)as z:e={n:z.read(n)for n in z.namelist()}
sounds=json.loads(e['assets/zomboid_gore/sounds.json']);sounds['body_destroy25']={'sounds':[{'name':f'zomboid_gore:body_destroy25_{i}','attenuation_distance':24}for i in range(3)]}
for i in range(3):e[f'assets/zomboid_gore/sounds/body_destroy25_{i}.ogg']=(r/'audio'/f'body_destroy25_{i}.ogg').read_bytes()
e['assets/zomboid_gore/sounds.json']=(json.dumps(sounds,indent=2)+'\n').encode()
e['META-INF/neoforge.mods.toml']=e['META-INF/neoforge.mods.toml'].replace(b'displayName="Zomboid Zombie Injuries"',b'displayName="Zomboid Zombie Injuries - Gore .25"')
e.pop('META-INF/zomboid-procedural24.json',None);e['META-INF/zomboid-procedural25.json']=json.dumps({'patch':25,'version_retained_for_consumers':'1.0.20','protocol':'17-procedural25','minecraft_runtime_tested':False}).encode()
with zipfile.ZipFile(g,'w',zipfile.ZIP_DEFLATED)as z:
 for n,b in sorted(e.items()):z.writestr(n,b)
(r/'build-validation.json').write_text(json.dumps({'inputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [GORE,RAG]},'outputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [g,rag]},'minecraft_runtime_tested':False},indent=2)+'\n')
