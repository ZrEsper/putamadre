package dev.zomboid.awareness;
import java.util.*;
public final class Awareness{
 private record Step(Object level,long tick,double x,double z,boolean moving){}
 private static final Map<Object,Step> steps=new WeakHashMap<>();
 private static boolean walking(Object player,long tick){Object level=R.call(player,"level");Step prev=steps.get(player);double x=R.coord(player,"X"),z=R.coord(player,"Z");boolean moving=false;
  if(prev!=null&&prev.level==level){if(prev.tick==tick)moving=prev.moving;else {double d=Math.pow(x-prev.x,2)+Math.pow(z-prev.z,2);moving=tick-prev.tick<=8&&d>.0004&&d<=16;}}
  steps.put(player,new Step(level,tick,x,z,moving));return moving&&!R.yes(R.call(player,"isCrouching"))&&!R.yes(R.call(player,"isPassenger"))&&R.yes(R.call(player,"onGround"));
 }

 static long now(Object mob){return R.lng(R.call(R.call(mob,"level"),"getGameTime"));}
 static Object profile(Object mob){return R.call(R.type("dev.zomboid.hordes.ZombieIndividual"),"profile",mob);}
 static double distance(Object a,Object b){return Math.sqrt(Math.pow(R.coord(a,"X")-R.coord(b,"X"),2)+Math.pow(R.coord(a,"Y")-R.coord(b,"Y"),2)+Math.pow(R.coord(a,"Z")-R.coord(b,"Z"),2));}
 static boolean eligible(Object p){return R.yes(R.call(p,"isAlive"))&&!R.yes(R.call(p,"isCreative"))&&!R.yes(R.call(p,"isSpectator"));}
 static void remember(Object tag,Object player,long tick){R.call(tag,"putUUID","zi_seen",R.call(player,"getUUID"));R.call(tag,"putLong","zi_seen_until",tick+80);}
 public static boolean close(Object mob,Object player){if(!eligible(player)||R.call(mob,"level")!=R.call(player,"level"))return false;double d=distance(mob,player);Object tag=profile(mob);long tick=now(mob);
  boolean recent=R.yes(R.call(tag,"hasUUID","za_heard_player"))&&R.call(tag,"getUUID","za_heard_player").equals(R.call(player,"getUUID"))&&R.lng(R.call(tag,"getLong","za_heard_until"))>tick&&d<=Math.max(2,R.num(R.call(tag,"getDouble","za_heard_radius")));
  if((d<=2||recent)&&R.yes(R.call(mob,"hasLineOfSight",player))){remember(tag,player,tick);return true;}return false;
 }
 public static boolean hear(Object mob,Object pos,Object player,double radius,long until,boolean heli){
  if(!eligible(player)||R.call(mob,"level")!=R.call(player,"level")||!Double.isFinite(radius)||radius<=0)return false;
  Object tag=profile(mob);long tick=now(mob);int type=((Number)R.call(tag,"getInt","zi_type")).intValue();double d=R.call(player,"blockPosition").equals(pos)?distance(mob,player):distance(mob,pos);
  double effective=R.num(R.call(R.type("dev.zomboid.hordes.NoiseRules"),"heardRadius",radius,R.num(R.call(tag,"getDouble","zi_hearing"))));boolean guaranteed=d<=2||(radius>=5&&d<=5);
  if(!guaranteed){if(d>effective)return false;if(R.lng(R.call(tag,"getLong","zi_hearing_next"))>tick&&radius<=R.num(R.call(tag,"getDouble","zi_last_radius"))*1.2)return false;
   double chance=R.num(R.call(R.type("dev.zomboid.hordes.IndividualRules"),"chance",type,d,effective));if(R.num(R.call(R.call(mob,"getRandom"),"nextDouble"))>=chance)return false;
  }
  R.call(tag,"putDouble","zi_last_radius",radius);R.call(tag,"putLong","zi_hearing_next",tick+reaction(type));
  R.call(tag,"putLong","zh_pos",R.call(pos,"asLong"));R.call(tag,"putLong","zh_until",Math.min(until,tick+(type==0?160:300)));R.call(tag,"putUUID","zh_player",R.call(player,"getUUID"));R.call(tag,"putBoolean","zh_heli",heli);
  R.call(tag,"putUUID","za_heard_player",R.call(player,"getUUID"));R.call(tag,"putLong","za_heard_until",tick+80);R.call(tag,"putDouble","za_heard_radius",Math.max(2,radius>=5?Math.max(5,effective):effective));
  if(close(mob,player)){Object target=R.call(mob,"getTarget");if(target==null||target==player)R.call(mob,"setTarget",player);}return true;
 }
 public static int reaction(int type){return type==0?12:type==1?6:2;}
 public static double radius(String sound,double original,boolean crouching){if(!Double.isFinite(original)||original<=0)return 0;String id=sound.toLowerCase(Locale.ROOT);
  if(id.contains("sneeze")||id.contains("sneez")||id.contains("cough"))return Math.max(5,Math.min(8,original));
  if(!crouching&&(id.contains("step")||id.contains("walk")||id.contains("rustle")))return 5;
  return R.num(R.call(R.type("dev.zomboid.hordes.NoiseRules"),"radius",sound,original,crouching));
 }
 public static boolean produced(Object sound,Object player){if(R.yes(R.call(sound,"isPlayerProduced")))return true;String name=String.valueOf(R.get(sound,"soundId")).toLowerCase(Locale.ROOT);return (name.contains("sneez")||name.contains("cough"))&&distance(R.get(sound,"pos"),player)<=2;}
 /** Fast local awareness, independent of the slow/random vanilla target acquisition. */
 public static void tick(Object event){Object mob=R.call(event,"getEntity"),level=R.call(mob,"level");if(R.yes(R.call(level,"isClientSide"))||!R.yes(R.call(mob,"isAlive"))||!R.yes(R.call(R.type("dev.zomboid.hordes.ZombieIndividual"),"supported",mob)))return;
  if(Math.floorMod(((Number)R.get(mob,"tickCount")).intValue()+((Number)R.call(mob,"getId")).intValue(),4)!=0)return;
  Object closest=null;double min=4;for(Object p:(Iterable<?>)R.call(level,"players")){if(!eligible(p))continue;double d=distance(mob,p);if(d<=5&&walking(p,now(mob)))hear(mob,R.call(p,"blockPosition"),p,5,now(mob)+120,false);if(d<=2&&d*d<=min&&R.yes(R.call(mob,"hasLineOfSight",p))){closest=p;min=d*d;}}
  if(closest==null)return;Object target=R.call(mob,"getTarget");if(target!=null&&target!=closest&&R.yes(R.call(target,"isAlive"))&&distance(mob,target)<=Math.sqrt(min))return;
  remember(profile(mob),closest,now(mob));R.call(mob,"setTarget",closest);R.call(R.call(mob,"getLookControl"),"setLookAt",closest,30f,30f);
 }
}
