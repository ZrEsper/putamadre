/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.hordes;

import java.util.Locale;

public final class NoiseRules {
    public static boolean gun(String string) {
        String string2 = string.toLowerCase(Locale.ROOT);
        return string2.startsWith("tacz:gun#") && string2.contains("/shoot") || (string2.startsWith("cgm:") || string2.startsWith("musketmod:")) && (string2.contains("fire") || string2.contains("shoot"));
    }

    public static boolean explosion(String string) {
        String string2 = string.toLowerCase(Locale.ROOT);
        return string2.contains("explode") || string2.contains("explosion");
    }

    public static double radius(String string, double d, boolean bl) {
        if (!Double.isFinite(d) || d <= 0.0) {
            return 0.0;
        }
        if (NoiseRules.gun(string)) {
            return Math.max(12.0, Math.min(192.0, d * 1.5));
        }
        if (NoiseRules.explosion(string)) {
            return Math.max(32.0, Math.min(144.0, d * 1.5));
        }
        String string2 = string.toLowerCase(Locale.ROOT);
        if (string2.contains("step") || string2.contains("walk") || string2.contains("rustle")) {
            return Math.min(d, (double)(bl ? 1 : 4));
        }
        if (string2.contains("break") || string2.contains("place")) {
            return Math.min(d, (double)(bl ? 2 : 4));
        }
        return Math.min(d, 8.0);
    }

    public static double heardRadius(double d, double d2) {
        return d <= 8.0 ? Math.min(8.0, d * d2) : Math.min(192.0, d * d2);
    }
}

