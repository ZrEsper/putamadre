/*
 * Decompiled with CFR 0.152.
 */
package dev.zomboid.hordes;

public final class IndividualRules {
    public static int type(double d) {
        return d < 0.75 ? 0 : (d < 0.9 ? 1 : 2);
    }

    public static double vision(int n, boolean bl) {
        return bl ? (n == 0 ? 1.5 : (n == 1 ? 3.5 : 10.0)) : (double)(n == 0 ? 8 : (n == 1 ? 14 : 24));
    }

    public static int delay(int n, int n2) {
        return n == 0 ? 30 + Math.floorMod(n2, 41) : (n == 1 ? 10 + Math.floorMod(n2, 21) : Math.floorMod(n2, 9));
    }

    public static double hearing(int n, double d) {
        return (n == 0 ? 0.5 : (n == 1 ? 0.8 : 1.1)) + Math.max(0.0, Math.min(1.0, d)) * 0.2;
    }

    public static double chance(int n, double d, double d2) {
        if (d > d2) {
            return 0.0;
        }
        if (d <= 1.5) {
            return 1.0;
        }
        return Math.max(0.05, (n == 0 ? 0.45 : (n == 1 ? 0.72 : 0.95)) * (1.0 - 0.45 * d / Math.max(1.0, d2)));
    }

    public static boolean inView(int n, double d, boolean bl) {
        return d >= (n == 0 ? (bl ? 0.7 : 0.55) : (n == 1 ? 0.2 : -0.2));
    }

    public static boolean smart(int n) {
        return n == 2;
    }

    public static int initial(int n, int n2) {
        return Math.min(30, n + Math.max(0, n2 - 1) * 4);
    }

    public static int activeLimit(int n, int n2) {
        return Math.min(42, n + Math.max(0, n2 - 1) * 6);
    }

    public static int quota(int n, int n2, int n3, int n4, int n5) {
        return Math.max(0, Math.min(Math.min(n, n2), Math.min(Math.max(0, n3), Math.max(0, n5 - n4))));
    }

    public static int reward(int n, int n2) {
        return Math.min(Math.max(0, n2), Math.max(0, n) + 1);
    }
}

