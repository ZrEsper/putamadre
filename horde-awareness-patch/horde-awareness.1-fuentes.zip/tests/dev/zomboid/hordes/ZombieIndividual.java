package dev.zomboid.hordes;import java.lang.reflect.*;
public class ZombieIndividual{public static Object profile(Object o){try{return o.getClass().getField("tag").get(o);}catch(Exception e){throw new RuntimeException(e);}}public static boolean supported(Object e){try{return e.getClass().getField("supported").getBoolean(e);}catch(Exception x){return false;}}}
