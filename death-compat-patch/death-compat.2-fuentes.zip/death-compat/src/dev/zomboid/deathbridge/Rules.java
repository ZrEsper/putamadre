package dev.zomboid.deathbridge;
/** Pure server rules: client reports cannot choose a death effect or create loot. */
public final class Rules {
 public static final int RAGDOLL=1,DISMEMBER=2,END=3,REPORT=4,POSITION=5;
 public static boolean violent(boolean explosion,double damage,double maxHealth){return explosion||Double.isFinite(damage)&&damage>=Math.max(24.0,1.25*Math.max(1,maxHealth));}
 public static boolean plausible(double x,double y,double z,double ox,double oy,double oz){return Double.isFinite(x)&&Double.isFinite(y)&&Double.isFinite(z)&&Math.abs(y-oy)<=512&&(x-ox)*(x-ox)+(z-oz)*(z-oz)<=16384;}
 public static boolean ready(long age,int stable){return age>=20&&stable>=12;}
}
