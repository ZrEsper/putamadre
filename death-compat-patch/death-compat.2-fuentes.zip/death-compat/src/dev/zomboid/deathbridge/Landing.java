package dev.zomboid.deathbridge;
/** Shared terrain tests; water is a supported surface, never a replacement target. */
public final class Landing {
 public static Object pos(double x,double y,double z){return R.call(R.type("net.minecraft.core.BlockPos"),"containing",x,y,z);}
 public static boolean water(Object state){Object fluid=R.call(state,"getFluidState");return R.yes(R.call(fluid,"is",R.get(R.type("net.minecraft.tags.FluidTags"),"WATER")));}
 public static boolean loaded(Object l,Object p){return R.yes(R.call(l,"isInWorldBounds",p))&&R.yes(R.call(l,"hasChunkAt",p));}
 public static boolean support(Object l,Object p){Object s=R.call(l,"getBlockState",p);if(water(s))return true;if(!R.yes(R.call(R.call(s,"getFluidState"),"isEmpty")))return false;
  Object shape=R.call(s,"getCollisionShape",l,p);return !R.yes(R.call(shape,"isEmpty"));
 }
 /** Checks the torso cell and the cell immediately below, including shallow water. */
 public static boolean touchingWater(Object l,double x,double y,double z){Object p=pos(x,y,z);return water(R.call(l,"getBlockState",p))||water(R.call(l,"getBlockState",R.call(p,"below")));}
 /** Returns the first dry cell above this water column, without draining any fluid. */
 public static Object waterSurface(Object l,double x,double y,double z){Object p=pos(x,y,z);if(!loaded(l,p))return null;
  if(!water(R.call(l,"getBlockState",p))){Object b=R.call(p,"below");if(!loaded(l,b)||!water(R.call(l,"getBlockState",b)))return null;p=b;}
  for(int i=0;i<384;i++){Object above=R.call(p,"offset",0,1,0);if(!loaded(l,above))return null;if(!water(R.call(l,"getBlockState",above)))return above;p=above;}return null;
 }
}
