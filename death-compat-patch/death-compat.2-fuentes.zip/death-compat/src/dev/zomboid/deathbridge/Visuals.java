package dev.zomboid.deathbridge;
import java.util.*;
/** Client-only class, loaded reflectively only by a client-bound handler. */
public final class Visuals {
 private static final Map<UUID,V> active=new HashMap<>();private static Object dimension;
 private static final class V {DeathPacket p;Object rag;List<Object> gibs=new ArrayList<>();int age,stable;boolean spawned,sent;int lastReport=-20,lastProgress;Object torso;double x,y,z;V(DeathPacket p){this.p=p;x=p.x();y=p.y();z=p.z();}}
 private static Object mc(){return R.call(R.type("net.minecraft.client.Minecraft"),"getInstance");}
 private static Object manager(){return R.call(R.type("de.sarocesch.sarosmobragdoll.client.ClientRagdollManager"),"get");}
 @SuppressWarnings("unchecked") private static List<Object> rags(){return (List<Object>)R.get(manager(),"ragdolls");}
 @SuppressWarnings("unchecked") private static List<Object> gibs(){return (List<Object>)R.get(R.get(R.type("me.ichun.mods.mobdismemberment.client.MobDismembermentClient"),"eventHandlerClient"),"activeGibs");}
 public static void accept(DeathPacket p){Object level=R.get(mc(),"level");if(level==null)return;resetIfChanged(level);
  if(p.kind()==Rules.END){V v=active.remove(p.token());if(v!=null)remove(v);return;}
  if(p.kind()!=Rules.RAGDOLL&&p.kind()!=Rules.DISMEMBER||active.containsKey(p.token()))return;
  V v=new V(p);active.put(p.token(),v);spawn(v,level);
 }
 private static void spawn(V v,Object level){if(v.spawned)return;DeathPacket p=v.p;
  try{if(p.kind()==Rules.RAGDOLL){Object registry=R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE");Object type=R.call(registry,"byId",p.typeId());List<Object> list=rags();int before=list.size();
    R.call(manager(),"spawn",type,p.entityId(),p.x(),p.y(),p.z(),(float)p.yaw(),(float)p.vx(),(float)p.vy(),(float)p.vz(),p.baby(),600);
    if(list.size()>before)v.rag=list.get(list.size()-1);v.spawned=true;
   }else{Object living=R.call(level,"getEntity",p.entityId());if(living==null)return;
    Object handler=R.get(R.type("me.ichun.mods.mobdismemberment.client.MobDismembermentClient"),"eventHandlerClient");List<Object> list=gibs();Set<Object> old=Collections.newSetFromMap(new IdentityHashMap<>());old.addAll(list);
    R.call(handler,"dismember",level,living,null);for(Object g:list)if(!old.contains(g))v.gibs.add(g);
    // Apply the authoritative, bounded launch to parts, including modded explosions.
    for(Object g:v.gibs){set(g,"motionX",p.vx()*.05+R.num(R.get(g,"motionX")));set(g,"motionY",Math.max(R.num(R.get(g,"motionY")),p.vy()*.05));set(g,"motionZ",p.vz()*.05+R.num(R.get(g,"motionZ")));}
    if(!v.gibs.isEmpty()){v.torso=torso(v.gibs);R.call(living,"discard");v.spawned=true;}else {v.p=new DeathPacket(p.token(),Rules.RAGDOLL,p.entityId(),p.typeId(),p.x(),p.y(),p.z(),p.vx(),p.vy(),p.vz(),p.yaw(),p.baby());spawn(v,level);}
   }
  }catch(RuntimeException e){R.warn("visual could not start; server keeps the loot",e);v.spawned=true;}
 }
 private static void set(Object o,String n,Object a){try{var f=o.getClass().getField(n);f.set(o,a);}catch(Exception e){throw new IllegalStateException(e);}}
 private static void resetIfChanged(Object level){if(level!=dimension){for(V v:active.values())remove(v);active.clear();dimension=level;}}
 public static void tick(){Object m=mc();Object level=R.get(m,"level");if(level==null){resetIfChanged(null);return;}resetIfChanged(level);if(R.yes(R.call(m,"isPaused")))return;
  for(V v:new ArrayList<>(active.values())){v.age++;if(!v.spawned)spawn(v,level);if(v.age>720){remove(v);active.remove(v.p.token());continue;}
   try{boolean quiet=false;double x=v.x,y=v.y,z=v.z;
    if(v.rag!=null&&!R.yes(R.call(v.rag,"isExpired"))){Object sk=R.get(v.rag,"skeleton");int idx=((Number)R.get(sk,"rootIndex")).intValue();Object root=R.call(v.rag,"body",idx);Object point=R.make("com.jme3.math.Vector3f");R.call(root,"getPhysicsLocation",point);x=R.num(R.get(point,"x"));y=R.num(R.get(point,"y"));z=R.num(R.get(point,"z"));
     quiet=true;Object vec=R.make("com.jme3.math.Vector3f");int count=((Number)R.call(v.rag,"bodyCount")).intValue();for(int i=0;i<count;i++){Object body=R.call(v.rag,"body",i);R.call(body,"getLinearVelocity",vec);if(R.num(R.call(vec,"lengthSquared"))>.025){quiet=false;break;}}
     Object surface=Landing.waterSurface(level,x,y,z);
     if(surface!=null){
      // Bullet has no water buoyancy: hold the torso at the surface rather than let it sink.
      double lift=R.coord(surface,"Y")+.12-y;Object velocity=R.make("com.jme3.math.Vector3f");boolean calm=true;for(int i=0;i<count;i++){Object body=R.call(v.rag,"body",i);Object bp=R.make("com.jme3.math.Vector3f");R.call(body,"getPhysicsLocation",bp);set(bp,"y",(float)(R.num(R.get(bp,"y"))+lift));R.call(body,"setPhysicsLocation",bp);R.call(body,"getLinearVelocity",velocity);set(velocity,"x",(float)(R.num(R.get(velocity,"x"))*.5));set(velocity,"y",0f);set(velocity,"z",(float)(R.num(R.get(velocity,"z"))*.5));R.call(body,"setLinearVelocity",velocity);calm &= R.num(R.get(velocity,"x"))*R.num(R.get(velocity,"x"))+R.num(R.get(velocity,"z"))*R.num(R.get(velocity,"z"))<.0025;}y=R.coord(surface,"Y")+.12;
      quiet=calm;
     }else{Object at=Landing.pos(x,y,z),below=R.call(at,"below");quiet &= Landing.support(level,below)||Landing.support(level,at);}
    }else if(!v.gibs.isEmpty()){quiet=true;for(Object g:v.gibs){if(!R.yes(R.call(g,"isRemoved"))&&(!R.yes(R.call(g,"onGround"))&&!R.yes(R.call(g,"isInWater"))&&!Landing.touchingWater(level,R.coord(g,"X"),R.coord(g,"Y"),R.coord(g,"Z"))||R.num(R.get(g,"motionX"))*R.num(R.get(g,"motionX"))+R.num(R.get(g,"motionZ"))*R.num(R.get(g,"motionZ"))>.0025))quiet=false;}
     if(v.torso!=null&&!R.yes(R.call(v.torso,"isRemoved"))){x=R.coord(v.torso,"X");y=R.coord(v.torso,"Y");z=R.coord(v.torso,"Z");}
    }else quiet=v.spawned||v.age>40;
    v.x=x;v.y=y;v.z=z;v.stable=quiet?v.stable+1:0;
    if((Rules.ready(v.age,v.stable)||v.age>=580)&&v.age-v.lastReport>=10){v.lastReport=v.age;v.sent=true;DeathPacket.toServer(v.p.finish(Rules.REPORT,x,y,z));}else if(v.age-v.lastProgress>=10){v.lastProgress=v.age;DeathPacket.toServer(v.p.finish(Rules.POSITION,x,y,z));}
   }catch(RuntimeException e){R.warn("visual tick failed; server timeout will recover corpse",e);if(v.age-v.lastReport>=20){v.lastReport=v.age;DeathPacket.toServer(v.p.finish(Rules.REPORT,v.x,v.y,v.z));}}
  }
 }

 private static Object torso(List<Object> parts){Object best=parts.get(0);int score=-1;for(Object g:parts){String name=String.valueOf(R.get(g,"partName")).toLowerCase(Locale.ROOT);int rank=name.matches(".*(head|arm|leg|hand|foot|tail|wing).*")?0:name.matches(".*(body|torso|chest|spine|trunk).*")?3:1;if(rank>score){score=rank;best=g;}}return best;}
 private static void remove(V v){try{if(v.rag!=null){R.call(v.rag,"remove");rags().remove(v.rag);}for(Object g:v.gibs)R.call(g,"discard");if(!v.gibs.isEmpty())gibs().removeAll(v.gibs);}catch(RuntimeException e){R.warn("visual cleanup",e);}}
 public static void clear(){for(V v:active.values())remove(v);active.clear();dimension=null;}
}
