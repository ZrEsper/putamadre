import java.net.*;import java.nio.file.*;import java.lang.reflect.*;
public final class NativeLayerChecks {
 public static void main(String[] a)throws Exception{
  // Parent models the PLUGIN layer; child models TRANSFORMER. No Minecraft double is used here.
  try(URLClassLoader parent=new URLClassLoader(new URL[]{Path.of(a[0]).toUri().toURL()},ClassLoader.getPlatformClassLoader());URLClassLoader child=new URLClassLoader(new URL[]{Path.of(a[1]).toUri().toURL(),Path.of(a[2]).toUri().toURL(),Path.of(a[3]).toUri().toURL()},parent)){
   Class.forName("WrongNative",true,child).getMethod("load",String.class).invoke(null,a[4]);
   Class<?> box=Class.forName("com.jme3.bullet.collision.shapes.BoxCollisionShape",true,parent);boolean broken=false;
   try{box.getConstructor(float.class,float.class,float.class).newInstance(.5f,.5f,.5f);}catch(InvocationTargetException e){broken=e.getCause() instanceof UnsatisfiedLinkError;}
   if(!broken)throw new AssertionError("Failed to reproduce user JNI layer error");System.out.println("PASS reproduced JNI UnsatisfiedLinkError with native loaded in child layer");
   Class.forName("dev.zomboid.deathbridge.NativeBinding",true,child).getMethod("load",String.class).invoke(null,a[4]);
   Object fixed=box.getConstructor(float.class,float.class,float.class).newInstance(.5f,.5f,.5f);if(fixed==null)throw new AssertionError();System.out.println("PASS library-owned loader repairs real JNI binding across layers");
   Class.forName("NativeFallScenario",true,child).getMethod("run").invoke(null);
  }
 }
}
