public final class WrongNative {public static void load(String p){System.load(p);}}
