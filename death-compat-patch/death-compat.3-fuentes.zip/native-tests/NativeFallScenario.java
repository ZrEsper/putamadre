import com.jme3.bullet.*;import com.jme3.bullet.objects.*;import com.jme3.bullet.collision.shapes.*;import com.jme3.math.*;import dev.zomboid.deathbridge.PhysicsTuning;
public final class NativeFallScenario {
 public static void run(){java.util.logging.Logger.getLogger(PhysicsRigidBody.class.getName()).setLevel(java.util.logging.Level.WARNING);
  for(float thin:new float[]{.12f,.02f,.008f}){PhysicsSpace world=new PhysicsSpace(new Vector3f(-100,-100,-100),new Vector3f(100,100,100),PhysicsSpace.BroadphaseType.DBVT);world.setGravity(new Vector3f(0,-9.81f,0));world.setAccuracy(1f/120);world.setMaxSubSteps(8);world.getSolverInfo().setNumIterations(16);
   PhysicsRigidBody floor=new PhysicsRigidBody(new BoxCollisionShape(50,.5f,50),0);floor.setPhysicsLocation(new Vector3f(0,-.5f,0));floor.setCollisionGroup(1);floor.setCollideWithGroups(2);world.addCollisionObject(floor);
   PhysicsRigidBody body=new PhysicsRigidBody(new BoxCollisionShape(.25f,thin,.4f),10);body.setPhysicsLocation(new Vector3f(0,5,0));body.setLinearVelocity(new Vector3f(6,-10,0));body.setCollisionGroup(2);body.setCollideWithGroups(7);PhysicsTuning.ccd(body,.1f);world.addCollisionObject(body);float min=Float.MAX_VALUE;for(int i=0;i<200;i++){world.update(.05f);min=Math.min(min,body.getPhysicsLocation(null).y);}Vector3f p=body.getPhysicsLocation(null);
   if(p.x<2||p.y<thin-.006||min<-.03)throw new AssertionError("Native floor penetration or no displacement: "+p+" min="+min);System.out.println("PASS real Bullet falling bone thickness "+thin+" lands at "+p+", not death origin; no floor tunneling");world.destroy();
  }
 }
}
