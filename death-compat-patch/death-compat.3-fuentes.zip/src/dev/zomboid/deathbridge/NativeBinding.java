package dev.zomboid.deathbridge;
import java.nio.file.*;
import java.io.*;
import java.security.MessageDigest;
import java.util.Arrays;
/** JNI must be loaded by Libbulletjme's own loader, not the child TRANSFORMER loader. */
public final class NativeBinding {
 public static synchronized void load(String oldPath){
  Path old=Path.of(oldPath);String original=old.getFileName().toString();String standard=original.replace("_18.1.0_","_");
  Path directory=old.toAbsolutePath().getParent().resolve("18.1.0-loader3");Path target=directory.resolve(standard);
  try(InputStream in=NativeBinding.class.getResourceAsStream("/natives/"+original)){
   if(in==null)throw new IOException("Missing bundled native "+original);byte[] bundled=in.readAllBytes();Files.createDirectories(directory);
   var sha=MessageDigest.getInstance("SHA-256");if(!Files.isRegularFile(target)||!Arrays.equals(sha.digest(Files.readAllBytes(target)),sha.digest(bundled))){Path tmp=Files.createTempFile(directory,"bullet-",".tmp");try{Files.write(tmp,bundled);Files.move(tmp,target,StandardCopyOption.REPLACE_EXISTING);}finally{Files.deleteIfExists(tmp);}}
   Class<?> owner=R.type("com.jme3.system.NativeLibraryLoader");Class<?> shape=R.type("com.jme3.bullet.collision.shapes.BoxCollisionShape");
   if(owner.getClassLoader()!=shape.getClassLoader())throw new IOException("Native loader and Bullet classes must share a loader");
   if(!R.yes(R.call(owner,"loadLibbulletjme",true,directory.toFile(),"Release","Sp")))throw new IOException("Bullet native loader returned false");
   // Readiness means an actual native allocation succeeds, not merely System.load.
   R.make("com.jme3.bullet.collision.shapes.BoxCollisionShape",.5f,.5f,.5f);
   System.out.println("[death-compat] Bullet JNI ready using library-owned loader and verified bundled binary");
  }catch(Exception e){throw new IllegalStateException("Cannot bind bundled Bullet native to its class loader",e);}
 }
}
