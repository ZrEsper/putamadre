import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;import java.nio.file.*;import java.util.*;import java.util.zip.*;
public class Patch implements Opcodes {
 static MethodInsnNode call(String o,String n,String d){return new MethodInsnNode(INVOKESTATIC,o,n,d,false);}static void reset(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;}
 public static void main(String[] args)throws Exception{int count=0;
  for(int base=0;base<3;base++){try(ZipFile z=new ZipFile(args[base])){
   List<String> names=base==0?List.of("de/sarocesch/sarosmobragdoll/SarosRagdollMod","de/sarocesch/sarosmobragdoll/network/NetworkHandler","de/sarocesch/sarosmobragdoll/client/MobRagdollClient","de/sarocesch/sarosmobragdoll/client/ClientMobRagdoll","de/sarocesch/sarosmobragdoll/ragdoll/physics/NativeInstaller","de/sarocesch/sarosmobragdoll/ragdoll/physics/BoneRagdollPhysics","de/sarocesch/sarosmobragdoll/ragdoll/physics/BasePhysicsWorld"):base==1?List.of("me/ichun/mods/mobdismemberment/client/core/EventHandlerClient","me/ichun/mods/mobdismemberment/client/render/RenderGib"):List.of("dev/zomboid/remains/ZombieRemainsLoot","dev/zomboid/remains/ZombieRemainsLoot$CorpseData");
   for(String name:names){ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class"))).accept(c,ClassReader.EXPAND_FRAMES);int changes=0;
    for(MethodNode m:c.methods){
     if(name.endsWith("SarosRagdollMod")&&m.name.equals("onLivingDeath")){reset(m);m.instructions.add(new InsnNode(RETURN));changes++;}
     if(name.endsWith("NetworkHandler")&&m.name.equals("register")){InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,0));i.add(call("dev/zomboid/deathbridge/DeathPacket","register",m.desc));m.instructions.insert(i);changes++;}
     if(name.endsWith("MobRagdollClient")&&m.name.equals("onClientTick")){for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.name.equals("clientTick")){m.instructions.insert(i,call("dev/zomboid/deathbridge/Visuals","tick","()V"));changes++;}}
     if(name.endsWith("EventHandlerClient")&&m.name.equals("queueDismember")){reset(m);m.instructions.add(new InsnNode(RETURN));changes++;}
     if(name.endsWith("NativeInstaller")&&m.name.equals("load")){for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.owner.equals("java/lang/System")&&x.name.equals("load")){x.owner="dev/zomboid/deathbridge/NativeBinding";changes++;}}
     if(name.endsWith("BoneRagdollPhysics")&&m.name.equals("build")){for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.name.equals("setCcdSweptSphereRadius")){x.setOpcode(INVOKESTATIC);x.owner="dev/zomboid/deathbridge/PhysicsTuning";x.name="ccd";x.desc="(Ljava/lang/Object;F)V";x.itf=false;changes++;}else if(i instanceof MethodInsnNode x&&x.name.equals("setDamping")&&x.desc.equals("(FF)V")){x.setOpcode(INVOKESTATIC);x.owner="dev/zomboid/deathbridge/PhysicsTuning";x.name="damping";x.desc="(Ljava/lang/Object;FF)V";x.itf=false;changes++;}}
     if(name.endsWith("BasePhysicsWorld")&&m.name.equals("initPhysicsWorld")){for(AbstractInsnNode i:m.instructions.toArray()){if(i instanceof MethodInsnNode x&&x.name.equals("setAccuracy")){AbstractInsnNode value=i.getPrevious();if(!(value instanceof LdcInsnNode))throw new IllegalStateException("Accuracy constant");((LdcInsnNode)value).cst=1f/60f;changes++;}if(i instanceof MethodInsnNode x&&x.name.equals("setMaxSubSteps")){AbstractInsnNode value=i.getPrevious();if(value.getOpcode()!=ICONST_4)throw new IllegalStateException("Substeps constant");m.instructions.set(value,new InsnNode(ICONST_4));changes++;}}}
     if(name.endsWith("ClientMobRagdoll")&&m.name.equals("alpha")){for(AbstractInsnNode i:m.instructions.toArray())if(i.getOpcode()==FRETURN){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(FLOAD,1));l.add(call("dev/zomboid/deathbridge/Visuals","alpha","(FLjava/lang/Object;F)F"));m.instructions.insertBefore(i,l);}changes++;}
     if(name.endsWith("RenderGib")&&m.name.equals("render")&&m.desc.contains("EntityGib")){for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.owner.equals("net/minecraft/util/Mth")&&x.name.equals("clamp")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(FLOAD,3));l.add(call("dev/zomboid/deathbridge/Visuals","gibAlpha","(FLjava/lang/Object;F)F"));m.instructions.insert(i,l);changes++;}}
     if(name.endsWith("ZombieRemainsLoot")){
      if(m.name.equals("death")){reset(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(call("dev/zomboid/remains/DeathSequence","drops","(Ljava/lang/Object;)V"));m.instructions.add(new InsnNode(RETURN));changes++;}
      if(m.name.equals("cleanup")){InsnList i=new InsnList();i.add(new VarInsnNode(ALOAD,0));i.add(call("dev/zomboid/remains/DeathSequence","tick","(Ljava/lang/Object;)V"));m.instructions.insert(i);changes++;}
     }
     if(name.endsWith("$CorpseData")){
      if(m.name.equals("load")){for(AbstractInsnNode i:m.instructions.toArray())if(i.getOpcode()==ARETURN){InsnList l=new InsnList();l.add(new InsnNode(DUP));l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(ALOAD,1));l.add(call("dev/zomboid/remains/DeathSequence","load","(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V"));m.instructions.insertBefore(i,l);changes++;}}
      if(m.name.equals("save")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(ALOAD,2));l.add(call("dev/zomboid/remains/DeathSequence","save","(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V"));m.instructions.insert(l);changes++;}
     }
    }
    int expected=name.endsWith("ZombieRemainsLoot")||name.endsWith("$CorpseData")||name.endsWith("BasePhysicsWorld")||name.endsWith("BoneRagdollPhysics")?2:1;if(changes!=expected)throw new IllegalStateException(name+" changed "+changes);
    ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] out=w.toByteArray();ClassNode check=new ClassNode();new ClassReader(out).accept(check,0);for(MethodNode m:check.methods)if(m.instructions.size()>0){new Analyzer<>(new BasicVerifier()).analyze(check.name,m);count++;}
    Path p=Path.of(args[3],""+base,name+".class");Files.createDirectories(p.getParent());Files.write(p,out);
   }
  }}System.out.println("PASS ASM verification of "+count+" original/transformed methods");
 }
}
