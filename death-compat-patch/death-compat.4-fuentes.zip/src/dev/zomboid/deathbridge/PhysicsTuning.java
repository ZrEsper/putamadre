package dev.zomboid.deathbridge;
/** CCD sphere must fit inside each small bone's actual collision box. */
public final class PhysicsTuning {
 public static void damping(Object body,float linear,float angular){R.call(body,"setDamping",linear,Math.min(angular,.10f));}
 public static void ccd(Object body,float previous){Object half=R.make("com.jme3.math.Vector3f");R.call(R.call(body,"getCollisionShape"),"getHalfExtents",half);float radius=(float)Math.max(.004,Math.min(R.num(R.get(half,"x")),Math.min(R.num(R.get(half,"y")),R.num(R.get(half,"z"))))*.8);R.call(body,"setCcdSweptSphereRadius",radius);R.call(body,"setCcdMotionThreshold",Math.max(.002f,radius*.5f));}
}
