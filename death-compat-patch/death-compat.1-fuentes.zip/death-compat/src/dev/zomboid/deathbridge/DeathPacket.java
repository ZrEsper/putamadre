package dev.zomboid.deathbridge;
import java.util.UUID;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.PacketDistributor;
public record DeathPacket(UUID token,int kind,int entityId,int typeId,double x,double y,double z,double vx,double vy,double vz,double yaw,boolean baby) implements CustomPacketPayload {
 public static final Type<DeathPacket> TYPE=new Type<>(ResourceLocation.fromNamespaceAndPath("saros_mob_ragdoll","death_sequence_v1"));
 public static final StreamCodec<FriendlyByteBuf,DeathPacket> CODEC=StreamCodec.of((b,p)->p.write(b),DeathPacket::read);
 private static DeathPacket read(FriendlyByteBuf b){return new DeathPacket(b.readUUID(),b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readDouble(),b.readDouble(),b.readDouble(),b.readDouble(),b.readDouble(),b.readDouble(),b.readDouble(),b.readBoolean());}
 private void write(FriendlyByteBuf b){b.writeUUID(token);b.writeVarInt(kind);b.writeVarInt(entityId);b.writeVarInt(typeId);b.writeDouble(x);b.writeDouble(y);b.writeDouble(z);b.writeDouble(vx);b.writeDouble(vy);b.writeDouble(vz);b.writeDouble(yaw);b.writeBoolean(baby);}
 public Type<DeathPacket> type(){return TYPE;}
 public static void register(RegisterPayloadHandlersEvent e){e.registrar("death-sequence-1").playBidirectional(TYPE,CODEC,(p,c)->{if(R.type("net.minecraft.server.level.ServerPlayer").isInstance(c.player()))server(p,c);else client(p,c);});}
 private static void client(DeathPacket p,IPayloadContext c){c.enqueueWork(()->R.call(R.type("dev.zomboid.deathbridge.Visuals"),"accept",p));}
 private static void server(DeathPacket p,IPayloadContext c){c.enqueueWork(()->{if(p.kind==Rules.REPORT)R.call(R.type("dev.zomboid.remains.DeathSequence"),"report",p,c.player());});}
 public static void toServer(DeathPacket p){PacketDistributor.sendToServer(p);}
 public static void toPlayer(DeathPacket p,Object player){R.call(R.type("net.neoforged.neoforge.network.PacketDistributor"),"sendToPlayer",player,p,new CustomPacketPayload[0]);}
 public DeathPacket finish(int k,double px,double py,double pz){return new DeathPacket(token,k,entityId,typeId,px,py,pz,0,0,0,0,false);}
}
