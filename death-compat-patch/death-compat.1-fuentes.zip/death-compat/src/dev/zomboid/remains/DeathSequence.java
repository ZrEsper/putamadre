package dev.zomboid.remains;
import dev.zomboid.deathbridge.*;
import java.util.*;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
@EventBusSubscriber(modid="zombie_remains_loot")
public final class DeathSequence {
 private static final Map<Object,Map<UUID,T>> pending=new WeakHashMap<>();
 private static final Map<Object,Map<UUID,D>> deaths=new WeakHashMap<>();
 private static final Map<Object,Hit> hits=new WeakHashMap<>();
 private record Hit(long tick,double damage,Object source){}
 private static final class D {DeathPacket packet;long born;Set<UUID> viewers=new HashSet<>();boolean done;double x,y,z;D(DeathPacket p,long now){packet=p;born=now;x=p.x();y=p.y();z=p.z();}}
 private static final class T {D death;Object corpse;int pose;boolean ended;T(D d,Object c,int pose){death=d;corpse=c;this.pose=pose;}}
 private static Object level(Object e){return R.call(e,"level");}private static long now(Object l){return R.lng(R.call(l,"getGameTime"));}private static UUID id(Object e){return (UUID)R.call(e,"getUUID");}
 private static boolean server(Object l){return R.type("net.minecraft.server.level.ServerLevel").isInstance(l);}private static Object data(Object l){return R.call(R.type("dev.zomboid.remains.ZombieRemainsLoot"),"data",l);}
 private static Map<UUID,D> ds(Object l){return deaths.computeIfAbsent(l,k->new HashMap<>());}private static Map<UUID,T> ps(Object d){return pending.computeIfAbsent(d,k->new LinkedHashMap<>());}
 @SubscribeEvent(priority=EventPriority.LOWEST)
 public static void damage(LivingDamageEvent.Pre e){Object entity=R.call(e,"getEntity"),l=level(entity);if(server(l))hits.put(entity,new Hit(now(l),R.num(R.call(e,"getNewDamage")),R.call(e,"getSource")));}
 @SubscribeEvent(priority=EventPriority.LOWEST)
 public static void death(LivingDeathEvent e){if(R.yes(R.call(e,"isCanceled")))return;Object entity=R.call(e,"getEntity"),l=level(entity);if(!server(l)||R.type("net.minecraft.world.entity.player.Player").isInstance(entity)||deferMutant(entity))return;
  if(ds(l).containsKey(id(entity)))return;
  Object source=R.call(e,"getSource");Hit h=hits.remove(entity);double damage=h!=null&&h.tick==now(l)&&h.source==source?h.damage:0;
  Object tag=R.get(R.type("net.minecraft.tags.DamageTypeTags"),"IS_EXPLOSION");boolean explosion=R.yes(R.call(source,"is",tag));
  int kind=Rules.violent(explosion,damage,R.num(R.call(entity,"getMaxHealth")))?Rules.DISMEMBER:Rules.RAGDOLL;
  double vx=0,vy=.8,vz=0;Object velocity=R.call(entity,"getDeltaMovement");vx=R.num(R.get(velocity,"x"));vy+=Math.max(-.5,Math.min(1,R.num(R.get(velocity,"y"))));vz=R.num(R.get(velocity,"z"));
  Object attacker=R.call(source,"getEntity");if(attacker!=null){double dx=R.coord(entity,"X")-R.coord(attacker,"X"),dz=R.coord(entity,"Z")-R.coord(attacker,"Z"),len=Math.hypot(dx,dz);if(len>.01){vx+=dx/len*(explosion?4:1.5);vz+=dz/len*(explosion?4:1.5);}}
  Object registry=R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE");
  DeathPacket p=new DeathPacket(UUID.randomUUID(),kind,((Number)R.call(entity,"getId")).intValue(),((Number)R.call(registry,"getId",R.call(entity,"getType"))).intValue(),R.coord(entity,"X"),R.coord(entity,"Y"),R.coord(entity,"Z"),Math.max(-6,Math.min(6,vx)),Math.max(.2,Math.min(3,vy)),Math.max(-6,Math.min(6,vz)),R.num(R.get(entity,"yBodyRot")),R.yes(R.call(entity,"isBaby")));
  D d=new D(p,now(l));ds(l).put(id(entity),d);
  for(Object player:(Iterable<?>)R.call(l,"players")){if(distance(player,p.x(),p.y(),p.z())<=128*128){d.viewers.add(id(player));DeathPacket.toPlayer(p,player);}}
 }
 private static boolean deferMutant(Object entity){Object registry=R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE");String key=String.valueOf(R.call(registry,"getKey",R.call(entity,"getType")));if(!key.equals("mutantmonsters:mutant_zombie"))return false;try{return R.num(R.call(entity,"getRemainingLives"))>0;}catch(RuntimeException e){return true;}}
 private static double distance(Object e,double x,double y,double z){return Math.pow(R.coord(e,"X")-x,2)+Math.pow(R.coord(e,"Y")-y,2)+Math.pow(R.coord(e,"Z")-z,2);}
 /** Replaces only the drops handler, keeping the native loot population routines. */
 public static void drops(Object event){Object entity=R.call(event,"getEntity"),l=level(entity);if(!server(l))return;
  Object nativeType=R.type("dev.zomboid.remains.ZombieRemainsLoot");Object reg=R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE");String key=String.valueOf(R.call(reg,"getKey",R.call(entity,"getType")));
  boolean bandit=NpcCompatibility.isBandit(entity),mutant=R.yes(R.call(R.type("dev.zomboid.remains.MutantIntegration"),"mutant",entity));
  boolean vanilla=Set.of("minecraft:zombie","minecraft:husk","minecraft:drowned","minecraft:zombie_villager").contains(key);
  boolean modded=R.yes(R.get(R.get(nativeType,"settings"),"includeModdedZombies"))&&R.type("net.minecraft.world.entity.monster.Zombie").isInstance(entity)&&!R.type("net.minecraft.world.entity.monster.ZombifiedPiglin").isInstance(entity);
  if(!(vanilla||modded||bandit||mutant)||deferMutant(entity))return;
  Object ddata=data(l);D d=ds(l).get(id(entity));if(d==null){DeathPacket p=new DeathPacket(UUID.randomUUID(),Rules.RAGDOLL,((Number)R.call(entity,"getId")).intValue(),0,R.coord(entity,"X"),R.coord(entity,"Y"),R.coord(entity,"Z"),0,0,0,R.num(R.call(entity,"getYRot")),false);d=new D(p,now(l));d.done=true;ds(l).put(id(entity),d);}
  if(ps(ddata).containsKey(d.packet.token()))return;
  Object random=R.get(l,"random");int[] floors=(int[])R.get(R.type("dev.zomboid.remains.RemainsRules"),"FLOOR");int pose=floors[((Number)R.call(random,"nextInt",floors.length)).intValue()];Object state=state(pose,d.packet.yaw());if(state==null)return;
  Object corpse=R.make("dev.zomboid.remains.ZombieRemainsLoot$Corpse",ddata,String.valueOf(R.call(nativeType,"blockId",state)),mutant);
  set(corpse,"born",now(l));int quality=((Number)R.call(R.type(mutant?"dev.zomboid.remains.MutantRules":"dev.zomboid.remains.QualityRules"),mutant?"quality":"roll",mutant?new Object[]{R.call(random,"nextDouble")}:new Object[]{R.call(random,"nextDouble"),bandit})).intValue();set(corpse,"quality",quality);
  if(mutant)R.call(nativeType,"populateMutant",corpse,l);else if(bandit)R.call(nativeType,"populateBandit",corpse,l,entity);else R.call(nativeType,"populate",corpse,l);
  set(corpse,"randomized",true);
  Collection<?> drops=(Collection<?>)R.call(event,"getDrops");
  if(!bandit)for(Object drop:drops){Object stack=R.call(drop,"getItem"),item=R.call(stack,"getItem");Object ir=R.get(R.type("net.minecraft.core.registries.BuiltInRegistries"),"ITEM");Object itemId=R.call(ir,"getKey",item);
   if(!mutant&&!R.type("net.minecraft.world.item.ArmorItem").isInstance(item)&&!R.type("net.minecraft.world.item.TieredItem").isInstance(item)&&(!String.valueOf(R.call(itemId,"getNamespace")).equals("tacz")||String.valueOf(R.call(itemId,"getPath")).equals("ammo")))continue;
   R.call(nativeType,"add",corpse,R.call(stack,"copy"));
  }
  NpcCompatibility.extras(corpse,l,bandit,mutant,entity);
  ps(ddata).put(d.packet.token(),new T(d,corpse,pose));R.call(ddata,"setDirty");drops.clear();
 }
 private static Object state(int pose,double yaw){Object dir=R.call(R.type("net.minecraft.core.Direction"),"fromYRot",yaw);return R.call(R.type("dev.zomboid.remains.ZombieRemainsLoot"),"poseState",pose,0,dir);}
 private static void set(Object o,String n,Object val){try{Class<?> c=o.getClass();for(;c!=null;c=c.getSuperclass())try{var f=c.getDeclaredField(n);f.setAccessible(true);f.set(o,val);return;}catch(NoSuchFieldException ignored){}throw new NoSuchFieldException(n);}catch(Exception e){throw new IllegalStateException(n,e);}}
 public static void report(DeathPacket p,Object player){Object l=level(player);if(!server(l)||p.kind()!=Rules.REPORT)return;for(D d:ds(l).values()){
   if(!d.packet.token().equals(p.token())||d.done||!d.viewers.contains(id(player))||now(l)-d.born<20||distance(player,d.packet.x(),d.packet.y(),d.packet.z())>160*160||!Rules.plausible(p.x(),p.y(),p.z(),d.packet.x(),d.packet.y(),d.packet.z()))continue;
   Object pos=floor(l,p.x(),p.y(),p.z());if(pos==null)continue;d.x=R.coord(pos,"X")+.5;d.y=R.coord(pos,"Y");d.z=R.coord(pos,"Z")+.5;d.done=true;R.call(data(l),"setDirty");end(l,d);return;
  }
 }
 private static void end(Object l,D d){DeathPacket end=d.packet.finish(Rules.END,d.x,d.y,d.z);for(Object player:(Iterable<?>)R.call(l,"players"))if(d.viewers.contains(id(player)))DeathPacket.toPlayer(end,player);}
 /** No chunk is forced into memory, and no existing block or corpse is overwritten. */
 public static Object floor(Object l,double x,double y,double z){Object origin=R.call(R.type("net.minecraft.core.BlockPos"),"containing",x,y,z);Object up=R.get(R.type("net.minecraft.core.Direction"),"UP");Object ddata=data(l);Map<?,?> corpses=(Map<?,?>)R.get(ddata,"corpses");
  for(int dy=1;dy>=-128;dy--)for(int radius=0;radius<=3;radius++)for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++){
   if(Math.max(Math.abs(dx),Math.abs(dz))!=radius)continue;Object pos=R.call(origin,"offset",dx,dy,dz);if(!R.yes(R.call(l,"isInWorldBounds",pos))||!R.yes(R.call(l,"hasChunkAt",pos))||corpses.containsKey(R.lng(R.call(pos,"asLong"))))continue;
   Object state=R.call(l,"getBlockState",pos);if(!R.yes(R.call(state,"canBeReplaced"))||!R.yes(R.call(R.call(state,"getFluidState"),"isEmpty")))continue;
   Object below=R.call(pos,"below");if(R.yes(R.call(R.call(l,"getBlockState",below),"isFaceSturdy",l,below,up)))return pos;
  }return null;
 }
 public static void tick(Object event){Object server=R.call(event,"getServer");for(Object l:(Iterable<?>)R.call(server,"getAllLevels")){long time=now(l);Object ddata=data(l);
   for(T t:new ArrayList<>(ps(ddata).values())){D d=t.death;long age=time-d.born;if(!d.done&&age>=600){d.done=true;end(l,d);}if(!d.done)continue;
    if(!t.ended){end(l,d);t.ended=true;}
    if(age>600&&time%20!=0)continue;
    Object pos=floor(l,d.x,d.y,d.z);if(pos==null)continue;Object block=state(t.pose,d.packet.yaw());if(block==null||!R.yes(R.call(l,"setBlock",pos,block,3)))continue;
    set(t.corpse,"born",time);((Map<Long,Object>)R.get(ddata,"corpses")).put(R.lng(R.call(pos,"asLong")),t.corpse);ps(ddata).remove(d.packet.token());R.call(ddata,"setDirty");
    R.call(l,"playSound",null,pos,R.call(R.get(R.type("dev.zomboid.remains.CorpseSounds"),"BLOOD"),"get"),R.get(R.type("net.minecraft.sounds.SoundSource"),"HOSTILE"),.9f,1.0f);
   }
   Iterator<D> it=ds(l).values().iterator();while(it.hasNext()){D d=it.next();if(time-d.born>=600&&!d.done){d.done=true;end(l,d);}if(d.done&&!ps(ddata).containsKey(d.packet.token()))it.remove();}
  }
 }
 /** Pending inventory is part of the existing SavedData, not a transient client cache. */
 public static void save(Object ddata,Object tag,Object provider){Object list=R.make("net.minecraft.nbt.ListTag");for(T t:ps(ddata).values()){Object entry=R.make("net.minecraft.nbt.CompoundTag");D d=t.death;R.call(entry,"putUUID","Token",d.packet.token());R.call(entry,"putDouble","X",d.x);R.call(entry,"putDouble","Y",d.y);R.call(entry,"putDouble","Z",d.z);R.call(entry,"putLong","Born",d.born);R.call(entry,"putDouble","Yaw",d.packet.yaw());R.call(entry,"putInt","Pose",t.pose);R.call(entry,"putBoolean","Done",d.done);R.call(entry,"putString","Block",R.get(t.corpse,"block"));R.call(entry,"putInt","Quality",R.get(t.corpse,"quality"));R.call(entry,"putBoolean","Mutant",R.get(t.corpse,"mutant"));
   Object items=R.make("net.minecraft.nbt.ListTag"),inv=R.get(t.corpse,"inventory");int size=((Number)R.call(inv,"getContainerSize")).intValue();for(int i=0;i<size;i++){Object stack=R.call(inv,"getItem",i);if(R.yes(R.call(stack,"isEmpty")))continue;Object s=R.call(stack,"save",provider);R.call(s,"putInt","Slot",i);R.call(items,"add",s);}R.call(entry,"put","Items",items);R.call(list,"add",entry);
  }R.call(tag,"put","PendingDeathCorpsesV1",list);
 }
 public static void load(Object ddata,Object tag,Object provider){Object list=R.call(tag,"getList","PendingDeathCorpsesV1",10);for(int i=0;i<((Number)R.call(list,"size")).intValue();i++){
   Object e=R.call(list,"getCompound",i);UUID token=(UUID)R.call(e,"getUUID","Token");double x=R.num(R.call(e,"getDouble","X")),y=R.num(R.call(e,"getDouble","Y")),z=R.num(R.call(e,"getDouble","Z"));DeathPacket p=new DeathPacket(token,Rules.RAGDOLL,-1,0,x,y,z,0,0,0,R.num(R.call(e,"getDouble","Yaw")),false);D d=new D(p,R.lng(R.call(e,"getLong","Born")));d.done=true;
   Object c=R.make("dev.zomboid.remains.ZombieRemainsLoot$Corpse",ddata,String.valueOf(R.call(e,"getString","Block")),R.yes(R.call(e,"getBoolean","Mutant")));set(c,"quality",Math.max(0,Math.min(4,((Number)R.call(e,"getInt","Quality")).intValue())));set(c,"randomized",true);
   Object items=R.call(e,"getList","Items",10),inv=R.get(c,"inventory");for(int j=0;j<((Number)R.call(items,"size")).intValue();j++){Object item=R.call(items,"getCompound",j);int slot=((Number)R.call(item,"getInt","Slot")).intValue();if(slot>=0&&slot<((Number)R.call(inv,"getContainerSize")).intValue())R.call(inv,"setItem",slot,R.call(R.type("net.minecraft.world.item.ItemStack"),"parseOptional",provider,item));}
   ps(ddata).put(token,new T(d,c,((Number)R.call(e,"getInt","Pose")).intValue()));
  }if(!ps(ddata).isEmpty())R.call(ddata,"setDirty");
 }
}
