from pathlib import Path
import subprocess,sys,zipfile,copy,hashlib,json
r=Path(__file__).resolve().parent
if len(sys.argv)!=4:raise SystemExit('Usage: build.py Saros-original.jar dismemberment-original.jar remains-npc-compat-original.jar')
bases=list(map(lambda s:Path(s).resolve(),sys.argv[1:]));expected=json.loads((r/'bases.sha256.json').read_text())
for i,p in enumerate(bases):assert hashlib.sha256(p.read_bytes()).hexdigest()==expected[str(i)],'Unexpected base '+str(p)
for n,sha in json.loads((r/'tools.sha256.json').read_text()).items():assert hashlib.sha256((r/'tools'/n).read_bytes()).hexdigest()==sha
asm=':'.join(map(str,(r/'tools').glob('asm*.jar')));ecj=['java','-jar',str(r/'tools/ecj.jar'),'-21','-proc:none','-warn:none']
def run(*a):subprocess.run(list(a),check=True)
run(*ecj,'-cp',str(bases[2]),'-d',str(r/'classes'),*[str(p) for f in ['src','stubs'] for p in (r/f).rglob('*.java')])
run(*ecj,'-cp',asm,'-d',str(r/'patch-tool'),str(r/'Patch.java'))
run('java','-cp',str(r/'patch-tool')+':'+asm,'Patch',*map(str,bases),str(r/'patched'))
if (r/'tests').exists():
 run(*ecj,'-cp',str(r/'classes'),'-d',str(r/'test-classes'),*[str(p) for p in (r/'tests').rglob('*.java')])
 run('java','-Xverify:all','-cp',str(r/'test-classes')+':'+str(r/'classes'),'DeathChecks')
outputs=['Saros-Mob-Ragdoll-NeoForge-1.21.1-1.0.1-death-compat.1.jar','mobdismembermentneoforge-1.21.1-1.4.0-death-compat.1.jar','zombie-remains-loot-1.6.2-neoforge-1.21.1-death-compat.1.jar']
ids=['saros_mob_ragdoll','mobdismemberment','zombie_remains_loot'];versions=['1.0.1-deathcompat.1','1.21.1-1.4.0-deathcompat.1','1.6.2-deathcompat.1']
for i,base in enumerate(bases):
 add={p.relative_to(r/'patched'/str(i)).as_posix():p.read_bytes() for p in (r/'patched'/str(i)).rglob('*.class')}
 root=r/'classes/dev/zomboid'/('deathbridge' if i==0 else 'remains')
 if i!=1:add.update({p.relative_to(r/'classes').as_posix():p.read_bytes() for p in root.rglob('*.class')})
 with zipfile.ZipFile(base) as z:
  import re
  toml=z.read('META-INF/neoforge.mods.toml').decode();toml=re.sub(r'(?m)^version\s*=\s*"[^"]+"',f'version="{versions[i]}"',toml,count=1)
  dependencies={0:[(1,'CLIENT'),(2,'BOTH')],1:[(0,'CLIENT')],2:[(0,'BOTH')]}
  for j,side in dependencies[i]:toml+=f'\n[[dependencies.{ids[i]}]]\nmodId="{ids[j]}"\ntype="required"\nversionRange="[{versions[j]}]"\nordering="NONE"\nside="{side}"\n'
  add['META-INF/neoforge.mods.toml']=toml.encode();modified=set(add);out=r/'output'/outputs[i];out.parent.mkdir(exist_ok=True)
  with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
   for e in z.infolist():w.writestr(copy.copy(e),add.pop(e.filename,z.read(e)))
   for n,b in sorted(add.items()):w.writestr(n,b)
  with zipfile.ZipFile(out) as w:
   assert w.testzip() is None
   for n in z.namelist():
    if n not in modified:assert z.read(n)==w.read(n),n
   assert not any(n.startswith('net/') for n in w.namelist())
 print('PASS preserved original resources/classes:',out.name)
