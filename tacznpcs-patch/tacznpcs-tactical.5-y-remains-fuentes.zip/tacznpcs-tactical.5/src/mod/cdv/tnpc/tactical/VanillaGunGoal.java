package mod.cdv.tnpc.tactical;
import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;
/** Vanilla ranged navigation, looking and shot timing, adapted to TACZ instead of arrows. */
public final class VanillaGunGoal extends Goal {
 final Object mob,delegate;Object last;
 public VanillaGunGoal(Object mob)throws Exception {this.mob=mob;delegate=Reflect.construct("net.minecraft.world.entity.ai.goal.RangedAttackGoal",mob,1.1,12,24,18f);setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
 public boolean canUse(){try{return CalmBrain.alive(CalmBrain.state(mob).target)&&CalmBrain.gun(mob);}catch(Exception e){CalmBrain.error("gun goal",e);return false;}}
 public boolean requiresUpdateEveryTick(){return true;}
 public void tick(){try {
  CalmBrain.State s=CalmBrain.state(mob);Object target=s.target;if(target==null)return;long time=CalmBrain.now(mob);
  if(last!=target){Reflect.call(delegate,"stop");last=target;}
  if(!CalmBrain.visible(mob,target)){Reflect.call(mob,"aim",false);if(s.seen>=0&&time-s.seen<=80)CalmBrain.path(mob,s,time,s.x,s.y,s.z,1.1);return;}
  CalmBrain.face(mob,target);
  if(Reflect.yes(Reflect.call(delegate,"canUse")))Reflect.call(delegate,"tick");
  // Vanilla ranged goals stop in range. Close zombies need one bounded retreat, not orbiting.
  double d=Math.sqrt(CalmBrain.distance(mob,target));
  if(d<4.5&&s.zombies>0){double dx=Reflect.coord(mob,"X")-Reflect.coord(target,"X"),dz=Reflect.coord(mob,"Z")-Reflect.coord(target,"Z"),len=Math.max(.01,Math.hypot(dx,dz));CalmBrain.path(mob,s,time,Reflect.coord(mob,"X")+dx/len*3,Reflect.coord(mob,"Y"),Reflect.coord(mob,"Z")+dz/len*3,1.1);}
  if(d>18&&Reflect.yes(Reflect.call(mob,"isInWater"))&&Reflect.yes(Reflect.call(Reflect.call(mob,"getNavigation"),"isDone")))CalmBrain.path(mob,s,time,Reflect.coord(target,"X"),Reflect.coord(target,"Y"),Reflect.coord(target,"Z"),1.1);
  boolean moving=!Reflect.yes(Reflect.call(Reflect.call(mob,"getNavigation"),"isDone"));Reflect.call(mob,"aim",!moving&&d<=18);
 }catch(Exception e){CalmBrain.error("vanilla gun goal",e);}}
 public void stop(){try{Reflect.call(delegate,"stop");Reflect.call(mob,"aim",false);CalmBrain.crouch(mob,false);Reflect.call(Reflect.call(mob,"getNavigation"),"stop");last=null;}catch(Exception e){CalmBrain.error("gun stop",e);}}
}
