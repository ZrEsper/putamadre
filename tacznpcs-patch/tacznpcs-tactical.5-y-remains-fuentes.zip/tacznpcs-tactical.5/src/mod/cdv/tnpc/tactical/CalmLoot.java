package mod.cdv.tnpc.tactical;
import java.util.*;
public final class CalmLoot {
 static final String INVENTORY="TacZNpcCalmInventory",OUTFIT="TacZNpcCalmOutfit";
 static final String[] SLOTS={"HEAD","CHEST","LEGS","FEET"};
 static Object slot(String name)throws Exception{return Reflect.field(Reflect.type("net.minecraft.world.entity.EquipmentSlot"),name);}
 static boolean empty(Object stack)throws Exception{return Reflect.yes(Reflect.call(stack,"isEmpty"));}
 static Object item(Object stack)throws Exception{return Reflect.call(stack,"getItem");}
 static Object emptyStack()throws Exception{return Reflect.field(Reflect.type("net.minecraft.world.item.ItemStack"),"EMPTY");}
 static Object persistent(Object mob)throws Exception{return Reflect.call(mob,"getPersistentData");}
 static Object registry(Object mob)throws Exception{return Reflect.call(Reflect.call(mob,"level"),"registryAccess");}
 static String id(Object stack)throws Exception{return String.valueOf(Reflect.call(Reflect.field(Reflect.type("net.minecraft.core.registries.BuiltInRegistries"),"ITEM"),"getKey",item(stack)));}
 static Object stack(String id)throws Exception {Object registry=Reflect.field(Reflect.type("net.minecraft.core.registries.BuiltInRegistries"),"ITEM");Object location=Reflect.call(Reflect.type("net.minecraft.resources.ResourceLocation"),"parse",id);Object value=Reflect.call(registry,"get",location);if(value==null||!id.equals(String.valueOf(Reflect.call(registry,"getKey",value))))return emptyStack();return Reflect.call(value,"getDefaultInstance");}
 public static int tier(Object mob,boolean armed)throws Exception {int armor=0;boolean military=false;for(String name:SLOTS){Object s=Reflect.call(mob,"getItemBySlot",slot(name));if(!empty(s)){armor++;military|=id(s).startsWith("fracturepoint:");}}int experience=((Number)Reflect.call(persistent(mob),"getInt","TacZNpcScavengingXP")).intValue();return Math.min(3,CalmRules.tier(armed,armor,military)+Math.min(1,experience/12));}
 static final String CIVILIAN_VERSION="TacZNpcCivilianV5",JOB="TacZNpcJob";
 static final String[][] JOBS={
  {"builder","minecraft:stone_pickaxe","Constructor"},{"miner","minecraft:iron_pickaxe","Minero"},
  {"doctor","minecraft:shears","Médico"},{"woodworker","minecraft:iron_axe","Carpintero"},
  {"fire","minecraft:iron_axe","Bombero"},{"courier","minecraft:wooden_sword","Mensajero"},
  {"police","minecraft:iron_sword","Policía"},{"official","minecraft:wooden_sword","Oficinista"},
  {"medieval_farmer","minecraft:stone_hoe","Agricultor"},{"gray_jacket","minecraft:stone_sword","Civil"},
  {"casual_autum","minecraft:wooden_sword","Civil"},{"apocalypsise_survivor","minecraft:stone_axe","Superviviente"}};
 static void retain(Object mob,Object stack,List<Object> bag)throws Exception {if(empty(stack))return;if(bag.size()<9)bag.add(Reflect.call(stack,"copy"));else Reflect.call(mob,"spawnAtLocation",Reflect.call(stack,"copy"));}
 public static void outfit(Object mob,Random random)throws Exception {
  Object data=persistent(mob);if(Reflect.yes(Reflect.call(data,"getBoolean",CIVILIAN_VERSION)))return;
  String[] ids=null;String job="",tool="";
  boolean equippedMilitary=true;for(String name:SLOTS)equippedMilitary&=id(Reflect.call(mob,"getItemBySlot",slot(name))).startsWith("fracturepoint:");
  if(equippedMilitary){Reflect.call(data,"putString",JOB,"military");Reflect.call(data,"putBoolean",CIVILIAN_VERSION,true);return;}
  if(CalmRules.military(random.nextDouble())){String base=random.nextBoolean()?"ratnik":"fsb";String prefix=base.equals("fsb")?"fsb_soldier":base;String[] candidates={"fracturepoint:"+prefix+"_helmet","fracturepoint:"+prefix+"_chestplate","fracturepoint:"+base+"_leggings","fracturepoint:"+base+"_boots"};boolean complete=true;for(String candidate:candidates)complete&=!empty(stack(candidate));if(complete){ids=candidates;job="military";}}
  if(ids==null){List<String[]> available=new ArrayList<>();for(String[] role:JOBS)if(!empty(stack("selfexpression:"+role[0]+"_chestplate")))available.add(role);if(available.isEmpty())return;
   String[] role=available.get(random.nextInt(available.size()));job=role[0];tool=role[1];String[] suffix={"helmet","chestplate","leggings","boots"};ids=new String[4];for(int i=0;i<4;i++)ids[i]="selfexpression:"+job+"_"+suffix[i];
  }
  List<Object> bag=bag(mob);
  // Migrate existing NPCs too: the older outfit marker must not retain template armor.
  for(int i=0;i<4;i++){Object replacement=stack(ids[i]),worn=Reflect.call(mob,"getItemBySlot",slot(SLOTS[i]));if(!empty(worn))retain(mob,worn,bag);Reflect.call(mob,"setItemSlot",slot(SLOTS[i]),replacement);}
  saveBag(mob,bag);
  if(!tool.isEmpty()){Object implement=stack(tool);if(!empty(implement)){
   if(!CalmBrain.gun(mob)){Object old=Reflect.call(mob,"getMainHandItem");retain(mob,old,bag);Reflect.call(mob,"setItemSlot",slot("MAINHAND"),implement);}
   else if(empty(Reflect.call(mob,"getOffhandItem")))Reflect.call(mob,"setItemSlot",slot("OFFHAND"),implement);
   else if(bag.size()<9)bag.add(implement);
   saveBag(mob,bag);
  }}
  Reflect.call(data,"putString",JOB,job);Reflect.call(data,"putBoolean",CIVILIAN_VERSION,true);Reflect.call(data,"putBoolean",OUTFIT,true);
 }
 static List<Object> bag(Object mob)throws Exception {List<Object> result=new ArrayList<>();Object tags=Reflect.call(persistent(mob),"getList",INVENTORY,10);int size=((Number)Reflect.call(tags,"size")).intValue();for(int i=0;i<Math.min(9,size);i++){Object tag=Reflect.call(tags,"getCompound",i);Object stack=Reflect.call(Reflect.type("net.minecraft.world.item.ItemStack"),"parseOptional",registry(mob),tag);if(!empty(stack))result.add(stack);}return result;}
 static void saveBag(Object mob,List<Object> bag)throws Exception {Object tags=Reflect.type("net.minecraft.nbt.ListTag").getConstructor().newInstance();for(Object stack:bag)Reflect.call(tags,"add",Reflect.call(stack,"save",registry(mob)));Reflect.call(persistent(mob),"put",INVENTORY,tags);}
 static Object destination(Object stack)throws Exception {Object it=item(stack);if(Reflect.type("com.tacz.guns.api.item.IGun").isInstance(it))return slot("MAINHAND");if(Reflect.type("net.minecraft.world.item.ArmorItem").isInstance(it)){String name=id(stack);if(!name.startsWith("selfexpression:")&&!name.startsWith("fracturepoint:"))return null;return Reflect.call(it,"getEquipmentSlot");}if(Reflect.type("net.minecraft.world.item.TieredItem").isInstance(it))return slot("MAINHAND");return null;}
 static double gearScore(Object stack)throws Exception {if(empty(stack))return 0;Object it=item(stack);if(Reflect.type("com.tacz.guns.api.item.IGun").isInstance(it))return 100;if(Reflect.type("net.minecraft.world.item.ArmorItem").isInstance(it))return 1+Reflect.number(Reflect.call(it,"getDefense"));if(Reflect.type("net.minecraft.world.item.TieredItem").isInstance(it))return 5;return 1;}
 static boolean preferred(Object mob,Object candidate,Object worn)throws Exception {if(empty(candidate))return false;if(empty(worn))return true;if(Reflect.type("com.tacz.guns.api.item.IGun").isInstance(item(candidate))&&Reflect.type("com.tacz.guns.api.item.IGun").isInstance(item(worn)))return Reflect.yes(Reflect.call(Reflect.type("mod.cdv.tnpc.tactical.BanditBrain"),"betterGun",candidate,worn));return gearScore(candidate)>gearScore(worn);}
 static final class Source {final Object inventory;final List<Object> list;final Object owner;final double x,y,z;Source(Object container,List<Object> list,Object owner,double x,double y,double z){this.inventory=container;this.list=list;this.owner=owner;this.x=x;this.y=y;this.z=z;}int size()throws Exception{return list!=null?list.size():((Number)Reflect.call(inventory,"getContainerSize")).intValue();}Object get(int i)throws Exception{return list!=null?list.get(i):Reflect.call(inventory,"getItem",i);}void set(int i,Object s)throws Exception{if(list!=null){Object old=list.get(i);list.set(i,s);if(owner.getClass().getName().equals("net.minecraft.world.entity.item.ItemEntity"))Reflect.call(owner,"setItem",s);else syncCorpseEquipment(owner,old,s);}else{Reflect.call(inventory,"setItem",i,s);Reflect.call(inventory,"setChanged");}}}
 static void syncCorpseEquipment(Object owner,Object old,Object remaining)throws Exception {
  @SuppressWarnings("unchecked") List<Object> equipment=(List<Object>)Reflect.call(Reflect.call(owner,"getDeath"),"getEquipment");
  if(empty(remaining))for(int i=0;i<equipment.size();i++)if(!empty(equipment.get(i))&&Reflect.yes(Reflect.call(Reflect.type("net.minecraft.world.item.ItemStack"),"isSameItemSameComponents",old,equipment.get(i)))){equipment.set(i,emptyStack());break;}
  Object display=Reflect.call(Reflect.type("net.minecraft.core.NonNullList"),"withSize",equipment.size(),emptyStack());
  for(int i=0;i<equipment.size();i++)Reflect.call(display,"set",i,Reflect.call(equipment.get(i),"copy"));Reflect.call(owner,"setEquipment",display);
 }
 static final Map<Object,Claim> CLAIMS=Collections.synchronizedMap(new WeakHashMap<>());
 static final class Claim {final java.lang.ref.WeakReference<Object> mob;long until;Claim(Object mob,long until){this.mob=new java.lang.ref.WeakReference<>(mob);this.until=until;}}
 static Object key(Source source){return source.owner!=null&&source.owner.getClass().getName().equals("net.minecraft.world.entity.item.ItemEntity")?source.owner:source.inventory!=null?source.inventory:source.list;}
 static boolean available(Source source,Object mob,long time){Claim c=CLAIMS.get(key(source));return c==null||c.mob.get()==null||c.mob.get()==mob||c.until<=time;}
 static boolean claim(Source source,Object mob,long time){Object key=key(source);Claim previous=CLAIMS.get(key);if(previous!=null&&previous.mob.get()!=mob&&previous.until>time)return false;CLAIMS.put(key,new Claim(mob,time+200));return true;}
 static long position(int x,int y,int z){return ((long)x&0x3ffffffL)<<38|((long)z&0x3ffffffL)<<12|((long)y&0xfffL);}
 static Source find(Object mob,long time)throws Exception {
  Object level=Reflect.call(mob,"level");Source best=null;double closest=145;
  try{Object data=Reflect.call(Reflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"data",level);Map<?,?> corpses=(Map<?,?>)Reflect.field(data,"corpses");int mx=(int)Math.floor(Reflect.coord(mob,"X")),my=(int)Math.floor(Reflect.coord(mob,"Y")),mz=(int)Math.floor(Reflect.coord(mob,"Z"));
   for(int dx=-12;dx<=12;dx++)for(int dz=-12;dz<=12;dz++){if(dx*dx+dz*dz>144)continue;for(int dy=-2;dy<=2;dy++){Object corpse=corpses.get(position(mx+dx,my+dy,mz+dz));if(corpse==null||Reflect.yes(Reflect.field(corpse,"skeleton")))continue;double d=dx*dx+dy*dy+dz*dz;if(d>=closest)continue;Object pos=Reflect.type("net.minecraft.core.BlockPos").getConstructor(int.class,int.class,int.class).newInstance(mx+dx,my+dy,mz+dz);if(!Reflect.yes(Reflect.call(level,"hasChunkAt",pos)))continue;String actual=String.valueOf(Reflect.call(Reflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"blockId",Reflect.call(level,"getBlockState",pos)));if(!actual.equals(String.valueOf(Reflect.field(corpse,"block"))))continue;Source candidate=new Source(Reflect.field(corpse,"inventory"),null,data,mx+dx+.5,my+dy,mz+dz+.5);if(useful(mob,candidate)&&available(candidate,mob,time)){best=candidate;closest=d;}}}
  }catch(ClassNotFoundException missing){}catch(Exception e){CalmBrain.error("remains loot",e);}
  // Player corpses from the optional Corpse mod use mutable death-inventory lists.
  for(Object entity:CalmBrain.nearby(mob,"net.minecraft.world.entity.Entity",12)){
   if(entity.getClass().getName().equals("net.minecraft.world.entity.item.ItemEntity")){
    double d=CalmBrain.distance(mob,entity);if(d>=closest||Reflect.yes(Reflect.call(entity,"isRemoved")))continue;
    Source candidate=new Source(null,new ArrayList<>(List.of(Reflect.call(entity,"getItem"))),entity,Reflect.coord(entity,"X"),Reflect.coord(entity,"Y"),Reflect.coord(entity,"Z"));
    if(useful(mob,candidate)&&available(candidate,mob,time)){best=candidate;closest=d;}continue;
   }
   if(!entity.getClass().getName().equals("de.maxhenkel.corpse.entities.CorpseEntity"))continue;
   double d=CalmBrain.distance(mob,entity);if(d>=closest)continue;
   try{Object death=Reflect.call(entity,"getDeath");for(String method:List.of("getMainInventory","getArmorInventory","getOffHandInventory","getAdditionalItems")){@SuppressWarnings("unchecked") List<Object> items=(List<Object>)Reflect.call(death,method);Source candidate=new Source(null,items,entity,Reflect.coord(entity,"X"),Reflect.coord(entity,"Y"),Reflect.coord(entity,"Z"));if(useful(mob,candidate)&&available(candidate,mob,time)){best=candidate;closest=d;break;}}}catch(Exception e){CalmBrain.error("Corpse loot",e);}
  }
  return best!=null&&claim(best,mob,time)?best:null;
 }
 static int mergeIndex(List<Object> bag,Object stack)throws Exception {for(int i=0;i<bag.size();i++)if(Reflect.yes(Reflect.call(Reflect.type("net.minecraft.world.item.ItemStack"),"isSameItemSameComponents",bag.get(i),stack))&&Reflect.number(Reflect.call(bag.get(i),"getCount"))<Reflect.number(Reflect.call(bag.get(i),"getMaxStackSize")))return i;return -1;}
 static boolean room(List<Object> bag,Object stack)throws Exception{return bag.size()<9||mergeIndex(bag,stack)>=0;}
 static void store(List<Object> bag,Object stack)throws Exception {int index=mergeIndex(bag,stack);if(index<0)bag.add(stack);else{Object merged=Reflect.call(bag.get(index),"copy");Reflect.call(merged,"setCount",((Number)Reflect.call(merged,"getCount")).intValue()+1);bag.set(index,merged);}}
 static boolean useful(Object mob,Source source)throws Exception {List<Object> bag=bag(mob);for(int i=0;i<source.size();i++){Object stack=source.get(i);if(empty(stack))continue;Object slot=destination(stack);if(slot!=null&&preferred(mob,stack,Reflect.call(mob,"getItemBySlot",slot))&&(empty(Reflect.call(mob,"getItemBySlot",slot))||bag.size()<9))return true;if(room(bag,stack))return true;}return false;}
 public static boolean transferOne(Object mob,Object container)throws Exception{return transfer(mob,new Source(container,null,null,0,0,0));}
 static boolean transfer(Object mob,Source source)throws Exception {
  List<Object> bag=bag(mob);int selected=-1;double priority=-1;Object equipSlot=null,worn=null;
  for(int i=0;i<source.size();i++){Object candidate=source.get(i);if(empty(candidate))continue;Object slot=destination(candidate);Object old=slot==null?null:Reflect.call(mob,"getItemBySlot",slot);boolean equip=slot!=null&&preferred(mob,candidate,old)&&(empty(old)||bag.size()<9);if(!equip&&!room(bag,candidate))continue;double score=gearScore(candidate)+(equip?1000:0);if(score>priority){priority=score;selected=i;equipSlot=equip?slot:null;worn=equip?old:null;}}
  if(selected<0)return false;
  Object original=source.get(selected),taken=Reflect.call(original,"copy"),remaining=Reflect.call(original,"copy");Reflect.call(taken,"setCount",1);Reflect.call(remaining,"shrink",1);
  Object data=persistent(mob),oldBag=Reflect.call(data,"getList",INVENTORY,10);List<Object> updated=new ArrayList<>(bag);
  if(equipSlot==null)store(updated,taken);else if(!empty(worn))updated.add(Reflect.call(worn,"copy"));
  try{
   saveBag(mob,updated);if(equipSlot!=null)Reflect.call(mob,"setItemSlot",equipSlot,taken);
   source.set(selected,remaining);
  }catch(Exception failed){Reflect.call(data,"put",INVENTORY,oldBag);if(equipSlot!=null)Reflect.call(mob,"setItemSlot",equipSlot,worn);source.set(selected,original);throw failed;}
  int xp=((Number)Reflect.call(data,"getInt","TacZNpcScavengingXP")).intValue();Reflect.call(data,"putInt","TacZNpcScavengingXP",Math.min(120,xp+1));
  return true;
 }
 static void search(Object mob,CalmBrain.State s,long time)throws Exception {if(s.corpse==null&&time>=s.nextLoot){s.nextLoot=time+40;s.corpse=find(mob,time);s.lootStart=Long.MIN_VALUE;s.lootApproach=Long.MIN_VALUE;}}
 static void release(Object mob,CalmBrain.State s)throws Exception {if(s.corpse instanceof Source source){Claim c=CLAIMS.get(key(source));if(c!=null&&c.mob.get()==mob)CLAIMS.remove(key(source));}s.corpse=null;s.lootStart=Long.MIN_VALUE;s.lootApproach=Long.MIN_VALUE;}
 static void idle(Object mob,CalmBrain.State s,long time)throws Exception {
  if(s.corpse instanceof Source source){
   if(source.inventory!=null&&source.owner!=null){Object current=((Map<?,?>)Reflect.field(source.owner,"corpses")).get(position((int)Math.floor(source.x),(int)Math.floor(source.y),(int)Math.floor(source.z)));if(current==null||Reflect.yes(Reflect.field(current,"skeleton"))||Reflect.field(current,"inventory")!=source.inventory){CLAIMS.remove(key(source));s.corpse=null;CalmBrain.crouch(mob,false);return;}}
   if(source.list!=null&&Reflect.yes(Reflect.call(source.owner,"isRemoved"))){CLAIMS.remove(key(source));s.corpse=null;CalmBrain.crouch(mob,false);return;}
   if(source.owner!=null&&source.owner.getClass().getName().equals("net.minecraft.world.entity.item.ItemEntity"))source.list.set(0,Reflect.call(source.owner,"getItem"));
   if(!claim(source,mob,time)){s.corpse=null;return;}
   double dx=Reflect.coord(mob,"X")-source.x,dz=Reflect.coord(mob,"Z")-source.z,dy=Reflect.coord(mob,"Y")-source.y;
   if(dx*dx+dy*dy+dz*dz>5){CalmBrain.crouch(mob,false);CalmBrain.path(mob,s,time,source.x,source.y,source.z,.8);if(s.lootApproach==Long.MIN_VALUE)s.lootApproach=time;if(time-s.lootApproach>300){CLAIMS.remove(key(source));s.corpse=null;s.nextLoot=time+200;}return;}
   Reflect.call(Reflect.call(mob,"getNavigation"),"stop");CalmBrain.crouch(mob,true);Reflect.call(Reflect.call(mob,"getLookControl"),"setLookAt",source.x,source.y+.2,source.z,10f,10f);
   if(time%20==0)Reflect.call(mob,"swing",Reflect.field(Reflect.type("net.minecraft.world.InteractionHand"),"MAIN_HAND"));if(s.lootStart==Long.MIN_VALUE)s.lootStart=time;
   if(time-s.lootStart>=(source.owner!=null&&source.owner.getClass().getName().equals("net.minecraft.world.entity.item.ItemEntity")?20:40)){boolean transferred=transfer(mob,source);s.lootStart=time;if(!transferred){CLAIMS.remove(key(source));s.corpse=null;s.nextLoot=time+100;CalmBrain.crouch(mob,false);}}return;
  }
  CalmBrain.crouch(mob,false);
 }
}
