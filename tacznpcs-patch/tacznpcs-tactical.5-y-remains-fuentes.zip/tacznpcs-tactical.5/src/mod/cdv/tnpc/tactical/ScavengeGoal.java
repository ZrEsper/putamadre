package mod.cdv.tnpc.tactical;
import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;
public final class ScavengeGoal extends Goal {
 final Object mob;public ScavengeGoal(Object mob){this.mob=mob;setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
 public boolean canUse(){CalmBrain.State s=CalmBrain.state(mob);return s.target==null&&s.corpse!=null;}
 public boolean requiresUpdateEveryTick(){return true;}
 public void tick(){try{CalmLoot.idle(mob,CalmBrain.state(mob),CalmBrain.now(mob));}catch(Exception e){CalmBrain.error("scavenge goal",e);}}
 public void stop(){try{CalmLoot.release(mob,CalmBrain.state(mob));CalmBrain.crouch(mob,false);Reflect.call(Reflect.call(mob,"getNavigation"),"stop");}catch(Exception e){CalmBrain.error("scavenge stop",e);}}
}
