package mod.cdv.tnpc.tactical;
import java.util.*;
import java.util.function.*;
public final class CalmBrain {
 static final Map<Object,State> STATES=Collections.synchronizedMap(new WeakHashMap<>());
 private static final Set<String> ERRORS=new HashSet<>();
 static final class State {boolean installed,sprint;Object target;long seen=-1,reactAt,nextDecision,nextPath,nextShot,nextIdle,nextLoot;double x,y,z;int tier,zombies;Object corpse;long lootStart=Long.MIN_VALUE,lootApproach=Long.MIN_VALUE;double corpseX,corpseY,corpseZ; final Random random=new Random();}
 static State state(Object mob){return STATES.computeIfAbsent(mob,k->new State());}
 static void error(String op,Exception e){synchronized(ERRORS){if(ERRORS.add(op))System.err.println("[TacZ NPCs Calm] "+op+": "+e);}}
 static boolean bandit(Object mob)throws Exception {String id=String.valueOf(Reflect.field(mob,"templateId")).toLowerCase(Locale.ROOT);if(id.contains("bandit")||id.contains("illager"))return true;Object template=Reflect.call(mob,"getTemplate");return template!=null&&((Set<?>)Reflect.call(template,"opposed")).contains("players");}
 public static boolean managed(Object mob){State s=STATES.get(mob);return s!=null&&s.installed;}
 static long now(Object mob)throws Exception{return ((Number)Reflect.call(Reflect.call(mob,"level"),"getGameTime")).longValue();}
 static boolean alive(Object target)throws Exception {if(target==null||!Reflect.yes(Reflect.call(target,"isAlive")))return false;if(Reflect.type("net.minecraft.world.entity.player.Player").isInstance(target))return !Reflect.yes(Reflect.call(target,"isCreative"))&&!Reflect.yes(Reflect.call(target,"isSpectator"));return true;}
 static boolean visible(Object mob,Object target)throws Exception{return Reflect.yes(Reflect.call(Reflect.call(mob,"getSensing"),"hasLineOfSight",target));}
 static double distance(Object a,Object b)throws Exception {double x=Reflect.coord(a,"X")-Reflect.coord(b,"X"),y=Reflect.coord(a,"Y")-Reflect.coord(b,"Y"),z=Reflect.coord(a,"Z")-Reflect.coord(b,"Z");return x*x+y*y+z*z;}
 static List<?> nearby(Object mob,String type,double radius)throws Exception {Object box=Reflect.call(Reflect.call(mob,"getBoundingBox"),"inflate",radius);return (List<?>)Reflect.call(Reflect.call(mob,"level"),"getEntitiesOfClass",Reflect.type(type),box);}
 static boolean gun(Object mob)throws Exception {Object item=Reflect.call(Reflect.call(mob,"getMainHandItem"),"getItem");return Reflect.type("com.tacz.guns.api.item.IGun").isInstance(item);}
 static boolean allied(Object a,Object b)throws Exception{return Reflect.type("mod.cdv.tnpc.entity.AutoGunOperator").isInstance(b)&&(bandit(a)&&bandit(b)||Reflect.yes(Reflect.call(a,"isAlliedTo",b)));}
 public static void tick(Object mob){try{
  if(Reflect.yes(Reflect.call(Reflect.call(mob,"level"),"isClientSide"))||!bandit(mob))return;
  State s=state(mob);
  if(!s.installed){
   Object goals=Reflect.field(mob,"goalSelector"),targets=Reflect.field(mob,"targetSelector");
   Reflect.call(goals,"removeAllGoals",(Predicate<Object>)(g->!g.getClass().getSimpleName().equals("FloatGoal")));
   Reflect.call(targets,"removeAllGoals",(Predicate<Object>)(g->true));
   Reflect.call(goals,"addGoal",1,new CalmGoal(mob));Reflect.call(Reflect.call(mob,"getNavigation"),"setCanFloat",true);Reflect.call(goals,"addGoal",2,new VanillaGunGoal(mob));
   Reflect.call(goals,"addGoal",3,new WaterRecoveryGoal(mob));
   Reflect.call(goals,"addGoal",4,Reflect.construct("net.minecraft.world.entity.ai.goal.MeleeAttackGoal",mob,1.1,true));
   Reflect.call(goals,"addGoal",5,new ScavengeGoal(mob));
   Reflect.call(goals,"addGoal",6,Reflect.construct("net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal",mob,.85));
   Reflect.call(goals,"addGoal",7,Reflect.construct("net.minecraft.world.entity.ai.goal.LookAtPlayerGoal",mob,Reflect.type("net.minecraft.world.entity.player.Player"),8f));
   Reflect.call(goals,"addGoal",8,Reflect.construct("net.minecraft.world.entity.ai.goal.RandomLookAroundGoal",mob));
   s.installed=true;
  }
  CalmLoot.outfit(mob,s.random);
  // Reapply after TACZ updates its own speed/sprint state, without changing armor stats.
  Object attribute=Reflect.call(mob,"getAttribute",Reflect.field(Reflect.type("net.minecraft.world.entity.ai.attributes.Attributes"),"MOVEMENT_SPEED"));
  Reflect.call(attribute,"setBaseValue",CalmRules.WALK_SPEED);clearGunSlowdown(attribute);Reflect.call(mob,"setSprinting",s.sprint);
 }catch(Exception e){error("install/speed",e);}}
 static void crouch(Object mob,boolean value)throws Exception {if(value&&Reflect.yes(Reflect.call(mob,"isInWater")))value=false;Reflect.call(mob,"setShiftKeyDown",value);String current=String.valueOf(Reflect.call(mob,"getPose"));if(current.equals("STANDING")||current.equals("CROUCHING"))Reflect.call(mob,"setPose",Reflect.field(Reflect.type("net.minecraft.world.entity.Pose"),value?"CROUCHING":"STANDING"));}
 public static void stop(Object mob){try{Reflect.call(Reflect.call(mob,"getNavigation"),"stop");crouch(mob,false);Reflect.call(mob,"setTarget",(Object)null);}catch(Exception e){error("stop",e);}}
 static void path(Object mob,State s,long time,double x,double y,double z,double speed)throws Exception {
  if(time<s.nextPath)return;s.nextPath=time+10;
  Object navigation=Reflect.call(mob,"getNavigation");boolean routed=Reflect.yes(Reflect.call(navigation,"moveTo",x,y,z,Math.min(1.15,Math.max(.95,speed))));
  if(!routed&&Reflect.yes(Reflect.call(mob,"isInWater")))Reflect.call(Reflect.call(mob,"getMoveControl"),"setWantedPosition",x,y,z,1.0);
 }
 static void acquire(Object mob,State s,long time,boolean armed)throws Exception {
  Object old=s.target;if(!armed&&old!=null&&distance(mob,old)>64)old=null;Object attacker=Reflect.call(mob,"getLastHurtByMob");if(((Number)Reflect.field(mob,"tickCount")).intValue()-((Number)Reflect.call(mob,"getLastHurtByMobTimestamp")).intValue()>100)attacker=null;Object closestZombie=null;double zd=24*24;s.zombies=0;
  for(Object z:nearby(mob,"net.minecraft.world.entity.monster.Zombie",24)){if(!alive(z)||!visible(mob,z))continue;double d=distance(mob,z);Object victim=Reflect.call(z,"getTarget");boolean threat=victim==mob||d<=(armed?20.25:12.25);if(!threat)continue;if(d<144)s.zombies++;if(d<zd){zd=d;closestZombie=z;}}
  Object chosen=null;
  if(alive(attacker)&&!allied(mob,attacker)&&distance(mob,attacker)<576)chosen=attacker;
  if(chosen==null&&closestZombie!=null)chosen=closestZombie;
  if(chosen==null&&alive(old)&&!allied(mob,old)&&(!Reflect.type("net.minecraft.world.entity.monster.Zombie").isInstance(old)||!visible(mob,old)&&s.seen>=0&&time-s.seen<=120))chosen=old;
  // Unarmed survivors do not proactively hunt players.
  if(chosen==null&&armed)for(Object player:nearby(mob,"net.minecraft.world.entity.player.Player",24)){
   if(!alive(player)||!visible(mob,player)||allied(mob,player))continue;
   double d=distance(mob,player);double detection=Math.min(24,16+s.tier*3);if(Reflect.yes(Reflect.call(player,"isCrouching")))detection*=.65;if(Reflect.yes(Reflect.call(player,"isInvisible")))detection=Math.min(detection,4);if(d>detection*detection)continue;double dx=Reflect.coord(player,"X")-Reflect.coord(mob,"X"),dz=Reflect.coord(player,"Z")-Reflect.coord(mob,"Z");double yaw=Math.toRadians(Reflect.number(Reflect.call(mob,"getYRot")));double forward=(-Math.sin(yaw)*dx+Math.cos(yaw)*dz)/Math.max(.01,Math.hypot(dx,dz));
   if(d>9&&forward<.15)continue;if(chosen==null||d<distance(mob,chosen))chosen=player;
  }
  if(chosen!=s.target){s.target=chosen;s.reactAt=time+CalmRules.reaction(s.tier)+s.random.nextInt(7);s.seen=-1;s.nextPath=time;CalmLoot.release(mob,s);crouch(mob,false);}
 }
 public static void control(Object mob){try{
  if(!Reflect.yes(Reflect.call(mob,"isAlive")))return;
  State s=state(mob);long time=now(mob);boolean armed=gun(mob);s.tier=CalmLoot.tier(mob,armed);
  if(time>=s.nextDecision){s.nextDecision=time+2;acquire(mob,s,time,armed);}
  Object target=s.target;if(!alive(target)||allied(mob,target)){s.target=null;target=null;}
  s.sprint=false;
  if(target==null){Reflect.call(mob,"setTarget",(Object)null);Reflect.call(mob,"setAggressive",false);Reflect.call(mob,"aim",false);CalmLoot.search(mob,s,time);return;}
  CalmLoot.release(mob,s);crouch(mob,false);boolean seen=visible(mob,target);
  if(seen){s.x=Reflect.coord(target,"X");s.y=Reflect.coord(target,"Y");s.z=Reflect.coord(target,"Z");s.seen=time;Reflect.call(mob,"setTarget",target);Reflect.call(mob,"setAggressive",true);s.sprint=distance(mob,target)>(armed?324:16);}
  else {Reflect.call(mob,"setTarget",(Object)null);Reflect.call(mob,"aim",false);if(s.seen<0||time-s.seen>80){s.target=null;return;}}
 }catch(Exception e){error("decisions",e);}}
 public static void rangedAttack(Object mob,Object target,float power){try{
  State s=state(mob);long time=now(mob);if(target!=s.target||!gun(mob)||!alive(target)||!visible(mob,target)||time<s.reactAt||time<s.nextShot)return;
  double d=Math.sqrt(distance(mob,target)),facing=face(mob,target);
  if(d>24||facing>15||allyInLine(mob,target))return;String reloadState=String.valueOf(Reflect.field(Reflect.call(mob,"getDataHolder"),"reloadStateType"));if(!reloadState.equals("NOT_RELOADING")&&!reloadState.endsWith("FINISHING"))return;
  double[] angles=aim(mob);Reflect.call(mob,"aim",true);
  Object result=Reflect.call(mob,"shoot",(Supplier<Float>)(()->(float)angles[0]),(Supplier<Float>)(()->(float)angles[1]));
  String outcome=String.valueOf(result);
  if(outcome.equals("NOT_DRAW"))Reflect.call(mob,"draw",(Supplier<Object>)(()->{try{return Reflect.call(mob,"getMainHandItem");}catch(Exception e){throw new IllegalStateException(e);}}));
  else if(outcome.equals("NO_AMMO"))Reflect.call(mob,"reload");
  else if(outcome.equals("NEED_BOLT"))Reflect.call(mob,"bolt");
  s.nextShot=time+(outcome.equals("SUCCESS")?CalmRules.shotPause(s.tier)+s.random.nextInt(5):5);
 }catch(Exception e){error("ranged attack",e);}}
 static void clearGunSlowdown(Object attribute)throws Exception {
  // Only TACZ's gun weight/aim modifiers; retain armor, potion and sprint modifiers.
  Class<?> c;try{c=Reflect.type("com.tacz.guns.entity.shooter.LivingEntitySpeedModifier");}catch(ClassNotFoundException optional){return;}
  for(java.lang.reflect.Field f:c.getDeclaredFields())if(java.lang.reflect.Modifier.isStatic(f.getModifiers())&&(f.getName().startsWith("EXTRA_SPEED_MODIFIER")||f.getName().startsWith("WEIGHT_SPEED_MODIFIER"))){f.setAccessible(true);Reflect.call(attribute,"removeModifier",f.get(null));}
 }
 public static boolean nativePickupAllowed(Object mob){return !managed(mob);}
 static double face(Object mob,Object target)throws Exception {
  double dx=Reflect.coord(target,"X")-Reflect.coord(mob,"X"),dz=Reflect.coord(target,"Z")-Reflect.coord(mob,"Z");
  double yaw=Math.toDegrees(Math.atan2(dz,dx))-90,old=Reflect.number(Reflect.call(mob,"getYRot"));
  double delta=((yaw-old)%360+540)%360-180;float next=(float)(old+Math.max(-25,Math.min(25,delta)));
  Reflect.call(mob,"setYRot",next);Reflect.call(mob,"setYHeadRot",next);Reflect.call(mob,"setYBodyRot",next);
  float pitch=(float)-Math.toDegrees(Math.atan2(Reflect.coord(target,"Y")+Reflect.number(Reflect.call(target,"getBbHeight"))*.52-Reflect.number(Reflect.call(mob,"getEyeY")),Math.max(.1,Math.hypot(dx,dz))));Reflect.call(mob,"setXRot",pitch);
  return Math.abs(((yaw-next)%360+540)%360-180);
 }
 public static boolean allyInLine(Object mob,Object target)throws Exception {
  double ax=Reflect.coord(mob,"X"),ay=Reflect.number(Reflect.call(mob,"getEyeY")),az=Reflect.coord(mob,"Z");double bx=Reflect.coord(target,"X"),by=Reflect.coord(target,"Y")+Reflect.number(Reflect.call(target,"getBbHeight"))*.52,bz=Reflect.coord(target,"Z");
  for(Object other:nearby(mob,"mod.cdv.tnpc.entity.AutoGunOperator",32))if(other!=mob&&alive(other)&&allied(mob,other)&&CalmRules.hitAlly(ax,ay,az,bx,by,bz,Reflect.coord(other,"X"),Reflect.coord(other,"Y")+Reflect.number(Reflect.call(other,"getBbHeight"))*.55,Reflect.coord(other,"Z"),1.0))return true;
  return false;
 }
 public static boolean ignoreDamage(Object mob,Object source){try{Object attacker=Reflect.call(source,"getEntity");return attacker!=null&&attacker!=mob&&bandit(mob)&&allied(mob,attacker);}catch(Exception e){error("friendly fire",e);return false;}}
 public static double[] aim(Object mob)throws Exception {
  Object target=state(mob).target;if(target==null)target=Reflect.call(mob,"getTarget");if(target==null)return new double[]{Reflect.number(Reflect.call(mob,"getViewXRot",1f)),Reflect.number(Reflect.call(mob,"getViewYRot",1f))};
  double dx=Reflect.coord(target,"X")-Reflect.coord(mob,"X"),dz=Reflect.coord(target,"Z")-Reflect.coord(mob,"Z"),d=Math.hypot(dx,dz);double y=Reflect.coord(target,"Y")+Reflect.number(Reflect.call(target,"getBbHeight"))*.52;
  Random random=new Random(((Number)Reflect.call(mob,"getId")).longValue()*341873128712L+now(mob)*132897987541L);double spread=CalmRules.dispersion(state(mob).tier,d);
  return new double[]{-Math.toDegrees(Math.atan2(y-Reflect.number(Reflect.call(mob,"getEyeY")),Math.max(.1,d)))+random.nextGaussian()*spread,Math.toDegrees(Math.atan2(dz,dx))-90+random.nextGaussian()*spread};
 }
 public static Object legacyCall(Object receiver,String name,Object[] args)throws Exception {if(name.equals("isSpectator")&&args.length==0&&Reflect.type("net.minecraft.world.entity.player.Player").isInstance(receiver))return !alive(receiver);return Reflect.call(receiver,name,args);}
 public static boolean spawnAllowed(Object event){try{Object level=Reflect.call(event,"getLevel");return !Reflect.yes(Reflect.call(level,"isClientSide"))&&!String.valueOf(Reflect.call(level,"getDifficulty")).equalsIgnoreCase("PEACEFUL")&&Reflect.yes(Reflect.call(Reflect.call(level,"getGameRules"),"getBoolean",Reflect.field(Reflect.type("net.minecraft.world.level.GameRules"),"RULE_DOMOBSPAWNING")));}catch(Exception e){error("spawn conditions",e);return false;}}
 public static void clientPose(Object mob,Object fake){try {for(String name:List.of("attackAnim","oAttackAnim")){java.lang.reflect.Field f=Reflect.type("net.minecraft.world.entity.LivingEntity").getDeclaredField(name);f.setAccessible(true);f.setFloat(fake,f.getFloat(mob));}}catch(Exception e){error("swing animation",e);}}
}
