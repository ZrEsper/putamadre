package mod.cdv.tnpc.tactical;
import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;
/** Allow swimming toward a visible melee threat when ground navigation cannot produce a route. */
public final class WaterRecoveryGoal extends Goal {
 final Object mob;public WaterRecoveryGoal(Object mob){this.mob=mob;setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
 public boolean canUse(){try{Object target=CalmBrain.state(mob).target;return !CalmBrain.gun(mob)&&Reflect.yes(Reflect.call(mob,"isInWater"))&&CalmBrain.alive(target)&&CalmBrain.visible(mob,target)&&CalmBrain.distance(mob,target)>4&&Reflect.call(Reflect.call(mob,"getNavigation"),"createPath",target,0)==null;}catch(Exception e){CalmBrain.error("water recovery",e);return false;}}
 public boolean requiresUpdateEveryTick(){return true;}
 public void tick(){try{Object target=CalmBrain.state(mob).target;if(target==null)return;CalmBrain.face(mob,target);CalmBrain.path(mob,CalmBrain.state(mob),CalmBrain.now(mob),Reflect.coord(target,"X"),Reflect.coord(target,"Y"),Reflect.coord(target,"Z"),1.1);}catch(Exception e){CalmBrain.error("swimming",e);}}
 public void stop(){try{Reflect.call(Reflect.call(mob,"getNavigation"),"stop");}catch(Exception e){CalmBrain.error("swim stop",e);}}
}
