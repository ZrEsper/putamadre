import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
public class Patch implements Opcodes {
 static final String P="mod/cdv/tnpc/tactical/";
 static MethodInsnNode invoke(String cls,String name,String desc){return new MethodInsnNode(INVOKESTATIC,P+cls,name,desc,false);}
 static void reset(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;}
 static void write(ClassNode c,Path root)throws Exception{ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] bytes=w.toByteArray();ClassNode verified=new ClassNode();new ClassReader(bytes).accept(verified,0);int n=0;for(MethodNode m:verified.methods)if(m.instructions.size()>0){new Analyzer<>(new BasicVerifier()).analyze(verified.name,m);n++;}Path target=root.resolve(c.name+".class");Files.createDirectories(target.getParent());Files.write(target,bytes);System.out.println("PASS: "+c.name+" — "+n+" methods analyzed");}
 public static void main(String[] args)throws Exception{
  Path output=Path.of(args[2]);
  try(ZipFile zip=new ZipFile(args[0])){
   for(String name:List.of("mod/cdv/tnpc/TNPC.class",P+"BanditBrain.class","mod/cdv/tnpc/entity/AutoGunOperator.class","mod/cdv/tnpc/client/render/AutoGunOperatorRenderer.class")){
    ClassNode c=new ClassNode();new ClassReader(zip.getInputStream(zip.getEntry(name))).accept(c,0);
    for(MethodNode m:c.methods){
     if(name.endsWith("TNPC.class")&&m.name.equals("<init>")){for(AbstractInsnNode i:m.instructions.toArray())if(i.getOpcode()==RETURN){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,1));l.add(invoke("EggRegistration","install","(Ljava/lang/Object;)V"));m.instructions.insertBefore(i,l);}}
     if(name.endsWith("BanditBrain.class")){
      if(m.name.equals("call")){reset(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(new VarInsnNode(ALOAD,2));m.instructions.add(invoke("CalmBrain","legacyCall","(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"));m.instructions.add(new InsnNode(ARETURN));}
      if(m.name.equals("aim")){reset(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(invoke("CalmBrain","aim","(Ljava/lang/Object;)[D"));m.instructions.add(new InsnNode(ARETURN));}
      if(m.name.equals("tick")){reset(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(invoke("CalmBrain","tick","(Ljava/lang/Object;)V"));m.instructions.add(new InsnNode(RETURN));}
      if(m.name.equals("levelTick")){InsnList l=new InsnList();LabelNode next=new LabelNode();l.add(new VarInsnNode(ALOAD,0));l.add(invoke("CalmBrain","spawnAllowed","(Ljava/lang/Object;)Z"));l.add(new JumpInsnNode(IFNE,next));l.add(new InsnNode(RETURN));l.add(next);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(l);}
     }
     if(name.endsWith("AutoGunOperator.class")&&m.name.equals("readAdditionalSaveData")){
      boolean inserted=false;for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof FieldInsnNode f&&f.name.equals("TEMPLATES")){AbstractInsnNode next=i.getNext();while(next!=null&&next.getOpcode()!=ALOAD)next=next.getNext();if(next==null)throw new IllegalStateException("template lookup not found");int index=((VarInsnNode)next).var;InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,index));l.add(invoke("EggRegistration","resolveTemplate","(Ljava/lang/String;)Ljava/lang/String;"));l.add(new VarInsnNode(ASTORE,index));m.instructions.insertBefore(i,l);inserted=true;break;}if(!inserted)throw new IllegalStateException("No template hook");
     }
     if(name.endsWith("AutoGunOperator.class")&&m.name.equals("tick")){
      boolean inserted=false;for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode mi&&mi.name.equals("onTickServerSide")){InsnList l=new InsnList();LabelNode next=new LabelNode();l.add(new VarInsnNode(ALOAD,0));l.add(invoke("CalmBrain","managed","(Ljava/lang/Object;)Z"));l.add(new JumpInsnNode(IFEQ,next));l.add(new InsnNode(RETURN));l.add(next);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(i,l);inserted=true;break;}if(!inserted)throw new IllegalStateException("No melee movement cutoff");
     }
     if(name.endsWith("AutoGunOperatorRenderer.class")&&m.name.equals("render")&&m.desc.startsWith("(Lmod/cdv/tnpc/entity/AutoGunOperator;")){
      boolean inserted=false;for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof FieldInsnNode f&&f.getOpcode()==PUTFIELD&&f.name.equals("swingTime")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(ALOAD,7));l.add(invoke("CalmBrain","clientPose","(Ljava/lang/Object;Ljava/lang/Object;)V"));m.instructions.insert(i,l);inserted=true;break;}if(!inserted)throw new IllegalStateException("No swing synchronization hook");
     }
    }
    if(name.endsWith("AutoGunOperator.class")){
     c.interfaces.add("net/minecraft/world/entity/monster/RangedAttackMob");
     MethodNode ranged=new MethodNode(ACC_PUBLIC,"performRangedAttack","(Lnet/minecraft/world/entity/LivingEntity;F)V",null,null);
     ranged.instructions.add(new VarInsnNode(ALOAD,0));ranged.instructions.add(new VarInsnNode(ALOAD,1));ranged.instructions.add(new VarInsnNode(FLOAD,2));ranged.instructions.add(invoke("CalmBrain","rangedAttack","(Ljava/lang/Object;Ljava/lang/Object;F)V"));ranged.instructions.add(new InsnNode(RETURN));c.methods.add(ranged);
     for(MethodNode m:c.methods)if(m.name.equals("canPickUpLoot")){reset(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(invoke("CalmBrain","nativePickupAllowed","(Ljava/lang/Object;)Z"));m.instructions.add(new InsnNode(IRETURN));}
     MethodNode hurt=new MethodNode(ACC_PUBLIC,"hurt","(Lnet/minecraft/world/damagesource/DamageSource;F)Z",null,null);LabelNode original=new LabelNode();hurt.instructions.add(new VarInsnNode(ALOAD,0));hurt.instructions.add(new VarInsnNode(ALOAD,1));hurt.instructions.add(invoke("CalmBrain","ignoreDamage","(Ljava/lang/Object;Ljava/lang/Object;)Z"));hurt.instructions.add(new JumpInsnNode(IFEQ,original));hurt.instructions.add(new InsnNode(ICONST_0));hurt.instructions.add(new InsnNode(IRETURN));hurt.instructions.add(original);hurt.instructions.add(new FrameNode(F_SAME,0,null,0,null));hurt.instructions.add(new VarInsnNode(ALOAD,0));hurt.instructions.add(new VarInsnNode(ALOAD,1));hurt.instructions.add(new VarInsnNode(FLOAD,2));hurt.instructions.add(new MethodInsnNode(INVOKESPECIAL,c.superName,"hurt",hurt.desc,false));hurt.instructions.add(new InsnNode(IRETURN));c.methods.add(hurt);
    }
    write(c,output.resolve("npc"));
   }
  }
  try(ZipFile zip=new ZipFile(args[1])){
   ClassNode c=new ClassNode();new ClassReader(zip.getInputStream(zip.getEntry("dev/zomboid/remains/ZombieRemainsLoot.class"))).accept(c,0);boolean replaced=false;
   for(MethodNode m:c.methods){if(m.name.equals("death")){for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode mi&&mi.owner.equals("dev/zomboid/remains/BanditDirector")&&mi.name.equals("bandit")){mi.owner="dev/zomboid/remains/NpcCompatibility";mi.name="isBandit";mi.desc="(Ljava/lang/Object;)Z";replaced=true;}}
    if(m.name.equals("death")){for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode mi&&mi.owner.equals("dev/zomboid/remains/LootExtras")&&mi.name.equals("populate")){mi.owner="dev/zomboid/remains/NpcCompatibility";mi.name="extras";mi.desc="(Ljava/lang/Object;Ljava/lang/Object;ZZLjava/lang/Object;)V";}}
    if(m.name.equals("populateBandit")){InsnList l=new InsnList();LabelNode next=new LabelNode();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(ALOAD,2));l.add(new MethodInsnNode(INVOKESTATIC,"dev/zomboid/remains/NpcCompatibility","populateNpc","(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z",false));l.add(new JumpInsnNode(IFEQ,next));l.add(new InsnNode(RETURN));l.add(next);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(l);}
   }
   if(!replaced)throw new IllegalStateException("Missing corpse recognition site");write(c,output.resolve("remains"));
  }
 }
}
