import zipfile,json,hashlib,copy
outputs=[r/'output/tacznpcs-2.1.0-1.21.1-tactical.5.jar',r/'output/zombie-remains-loot-1.6.1-neoforge-1.21.1-npc-compat.jar']
for i,base in enumerate(bases):
 kind='npc' if i==0 else 'remains'
 additions={p.relative_to(r/'patched'/kind).as_posix():p.read_bytes() for p in (r/'patched'/kind).rglob('*.class')}
 classes=r/('classes/mod' if i==0 else 'remains-classes/dev')
 relative_root=r/('classes' if i==0 else 'remains-classes')
 additions.update({p.relative_to(relative_root).as_posix():p.read_bytes() for p in classes.rglob('*.class')})
 with zipfile.ZipFile(base) as source:
  metadata=source.read('META-INF/neoforge.mods.toml')
  if i==0:
   additions['META-INF/neoforge.mods.toml']=metadata.replace(b'2.1.0-tactical.1',b'2.1.0-tactical.5')
   for language,name in [('en_us','Tactical Bandit Spawn Egg'),('es_es','Huevo de bandido táctico'),('es_mx','Huevo de bandido táctico')]:
    key=f'assets/tacznpcs/lang/{language}.json';lang=json.loads(source.read(key)) if key in source.namelist() else {'entity.tacznpcs.npc':'NPC armado'}
    lang['item.tacznpcs.bandit_spawn_egg']=name;additions[key]=json.dumps(lang,ensure_ascii=False,indent=2).encode()
   additions['assets/tacznpcs/models/item/bandit_spawn_egg.json']=json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':'tacznpcs:item/bandit_spawn_egg'}}).encode()
   additions['assets/tacznpcs/textures/item/bandit_spawn_egg.png']=(r/'resources/bandit_spawn_egg.png').read_bytes()
  else:additions['META-INF/neoforge.mods.toml']=metadata.replace(b'version="1.6.0"',b'version="1.6.1"')
  output=outputs[i];output.parent.mkdir(exist_ok=True)
  with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as out:
   for entry in source.infolist():out.writestr(copy.copy(entry),additions.pop(entry.filename,source.read(entry)))
   for name,data in sorted(additions.items()):out.writestr(name,data)
  with zipfile.ZipFile(output) as final:
   assert final.testzip() is None
   assert len(final.namelist())==len(set(final.namelist()))
   assert not any(n.startswith(('net/','org/objectweb/','com/tacz/')) for n in final.namelist())
   actual={n for n in source.namelist() if source.read(n)!=final.read(n)}
   expected={'META-INF/neoforge.mods.toml','mod/cdv/tnpc/TNPC.class','mod/cdv/tnpc/tactical/BanditBrain.class','mod/cdv/tnpc/entity/AutoGunOperator.class','mod/cdv/tnpc/client/render/AutoGunOperatorRenderer.class','assets/tacznpcs/lang/en_us.json'} if i==0 else {'META-INF/neoforge.mods.toml','dev/zomboid/remains/ZombieRemainsLoot.class'}
   assert actual==expected,actual
   for n in source.namelist():
    if n not in expected:assert source.read(n)==final.read(n),n
   print('PASS:',kind,'only',len(actual),'existing entries changed; all other entries preserved, no API doubles packaged')
 print(output)
 print('SHA256',hashlib.sha256(output.read_bytes()).hexdigest())
