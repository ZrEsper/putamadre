"""Verify job clothing against the exact user-supplied Self Expression JAR, without loading Minecraft."""
import pathlib,re,sys,zipfile,hashlib
root=pathlib.Path(__file__).resolve().parent
roles=re.findall(r'\{"([a-z_]+)","(minecraft:[a-z_]+)","([^"\n]+)"\}',(root/'src/mod/cdv/tnpc/tactical/CalmLoot.java').read_text())
if len(sys.argv)!=2:raise SystemExit('Usage: python3 verify_integrations.py selfexpression-2.22a-neoforge-1.21.1.jar')
jar=pathlib.Path(sys.argv[1])
with zipfile.ZipFile(jar) as z:
 data=z.read('net/mcreator/selfexpression/init/SelfexpressionModItems.class')
 for style,tool,name in roles:
  assert (style+'_chestplate').encode() in data,style
  slots=[s for s in ['helmet','chestplate','leggings','boots'] if (style+'_'+s).encode() in data]
  print('PASS:',name,style,','.join(slots),'->',tool)
print('Self Expression SHA256:',hashlib.sha256(jar.read_bytes()).hexdigest())
