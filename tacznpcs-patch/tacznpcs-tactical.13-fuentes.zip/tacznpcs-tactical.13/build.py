from pathlib import Path
import subprocess,sys,zipfile,copy,hashlib,json
r=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('Usage: python3 -B build.py tactical.12.jar')
base=Path(sys.argv[1]).resolve()
assert hashlib.sha256(base.read_bytes()).hexdigest()==(r/'base.sha256').read_text().strip(),'Unexpected base jar'
for name,sha in json.loads((r/'tool-checksums.json').read_text()).items():assert hashlib.sha256((r/'tools'/name).read_bytes()).hexdigest()==sha
cp=':'.join(str(p) for p in sorted((r/'tools').glob('asm*.jar')))
ecj=['java','-jar',str(r/'tools/ecj.jar'),'-21','-proc:none','-warn:none']
def run(*args):subprocess.run(list(args),check=True)
run(*ecj,'-cp',str(base),'-d',str(r/'classes'),*[str(p) for p in (r/'src').rglob('*.java')],str(r/'stubs/net/minecraft/world/entity/ai/goal/Goal.java'))
run(*ecj,'-cp',cp,'-d',str(r/'patch-tool'),str(r/'Patch.java'))
run('java','-cp',str(r/'patch-tool')+':'+cp,'Patch',str(base),str(r/'patched'))
if (r/'test-src').exists():
 run(*ecj,'-cp',str(r/'classes')+':'+str(base),'-d',str(r/'test-classes'),*[str(p) for p in (r/'test-src').rglob('*.java')])
 run('java','-Xverify:all','-cp',':'.join(map(str,[r/'test-classes',r/'classes',r/'patched',base])),'mod.cdv.tnpc.tactical.SurvivorChecks')
add={p.relative_to(r/'patched').as_posix():p.read_bytes() for p in (r/'patched').rglob('*.class')}
add.update({p.relative_to(r/'classes').as_posix():p.read_bytes() for p in (r/'classes/mod').rglob('*.class')})
out=r/'output/tacznpcs-2.1.0-1.21.1-tactical.13.jar';out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(base) as z:
 add['META-INF/neoforge.mods.toml']=z.read('META-INF/neoforge.mods.toml').replace(b'2.1.0-tactical.12',b'2.1.0-tactical.13')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for entry in z.infolist():w.writestr(copy.copy(entry),add.pop(entry.filename,z.read(entry)))
  for name,data in sorted(add.items()):w.writestr(name,data)
 with zipfile.ZipFile(out) as w:
  assert w.testzip() is None
  actual={n for n in z.namelist() if z.read(n)!=w.read(n)}
  expected={'META-INF/neoforge.mods.toml',*[p.relative_to(r/'patched').as_posix() for p in (r/'patched').rglob('*.class')]}
  assert actual==expected,actual
  assert not any(n.startswith(('net/','com/tacz/','org/objectweb/')) for n in w.namelist())
 print('PASS all unmodified .12 entries preserved byte-for-byte')
print(out,hashlib.sha256(out.read_bytes()).hexdigest())
