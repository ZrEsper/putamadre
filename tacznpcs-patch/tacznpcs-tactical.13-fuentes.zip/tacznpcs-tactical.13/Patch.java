import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;import java.nio.file.*;import java.util.*;import java.util.zip.*;
public class Patch implements Opcodes {
 static String P="mod/cdv/tnpc/tactical/",H=P+"SurvivorPatch";
 static MethodInsnNode call(String name,String desc){return new MethodInsnNode(INVOKESTATIC,H,name,desc,false);}
 static void reset(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;}
 static void delegate(MethodNode m,String method,String args,String ret){reset(m);int local=0;for(Type type:Type.getArgumentTypes(m.desc)){m.instructions.add(new VarInsnNode(type.getOpcode(ILOAD),local));local+=type.getSize();}m.instructions.add(call(method,args+ret));if(ret.equals("Ljava/lang/Object;")&&!Type.getReturnType(m.desc).getDescriptor().equals(ret))m.instructions.add(new TypeInsnNode(CHECKCAST,Type.getReturnType(m.desc).getInternalName()));m.instructions.add(new InsnNode(Type.getReturnType(m.desc).getOpcode(IRETURN)));}
 static void guard(MethodNode m,String method){InsnList l=new InsnList();LabelNode proceed=new LabelNode();l.add(new VarInsnNode(ALOAD,0));l.add(call(method,"(Ljava/lang/Object;)Z"));l.add(new JumpInsnNode(IFEQ,proceed));l.add(new InsnNode(RETURN));l.add(proceed);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(l);}
 public static void main(String[] args)throws Exception{
  Path output=Path.of(args[1]);int count=0;
  try(ZipFile z=new ZipFile(args[0])){for(String n:List.of(P+"CalmLoot.class",P+"TeamBrain.class",P+"NightCombat.class",P+"GroundStash.class",P+"SurvivalGear.class","mod/cdv/tnpc/entity/AutoGunOperator.class")){
   ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(n))).accept(c,0);
   for(MethodNode m:c.methods){
    if(n.endsWith("CalmLoot.class"))switch(m.name){
     case "gearScore"->delegate(m,"gearScore","(Ljava/lang/Object;)","D");
     case "key"->delegate(m,"key","(Ljava/lang/Object;)","Ljava/lang/Object;");
     case "syncCorpseEquipment"->delegate(m,"syncEquipment","(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)","V");
     case "find"->delegate(m,"find","(Ljava/lang/Object;J)","Ljava/lang/Object;");
     case "useful"->delegate(m,"useful","(Ljava/lang/Object;Ljava/lang/Object;)","Z");
     case "transfer"->delegate(m,"transfer","(Ljava/lang/Object;Ljava/lang/Object;)","Z");
     case "search"->delegate(m,"search","(Ljava/lang/Object;Ljava/lang/Object;J)","V");
     case "idle"->delegate(m,"idle","(Ljava/lang/Object;Ljava/lang/Object;J)","V");
     case "bag"->{boolean found=false;for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof IntInsnNode x&&x.operand==9){x.operand=127;found=true;}if(!found)throw new IllegalStateException("bag limit missing");}
    }
    if(n.endsWith("TeamBrain.class")){
     if(m.name.equals("pauseSearch"))delegate(m,"pauseSearch","(Ljava/lang/Object;)","Z");
     if(m.name.equals("loot"))delegate(m,"lootGate","(Ljava/lang/Object;Ljava/lang/Object;J)","Z");
     if(m.name.equals("tick")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(call("prepare","(Ljava/lang/Object;)V"));m.instructions.insert(l);}
     if(Set.of("nightPlan","activity","investigate").contains(m.name))guard(m,m.name.equals("nightPlan")?"nightPause":"active");
     if(m.name.equals("gunTick")){int changes=0;for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof FieldInsnNode f&&f.getOpcode()==PUTFIELD&&f.name.equals("meleeAt")){AbstractInsnNode v=i.getPrevious().getPrevious();if(!(v instanceof LdcInsnNode x)||!Long.valueOf(2).equals(x.cst))throw new IllegalStateException("melee assignment mismatch");x.cst=20L;changes++;}if(changes!=1)throw new IllegalStateException("melee cooldown constants "+changes);}
     if(m.name.equals("trim")){reset(m);m.instructions.add(new InsnNode(RETURN));}
    }
    if(n.endsWith("NightCombat.class")){
     if(m.name.equals("emergency"))delegate(m,"emergency","(Ljava/lang/Object;)","V");
     if(m.name.equals("lightInterest"))guard(m,"active");
     if(m.name.equals("equipment")){AbstractInsnNode cut=null;for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode x&&x.owner.equals(P+"CalmBrain")&&x.name.equals("bandit")){cut=i.getPrevious();if(cut.getOpcode()!=ALOAD)throw new IllegalStateException("flashlight boundary");break;}if(cut==null)throw new IllegalStateException("flashlight boundary missing");boolean delete=false;for(AbstractInsnNode i:m.instructions.toArray()){if(i==cut)delete=true;if(delete)m.instructions.remove(i);}m.localVariables=null;m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(call("flashlight","(Ljava/lang/Object;)V"));m.instructions.add(new InsnNode(RETURN));}
    }
    if(n.endsWith("GroundStash.class")&&(m.name.equals("tick")||m.name.equals("store"))){reset(m);if(m.name.equals("store"))m.instructions.add(new InsnNode(ICONST_0));m.instructions.add(new InsnNode(m.name.equals("store")?IRETURN:RETURN));}
    if(n.endsWith("SurvivalGear.class")&&m.name.equals("allowed"))delegate(m,"allowed","(Ljava/lang/Object;Ljava/lang/Object;)","Z");
    if(n.endsWith("SurvivalGear.class")&&m.name.equals("finished"))delegate(m,"finished","(Ljava/lang/Object;Ljava/lang/Object;)","V");
    if(n.endsWith("AutoGunOperator.class")&&m.name.equals("doHurtTarget")){
     InsnList l=new InsnList();LabelNode proceed=new LabelNode();l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(ALOAD,1));l.add(call("hit","(Ljava/lang/Object;Ljava/lang/Object;)Z"));l.add(new JumpInsnNode(IFNE,proceed));l.add(new InsnNode(ICONST_0));l.add(new InsnNode(IRETURN));l.add(proceed);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(l);
    }
   }
   if(n.endsWith("AutoGunOperator.class")){if(c.methods.stream().anyMatch(m->m.name.equals("die")))throw new IllegalStateException("existing death override");MethodNode death=new MethodNode(ACC_PUBLIC,"die","(Lnet/minecraft/world/damagesource/DamageSource;)V",null,null);death.instructions.add(new VarInsnNode(ALOAD,0));death.instructions.add(call("death","(Ljava/lang/Object;)V"));death.instructions.add(new VarInsnNode(ALOAD,0));death.instructions.add(new VarInsnNode(ALOAD,1));death.instructions.add(new MethodInsnNode(INVOKESPECIAL,c.superName,"die",death.desc,false));death.instructions.add(new InsnNode(RETURN));c.methods.add(death);}
   ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(writer);byte[] bytes=writer.toByteArray();ClassNode check=new ClassNode();new ClassReader(bytes).accept(check,0);for(MethodNode m:check.methods)if(m.instructions.size()>0){new Analyzer<>(new BasicVerifier()).analyze(check.name,m);count++;}Path target=output.resolve(c.name+".class");Files.createDirectories(target.getParent());Files.write(target,bytes);System.out.println("PASS bytecode "+c.name);
  }}System.out.println("PASS "+count+" methods");
 }
}
