package mod.cdv.tnpc.tactical;
import java.util.*;
public final class SurvivorPatch {
 static final int CAPACITY=27,MELEE_TICKS=20;
 static final String LIGHT="TacZNpcStoredFlashlight13",OFF="TacZNpcStoredOffhand13";
 static final Map<Object,Long> HITS=Collections.synchronizedMap(new WeakHashMap<>()),TICKS=Collections.synchronizedMap(new WeakHashMap<>());
 static final Map<Object,Route> ROUTES=Collections.synchronizedMap(new WeakHashMap<>());
 static final class Route {long next;double heading=Double.NaN;final Deque<double[]> visited=new ArrayDeque<>();}
 static Object call(Object o,String n,Object... a)throws Exception{return Reflect.call(o,n,a);}
 static long now(Object mob)throws Exception{return CalmBrain.now(mob);}
 static boolean isLight(Object stack)throws Exception{return !CalmLoot.empty(stack)&&Set.of("flashlight:flashlight","flashlight:flashlight_off").contains(CalmLoot.id(stack));}
 static Object read(Object mob,String key)throws Exception{return call(Reflect.type("net.minecraft.world.item.ItemStack"),"parseOptional",CalmLoot.registry(mob),call(CalmLoot.persistent(mob),"getCompound",key));}
 static void write(Object mob,String key,Object stack)throws Exception{Object tag=CalmLoot.persistent(mob);if(CalmLoot.empty(stack))call(tag,"remove",key);else call(tag,"put",key,call(stack,"save",CalmLoot.registry(mob)));}
 static Object activeLight(Object old)throws Exception{Object on=CalmLoot.stack("flashlight:flashlight");if(CalmLoot.empty(on))return old;call(on,"applyComponents",call(old,"getComponentsPatch"));call(on,"setCount",((Number)call(old,"getCount")).intValue());return on;}
 public static void flashlight(Object mob){try{
  if(!CalmBrain.bandit(mob)||TeamBrain.busy(mob))return;Object off=call(mob,"getOffhandItem");boolean night=Reflect.yes(call(call(mob,"level"),"isNight"));
  if(!night){if(isLight(off)){write(mob,LIGHT,off);Object restore=read(mob,OFF);call(mob,"setItemSlot",CalmLoot.slot("OFFHAND"),restore);write(mob,OFF,CalmLoot.emptyStack());}return;}
  if(isLight(off)){if(CalmLoot.id(off).endsWith("_off")){call(mob,"setItemSlot",CalmLoot.slot("OFFHAND"),activeLight(off));}return;}
  Object light=read(mob,LIGHT);if(CalmLoot.empty(light)){
   List<Object> bag=CalmLoot.bag(mob);for(int i=0;i<bag.size();i++)if(isLight(bag.get(i))){light=bag.remove(i);CalmLoot.saveBag(mob,bag);break;}
  }
  if(CalmLoot.empty(light))light=CalmLoot.stack("flashlight:flashlight");if(CalmLoot.empty(light))return;
  if(CalmLoot.id(light).endsWith("_off")){light=activeLight(light);}
  write(mob,OFF,off);call(mob,"setItemSlot",CalmLoot.slot("OFFHAND"),light);write(mob,LIGHT,CalmLoot.emptyStack());
 }catch(Exception e){CalmBrain.error("night-only flashlight",e);}}
 public static boolean hit(Object mob,Object target){try{if(!CalmBrain.managed(mob))return true;long time=now(mob);Long last=HITS.get(mob);if(last!=null&&time-last<MELEE_TICKS)return false;HITS.put(mob,time);return true;}catch(Exception e){CalmBrain.error("human melee cooldown",e);return false;}}
 public static void death(Object mob){try{
  if(!CalmBrain.managed(mob))return;for(String key:List.of(LIGHT,OFF)){Object stack=read(mob,key);if(!CalmLoot.empty(stack)){call(mob,"spawnAtLocation",stack);write(mob,key,CalmLoot.emptyStack());}}
  // Existing Remains 1.6.1 reads nine bag entries. Preserve additional cargo as death drops.
  List<Object> bag=CalmLoot.bag(mob);if(bag.size()>9){List<Object> extras=new ArrayList<>(bag.subList(9,bag.size()));CalmLoot.saveBag(mob,new ArrayList<>(bag.subList(0,9)));for(Object stack:extras)call(mob,"spawnAtLocation",stack);}
 }catch(Exception e){CalmBrain.error("stored equipment death drops",e);}}
 static boolean danger(Object mob)throws Exception{
  Object attacker=call(mob,"getLastHurtByMob");int age=((Number)Reflect.field(mob,"tickCount")).intValue()-((Number)call(mob,"getLastHurtByMobTimestamp")).intValue();
  if(age<=100&&CalmBrain.alive(attacker)&&!CalmBrain.allied(mob,attacker)&&CalmBrain.distance(mob,attacker)<256)return true;
  for(Object z:CalmBrain.nearby(mob,"net.minecraft.world.entity.monster.Zombie",16))if(CalmBrain.alive(z)&&CalmBrain.visible(mob,z)&&(call(z,"getTarget")==mob||CalmBrain.distance(mob,z)<12.25))return true;return false;
 }
 public static void emergency(Object mob){try{
  if(!CalmBrain.managed(mob)||!CalmBrain.alive(mob))return;Object target=null;double nearest=257;
  Object attacker=call(mob,"getLastHurtByMob");int age=((Number)Reflect.field(mob,"tickCount")).intValue()-((Number)call(mob,"getLastHurtByMobTimestamp")).intValue();
  if(age<=100&&CalmBrain.alive(attacker)&&!CalmBrain.allied(mob,attacker)&&CalmBrain.distance(mob,attacker)<256)target=attacker;
  if(target==null)for(Object z:CalmBrain.nearby(mob,"net.minecraft.world.entity.monster.Zombie",16)){double d=CalmBrain.distance(mob,z);if(CalmBrain.alive(z)&&CalmBrain.visible(mob,z)&&d<nearest&&(call(z,"getTarget")==mob||d<12.25)){target=z;nearest=d;}}
  if(target==null)return;TeamBrain.Memory m=TeamBrain.mem(mob);m.sheltering=m.tidying=false;m.investigateUntil=0;if(TeamBrain.busy(mob))TeamBrain.cancelAid(mob,m,now(mob));CalmBrain.State s=CalmBrain.state(mob);if(s.target!=target){CalmLoot.release(mob,s);s.target=target;s.reactAt=now(mob)+8;}call(mob,"setTarget",target);
 }catch(Exception e){CalmBrain.error("priority defense",e);}}
 public static boolean pauseSearch(Object mob){try{return TeamBrain.mem(mob).fleeing||TeamBrain.busy(mob)||TeamBrain.protectedPatient(mob)||CalmBrain.state(mob).target!=null||danger(mob);}catch(Exception e){CalmBrain.error("scavenge priority",e);return true;}}
 public static Object key(Object object){CalmLoot.Source source=(CalmLoot.Source)object;if(source.owner!=null&&Set.of("de.maxhenkel.corpse.entities.CorpseEntity","net.minecraft.world.entity.item.ItemEntity").contains(source.owner.getClass().getName()))return source.owner;return source.inventory!=null?source.inventory:source.list;}
 public static void syncEquipment(Object corpse,Object old,Object remaining)throws Exception{
  @SuppressWarnings("unchecked") List<Object> equipment=(List<Object>)call(call(corpse,"getDeath"),"getEquipment");for(int i=0;i<equipment.size();i++)if(!CalmLoot.empty(equipment.get(i))&&Reflect.yes(call(Reflect.type("net.minecraft.world.item.ItemStack"),"isSameItemSameComponents",old,equipment.get(i)))){equipment.set(i,call(remaining,"copy"));break;}
  Object display=call(Reflect.type("net.minecraft.core.NonNullList"),"withSize",equipment.size(),CalmLoot.emptyStack());for(int i=0;i<equipment.size();i++)call(display,"set",i,call(equipment.get(i),"copy"));call(corpse,"setEquipment",display);
 }
 static boolean corpseEmpty(Object owner)throws Exception{Object death=call(owner,"getDeath");for(String getter:List.of("getMainInventory","getArmorInventory","getOffHandInventory","getAdditionalItems"))for(Object stack:(List<?>)call(death,getter))if(!CalmLoot.empty(stack))return false;return true;}
 static Object sourceKey(CalmLoot.Source source){return source.owner!=null&&source.owner.getClass().getName().equals("de.maxhenkel.corpse.entities.CorpseEntity")?source.owner:CalmLoot.key(source);}
 static boolean available(Object mob,CalmLoot.Source s,long time){CalmLoot.Claim claim=CalmLoot.CLAIMS.get(CalmLoot.key(s));return (claim==null||claim.mob.get()==null||claim.mob.get()==mob||claim.until<=time)&&TeamBrain.mem(mob).skipped.getOrDefault(sourceKey(s),0L)<=time;}
 public static boolean allowed(Object mob,Object stack){try{if(CalmLoot.empty(stack)||!Reflect.type("net.minecraft.world.item.ArmorItem").isInstance(CalmLoot.item(stack)))return true;String id=CalmLoot.id(stack);return id.startsWith("selfexpression:")||id.startsWith("fracturepoint:");}catch(Exception e){CalmBrain.error("wearable upgrades",e);return false;}}
 public static double gearScore(Object stack)throws Exception{
  if(CalmLoot.empty(stack))return 0;Object item=CalmLoot.item(stack);if(Reflect.type("com.tacz.guns.api.item.IGun").isInstance(item))return 100;
  if(Reflect.type("net.minecraft.world.item.ArmorItem").isInstance(item))return 1+Reflect.number(call(item,"getDefense"));
  if(Reflect.type("net.minecraft.world.item.TieredItem").isInstance(item)){double bonus=0;try{bonus=Reflect.number(call(call(item,"getTier"),"getAttackDamageBonus"));}catch(NoSuchMethodException missing){}String name=CalmLoot.id(stack);return 4+bonus+(name.contains("axe")?1:name.contains("sword")?.5:0);}return 1;
 }
 static boolean equip(Object mob,Object candidate,Object slot)throws Exception{return slot!=null&&CalmLoot.preferred(mob,candidate,call(mob,"getItemBySlot",slot));}
 static double score(Object mob,Object stack)throws Exception{Object slot=CalmLoot.destination(stack);return (equip(mob,stack,slot)?10000:0)+TeamBrain.priority(stack,mob)*10+CalmLoot.gearScore(stack);}
 public static boolean useful(Object mob,Object object){try{
  CalmLoot.Source source=(CalmLoot.Source)object;List<Object> bag=CalmLoot.bag(mob);
  for(int i=0;i<source.size();i++){Object stack=source.get(i);if(CalmLoot.empty(stack))continue;Object slot=CalmLoot.destination(stack);if(equip(mob,stack,slot)&&(((Number)call(stack,"getCount")).intValue()==1||bag.size()<CAPACITY))return true;if(bag.size()<CAPACITY||CalmLoot.mergeIndex(bag,stack)>=0)return true;}return false;
 }catch(Exception e){CalmBrain.error("loot usefulness",e);return false;}}
 static double distance(Object mob,CalmLoot.Source s)throws Exception{double x=Reflect.coord(mob,"X")-s.x,y=Reflect.coord(mob,"Y")-s.y,z=Reflect.coord(mob,"Z")-s.z;return x*x+y*y+z*z;}
 public static Object find(Object mob,long time)throws Exception{
  List<CalmLoot.Source> sources=new ArrayList<>();Object level=call(mob,"level");
  try{Object data=call(Reflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"data",level);Map<?,?> map=(Map<?,?>)Reflect.field(data,"corpses");
   for(var entry:map.entrySet()){long packed=((Number)entry.getKey()).longValue();int x=(int)(packed>>38),y=(int)(packed<<52>>52),z=(int)(packed<<26>>38);if(Math.abs(x-Reflect.coord(mob,"X"))>24||Math.abs(z-Reflect.coord(mob,"Z"))>24||Math.abs(y-Reflect.coord(mob,"Y"))>5)continue;
    Object record=entry.getValue(),inventory=Reflect.field(record,"inventory");if(inventory==null)continue;Object pos=TeamBrain.pos(x,y,z);if(!Reflect.yes(call(level,"hasChunkAt",pos)))continue;String actual=String.valueOf(call(Reflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"blockId",call(level,"getBlockState",pos)));if(!actual.equals(String.valueOf(Reflect.field(record,"block"))))continue;sources.add(new CalmLoot.Source(inventory,null,data,x+.5,y,z+.5));
   }
  }catch(ClassNotFoundException missing){}catch(Exception e){CalmBrain.error("local corpse survey",e);}
  for(Object entity:CalmBrain.nearby(mob,"net.minecraft.world.entity.Entity",24)){
   String name=entity.getClass().getName();if(Reflect.yes(call(entity,"isRemoved")))continue;
   if(name.equals("net.minecraft.world.entity.item.ItemEntity"))sources.add(new CalmLoot.Source(null,new ArrayList<>(List.of(call(entity,"getItem"))),entity,Reflect.coord(entity,"X"),Reflect.coord(entity,"Y"),Reflect.coord(entity,"Z")));
   if(name.equals("de.maxhenkel.corpse.entities.CorpseEntity")){Object death=call(entity,"getDeath");for(String getter:List.of("getMainInventory","getArmorInventory","getOffHandInventory","getAdditionalItems")){@SuppressWarnings("unchecked") List<Object> list=(List<Object>)call(death,getter);sources.add(new CalmLoot.Source(null,list,entity,Reflect.coord(entity,"X"),Reflect.coord(entity,"Y"),Reflect.coord(entity,"Z")));}}
  }
  CalmLoot.Source best=null;double value=-Double.MAX_VALUE;
  for(CalmLoot.Source source:sources){if(!available(mob,source,time))continue;double d=distance(mob,source);if(d>24*24)continue;
   boolean any=false;double priority=0;for(int i=0;i<source.size();i++){Object stack=source.get(i);if(!CalmLoot.empty(stack)){any=true;priority=Math.max(priority,score(mob,stack));}}
   if(!any&&source.inventory==null&&source.owner!=null){String type=source.owner.getClass().getName();if(type.equals("net.minecraft.world.entity.item.ItemEntity")||type.equals("de.maxhenkel.corpse.entities.CorpseEntity")&&!corpseEmpty(source.owner))continue;}
   if(any&&!useful(mob,source))continue;double candidate=priority-Math.sqrt(d)*8;
   if(candidate>value){best=source;value=candidate;}
  }
  return best!=null&&CalmLoot.claim(best,mob,time)?best:null;
 }
 public static void search(Object mob,Object object,long time)throws Exception{
  CalmBrain.State s=(CalmBrain.State)object;if(pauseSearch(mob))return;if(s.corpse==null&&time>=s.nextLoot){s.nextLoot=time+20;s.corpse=find(mob,time);s.lootStart=s.lootApproach=Long.MIN_VALUE;if(s.corpse!=null){TeamBrain.Memory m=TeamBrain.mem(mob);m.sheltering=m.tidying=false;m.investigateUntil=0;m.sourceKey=null;}}
 }
 public static void prepare(Object mob){try{
  if(!CalmBrain.managed(mob)||Reflect.yes(call(call(mob,"level"),"isClientSide")))return;flashlight(mob);long time=now(mob);if(TICKS.getOrDefault(mob,Long.MIN_VALUE)==time)return;TICKS.put(mob,time);
  if(time%20==0){search(mob,CalmBrain.state(mob),time);Object goals=Reflect.field(mob,"goalSelector");Route r=ROUTES.get(mob);if(r==null){ROUTES.put(mob,new Route());call(goals,"removeAllGoals",(java.util.function.Predicate<Object>)(g->g.getClass().getSimpleName().equals("WaterAvoidingRandomStrollGoal")));call(goals,"addGoal",6,new SurveyGoal(mob));}}
 }catch(Exception e){CalmBrain.error("surroundings survey",e);}}
 public static boolean transfer(Object mob,Object object)throws Exception{
  CalmLoot.Source source=(CalmLoot.Source)object;if(!valid(mob,source))return false;List<Object> bag=CalmLoot.bag(mob);int index=-1;double priority=-Double.MAX_VALUE;Object destination=null,old=null;
  for(int i=0;i<source.size();i++){Object stack=source.get(i);if(CalmLoot.empty(stack))continue;Object slot=CalmLoot.destination(stack);boolean upgrade=equip(mob,stack,slot)&&(((Number)call(stack,"getCount")).intValue()==1||bag.size()<CAPACITY);if(!upgrade&&bag.size()>=CAPACITY&&CalmLoot.mergeIndex(bag,stack)<0)continue;double value=score(mob,stack);if(value>priority){priority=value;index=i;destination=upgrade?slot:null;old=upgrade?call(mob,"getItemBySlot",slot):null;}}
  if(index<0){finished(mob,source);return false;}Object original=source.get(index),taken=call(original,"copy"),remaining=call(original,"copy");List<Object> updated=new ArrayList<>(bag);
  if(destination!=null){call(taken,"setCount",1);if(((Number)call(original,"getCount")).intValue()==1)remaining=call(old,"copy");else{call(remaining,"shrink",1);if(!CalmLoot.empty(old))updated.add(call(old,"copy"));}}
  else{int merge=CalmLoot.mergeIndex(updated,taken);int count=((Number)call(original,"getCount")).intValue(),limit=((Number)call(taken,"getMaxStackSize")).intValue();int amount=Math.min(count,merge<0?limit:limit-((Number)call(updated.get(merge),"getCount")).intValue());call(taken,"setCount",amount);call(remaining,"shrink",amount);if(merge<0)updated.add(taken);else{Object merged=call(updated.get(merge),"copy");call(merged,"setCount",((Number)call(merged,"getCount")).intValue()+amount);updated.set(merge,merged);}}
  Object tag=CalmLoot.persistent(mob),backup=call(tag,"getList",CalmLoot.INVENTORY,10);
  try{CalmLoot.saveBag(mob,updated);if(destination!=null)call(mob,"setItemSlot",destination,taken);source.set(index,remaining);if(source.inventory!=null&&source.owner!=null)call(source.owner,"setDirty");}
  catch(Exception failure){call(tag,"put",CalmLoot.INVENTORY,backup);if(destination!=null)call(mob,"setItemSlot",destination,old);source.set(index,original);throw failure;}
  call(tag,"putInt","TacZNpcScavengingXP",Math.min(120,((Number)call(tag,"getInt","TacZNpcScavengingXP")).intValue()+1));TeamBrain.Memory memory=TeamBrain.mem(mob);memory.lootSince=now(mob);memory.skipped.remove(sourceKey(source));finished(mob,source);return true;
 }
 public static void finished(Object mob,Object object){try{
  CalmLoot.Source source=(CalmLoot.Source)object;for(int i=0;i<source.size();i++)if(!CalmLoot.empty(source.get(i)))return;
  if(source.owner==null)return;String type=source.owner.getClass().getName();if(type.equals("net.minecraft.world.entity.item.ItemEntity")){call(source.owner,"discard");return;}
  if(type.equals("de.maxhenkel.corpse.entities.CorpseEntity")){Object death=call(source.owner,"getDeath");for(String getter:List.of("getMainInventory","getArmorInventory","getOffHandInventory","getAdditionalItems"))for(Object item:(List<?>)call(death,getter))if(!CalmLoot.empty(item))return;call(source.owner,"discard");return;}
  Object level=call(mob,"level"),data=call(Reflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"data",level);Map<?,?> records=(Map<?,?>)Reflect.field(data,"corpses");long key=CalmLoot.position((int)Math.floor(source.x),(int)Math.floor(source.y),(int)Math.floor(source.z));Object record=records.get(key);if(record==null||Reflect.field(record,"inventory")!=source.inventory)return;Object pos=TeamBrain.pos(source.x,source.y,source.z);String id=String.valueOf(call(Reflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"blockId",call(level,"getBlockState",pos)));if(!id.equals(String.valueOf(Reflect.field(record,"block"))))return;
  if(Reflect.yes(call(level,"destroyBlock",pos,false,mob))){records.remove(key);call(data,"setDirty");TeamBrain.mode(mob,1,now(mob));}
 }catch(ClassNotFoundException missing){}catch(Exception e){CalmBrain.error("empty-only corpse removal",e);}}
 static boolean valid(Object mob,CalmLoot.Source source)throws Exception{
  if(source.owner==null)return true;if(source.list!=null)return !Reflect.yes(call(source.owner,"isRemoved"));
  Object record=((Map<?,?>)Reflect.field(source.owner,"corpses")).get(CalmLoot.position((int)Math.floor(source.x),(int)Math.floor(source.y),(int)Math.floor(source.z)));if(record==null||Reflect.field(record,"inventory")!=source.inventory)return false;Object pos=TeamBrain.pos(source.x,source.y,source.z);Object level=call(mob,"level");return Reflect.yes(call(level,"hasChunkAt",pos))&&String.valueOf(Reflect.field(record,"block")).equals(String.valueOf(call(Reflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"blockId",call(level,"getBlockState",pos))));
 }
 public static boolean nightPause(Object mob){try{return active(mob)||(!danger(mob)&&!TeamBrain.mem(mob).fleeing&&Reflect.number(call(mob,"getHealth"))/Reflect.number(call(mob,"getMaxHealth"))>.3);}catch(Exception e){return active(mob);}}
 public static boolean lootGate(Object mob,Object state,long time){return false;}
 public static void idle(Object mob,Object object,long time)throws Exception{
  CalmBrain.State s=(CalmBrain.State)object;if(!(s.corpse instanceof CalmLoot.Source))return;if(pauseSearch(mob)){CalmLoot.release(mob,s);CalmBrain.crouch(mob,false);return;}CalmLoot.Source source=(CalmLoot.Source)s.corpse;if(!valid(mob,source)){CalmLoot.release(mob,s);CalmBrain.crouch(mob,false);return;}
  if(source.list!=null&&Reflect.yes(call(source.owner,"isRemoved"))){CalmLoot.release(mob,s);CalmBrain.crouch(mob,false);return;}
  if(source.owner!=null&&source.owner.getClass().getName().equals("net.minecraft.world.entity.item.ItemEntity"))source.list.set(0,call(source.owner,"getItem"));
  if(!CalmLoot.claim(source,mob,time)){CalmLoot.release(mob,s);return;}TeamBrain.Memory memory=TeamBrain.mem(mob);
  if(!Objects.equals(memory.sourceKey,sourceKey(source))){memory.sourceKey=sourceKey(source);memory.lootSince=time;}
  if(distance(mob,source)>5){CalmBrain.crouch(mob,false);CalmBrain.path(mob,s,time,source.x,source.y,source.z,1.0);if(s.lootApproach==Long.MIN_VALUE)s.lootApproach=time;if(time-s.lootApproach>240){memory.skipped.put(sourceKey(source),time+300);CalmLoot.release(mob,s);s.nextLoot=time+20;}return;}
  call(call(mob,"getNavigation"),"stop");CalmBrain.crouch(mob,true);call(call(mob,"getLookControl"),"setLookAt",source.x,source.y+.2,source.z,15f,15f);
  if(time%20==0){TeamBrain.mode(mob,1,time);TeamBrain.swing(mob,false);}if(s.lootStart==Long.MIN_VALUE)s.lootStart=time;
  if(time-s.lootStart>=20){boolean moved=transfer(mob,source);s.lootStart=time;if(!moved){boolean contents=false;for(int i=0;i<source.size();i++)contents|=!CalmLoot.empty(source.get(i));if(contents)memory.skipped.put(sourceKey(source),time+100);CalmLoot.release(mob,s);s.nextLoot=time+1;CalmBrain.crouch(mob,false);}}
 }
 public static boolean active(Object mob){return CalmBrain.state(mob).corpse!=null;}
 public static boolean surveyUse(Object mob){try{if(nightPause(mob)&&!active(mob))TeamBrain.mem(mob).sheltering=false;return CalmBrain.managed(mob)&&!pauseSearch(mob)&&!active(mob)&&!TeamBrain.mem(mob).sheltering;}catch(Exception e){return false;}}
 public static void survey(Object mob){try{
  long time=now(mob);Route route=ROUTES.computeIfAbsent(mob,k->new Route());if(time<route.next)return;search(mob,CalmBrain.state(mob),time);if(active(mob))return;Object nav=call(mob,"getNavigation");if(!Reflect.yes(call(nav,"isDone"))){route.next=time+20;return;}
  double x=Reflect.coord(mob,"X"),y=Reflect.coord(mob,"Y"),z=Reflect.coord(mob,"Z");if(Double.isNaN(route.heading))route.heading=CalmBrain.state(mob).random.nextDouble()*Math.PI*2;Object path=null;double best=-Double.MAX_VALUE,bx=x,bz=z;
  for(int i=0;i<10;i++){double heading=route.heading+(i<6?(i-2.5)*.3:CalmBrain.state(mob).random.nextDouble()*Math.PI*2);double length=10+CalmBrain.state(mob).random.nextInt(9),dx=x+Math.cos(heading)*length,dz=z+Math.sin(heading)*length;Object pos=TeamBrain.pos(dx,y,dz);if(!Reflect.yes(call(call(mob,"level"),"hasChunkAt",pos)))continue;Object candidate=call(nav,"createPath",dx,y,dz,0);if(candidate==null||!Reflect.yes(call(candidate,"canReach")))continue;double quality=length;for(double[] old:route.visited)if(Math.hypot(old[0]-dx,old[1]-dz)<12)quality-=30;if(quality>best){best=quality;path=candidate;bx=dx;bz=dz;}}
  if(path!=null){call(nav,"moveTo",path,.95);route.heading=Math.atan2(bz-z,bx-x);route.visited.addLast(new double[]{x,z});if(route.visited.size()>16)route.visited.removeFirst();}else route.heading+=Math.PI*.5;route.next=time+40;
 }catch(Exception e){CalmBrain.error("search route",e);}}
}
