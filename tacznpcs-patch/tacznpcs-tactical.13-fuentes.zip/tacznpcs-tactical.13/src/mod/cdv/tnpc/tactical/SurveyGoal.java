package mod.cdv.tnpc.tactical;
import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;
public final class SurveyGoal extends Goal {final Object mob;public SurveyGoal(Object mob){this.mob=mob;setFlags(EnumSet.of(Flag.MOVE));}public boolean canUse(){return SurvivorPatch.surveyUse(mob);}public boolean requiresUpdateEveryTick(){return true;}public void tick(){SurvivorPatch.survey(mob);}public void stop(){try{Reflect.call(Reflect.call(mob,"getNavigation"),"stop");}catch(Exception e){CalmBrain.error("survey stop",e);}}}
