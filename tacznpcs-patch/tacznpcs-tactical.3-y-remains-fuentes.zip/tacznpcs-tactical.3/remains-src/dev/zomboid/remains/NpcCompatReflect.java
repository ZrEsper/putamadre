package dev.zomboid.remains;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
public final class NpcCompatReflect {
 private static final Map<String,Method> CACHE=new ConcurrentHashMap<>();
 public static Class<?> type(String n)throws Exception{return Class.forName(n);}
 public static Object field(Object o,String n)throws Exception{for(Class<?> c=o instanceof Class<?>?(Class<?>)o:o.getClass();c!=null;c=c.getSuperclass())try{Field f=c.getDeclaredField(n);f.setAccessible(true);return f.get(o instanceof Class<?>?null:o);}catch(NoSuchFieldException e){}throw new NoSuchFieldException(n);}
 public static Object call(Object o,String n,Object... args)throws Exception{
  Class<?> c=o instanceof Class<?>?(Class<?>)o:o.getClass();String key=c.getName()+"#"+n+Arrays.toString(Arrays.stream(args).map(a->a==null?null:a.getClass()).toArray());Method m=CACHE.get(key);
  if(m==null){List<Method> methods=new ArrayList<>(Arrays.asList(c.getMethods()));for(Class<?> t=c;t!=null;t=t.getSuperclass())methods.addAll(Arrays.asList(t.getDeclaredMethods()));
   outer:for(Method candidate:methods){if(!candidate.getName().equals(n)||candidate.getParameterCount()!=args.length)continue;Class<?>[] types=candidate.getParameterTypes();for(int i=0;i<args.length;i++){Class<?> t=types[i];if(t==double.class && args[i] instanceof Number)continue;if(t==float.class && (args[i] instanceof Integer || args[i] instanceof Long || args[i] instanceof Float))continue;if(t==long.class && args[i] instanceof Integer)continue;if(t.isPrimitive())t=t==int.class?Integer.class:t==float.class?Float.class:t==double.class?Double.class:t==long.class?Long.class:t==boolean.class?Boolean.class:t;if(args[i]==null?types[i].isPrimitive():!t.isInstance(args[i]))continue outer;}m=candidate;m.setAccessible(true);break;}if(m==null)throw new NoSuchMethodException(c.getName()+"."+n);CACHE.put(key,m);}
  return m.invoke(o instanceof Class<?>?null:o,args);
 }
 public static double number(Object o){return ((Number)o).doubleValue();}
 public static double coord(Object o,String axis)throws Exception{return number(call(o,"get"+axis));}
 public static boolean yes(Object o){return Boolean.TRUE.equals(o);}
}
