package dev.zomboid.remains;
/** Adds TacZ NPC corpse recognition without installing the unrelated tacz_bandits controller. */
public final class NpcCompatibility {
 public static boolean isBandit(Object entity){try{
  Object registry=NpcCompatReflect.field(NpcCompatReflect.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE");
  String id=String.valueOf(NpcCompatReflect.call(registry,"getKey",NpcCompatReflect.call(entity,"getType")));
  return id.equals("tacz_bandits:bandit")||id.equals("tacznpcs:npc");
 }catch(Exception e){throw new IllegalStateException("NPC corpse identity lookup failed",e);}}
 public static boolean populateNpc(Object corpse,Object level,Object mob){try {
  Object registry=NpcCompatReflect.field(NpcCompatReflect.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE");
  if(!String.valueOf(NpcCompatReflect.call(registry,"getKey",NpcCompatReflect.call(mob,"getType"))).equals("tacznpcs:npc"))return false;
  Object main=NpcCompatReflect.call(mob,"getMainHandItem");
  if(!NpcCompatReflect.yes(NpcCompatReflect.call(main,"isEmpty")))NpcCompatReflect.call(NpcCompatReflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"add",corpse,NpcCompatReflect.call(main,"copy"));
  for(Object stack:(Iterable<?>)NpcCompatReflect.call(mob,"getArmorSlots"))if(!NpcCompatReflect.yes(NpcCompatReflect.call(stack,"isEmpty")))NpcCompatReflect.call(NpcCompatReflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"add",corpse,NpcCompatReflect.call(stack,"copy"));
  Object offhand=NpcCompatReflect.call(mob,"getOffhandItem");if(!NpcCompatReflect.yes(NpcCompatReflect.call(offhand,"isEmpty")))NpcCompatReflect.call(NpcCompatReflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"add",corpse,NpcCompatReflect.call(offhand,"copy"));
  appendStoredLoot(corpse,level,mob);
  NpcCompatReflect.call(NpcCompatReflect.type("dev.zomboid.remains.QualityLoot"),"populate",corpse,level,true);
  return true;
 }catch(Exception e){throw new IllegalStateException("Cannot populate NPC corpse",e);}}
 public static void extras(Object corpse,Object level,boolean bandit,boolean mutant,Object mob){try{
  Object registry=NpcCompatReflect.field(NpcCompatReflect.type("net.minecraft.core.registries.BuiltInRegistries"),"ENTITY_TYPE");
  if(String.valueOf(NpcCompatReflect.call(registry,"getKey",NpcCompatReflect.call(mob,"getType"))).equals("tacznpcs:npc"))return;
  NpcCompatReflect.call(NpcCompatReflect.type("dev.zomboid.remains.LootExtras"),"populate",corpse,level,bandit,mutant,mob);
 }catch(Exception e){throw new IllegalStateException("Cannot apply corpse extras",e);}}
 public static void appendStoredLoot(Object corpse,Object level,Object mob){try{
  Object tags=NpcCompatReflect.call(NpcCompatReflect.call(mob,"getPersistentData"),"getList","TacZNpcCalmInventory",10);
  int count=((Number)NpcCompatReflect.call(tags,"size")).intValue();
  for(int i=0;i<Math.min(9,count);i++){
   Object stack=NpcCompatReflect.call(NpcCompatReflect.type("net.minecraft.world.item.ItemStack"),"parseOptional",NpcCompatReflect.call(level,"registryAccess"),NpcCompatReflect.call(tags,"getCompound",i));
   if(!NpcCompatReflect.yes(NpcCompatReflect.call(stack,"isEmpty")))NpcCompatReflect.call(NpcCompatReflect.type("dev.zomboid.remains.ZombieRemainsLoot"),"add",corpse,stack);
  }
 }catch(Exception e){throw new IllegalStateException("Cannot preserve NPC stored loot in corpse",e);}}
}
