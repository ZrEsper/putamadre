package net.neoforged.neoforge.event.entity;public class EntityJoinLevelEvent {}
