from pathlib import Path
import subprocess,sys,hashlib,json
r=Path(__file__).resolve().parent
if len(sys.argv)!=3: raise SystemExit('Usage: python3 -B build.py TACTICAL_1.jar REMAINS_1_6_0.jar')
for name,expected in json.loads((r/'tool-checksums.json').read_text()).items():
 assert hashlib.sha256((r/'tools'/name).read_bytes()).hexdigest()==expected, 'Tool checksum mismatch: '+name
bases=[Path(arg).resolve() for arg in sys.argv[1:]]
for base,expected in zip(bases,json.loads((r/'base-checksums.json').read_text())):
 assert hashlib.sha256(base.read_bytes()).hexdigest()==expected, 'Base checksum mismatch: '+str(base)
cp=':'.join(str(p) for p in sorted((r/'tools').glob('asm*.jar')))
compiler=['java','-jar',str(r/'tools/ecj.jar'),'-21','-proc:none','-warn:none']
def run(*args):subprocess.run(list(args),check=True)
for folder,out in [('src','classes'),('remains-src','remains-classes')]:
 sources=[str(p) for p in (r/folder).rglob('*.java')]
 if folder=='src':sources += [str(p) for p in (r/'stubs').rglob('*.java')]
 run(*compiler,'-d',str(r/out),*sources)
run(*compiler,'-cp',cp,'-d',str(r/'patch-tool'),str(r/'Patch.java'))
base=str(bases[0])
run('java','-cp',str(r/'patch-tool')+':'+cp,'Patch',base,str(bases[1]),str(r/'patched'))
run(*compiler,'-cp',str(r/'classes')+':'+str(r/'remains-classes'),'-d',str(r/'test-classes'),*[str(p) for p in (r/'test-src').rglob('*.java')])
run('java','-Xverify:all','-cp',':'.join([str(r/'test-classes'),str(r/'classes'),str(r/'remains-classes'),str(r/'patched/npc'),base]),'mod.cdv.tnpc.tactical.Checks')

exec((r/"package.py").read_text())
