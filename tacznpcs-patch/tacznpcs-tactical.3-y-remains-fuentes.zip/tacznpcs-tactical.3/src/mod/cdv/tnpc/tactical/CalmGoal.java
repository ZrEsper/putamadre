package mod.cdv.tnpc.tactical;
import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;
public final class CalmGoal extends Goal {
 private final Object mob;
 public CalmGoal(Object mob){this.mob=mob;setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK,Flag.TARGET));}
 public boolean canUse(){return CalmBrain.managed(mob);}
 public boolean requiresUpdateEveryTick(){return true;}
 public void tick(){CalmBrain.control(mob);}
 public void stop(){CalmBrain.stop(mob);}
}
