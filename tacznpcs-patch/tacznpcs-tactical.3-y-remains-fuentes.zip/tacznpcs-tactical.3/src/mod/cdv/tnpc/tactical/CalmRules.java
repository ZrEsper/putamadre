package mod.cdv.tnpc.tactical;
/** Pure policy; units are game ticks and blocks. */
public final class CalmRules {
 public static final double WALK_SPEED=.1*.95;
 public static int tier(boolean armed,int armorPieces,boolean military){return Math.min(3,(armed?1:0)+(armorPieces>=2?1:0)+(military&&armorPieces>=3?1:0));}
 public static int reaction(int tier){return 24-tier*4;}
 public static int shotPause(int tier){return 14-tier*2;}
 public static double dispersion(int tier,double distance){return Math.max(.8,3.2-tier*.6)+Math.min(40,distance)*.035;}
 public static boolean military(double roll){return roll<.01;}
 public static double stepBack(double distance,boolean armed,int zombies){double desired=armed?(zombies>=4?11:8):5;return Math.min(armed?3:2,Math.max(0,desired-distance));}
 public static boolean hitAlly(double ax,double ay,double az,double bx,double by,double bz,double px,double py,double pz,double radius){double dx=bx-ax,dy=by-ay,dz=bz-az;double length=dx*dx+dy*dy+dz*dz;if(length<.001)return false;double t=((px-ax)*dx+(py-ay)*dy+(pz-az)*dz)/length;if(t<=0||t>=1)return false;double x=px-ax-dx*t,y=py-ay-dy*t,z=pz-az-dz*t;return x*x+y*y+z*z<radius*radius;}
}
