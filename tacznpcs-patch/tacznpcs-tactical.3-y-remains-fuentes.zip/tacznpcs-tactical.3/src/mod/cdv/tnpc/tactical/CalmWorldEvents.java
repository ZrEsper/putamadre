package mod.cdv.tnpc.tactical;
import java.util.function.Predicate;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
public final class CalmWorldEvents {
 public static void install(){try{Reflect.call(Reflect.field(Reflect.type("net.neoforged.neoforge.common.NeoForge"),"EVENT_BUS"),"register",CalmWorldEvents.class);}catch(Exception e){throw new IllegalStateException("Cannot register NPC zombie targeting",e);}}
 @SubscribeEvent public static void join(EntityJoinLevelEvent event){try{
  Object entity=Reflect.call(event,"getEntity"),level=Reflect.call(event,"getLevel");if(Reflect.yes(Reflect.call(level,"isClientSide"))||!Reflect.type("net.minecraft.world.entity.monster.Zombie").isInstance(entity))return;
  Class<?> mob=Reflect.type("net.minecraft.world.entity.Mob"),npc=Reflect.type("mod.cdv.tnpc.entity.AutoGunOperator");
  Predicate<Object> target=e->{try{return npc.isInstance(e)&&CalmBrain.bandit(e)&&CalmBrain.alive(e);}catch(Exception ex){CalmBrain.error("zombie target predicate",ex);return false;}};
  Object goal=Reflect.type("net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal").getConstructor(mob,Class.class,int.class,boolean.class,boolean.class,Predicate.class).newInstance(entity,npc,10,true,false,target);
  Reflect.call(Reflect.field(entity,"targetSelector"),"addGoal",3,goal);
 }catch(Exception e){CalmBrain.error("zombie targeting",e);}}
}
