import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
public class Patch implements Opcodes {
 static final String P="mod/cdv/tnpc/tactical/";
 static MethodInsnNode invoke(String cls,String name,String desc){return new MethodInsnNode(INVOKESTATIC,P+cls,name,desc,false);}
 static void reset(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;}
 public static void main(String[] args)throws Exception{
  int methods=0;Map<String,byte[]> changed=new HashMap<>();
  try(ZipFile zip=new ZipFile(args[0])){
   for(String name:List.of("mod/cdv/tnpc/TNPC.class",P+"BanditBrain.class","mod/cdv/tnpc/entity/AutoGunOperator.class","mod/cdv/tnpc/entity/goal/FireAtNearestTargetGoal.class")){
    ClassNode c=new ClassNode();new ClassReader(zip.getInputStream(zip.getEntry(name))).accept(c,0);
    for(MethodNode m:c.methods){
     if(name.endsWith("TNPC.class")&&m.name.equals("<init>")){for(AbstractInsnNode i:m.instructions.toArray())if(i.getOpcode()==RETURN){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,1));l.add(invoke("EggRegistration","install","(Ljava/lang/Object;)V"));m.instructions.insertBefore(i,l);}}
     if(name.endsWith("BanditBrain.class")){
      if(m.name.equals("call")){reset(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(new VarInsnNode(ALOAD,2));m.instructions.add(invoke("TacticalCombat","legacyCall","(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"));m.instructions.add(new InsnNode(ARETURN));}
      if(m.name.equals("levelTick")){InsnList l=new InsnList();LabelNode next=new LabelNode();l.add(new VarInsnNode(ALOAD,0));l.add(invoke("TacticalCombat","spawnAllowed","(Ljava/lang/Object;)Z"));l.add(new JumpInsnNode(IFNE,next));l.add(new InsnNode(RETURN));l.add(next);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(l);for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode mi && mi.name.equals("isSpectator")){mi.setOpcode(INVOKESTATIC);mi.owner=P+"TacticalCombat";mi.name="excludedPlayer";mi.desc="(Ljava/lang/Object;)Z";mi.itf=false;}}
      if(m.name.equals("aim")){reset(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(invoke("TacticalCombat","aim","(Ljava/lang/Object;)[D"));m.instructions.add(new InsnNode(ARETURN));}
      if(m.name.equals("tick")){InsnList l=new InsnList();LabelNode next=new LabelNode();l.add(new VarInsnNode(ALOAD,0));l.add(invoke("TacticalCombat","beforeTick","(Ljava/lang/Object;)Z"));l.add(new JumpInsnNode(IFEQ,next));l.add(new InsnNode(RETURN));l.add(next);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(l);}
     }
     if(name.endsWith("AutoGunOperator.class")&&m.name.equals("registerGoals")){boolean changedRadius=false;for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode mi && mi.name.equals("<init>")&&mi.owner.equals("mod/cdv/tnpc/entity/goal/FireAtNearestTargetGoal")){AbstractInsnNode p=i.getPrevious();if(!(p instanceof LdcInsnNode value)||!Float.valueOf(8.0f).equals(value.cst))throw new IllegalStateException("Unexpected attack radius");value.cst=24.0f;changedRadius=true;}if(!changedRadius)throw new IllegalStateException("No gun goal constructor");}
     if(name.endsWith("AutoGunOperator.class")&&m.name.equals("readAdditionalSaveData")){
      boolean inserted=false;for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof FieldInsnNode f&&f.name.equals("TEMPLATES")){AbstractInsnNode next=i.getNext();while(next!=null&&next.getOpcode()!=ALOAD)next=next.getNext();if(next==null)throw new IllegalStateException("template lookup not found");m.instructions.insert(next,invoke("EggRegistration","resolveTemplate","(Ljava/lang/String;)Ljava/lang/String;")); // Also resolve the local so saved templateId remains the actual loadout.
       int index=((VarInsnNode)next).var;InsnList update=new InsnList();update.add(new VarInsnNode(ALOAD,index));update.add(invoke("EggRegistration","resolveTemplate","(Ljava/lang/String;)Ljava/lang/String;"));update.add(new VarInsnNode(ASTORE,index));m.instructions.insertBefore(i,update);inserted=true;break;}if(!inserted)throw new IllegalStateException("missing template hook");
     }
     if(name.endsWith("FireAtNearestTargetGoal.class")&&m.name.equals("tick")){
      InsnList l=new InsnList();LabelNode next=new LabelNode();l.add(new VarInsnNode(ALOAD,0));l.add(new FieldInsnNode(GETFIELD,c.name,"mob","Lmod/cdv/tnpc/entity/AutoGunOperator;"));l.add(invoke("TacticalCombat","allowGoal","(Ljava/lang/Object;)Z"));l.add(new JumpInsnNode(IFNE,next));l.add(new InsnNode(RETURN));l.add(next);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(l);
      for(AbstractInsnNode i:m.instructions.toArray())if(i.getOpcode()==RETURN){InsnList move=new InsnList();move.add(new VarInsnNode(ALOAD,0));move.add(new FieldInsnNode(GETFIELD,c.name,"mob","Lmod/cdv/tnpc/entity/AutoGunOperator;"));move.add(invoke("TacticalCombat","movement","(Ljava/lang/Object;)V"));m.instructions.insertBefore(i,move);}
     }
    }
    ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_MAXS){protected String getCommonSuperClass(String a,String b){return "java/lang/Object";}};
    c.accept(writer);byte[] bytes=writer.toByteArray();ClassNode checked=new ClassNode();new ClassReader(bytes).accept(checked,0);for(MethodNode m:checked.methods)if(m.instructions.size()>0){new Analyzer<>(new BasicVerifier()).analyze(checked.name,m);methods++;}changed.put(name,bytes);
   }
  }
  Path out=Path.of(args[1]);Files.createDirectories(out);
  for(var e:changed.entrySet()){Path p=out.resolve(e.getKey());Files.createDirectories(p.getParent());Files.write(p,e.getValue());}
  System.out.println("PASS: analyzed "+methods+" patched-class methods with ASM BasicVerifier");
 }
}
