package mod.cdv.tnpc.tactical;
import java.util.*;
import java.util.function.Supplier;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
public final class EggRegistration {
 private static Object egg;
 public static void install(Object bus){try{
  Object registry=Reflect.field(Reflect.type("net.minecraft.core.registries.BuiltInRegistries"),"ITEM");
  Object register=Reflect.call(Reflect.type("net.neoforged.neoforge.registries.DeferredRegister"),"create",registry,"tacznpcs");
  egg=Reflect.call(register,"register","bandit_spawn_egg",(Supplier<Object>)EggRegistration::createEgg);
  Reflect.call(register,"register",bus);Reflect.call(bus,"register",EggRegistration.class);
 }catch(Exception e){throw new IllegalStateException("Cannot register tactical bandit egg",e);}}
 public static Object createEgg(){try{
  Object props=Reflect.type("net.minecraft.world.item.Item$Properties").getConstructor().newInstance();
  Object tag=Reflect.type("net.minecraft.nbt.CompoundTag").getConstructor().newInstance();
  Reflect.call(tag,"putString","id","tacznpcs:npc");Reflect.call(tag,"putString","template","__tactical_bandit");
  Object data=Reflect.call(Reflect.type("net.minecraft.world.item.component.CustomData"),"of",tag);
  Reflect.call(props,"component",Reflect.field(Reflect.type("net.minecraft.core.component.DataComponents"),"ENTITY_DATA"),data);
  Supplier<Object> entity=()->{try{return Reflect.field(Reflect.type("mod.cdv.tnpc.entity.AutoGunOperator"),"NPC_TYPE");}catch(Exception e){throw new IllegalStateException(e);}};
  return Reflect.type("net.neoforged.neoforge.common.DeferredSpawnEggItem").getConstructor(Supplier.class,int.class,int.class,props.getClass()).newInstance(entity,0xffffff,0xffffff,props);
 }catch(Exception e){throw new IllegalStateException("Cannot create tactical bandit egg",e);}}
 @SubscribeEvent public static void creative(BuildCreativeModeTabContentsEvent event){try{
  if(Reflect.call(event,"getTabKey").equals(Reflect.field(Reflect.type("net.minecraft.world.item.CreativeModeTabs"),"SPAWN_EGGS"))){
   Object stack=Reflect.call(Reflect.call(egg,"get"),"getDefaultInstance");
   Object visibility=Reflect.field(Reflect.type("net.minecraft.world.item.CreativeModeTab$TabVisibility"),"PARENT_AND_SEARCH_TABS");Reflect.call(event,"accept",stack,visibility);
  }
 }catch(Exception e){throw new IllegalStateException("Cannot populate tactical egg in creative",e);}}
 public static String resolveTemplate(String requested){if(!"__tactical_bandit".equals(requested))return requested;try{Map<?,?> templates=(Map<?,?>)Reflect.field(Reflect.type("mod.cdv.tnpc.data.TemplateDataManager"),"TEMPLATES");for(String id:List.of("bandits","bandit","illagers","default"))if(templates.containsKey(id))return id;throw new IllegalStateException("No NPC templates loaded");}catch(Exception e){throw new IllegalStateException("Cannot resolve bandit template",e);}}
}
