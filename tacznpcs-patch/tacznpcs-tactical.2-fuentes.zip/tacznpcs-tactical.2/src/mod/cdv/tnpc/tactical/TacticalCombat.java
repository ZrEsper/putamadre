package mod.cdv.tnpc.tactical;
import java.util.*;
public final class TacticalCombat {
 private static final Map<Object,Memory> MEMORIES=Collections.synchronizedMap(new WeakHashMap<>());
 private static final Set<String> ERRORS=new HashSet<>();
 private static final class Memory {Object target;long lastSeen=-1,readyAt;double x,y,z; final Random random=new Random(); final double skill=.7+random.nextDouble()*.6;}
 private static Memory memory(Object mob){return MEMORIES.computeIfAbsent(mob,k->new Memory());}
 private static boolean bandit(Object mob)throws Exception{return Reflect.yes(Reflect.call(Reflect.type("mod.cdv.tnpc.tactical.BanditBrain"),"bandit",mob));}
 private static long time(Object mob)throws Exception{return ((Number)Reflect.call(Reflect.call(mob,"level"),"getGameTime")).longValue();}
 private static boolean visible(Object mob,Object target)throws Exception{return Reflect.yes(Reflect.call(Reflect.call(mob,"getSensing"),"hasLineOfSight",target));}
 public static Object legacyCall(Object receiver,String name,Object[] arguments)throws Exception {if(name.equals("isSpectator")&&arguments.length==0&&Reflect.type("net.minecraft.world.entity.player.Player").isInstance(receiver))return excludedPlayer(receiver);return Reflect.call(receiver,name,arguments);}
 public static boolean eligible(Object target)throws Exception {if(!Reflect.yes(Reflect.call(target,"isAlive")))return false;if(Reflect.type("net.minecraft.world.entity.player.Player").isInstance(target))return !Reflect.yes(Reflect.call(target,"isCreative"))&&!Reflect.yes(Reflect.call(target,"isSpectator"));return true;}
 public static boolean excludedPlayer(Object target)throws Exception{return !eligible(target);}
 public static boolean spawnAllowed(Object event){try{Object level=Reflect.call(event,"getLevel");if(Reflect.yes(Reflect.call(level,"isClientSide")))return false;if(String.valueOf(Reflect.call(level,"getDifficulty")).equalsIgnoreCase("peaceful"))return false;Object rules=Reflect.call(level,"getGameRules");return Reflect.yes(Reflect.call(rules,"getBoolean",Reflect.field(Reflect.type("net.minecraft.world.level.GameRules"),"RULE_DOMOBSPAWNING")));}catch(Exception e){error("spawn conditions",e);return false;}}
 private static void error(String op,Exception e){synchronized(ERRORS){if(ERRORS.add(op))System.err.println("[TacZ NPCs Tactical] "+op+": "+e);}}
 public static boolean beforeTick(Object mob){try{
  if(Reflect.yes(Reflect.call(Reflect.call(mob,"level"),"isClientSide"))||!bandit(mob))return false;
  Memory m=memory(mob);long now=time(mob);Object legacy=Reflect.call(Reflect.type("mod.cdv.tnpc.tactical.BanditBrain"),"state",mob);if(((Number)Reflect.field(legacy,"retreatUntil")).longValue()>now){m.target=null;m.lastSeen=-1;return false;}Object target=Reflect.call(mob,"getTarget");
  if(target!=null){
   boolean invalid=!Reflect.yes(Reflect.call(target,"isAlive"));
   if(Reflect.type("net.minecraft.world.entity.player.Player").isInstance(target))invalid|=Reflect.yes(Reflect.call(target,"isCreative"))||Reflect.yes(Reflect.call(target,"isSpectator"));
   if(invalid){Reflect.call(mob,"setTarget",(Object)null);m.target=null;m.lastSeen=-1;return false;}
   if(visible(mob,target)){if(m.target!=target){m.readyAt=now+6+m.random.nextInt(9);m.target=target;}m.lastSeen=now;m.x=Reflect.coord(target,"X");m.y=Reflect.coord(target,"Y");m.z=Reflect.coord(target,"Z");return false;}
   // Never pathfind to the current position of an unseen player.
   Reflect.call(mob,"setTarget",(Object)null);
  }
  if(m.target!=null&&m.lastSeen>=0&&now-m.lastSeen<=160){
   if(eligible(m.target)&&visible(mob,m.target)){Reflect.call(mob,"setTarget",m.target);m.readyAt=now+4+m.random.nextInt(5);return false;}
   if(now%10==0)Reflect.call(Reflect.call(mob,"getNavigation"),"moveTo",m.x,m.y,m.z,1.0);
   return true;
  }
  m.target=null;m.lastSeen=-1;return false;
 }catch(Exception e){error("perception",e);return false;}}
 public static boolean allowGoal(Object mob){try{if(!bandit(mob))return true;Object target=Reflect.call(mob,"getTarget");if(target==null)return true;if(!visible(mob,target))return false;Memory m=memory(mob);long now=time(mob);if(m.target!=target){m.target=target;m.readyAt=now+6+m.random.nextInt(9);}return now>=m.readyAt;}catch(Exception e){error("reaction",e);return false;}}
 public static void movement(Object mob){try{if(!bandit(mob))return;Object target=Reflect.call(mob,"getTarget");if(target==null||!visible(mob,target)||!allowGoal(mob))return;Object goal=Reflect.field(mob,"fireAtNearestTargetGoal");String gun=String.valueOf(Reflect.field(goal,"gunState"));if(gun.equals("RELOADING")||gun.equals("EMPTY"))return;double distance=Reflect.number(Reflect.call(mob,"distanceToSqr",target));if(distance<16||distance>576)return;long phase=(time(mob)+Math.abs(((Number)Reflect.call(mob,"getId")).intValue())*13L)%100;float side=phase<35?.35f:phase<70?-.35f:0;Reflect.call(Reflect.call(mob,"getMoveControl"),"strafe",0.0f,side);}catch(Exception e){error("combat movement",e);}}
 public static double[] aim(Object mob)throws Exception{
  Object target=Reflect.call(mob,"getTarget");if(target==null)return new double[]{Reflect.number(Reflect.call(mob,"getViewXRot",1.0f)),Reflect.number(Reflect.call(mob,"getViewYRot",1.0f))};
  double dx=Reflect.coord(target,"X")-Reflect.coord(mob,"X"),dz=Reflect.coord(target,"Z")-Reflect.coord(mob,"Z");double distance=Math.hypot(dx,dz);
  double y=Reflect.coord(target,"Y")+Reflect.number(Reflect.call(target,"getBbHeight"))*.52;
  Memory m=memory(mob);double spread=(.45+Math.min(distance,64)*.035)/m.skill;
  // Stable within a game tick, different across ticks and individuals; both axes use the same sample.
  long seed=((Number)Reflect.call(mob,"getId")).longValue()*341873128712L+time(mob)*132897987541L;
  Random r=new Random(seed);
  return new double[]{-Math.toDegrees(Math.atan2(y-Reflect.number(Reflect.call(mob,"getEyeY")),Math.max(.1,distance)))+r.nextGaussian()*spread,Math.toDegrees(Math.atan2(dz,dx))-90+r.nextGaussian()*spread};
 }
}
