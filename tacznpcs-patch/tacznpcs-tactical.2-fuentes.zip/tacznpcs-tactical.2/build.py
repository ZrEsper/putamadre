from pathlib import Path
import subprocess,zipfile,json,hashlib,sys
r=Path(__file__).resolve().parent
t=r/'tools'
for name,expected in json.loads((r/'tool-checksums.json').read_text()).items():
 assert hashlib.sha256((t/name).read_bytes()).hexdigest()==expected, 'Tool checksum mismatch: '+name
if len(sys.argv)!=2: raise SystemExit('Usage: python3 -B build.py /path/tacznpcs-2.1.0-1.21.1-tactical.1.jar')
base=Path(sys.argv[1]).resolve()
assert hashlib.sha256(base.read_bytes()).hexdigest()=='3cd3152065689f97d5cc11f07a8b6b7bf006a6e0c8abc52829a3849863f37cbe', 'Wrong input JAR'
cp=':'.join(str(p) for p in sorted(t.glob('asm*.jar')))
compiler=['java','-jar',str(t/'ecj.jar'),'-21','-proc:none','-warn:none']
def run(*args):subprocess.run(list(args),check=True)
run(*compiler,'-d',str(r/'classes'),*[str(p) for folder in ['src','stubs'] for p in (r/folder).rglob('*.java')])
run(*compiler,'-cp',cp,'-d',str(r/'patch-tool'),str(r/'Patch.java'))
run('java','-cp',str(r/'patch-tool')+':'+cp,'Patch',str(base),str(r/'patched'))
run(*compiler,'-cp',str(r/'classes'),'-d',str(r/'test-classes'),*[str(p) for p in (r/'test-src').rglob('*.java')])
run('java','-Xverify:all','-cp',':'.join(str(p) for p in [r/'test-classes',r/'classes',r/'patched',base]),'Tests')
changes={p.relative_to(r/'patched').as_posix():p.read_bytes() for p in (r/'patched').rglob('*.class')}
changes.update({p.relative_to(r/'classes').as_posix():p.read_bytes() for p in (r/'classes/mod').rglob('*.class')})
texture=(r/'resources/bandit_spawn_egg.png').read_bytes()
changes['assets/tacznpcs/textures/item/bandit_spawn_egg.png']=texture
changes['assets/tacznpcs/models/item/bandit_spawn_egg.json']=json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':'tacznpcs:item/bandit_spawn_egg'}}).encode()
with zipfile.ZipFile(base) as original:
 changes['META-INF/neoforge.mods.toml']=original.read('META-INF/neoforge.mods.toml').replace(b'2.1.0-tactical.1',b'2.1.0-tactical.2')
 for language,name in [('en_us','Tactical Bandit Spawn Egg'),('es_es','Huevo de bandido táctico'),('es_mx','Huevo de bandido táctico')]:
  key=f'assets/tacznpcs/lang/{language}.json';lang=json.loads(original.read(key)) if key in original.namelist() else {'entity.tacznpcs.npc':'NPC armado'}
  lang['item.tacznpcs.bandit_spawn_egg']=name;changes[key]=json.dumps(lang,ensure_ascii=False,indent=2).encode()
 output=r/'output/tacznpcs-2.1.0-1.21.1-tactical.2.jar';output.parent.mkdir(exist_ok=True)
 with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as out:
  for n in original.namelist():out.writestr(n,changes.pop(n,original.read(n)))
  for n,data in sorted(changes.items()):out.writestr(n,data)
 with zipfile.ZipFile(output) as final:
  assert final.testzip() is None
  assert len(final.namelist())==len(set(final.namelist()))
  assert not any(n.startswith(('net/','Tests','org/objectweb')) for n in final.namelist())
  permitted={'mod/cdv/tnpc/TNPC.class','mod/cdv/tnpc/tactical/BanditBrain.class','mod/cdv/tnpc/entity/AutoGunOperator.class','mod/cdv/tnpc/entity/goal/FireAtNearestTargetGoal.class','META-INF/neoforge.mods.toml','assets/tacznpcs/lang/en_us.json'}
  changed={n for n in original.namelist() if original.read(n)!=final.read(n)}
  assert changed==permitted,changed
  for n in ['mod/cdv/tnpc/TNPC$StructureSpawnHandler.class','mod/cdv/tnpc/tactical/BanditBrain$Regions.class','mod/cdv/tnpc/data/TemplateDataManager.class']:
   assert original.read(n)==final.read(n),n
  print('PASS: existing structure-spawn handler, regional ledger and templates preserved; only six existing entries changed; no API doubles packaged')
print(output)
print('SHA256',hashlib.sha256(output.read_bytes()).hexdigest())
