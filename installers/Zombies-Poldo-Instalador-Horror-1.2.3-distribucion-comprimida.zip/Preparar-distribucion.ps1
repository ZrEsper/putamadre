﻿$ErrorActionPreference = 'Stop'
try {
 $base = $PSScriptRoot
 $stage = Join-Path ([System.IO.Path]::GetTempPath()) ('Poldo-distribucion-' + [guid]::NewGuid().ToString('N'))
 New-Item -ItemType Directory -Path $stage | Out-Null
 $required = @('Zomboid-Installer.jar','Instalar.cmd','Instalar-debug.cmd','Abrir-Instalador.ps1','audio','pack','componentes','LEEME.txt')
 foreach ($name in $required) {
  $source = Join-Path $base $name
  if (-not (Test-Path $source)) { throw "Falta $name en la carpeta del instalador." }
  Copy-Item -LiteralPath $source -Destination $stage -Recurse
 }
 $destination = Join-Path $base 'Zombies-Poldo-Modpack-Completo.zip'
 if (Test-Path $destination) { throw 'Ya existe Zombies-Poldo-Modpack-Completo.zip. Renombralo antes de crear otro.' }
 Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $destination -CompressionLevel Optimal
 Write-Host "LISTO: $destination"
 Write-Host 'Envia ese ZIP. El jugador lo extrae y abre Instalar.cmd; los componentes se detectan automaticamente.'
} catch {
 Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
 Write-Host 'Si tu paquete supera los limites de Compress-Archive, comprime manualmente con 7-Zip las carpetas y archivos indicados en LEEME.txt.'
 exit 1
} finally {
 if ($stage -and (Test-Path $stage)) { Remove-Item -LiteralPath $stage -Recurse -Force }
}
