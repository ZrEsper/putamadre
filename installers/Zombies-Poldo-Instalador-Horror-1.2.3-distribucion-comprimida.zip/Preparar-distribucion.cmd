@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Preparar-distribucion.ps1"
pause
