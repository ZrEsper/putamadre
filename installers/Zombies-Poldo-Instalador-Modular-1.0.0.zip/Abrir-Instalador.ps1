﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
try {
    $candidates = [System.Collections.Generic.List[string]]::new()
    $fromPath = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($fromPath) { $candidates.Add($fromPath.Source) }
    if ($env:JAVA_HOME) { $candidates.Add((Join-Path $env:JAVA_HOME 'bin\java.exe')) }
    $runtimeRoots = @(
        (Join-Path $env:ProgramFiles 'Eclipse Adoptium'),
        (Join-Path $env:ProgramFiles 'Java'),
        (Join-Path $env:ProgramFiles 'Microsoft'),
        (Join-Path $env:USERPROFILE 'curseforge\minecraft\Install\runtime'),
        (Join-Path $env:APPDATA '.minecraft\runtime'),
        (Join-Path $env:APPDATA '.tlauncher\jvms'),
        (Join-Path $env:USERPROFILE '.tlauncher\jvms')
    )
    foreach ($runtimeRoot in $runtimeRoots) {
        if (Test-Path -LiteralPath $runtimeRoot -PathType Container) {
            Get-ChildItem -LiteralPath $runtimeRoot -Filter java.exe -Recurse -File -ErrorAction SilentlyContinue |
                Select-Object -First 100 |
                ForEach-Object { $candidates.Add($_.FullName) }
        }
    }
    $chosenJava = $null
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        try {
            $processInfo = New-Object System.Diagnostics.ProcessStartInfo
            $processInfo.FileName = $candidate
            $processInfo.Arguments = '-version'
            $processInfo.UseShellExecute = $false
            $processInfo.CreateNoWindow = $true
            $processInfo.RedirectStandardOutput = $true
            $processInfo.RedirectStandardError = $true
            $process = New-Object System.Diagnostics.Process
            $process.StartInfo = $processInfo
            [void]$process.Start()
            if (-not $process.WaitForExit(5000)) { $process.Kill(); $process.Dispose(); continue }
            $details = $process.StandardError.ReadToEnd() + $process.StandardOutput.ReadToEnd()
            $process.Dispose()
            if ($details -match 'version\s+"(\d+)[.\-]') {
                if ([int]$Matches[1] -ge 21) { $chosenJava = $candidate; break }
            }
        } catch { continue }
    }
    if (-not $chosenJava) {
        [System.Windows.Forms.MessageBox]::Show(
            'No se encontró Java 21. Instala Temurin Java 21 o ejecuta Minecraft 1.21.1 desde tu launcher para que descargue su Java. Después vuelve a abrir este instalador. No necesita permisos de administrador.',
            'Zombies Poldo · Java 21 necesario', 'OK', 'Information') | Out-Null
        exit 1
    }
    $javaWindow = Join-Path (Split-Path -Parent $chosenJava) 'javaw.exe'
    if (-not (Test-Path -LiteralPath $javaWindow)) { $javaWindow = $chosenJava }
    $installerJar = Join-Path $PSScriptRoot 'Zomboid-Installer.jar'
    if (-not (Test-Path -LiteralPath $installerJar)) { throw 'Extrae todo el ZIP antes de abrir Instalar.cmd.' }
    Start-Process -FilePath $javaWindow -ArgumentList @('-jar', ('"' + $installerJar + '"')) -WorkingDirectory $PSScriptRoot
} catch {
    [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'No se pudo abrir el instalador', 'OK', 'Error') | Out-Null
    exit 1
}
