@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Abrir-Instalador.ps1" -Debug
pause
