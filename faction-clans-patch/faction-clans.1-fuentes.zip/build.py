#!/usr/bin/env python3
from pathlib import Path
import sys,hashlib,json,subprocess,zipfile,copy,shutil
r=Path(__file__).resolve().parent;base=Path(sys.argv[1]).resolve()
assert hashlib.sha256(base.read_bytes()).hexdigest()==json.loads((r/'base.sha256.json').read_text())['sha256'],'Different base JAR'
for name,digest in json.loads((r/'tools.sha256.json').read_text()).items():assert hashlib.sha256((r/'tools'/name).read_bytes()).hexdigest()==digest,name
for d in ['classes','patch-tool','patched','test-classes']:
 shutil.rmtree(r/d,ignore_errors=True);(r/d).mkdir()
def run(*args):subprocess.run(args,check=True,cwd=r)
ecj=['java','-jar',str(r/'tools/ecj.jar'),'-21','-nowarn']
run(*ecj,'-d',str(r/'classes'),*[str(p) for folder in ['stubs','src'] for p in (r/folder).rglob('*.java')])
asm=':'.join(str(r/'tools'/n) for n in ['asm.jar','asm-tree.jar','asm-analysis.jar','asm-util.jar'])
run(*ecj,'-cp',asm,'-d',str(r/'patch-tool'),str(r/'Patch.java'))
run('java','-Xverify:all','-cp',str(r/'patch-tool')+':'+asm,'Patch',str(base),str(r/'patched'))
if (r/'tests').exists():
 run(*ecj,'-cp',str(r/'patched')+':'+str(r/'classes'),'-d',str(r/'test-classes'),*[str(p) for p in (r/'tests').rglob('*.java')])
 run('java','-Xverify:all','-cp',str(r/'test-classes')+':'+str(r/'patched')+':'+str(r/'classes'),'ClanChecks')
add={p.relative_to(r/'patched').as_posix():p.read_bytes() for p in (r/'patched').rglob('*.class')}
add.update({p.relative_to(r/'classes').as_posix():p.read_bytes() for p in (r/'classes/dev/zomboid/clans').rglob('*.class')})
with zipfile.ZipFile(base) as z:
 toml=z.read('META-INF/neoforge.mods.toml').decode().replace('version="1.8.0R-1.21.1-NEOFORGE"','version="1.8.0R-zomboid-clans.1"');toml=toml.replace('displayName="Faction Friction"','displayName="Faction Friction - Zomboid Clans"').replace('Faction Friction brings','Zomboid Clans patch: survivor notebook, scored skirmishes and sieges, five-minute preparation, online defender protection and persistent mixed rewards.\n\nFaction Friction brings');add['META-INF/neoforge.mods.toml']=toml.encode()
 # Original translations and tier enum identifiers remain compatible; only presentation changes.
 for n in ['assets/factionfriction/lang/en_us.json','assets/factionfriction/lang/es_es.json']:
  if n in z.namelist():lang=json.loads(z.read(n))
  else:lang=json.loads(z.read('assets/factionfriction/lang/en_us.json'))
  for k,v in list(lang.items()):
   if k.endswith('.tier.team'):lang[k]='Banda' if 'es_es' in n else 'Survivor Band'
   if k.endswith('.tier.colony'):lang[k]='Refugio' if 'es_es' in n else 'Settlement'
   if k.endswith('.tier.country'):lang[k]='Coalición' if 'es_es' in n else 'Coalition'
  lang['key.factionfriction.open_ui']='Cuaderno de clanes' if 'es_es' in n else 'Survival Clan Notebook';add[n]=json.dumps(lang,ensure_ascii=False,indent=2).encode()
 out=r/'output/factionfriction-1.8.0R-1.21.1-NEOFORGE-zomboid-clans.1.jar';out.parent.mkdir(exist_ok=True);modified=set(add)
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for e in z.infolist():w.writestr(copy.copy(e),add.pop(e.filename,z.read(e)))
  for n,b in sorted(add.items()):w.writestr(n,b)
 with zipfile.ZipFile(out) as w:
  assert w.testzip() is None
  for n in z.namelist():
   if n not in modified:assert z.read(n)==w.read(n),n
  assert not any(n.startswith('net/') for n in w.namelist())
 print('PASS preserved all untouched original resources/classes:',out.name)
