package net.minecraft.core;public class HolderLookup{public interface Provider{}}
