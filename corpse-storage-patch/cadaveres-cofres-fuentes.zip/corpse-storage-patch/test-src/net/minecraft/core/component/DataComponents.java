package net.minecraft.core.component;public class DataComponents{public static final Object CUSTOM_NAME=new Object();}
