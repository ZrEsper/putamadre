import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
public class Patch implements Opcodes {
 public static void main(String[] args)throws Exception{
  try(ZipFile z=new ZipFile(args[0])){
   for(String name:List.of("dev/survivorcreator/net/Net$Confirm","dev/survivorcreator/net/Net$SyncChar","dev/survivorcreator/effects/Effects","dev/survivorcreator/hearing/XpRules")){
    ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class"))).accept(c,0);int changes=0;
    for(MethodNode m:c.methods){
     if(name.endsWith("Effects")&&m.name.equals("firstGrant")){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new MethodInsnNode(INVOKESTATIC,"dev/survivorcreator/creation/CreationSummary","seed","(Ljava/lang/Object;)V",false));m.instructions.insert(l);changes++;}
     if(name.endsWith("XpRules")&&m.name.equals("scale"))for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.owner.equals("dev/survivorcreator/skills/ProgressRules")&&call.name.equals("scale")){
      InsnList l=new InsnList();l.add(new VarInsnNode(DSTORE,4));l.add(new VarInsnNode(ALOAD,0));l.add(new VarInsnNode(DLOAD,4));l.add(new MethodInsnNode(INVOKESTATIC,"dev/survivorcreator/creation/CreationSummary","xp","(Ljava/lang/Object;D)D",false));m.instructions.insert(i,l);changes++;
     }
     if(name.contains("Net$"))for(AbstractInsnNode i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.name.equals("list")&&call.owner.equals("net/minecraft/network/codec/ByteBufCodecs")){AbstractInsnNode prev=i.getPrevious();while(prev.getOpcode()<0)prev=prev.getPrevious();if(!(prev instanceof IntInsnNode v)||v.operand!=64)throw new IllegalStateException("Unexpected packet cap "+prev.getClass()+" "+prev.getOpcode()+(prev instanceof LdcInsnNode x?" "+x.cst:""));m.instructions.set(prev,new LdcInsnNode(Integer.MAX_VALUE));changes++;}
    }
    if(changes!=1)throw new IllegalStateException(name+" changes "+changes);
    ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] out=w.toByteArray();ClassNode checked=new ClassNode();new ClassReader(out).accept(checked,0);for(MethodNode m:checked.methods)if(m.instructions.size()>0)new Analyzer<>(new BasicVerifier()).analyze(checked.name,m);
    Path p=Path.of(args[1],name+".class");Files.createDirectories(p.getParent());Files.write(p,out);System.out.println("PASS transform "+name);
   }
  }
 }
}
