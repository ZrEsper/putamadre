from pathlib import Path
import json
r=Path(__file__).resolve().parent/'resources'
def put(kind,id,data):
 p=r/f'data/survivorcreator/survivor/{kind}/{id}.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def item(id,n=1):return {'type':'start_item','item':id,'count':n}
def attr(id,n):return {'type':'attribute','attribute':'minecraft:generic.'+id,'amount':n,'operation':'add'}
def exhaustion(n):return {'type':'exhaustion','multiplier':n}
def damage(n):return {'type':'damage_taken','multiplier':n}
def perk(id,name,cost,desc,icon,fx,conflicts=()):put('perks',id,{'name':name,'description':desc,'cost':cost,'icon':'minecraft:'+icon,'requires_professions':[],'requires_perks':[],'conflicts':['survivorcreator:'+c for c in conflicts],'effects':fx})
perk('marksman','Tirador entrenado',5,'Puntería +2 y recarga +1 al empezar. Reduce la dispersión y el tiempo de recarga.','crossbow',[],['shaky_hands','bad_aim'])
perk('runner','Corredor de fondo',4,'Fitness +1 y carrera +2; consume un 10% menos de energía.','leather_boots',[exhaustion(.9)],['sedentary','easily_exhausted'])
perk('brawler','Peleador callejero',4,'Contundentes cortos +2, fuerza +1 y un pequeño aumento del empuje al golpear.','iron_shovel',[attr('attack_knockback',.1)],['poor_fighter','weak'])
perk('field_medic','Socorrista de campo',4,'Primeros auxilios +2. Empieza con papel y miel; los niveles mejoran tratamiento y curación.','paper',[item('minecraft:paper',6),item('minecraft:honey_bottle',2)])
perk('scavenger','Rebuscador',3,'Mantenimiento +1, suerte +0.25 y un bundle para organizar lo encontrado.','bundle',[attr('luck',.25),item('minecraft:bundle')])
perk('angler','Pescador aficionado',3,'Pesca +2 y una caña al empezar; menos espera y mejores posibilidades de pesca.','fishing_rod',[item('minecraft:fishing_rod')])
perk('fragile_bones','Huesos frágiles',-5,'Recibes un 12% más de daño. No puede combinarse con Resistente.','bone',[damage(1.12)],['tough'])
perk('sedentary','Sedentario',-4,'Resta un nivel a fitness y carrera iniciales; consumes un 10% más de energía. Nunca baja de nivel cero.','potato',[exhaustion(1.1)],['athletic','runner'])
perk('shaky_hands','Manos temblorosas',-4,'Resta un nivel inicial de puntería y recarga; reduce la velocidad de ataque en 0.15.','string',[attr('attack_speed',-.15)],['good_aim','marksman'])
perk('easily_exhausted','Se agota fácilmente',-3,'Consume un 18% más de energía durante el esfuerzo.','rotten_flesh',[exhaustion(1.18)],['runner'])
perk('slow_learner','Aprendiz lento',-4,'Obtiene un 20% menos de XP de habilidades.','book',[],['fast_learner'])
perk('poor_fighter','Inexperto en peleas',-3,'Resta un nivel inicial de fuerza y contundentes cortos; daño cuerpo a cuerpo -0.5.','wooden_sword',[attr('attack_damage',-.5)],['strong','brawler'])
def prof(id,name,cost,desc,icon,perks,fx):put('professions',id,{'name':name,'description':desc,'cost':cost,'icon':'minecraft:'+icon,'bonuses':[],'perks':['survivorcreator:'+p for p in perks],'incompatible_perks':[],'effects':fx})
prof('paramedic','Paramédico',3,'Auxilio bajo presión: primeros auxilios +2 y fitness +1, además del rasgo de primeros auxilios.','honey_bottle',['first_aid'],[item('minecraft:honey_bottle',4),item('minecraft:paper',8)])
prof('hunter','Cazador',4,'Puntería +2, recarga +1 y pesca +1. Trae arco, flechas y comida para sus primeras salidas.','bow',['outdoorsman'],[item('minecraft:bow'),item('minecraft:arrow',24),item('minecraft:cooked_rabbit',3)])
prof('supply_runner','Recolector de suministros',2,'Carrera +2 y mantenimiento +1. Prioriza movilidad y carga organizada.','bundle',['organized'],[item('minecraft:stone_axe'),item('minecraft:bread',4)])
prof('delivery_worker','Repartidor',1,'Carrera +2, el rasgo Rápido, brújula y comida; poco equipo de combate.','compass',['fast'],[item('minecraft:compass'),item('minecraft:bread',3)])
prof('maintenance_worker','Técnico de mantenimiento',3,'Mantenimiento +3 y carpintería +1; herramientas sencillas y materiales para un refugio.','stone_pickaxe',['handy'],[item('minecraft:stone_axe'),item('minecraft:oak_planks',12),item('minecraft:coal',4)])
prof('fisherman','Pescador profesional',2,'Pesca +3 y cocina +1. Caña, pescado y un cuchillo improvisado.','fishing_rod',[],[item('minecraft:fishing_rod'),item('minecraft:cooked_cod',5),item('minecraft:stone_sword')])
prof('butcher','Carnicero',2,'Hojas cortas +2 y cocina +2. Herramienta de corte y comida, sin entrenamiento de tiro.','iron_sword',[],[item('minecraft:iron_sword'),item('minecraft:cooked_beef',4)])
prof('scrap_worker','Chatarrero',2,'Metalurgia +2 y mantenimiento +2. Recupera y trabaja metal con equipo básico.','iron_ingot',['handy'],[item('minecraft:iron_ingot',5),item('minecraft:coal',5)])
# All optional start_items are ignored by the original effect when their item is absent.
extras={
 'burglar':[item('okadditions:crowbar')], 'carpenter':[item('okadditions:tape_measure')],
 'construction_worker':[item('okadditions:tape_measure'),item('okadditions:iron_rod',3)],
 'mechanic':[item('okadditions:tool_lubricant',2)],'lumberjack':[item('okadditions:tomahawk_stone')],
 'park_ranger':[item('okadditions:binoculars')],'rancher':[item('okadditions:lasso')],
 'fire_officer':[item('okadditions:ice_pack',2)],'security_guard':[item('okadditions:lightweight_shield')],
 'hunter':[item('okadditions:binoculars'),item('okadditions:bola_stone',2)],
 'paramedic':[item('okadditions:smelling_salts',2)],'delivery_worker':[item('okadditions:energy_drink',2)],
 'maintenance_worker':[item('okadditions:crowbar'),item('okadditions:tool_lubricant')],
 'scrap_worker':[item('okadditions:dull_pickaxe'),item('okadditions:iron_rod',4)],
 'supply_runner':[item('okadditions:crowbar')],
}
import zipfile,sys
if len(sys.argv)>1:
 with zipfile.ZipFile(sys.argv[1]) as z:
  for id,items in extras.items():
   p=r/f'data/survivorcreator/survivor/professions/{id}.json'
   data=json.loads(p.read_text()) if p.exists() else json.loads(z.read(f'data/survivorcreator/survivor/professions/{id}.json'))
   data['effects']+=items;put('professions',id,data)
prof('scout','Explorador',4,'Puntería +1 y fitness +1. Con OK Additions trae prismáticos, marcador y un tomahawk de piedra.','spyglass',['outdoorsman'],[item('minecraft:spyglass'),item('minecraft:bread',3),item('okadditions:binoculars'),item('okadditions:spotter'),item('okadditions:tomahawk_stone')])
prof('musician','Músico',0,'No es combatiente: algo de comida e instrumentos de OK Additions para tocar durante los descansos.','note_block',[],[item('minecraft:bread',3),item('okadditions:inst_guitar_acoustic'),item('okadditions:inst_flute')])
perk('resourceful','Manitas de emergencia',3,'Mantenimiento +1 y, con OK Additions, una palanca y lubricante para herramientas.','stone_pickaxe',[item('okadditions:crowbar'),item('okadditions:tool_lubricant')])
perk('ready_for_trouble','Preparado para problemas',3,'Con OK Additions, un escudo ligero y dos bolas de piedra; trae también tres panes.','shield',[item('okadditions:lightweight_shield'),item('okadditions:bola_stone',2),item('minecraft:bread',3)])
