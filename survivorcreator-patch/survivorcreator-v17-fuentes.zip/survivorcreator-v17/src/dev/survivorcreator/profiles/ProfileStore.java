package dev.survivorcreator.profiles;
import java.nio.file.*;
import java.io.*;
import java.util.*;
public final class ProfileStore {
 public record Profile(String name,String profession,List<String> perks) {public Profile {perks=List.copyOf(perks);}}
 public static List<Profile> read(Path path)throws IOException {
  if(!Files.exists(path))return new ArrayList<>();
  Properties p=new Properties();try(var in=Files.newInputStream(path)){p.loadFromXML(in);}
  List<Profile> list=new ArrayList<>();
  int count=Integer.parseInt(p.getProperty("count","0"));if(count<0||count>10000)throw new IOException("Archivo de perfiles inválido");
  for(int i=0;i<count;i++){String k="profile."+i+".";String ids=p.getProperty(k+"perks","");list.add(new Profile(p.getProperty(k+"name","Perfil"),p.getProperty(k+"profession",""),ids.isBlank()?List.of():List.of(ids.split(","))));}
  return list;
 }
 public static void save(Path path,String name,String profession,List<String> perks)throws IOException {
  name=name.strip();if(name.isEmpty()||name.length()>64)throw new IllegalArgumentException("Nombre: entre 1 y 64 caracteres");
  List<Profile> list=read(path);String n=name;list.removeIf(p->p.name().equals(n));list.add(new Profile(name,profession,perks));write(path,list);
 }
 public static void delete(Path path,String name)throws IOException {List<Profile> list=read(path);list.removeIf(p->p.name().equals(name));write(path,list);}
 private static void write(Path path,List<Profile> list)throws IOException {
  Files.createDirectories(path.toAbsolutePath().getParent());Properties p=new Properties();p.setProperty("count",""+list.size());
  for(int i=0;i<list.size();i++){Profile f=list.get(i);String k="profile."+i+".";p.setProperty(k+"name",f.name());p.setProperty(k+"profession",f.profession());p.setProperty(k+"perks",String.join(",",f.perks()));}
  Path temp=Files.createTempFile(path.toAbsolutePath().getParent(),"survivor-profiles-",".tmp");
  try {try(var out=Files.newOutputStream(temp)){p.storeToXML(out,"Survivor Creator: profesiones y rasgos, no progreso del personaje","UTF-8");}
   try{Files.move(temp,path,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(temp,path,StandardCopyOption.REPLACE_EXISTING);}
  }finally{Files.deleteIfExists(temp);}
 }
}
