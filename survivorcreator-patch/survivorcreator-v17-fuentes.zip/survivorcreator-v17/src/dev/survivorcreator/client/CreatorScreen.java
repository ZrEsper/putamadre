package dev.survivorcreator.client;

import dev.survivorcreator.Config;
import dev.survivorcreator.client.ClientHooks;
import dev.survivorcreator.client.DeathAudio;
import dev.survivorcreator.data.CharacterData;
import dev.survivorcreator.data.ClientState;
import dev.survivorcreator.data.DataRegistry;
import dev.survivorcreator.data.Perk;
import dev.survivorcreator.data.Profession;
import dev.survivorcreator.data.Validator;
import dev.survivorcreator.effects.EffectTypes;
import dev.survivorcreator.net.Net;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.neoforged.neoforge.network.PacketDistributor;

public class CreatorScreen
extends Screen {
    private static final int ROW = 20;
    private static final int HEAD = 18;
    private static final int GAP = 8;
    private static final int C_BG = -267514869;
    private static final int C_PANEL = -434563307;
    private static final int C_BORDER = -11910084;
    private static final int C_HEAD = -14014941;
    private static final int C_TEXT = -2568000;
    private static final int C_DIM = -7699336;
    private static final int C_POS = -10695844;
    private static final int C_NEG = -2074033;
    private static final int C_ACCENT = -4045521;
    private static final int C_BTN = -13751770;
    private static final int C_BTN_HOVER = -12370891;
    private static final int C_BTN_OFF = -14935528;
    private final List<Map.Entry<ResourceLocation, Profession>> professions = DataRegistry.professionList();
    private final List<Row> rows = new ArrayList<Row>();
    private ResourceLocation profession;
    private final List<ResourceLocation> chosen = new ArrayList<ResourceLocation>();
    private int focus = 0;
    private final int[] cursor = new int[2];
    private final int[] scroll = new int[4];
    private ResourceLocation hoverPerk;
    private ResourceLocation hoverProf;
    private Component status = Component.empty();
    private int statusColor = -2568000;
    private long statusUntil = 0L;
    private boolean sending = false;
    private List<Component> hoverBoost=List.of();
    private int renderMouseX;
    private int renderMouseY;
    private int margin;
    private int top;
    private int bottom;
    private Box boxProf;
    private Box boxPerks;
    private Box boxCard;
    private Box boxChosen;
    private Box btnProfiles;
    private Box btnBack;
    private Box btnReset;
    private Box btnRandom;
    private Box btnConfirm;

    public CreatorScreen() {
        super((Component)Component.translatable((String)"screen.survivorcreator.title"));
        ArrayList<Map.Entry<ResourceLocation, Perk>> pos = new ArrayList<>();
        ArrayList<Map.Entry<ResourceLocation, Perk>> neg = new ArrayList<Map.Entry<ResourceLocation, Perk>>();
        for (Map.Entry<ResourceLocation, Perk> e2 : DataRegistry.perkList()) {
            (e2.getValue().negative() ? neg : pos).add(e2);
        }
        this.rows.add(new Row((Component)Component.translatable((String)"screen.survivorcreator.advantages"), null, null));
        pos.forEach(e -> this.rows.add(new Row(null, (ResourceLocation)e.getKey(), (Perk)e.getValue())));
        this.rows.add(new Row((Component)Component.translatable((String)"screen.survivorcreator.disadvantages"), null, null));
        neg.forEach(e -> this.rows.add(new Row(null, (ResourceLocation)e.getKey(), (Perk)e.getValue())));
        CharacterData cd = ClientState.character;
        if (cd.completed()) {
            this.profession = cd.profession().orElse(null);
            this.chosen.addAll(cd.perks());
        }
        this.cursor[1] = 1;
    }

    protected void init() {
        this.layout();
    }

    public boolean shouldCloseOnEsc() {
        return ClientState.character.completed();
    }

    public boolean isPauseScreen() {
        return false;
    }

    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
    }

    private void layout() {
        this.margin = Math.max(10, this.width / 40);
        this.top = 44;
        this.bottom = this.height - 84;
        int cw = this.width - this.margin * 2;
        int ch = Math.max(60, this.bottom - this.top);
        int aw = cw * 27 / 100;
        int bw = cw * 38 / 100;
        this.boxProf = new Box(this.margin, this.top, aw, ch);
        this.boxPerks = new Box(this.margin + aw + 8, this.top, bw, ch);
        int cx = this.boxPerks.x() + bw + 8;
        int cwid = this.width - this.margin - cx;
        int half = ch * 55 / 100;
        this.boxCard = new Box(cx, this.top, cwid, half);
        this.boxChosen = new Box(cx, this.top + half + 8, cwid, ch - half - 8);
        int bwid = Mth.clamp((int)((cw - 24) / 4), (int)80, (int)170);
        this.btnProfiles = new Box(this.margin,this.height-57,Math.min(230,cw),22);
        int by = this.height - 30;
        this.btnBack = new Box(this.margin, by, bwid, 22);
        this.btnConfirm = new Box(this.width - this.margin - bwid, by, bwid, 22);
        this.btnRandom = new Box(this.btnConfirm.x() - 8 - bwid, by, bwid, 22);
        this.btnReset = new Box(this.btnRandom.x() - 8 - bwid, by, bwid, 22);
    }

    private Optional<ResourceLocation> opt() {
        return Optional.ofNullable(this.profession);
    }

    private boolean professionOk() {
        return this.profession != null || (Boolean)Config.PROFESSION_REQUIRED.get() == false || this.professions.isEmpty();
    }

    private int points() {
        return Validator.points(this.opt(), this.chosen);
    }

    private Component idName(String s) {
        ResourceLocation id = ResourceLocation.tryParse((String)s);
        if (id != null) {
            Perk p = DataRegistry.perk(id);
            if (p != null) {
                return p.name();
            }
            Profession pr = DataRegistry.profession(id);
            if (pr != null) {
                return pr.name();
            }
        }
        return Component.literal((String)s);
    }

    private Component errorText(String key, String arg) {
        if ("survivorcreator.created".equals(key)) {
            return Component.translatable((String)key);
        }
        if (arg.contains("|")) {
            String[] parts = arg.split("\\|");
            return Component.translatable((String)key, (Object[])new Object[]{this.idName(parts[0]), this.idName(parts[1])});
        }
        return Component.translatable((String)key, (Object[])new Object[]{this.idName(arg)});
    }

    private void setStatus(Component c, int color) {
        this.status = c;
        this.statusColor = color;
        this.statusUntil = Util.getMillis() + 4500L;
    }

    private void selectProfession(ResourceLocation id) {
        boolean changed;
        this.profession = id.equals((Object)this.profession) && (Boolean)Config.PROFESSION_REQUIRED.get() == false ? null : id;
        ArrayList<ResourceLocation> original = new ArrayList<ResourceLocation>(this.chosen);
        this.chosen.clear();
        do {
            changed = false;
            for (ResourceLocation pid : original) {
                if (this.chosen.contains(pid)) continue;
                ArrayList<ResourceLocation> test = new ArrayList<ResourceLocation>(this.chosen);
                test.add(pid);
                if (!Validator.validate(this.opt(), test, false).ok()) continue;
                this.chosen.add(pid);
                changed = true;
            }
        } while (changed && this.chosen.size() < original.size());
    }

    private void togglePerk(ResourceLocation id, boolean addExtra) {
        block5: {
            block6: {
                if (!this.chosen.contains(id)) break block5;
                if (!addExtra) break block6;
                if (((Boolean)Config.ALLOW_DUPLICATES.get()).booleanValue()) break block5;
            }
            this.chosen.removeIf(arg_0 -> ((ResourceLocation)id).equals(arg_0));
            return;
        }
        ArrayList<ResourceLocation> test = new ArrayList<ResourceLocation>(this.chosen);
        test.add(id);
        Validator.Result r = Validator.validate(this.opt(), test, false);
        if (!r.ok()) {
            this.setStatus(this.errorText(r.key(), r.arg()), -2074033);
            return;
        }
        Perk p = DataRegistry.perk(id);
        if (p != null && p.cost() > 0 && Validator.points(this.opt(), test) < 0) {
            this.setStatus((Component)Component.translatable((String)"survivorcreator.error.not_enough_points"), -2074033);
            return;
        }
        this.chosen.add(id);
    }

    private Component blockReason(ResourceLocation id) {
        ArrayList<ResourceLocation> test = new ArrayList<ResourceLocation>(this.chosen);
        test.add(id);
        Validator.Result r = Validator.validate(this.opt(), test, false);
        if (!r.ok()) {
            return this.errorText(r.key(), r.arg());
        }
        Perk p = DataRegistry.perk(id);
        if (p != null && p.cost() > 0 && Validator.points(this.opt(), test) < 0) {
            return Component.translatable((String)"survivorcreator.error.not_enough_points");
        }
        return null;
    }

    private void randomize() {
        Random rnd = new Random();
        this.profession = this.professions.isEmpty() ? null : this.professions.get(rnd.nextInt(this.professions.size())).getKey();
        this.chosen.clear();
        ArrayList<Row> all = new ArrayList<Row>(this.rows.stream().filter(r -> r.id() != null).toList());
        Collections.shuffle(all, rnd);
        int target = 2 + rnd.nextInt(5);
        for (Row r2 : all) {
            if (this.chosen.size() >= target) break;
            ArrayList<ResourceLocation> test = new ArrayList<ResourceLocation>(this.chosen);
            test.add(r2.id());
            if (!Validator.validate(this.opt(), test, false).ok() || Validator.points(this.opt(), test) < 0) continue;
            this.chosen.add(r2.id());
        }
    }

    private void resetAll() {
        this.profession = null;
        this.chosen.clear();
        Arrays.fill(this.scroll, 0);
    }

    private boolean canConfirm() {
        return !this.sending && Validator.validate(this.opt(), this.chosen, true).ok();
    }

    private void confirm() {
        if (this.sending) {
            return;
        }
        Validator.Result r = Validator.validate(this.opt(), this.chosen, true);
        if (!r.ok()) {
            this.setStatus(this.errorText(r.key(), r.arg()), -2074033);
            return;
        }
        try {saveProfile("Último personaje");}catch(java.io.IOException e){this.setStatus(Component.literal("No se pudo guardar el último perfil: "+e.getMessage()),-2074033);}
        this.sending = true;
        this.setStatus((Component)Component.translatable((String)"screen.survivorcreator.sending"), -2568000);
        PacketDistributor.sendToServer((CustomPacketPayload)new Net.Confirm(this.opt(), List.copyOf(this.chosen)), (CustomPacketPayload[])new CustomPacketPayload[0]);
    }

    public void onResult(Net.Result p) {
        this.sending = false;
        if (!p.ok()) {
            this.setStatus(this.errorText(p.key(), p.arg()), -2074033);
        }
    }

    public void onClose() {
        ClientHooks.endCreationAudio();
        super.onClose();
    }

    private void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(this.font, s, x, y, color, false);
    }

    private void text(GuiGraphics g, Component c, int x, int y, int color) {
        g.drawString(this.font, c, x, y, color, false);
    }

    private int wrap(GuiGraphics g, Component c, int x, int y, int w, int color) {
        for (FormattedCharSequence line : this.font.split((FormattedText)c, Math.max(20, w))) {
            g.drawString(this.font, line, x, y, color, false);
            y += 10;
        }
        return y;
    }

    private String fit(String s, int w) {
        return this.font.plainSubstrByWidth(s, Math.max(0, w));
    }

    private void outline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    private void panel(GuiGraphics g, Box b, Component title) {
        g.fill(b.x(), b.y(), b.x() + b.w(), b.y() + b.h(), -11910084);
        g.fill(b.x() + 1, b.y() + 1, b.x() + b.w() - 1, b.y() + b.h() - 1, -434563307);
        g.fill(b.x() + 1, b.y() + 1, b.x() + b.w() - 1, b.y() + 18, -14014941);
        this.text(g, title, b.x() + 6, b.y() + 5, -2568000);
    }

    private void icon(GuiGraphics g, ResourceLocation id, int x, int y) {
        Item it = (Item)BuiltInRegistries.ITEM.get(id);
        if (it == Items.AIR) {
            g.fill(x, y, x + 16, y + 16, -12303292);
            return;
        }
        g.renderItem(new ItemStack((ItemLike)it), x, y);
    }

    private void scrollbar(GuiGraphics g, Box b, int listTop, int listH, int max, int pos) {
        if (max <= 0) {
            return;
        }
        int th = Math.max(12, listH * listH / (listH + max));
        int ty = listTop + (listH - th) * pos / max;
        g.fill(b.x() + b.w() - 5, listTop, b.x() + b.w() - 2, listTop + listH, -16119544);
        g.fill(b.x() + b.w() - 5, ty, b.x() + b.w() - 2, ty + th, -7699336);
    }

    private String costText(int c) {
        return c > 0 ? "-" + c : (c < 0 ? "+" + -c : "0");
    }

    public void render(GuiGraphics g, int mx, int my, float pt) {
        this.layout();
        this.renderMouseX = mx;
        this.renderMouseY = my;
        this.hoverBoost=List.of();
        this.hoverPerk = null;
        this.hoverProf = null;
        g.fill(0, 0, this.width, this.height, -267514869);
        g.fillGradient(0, 0, this.width, 40, Integer.MIN_VALUE, 0);
        this.drawHeader(g);
        this.drawProfessions(g, mx, my);
        this.drawPerks(g, mx, my);
        this.drawCard(g);
        this.drawChosen(g, mx, my);
        this.drawFooter(g, mx, my);
        if (Util.getMillis() < this.statusUntil) {
            this.text(g, this.status, (this.width - this.font.width((FormattedText)this.status)) / 2, this.height - 73, this.statusColor);
        }
        this.drawDetailsTooltip(g);
        DeathAudio.fadeIn(g, this.width, this.height);
    }

    private void drawHeader(GuiGraphics g) {
        g.pose().pushPose();
        g.pose().scale(1.5f, 1.5f, 1.0f);
        this.text(g, (Component)Component.translatable((String)"screen.survivorcreator.title"), (int)((float)this.margin / 1.5f), 5, -2568000);
        g.pose().popPose();
        this.text(g, (Component)Component.translatable((String)"screen.survivorcreator.subtitle"), this.margin, 27, -7699336);
        int pts = this.points();
        MutableComponent p = Component.translatable((String)"screen.survivorcreator.points", (Object[])new Object[]{pts});
        int color = pts < 0 ? -2074033 : (pts == 0 ? -7699336 : -10695844);
        g.pose().pushPose();
        g.pose().scale(1.4f, 1.4f, 1.0f);
        int pw = (int)((float)this.font.width((FormattedText)p) * 1.4f);
        this.text(g, (Component)p, (int)((float)(this.width - this.margin - pw) / 1.4f), 7, color);
        g.pose().popPose();
    }

    private void drawButton(GuiGraphics g, Box b, Component label, boolean enabled, boolean accent, int mx, int my) {
        boolean hov;
        boolean bl = hov = enabled && b.in(mx, my);
        int bg = !enabled ? -14935528 : (accent ? (hov ? -2533569 : -4045521) : (hov ? -12370891 : -13751770));
        g.fill(b.x(), b.y(), b.x() + b.w(), b.y() + b.h(), bg);
        this.outline(g, b.x(), b.y(), b.w(), b.h(), -11910084);
        this.text(g, label, b.x() + (b.w() - this.font.width((FormattedText)label)) / 2, b.y() + 7, enabled ? -1 : -10857138);
    }

    private void drawFooter(GuiGraphics g, int mx, int my) {
        this.drawButton(g,btnProfiles,Component.translatable("screen.survivorcreator.profiles"),!sending,false,mx,my);
        boolean backOn = this.shouldCloseOnEsc();
        MutableComponent back = Component.translatable((String)(this.shouldCloseOnEsc() ? "screen.survivorcreator.btn.cancel" : "screen.survivorcreator.btn.back"));
        this.drawButton(g, this.btnBack, (Component)back, backOn, false, mx, my);
        this.drawButton(g, this.btnReset, (Component)Component.translatable((String)"screen.survivorcreator.btn.reset"), !this.sending, false, mx, my);
        this.drawButton(g, this.btnRandom, (Component)Component.translatable((String)"screen.survivorcreator.btn.random"), !this.sending, false, mx, my);
        this.drawButton(g, this.btnConfirm, (Component)Component.translatable((String)"screen.survivorcreator.btn.confirm"), !this.sending, true, mx, my);
    }

    private void drawProfessions(GuiGraphics g, int mx, int my) {
        Box b = this.boxProf;
        this.panel(g, b, (Component)Component.translatable((String)"screen.survivorcreator.profession"));
        int ly = b.y() + 18;
        int lh = b.h() - 18 - 1;
        int max = Math.max(0, this.professions.size() * 20 - lh);
        this.scroll[0] = Mth.clamp((int)this.scroll[0], (int)0, (int)max);
        g.enableScissor(b.x() + 1, ly, b.x() + b.w() - 1, ly + lh);
        for (int i = 0; i < this.professions.size(); ++i) {
            boolean hov;
            int ry = ly + i * 20 - this.scroll[0];
            if (ry + 20 < ly || ry > ly + lh) continue;
            ResourceLocation id = this.professions.get(i).getKey();
            Profession p = this.professions.get(i).getValue();
            boolean sel = id.equals((Object)this.profession);
            boolean bl = hov = b.in(mx, my) && my >= ly && my >= ry && my < ry + 20;
            if (hov) {
                this.hoverProf = id;
            }
            if (sel) {
                g.fill(b.x() + 2, ry, b.x() + b.w() - 6, ry + 20 - 1, 1438795055);
            } else if (hov) {
                g.fill(b.x() + 2, ry, b.x() + b.w() - 6, ry + 20 - 1, 0x30FFFFFF);
            }
            if (this.focus == 0 && this.cursor[0] == i) {
                this.outline(g, b.x() + 2, ry, b.w() - 8, 19, -2568000);
            }
            this.icon(g, p.icon(), b.x() + 5, ry + 2);
            int c = p.cost();
            String cs = c == 0 ? "" : this.costText(c);
            int csw = this.font.width(cs);
            this.text(g, this.fit(p.name().getString(), b.w() - 26 - 12 - csw - 6), b.x() + 26, ry + 6, sel ? -1 : -2568000);
            if (c == 0) continue;
            this.text(g, cs, b.x() + b.w() - 12 - csw, ry + 6, c > 0 ? -2074033 : -10695844);
        }
        g.disableScissor();
        this.scrollbar(g, b, ly, lh, max, this.scroll[0]);
    }

    private void drawPerks(GuiGraphics g, int mx, int my) {
        Box b = this.boxPerks;
        this.panel(g, b, (Component)Component.translatable((String)"screen.survivorcreator.traits"));
        int ly = b.y() + 18;
        int lh = b.h() - 18 - 1;
        int max = Math.max(0, this.rows.size() * 20 - lh);
        this.scroll[1] = Mth.clamp((int)this.scroll[1], (int)0, (int)max);
        g.enableScissor(b.x() + 1, ly, b.x() + b.w() - 1, ly + lh);
        for (int i = 0; i < this.rows.size(); ++i) {
            boolean hov;
            int ry = ly + i * 20 - this.scroll[1];
            if (ry + 20 < ly || ry > ly + lh) continue;
            Row row = this.rows.get(i);
            if (row.header() != null) {
                this.text(g, (Component)row.header().copy().withStyle(ChatFormatting.BOLD), b.x() + 8, ry + 6, -4045521);
                g.fill(b.x() + 6, ry + 20 - 3, b.x() + b.w() - 8, ry + 20 - 2, -11910084);
                continue;
            }
            Perk p = row.perk();
            boolean neg = p.negative();
            boolean sel = this.chosen.contains(row.id());
            Component reason = sel ? null : this.blockReason(row.id());
            boolean bl = hov = b.in(mx, my) && my >= ly && my >= ry && my < ry + 20;
            if (hov) {
                this.hoverPerk = row.id();
            }
            if (sel) {
                g.fill(b.x() + 2, ry, b.x() + b.w() - 6, ry + 20 - 1, neg ? 1172331087 : 1163709276);
            } else if (hov) {
                g.fill(b.x() + 2, ry, b.x() + b.w() - 6, ry + 20 - 1, 0x30FFFFFF);
            }
            if (this.focus == 1 && this.cursor[1] == i) {
                this.outline(g, b.x() + 2, ry, b.w() - 8, 19, -2568000);
            }
            this.icon(g, p.icon(), b.x() + 5, ry + 2);
            String cs = this.costText(p.cost());
            int csw = this.font.width(cs);
            int color = reason != null ? -7699336 : (neg ? -2074033 : -10695844);
            long count = this.chosen.stream().filter(arg_0 -> ((ResourceLocation)row.id()).equals(arg_0)).count();
            String name = (sel ? "\u2714 " : "") + p.name().getString() + (String)(count > 1L ? " x" + count : "");
            this.text(g, this.fit(name, b.w() - 26 - 12 - csw - 6), b.x() + 26, ry + 6, color);
            this.text(g, cs, b.x() + b.w() - 12 - csw, ry + 6, color);
        }
        g.disableScissor();
        this.scrollbar(g, b, ly, lh, max, this.scroll[1]);
    }

    private List<Perk> selectedPerks() {
        return this.chosenRows().stream().map(r -> DataRegistry.perk(r.id())).filter(Objects::nonNull).toList();
    }

    private void drawCard(GuiGraphics g) {
        Box b=this.boxCard;
        this.panel(g,b,Component.translatable("screen.survivorcreator.loadout"));
        int ly=b.y()+20, lh=b.h()-22, x=b.x()+7, w=b.w()-16;
        List<Perk> perks=selectedPerks();
        Profession prof=profession==null?null:DataRegistry.profession(profession);
        int content=26 + perks.size()*16 + EffectTypes.previewStartItems(prof,perks).size()*21 + 32;
        scroll[3]=Mth.clamp(scroll[3],0,Math.max(0,content-lh));
        int y=ly+4-scroll[3];
        g.enableScissor(b.x()+1,ly,b.x()+b.w()-1,ly+lh);
        if(prof!=null) { this.text(g,this.fit(prof.name().getString(),w),x,y,-4045521); y+=20; }
        for(ChosenRow row:chosenRows()) {
            Perk perk=DataRegistry.perk(row.id()); if(perk==null)continue;
            String suffix=row.granted()?" *":"";
            this.text(g,this.fit(perk.name().getString()+suffix,w-16),x+16,y,perk.negative()?-2074033:-10695844);
            if(!row.granted())this.text(g,"×",x,y,-7699336);
            y+=16;
        }
        y+=8;this.text(g,Component.translatable("screen.survivorcreator.starting_equipment"),x,y,-4045521);y+=16;
        List<ItemStack> equipment=EffectTypes.previewStartItems(prof,perks);
        if(equipment.isEmpty()) {this.text(g,Component.translatable("screen.survivorcreator.no_starting_equipment"),x,y,-7699336);y+=16;}
        for(ItemStack stack:equipment) {
            g.renderItem(stack,x,y-3);
            this.text(g,this.fit(stack.getHoverName().getString()+" x"+stack.getCount(),w-21),x+21,y+1,-2568000);y+=21;
        }
        g.disableScissor();this.scrollbar(g,b,ly,lh,Math.max(0,content-lh),scroll[3]);

    }
    private void drawDetailsTooltip(GuiGraphics g) {
        List<Component> lines=new ArrayList<>();
        if(hoverPerk!=null) {
            Perk p=DataRegistry.perk(hoverPerk);if(p!=null){lines.add(p.name());lines.add(p.description());Component reason=blockReason(hoverPerk);if(reason!=null&&!chosen.contains(hoverPerk))lines.add(reason);}
        }else if(hoverProf!=null) {
            Profession p=DataRegistry.profession(hoverProf);if(p!=null){lines.add(p.name());lines.add(p.description());}
        }
        if(!hoverBoost.isEmpty())lines=hoverBoost;
        if(!lines.isEmpty())g.renderComponentTooltip(this.font,lines,renderMouseX,renderMouseY);
    }

    private int rowAt(Box b, int scrollId, int size, double mx, double my, int bottomPad) {
        int ly = b.y() + 18;
        if (!b.in(mx, my) || my < (double)ly || my >= (double)(b.y() + b.h() - bottomPad)) {
            return -1;
        }
        int idx = (int)((my - (double)ly + (double)this.scroll[scrollId]) / 20.0);
        return idx >= 0 && idx < size ? idx : -1;
    }

    private Component names(List<ResourceLocation> ids) {
        MutableComponent out = Component.empty();
        for (int i = 0; i < ids.size(); ++i) {
            if (i > 0) {
                out.append(", ");
            }
            out.append(this.idName(ids.get(i).toString()));
        }
        return out;
    }

    private List<ChosenRow> chosenRows() {
        Profession p;
        ArrayList<ChosenRow> out = new ArrayList<ChosenRow>();
        Profession profession = p = this.profession == null ? null : DataRegistry.profession(this.profession);
        if (p != null) {
            for (ResourceLocation gid : p.grantedPerks()) {
                out.add(new ChosenRow(gid, true));
            }
        }
        for (ResourceLocation id : this.chosen) {
            out.add(new ChosenRow(id, false));
        }
        return out;
    }

    private void drawChosen(GuiGraphics g,int mx,int my) {
        Box b=boxChosen;this.panel(g,b,Component.translatable("screen.survivorcreator.boosts"));
        List<dev.survivorcreator.creation.CreationSummary.Boost> list=dev.survivorcreator.creation.CreationSummary.boosts(opt(),chosen);
        int ly=b.y()+20,lh=b.h()-22;
        int max=Math.max(0,list.size()*28-lh);scroll[2]=Mth.clamp(scroll[2],0,max);
        g.enableScissor(b.x()+1,ly,b.x()+b.w()-1,ly+lh);
        for(int i=0;i<list.size();i++) {
            var boost=list.get(i);int y=ly+4+i*28-scroll[2];int color=boost.positive()?-10695844:-2074033;
            this.text(g,this.fit(boost.name(),b.w()-(boost.level()>0?80:14)),b.x()+6,y,color);
            if(b.in(mx,my)&&my>=ly&&my<ly+lh&&my>=y&&my<y+26)hoverBoost=List.of(Component.literal(boost.name()),Component.literal(boost.detail()));
            this.text(g,this.fit(boost.detail(),b.w()-14),b.x()+6,y+11,-2568000);
            if(boost.level()>0)for(int n=0;n<10;n++)g.fill(b.x()+b.w()-65+n*5,y,b.x()+b.w()-61+n*5,y+6,n<boost.level()?color:-14935528);
        }
        g.disableScissor();this.scrollbar(g,b,ly,lh,max,scroll[2]);
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if(btnProfiles.in(mx,my)&&!sending) {this.minecraft.setScreen(new ProfileScreen(this));return DeathAudio.clickIf(true);}

        if (this.btnBack.in(mx, my) && this.shouldCloseOnEsc()) {
            this.onClose();
            return DeathAudio.clickIf(true);
        }
        if (this.btnReset.in(mx, my) && !this.sending) {
            this.resetAll();
            return DeathAudio.clickIf(true);
        }
        if (this.btnRandom.in(mx, my) && !this.sending) {
            this.randomize();
            return DeathAudio.clickIf(true);
        }
        if (this.btnConfirm.in(mx, my)) {
            this.confirm();
            return DeathAudio.clickIf(true);
        }
        if (this.sending) {
            return DeathAudio.clickIf(true);
        }
        int i = this.rowAt(this.boxProf, 0, this.professions.size(), mx, my, 1);
        if (i >= 0) {
            this.focus = 0;
            this.cursor[0] = i;
            this.selectProfession(this.professions.get(i).getKey());
            return DeathAudio.clickIf(true);
        }
        i = this.rowAt(this.boxPerks, 1, this.rows.size(), mx, my, 1);
        if (i >= 0) {
            this.focus = 1;
            this.cursor[1] = i;
            if (this.rows.get(i).id() != null) {
                this.togglePerk(this.rows.get(i).id(), button == 1);
            }
            return DeathAudio.clickIf(true);
        }
        if(boxCard.in(mx,my)) {
            int start=boxCard.y()+24-scroll[3]+(profession==null?0:20);
            int idx=(int)((my-start)/16);
            List<ChosenRow> selected=chosenRows();
            if(my>=boxCard.y()+20 && my<boxCard.y()+boxCard.h()-2 && my>=start && idx>=0 && idx<selected.size()&&!selected.get(idx).granted()) {
                chosen.remove(selected.get(idx).id());return DeathAudio.clickIf(true);
            }
        }
        return DeathAudio.clickIf(super.mouseClicked(mx, my, button));
    }

    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        int d = (int)(-sy * 20.0);
        if (this.boxProf.in(mx, my)) {
            this.scroll[0] = Math.max(0, this.scroll[0] + d);
        } else if (this.boxPerks.in(mx, my)) {
            this.scroll[1] = Math.max(0, this.scroll[1] + d);
        } else if (this.boxChosen.in(mx, my)) {
            this.scroll[2] = Math.max(0, this.scroll[2] + d);
        } else if (this.boxCard.in(mx, my)) {
            this.scroll[3] = Math.max(0, this.scroll[3] + d);
        }
        return true;
    }

    private void moveCursor(int dir) {
        int size;
        int n = size = this.focus == 0 ? this.professions.size() : this.rows.size();
        if (size == 0) {
            return;
        }
        int c = Mth.clamp((int)(this.cursor[this.focus] + dir), (int)0, (int)(size - 1));
        if (this.focus == 1 && this.rows.get(c).id() == null) {
            c = Mth.clamp((int)(c + dir), (int)0, (int)(size - 1));
        }
        if (this.focus == 1 && this.rows.get(c).id() == null) {
            return;
        }
        this.cursor[this.focus] = c;
        Box b = this.focus == 0 ? this.boxProf : this.boxPerks;
        int lh = b.h() - 18 - 1;
        int rowTop = c * 20;
        if (rowTop < this.scroll[this.focus]) {
            this.scroll[this.focus] = rowTop;
        } else if (rowTop + 20 > this.scroll[this.focus] + lh) {
            this.scroll[this.focus] = rowTop + 20 - lh;
        }
        this.scroll[3] = 0;
    }

    private void activate() {
        if (this.focus == 0) {
            if (!this.professions.isEmpty()) {
                this.selectProfession(this.professions.get(Mth.clamp((int)this.cursor[0], (int)0, (int)(this.professions.size() - 1))).getKey());
            }
        } else if (this.cursor[1] < this.rows.size() && this.rows.get(this.cursor[1]).id() != null) {
            this.togglePerk(this.rows.get(this.cursor[1]).id(), false);
        }
    }

    public boolean keyPressed(int key, int scan, int mods) {
        if (this.sending) {
            return super.keyPressed(key, scan, mods);
        }
        switch (key) {
            case 265: {
                this.moveCursor(-1);
                return true;
            }
            case 264: {
                this.moveCursor(1);
                return true;
            }
            case 263: {
                this.focus = 0;
                return true;
            }
            case 258: 
            case 262: {
                this.focus = this.focus == 0 ? 1 : 0;
                return true;
            }
            case 32: 
            case 257: 
            case 335: {
                this.activate();
                return true;
            }
            case 67: {
                this.confirm();
                return true;
            }
        }
        return super.keyPressed(key, scan, mods);
    }

    public void saveProfile(String name)throws java.io.IOException {
        dev.survivorcreator.profiles.ProfileStore.save(this.minecraft.gameDirectory.toPath().resolve("config/survivorcreator-profiles.xml"),name,profession==null?"":profession.toString(),chosen.stream().map(Object::toString).toList());
    }
    public void loadProfile(dev.survivorcreator.profiles.ProfileStore.Profile saved) {
        ResourceLocation p=saved.profession().isEmpty()?null:ResourceLocation.tryParse(saved.profession());
        if(!saved.profession().isEmpty()&&(p==null||DataRegistry.profession(p)==null))throw new IllegalArgumentException("La profesión guardada ya no existe");
        List<ResourceLocation> perks=new ArrayList<>();
        for(String id:saved.perks()){ResourceLocation r=ResourceLocation.tryParse(id);if(r==null||DataRegistry.perk(r)==null)throw new IllegalArgumentException("Rasgo no disponible: "+id);perks.add(r);}
        Validator.Result result=Validator.validate(Optional.ofNullable(p),perks,false);
        if(!result.ok())throw new IllegalArgumentException(errorText(result.key(),result.arg()).getString());
        profession=p;chosen.clear();chosen.addAll(perks);Arrays.fill(scroll,0);sending=false;
    }

    private record Row(Component header, ResourceLocation id, Perk perk) {
    }

    private record Box(int x, int y, int w, int h) {
        boolean in(double mx, double my) {
            return mx >= (double)this.x && mx < (double)(this.x + this.w) && my >= (double)this.y && my < (double)(this.y + this.h);
        }
    }

    private record ChosenRow(ResourceLocation id, boolean granted) {
    }
}

