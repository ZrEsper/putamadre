package dev.survivorcreator.client;
import dev.survivorcreator.profiles.ProfileStore;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import java.nio.file.Path;
import java.util.*;
public final class ProfileScreen extends Screen {
 private final CreatorScreen parent;
 private List<ProfileStore.Profile> profiles=List.of();
 private String name="",status="";private int scroll;private boolean typing=true;
 public ProfileScreen(CreatorScreen parent){super(Component.translatable("screen.survivorcreator.profiles"));this.parent=parent;}
 private Path path(){return minecraft.gameDirectory.toPath().resolve("config/survivorcreator-profiles.xml");}
 protected void init(){refresh();}
 private void refresh(){try{profiles=ProfileStore.read(path());}catch(Exception e){status="Error de lectura: "+e.getMessage();}}
 public boolean isPauseScreen(){return false;}
 public void onClose(){minecraft.setScreen(parent);}
 private void text(GuiGraphics g,String s,int x,int y,int color){g.drawString(font,s,x,y,color,false);}
 public void renderBackground(GuiGraphics g,int x,int y,float p){}
 public void render(GuiGraphics g,int mx,int my,float pt){
  g.fill(0,0,width,height,0xee101512);text(g,title.getString(),20,16,0xffe2d9bb);
  text(g,Component.translatable("screen.survivorcreator.profile_help").getString(),20,31,0xffaaaaaa);
  int listBottom=height-103;scroll=Math.max(0,Math.min(scroll,Math.max(0,profiles.size()*22-(listBottom-50))));
  g.enableScissor(20,48,width-20,listBottom);
  for(int i=0;i<profiles.size();i++){int y=50+i*22-scroll;var p=profiles.get(i);g.fill(20,y,width-20,y+20,p.name().equals(name)?0xff384e36:0xff202923);text(g,font.plainSubstrByWidth(p.name(),width-52),26,y+6,0xffdddfcb);}
  g.disableScissor();
  text(g,Component.translatable("screen.survivorcreator.profile_name").getString(),20,height-91,0xffdddddd);
  g.fill(20,height-77,width-20,height-55,typing?0xff3a4e3a:0xff202923);text(g,font.plainSubstrByWidth(name+(typing?"_":""),width-52),26,height-70,0xffffffff);
  String[] keys={"save","load","delete","back"};int bw=(width-46)/4;
  for(int i=0;i<4;i++){int x=20+i*(bw+2);g.fill(x,height-48,x+bw,height-26,0xff354335);String label=Component.translatable("screen.survivorcreator.profile_"+keys[i]).getString();text(g,label,x+4,height-41,0xffffffff);}
  text(g,font.plainSubstrByWidth(status,width-40),20,height-17,0xffffcc88);
 }
 public boolean mouseClicked(double x,double y,int button){
  if(y>=48&&y<height-103&&x>=20&&x<width-20){int idx=(int)((y-50+scroll)/22);if(idx>=0&&idx<profiles.size()){name=profiles.get(idx).name();typing=false;}return true;}
  if(y>=height-77&&y<height-55){typing=true;return true;}
  if(y>=height-48&&y<height-26){int bw=(width-46)/4;int i=(int)((x-20)/(bw+2));if(x<20||i<0||i>3)return false;
   try{switch(i){case 0-> {parent.saveProfile(name);refresh();status="Perfil guardado";}case 1->{var saved=profiles.stream().filter(p->p.name().equals(name)).findFirst().orElseThrow(()->new IllegalArgumentException("Elige un perfil guardado"));parent.loadProfile(saved);onClose();}case 2->{ProfileStore.delete(path(),name);refresh();status="Perfil eliminado";}case 3->onClose();}}catch(Exception e){status=e.getMessage();}return true;}
  return super.mouseClicked(x,y,button);
 }
 public boolean mouseScrolled(double x,double y,double sx,double sy){scroll+= (int)(-sy*22);return true;}
 public boolean charTyped(char c,int mods){if(typing&&!Character.isISOControl(c)&&name.length()<64){name+=c;return true;}return super.charTyped(c,mods);}
 public boolean keyPressed(int key,int scan,int mods){if(key==256){onClose();return true;}if(typing&&key==259&&!name.isEmpty()){name=name.substring(0,name.offsetByCodePoints(name.length(),-1));return true;}return super.keyPressed(key,scan,mods);}
}
