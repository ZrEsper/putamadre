package dev.survivorcreator.data;

import dev.survivorcreator.Config;
import dev.survivorcreator.data.DataRegistry;
import dev.survivorcreator.data.Perk;
import dev.survivorcreator.data.Profession;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;

public final class Validator {
    private Validator() {
    }

    public static int professionCost(Profession p) {
        return p == null ? 0 : p.cost();
    }

    public static int perkCost(Perk p) {
        return p == null ? 0 : p.cost();
    }

    public static int points(Optional<ResourceLocation> prof, List<ResourceLocation> perks) {
        int pts = (Integer)Config.START_POINTS.get() + 5;
        if (prof.isPresent()) {
            pts -= Validator.professionCost(DataRegistry.profession(prof.get()));
        }
        for (ResourceLocation id : perks) {
            pts -= Validator.perkCost(DataRegistry.perk(id));
        }
        return pts;
    }

    public static Result validate(Optional<ResourceLocation> prof, List<ResourceLocation> perks, boolean fin) {
        Profession pr = null;
        if (prof.isPresent()) {
            pr = DataRegistry.profession(prof.get());
            if (pr == null) {
                return Result.fail("unknown_profession", prof.get().toString());
            }
        } else if (fin && ((Boolean)Config.PROFESSION_REQUIRED.get()).booleanValue() && !DataRegistry.professionList().isEmpty()) {
            return Result.fail("profession_required", "");
        }
        List<ResourceLocation> all=new java.util.ArrayList<>(perks);
        if(pr!=null)all.addAll(pr.grantedPerks());
        HashSet<ResourceLocation> seen = new HashSet<ResourceLocation>();
        int pos = 0;
        int neg = 0;
        for (ResourceLocation id : perks) {
            Perk p = DataRegistry.perk(id);
            if (p == null) {
                return Result.fail("unknown_perk", id.toString());
            }
            if (!seen.add(id) && !((Boolean)Config.ALLOW_DUPLICATES.get()).booleanValue()) {
                return Result.fail("duplicate", id.toString());
            }
            if (p.negative()) {
                ++neg;
            } else {
                ++pos;
            }
            for (ResourceLocation c : p.conflicts()) {
                if (!all.contains(c)) continue;
                return Result.fail("conflict", String.valueOf(id) + "|" + String.valueOf(c));
            }
            for (ResourceLocation r : p.requiresPerks()) {
                if (all.contains(r)) continue;
                return Result.fail("requires_perk", r.toString());
            }
            if (!(p.requiresProfessions().isEmpty() || !prof.isEmpty() && p.requiresProfessions().contains(prof.get()))) {
                return Result.fail("requires_profession", id.toString());
            }
            if (pr != null && pr.incompatiblePerks().contains(id)) {
                return Result.fail("incompatible_profession", id.toString());
            }
            if (pr == null || !pr.grantedPerks().contains(id)) continue;
            return Result.fail("duplicate", id.toString());
        }
        if(pr!=null)for(ResourceLocation granted:pr.grantedPerks()) {
            Perk included=DataRegistry.perk(granted);if(included==null)continue;
            for(ResourceLocation conflict:included.conflicts())if(perks.contains(conflict))return Result.fail("conflict",granted+"|"+conflict);
        }
        int pts = Validator.points(prof, perks);
        if (fin && pts < 0) {
            return Result.fail("negative_points", "" + pts);
        }
        return Result.OK;
    }

    public record Result(boolean ok, String key, String arg) {
        static final Result OK = new Result(true, "", "");

        static Result fail(String code, String arg) {
            return new Result(false, "survivorcreator.error." + code, arg);
        }
    }
}

