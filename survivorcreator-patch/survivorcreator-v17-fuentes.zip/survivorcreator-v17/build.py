from pathlib import Path
import subprocess,zipfile,copy,sys,json,hashlib
r=Path(__file__).resolve().parent;base=Path(sys.argv[1]).resolve()
assert hashlib.sha256(base.read_bytes()).hexdigest()==(r/'base.sha256').read_text().strip()
for n,h in json.loads((r/'tools.sha256.json').read_text()).items():assert hashlib.sha256((r/'tools'/n).read_bytes()).hexdigest()==h
cp=':'.join(map(str,(r/'tools').glob('asm*.jar')))
ecj=['java','-jar',str(r/'tools/ecj.jar'),'-21','-proc:none','-warn:none']
def run(*args):subprocess.run(list(args),check=True)
run(*ecj,'-cp',str(base),'-d',str(r/'classes'),*[str(p) for folder in ['src','stubs'] for p in (r/folder).rglob('*.java')])
run(*ecj,'-cp',cp,'-d',str(r/'patch-tool'),str(r/'Patch.java'))
run('java','-cp',str(r/'patch-tool')+':'+cp,'Patch',str(base),str(r/'patched'))
run(*ecj,'-cp',str(r/'classes')+':'+str(base),'-d',str(r/'test-classes'),*[str(p) for p in (r/'tests').rglob('*.java')])
run('java','-Xverify:all','-cp',':'.join(map(str,[r/'test-classes',r/'classes',r/'patched',base])),'SurvivorChecks')
add={p.relative_to(r/folder).as_posix():p.read_bytes() for folder in ['classes','patched'] for p in (r/folder/'dev').rglob('*.class')}
# Only production dev classes compile into classes; all fake APIs live in stubs or test-classes.
add.update({p.relative_to(r/'resources').as_posix():p.read_bytes() for p in (r/'resources').rglob('*') if p.is_file()})
modified=set(add)
out=r/'output/survivorcreator-neoforge-1.21.1-1.0.9-zomboid-v17-profiles.jar';out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(base) as z:
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for entry in z.infolist():w.writestr(copy.copy(entry),add.pop(entry.filename,z.read(entry)))
  for n,b in sorted(add.items()):w.writestr(n,b)
 with zipfile.ZipFile(out) as w:
  assert w.testzip() is None
  for n in z.namelist():
   if n not in modified:assert z.read(n)==w.read(n),n
  assert not any(n.startswith(('net/','com/','org/')) for n in w.namelist())
  known_ok=set(json.loads((r/'ok-items.json').read_text()))
  defs={n:json.loads(w.read(n)) for n in w.namelist() if n.startswith('data/survivorcreator/survivor/') and n.endswith('.json')}
  perks={n.rsplit('/',1)[1][:-5] for n in defs if '/perks/' in n}
  for n,d in defs.items():
   for field in ['perks','incompatible_perks','conflicts','requires_perks']:
    for id in d.get(field,[]):assert id.split(':')[1] in perks,(n,id)
   for effect in d.get('effects',[]):
    assert effect['type'] in {'attribute','exhaustion','damage_taken','start_item','mob_effect'}
    if effect.get('item','').startswith('okadditions:'):assert effect['item'].split(':')[1] in known_ok
  print('PASS',len(perks),'traits;',len(defs)-len(perks),'professions; resources and preserved original entries')
print(out)
