from pathlib import Path
import zipfile,copy,hashlib,sys
r=Path(__file__).resolve().parent;base=Path(sys.argv[1]);assert hashlib.sha256(base.read_bytes()).hexdigest()==(r/'ok-base.sha256').read_text().strip()
out=r/'output/okadditions-1.1.0-neoforge-1.21.1-compat.jar';out.parent.mkdir(exist_ok=True)
name='META-INF/neoforge.mods.toml'
with zipfile.ZipFile(base) as z:
 original=z.read(name);assert original.count(b'versionRange="[1.21]"')==1
 changed=original.replace(b'versionRange="[1.21]"',b'versionRange="[1.21,1.21.2)"')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for entry in z.infolist():w.writestr(copy.copy(entry),changed if entry.filename==name else z.read(entry))
 with zipfile.ZipFile(out) as w:
  assert w.testzip() is None
  assert {n for n in z.namelist() if z.read(n)!=w.read(n)}=={name}
print('PASS OK Additions: metadata only; all code, assets, credits and license preserved')
print(out)
